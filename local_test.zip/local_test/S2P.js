!function (t, r) {
    "use strict";
    "function" == typeof define && define.amd ? define(r) : "object" == typeof exports ? module.exports = r() : t.S2P = r()
}(this, function () {
    "use strict";
    function t(t, r, n, e) {
        this.x0 = t, this.y0 = r, this.x1 = n, this.y1 = e
    }

    function r(t, r, n) {
        return Math.abs(t - r) <= (n || 1e-6)
    }

    function n(t, n, e) {
        return r(t.x, n.x, e) && r(t.y, n.y, e)
    }

    function e(t, n, e, i, o) {
        return r((t.x - n.x) * (e.y - i.y) - (t.y - n.y) * (e.x - i.x), 0, o)
    }

    function i(t, r, n, e) {
        var i = (t.x - r.x) * (n.y - e.y) - (t.y - r.y) * (n.x - e.x), o = 1 / i, u = t.x * r.y - t.y * r.x, a = n.x * e.y - n.y * e.x, v = u * (n.x - e.x) - (t.x - r.x) * a, f = u * (n.y - e.y) - (t.y - r.y) * a;
        return {x: v * o, y: f * o}
    }

    function o(t, r, n) {
        var e = u(n, t, r);
        return Math.abs(t.x - r.x) > Math.abs(t.y - r.y) ? (e.x - t.x) / (r.x - t.x) : (e.y - t.y) / (r.y - t.y)
    }

    function u(r, n, e) {
        var i = new t(n.x, n.y, e.x, e.y);
        return i.getClosestPoint(r.x, r.y)
    }

    function a(t, r) {
        return 180 * Math.atan2(r.y - t.y, r.x - t.x) / Math.PI
    }

    function v(r, n) {
        var e = new t(r.x, r.y, n.x, n.y), i = e.getSegmentLength();
        return i
    }

    function f(t) {
        var r = typeof t;
        if ("object" == r || "array" == r) {
            if (t && t.clone)
                return t.clone();
            var n = "array" == r ? [] : {};
            for (var e in t)
                n[e] = f(t[e]);
            return n
        }
        return t
    }

    function s(t) {
        var r = f(t);
        return r
    }

    function y(t, r) {
        if (t === !1)throw new Error(r)
    }

    function h(t) {
        return t.id = t.id || g++ + "", t.id
    }

    function x(t, r) {
        return {x: t.x - r.x, y: t.y - r.y}
    }

    function c(t, r) {
        function u(t) {
            var r = j;
            for (var e in m) {
                var i = m[e];
                if (n(t, i, r))return i
            }
            var o = s(t);
            return o.e = [], m[h(o)] = o, o
        }

        m = {}, S = {}, I = {}, b = [], y(Array.isArray(t) && Array.isArray(r)), l("init");
        for (var a = 0; a < r.length; ++a) {
            var f = r[a], x = f.v1, c = f.v2, p = u(t[x]), d = u(t[c]), g = {v1: h(p), v2: h(d), e: [], id: f.id};
            S[h(g)] = g
        }
        l("build Segment and Vertex complete!!");
        for (var M in S) {
            var P = S[M], w = m[P.v1], C = m[P.v2], E = [w, C];
            for (var L in S) {
                var N = S[L];
                if (h(P) != h(N)) {
                    var H = m[N.v1], q = m[N.v2];
                    if (!e(w, C, H, q, j)) {
                        var A = i(w, C, H, q), O = o(w, C, A), k = o(H, q, A), j = .01;
                        if (!(0 - j > O || O > 1 + j || 0 - j > k || k > 1 + j)) {
                            var A = u(A);
                            E.push(A)
                        }
                    }
                }
            }
            E.sort(function (t, r) {
                return v(w, t) - v(w, r)
            });
            for (var a = 0; a < E.length - 1; ++a) {
                var D = E[a], _ = E[a + 1];
                if (h(D) != h(_)) {
                    var B = {v1: h(D), v2: h(_), s: h(P)};
                    I[h(B)] = B, P.e.pushIfNotHas(h(B)), D.e.pushIfNotHas(h(B)), _.e.pushIfNotHas(h(B))
                }
            }
        }
        return l("build Edge complete!!"), {VERTICES: m, SEGMENTS: S, EDGES: I}
    }

    function p(t, r) {
        function n(t) {
            var r = I[t];
            delete I[t];
            var n = m[r.v1], e = m[r.v2], i = n.e.indexOf(t), o = e.e.indexOf(t);
            y(-1 != i && -1 != o), n.e.splice(i, 1), e.e.splice(o, 1);
            var u = S[r.s], a = u.e.indexOf(t);
            return y(-1 != a), u.e.splice(a, 1), r
        }

        function e() {
            for (var t = Object.keys(I), r = t.length - 1; r > 0; --r)for (var e = I[t[r]], i = 0; r > i; ++i) {
                var o = I[t[i]];
                if (e && o && (e.v1 == o.v1 && e.v2 == o.v2 || e.v1 == o.v2 && e.v2 == o.v1)) {
                    n(e.id);
                    break
                }
            }
        }

        function i() {
            function t() {
                for (var t in m) {
                    var r = m[t];
                    if (1 == r.e.length)return r.e[0]
                }
            }

            do {
                var r = t();
                void 0 != r && n(r)
            } while (void 0 != r)
        }

        function o() {
            var t = [];
            for (var r in I) {
                var n = I[r], e = m[n.v1], i = m[n.v2];
                t.pushIfNotHas(e), t.pushIfNotHas(i)
            }
            return t
        }

        function u() {
            var t = o();
            for (var r in I) {
                for (var n = I[r], e = 0, i = !0, u = m[n.v1], a = m[n.v2], v = 0; v < t.length; ++v) {
                    var f = t[v];
                    if (h(f) != h(u) && h(f) != h(a)) {
                        var s = x(f, u), y = x(a, f), c = y.x * s.y - s.x * y.y;
                        if (Math.abs(c) > .01) {
                            if (0 > e * c) {
                                i = !1;
                                break
                            }
                            e = c
                        }
                    }
                }
                if (i)return {id: r, left: e > 0}
            }
        }

        function v(t, r) {
            function n(t, r) {
                function n(t, r, n) {
                    var e = a(t, r), i = a(t, n), o = i - e;
                    return o > 0 ? o : 360 + o
                }

                for (var e = r.v1 == h(t) ? m[r.v2] : m[r.v1], i = t.e.map(function (t) {
                    return I[t]
                }), o = void 0, u = 360, v = 0; v < i.length; ++v) {
                    var f = i[v];
                    if (h(f) != h(r)) {
                        var s = f.v1 == h(t) ? m[f.v2] : m[f.v1], y = n(t, e, s);
                        u > y && (u = y, o = f)
                    }
                }
                return o
            }

            var e = I[r], i = m[t], o = {v: [i], e: []};
            do {
                var u = e.v1 == h(i) ? m[e.v2] : m[e.v1];
                o.v.push(u), o.e.push(e), e = n(u, e), i = u
            } while (e && h(i) != t);
            return o
        }

        do {
            e(), i(), l("make manifold structure to build profile.");
            var f = u();
            if (void 0 != f) {
                var s = 1 == f.left ? I[f.id].v2 : I[f.id].v1, c = v(s, f.id);
                //100 * M.getYear() + M.getMonth() < 11703 && b.push(c), n(f.id), l("build one profile.")
                b.push(c), n(f.id), l("build one profile.");
            }
        } while (void 0 != f);
        return l("Complete!!"), t === !0 ? b : b.map(function (t) {
            return t.v.map(function (t) {
                return {x: t.x, y: t.y, id: h(t)}
            })
        })
    }

    function d(t) {
        P = t
    }

    function l(t) {
    }

    t.prototype.clone = function () {
        return new t(this.x0, this.y0, this.x1, this.y1)
    }, t.prototype.equals = function (t) {
        return this.x0 == t.x0 && this.y0 == t.y0 && this.x1 == t.x1 && this.y1 == t.y1
    }, t.prototype.getSegmentLengthSquared = function () {
        var t = this.x1 - this.x0, r = this.y1 - this.y0;
        return t * t + r * r
    }, t.prototype.getSegmentLength = function () {
        return Math.sqrt(this.getSegmentLengthSquared())
    }, t.prototype.getClosestLinearInterpolation_ = function (t, r) {
        var n = r, e = this.x0, i = this.y0, o = this.x1 - e, u = this.y1 - i;
        return ((t - e) * o + (n - i) * u) / this.getSegmentLengthSquared()
    }, t.prototype.getInterpolatedPoint = function (t) {
        function r(t, r, n) {
            return t + n * (r - t)
        }

        return {x: r(this.x0, this.x1, t), y: r(this.y0, this.y1, t)}
    }, t.prototype.getClosestPoint = function (t, r) {
        return this.getInterpolatedPoint(this.getClosestLinearInterpolation_(t, r))
    }, t.prototype.getClosestSegmentPoint = function (t, r) {
        function n(t, r, n) {
            return Math.min(Math.max(t, r), n)
        }

        return this.getInterpolatedPoint(n(this.getClosestLinearInterpolation_(t, r), 0, 1))
    };
    var g = 1, m = {}, S = {}, I = {}, b = [], M = new Date;
    Array.prototype.pushIfNotHas = function (t) {
        return -1 == this.indexOf(t) && this.push(t), this
    };
    var P = void 0, w = {};
    return w.MS = c, w.BP = p, w.DPCB = d, w
});