/*模型库+我的素材 模版在=ui\layout\layout.xml
 * --add by oxl*/
/*我的素材.catalogMaterial的选项卡内容区模版在=ui\catalog\catalog_oceano.xml
 * --add by oxl*/
$('.catalogMaterial').appendTo($('#panelProductMaterialId'));

window.uploadActiveStatus = false;//初始化上传状态
/*点击产品 add by oxl*/
function customProductClick(e) {
    var pid = $(this).attr("pid");
    if (PARQUET_EDIT_MODE === true) {
        ParquetEditor_CatalogImageClick(pid);
        return;
    }
    api.catalogGetCustomProductsMetaPromise([pid, pid, pid]).then(function (rv) {
        api.actionBegin("AddProduct", pid, rv);
    });
}

/*保存图片 imgTopResultArg：提交的图片；imgFileType：图片后缀名*/
var materialUploadImgAction=function(imgThumbResultArg,imgTopResultArg,imgFileType){
    var fileserver = api.getServicePrefix("file")
        ,customTileCatalogServer = api.getServicePrefix("customcatalog")
        ,materialId = api.uuid();
    /*上传文件的action
     *uploadFile接口在 file/index.js 定义
     * 上传接口会先保存到本地，再上传阿里云
     * add by oxl 2017-03-08
     * */

    var p=$("#uploadMaterial_oceano"),
        $title=p.find(".material_title_ipt").val(),
        $xlen=p.find(".material_xlen_ipt").val(),
        $ylen=p.find(".material_ylen_ipt").val(),
        $reflection=p.find(".material_reflection_sel option:selected").attr("reflectionValue");
    /*id产品id，globalPartyId：用户目录id*/
    var $objData={"pid":materialId,"title":$title,"xlen":$xlen,"ylen":$ylen,"reflection":$reflection,"globalPartyId":globalUsrObj.globalPartyId}
        ,commonUrl=fileserver + "/uploadFile" + "?id=" + materialId + "&category=product&"
        ,uploadThumbJpgUrl = commonUrl+"type=thumb"/*目录小图*/
        ,uploadTopJpgUrl = commonUrl+"type=topjpg"/*大图*/
        ,saveCustomTileUrl=customTileCatalogServer+"/addCustomTile/";
    api.getServiceJSONResponsePromise({
        url: (  api.getServicePrefix("customcatalog") )+ "/checklogin",
        type: "POST",
        data: {
            "globalUserLoginId":globalUsrObj.globalUserLoginId,
            "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue
        }
    }).then(function (resp) {
        //var formData=new FormData();
        //formData.append("data",imgThumbResultArg)
        if(resp.msg=="existsUser"){//注册用户
            /*先上传大图*/
            api.getServiceJSONResponsePromise({
                url: uploadTopJpgUrl,
                type: "POST",
                cache: false,
                contentType: false,
                processData: false,
                data: imgTopResultArg//可以用buffer或者formData，这里是buffer
            }).catch(function (e) {
                layer.alert('上传失败,请重试!! ', {
                    closeBtn: 0,
                    skin: 'layui-layer-default'
                });
                window.uploadActiveStatus = false;//重新定义上传状态
                resetUploadDialog();

            }).then(function(resp){
                /*大图内容为0，但不是错误的情况*/
                if(resp.error || !resp){
                    return ;
                }
                /*小图*/
                return api.getServiceJSONResponsePromise({
                    url: uploadThumbJpgUrl,
                    type: "POST",
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: imgThumbResultArg
                })//可以用buffer或者formData，这里是buffer

            }).then(function (resp) {
                /*成功保存图片后，再保存其他参数
                 * */
                if(resp){
                    /*保存其他参数*/
                    console.warn($objData);
                    api.getServiceJSONResponsePromise({
                        url: saveCustomTileUrl,
                        type: "POST",
                        cache: false,
                        data: $objData
                    }).then(function (r) {
                        var res = (r);
                        //添加成功后，触发一次请求最新数据
                        $("#productMaterialdefaultId").trigger("click");
                        /*提示上传成功*/
                        layer.msg("上传成功");
                        window.uploadActiveStatus = false;//重新定义上传状态
                        resetUploadDialog();
                        /*关闭弹出框*/
                        $("#uploadMaterial_oceano").dialog("close");
                    })
                }else{
                    layer.alert('上传失败,请重试!! ', {
                        closeBtn: 0,
                        skin: 'layui-layer-default'
                    });

                    window.uploadActiveStatus = false;//重新定义上传状态
                    resetUploadDialog();

                }
            });
        }
        else{
            $material.tips("请登录");
            window.uploadActiveStatus = false;//重新定义上传状态
        }
    });
}

/*关闭对话框时reset数据 2017-04-20*/
function resetUploadDialog(){
    //删除上传预览图的蒙板
    $("#localImag").removeAttr("class")
    //删除输入框数值
    $("#uploadMaterial_oceano").find("input").each(function(i,v){
        if(this.className=="txt")
            this.value="";
    });
    //下拉框数值选中默认
    $('.material_reflection_sel')[0].selectedIndex = 0;
    imgTopJpgResult=undefined;
    $(".uploadMaterial_img_box").attr("src","");
    /*解决能上传两张同样的图片*/
    $(".wrap_uploadMaterial_img_box").wrap("<form>").closest("form").get(0).reset();
}


$("#selectCustomTileType").dialog({
    autoOpen: false,
    width:576,
    dialogClass:"ui_whiteStyle"

})
/*关闭对话框时close事件的回调 2017-04-20*/
$('#uploadCustom_tile').dialog({
    width: 400,
    autoOpen: false,
    resizable: true,
    modal: false,
    dialogClass:"ui_whiteStyle",
    buttons: {
        '提交': function () {
            if(
                $material.checkMaterialName('uploadCustom_tile') &&
                $material.checkMaterialLength('uploadCustom_tile') &&
                $material.checkMaterialWidth('uploadCustom_tile') &&
                $material.checkMaterialReflection('uploadCustom_tile')
            ){
                if(!CustomParquetDwgBuffer){$material.tips("请先上传DWG文件");return;}
                $(this).dialog("close");
                $('#loadingCustomTile').dialog('open');
                upfileDWG();
            }
        },
        '取消': function () {
            $(this).dialog("close");
        }
    }
})
$("#uploadMaterial_oceano").dialog({
    width: 400,
    autoOpen: false,
    resizable: true,
    modal: false,
    dialogClass:"ui_whiteStyle",
    close: function( event, ui ) {
        resetUploadDialog();
    },
    buttons: {
        '提交': function () {
            //判断提交时是否都非空
            if (
                $material.checkMaterialName('uploadMaterial_oceano') &&
                $material.checkMaterialLength('uploadMaterial_oceano') &&
                $material.checkMaterialWidth('uploadMaterial_oceano') &&
                $material.checkMaterialReflection('uploadMaterial_oceano') &&
                $material.checkImgResult()
            ) {
                //判断是否重复提交
                if (window.uploadActiveStatus == false) {
                    window.uploadActiveStatus = true;
                    /*同时上传图片和素材数值*/
                    layer.msg('上传中...', {
                        icon: 16,
                        shade: false
                    });
                    materialUploadImgAction(imgThumbResult,imgTopJpgResult, imgFileType);
                } else {
                    $material.tips("素材已经上传,无须重复提交");
                }
            }

        },
        '取消': function () {
            $(this).dialog("close");
        }
    }

});



/*提交图片，imgTopJpgResult：提交的大图图片；imgFileType：图片后缀名，scaleRatio：压缩比例
 * */
var imgTopJpgResult,imgFileType,scaleRatio=0.85,imgThumbResult,
    uploadCustomTileChanged = (function () {
        var objectURL = undefined;
        var img = new Image();
        var maxSize=4096;
        var minSize=256;
        var compRatio=0.8//压缩比
        var minImgSize={width:minSize,height:minSize}
        var bigImgSize={};
        return function (e) {
            var file = e.target.files[0];
            var reader = new FileReader();
            var reader2 = new FileReader();
            imgFileType=file.name.substr(file.name.lastIndexOf(".")+1);//imgFileType=file.name.substr(file.name.lastIndexOf(".")+1).match(/.([\s\S]*)/)[1];
            if (objectURL) {
                /*释放ObjectURL对象资源*/
                window.URL.revokeObjectURL(objectURL);
                objectURL = undefined;
            }
            if(imgFileType=='jpg'){
                /*创建ObjectURL对象资源,同时创建小图*/
                objectURL = window.URL.createObjectURL(file);
                img.name = file.name, img.type = imgFileType, img.size = file.size;
                img.src = objectURL;
                var tempImgW,tempImgH;
                img.onload = function () {
                    //TODO 以下压缩图片代码需要合并优化 add by oxl 2017-04-07
                    //1.图片转为base64，并压缩处理，然后转为blob

                    //获取图片宽高，超出指定宽高需要修剪 add by oxl 2017-04-17
                    var imgSize={width:(+img.naturalWidth),height:(+img.naturalHeight)}
                    /*小于2048*2的时候,使用原来的imgSize宽高即可，大于2048*2，计算一下最新的数值*/
                    bigImgSize=adjustImageWH(imgSize, maxSize, maxSize)
                    minImgSize=adjustImageWH(imgSize, minSize, minSize)

                    //生成预览图blob
                    var imgThumbResult1 = imageToBlob(imageToBase64(img, compRatio, minImgSize));
                    //2.blob转为File 对象 http://stackoverflow.com/questions/27553617/convert-blob-to-file，这一部不是必须，这里直接使用blob对象
                    var imgThumbResult2 = new File([imgThumbResult1], file.name, {
                        type: file.type,
                        lastModified: Date.now()
                    });

                    /*如果高度比宽度大，添加一个class*/
                    $(".uploadMaterial_img_box").parent().removeClass("uploadMaterial_img_box_h").removeClass("mask");
                    $(".uploadMaterial_img_box").parent().addClass("mask")
                    if( img.width < img.height ){
                        $(".uploadMaterial_img_box").parent().addClass("uploadMaterial_img_box_h")
                    }

                    //3.处理为FileReader对象
                    //http://javascript.ruanyifeng.com/htmlapi/file.html 文件和二进制数据的操作
                    // http://www.cnblogs.com/jscode/archive/2013/04/27/3572239.html 直接读取 blob就行，因为File继承于blob
                    reader2.readAsArrayBuffer(imgThumbResult1);
                    /*输出小图Buffer*/
                    reader2.onload = function (e) {
                        imgThumbResult = this.result;
                    };

                    /*输出大图Buffer,将用户的大图片调整大小为 小于等于2048的尺寸*/
                    var imgTopJpgResult1 = imageToBlob(imageToBase64(img, compRatio, bigImgSize));
                    var imgTopJpgResult2 = new File([imgTopJpgResult1], file.name, {
                        type: file.type,
                        lastModified: Date.now()
                    });
                    reader.readAsArrayBuffer(imgTopJpgResult2);
                    reader.onload = function (e) {
                        imgTopJpgResult = this.result;
                    };
                }
                $(".uploadMaterial_img_box").attr("src", objectURL);


            }else{
                $material.tips("不是jpg文件");
            }


        }
    })();


/*base64图片转blob
 * TODO 1.整站需要修改成amd加载模式;2.等有时间使用localResizeIMG.js 来做兼容性调整。 add by oxl 2017-04-07
 * image:图片, quality：压缩质量,width,height, scale：缩放比例，默认1
 * */
function imageToBase64(image, quality,imgWh, scale) {
    var canvas = document.createElement('canvas');
    canvas.width = (imgWh.width || image.naturalWidth) * (scale || 1 );
    canvas.height = (imgWh.height || image.naturalHeight) * ( scale ||1 );
    //https://segmentfault.com/q/1010000000601812 html5 canvas的宽高有大小限制吗？
    /*TODO 超过这个值base64无法生成，在IOS上,移动端时需要优化，或者使用imgresize.js 2017-04-19
     while (canvas.width >= 3264 || canvas.height >= 2448) {
     canvas.width = canvas.naturalWidth * (scale || 1 )
     canvas.height = canvas.naturalHeight * (scale || 1 )
     }
     * */
    var ctx = canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height)
    var base64 = canvas.toDataURL('image/jpeg', quality);
    return base64;
}

function imageToBlob(base64) {
    var blob = dataURItoBlob(base64);
    blob.name = blob.filename //= image.name
    console.group('image compress to blob')
    // console.log('文件类型 => ' + image.type)
    //console.log('文件大小 => ' + (image.size / 1024 / 1024).toFixed(2) + 'M')
    //console.log('blob质量 => ' + quality)
    console.log('blob大小 => ' + (blob.size / 1024 / 1024).toFixed(2) + 'M')
    console.groupEnd()
    return blob;
}

function dataURItoBlob(dataURI) {
    var byteString = atob(dataURI.split(',')[1]);
    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0]
    var ab = new ArrayBuffer(byteString.length);
    var ia = new Uint8Array(ab);
    for (var i = 0; i < byteString.length; i++) {
        ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], {type: mimeString});
}
/*限制图片的宽高大小在指定范围内；
 imgSizeObj:包含宽高值的obj，WIDTH, HEIGHT:指定的最大宽高*/
function adjustImageWH(imgSizeObj, WIDTH, HEIGHT) {
//2048*6000
//2048*1024
//1024*2048
//1024*6000
//1024*600
    //复制一个内部的新对象
    var wh={width:imgSizeObj.width,height:imgSizeObj.height};
    var objW=wh.width,objH=wh.height;
    if (objW > 0 && objH > 0) {
        var scale=1;
        if(objW > WIDTH || objH > HEIGHT) {
            var scale;
            var scale1 = objW / WIDTH;
            var scale2 = objH / HEIGHT;
            if (scale1 > scale2) {
                scale = scale1;
            }
            else {
                scale = scale2;
            }
        }
        wh.width = parseInt(objW/scale);
        wh.height = parseInt(objH/scale);
    }
    return wh;
}

/*TODO 1.整站需要修改成amd加载模式;2.等有时间使用localResizeIMG.js 来做兼容性调整。 add by oxl 2017-04-07*/

/*通用方法*/
(function(window){
    var c = {};
    c.tips = function(msg,title){
        layer.open({
            title: title||'提示',
            content: msg
        });
    };
    //模版
    /*c.xxx=function(xxx){

    };*/
    //检查素材是否填写名字
    c.checkMaterialName=function(id) {
        if ($("#"+id+" .material_title_ipt").val() == "") {
            c.tips("请输入素材名字");
            return false;
        }
        return true;
    };
    //检查素材是否填写长度
    c.checkMaterialLength=function(id){
        if ($("#"+id+" .material_xlen_ipt").val() == "") {
            c.tips("请输入素材长度");
            return false;
        }
        if ($("#"+id+" .material_xlen_ipt").val() == 0) {
            c.tips("输入素材长度不能为0");
            return false;
        }
        if (isNaN(Number($("#"+id+" .material_xlen_ipt").val()))) {
            c.tips("您输入长度必须为数字");
            return false;
        }
        return true;
    };
    //检查素材是否填写宽度
    c.checkMaterialWidth=function(id) {
        if ($("#"+id+" .material_ylen_ipt").val() == "") {
            c.tips("请输入素材宽度");
            return false;
        }
        if ($("#"+id+" .material_ylen_ipt").val() == 0) {
            $material.tips("输入素材宽度不能为0");
            return false;
        }
        if (isNaN(Number($("#"+id+" .material_ylen_ipt").val()))) {
            $material.tips("您输入宽度必须为数字");
            return false;
        }
        return true;
    };
    //检查素材是否填写宽度
    c.checkMaterialReflection = function(id) {
        if ($("#"+id+" .material_reflection_sel option:selected").val() == "请选择") {
            c.tips("请选择素材反射系数");
            return false;
        }
        return true;
    };
    //检查素材是否填写宽度
    c.checkImgResult =function() {
        if (imgTopJpgResult == undefined) {
            c.tips("请选择上传素材图片");
            return false;
        }
        return true;
    };


    window.$material = c;

})(window);


/*订阅我的素材 事件*/
/*catalogSetUserCustomCatalogPromise：增加用户目录或检查用户目录，没有就创建，已有就无需操作*/
/*catalogGetCustomTileCatalogTreePromise：通过partyId来查询用户的目录*/
api.application_ready_event.add(function () {
    api.catalogSetUserRootCustomCatalogPromise("setUserRootCustomCatalog").then(function(v){
        return api.catalogSetUserRootCustomCatalogPromise("setRootFurnitureCatalog")
    }).then(function(v) {
        api.actionBeginEvent.add(function (action, actionType, args) {
            if (actionType == "AddProduct") {
                if (!args || args.length < 2) return;
                if (!args[1][args[0]])return;
                if (args[1][args[0]].category == "custom_tile" || args[1][args[0]].category == "customparquet") {
                    if (api.floorplanIsLocked() == false) {
                        // need to lock first:
                        layer.confirm('添加瓷砖类商品需要首先锁定户型。<br>是否需要锁定户型？', {
                            btn: ['确定', '取消'], //按钮
                            shade: 0.3, //不显示遮罩
                            skin: 'layui-layer-default',
                            title: '提示'
                        }, function (index) { //layer.msg('确定', {icon: 1});
                            layer.close(index);
                            if (api.floorplanIsLocked()) return;
                            api.floorplanLock(true);
                        }, function () { //layer.msg('取消', {shift: 6});
                        });
                        //if (window.confirm("添加瓷砖类商品需要首先锁定户型。\n是否需要锁定户型？") === true) {
                        //    $("#toolLockFloorplan").trigger("click");
                        //} else return;
                    }
                    
                    $("body").css({cursor: ""});
                    $("body").attr("class", "");
                    $("body").addClass("brushCursor");
                }
            } else if (actionType == "AddWall") {

            }
        });

        api.catalogGetCustomTileCatalogTreePromise()
            .then(function (root) {
                /*我的素材-左边栏"默认"标签tab*/
                /*头部tab点击定义在catalog.js*/
                $("<li id='productMaterialdefaultId' class='selected'><a>拼花</a></li>").appendTo(".MaterialLi")
                    .on("mouseleave", function (e) {
                        $(this).removeClass("hover");
                    }).on("click", function (e) {
                    $("#customModelSeries,#customModelStyle").hide()
                    //加载默认的产品数据
                    loadCustomCatalogProducts(globalUsrObj.globalPartyId, 0, 20);
                    $("#materialSearch,.catalogMaterial .catalogMaterialPagination").show();
                    $("#materialSearch .line .valueText").val('');
                    $("#materialContent").empty();
                    $("#catalogMyMaterialId").clone(true).removeAttr("id").show().appendTo($("#materialContent"));
                    resizePage();
                }).on("mouseover", function (e) {
                    $(this).addClass("hover");
                    $(".content_catalog").empty();
                    $(".catalogRoomContent").hide();
                });


                //读取自定义模型品牌列表 此版本暂时注释以下代码
                api.catalogGetCatalogTreePromise()
                    .then(function (root) {
                        var customCatalogServicePrefix = api.getServicePrefix("customcatalog");
                        var getProductCategoryAPi = customCatalogServicePrefix + "/getProductCategory";
                        var getStyleAPi = customCatalogServicePrefix + "/getProductAllStyle";
                        var getTagAPi = customCatalogServicePrefix + "/getProductAllTag";

                        var furnitureRoot;
                        //获取大类+子类-2017-08-29
                        api.getServiceJSONResponsePromise({
                            type: 'get',
                            url: getProductCategoryAPi,
                            cache: false,
                            data: {}
                        }).then(function (res) {
                            window.furnitureModelDateJson=furnitureRoot=res;

                            //获取风格类型
                            api.getServiceJSONResponsePromise({
                                type: 'get',
                                url: getStyleAPi,
                                cache: false,
                                data: {}
                            }).then(function (res) {
                                window.furnitureModelStyleDateJson=JSON.parse(res);
                                api.getServiceJSONResponsePromise({
                                    type: 'get',
                                    url: getTagAPi,
                                    cache: false,
                                    data: {ucid:globalUsrObj.globalPartyId}
                                }).then(function (r) {
                                    window.furnitureModelTagDateJson=JSON.parse(r);
                                })
                            })

                            furnitureRoot.children.forEach(function (level1,i) {
                                if(i>0)return
                                var cataloghide = "";
                                $("<li style='" + cataloghide + "'><a>模型</a></li>").attr("id", "productModeldefaultId")
                                    .appendTo(".MaterialLi")
                                    .on("click", function (e) {
                                        initList()

                                        /*点击左边一级目录 初始化二、三级目录 start*/
                                        var catalogLevel1 = furnitureRoot;
                                        var catalogLevel2 = undefined;
                                        var catalogLevel3 = undefined;
                                        furnitureRoot.children.forEach(function (level2, index2) {
                                            if (index2 == 0) {
                                                catalogLevel2 = level2;
                                                level2.children.forEach(function (level3, index3) {
                                                    if (index3 == 0) {
                                                        catalogLevel3 = level3;
                                                    }
                                                });
                                            }
                                        });
                                        var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:catalogLevel3.ENUM_CODE,style:window.furnitureModelStyleDateJson[0].sid,tags:"all"};
                                        //读取level3的id
                                        loadCustomModelProducts(dataObj, 0, 10);
                                        resizePage();

                                        initSelectModelCatalog(catalogLevel1, catalogLevel2, catalogLevel3);
                                        initSelectTagModelCatalog()
                                        /*点击一级目录 初始化二、三级目录 end*/
                                    }).on("mouseover", function (e, idx) {
                                    //弹出菜单
                                    var $menu = $(this);
                                    $menu.addClass("hover");
                                    var $subMenu = $("#panelProductMaterialId .catalogMaterial .catalogRoomContent");
                                    $("#panelProductMaterialId .catalogMaterial .catalogRoomContent .content_catalog").empty(); // clear all.
                                    furnitureRoot.children.forEach(function (level2) {
                                        var level2Root = $("<div>").appendTo(".content_catalog");
                                        var level2Title = $("<div>").addClass("title").text(level2.DESCRIPTION).appendTo(level2Root);
                                        var level2ul = $("<ul>").appendTo(level2Root);
                                        level2.children.forEach(function (level3) {
                                            var level2li = $("<li>").text(level3.DESCRIPTION).appendTo(level2ul)
                                                .on("mouseover", function () {
                                                    $(this).addClass("hover");
                                                })
                                                .on("mouseleave", function () {
                                                    $(this).removeClass("hover");
                                                })
                                                .on("click", function (e) {
                                                    initList()
                                                    //showOrHideBrandSeriesSearchItem(level3);
                                                    /*硬编码逻辑：一级菜单硬装点击不显示风格和色系
                                                     1、不需要风格和色系查询
                                                     2、品牌只显示【欧神诺】
                                                     * */
                                                    $("#panelProductMaterialId .catalogMaterial .catalogRoomContent").hide();
                                                    $('#productsList').empty();
                                                    /*一级目录高亮切换*/
                                                    $("#panelProductMaterialId .catalogMaterial .catalogRoomLeft li[id='productModeldefaultId']").addClass("selected");
                                                    $("#panelProductMaterialId .catalogMaterial .catalogRoomLeft li[id='productModeldefaultId']").siblings("li").removeClass("selected");
                                                    var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:level3.ENUM_CODE,style:window.furnitureModelStyleDateJson[0].sid,tags:"all"};
                                                    loadCustomModelProducts(dataObj, 0, 10);
                                                    $("#ModelContent").empty();
                                                    $("#catalogMyBrandId").clone(true).removeAttr("id").show().appendTo($("#materialContent"));
                                                    initSelectModelCatalog(furnitureRoot, level2, level3);
                                                    initSelectTagModelCatalog()
                                                });
                                        });
                                    });
                                    if($subMenu.find(".content_catalog").height()==0) {
                                        setBrandSubMenuPos($menu, $subMenu);
                                    }
                                    setBrandSubMenuPos($menu, $subMenu);
                                }).on("mouseleave", function (e) {
                                    $(this).removeClass("hover");
                                });
                            });

                        })
                        /*点击左边栏目模型时初始化 add by hcw*/
                        function initList() {
                            $("#customModelSeries,#customModelStyle").show()
                            $("#materialContent").empty();
                            $("#materialSearch .line .valueText").val('');
                            $("#catalogMyModelId").clone(true).removeAttr("id").show().appendTo($("#materialContent"));
                        }
                    })

                /*TODO 此处代码不要删除 基本接口已处理好，侧边栏标签待下个版本做 2017-03-07
                 * 暂时隐藏分类 2017-04-07
                 * add by oxl
                 * */
                //TODO 参考catalog的逻辑
                root.children.forEach(function (level1) {
                    $("<li><a>" + level1.label + "</a></li>").attr("id", level1.cid)
                        .appendTo(".MaterialLi").on("click",function(){

                    })
                })


                /*************************** 自定义拼花打开对话框后所有逻辑操作 **********************************/
                function uploadMaterialBtnHandler() {
                    $("#selectCustomTileType").dialog("open").dialog({zIndex:1001});
                    $(".renderPanel_oceano").hide();
                    $("#renderPanel_oceano").dialog("close");
                }
                $("#selectCustomTileType .picture").on(click, function(){
                    $("#selectCustomTileType").dialog("close")
                    $("#uploadMaterial_oceano").dialog("open").dialog({zIndex:1001});

                });
                $("#selectCustomTileType .cad").on(click, function(){
                    //layer.msg("开发中，敬请期待");return;
                    $("#selectCustomTileType").dialog("close")
                    $("#uploadCustom_tile").dialog("open").dialog({zIndex:1001});

                });
                /*定义上传素材对话框*/




                /*打开对话框点击事件*/
                /*打开对话框点击事件*/
                $(".materialUploadBtn").on(click, uploadMaterialBtnHandler);
                /*选择图片事件*/
                $("#customTileImageFile").on("change", uploadCustomTileChanged);
                /*对话框的保存按钮点击事件，TODO 点击提交素材不能同名还没做*/
                $("#customTileDWGFile").on("change", changeUploadParquet);


                /*************************** 自定义拼花打开对话框后所有逻辑操作 **********************************/

            });
    })
});








function searchAction() {
    var searchstring = $("#materialSearch").find(".valueText").val();
    if (searchstring == ''){
        $("#productMaterialdefaultId").trigger("click");
        return
    };
    loadSearchedMaterials(searchstring, 0, 20);
}
function throttle(fn,idle, context) {
    clearTimeout(fn.tId);
    fn.tId = setTimeout(function(){
        fn.apply(this,context);
    }, idle);
}
var debounce = function( fn,idle ){
    var last
    return function(){
        var context = this, args = arguments
        clearTimeout(last)
        last = setTimeout(function(){
            fn.apply(context, args)
        }, idle)
    }
}




/*目录中的搜索输入为空时自动请求一次 add by oxl*/
$("#materialSearch").find(".valueText").on("keyup",function(){
    if($('#productMaterialdefaultId').hasClass("selected")){
        throttle(searchAction,300)
    }else{
        throttle(searchModelAction,300) //加载自定义模型搜索 add by hcw
    }
    // throttle(searchAction,300)
})
/*搜索按钮点击事件*/
$("#materialSearch .line .button").on("click", function (e) {
    if($('#productMaterialdefaultId').hasClass("selected")){
        throttle(searchAction,300)
    }else{
        throttle(searchModelAction,300) //加载自定义模型搜索  add by hcw
    }
    //throttle(searchAction,300)
});


/**
 * 加载自定义目录下的产品
 * @param cid
 * @param viewindex
 * @param viewsize
 */
function loadCustomCatalogProducts(cid, viewindex, viewsize) {
    $("#custom_productsList").empty();
    var data = {
        "cid": cid,
        "viewindex": viewindex,
        "viewsize": viewsize
    };

    api.getServiceJSONResponsePromise({
        type: 'get',
        url: ( api.getServicePrefix("customcatalog") )+ "/getCustomProductsByCatalogId",
        cache: false,
        data: data
    }).then(function (products) {
        renderCustomCatalogProducts(products);
        /*初始化分页属性*/
        if (products && products.length > 0) {
            $(".catalogMaterialPagination").show();
            resizePage();
            $(".catalogMaterialPagination .pagination").pagination(products[0].count, {
                callback: function (page_index, jq) {
                    loadCustomCatalogProducts(cid, page_index, viewsize);
                },
                prev_text: '<',
                next_text: '>',
                items_per_page: 20,
                num_display_entries: 4, //连续分页主体部分显示的分页条目数
                current_page: viewindex,
                num_edge_entries: 2 //两侧显示的首尾分页的条目数
            });
        } else {
            $(".catalogMaterialPagination").hide();
        }
    }).catch(function (e) {
        layer.alert('send getCustomProductsByCatalogId request to server failed!! ', {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
    });
}


/*渲染[自定义拼花] 目录里面的数据
 * add by oxl
 * */
function renderCustomCatalogProducts(products) {
    if (!products || products.length == 0) return;

    var $productZoom = $('#materialZoom').css({"height":"380px"});
    products.forEach(function (leaf) {
        var $productItem = $("<div>");
        $productItem.attr({
            pid: leaf.pid,
            title: leaf.title
        })
            .addClass("img_container")
            .appendTo($("<li>")
                .appendTo("#custom_productsList"))
            .on("click", customProductClick)
            .each(function () {
                var pid = leaf.pid;
                var _self = this;
                var product_name = leaf.title;
                var product_xlen = leaf.xlen;
                var product_ylen = leaf.ylen;
                var product_reflection = JSON.parse(leaf.extra).reflection;

                //loadProductImage(api.catalogGetFileUrl("product", pid, "iso"), _self);
                //目录的小预览图，修正为自适应宽高 oxl
                $("<img>").attr({
                    src: ui.catalogGetFileUrl("product", pid, "iso"),
                    class: 'prodimg'
                }).load(function(e){
                    var imgSize={"width":this.naturalWidth,"height":this.naturalHeight};
                    imgSize=adjustImageWH(imgSize, 100, 100);
                    $(this).css({ width: imgSize.width, height: imgSize.height });
                }).appendTo(this);


                $("<div>").addClass("img_oper")
                    .append($("<div>").addClass("bookremark").attr("title", "收藏"))
                    .append($("<div>").addClass("info").hover(function (e) {
                        $productZoom.empty();
                        $("<div>").addClass("wrap-product-zoom-img")
                            .append(
                                $("<img>")
                                    .addClass("prodimg product-zoom-img")
                                    .attr({
                                        src: ui.catalogGetFileUrl("product", leaf.pid, "iso"),
                                        objid:pid
                                    }).load(function(e){
                                    var imgSize={"width":this.naturalWidth,"height":this.naturalHeight};
                                    imgSize=adjustImageWH(imgSize, 300, 300);
                                    $(this).css({ width: imgSize.width, height: imgSize.height });
                                })
                            ).appendTo($productZoom);



                        var product_size = (Math.ceil(leaf.xlen * 1000) / 1000) + "x" + (Math.ceil(leaf.ylen * 1000) / 1000);
                        if (leaf.zlen > 0) product_size += "x" + (Math.ceil(leaf.zlen * 1000) / 1000);
                        var product_brand = fakeUnnicodeToChinese(leaf.productbrand);
                        if ('' == product_brand) product_brand = "无";

                        $("<div objpid="+pid+" product_name="+product_name+" product_xlen="+product_xlen+" product_ylen="+product_ylen+" product_reflection="+product_reflection+">").addClass("product-short-info")
                            .append($("<div>").addClass("name").text("【" + (leaf.model || "") + leaf.title + "】"))
                            .append($("<div>").addClass("size").text("尺寸：" + product_size + "(m)"))
                            .append($("<div>").addClass("size").text("品牌：" + product_brand))
                            .append($("<div>").addClass("modify_btn button").text("修改"))
                            .append($("<div>").addClass("delete_btn button").text("删除"))
                            .appendTo($productZoom);
                        var position = $(_self).position();


                        var zoomTop = position.top;
                        var zoomLeft = (position.left + 98) + 'px';
                        var zoomHeight = $productZoom.height();
                        var catalogHeight = jQuery('.catalogRoomRight').height();

                        if (catalogHeight - zoomTop - zoomHeight < 30) {
                            var productItemHeight = $productItem.parent().height();
                            zoomTop = position.top + productItemHeight - zoomHeight;
                        }

                        zoomTop = (zoomTop + 20) + 'px';

                        $productZoom
                            .css({
                                left: zoomLeft,
                                top: zoomTop
                            })
                            .show()
                            .hover(function (e) {
                                $(this).show();
                            }, function (e) {
                                $(this).hide();
                            });

                    }, function (e) {
                        $productZoom.hide();
                    }))
                    .appendTo(this);
            }).hover(function (e) {
            $(this).find(".img_oper").addClass("img_oper_cur");
        }, function (e) {
            $(this).find(".img_oper").removeClass("img_oper_cur");
        });


        ;
        lazyLoad.init();
    });

}

/**
 * 加载搜索后的产品
 * @param searchstring
 * @param viewindex
 * @param viewsize
 * todo 搜索待定还没修改
 */
function loadSearchedMaterials(searchstring, viewindex, viewsize) {
    $("#custom_productsList").empty();
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: api.getServicePrefix("customcatalog") + "/searchProductsFromCustomCatalog",
        cache: false,
        data: {
            "searchstring": searchstring,
            "globalPartyId":globalUsrObj.globalPartyId,
            "viewindex": viewindex,
            "viewsize": viewsize
        }
    }).then(function (products) {
        renderCustomCatalogProducts(products);
        /*初始化分页属性*/
        if (products && products.length > 0) {
            $(".catalogMaterialPagination").show();
            $(".catalogMaterialPagination .pagination").pagination(products[0].count, {
                callback: function (page_index, jq) {
                    loadSearchedMaterials(searchstring, page_index, viewsize);
                },
                prev_text: '<',
                next_text: '>',
                items_per_page: 20,
                num_display_entries: 4, //连续分页主体部分显示的分页条目数
                current_page: viewindex,
                num_edge_entries: 2 //两侧显示的首尾分页的条目数
            });
        } else {
            $(".catalogMaterialPagination").hide();
        }
    }).catch(function (e) {
        layer.alert('send searchProductsFromCustomCatalog request to server failed!! ', {
            title: '提示',
            skin: 'layui-layer-default'
        });
    });
}


/*素材hover删除事件*/
$("#materialZoom").on("click",".delete_btn",function(){
    var that = $(this);
    var $img = that.parents("#materialZoom").find("img");
    var objid = $img.attr("objid");
    api.getServiceJSONResponsePromise({
        url: ( api.getServicePrefix("customcatalog") )+ "/delCustomTile",
        type: "POST",
        data: {
            "globalUserLoginId":globalUsrObj.globalUserLoginId,
            "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue,
            "globalPartyId":globalUsrObj.globalPartyId,
            "pid":objid
        }
    }).then(function (v) {
        if(v.error==0){
            that.parent().parent().hide();
            $("#custom_productsList li div[pid="+objid+"]").parent().remove()
            layer.msg("删除成功");
            return
        }
        v=JSON.parse(v)
        layer.msg(v.msg);
    }).catch(function (v) {
        $material.tips("删除失败");
    });
});

/*************************** 修改拼花打开对话框后所有逻辑操作 **********************************/
/*定义修改素材对话框*/
$("#modifyMaterial_oceano").dialog({
    width: 400,
    autoOpen: false,
    resizable: true,
    modal: false,
    dialogClass:"ui_whiteStyle",
    buttons:{
        "确定":function(){
            var materialId=$("#modify_material_pid_ipt").val(),
                p = $('#modifyMaterial_oceano'),
                $title=p.find(".material_title_ipt").val(),
                $xlen=p.find(".material_xlen_ipt").val(),
                $ylen=p.find(".material_ylen_ipt").val(),
                $reflection=p.find(".material_reflection_sel option:selected").attr("reflectionValue");
            var reader2 = new FileReader();
            /*输出小图Buffer*/
            reader2.onload = function (e) {
                imgThumbResult = this.result;
            };
            var $objData={
                "pid":materialId,
                "title":$title,
                "xlen":$xlen,
                "ylen":$ylen,
                "reflection":$reflection,
                "globalPartyId":globalUsrObj.globalPartyId
            };
            console.warn($objData);
            var customTileCatalogServer = api.getServicePrefix("customcatalog");
            var updateCustomTileUrl = customTileCatalogServer+"/updateCustomTile/";
            api.getServiceJSONResponsePromise({
                url: (  api.getServicePrefix("customcatalog") )+ "/checklogin",
                type: "POST",
                data: {
                    "globalUserLoginId":globalUsrObj.globalUserLoginId,
                    "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue
                }
            }).then(function (resp) {
                //var formData=new FormData();
                //formData.append("data",imgThumbResultArg)
                if (resp.msg == "existsUser") {//注册用户
                    api.getServiceJSONResponsePromise({
                        url: updateCustomTileUrl,
                        type: "POST",
                        cache: false,
                        data: $objData
                    }).catch(function (e) {
                        layer.alert('修改失败,请重试! ', {
                            closeBtn: 0,
                            skin: 'layui-layer-default'
                        });
                    }).then(function (r) {

                        if(
                            $material.checkMaterialName('modifyMaterial_oceano')&&
                            $material.checkMaterialLength('modifyMaterial_oceano')&&
                            $material.checkMaterialWidth('modifyMaterial_oceano')
                        ){
                            if(r.msg=="success saved"){
                                layer.msg("修改成功");
                                //删除成功后，触发一次请求最新数据
                                $("#productMaterialdefaultId").trigger("click");
                                $("#modifyMaterial_oceano").dialog("close");
                            }else{
                                layer.msg("修改失败");
                            }
                        }
                    });
                }else{
                    layer.msg("请登录再进行修改");
                }
            });
        },
        "取消":function(){
            $(this).dialog('close');
        }
    }
});

/*打开修改拼花对话框点击事件*/
$("#panelProductMaterialId").on("click",".modify_btn", function(){
    $("#modifyMaterial_oceano").dialog("open");
    var product_pid = $(this).parent().attr("objpid");
    var product_name = $(this).parent().attr("product_name");
    var product_xlen = $(this).parent().attr("product_xlen");
    var product_ylen = $(this).parent().attr("product_ylen");
    var product_reflection = $(this).parent().attr("product_reflection");
    var p = $('#modifyMaterial_oceano');

    $("#modify_material_pid_ipt").val(product_pid);
    p.find(".material_title_ipt").val(product_name);
    p.find(".material_xlen_ipt").val(product_xlen);
    p.find(".material_ylen_ipt").val(product_ylen);
    if(product_reflection==0){
        product_reflection ="无反射-0";
        console.warn(product_reflection)
    }
    else if(product_reflection==0.15){
        product_reflection ="抛晶砖-0.15";
        console.warn(product_reflection)
    }
    else if(product_reflection==0.25){
        product_reflection ="抛光砖-0.25";
        console.warn(product_reflection)
    }
    else if(product_reflection==0.1){
        product_reflection ="全反射-1";
        console.warn(product_reflection)
    }
    p.find(".material_reflection_sel option[value='"+product_reflection+"']").attr("selected",true);

});



//# sourceURL=ui\catalog\catalog_oceano_material.js
