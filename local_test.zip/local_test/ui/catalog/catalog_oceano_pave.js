api.application_ready_event.add(function () {
	api.actionBeginEvent.add(function (action, actionType, args) {
		if (actionType == "AddBoundary" ||
		    actionType == "TilesingleSetPave" ||
		    actionType == "AddWallBaseboard" ||
		    actionType == "SetWallboard") {
		    $("body").css({cursor: ""});
		    $("body").attr("class", ""); 	
			$("body").addClass("brushCursor");
		}
	});
	api.actionEndEvent.add(function (action, actionType, args) {			
		if (actionType == "AddBoundary" ||
		    actionType == "TilesingleSetPave" ||
		    actionType == "AddWallBaseboard" ||
		    actionType == "SetWallboard") {
			$("body").removeClass("brushCursor");	
		}
	});
})

//# sourceURL=ui\catalog\catalog_oceano_pave.js