var CustomParquetDwgBuffer;
var loading_setInterval;
var osnfuzzy;
/*定义上传素材对话框*/
$("#uploadMaterial_oceano_two").dialog({
    width: 500,
    autoOpen: false,
    resizable: true,
    modal: false
})
/*打开对话框点击事件*/
$("#materialUploadBtnTwo").on(click, function () {
    $("#uploadMaterial_oceano_two").dialog("open").dialog({"zIndex":1001});
});
/*选择图片事件*/
var changeUploadParquet=(function () {
    return function (e) {
        $('#loadingCustomTile .progress-bar').css('width','0%')
        $('#loadingCustomTile  .progress-value').html('0%');
        CustomParquetDwgBuffer='';
        var file = e.target.files[0];
        if(file.size>10*1024*1024){ $(this).val('');$material.tips("文件过大,请选择10M以内的文件");CustomParquetDwgBuffer='';return;}
        var reader = new FileReader();
        reader.readAsArrayBuffer(file);
        reader.onload = function (e) {
            CustomParquetDwgBuffer = this.result;
            $('.Custom_tile_name .text').html(file.name)
        };
    }
})()

function upfileDWG(){
    loading_setInterval=setInterval(function(){
        var num = parseInt( $('#loadingCustomTile  .progress-value').html());
        if(num >= 30){
            clearInterval(loading_setInterval)
        }else{
            var tmp = Math.floor(Math.random()*10%2)+1;
            $('#loadingCustomTile .progress-bar').css('width',(num+tmp)+'%')
            $('#loadingCustomTile  .progress-value').html((num+tmp)+'%');
        }
    },1000)

    var exportServer = api.getServicePrefix("export");
    //exportServer = 'http://114.55.36.70:6500';
    api.getServiceJSONResponsePromise({
        url: exportServer + "/uploadCustomParquetFile?id="+api.uuid(),
        type: "POST",
        cache: false,
        contentType: false,
        processData: false,
        data: CustomParquetDwgBuffer//可以用buffer或者formData，这里是buffer
    }).catch(function (e) {
        $('#customTileDWGFile').val('');
        $('#loadingCustomTile').dialog('close')
        layer.alert('上传失败,请重试!! ', {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
    }).then(function (data) {
        if(data.error==0 && data.msg){
            $('#loadingCustomTile .progress-bar').css('width','31%')
            $('#loadingCustomTile  .progress-value').html('31%');
            $('#customTileDWGFile').val('');
            $('.edit_parquet_content').attr('pid',data.msg)
            osnfuzzy = void 0;
            osnfuzzy_slider = void 0;
            osnfuzzy = new osnFuzzy(
                exportServer+'/getCustomParquetFile?id='+data.msg+"&size=",
                exportServer+'/getCustomParquetFile?id='+data.msg+"&size=2000",
                exportServer+'/getCustomParquetFile?id='+data.msg+"&size=1000",
                exportServer+'/getCustomParquetFile?id='+data.msg+"&size=600"
            );
            var p = $('#uploadCustom_tile'),
                title = p.find('.material_name input'),
                xlen = p.find('.material_length input'),
                ylen = p.find('.material_width input'),
                reflection = p.find(".material_reflection_sel option:selected").attr("reflectionValue");
            osnfuzzy.conf = {
                title:title.val(),
                ylen:ylen.val(),
                xlen:xlen.val(),
                reflection:reflection
            }
            osnfuzzy.dwg = CustomParquetDwgBuffer;
            CustomParquetDwgBuffer='';
            title.val('')
            ylen.val('')
            xlen.val('')
            p.find('.material_reflection_sel')[0].selectedIndex = 0;
            p.find('.Custom_tile_name .text').html('<span>文件小于10M</span>');
            osnfuzzy.init();
            //osnfuzzy.firstBtnStyle();
        }else{
            $('#customTileDWGFile').val('');
            $('#loadingCustomTile').dialog('close')
            layer.alert('上传失败,请重试!! ')
        }

    })
}
$("#customTileImageFileTwo").on("change",changeUploadParquet);

//# sourceURL=ui\catalog\catalog_oceano_parquet.js