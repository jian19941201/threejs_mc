var oceanoImportUnderlayChanged = (function () {
    var _imgcdndomain = "";
    var buildingModelPrefix ="";
    api.application_ready_event.add(function (setting) {
        _imgcdndomain = setting.imgcdndomain;
        buildingModelPrefix = _imgcdndomain + "/buildingimage/";
    });

    var oceanolayerTipsIndex = undefined;
    var objectURL = undefined;
    var img = new Image();
    var materialId = undefined;

    if (objectURL) {
        window.URL.revokeObjectURL(objectURL);
        objectURL = undefined;
    }
    function loadAliyunFile() {
        var designMeta = ui.getOpenedDesignMeta();
        if (!designMeta)return ;
        //var param_dtype = getQueryString("dtype");
        //var param_buildingmodelimg = getQueryString("buildingmodelimg");
        var param_dtype = designMeta.designType;
        var param_buildingmodelimg = designMeta.buildingModelImage;
        if (param_dtype && param_dtype == 'buildingmodel' && param_buildingmodelimg) {
            materialId = api.uuid();
            var oReq = new XMLHttpRequest();
            if(!designMeta.designId){
                oReq.open("GET", param_buildingmodelimg, true);
            }else{
                oReq.open("GET", buildingModelPrefix + param_buildingmodelimg, true);
            }
            oReq.responseType = "blob";
            oReq.onreadystatechange = function () {
                if (oReq.readyState == oReq.DONE) {
                    var blob = oReq.response;

                    /*blob转arrayBuffer*/
                    var arrayBuffer;
                    var fileReader = new FileReader();
                    fileReader.readAsArrayBuffer(blob);
                    fileReader.onload = function () {
                        arrayBuffer = this.result;
                        uploadFile(arrayBuffer);
                    };
                    objectURL = URL.createObjectURL(blob);
                    addUnderImage();
                }
            }
            oReq.send();
        }
    }


    function uploadFile(content) {
        var fileserver = api.getServicePrefix("file");
        var uploadUrl = fileserver + "/uploadFile" + "?id=" + materialId + "&category=underlay&type=thumb";
        api.getServiceJSONResponsePromise({
            url: uploadUrl,
            type: "POST",
            cache: false,
            contentType: false,
            processData: false,
            data: content
        }).then(function (resp) {
            var res = (resp);
        });
    }

    function addUnderImage() {
        img.src = objectURL;
        img.onload = function (e) {
            var target = e.target;
            api.actionBegin("AddUnderImage", {width: target.width, height: target.height, pid: materialId}, objectURL);
            layer.alert('为了精确地绘制户型图，请先绘制一面墙体并输入该墙的真实长度', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                layer.close(index);
                if (oceanolayerTipsIndex != undefined) {
                    layer.close(oceanolayerTipsIndex);
                }
                oceanolayerTipsIndex = layer.tips('第二步：描图画户型', '.draw', {
                    tips: [1, '#CC3525'],
                    time: 6000
                });
            });
        }
    }

    return loadAliyunFile;
})();

/*目录中的搜索框，第一个字符禁止输空格*/
$(".catalog .catalogRoomRight .valueText").keypress(function (e) {
    if (e.keyCode == 32 && $(this).val().length == 0) {
        $(this).val('');
        return false;
    }

    /*回车键*/
    if (event.keyCode == 13) {
        $(this).siblings(".button").trigger("click");
    }

});
/*目录中的搜索按钮事件*/
$(".catalog .catalogRoomRight .button").on("click", function (e) {
    var searchstring = $(this).siblings(".valueText").val();
    if (searchstring == '')return;
    loadSearchedProducts(searchstring, 0, 20);
});


/**
 * 加载搜索后的产品
 * @param searchstring
 * @param viewindex
 * @param viewsize
 */
function loadSearchedProducts(searchstring, viewindex, viewsize) {
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: api.getServicePrefix("catalog") + "/searchProductsFromCatalog",
        cache: false,
        data: {
            "searchstring": searchstring,
            "viewindex": viewindex,
            "viewsize": viewsize
        }
    }).then(function (products) {
        $("#productsList").empty();
        renderCatalogProducts(products);
        /*初始化分页属性*/
        if (products && products.length > 0) {
            $(".catalogProductPagination").show();
            $(".catalogProductPagination .subPagination").hide()
            $(".catalogProductPagination .pagination").show().pagination(products[0].count, {
                callback: function (page_index, jq) {
                    loadSearchedProducts(searchstring, page_index, viewsize);
                },
                prev_text: '<',
                next_text: '>',
                items_per_page: 20,
                num_display_entries: 4, //连续分页主体部分显示的分页条目数
                current_page: viewindex,
                num_edge_entries: 2 //两侧显示的首尾分页的条目数
            });
        } else {
            $(".catalogProductPagination").hide();
        }
    }).catch(function (e) {
        layer.alert('send searchProductsFromCatalog request to server failed!! ', {
            title: '提示',
            skin: 'layui-layer-default'
        });
    });
}


/*获得二维数组子项总长度*/
function getArr2ElementNum(arr) {
    var eleNum = 0;
    if (arr == null) {
        return 0;
    }
    for (var i = 0; i < arr.length; i++) {
            eleNum++;
    }
    return eleNum;
};

var baseAssertUrl="asset/imgCatalog/pavingmodel",
    singleCeramicUrl=baseAssertUrl+"/single_ceramic",
    waveLineUrl=baseAssertUrl+"/waveLine",
    doubleCeramicUrl=baseAssertUrl+"/double_ceramic",
    multCeramicUrl=baseAssertUrl+"/mult_ceramic";



/*加载渲染铺贴模板列表*/
/*每一个子数组存放20条数据*/
var pavingModelObj = {
    "singleCeramic":[
        {
            "name":"混序直铺", "id":"singleCeramic01",  "url":singleCeramicUrl+"/single_ceramic1X.jpg","action":"SINGLEPAVE_01"
        },
        {
            "name":"连续直铺", "id":"singleCeramic01X",  "url":singleCeramicUrl+"/single_ceramic1.jpg","action":"SINGLEPAVE_01X"
        },
        {
            "name":"旋转铺砖", "id":"singleCeramic03",  "url":singleCeramicUrl+"/single_ceramic3.jpg","action":"SINGLEPAVE_03"
        },
        {
            "name":"人字铺砖", "id":"singleCeramic04",  "url":singleCeramicUrl+"/single_ceramic4.jpg","action":"SINGLEPAVE_04"
        },
        {
            "name":"错位铺砖", "id":"singleCeramic05",  "url":singleCeramicUrl+"/single_ceramic5.jpg","action":"SINGLEPAVE_05"
        },
        {
            "name":"错位铺砖", "id":"singleCeramic06",  "url":singleCeramicUrl+"/single_ceramic6.jpg","action":"SINGLEPAVE_06"
        },
        {
            "name":"六角铺砖", "id":"singleCeramic07",  "url":singleCeramicUrl+"/single_ceramic7.jpg","action":"SINGLEPAVE_07"
        },
        {
            "name":"六角铺砖", "id":"singleCeramic08",  "url":singleCeramicUrl+"/single_ceramic8.jpg","action":"SINGLEPAVE_08"
        },
        {
            "name":"六角铺砖", "id":"singleCeramic09",  "url":singleCeramicUrl+"/single_ceramic9.jpg","action":"SINGLEPAVE_09"
        }
    ],
    "pavingModelList":[
        {
            "name":"转角波打线", "id":"waveLine01",  "url":waveLineUrl+"/waveLine01.jpg"
        },
        {
            "name":"切角波打线", "id":"waveLine02",  "url":waveLineUrl+"/waveLine02.jpg"
        },
        {
            "name":"四件套波打线", "id":"waveLine03",  "url":waveLineUrl+"/waveLine03.jpg"
        }
    ],
    "elevationModelList":[
        {
            "name":"踢脚线", "id":"baseboard", "url":"asset/imgCatalog/pavingmodel/elevation/tijiaoxian.jpg","action":""
        },
        {
            "name":"立面铺贴01", "id":"wallboard01", "url":"asset/imgCatalog/pavingmodel/elevation/danyaoxian.jpg","action":""
        },
        {
            "name":"立面铺贴02", "id":"wallboard02", "url":"asset/imgCatalog/pavingmodel/elevation/shuangyaoxian.jpg","action":""
        },
        {
            "name":"立面铺贴03", "id":"wallboard03", "url":"asset/imgCatalog/pavingmodel/elevation/sanyaoxian.jpg","action":""
        },
        {
            "name":"立面铺贴04", "id":"wallboard04", "url":"asset/imgCatalog/pavingmodel/elevation/siyaoxian.jpg","action":""
        }
    ],
    //step 1 end ： goto 382
    "shuangzhuanModelList":[
        {
            "name":"双砖01", "id":"shuangzhuan01", "url":doubleCeramicUrl+"/doublePave001.jpg","action":"DOUBLEPAVE_01"
        },
        {
            "name":"双砖02", "id":"shuangzhuan02", "url":doubleCeramicUrl+"/doublePave002.jpg","action":"DOUBLEPAVE_02"
        },
        {
            "name":"双砖03", "id":"shuangzhuan03", "url":doubleCeramicUrl+"/doublePave003.jpg","action":"DOUBLEPAVE_03"
        },
        {
            "name":"双砖04", "id":"shuangzhuan04", "url":doubleCeramicUrl+"/doublePave004.jpg","action":"DOUBLEPAVE_04"
        },
        {
            "name":"双砖05", "id":"shuangzhuan05", "url":doubleCeramicUrl+"/doublePave005.jpg","action":"DOUBLEPAVE_05"
        },
        {
            "name":"双砖06", "id":"shuangzhuan06", "url":doubleCeramicUrl+"/doublePave006.jpg","action":"DOUBLEPAVE_06"
        },
        {
            "name":"双砖07", "id":"shuangzhuan07", "url":doubleCeramicUrl+"/doublePave007.jpg","action":"DOUBLEPAVE_07"
        },
        {
            "name":"双砖08", "id":"shuangzhuan08", "url":doubleCeramicUrl+"/doublePave008.jpg","action":"DOUBLEPAVE_08"
        },
        {
            "name":"双砖09", "id":"shuangzhuan09", "url":doubleCeramicUrl+"/doublePave009.jpg","action":"DOUBLEPAVE_09"
        },
        {
            "name":"双砖10", "id":"shuangzhuan10", "url":doubleCeramicUrl+"/doublePave010.jpg","action":"DOUBLEPAVE_10"
        },
        {
            "name":"双砖35", "id":"shuangzhuan35", "url":doubleCeramicUrl+"/doublePave035.jpg","action":"DOUBLEPAVE_35"
        },
        {
            "name":"双砖11", "id":"shuangzhuan11", "url":doubleCeramicUrl+"/doublePave011.jpg","action":"DOUBLEPAVE_11"
        },
        {
            "name":"双砖12", "id":"shuangzhuan12", "url":doubleCeramicUrl+"/doublePave012.jpg","action":"DOUBLEPAVE_12"
        },
        {
            "name":"双砖13", "id":"shuangzhuan13", "url":doubleCeramicUrl+"/doublePave013.jpg","action":"DOUBLEPAVE_13"
        },
        {
            "name":"双砖14", "id":"shuangzhuan14", "url":doubleCeramicUrl+"/doublePave014.jpg","action":"DOUBLEPAVE_14"
        },
        {
            "name":"双砖15", "id":"shuangzhuan15", "url":doubleCeramicUrl+"/doublePave015.jpg","action":"DOUBLEPAVE_15"
        },
        {
            "name":"双砖16", "id":"shuangzhuan16", "url":doubleCeramicUrl+"/doublePave016.jpg","action":"DOUBLEPAVE_16"
        },
        {
            "name":"双砖17", "id":"shuangzhuan17", "url":doubleCeramicUrl+"/doublePave017.jpg","action":"DOUBLEPAVE_17"
        },
        {
            "name":"双砖18", "id":"shuangzhuan18", "url":doubleCeramicUrl+"/doublePave018.jpg","action":"DOUBLEPAVE_18"
        },
        {
            "name":"双砖19", "id":"shuangzhuan19", "url":doubleCeramicUrl+"/doublePave019.jpg","action":"DOUBLEPAVE_19"
        },
        {
            "name":"双砖20", "id":"shuangzhuan20", "url":doubleCeramicUrl+"/doublePave020.jpg","action":"DOUBLEPAVE_20"
        },
        {
            "name":"双砖21", "id":"shuangzhuan21", "url":doubleCeramicUrl+"/doublePave021.jpg","action":"DOUBLEPAVE_21"
        },

        {
            "name":"双砖23", "id":"shuangzhuan23", "url":doubleCeramicUrl+"/doublePave023.jpg","action":"DOUBLEPAVE_23"
        },
        {
            "name":"双砖24", "id":"shuangzhuan24", "url":doubleCeramicUrl+"/doublePave024.jpg","action":"DOUBLEPAVE_24"
        },
        {
            "name":"双砖25", "id":"shuangzhuan25", "url":doubleCeramicUrl+"/doublePave025.jpg","action":"DOUBLEPAVE_25"
        },
        {
            "name":"双砖26", "id":"shuangzhuan26", "url":doubleCeramicUrl+"/doublePave026.jpg","action":"DOUBLEPAVE_26"
        },
        {
            "name":"双砖27", "id":"shuangzhuan27", "url":doubleCeramicUrl+"/doublePave027.jpg","action":"DOUBLEPAVE_27"
        },
        {
            "name":"双砖28", "id":"shuangzhuan28", "url":doubleCeramicUrl+"/doublePave028.jpg","action":"DOUBLEPAVE_28"
        },
        {
            "name":"双砖29", "id":"shuangzhuan29", "url":doubleCeramicUrl+"/doublePave029.jpg","action":"DOUBLEPAVE_29"
        },
        {
            "name":"双砖30", "id":"shuangzhuan30", "url":doubleCeramicUrl+"/doublePave030.jpg","action":"DOUBLEPAVE_30"
        },
        {
            "name":"双砖31", "id":"shuangzhuan31", "url":doubleCeramicUrl+"/doublePave031.jpg","action":"DOUBLEPAVE_31"
        },
        {
            "name":"双砖32", "id":"shuangzhuan32", "url":doubleCeramicUrl+"/doublePave032.jpg","action":"DOUBLEPAVE_32"
        },
        {
            "name":"双砖33", "id":"shuangzhuan33", "url":doubleCeramicUrl+"/doublePave033.jpg","action":"DOUBLEPAVE_33"
        },
        {
            "name":"双砖36", "id":"shuangzhuan36", "url":doubleCeramicUrl+"/doublePave036.jpg","action":"DOUBLEPAVE_36"
        }
    ],
    "duozhuanModelList":[
        //{
        //    "name":"多砖01", "id":"duozhuan01", "url":waveLineUrl+"/waveLine01.jpg","action":""
        //},
        //{
        //    "name":"多砖02", "id":"duozhuan02", "url":waveLineUrl+"/waveLine02.jpg","action":""
        //}
        {
            "name":"多砖07", "id":"duozhuan07", "url":multCeramicUrl+"/multPave007.jpg","action":"MULTPAVE_07"
        },
        {
            "name":"多砖08", "id":"duozhuan08", "url":multCeramicUrl+"/multPave008.jpg","action":"MULTPAVE_08"
        },
        {
            "name":"多砖09", "id":"duozhuan09", "url":multCeramicUrl+"/multPave009.jpg","action":"MULTPAVE_09"
        },
        {
            "name":"多砖10", "id":"duozhuan10", "url":multCeramicUrl+"/multPave010.jpg","action":"MULTPAVE_10"
        }
        ,
        {
            "name":"多砖11", "id":"duozhuan11", "url":multCeramicUrl+"/multPave011.jpg","action":"MULTPAVE_11"
        }
        ,
        {
            "name":"多砖12", "id":"duozhuan12", "url":multCeramicUrl+"/multPave012.jpg","action":"MULTPAVE_12"
        }
        // ,11和13一样
        // {
        //     "name":"多砖13", "id":"duozhuan13", "url":multCeramicUrl+"/multPave013.jpg","action":"MULTPAVE_13"
        // }
        ,
        {
            "name":"多砖14", "id":"duozhuan14", "url":multCeramicUrl+"/multPave014.jpg","action":"MULTPAVE_14"
        }
        ,
        {
            "name":"多砖16", "id":"duozhuan16", "url":multCeramicUrl+"/multPave016.jpg","action":"MULTPAVE_16"
        },
        {
            "name":"多砖22", "id":"duozhuan22", "url":multCeramicUrl+"/multPave022.jpg","action":"MULTPAVE_22"
        },
        // {
        //     "name":"多砖23", "id":"duozhuan23", "url":multCeramicUrl+"/multPave023.jpg","action":"MULTPAVE_23"
        // },
        {
            "name":"多砖24", "id":"duozhuan24", "url":multCeramicUrl+"/multPave024.jpg","action":"MULTPAVE_24"
        },
        {
            "name":"多砖25", "id":"duozhuan25", "url":multCeramicUrl+"/multPave025.jpg","action":"MULTPAVE_25"
        }
        ,
        {
            "name":"多砖26", "id":"duozhuan26", "url":multCeramicUrl+"/multPave026.jpg","action":"MULTPAVE_26"
        }
        ,
        {
            "name":"多砖27", "id":"duozhuan27", "url":multCeramicUrl+"/multPave027.jpg","action":"MULTPAVE_27"
        }
        ,
        {
            "name":"多砖28", "id":"duozhuan28", "url":multCeramicUrl+"/multPave028.jpg","action":"MULTPAVE_28"
        }
        ,
        {
            "name":"多砖30", "id":"duozhuan30", "url":multCeramicUrl+"/multPave030.jpg","action":"MULTPAVE_30"
        }
        ,
        {
            "name":"多砖31", "id":"duozhuan31", "url":multCeramicUrl+"/multPave031.jpg","action":"MULTPAVE_31"
        }
        ,
        {
            "name":"多砖32", "id":"duozhuan32", "url":multCeramicUrl+"/multPave032.jpg","action":"MULTPAVE_32"
        }
        ,
        {
            "name":"多砖33", "id":"duozhuan33", "url":multCeramicUrl+"/multPave033.jpg","action":"MULTPAVE_33"
        }
    ]
};

var paveActionObj = {};
for(var i in pavingModelObj.singleCeramic){
	paveActionObj[pavingModelObj.singleCeramic[i].action]=pavingModelObj.singleCeramic[i];
}
for(var i in pavingModelObj.pavingModelList){
	paveActionObj[pavingModelObj.pavingModelList[i].action]=pavingModelObj.pavingModelList[i];
}
for(var i in pavingModelObj.elevationModelList){
	paveActionObj[pavingModelObj.elevationModelList[i].action]=pavingModelObj.elevationModelList[i];
}
for(var i in pavingModelObj.shuangzhuanModelList){
	paveActionObj[pavingModelObj.shuangzhuanModelList[i].action]=pavingModelObj.shuangzhuanModelList[i];
}
for(var i in pavingModelObj.duozhuanModelList){
	paveActionObj[pavingModelObj.duozhuanModelList[i].action]=pavingModelObj.duozhuanModelList[i];
}

var paveIdObj = {};
for(var i in pavingModelObj.singleCeramic){
	paveIdObj[pavingModelObj.singleCeramic[i].id]=pavingModelObj.singleCeramic[i];
}
for(var i in pavingModelObj.pavingModelList){
	paveIdObj[pavingModelObj.pavingModelList[i].id]=pavingModelObj.pavingModelList[i];
}
for(var i in pavingModelObj.elevationModelList){
	paveIdObj[pavingModelObj.elevationModelList[i].id]=pavingModelObj.elevationModelList[i];
}
for(var i in pavingModelObj.shuangzhuanModelList){
	paveIdObj[pavingModelObj.shuangzhuanModelList[i].id]=pavingModelObj.shuangzhuanModelList[i];
}
for(var i in pavingModelObj.duozhuanModelList){
	paveIdObj[pavingModelObj.duozhuanModelList[i].id]=pavingModelObj.duozhuanModelList[i];
}

/*单砖数据源和显示容器*/
var singleCeramicList = pavingModelObj.singleCeramic;
var singleCeramicListDiv =".pavingModelContent .singleCeramicList";
/*波打线数据源和显示容器*/
var pavingModelList = pavingModelObj.pavingModelList;
var pavingModelListDiv =".pavingModelContent .pavingModelList";
/*双砖数据源和显示容器*/
var shuangzhuanModelList = pavingModelObj.shuangzhuanModelList;
var shuangzhuanModelListDiv =".pavingModelContent .shuangzhuanModelList";
/*多砖数据源和显示容器*/
var duozhuanModelList = pavingModelObj.duozhuanModelList;
var duozhuanModelListDiv =".pavingModelContent .duozhuanModelList";
/*立面铺贴数据源和显示容器*/
var elevationModelList = pavingModelObj.elevationModelList;
var elevationModelListDiv =".pavingModelContent .elevationModelList";

/*铺贴模板分页函数*/
function pavingModelPagination(ModelList,ModelListDiv){
    var modelCeramicList = getArr2ElementNum(ModelList);
    if (modelCeramicList && modelCeramicList > 0) {
        $(".catalogProductPagination").show();
        $(".catalogProductPagination .pagination").pagination(modelCeramicList, {
            callback:pageCallback,
            prev_text: '<',
            next_text: '>',
            items_per_page: 20,
            num_display_entries: 4, //连续分页主体部分显示的分页条目数
            current_page: 0,
            num_edge_entries: 2 //两侧显示的首尾分页的条目数
        });
        function pageCallback(page_index,jq){//0
            $(ModelListDiv).empty();
            renderPavingModel(ModelList,page_index,ModelListDiv);
        }
    } else {
        $(".catalogProductPagination").hide();
    }
};
/*渲染铺贴模板列表函数*/
function renderPavingModel(data,index,div){
    $(div).empty();
    var host = window.location.hostname;
    data = data.slice(index*20,index*20+20);
        $.each(data,function(i,item){
                var imgTitle = item.id;
                var title = item.name;
                var imgUrl = item.url;
                if(host == "localhost" || host == "127.0.0.1"){
                    imgUrl = "ui/catalog/"+imgUrl;
                };
                var DivContent = "<div class='img_container' title='"+title+"' imgTitle='"+imgTitle+"'style='background-image:url("+imgUrl+")'"+"'></div>";
                $(DivContent).appendTo($("<li>").appendTo(div));
        });
};

/*铺贴模板*/
$(".pavingModelItems").on("click","li",function(){
    $(this).addClass("current").siblings().removeClass("current");
    $(".catalog .catalogProductPagination").show();
});
/*单砖*/
$(".pavingModelItems").on("click",".single_ceramic",function(){
    $(".pavingModelContent .singleCeramicList").empty();
    renderPavingModel(singleCeramicList,0,singleCeramicListDiv);
    pavingModelPagination(singleCeramicList,singleCeramicListDiv);
    $(".singleCeramicList").show().siblings().hide();
});
/*波打线*/
$(".paving").on("click",function(){
    $(".pavingModelContent .pavingModelList").empty();
    renderPavingModel(pavingModelList,0,pavingModelListDiv);
    pavingModelPagination(pavingModelList,pavingModelListDiv);
    $(".pavingModelList").show().siblings().hide();
});
/*双砖*/
$(".double_ceramic").on("click",function(){
    $(".pavingModelContent .shuangzhuanModelList").empty();
    renderPavingModel(shuangzhuanModelList,0,shuangzhuanModelListDiv);
    pavingModelPagination(shuangzhuanModelList,shuangzhuanModelListDiv);
    $(".shuangzhuanModelList").show().siblings().hide();
});
/*多砖*/
$(".more_ceramic").on("click",function(){
    $(".pavingModelContent .duozhuanModelList").empty();
    renderPavingModel(duozhuanModelList,0,duozhuanModelListDiv);
    pavingModelPagination(duozhuanModelList,duozhuanModelListDiv);
    $(".duozhuanModelList").show().siblings().hide();
});
/*立面铺贴*/
$(".elevation").on("click",function(){
    $(".pavingModelContent .elevationModelList").empty();
    renderPavingModel(elevationModelList,0,elevationModelListDiv);
    pavingModelPagination(elevationModelList,elevationModelListDiv);
    $(".elevationModelList").show().siblings().hide();
});

$(".pavingModelContent").on("click",".img_container",function(){
    var title = $(this).attr("imgTitle");
    //console.warn(title);



    var failAlert = function(){
    	layer.alert('波打线添加失败', {title: '提示', skin: 'layui-layer-default'}, function (index) {
          layer.close(index);
      });
    }

    if(title.indexOf("singleCeramic") >=0){  //单砖
        var num = title.substring(13,title.length);
        api.actionBegin("TilesingleSetPave", "SINGLEPAVE_" + num);
    }else if(title.indexOf("shuangzhuan") >=0)//双砖
    {
        var num = title.substring(11,title.length);
        api.actionBegin("TilesingleSetPave", "DOUBLEPAVE_" + num);

    }else if(title.indexOf("duozhuan") >=0)//多砖
    {
        var num = title.substring(8,title.length);
        api.actionBegin("TilesingleSetPave", "MULTPAVE_" + num);

    }else if(title.indexOf("waveLine") >=0){//波打线
        switch(title) {
            //波打线部分
            case "waveLine01":
                //转角波打线 "corner" 转角类型
                api.actionBegin("AddBoundary", {
                    type: "corner",
                    base: "paa17fb28c6b74500bbafcd81e5da7354",
                    corner: "p561cafec23e944ab89634bd0cbdc6b23",
                    size: 0.12
                }, failAlert);
                break;
            case "waveLine02":
                //切角波打线
                api.actionBegin("AddBoundary", {
                    type: "base",
                    base: "p2d0ccb1015624c2596555b0aaf501377",
                    corner: "p8f9b024e43e64dc0bf51d7da321ac613",
                    size: 0.12
                }, failAlert);
                break;
            case "waveLine03":
                //四件套波打线 corner + base + left + right 四件套
                api.actionBegin("AddBoundary", {
                    type: "cblr",
                    base: "p01212d0d2b2646f6a943cb3bf38b9b7c",
                    corner: "p8f9b024e43e64dc0bf51d7da321ac613",
                    left: "p4f8e2bc0c83240d4bc378ec81ffb4a40",
                    right: "p6abd67bb2bcf4104a3a3e79cf477484c",
                    cornerRot: 90,
                    size: 0.15
                }, failAlert);
                break;
        }
    }else{
    	switch(title){
    		//立面铺贴
				case "baseboard":
				    //踢脚线
				    api.actionBegin("AddWallBaseboard");
				    break;
				case "wallboard01":
				    //踢脚线
				    api.actionBegin("SetWallboard",[{pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:1.2},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.1},
				                                    {pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:1.2}]);
				    break;
				case "wallboard02":
				    //踢脚线
				    api.actionBegin("SetWallboard",[{pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.1},
				                                    {pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.1},
				                                    {pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8}
				                                    ]);
				    break;  
				case "wallboard03":
				    //踢脚线
				    api.actionBegin("SetWallboard",[{pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.1},
				                                    {pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.2}]);
				    break; 
				case "wallboard04":
				    //踢脚线
				    api.actionBegin("SetWallboard",[{pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.1},
				                                    {pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.2},
				                                    {pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.8},
				                                    {pid:"p341de63930674205912658d6fd79e0aa",height:0.1},
				                                    {pid:"p9b8ebdd80a0f4a4d88939f5b54836fdf",height:0.4}]);
				    break;
    	}
    }

});


//# sourceURL=ui\catalog\catalog_oceano.js