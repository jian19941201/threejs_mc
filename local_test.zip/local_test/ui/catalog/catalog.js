$('.catalog').appendTo($('#panelProductLibraryId'));

//显示或隐藏品牌系列查询项全局变量
var showOrHideBrandSeriesSearchItemG = null;

function productClick(pid,pids) {
    //var pid = $(this).attr("pid");
    console.log('PARQUET_EDIT_MODE='+PARQUET_EDIT_MODE);
    if (PARQUET_EDIT_MODE === true) {
        ParquetEditor_CatalogImageClick(pid);
        return;
    }
    if(pid == "waveLine01"){
         var RV = {
            "waveLine01":
            {
                attitude:"0",
                brand:"b6b27795e8bfa",
                category:"tile",
                extra:'{"reflection":"0.25","reflectiong_lossiness":"1"}',
                hasmax:"0",
                hasobj:"0",
                model:null,
                pid:"waveLine01",
                subcategory:null,
                title:"波打线1",
                version:"20161128113103",
                xlen:1.2,
                ylen:0.6,
                zlen:0
            }
        };
        var rvPromise = Promise.resolve(RV);
        rvPromise.then(function (rv) {
            api.actionBegin("AddProduct", pid, rv);
        });
        //api.actionBegin("AddProduct", pid, RV);

    }else{
    api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
        console.warn(rv);
        console.warn(api.catalogGetProductsMetaPromise([pid, pid, pid]));
        if(osnfuzzy){
            if(osnfuzzy.data.step==0){layer.msg('请先完成颜色填充，再选砖');return;}
            if(osnfuzzy.data.step==1){layer.msg('请先点击下一步，再选砖');return;}
            osnfuzzy.data.selectTile=rv[Object.keys(rv)[0]];
        }else if(rv[pid].category=='productset'){
            if((pids.length!=0)){
               // viewSubComponents(pids)
                var productGroup=JSON.parse(rv[pid].group);
                if (productGroup) {
                    makeTempGroup(productGroup)
                } else {
                    viewSubComponents(pids)
                }
            }else {
                //pids为0的时候点击没反应
            }

        }else {
            console.warn(rv[pid].extra)
            var productGroup=JSON.parse(rv[pid].group);
            if(pids && productGroup){
                    makeTempGroup(productGroup)
            }else{
                api.actionBegin("AddProduct", pid, rv);
            }
        }
    });
    }

    removePrevPrdObj();
}
// 添加可拖拽临时组合 add by hcw
function makeTempGroup(groups) {
    api.removeTempGroup()
    if(groups.length>0){
        var alreadyPicked=[],offetx,offety,factor=200,models,count=0;
        groups.forEach(function (p,i) {
            api.catalogGetProductsMetaPromise([p.pid, p.pid, p.pid]).then(function (rv) {
                count+=1;
                var product = api.actionBegin("AddProduct", p.pid, rv);
                product.x = p.x+factor, product.y = p.y+factor,product.z = p.z;
                product.px = p.x, product.py = p.y, product.rot=p.rot;
                product.quaternion_w=p.quaternion_w, product.quaternion_x=p.quaternion_x;
                product.quaternion_y=p.quaternion_y, product.quaternion_z=p.quaternion_z;
                product.sx=p.sx, product.sy=p.sy,product.sz=p.sz;
                product.rotx=p.rotx, product.roty=p.roty,product.rotz=p.rotz;
                api.actionEnd("AddProduct");
                if(count==1){
                    offetx=p.x,offety=p.y;
                    product.x=0.001+factor, product.y=0.001+factor;
                    product.px=0.001, product.py=0.001
                    models=product
                }else{
                    product.x=p.x-offetx+factor, product.y=p.y-offety+factor;
                    product.px=p.x-offetx,product.py=p.y-offety
                    alreadyPicked.push(product)
                }
                if(count==groups.length){
                    api.addTempGroup(alreadyPicked,models);
                    var groupCount = api.floorplanFilterEntity(function (e) {
                        return e.type == "GROUP";
                    }).length;
                    var group = api.actionBegin("AddGroup");
                    group.name = "我的组合-" + (groupCount <= 10 ? "0" : "") + groupCount;
                }
            })
        })

    }
}


function removePrevPrdObj(){
    var curAction = api.getCurrentAction();
    if(curAction){
        if(!curAction.hasOwnProperty('product')){
            //删除拖动出来临时组合的所有产品 add by hcw
            var group = api.floorplanFilterEntity(function (e) {
                return e.type == "GROUP";
            })
            group.forEach(function (g) {
                if(g.id=="TempGroup" && g.children.length>0 || g.children.length==0){
                    api.actionBegin("DeleteGroup", g);
                    api.actionEnd("DeleteGroup")
                }
            })
        }else{
            api.actionBegin("DeleteProduct", curAction.product);
            api.actionEnd("DeleteProduct");
        }
    }
};

//点击查看套件，进入套件
function viewSubComponents(id){
    $('#productsList,.catalogProductPagination .pagination').hide();
    $('#subProductsList,.catalogProductPagination .subPagination').show();
    loadCatalogSubProducts(JSON.parse(id),0,20);
}
function loadCatalogSubProducts(pids, viewindex, viewsize) {

    api.getServiceJSONResponsePromise({
        type: 'get',
        url: api.getServicePrefix("catalog") + "/getProductsByProductsId",
        //url:  "http://localhost:8080/getProductsByProductsId",
        cache: false,
        data: {
            pids:pids,
            "viewindex": viewindex,
            "viewsize": viewsize,
        }
    }).then(function (products) {
        $('#subProductsList ul').empty();
        renderCatalogProducts(products,"subProducts");
        /*初始化分页属性*/
        if (products && products.length > 0) {
            $(".catalogProductPagination").show();
            resizePage();
            $(".catalogProductPagination .subPagination").pagination(pids.length, {
                callback: function (page_index, jq) {
                        loadCatalogSubProducts(pids, page_index, viewsize)
                },
                prev_text: '<',
                next_text: '>',
                items_per_page: 20,
                num_display_entries: 4, //连续分页主体部分显示的分页条目数
                current_page: viewindex,
                num_edge_entries: 2 //两侧显示的首尾分页的条目数
            });
        } else {
            $(".catalogProductPagination").hide();
        }

    }).catch(function (e) {
        console.log(e);
        layer.alert('send getProductsByCatalogId request to server failed!! ', {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
    });
}
function setCatalogSubMenuPos($selectedMenu, $subMenu) {

    var bodyHeight = $body.height();
    var menuOffset = $selectedMenu.offset();
    //var menuTop = menuOffset.top;
    var menuTop = $selectedMenu[0].offsetTop+12;
    var menuWidth = $selectedMenu.width();
    var menuHeight = $selectedMenu.height();
    var bottomSpace = bodyHeight - menuTop;
    var topBarSpace = 120;
    var maxTopSpace = bodyHeight - topBarSpace;

    var subMenuHeight = $subMenu.find(".content_catalog").height();
    var subMenuLeft = (menuOffset.left + menuWidth) + 'px';
    var subMenuTop = bottomSpace < subMenuHeight ?
        (menuTop + menuHeight - subMenuHeight + 1) :
        menuTop;

        $subMenu.height(subMenuHeight+10);
    if (subMenuTop < 0) {
        subMenuTop = 0;
        $subMenu.height(bodyHeight -subMenuTop );
        $subMenu.css("overflow","auto");
    }

    $subMenu.css({
        left: subMenuLeft,
        top: subMenuTop + 'px'
    }).show();
}
function loadProductImage(imageurl, $container) {
    var img = new Image();
    img.width = '100';
    img.height = '100';
    //img.className = 'prodimg ui-imglazy';
    img.src = imageurl;
    var $div = $("<div>").addClass("prodimg").attr({"style": "width:100px;height:100px;"});
    $($div).appendTo($container);
    if (img.complete) {
        console.log("pid complete=" + imageurl);
        $div.remove();
        $(img).appendTo($container);
    } else {
        img.onload = function (e) {
            console.log("pid success=" + imageurl);
            $div.remove();
            $(img).appendTo($container);
        }

        img.onerror = function (e) {
            console.log("pid error=" + imageurl);
            //loadProductImage(imageurl,$container);
        }
    }
}

/*渲染[产品库]catalog 目录里面的数据
* add by oxl
* */

window.swapUsagecount={};
function renderCatalogProducts(products) {
    var parentId="#productsList";
    if(arguments[1]){
        parentId="#subProductsList ul";
        $("#productsList").hide();
        $("subProductsList").show();
    }else{
        $("#productsList").show();
        $("subProductsList").hide();
    }

    $("#productContent .items").remove();
    if (!products || products.length == 0) return;

    var $productZoom = $('#productZoom');
    //console.warn(products)

    products.forEach(function (leaf) {
        var $productItem = $("<div>",{
            pid: leaf.pid,
            "title": leaf.title,
            "category_pid":leaf.category,
            "class":'img_container',
    }).appendTo($("<li>")
            .appendTo(parentId))
            .on("click", function(){
                productClick(leaf.pid,leaf.pids);
            })
            .each(function () {
                var pid = leaf.pid;
                var pids = leaf.pids;
                var _self = this;
                window.swapUsagecount[pid]=leaf.usagecount;

                //loadProductImage(api.catalogGetFileUrl("product", pid, "iso"), _self);

                    $("<img>",{
                        src: ui.catalogGetFileUrl("product", pid, "iso"),
                        width: '100%',
                        height: '100%',
                        class: 'prodimg'
                    }).appendTo(this);

                $("<div>").addClass("img_oper")
                    .append($("<div>").addClass("bookremark").attr("title", "收藏"))
                    .append($("<div>").addClass("info").hover(function (e) {
                        $productZoom.empty();

                            $("<img>",{
                                'class':"prodimg product-zoom-img",
                                src: ui.catalogGetFileUrl("product", leaf.pid, "iso")
                            }).appendTo($productZoom);

                        var product_size = (Math.ceil(leaf.xlen * 1000) / 1000) + "x" + (Math.ceil(leaf.ylen * 1000) / 1000);
                        if (leaf.zlen > 0) product_size += "x" + (Math.ceil(leaf.zlen * 1000) / 1000);
                        var product_brand = fakeUnnicodeToChinese(leaf.productbrand);
                        if ('' == product_brand) product_brand = "无";

                        var usagecount = window.swapUsagecount[pid];

                        var div=$("<div>").addClass("product-short-info")
                            .append($("<div>").addClass("name").text("【" + (leaf.model || "") + leaf.title + "】"+ (leaf.category=='furniture_replacement'?"(可替换材质)":"")))
                            .append($("<div>").addClass("size").text("尺寸：" + product_size + "(m)"))
                            .append($("<div>").addClass("size").text("品牌：" + product_brand))
                            .append($("<div>").addClass("hotPoint").text("热度：" + usagecount))
                            .attr({
                                pid: leaf.pid
                            });
                        api.checkEditGroupModel() && pids &&(div.append($("<div>").addClass("save_group button ").text("保存套件")))
                        div.appendTo($productZoom);
                        var position = $(_self).position();


                        var zoomTop = position.top;
                        var zoomLeft = (position.left + 98) + 'px';
                        var zoomHeight = $productZoom.height();
                        var catalogHeight = jQuery('.catalogRoomRight').height();

                        if (catalogHeight - zoomTop - zoomHeight < 30) {
                            var productItemHeight = $productItem.parent().height();
                            zoomTop = position.top + productItemHeight - zoomHeight;
                        }

                        zoomTop = (zoomTop + 46) + 'px';

                        $productZoom
                            .css({
                                left: zoomLeft,
                                top: zoomTop
                            })
                            .show()
                            .hover(function (e) {
                                $(this).show();
                            }, function (e) {
                                $(this).hide();
                            });

                    }, function (e) {
                        $productZoom.hide();
                    }))
                    .appendTo(this);
                 //添加可替换材质模型图标 add by hcw
                 if(leaf.category=='furniture_replacement')$("<div>").addClass("showFurnitureReplacement").appendTo(this);
                    //点击图片查看套件
                    //2017.5.4 add by xph 查看套件
                    $('#productsList').is(':visible') && pids && $("<div>",{
                        "class":"viewSubComponents",
                        title:"查看套件",
                        click:function(event){
                            viewSubComponents(pids);
                            event.stopPropagation();
                            event.preventDefault();
                        }
                    }).append($('<a>',{
                        "href":"javascript:"
                    })).appendTo(this);
            }).hover(function (e) {
                $(this).find(".img_oper").addClass("img_oper_cur");
                $(this).find(".showFurnitureReplacement").addClass("showFurnitureReplacement_hide");
            }, function (e) {
                $(this).find(".img_oper").removeClass("img_oper_cur");
                $(this).find(".showFurnitureReplacement").removeClass("showFurnitureReplacement_hide");
            });

        lazyLoad.init();

    });
}

//从套件点击返回，返回到上一层
$('#subProductsList>a').on('click',function(){
    $("#productsList,.catalogProductPagination .pagination").show();
    $("#subProductsList,.catalogProductPagination .subPagination").hide();
    $("#subProductsList ul").empty();

})
$("#main-design-area").on("mouseover", function (e) {
    $(".catalog .catalogRoomContent").hide();
});

/*编辑模式下保存组合套装事件 add by hcw*/
$("#panelProductLibraryId").on("click",".save_group", function() {
        var  group = api.pickGetPickedGroup();
        var  pid=$(this).parent('.product-short-info').attr('pid')
        if(group && pid){
                var dataArray=[];
                group.forEach(function (p) {
                    dataArray.push({pid:p.pid,x:p.x,y:p.y,z:p.z,rot:p.rot,quaternion_w:p.quaternion_w,quaternion_x:p.quaternion_w,quaternion_y: p.quaternion_y,quaternion_z:p.quaternion_z,rot:p.rot,rotx:p.rotx,roty:p.roty,rotz:p.rotz,sx:p.sx,sy:p.sy,sz:p.sz})
                })
                api.getServiceJSONResponsePromise({
                    url: ( api.getServicePrefix("catalog") )+ "/updateProductGroup/",
                    type: "POST",
                    data: {
                        "group":JSON.stringify(dataArray),
                        "pid":pid,
                    }
                }).then(function (v) {
                    if(v.error!=2){
                        api.clearCatalogProductMetaCache(pid)
                        layer.msg('保存成功')
                    }else{
                        layer.msg('保存失败')
                    }
                })
        }else{
            layer.msg('请选择一组套件组合！')
        }
});

var layerTipsIndex = undefined;
var importUnderlayChanged = (function () {
    var objectURL = undefined;
    var img = new Image();
    return function (e) {
        var file = e.target.files[0];
        var materialId = api.uuid();

        var reader = new FileReader();
        reader.readAsArrayBuffer(file);
        reader.onload = function (e) {
        	  $("body").append($("<div id='maskLayer' " +
                "style='position: absolute;width: 100%;height: 100%;top: 0;    text-align: center;line-height: 500px;" +
                " color: white; left: 0;background: rgba(0,0,0,0.6);z-index: 10000000000000000;'>正在上传背景图，请稍后...</div>"));
                
            var content = this.result;
            var fileserver = api.getServicePrefix("file");
            var uploadUrl = fileserver + "/uploadFile" + "?id=" + materialId + "&category=underlay&type=thumb";
            api.getServiceJSONResponsePromise({
                url: uploadUrl,
                type: "POST",
                cache: false,
                contentType: false,
                processData: false,
                data: content
            }).then(function (resp) {
                var res = (resp);
                if(res && res.error == 0){
                	//成功后需要延迟5秒后再进行加载
                	setTimeout(function(){
                		if (objectURL) {
						            window.URL.revokeObjectURL(objectURL);
						            objectURL = undefined;
						        }
						        objectURL = window.URL.createObjectURL(file);
	                	img.src = objectURL;
	                	img.onload = function (e) {
	                		$("#maskLayer").remove();
	                		
					            var target = e.target;
					            api.actionBegin("AddUnderImage", {
					                width: target.width,
					                height: target.height,
					                pid: materialId
					            },objectURL);
					            
					            layer.alert('为了精确地绘制户型图，请先绘制一面墙体并输入该墙的真实长度', {
					                title: '提示',
					                skin: 'layui-layer-default'
					            }, function (index) {
					                layer.close(index);
					                if (layerTipsIndex != undefined) {
					                    layer.close(layerTipsIndex);
					                }
					                layerTipsIndex = layer.tips('第二步：描图画户型', '.draw', {
					                    tips: [1, '#CC3525'],
					                    time: 6000
					                });
					            });
					          }
                  },5000);                	
                }else{
                	layer.msg('背景图上传失败，请重新上传');
                	$("#maskLayer").remove();
                }
            }, function(error){
            	layer.msg('背景图上传失败，请重新上传');
            	$("#maskLayer").remove();
            });
        };
        
        /*上传户型图，两次上传相同文件名的文件无效，
         解决方案：重建此元素，得到全新的file input
         */
        var importUnderlayClone = $("#importUnderlay").clone(true);
        $("#importUnderlay").remove();
        $(".catalogRoomRight").append(importUnderlayClone);
    }
})();

api.application_ready_event.add(function () {
    var currentSelectedCatalogId = undefined;
    var twoCatalogDivSelectStr = "#twoCatalogDivSelect";
    var threeCatalogDivSelectStr = "#threeCatalogDivSelect";

    var twoCatalogInputSelectStr = "#twoCatalogInputSelect";
    var threeCatalogInputSelectStr = "#threeCatalogInputSelect";

    var styleDivSelectStr = "#styleDivSelect";
    var styleInputSelectStr = "#styleInputSelect";

    var saturationDivSelectStr = "#saturationDivSelect";
    var saturationInputSelectStr = "#saturationInputSelect";

    var brandDivSelectStr = "#brandDivSelect";
    var brandInputSelectStr = "#brandInputSelect";

    var seriesDivSelectStr = "#seriesDivSelect";
    var seriesInputSelectStr = "#seriesInputSelect";

    api.actionBeginEvent.add(function (action, actionType, args) {
        if (actionType == "AddProduct") {
            if (!args || args.length < 2) return;
            if (!args[1][args[0]])return;
            if (args[1][args[0]].category == "tile") {
                if (api.floorplanIsLocked() == false) {
                    // need to lock first:
                    layer.confirm('添加瓷砖类商品需要首先锁定户型。<br>是否需要锁定户型？', {
                        btn: ['确定', '取消'], //按钮
                        shade: 0.3, //不显示遮罩
                        skin: 'layui-layer-default',
                        title: '提示'
                    }, function (index) { //layer.msg('确定', {icon: 1});
                        layer.close(index);
                        if (api.floorplanIsLocked()) return;
                        api.floorplanLock(true);
                    }, function () { //layer.msg('取消', {shift: 6});
                    });
                    //if (window.confirm("添加瓷砖类商品需要首先锁定户型。\n是否需要锁定户型？") === true) {
                    //    $("#toolLockFloorplan").trigger("click");
                    //} else return;
                }

                $("body").css({cursor: ""});
                $("body").attr("class", "");
                $("body").addClass("brushCursor");
            }
        } else if (actionType == "AddWall") {

        }
    });
    api.actionEndEvent.add(function (action, actionType, args) {
        $("body").removeClass("brushCursor");
        if (actionType == "AddWall") {
            var scale = api.floorplanGetUnderImageScale();
            if (scale == undefined || scale != 1) return;

            var wall = action.model,
                begin = wall.begin,
                end = wall.end;
            if (begin && end) {
                var wallLength = Math.sqrt((begin.x - end.x) * (begin.x - end.x) + (begin.y - end.y) * (begin.y - end.y));
            }
            underlayInputDimensionPrompt(function (wallActLength) {
                var factor = wallActLength / wallLength;
                api.floorplanSetUnderImageScale(factor);
                api.actionRun("scale", factor, [wall]);

                //输入比例后，删除第一次画的墙--by gaining 2017.4.24
                api.actionRun("ESC", factor, [wall]);
                api.actionBegin("DeleteWall", wall);

            });
        }
    });
    /*api.catalogGetCatalogTreePromise 在 方法在misc.footer.js  里面 utilInitApi() 第二次包装定义,
    *执行在这行 【 catalogGetCatalogTreePromise: utilCatalogGetCatalogTreePromise.bind(void 0, application.catalogMgr) 】;
    *ajax获取catalog目录树的方法 utilCatalogGetCatalogTreePromise 在app.comp.js,
    * --add by oxl*/
    api.catalogGetCatalogTreePromise()
        .then(function (root) {
            /*箭头事件*/
            $("#catalogDrawHouseTypeId .arrow_down_right_img")
                .on("mouseover", function (e) {
                    var downObj = {};
                    if ($(this).parent().hasClass("draw-wall")) {
                        downObj = $(".catalog .catalogHouseDownRightMenu .draw_wall");
                    } else if ($(this).parent().hasClass("draw-inner-area")) {
                        downObj = $(".catalog .catalogHouseDownRightMenu .draw_inner_area");
                    } else if ($(this).parent().hasClass("draw-outer-area")) {
                        downObj = $(".catalog .catalogHouseDownRightMenu .draw_outer_area");
                    }
                    downObj.show();
                    var offset = $(this).offset();
                    downObj.offset({
                        left: offset.left,
                        top: offset.top
                    });
                    downObj.on("mouseover", function (e) {
                        $(this).show();
                    }).on("mouseout", function (e) {
                        $(this).hide();
                    });
                })
                .on("mouseout", function (e) {
                    $(".catalog .catalogHouseDownRightMenu .arrow_down_right_content").hide();
                });

            /*菜单点击隐藏*/
            $(".catalog .catalogHouseDownRightMenu .arrow_down_right_content").on("click", function (e) {
                $(this).hide();
            });

            /*画墙*/
            $(".catalog .drawFreeWall").on("click", function (e) {
                api.actionBegin("AddWall", {
                    continuous: !isMobileDevice()
                });
            });
            $(".catalog .drawRectWall").on("click", function (e) {
                api.actionBegin("AddRectRoom", {
                    continuous: !isMobileDevice()
                });
            });
            /*画区域*/
            $(".catalog .drawInnerFreeArea").on("click", function (e) {
                api.actionBegin("AddFreeArea", "inner");
            });
            $(".catalog .drawInnerRectArea").on("click", function (e) {
                api.actionBegin("AddRectArea", "inner");
            });
            $(".catalog .drawInnerCircleArea").on("click", function (e) {
                api.actionBegin("AddRoundArea", "inner");
            });
            $(".catalog .drawOuterFreeArea").on("click", function (e) {
                api.actionBegin("AddFreeArea", "outer");
            });
            $(".catalog .drawOuterRectArea").on("click", function (e) {
                api.actionBegin("AddRectArea", "outer");
            });
            $(".catalog .drawOuterCircleArea").on("click", function (e) {
                api.actionBegin("AddRoundArea", "outer");
            });

            /*var underlay_flag = false;
             var underlay_stop = undefined ;*/
            $("#importUnderlay").on("change", importUnderlayChanged);
            $("#catalogDrawHouseTypeId .underlay")
                .on("click", function (e) {
                    $("#importUnderlay").trigger("click");
                })
                /* .on("mousedown", function (e) {
                 underlay_stop = setTimeout(function() {
                 underlay_flag = true;
                 console.log("1111111111111111111111");
                 }, 1000);
                 })
                 .on("mouseup", function (e) {
                 if (! underlay_flag ) {
                 $("#importUnderlay").trigger("click");
                 clearTimeout( underlay_stop );
                 }
                 underlay_flag = false ;
                 underlay_stop = undefined ;
                 })*/
            ;
            $("#catalogDrawHouseTypeId .drawall")
                .on("click", function (e) {
                    if (api.floorplanIsLocked() == true) {
                        // need to lock first:
                        layer.confirm('添加新墙体需要首先解锁户型。<br>是否需要解锁户型？', {
                            btn: ['确定', '取消'], //按钮
                            shade: 0.3, //不显示遮罩
                            skin: 'layui-layer-default',
                            title: '提示'
                        }, function (index) { //layer.msg('确定', {icon: 1});
                            layer.close(index);
                            api.floorplanLock(false);
                            api.actionBegin("AddWall");
                        }, function () { //layer.msg('取消', {shift: 6});
                        });
                    } else {
                        api.actionBegin("AddWall");
                    }
                });
            $("#catalogDrawHouseTypeId .draw-inner-area")
                .on("click", function (e) {
                    //api.actionBegin("AddFreeArea", "inner");
                    if (api.floorplanIsLocked() == true) {
                        // need to lock first:
                        layer.confirm('绘制室内区域需要首先解锁户型。<br>是否需要解锁户型？', {
                            btn: ['确定', '取消'], //按钮
                            shade: 0.3, //不显示遮罩
                            skin: 'layui-layer-default',
                            title: '提示'
                        }, function (index) { //layer.msg('确定', {icon: 1});
                            layer.close(index);
                            api.floorplanLock(false);
                            api.actionBegin("AddRectArea", "inner");
                        }, function () { //layer.msg('取消', {shift: 6});
                        });
                    } else {
                        api.actionBegin("AddRectArea", "inner");
                    }
                });

            $("#catalogDrawHouseTypeId .draw-outer-area")
                .on("click", function (e) {
                    //api.actionBegin("AddFreeArea", "outer");
                    if (api.floorplanIsLocked() == true) {
                        // need to lock first:
                        layer.confirm('绘制室外区域需要首先解锁户型。<br>是否需要解锁户型？', {
                            btn: ['确定', '取消'], //按钮
                            shade: 0.3, //不显示遮罩
                            skin: 'layui-layer-default',
                            title: '提示'
                        }, function (index) { //layer.msg('确定', {icon: 1});
                            layer.close(index);
                            api.floorplanLock(false);
                            api.actionBegin("AddRectArea", "outer");
                        }, function () { //layer.msg('取消', {shift: 6});
                        });
                    } else {
                        api.actionBegin("AddRectArea", "outer");
                    }
                });

            /*画房间*/
            $("#catalogDrawHouseTypeId .draw-room").on(click, function (e) {
                if (api.floorplanIsLocked() == true) {
                    layer.alert("添加房间请先解锁户型。", {
                        closeBtn: 0,
                        skin: 'layui-layer-default'
                    }, function (idx) {
                        $('#houseNavigationId .close').trigger(click);
                        layer.close(idx);
                    });
                } else api.actionBegin("AddRectRoom", {
                    continuous: !isMobileDevice()
                });
            });

            /*画墙*/
            $("#catalogDrawHouseTypeId .draw-wall").on(click, function (e) {
                if (api.floorplanIsLocked() == true) {
                    layer.alert("添加墙请先解锁户型。", {
                        closeBtn: 0, title: '信息', skin: 'layui-layer-default'
                    }, function (idx) {
                        $('#houseNavigationId .close').trigger(click);
                        layer.close(idx);
                    });
                } else api.actionBegin("AddWall", {
                    continuous: !isMobileDevice()
                });
            });

            /*门*/
            $("#catalogDrawHouseTypeId .draw-door").on(click, function (e) {
                var pid = "testdoor";
                api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
                    api.actionBegin("AddProduct", pid, rv);
                });
            });

            /*双开门*/
            $("#catalogDrawHouseTypeId .draw-double-door").on(click, function (e) {
                var pid = "p4aa00d623bc148a582540483ed3e5a79";
                api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
                    api.actionBegin("AddProduct", pid, rv);
                });
            });

            /*移门*/
            $("#catalogDrawHouseTypeId .draw-sliding-door").on(click, function (e) {
                var pid = "p10fa159cb143480496e08f2d6bfc27f7";
                api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
                    api.actionBegin("AddProduct", pid, rv);
                });
            });

            /*窗*/
            $("#catalogDrawHouseTypeId .draw-window").on(click, function (e) {
                var pid = "p7b946e57fc6046a09c97115197b71889";
                api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
                    api.actionBegin("AddProduct", pid, rv);
                });
            });

            /*落地窗*/
            $("#catalogDrawHouseTypeId .draw-ground-window").on(click, function (e) {
                var pid = "pb51d1a4516204c078d9c0334836cc5e4";
                api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
                    api.actionBegin("AddProduct", pid, rv);
                });
            });

            /*飘窗*/
            $("#catalogDrawHouseTypeId .draw-bay-window").on(click, function (e) {
                var pid = "p3aa31c381d564778adc27195a975948e";
                api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
                    api.actionBegin("AddProduct", pid, rv);
                });
            });

            $("#catalogDrawHouseTypeId .draw-dw").on(click, function (e) {
                removePrevPrdObj();
            });
            $("#catalogDrawHouseTypeId .draw-structure").on(click,function (e) {
                removePrevPrdObj();
            });


            $("#catalogDrawHouseTypeId .click-add-text").on(click, addTextAnnotation);

            $("#catalogDrawHouseTypeId .click-add-pillar").on(click, addPillar);
            $("#catalogDrawHouseTypeId .click-add-basement").on(click, addBasement);
            $("#catalogDrawHouseTypeId .click-add-beam").on(click, addBeam);

            $("#catalogDrawHouseTypeId .click-add-camera").on(click, addCamera);


            /*画户型，不是从数据库读取
            *
            * add by oxl
            * */
            $("<li id='drawHouseLeftId'><a>画户型</a></li>").appendTo(".roomLi")
                .on("mouseleave", function (e) {
                    $(this).removeClass("hover");
                }).on("click", function (e) {

                    if($(this).attr('class')&&(($(this).attr('class')).indexOf('selected')>-1))
                        return ;
                    $("#search,.catalog .catalogProductPagination").hide();
                    $("#productsList,#subProductsList").hide();
                    $('#productContent>.items').remove();
                    $("#catalogDrawHouseTypeId").clone(true).removeAttr("id").show().appendTo($("#productContent"));
                    resizePage();

                }).on("mouseover", function (e) {
                    $(this).addClass("hover");
                    $(".content_catalog").empty();
                    $(".catalogRoomContent").hide();
                });

            /*铺贴模板，不是从数据库读取
             * add by zk
             * */
            $("<li id='pavingModelLeftId01'><a>铺贴模板</a></li>").appendTo(".roomLi")
                .on("mouseleave", function (e) {
                    $(this).removeClass("hover");
                }).on("click", function (e) {
                    $("#search").hide();

                    $(".pavingModelContent .singleCeramicList").empty();
                    renderPavingModel(singleCeramicList,0,singleCeramicListDiv);
                    pavingModelPagination(singleCeramicList,singleCeramicListDiv);

                    /*铺贴模板分页显示隐藏*/
                    $("#productsList,#subProductsList").hide();
                    $('#productContent>.items').remove();
                    //$(".singleCeramicList").show().siblings().hide();
                    if($(".pavingModelList").css("display") == "block"){
                        $(".pavingModelItems .paving").addClass("current").siblings().removeClass("current");
                        renderPavingModel(pavingModelList,0,pavingModelListDiv);
                        pavingModelPagination(pavingModelList,pavingModelListDiv);
                    }else if($(".singleCeramicList").css("display") == "block"){
                        $(".pavingModelItems .single_ceramic").addClass("current").siblings().removeClass("current");
                        renderPavingModel(singleCeramicList,0,singleCeramicListDiv);
                        pavingModelPagination(singleCeramicList,singleCeramicListDiv);
                    }else if($(".shuangzhuanModelList").css("display") == "block"){
                        $(".pavingModelItems .double_ceramic").addClass("current").siblings().removeClass("current");
                        renderPavingModel(shuangzhuanModelList,0,shuangzhuanModelListDiv);
                        pavingModelPagination(shuangzhuanModelList,shuangzhuanModelListDiv);
                    }else if($(".duozhuanModelList").css("display") == "block"){
                        $(".pavingModelItems .more_ceramic").addClass("current").siblings().removeClass("current");
                        renderPavingModel(duozhuanModelList,0,duozhuanModelListDiv);
                        pavingModelPagination(duozhuanModelList,duozhuanModelListDiv);
                    }else{
                        $(".pavingModelItems .elevation").addClass("current").siblings().removeClass("current");
                        renderPavingModel(elevationModelList,0,elevationModelListDiv);
                        pavingModelPagination(elevationModelList,elevationModelListDiv);
                    }
                    $("#catalogPavingModelLeftId").clone(true).removeAttr("id").show().appendTo($("#productContent"));
                    resizePage();
                }).on("mouseover", function (e) {
                    $(this).addClass("hover");
                    $(".content_catalog").empty();
                    $(".catalogRoomContent").hide();
                });

            if (!root || !root.children) {
                lazyLoad.init();
                api.viewFit("2d");
                $.unblockUI({
                    onUnblock: function () {
                        resizePage();
                    }
                });
                return;
            }

            /*显示或隐藏品牌系列查询项*/
            function showOrHideBrandSeriesSearchItem(level3) {
                var extra = level3.extra;
                extra = JSON.parse(extra);
                if (extra && extra.brandquery != undefined) {
                    if (extra.brandquery) {
                        $("#search .brandseriesline").show();
                    } else {
                        $("#search .brandseriesline").hide();
                    }
                } else {
                    $("#search .brandseriesline").hide();
                }
            }

            showOrHideBrandSeriesSearchItemG = showOrHideBrandSeriesSearchItem;

            /*渲染左则catalog目录树数据
            *
            * add by --oxl*/
            root.children.forEach(function (level1) {
                var cataloghide = "";
                if (level1.label === '其他')cataloghide = "display:none;"
                $("<li style='" + cataloghide + "'><a>" + level1.label + "</a></li>").attr("id", level1.cid)
                    .appendTo(".roomLi")
                    .on("click", function (e) {
                        //if($(this).attr('class')&&(($(this).attr('class')).indexOf('selected')>-1))return ;
                        $.divselectInit("风格", "all", styleDivSelectStr, styleInputSelectStr);
                        $.divselectInit("品牌", "all", brandDivSelectStr, brandInputSelectStr);
                        $.divselectInit("系列", "all", seriesDivSelectStr, seriesInputSelectStr);
                        /*不同目录加载不同的色调*/
                        if (level1.label == '产品库') {
                            initProductSaturation('tile');
                        } else {
                            initProductSaturation('furniture');
                        }

                        /*硬编码逻辑：一级菜单硬装点击不显示风格和色系
                        1、不需要风格和色系查询
                        2、品牌只显示【欧神诺】
                        * */
                        //if (level1.label == '硬装'||level1.label == '铺贴模板') {
                        //    $("#search .styleline").hide();
                        //     $.divselectclick(brandDivSelectStr,"b6b27795e8bfa");
                        //} else {
                        //    $("#search .styleline").show();
                        // }

                        /*当前空间下取第一个的产品数据，比如【客厅-沙发-单人沙发】*/
                        $("#search,.catalog .catalogProductPagination").show();
                        $('#productsList').empty();
                        /*$("<ul>").attr({
                            id: "productsList"
                        }).appendTo("#productContent");*/
                        level1.children.forEach(function (level2, index2) {
                            if (index2 == 0) {
                                level2.children.forEach(function (level3, index3) {
                                    if (index3 == 0) {
                                        showOrHideBrandSeriesSearchItem(level3);
                                          /*硬编码逻辑：一级菜单硬装点击不显示风格和色系
                                            1、不需要风格和色系查询
                                            2、品牌只显示【欧神诺】
                                            * */
                                           if (level2.label == '拼花模板' || level2.label == '背景墙') {
                                               $("#search .styleline").hide();
                                               $.divselectInit("欧神诺", "b6b27795e8bfa", brandDivSelectStr, brandInputSelectStr);
                                           } else {
                                               $("#search .styleline").show();
                                               $.divselectInit("品牌", "all", brandDivSelectStr, brandInputSelectStr);
                                            }
                                        $(".catalogRoomContent").hide();
                                        loadCatalogProducts(level3.cid, 0, 20);
                                    }
                                });
                            }
                        });
                        resizePage();

                        /*点击一级目录 初始化二、三级目录 start*/
                        var catalogLevel1 = level1;
                        var catalogLevel2 = undefined;
                        var catalogLevel3 = undefined;
                        level1.children.forEach(function (level2, index2) {
                            if (index2 == 0) {
                                catalogLevel2 = level2;
                                level2.children.forEach(function (level3, index3) {
                                    if (index3 == 0) {
                                        catalogLevel3 = level3;
                                    }
                                });
                            }
                        });
                        initSelectCatalog(catalogLevel1, catalogLevel2, catalogLevel3);
                        /*点击一级目录 初始化二、三级目录 end*/


                    }).on("mouseover", function (e, idx) {

                        var $menu = $(this);
                        $menu.addClass("hover");
                        var $subMenu = $(".catalogRoomContent");

                        $(".content_catalog").empty(); // clear all.

                        level1.children.forEach(function (level2) {
                            var level2Root = $("<div>")/*.attr("id", level2.cid)*/.appendTo(".content_catalog");
                            var level2Title = $("<div>").addClass("title").text(level2.label).appendTo(level2Root);
                            var level2ul = $("<ul>").appendTo(level2Root);
                            level2.children.forEach(function (level3) {
                                var level2li = $("<li>")/*.attr("id", level3.cid)*/.text(level3.label).appendTo(level2ul)
                                    .on("mouseover", function () {
                                        $(this).addClass("hover");
                                    })
                                    .on("mouseleave", function () {
                                        $(this).removeClass("hover");
                                    })
                                    .on("click", function (e) {
                                        showOrHideBrandSeriesSearchItem(level3);

                                        /*硬编码逻辑：一级菜单硬装点击不显示风格和色系
                                            1、不需要风格和色系查询
                                            2、品牌只显示【欧神诺】
                                            * */
                                           if (level2.label == '拼花模板' || level2.label == '背景墙') {
                                               $("#search .styleline").hide();
                                               $.divselectInit("欧神诺", "b6b27795e8bfa", brandDivSelectStr, brandInputSelectStr);
                                           } else {
                                               $("#search .styleline").show();
                                               $.divselectInit("品牌", "all", brandDivSelectStr, brandInputSelectStr);
                                            }

                                        $(".catalogRoomContent").hide();
                                        $('#productsList').empty();
                                        /*$("<ul>").attr({
                                            id: "productsList"
                                        }).appendTo("#productContent");*/
                                        $("#search,.catalog .catalogProductPagination").show();
                                        loadCatalogProducts(level3.cid, 0, 20);

                                        /*一级目录高亮切换*/
                                        $(".catalogRoomLeft li[id='" + level1.cid + "']").addClass("selected");
                                        $(".catalogRoomLeft li[id='" + level1.cid + "']").siblings("li").removeClass("selected");

                                        initSelectCatalog(level1, level2, level3);
                                    });
                            });
                        });
                        if($subMenu.find(".content_catalog").height()==0) {
                            setCatalogSubMenuPos($menu, $subMenu);
                        }
                        setCatalogSubMenuPos($menu, $subMenu);
                    }).on("mouseleave", function (e) {
                        $(this).removeClass("hover");
                    });
            });

            /*目录数据初始化完成后执行 内容 开始*/
            $('#drawHouseLeftId').trigger("click");
            //$('#pavingModelLeftId01').trigger("click");
            //$('.pavingModelLeftId').trigger("click");
            /*默认显示画户型*/
            /* layerTipsIndex = layer.tips('第一步：请上传户型图', '.underlay', {
             tips: [1, '#666666'],
             time: 6000
             });*/
            api.viewFit("2d");
            /*2d画布鼠标点有偏移，调用此方法即正常*/
            $.unblockUI({
                onUnblock: function () {
                    resizePage();
                    api.viewFit("2d");
                }
            });
            /*关闭遮罩*/

            catalog_init_complete_event.dispatch("ok");

            /*目录数据初始化完成后执行 内容 结束*/

            /*滚动滚动条加载图片*/
            $('#productContent').scroll(function () {
                lazyLoad.init();
            });

            $(".catalogRoomContent").on("mouseleave", function (e) {
                $(this).hide();
            });


            $(".catalog").tooltip({
                position:{
                    my:"center bottom+40",
                    at:"center bottom"
                },
                content:function(){
                    var canChange=$(this).attr('category_pid')=="furniture_replacement"?"(可替换材质)":"";
                    if($(this).attr("class")=="viewSubComponents"){
                        return "<div style='background:#666666;color:#fff;font-size: 12px;'>"+$(this).attr('title')+canChange+"<div class='arrow top center'></div></div>";
                    }else{
                        return ($(this).attr('title')+canChange);
                    }
                },
                open:function(event,ui){
                    if(ui.tooltip[0].childNodes[0].innerText=="查看套件"){
                        $('#'+ui.tooltip[0].id).css('background','#666')
                    }
                }
            });

            /*初始化风格，色系下拉框*/
            initProductStyle();
            initProductSaturation('tile');
            initProductBrand();
        });


    /*初始化下拉框目录信息*/
    function initSelectCatalog(catalogLevel1, catalogLevel2, catalogLevel3) {
        /*二、三级当前目录值*/
        var twoCatalogObj = $(twoCatalogDivSelectStr + ' ul').empty();
        var threeCatalogObj = $(threeCatalogDivSelectStr + ' ul').empty();
        catalogLevel1.children.forEach(function (level2, index2) {
            $("<li>").append($("<a>").attr({
                "href": "javascript:;",
                "selectid": level2.cid
            }).text(level2.label)).appendTo(twoCatalogObj);
        });

        catalogLevel2.children.forEach(function (level3, index3) {
            $("<li>").append($("<a>").attr({
                "href": "javascript:;",
                "selectid": level3.cid
            }).text(level3.label)).appendTo(threeCatalogObj);
        });
        $.divselectInit(catalogLevel2.label, catalogLevel2.cid, twoCatalogDivSelectStr, twoCatalogInputSelectStr);
        $.divselectInit(catalogLevel3.label, catalogLevel3.cid, threeCatalogDivSelectStr, threeCatalogInputSelectStr);


        /*二级目录联动三级目录，默认显示三级目录中的第一个目录值，并加载出该目录下的产品数据*/
        $.divselect("二级目录", twoCatalogDivSelectStr, twoCatalogInputSelectStr, function (value) {
            threeCatalogObj.empty();

            catalogLevel1.children.forEach(function (level2, index2) {
                if (level2.cid == value) {
                    level2.children.forEach(function (level3, index3) {

                           showOrHideBrandSeriesSearchItemG(level3);

                        /*硬编码逻辑：一级菜单硬装点击不显示风格和色系
                            1、不需要风格和色系查询
                            2、品牌只显示【欧神诺】
                            * */
                            if (level2.label == '拼花模板' || level2.label == '背景墙') {
                                $("#search .styleline").hide();
                                $.divselectInit("欧神诺", "b6b27795e8bfa", brandDivSelectStr, brandInputSelectStr);
                            } else {
                                $("#search .styleline").show();
                                $.divselectInit("品牌", "all", brandDivSelectStr, brandInputSelectStr);
                            }

                        $("<li>").append($("<a>").attr({
                            "href": "javascript:;",
                            "selectid": level3.cid
                        }).text(level3.label)).appendTo(threeCatalogObj);
                        if (index3 == 0) {
                            $.divselectInit(level3.label, level3.cid, threeCatalogDivSelectStr, threeCatalogInputSelectStr);
                            loadCatalogProducts(level3.cid, 0, 20);
                        }
                    });
                }
            });

            $.divselect("三级目录", threeCatalogDivSelectStr, threeCatalogInputSelectStr, function (value) {
                loadCatalogProducts(value, 0, 20);
            });
        });

        /*三级目录加载该目录下数据*/
        $.divselect("三级目录", threeCatalogDivSelectStr, threeCatalogInputSelectStr, function (value) {
            loadCatalogProducts(value, 0, 20);
        });
    }

    /*初始化风格区域*/
    function initProductStyle() {
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductStyleData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {}
        }).then(function (res) {
            //console.log(res)
            var styleObj = $('#styleDivSelect ul').empty();
            $("<li>").append($("<a>").attr({"href": "javascript:;", "selectid": "all"}).text("全部")).appendTo(styleObj);
            res.forEach(function (obj) {
                $("<li>").append($("<a>").attr({
                    "href": "javascript:;",
                    "selectid": obj.sid
                }).text(obj.title)).appendTo(styleObj);
            });
            $.divselect("风格", styleDivSelectStr, styleInputSelectStr, function (value) {
                loadCatalogProducts(currentSelectedCatalogId, 0, 20);
            });
        }).catch(function (e) {
            layer.alert('send getProductStyleData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }

    /*初始化色调区域-色系
    * edit by -oxl
    * */
    function initProductSaturation(typeid) {
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductSaturationData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {}
        }).then(function (res) {
            var saturationObj = $('#saturationDivSelect ul').empty();
            $("<li>").append($("<a>").attr({
                "href": "javascript:;",
                "selectid": "all"
            }).text("全部")).appendTo(saturationObj);
            res.forEach(function (obj) {
                if (typeid == obj.typeid) {
                    $("<li>").append($("<a>").attr({
                        "href": "javascript:;",
                        "selectid": obj.satid
                    }).text(obj.title)).appendTo(saturationObj);
                }
            });
            $.divselect("色系", saturationDivSelectStr, saturationInputSelectStr, function (value) {
                loadCatalogProducts(currentSelectedCatalogId, 0, 20);
            });
            $.divselectInit("色系", "all", saturationDivSelectStr, saturationInputSelectStr);
        }).catch(function (e) {
            layer.alert('send getProductSaturationData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }


    /*初始化品牌区域*/
    function initProductBrand() {
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductBrandData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {}
        }).then(function (res) {
            var brandObj = $('#brandDivSelect ul').empty();
            $("<li>").append($("<a>").attr({"href": "javascript:;", "selectid": "all"}).text("全部")).appendTo(brandObj);
            res.forEach(function (obj) {
                $("<li>").append($("<a>").attr({
                    "href": "javascript:;",
                    "selectid": obj.bid
                }).text(obj.title)).appendTo(brandObj);
            });
            $.divselect("品牌", brandDivSelectStr, brandInputSelectStr, function (value) {
                initProductBrandSeries(value);
                loadCatalogProducts(currentSelectedCatalogId, 0, 20);
            });

        }).catch(function (e) {
            layer.alert('send getProductBrandData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }


    /*初始化品牌系列区域
     * 由品牌改变触发
     * */
    function initProductBrandSeries(productBrandId) {
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductSeriesData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {"bid": productBrandId}
        }).then(function (res) {
            var seriesObj = $('#seriesDivSelect ul').empty();
            $("<li>").append($("<a>").attr({"href": "javascript:;", "selectid": "all"}).text("全部")).appendTo(seriesObj);
            res.forEach(function (obj) {
                $("<li>").append($("<a>").attr({
                    "href": "javascript:;",
                    "selectid": obj.sid
                }).text(obj.title)).appendTo(seriesObj);
            });
            $.divselect("系列", seriesDivSelectStr, seriesInputSelectStr, function (value) {
                console.log(value);
                loadCatalogProducts(currentSelectedCatalogId, 0, 20);
            });
        }).catch(function (e) {
            layer.alert('send getProductBrandData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }




    /**
     * 加载目录下的产品
     * @param cid
     * @param viewindex
     * @param viewsize
     */

    function loadCatalogProducts(cid, viewindex, viewsize) {
        currentSelectedCatalogId = cid;
        var styleValue = $(styleInputSelectStr).val();
        var saturationValue = $(saturationInputSelectStr).val();
        var brandValue = $(brandInputSelectStr).val();
        var seriesValue = $(seriesInputSelectStr).val();

        $("#productsList").empty();
        var data = {
            "cid": cid,
            "viewindex": viewindex,
            "viewsize": viewsize,
            "saturation": saturationValue,
            "style": styleValue,
            "productbrand": brandValue,
            "productseries": seriesValue
        };

        api.getServiceJSONResponsePromise({
            type: 'get',
            url: api.getServicePrefix("catalog") + "/getProductsByCatalogId",
            cache: false,
            data: data
        }).then(function (products) {
            renderCatalogProducts(products);
            /*初始化分页属性*/
            if (products && products.length > 0) {
                $(".catalogProductPagination").show();
                resizePage();
                $(".catalogProductPagination .pagination").pagination(products[0].count, {
                    callback: function (page_index, jq) {
                        loadCatalogProducts(cid, page_index, viewsize);
                    },
                    prev_text: '<',
                    next_text: '>',
                    items_per_page: 20,
                    num_display_entries: 4, //连续分页主体部分显示的分页条目数
                    current_page: viewindex,
                    num_edge_entries: 2 //两侧显示的首尾分页的条目数
                });
            } else {
                $(".catalogProductPagination").hide();
            }
        }).catch(function (e) {
            console.log(e);
            layer.alert('send getProductsByCatalogId request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }


});

/*catalog-头部选项卡*/
var $etabs = jQuery('#tab-container').find('.etabs');
$etabs.on("click", 'li', function (e) {
    resizePage();
    $etabs.find('.selected').removeClass('selected');
    jQuery(e.currentTarget).addClass('selected');
    $(".catalogRoomContent").hide();
});
/*catalog-左边栏选项卡*/
var $roomLi = jQuery('.catalogRoomLeft .roomLi');
var liId;
$roomLi.on('click', 'li', function (e) {
    liId = $(this).attr("id");
    $roomLi.find('.selected').removeClass('selected');
    jQuery(e.currentTarget).addClass('selected');
    $(".catalogProductPagination .pagination.pagination_layout").show();
    $(".catalogProductPagination .subPagination.pagination_layout").hide();
});


//# sourceURL=ui\catalog\catalog.js