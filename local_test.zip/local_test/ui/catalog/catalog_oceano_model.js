/*模型库+我的素材 模版在=ui\layout\layout.xml
 * --add by oxl*/
/*我的素材.catalogMaterial的选项卡内容区模版在=ui\catalog\catalog_oceano.xml
 * --add by oxl*/
/*点击产品 add by oxl*/
function customModelProductClick(e) {
    var pid = $(this).attr("pid");
    if (PARQUET_EDIT_MODE === true) {
        ParquetEditor_CatalogImageClick(pid);
        return;
    }
    api.catalogGetCustomModelProductsMetaPromise([pid, pid, pid]).then(function (rv) {
        api.actionBegin("AddProduct", pid, rv);
    });
}
var ModelUploadinterval,current=0,setTime,uploadTime=0,dropUpload;
api.application_ready_event.add(function () {
    /*我的素材-左边栏"默认"标签tab*/
    /*头部tab点击定义在catalog.js*/
    /*************************** 自定义模型打开对话框后所有逻辑操作 **********************************/
    /*定义上传模型对话框*/
    $("#uploadModel_oceano,#uploadModel_oceano2,#uploadModel_oceano3").dialog({
        width:550,
        autoOpen: false,
        resizable: true,
        modal: false,
        close:function () {
            setIncrementNormal()
        }
    })
    $("#uploadModel_oceano4").dialog({
        width: 900,
        height: 630,
        autoOpen: false,
        resizable: true,
        modal: false,
        open:function(tag){
            $('div[aria-describedby="uploadModel_oceano4"]').css({zIndex:999999})
        }
    })
    $("#uploadModel_oceano5,#uploadModel_oceano6").dialog({
        width: 840,
        autoOpen: false,
        resizable: true,
        modal: false
    })
    ///编辑自定义模型对话框
    $("#edit_Model_oceano3").dialog({
        width: 840,
        resizable:true,
        draggable:false,
        autoOpen: false,
        open:function(){
            $('[aria-describedby="edit_Model_oceano3"] .ui-dialog-titlebar').hide();
        }
    })
    var uploadModelDialogPrompt = function (onSuccessCB) {
        renderDialog_onSuccessCB = onSuccessCB;
        $("#uploadModel_oceano").dialog("open");
        $("div[aria-describedby='uploadModel_oceano']").css("z-index", 1001);
        $(".renderPanel_oceano").hide();
        $("#renderPanel_oceano").dialog("close");
    };
    /*上传模型对话框相关操作，步骤1（文件上传）*/
    $(".modelUploadBtn").on(click,uploadModelDialogPrompt)
    $("#uploadModel_oceano .model")
        .on("click", function (e) {
            setIncrementNormal()
            $("#ModelUpload").trigger("click");
        })

    /*选择模型文件事件*/
    $("#ModelUpload").on("change",uploadCustomModelChanged)

    /*拖动文件上传*/
    $('#uploadModel_oceano .model')[0].addEventListener('drop',function (e) {
        e.preventDefault();
        dropUpload=e.dataTransfer.files;
        $("#ModelUpload").trigger("change");
        return false
    })
    //取消上传模型
    $('#uploadModel_oceano2 .model .progress .progress-close').click(function () {
            setIncrementNormal();
        $('#uploadModel_oceano').dialog('open');
        }
    )

});
/*
 FileType：图片后缀名，scaleRatio：压缩比例
 *优化上传流程-2017-08-22-oxl
 * */
// var imgPNGResult,modelObjResult,modelZipResult,modelTopResult,modelThumbResult,
//     uploadCustomModelChanged = (function () {
//         var objectURL = undefined;
//         var img = new Image();
//         var maxSize=4096;
//         var compRatio=0.8//压缩比
//         var bigImgSize;
//         return function (e) {
//             var files;
//             if(dropUpload){
//                 files = dropUpload[0]
//             }else{
//                 files = e.target.files[0];
//             }
//             if(files.size>52428800){
//                 layer.msg('上传文件大小不能超过50m');
//                 return;
//             }
//             window.un=new UnZipArchive(files);
//             var file = [],pngFlie,objFlie,zipFile,thumbFile,topFile;
//             uploadModelStep();
//             un.getData(function () {
//                 var arr=un.getEntries();
//                 for (var i = 0; i < arr.length; i++) {
//                     un.getFile(arr[i], function (data) {
//                         file.push(data)
//                         if (file.length == arr.length) {
//                             file.forEach(function (t) {
//                                 if (t.name == "product.png") pngFlie = t;
//                                 if (t.name.substr(t.name.lastIndexOf(".") + 1) == "obj") objFlie = t;
//                                 if (t.name.substr(t.name.lastIndexOf(".") + 1) == "zip") zipFile = t;
//                                 if (t.name.substr(t.name.lastIndexOf(".") + 1) == "jpg") thumbFile = t;
//                                 if (t.name == "top.png") topFile = t;
//                             })
//                             if (!pngFlie || !objFlie || !zipFile || !topFile || !thumbFile) {
//                                 var message=!pngFlie?'压缩包缺少product.png图片':!objFlie?'压缩包缺少obj文件':!zipFile?'压缩包缺少product.max.zip文件':!thumbFile?'压缩包缺少thumb.jpg图片':'压缩包缺少top.png图片';
//                                 $material.tips(message)
//                                 $("#uploadModel_oceano").dialog("open");
//                                 $("#uploadModel_oceano2").dialog("close");
//                                 return;
//                             }
//                            /* flieToMd5(zipFile)
//                             return;*/
//                             var reader = new FileReader();
//                             reader.readAsArrayBuffer(pngFlie);
//                             reader.onload = function (e) {
//                                 imgPNGResult = this.result;
//                                 reader.readAsArrayBuffer(topFile);
//                                 reader.onload = function () {
//                                     modelTopResult = this.result;
//                                     reader.readAsArrayBuffer(thumbFile);
//                                     reader.onload = function () {
//                                         modelThumbResult = this.result;
//                                         modelObjResult = objFlie;
//                                         modelZipResult = zipFile;
//                                         if (modelObjResult && imgPNGResult && modelZipResult && modelTopResult && modelThumbResult) {
//                                             modelUploadImgAction(null,modelObjResult, imgPNGResult,modelZipResult,modelTopResult,modelThumbResult)
//                                         }
//                                     }
//                                 }
//                             };
//                         }
//                     })
//
//                 }
//             })
//         }
//     })();
var imgPNGResult,modelObjResult,modelZipResult,modelTopResult,modelThumbResult,
    uploadCustomModelChanged = (function () {
        var objectURL = undefined;
        var img = new Image();
        var maxSize=4096;
        var compRatio=0.8//压缩比
        var bigImgSize;
        return function (e) {
            var files;
            if(dropUpload){
                files = dropUpload[0]
            }else{
                files = e.target.files[0];
            }
            if(files.size>52428800){
                layer.msg('上传文件大小不能超过50m');
                return;
            }
            window.un=new UnZipArchive(files);
            var file = [],zipFile;
            uploadModelStep();
            un.getData(function () {
                var arr=un.getEntries();
                for (var i = 0; i < arr.length; i++) {
                    un.getFile(arr[i], function (data) {
                        file.push(data)
                        if (file.length == arr.length) {
                            file.forEach(function (t) {
                                if (t.name.substr(t.name.lastIndexOf(".") + 1) == "max") zipFile = t;
                            })
                            if (!zipFile) {
                                var message='压缩包缺少max文件';
                                $material.tips(message)
                                $("#uploadModel_oceano").dialog("open");
                                $("#uploadModel_oceano2").dialog("close");
                                return;
                            }
                            var reader = new FileReader();
                            reader.readAsArrayBuffer(files);
                            reader.onload = function (e) {
                                modelZipResult=this.result;
                                var uuid=api.uuid();
                                uploadProductMaxZip(uuid,modelZipResult);
                            }
                        }
                    })

                }
            })
        }
    })();

function customPromise(fun){
    return new Promise(function (resolve, reject) {
        fun(resolve,reject);
    });
}
/* 计算 file文件的Md5值*/
function flieToMd5(file) {
    var fileReader = new FileReader(), box = document.getElementById('box');
    //文件分割方法（注意兼容性）
    var blobSlice = File.prototype.mozSlice || File.prototype.webkitSlice || File.prototype.slice,
        file =file,
        //文件每块分割2M，计算分割详情
        chunkSize = 2097152,
        chunks = Math.ceil(file.size / chunkSize),
        currentChunk = 0,

        //创建md5对象（基于SparkMD5）
        spark = new SparkMD5();

    //每块文件读取完毕之后的处理
    fileReader.onload = function(e) {
        console.log("读取文件", currentChunk + 1, "/", chunks);
        //每块交由sparkMD5进行计算
        spark.appendBinary(e.target.result);
        currentChunk++;

        //如果文件处理完成计算MD5，如果还有分片继续处理
        if (currentChunk < chunks) {
            loadNext();
        } else {
            console.log("finished loading");
            console.info("计算的Hash", spark.end());
            return
        }
    };
    //处理单片文件的上传
    function loadNext() {
        var start = currentChunk * chunkSize, end = start + chunkSize >= file.size ? file.size : start + chunkSize;
        fileReader.readAsBinaryString(blobSlice.call(file, start, end));
    }
    loadNext();
}
/*处理图片，保存图片 imgTopResultArg：提交的图片；objResultArg：模型obj对象*/


/*上传模型对话框相关操作 步骤2 （进度条）*/
var uploadModelStep = function () {
    $("#uploadModel_oceano").dialog("close");
    $("#uploadModel_oceano2").dialog("open").dialog({"zIndex":1001});
    $(".renderPanel_oceano").hide();
    $("#renderPanel_oceano").dialog("close");
};

//渲染测试 步骤4
$("#uploadModel_oceano4 .model_bottom .btn_next_step").on("click",function(){
    if(!$('#uploadModel_oceano4 .model .model_top .render_pic p').find('img')[0]){
        layer.msg("请测试渲染模型");
        return;
    }
    $("#uploadModel_oceano4").dialog("close");
    tagsShow('uploadModel_oceano6')
    $("#uploadModel_oceano6").dialog("open");
    initUploadSelectModelCatalog("wrap_custom_select_model_style", window.furnitureModelStyleDateJson);
    initUploadSelectModelCatalog("wrap_custom_select_model",window.furnitureModelDateJson);
    $('#custom_select_model_two').find('option').eq(0).attr("selected",true);
    $('#custom_select_model_two').trigger('change');
    var url = api.catalogGetFileUrl("product", UploadProductObj.id, "iso");
    if(url.substr(url.lastIndexOf("&")+1)=="d"){
        url+="=1?"+Date.parse(new Date())/1000
    }else{
        url+="?"+Date.parse(new Date())/1000
    }
    $("#uploadModel_oceano6 .model .right img").attr({"src":url})
    initUploadMessage()
})
/*初始化上传自定义模型的输入框信息 add by hcw*/
function initUploadMessage() {
    $("#edit_Model_oceano3 .model").find('input[type="text"]').val("");
    $('#uploadModel_oceano6 .model ').find('input[cid="clear"]').val("")
    var select=$("#uploadModel_oceano6 .model").find('select')
    select.each(function () {
       $(this).prop("selectedIndex",0)
    })
}
/*初始化上传自定义模型时的下拉框目录信息-2017-08-28 -oxl*/
function initUploadSelectModelCatalog(id,data) {
    var selectsId=[];
    $("#"+id).find("select").each(function(i,v){
        selectsId.push(v.id);
    });
    if(selectsId.length==1){  //风格类型
        $('#'+id).cxSelect({
            selects: selectsId,
            required: true,
            jsonName:"title",
            jsonValue: 'sid',
            data: data
        });
    }else{
        $('#'+id).cxSelect({
            selects: selectsId,
            required: true,
            jsonName:"DESCRIPTION",
            jsonSub: 'children',
            jsonValue: 'ENUM_CODE',
            data: data.children
        });
    }

}

var $MaterialLi = jQuery('.catalogRoomLeft .MaterialLi');
var MaterialLiId;
$MaterialLi.on('click', 'li', function (e) {
    MaterialLiId = $(this).attr("id");
    $MaterialLi.find('.selected').removeClass('selected');
    jQuery(e.currentTarget).addClass('selected');
});

//自定义模型上传步骤6,模型保存
//模型标签删除
$('#uploadModel_oceano6 .model ,#edit_model_property .model').on('click','i',function(e){
    layer.confirm('确定删除该标签？',{},function (index) {
        var tid=jQuery(e.currentTarget).prev('input[type="checkbox"]').val();
        api.getServiceJSONResponsePromise({
            url: ( api.getServicePrefix("customcatalog") )+ "/delCustomTag/",
            type: "POST",
            data: {
                "globalUserLoginId":globalUsrObj.globalUserLoginId,
                "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue,
                "globalPartyId":globalUsrObj.globalPartyId,
                "tid":tid
            }
        }).then(function (v) {
            if(v.error==0){
                layer.close(index);
                jQuery(e.currentTarget).parent('span').remove();
                updateTage();
            }else{
                v=JSON.parse(v)
                layer.msg(v.msg);
                return false;
            }
        }).catch(function (v) {
            $material.tips("删除失败");
            return false;
        });
    })
})

//点击保存标签
$('#uploadModel_oceano6 ,#edit_model_property').find('.save').on("click",function () {
    var text=$.trim($(this).prev('input').val());
    var parent=$(this).parents('.model')
    var lenght= parent.find('div.buttom span').length;
    if(text.length>10){
        layer.msg('标签长度不能超过10个字符');
        return;
    }
    if(text&&lenght<10){
        addTag(parent,text)
    }else if(lenght>=10){
        layer.msg('标签最多10个');
    }
})
//添加标签显示
function addTag(parent,text) {
    var same=false
    parent.find('div.buttom span').each(function () {
        if($(this).attr("val")==text)same=true
    })
    if(same)return
    api.getServiceJSONResponsePromise({
        url: ( api.getServicePrefix("customcatalog") )+ "/addModelFromCustomTag/",
        type: "POST",
        data: {
            "globalUserLoginId":globalUsrObj.globalUserLoginId,
            "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue,
            "globalPartyId":globalUsrObj.globalPartyId,
            "tid":api.uuid(),
            "title":text
        }
    }).then(function (v) {
        if(v.error==0){
            updateTage();
            var html='<span val='+v.msg.title+'><input type="checkbox" value="'+v.msg.tid+'" tag="'+v.msg.title+'"/>'+v.msg.title+'<i></i></span>';
            parent.find('div.buttom').append(html);
        }else{
            v=JSON.parse(v)
            layer.msg(v.msg);
            return false;
        }
    }).catch(function (v) {
        $material.tips("添加失败");
        return false;
    });
}

$("#uploadModel_oceano6 .model_bottom #prevButtonStep6").click(function () {
    $("#uploadModel_oceano6").dialog("close");
    $("#uploadModel_oceano4").dialog("open");
});
/*保存到服务器*/
/*保存之后要清除状态，关闭所有对话框,弹出模态窗口提示上传成功 TODO -2017-08-22*/
$("#uploadModel_oceano6 .model_bottom #buttonStep6").click(function () {
    updateModelInfo('uploadModel_oceano6','保存失败,请重试!!')
});

/*保存自定义模型时信息验证  add by hcw */
function modelValidate(id) {
    var text
    var name=$.trim($('#'+id).find('div.left_div .name').find('input').val());
    var style=$('#'+id).find('div.left_div .style').find('select').val();
    var parent=$('#'+id).find('div.left_div .parent').find('select').val();
    var child=$('#'+id).find('div.left_div .child').find('select').val();
    var long=Number($('#'+id).find('div.left_div .model_size').find('input').eq(0).val());
    var width=Number($('#'+id).find('div.left_div .model_size').find('input').eq(1).val());
    var height=Number($('#'+id).find('div.left_div .model_size').find('input').eq(2).val());
    var max=$('#'+id).find('div.model div.buttom').find('span').length
    if(max>10)text='标签最多10个'
    if(!height)text="请输入模型高度"
    if(!width)text="请输入模型宽度"
    if(!long)text="请输入模型长度"
    if(!child)text="请选择建材子类"
    if(!parent)text="请选择建材主类"
    if(!style)text="请选择风格类型"
    if(!name)text="请输入模型名称"
    if(!text){
        var brand=$('#'+id).find('div.model').find('input[name="brand"]').val();
        var pid=$('#'+id).find('div.model').find('input[name="pid"]').val()
        var tag='';
        $('#'+id).find('div.model').find('div.buttom').find('input[type="checkbox"]').each(function () {
            if($(this).prop('checked')){
                tag+=$(this).val()+',';
            }
        })
        var data={title:name,style:style,category:parent,subcategory:child,xlen:long,ylen:width,zlen:height,brand:brand,tag:tag.substring(0,tag.length-1)}
        if(pid)data.pid=pid
        return data
    }else{
        layer.msg(text,{time:1000})
        return false
    }
}

//自定义模型编辑
$('#edit_model_ul').draggable({"helper": null, "opacity": 1, "cursor": 'move'})
    .on("drag", function (event, ui) {
        $('[aria-describedby="edit_Model_oceano3"]').offset(ui.offset);
    });
$('#edit_Model_oceano3>a').click(function () {
    $("#edit_Model_oceano3").dialog('close')
})
$('#edit_model_ul li').click(function () {
    $("#edit_model_ul li").removeClass('active');
    $(this).addClass('active');
    $('.model_edit_lists').hide();
    $("#" + $(this).attr("cid")).show();
})


var loadingPer=0;
//上传进度条显示
function CustomModelProgress(evt) {
    var loaded=evt.loaded;
    var tot=evt.total;
    var per=Math.floor(100/2*loaded/tot)
    loadingPer+=per
    $('.progress-bar').css('width',loadingPer+'%')
    $('.progress-value').html(loadingPer+'%');
    if(loadingPer >= 100){
        loadingPer=0;
        /*移除原来的弹出框代码到uploadCallback() -2017-08-23*/
    }
}

//初始化进度条
function setIncrementNormal() {
    clearInterval(setTime);
    clearInterval(ModelUploadinterval);
    current=0,uploadTime=0,dropUpload=null,loadingPer=0;
    $("#ModelUpload").val('');
    $('.progress-bar').css('width',current+'%')
    $('.progress-value').html(current+'%');
    $("#uploadModel_oceano2").dialog("close");
}



/*韩超文创建自定义模型步骤*/
/*1.创建临时目录 用作测试用(预览图服务,所以不会保存到服务器)，在表table_catalog_product_custom p10025 p10025,在视图也有这样的数据绑定*/
/*2.真正保存自定义模型到服务器是用了 saveCustomModel() 方法，在所有下一步操作后，点击按钮完成 2017-08-16
 *
 * 整合一下2个 方法，里面很多重复的代码，以及优化数据表的结构，参照自定义拼花的结构去做
 * 后端分离update接口出来，给前端调用 -2017-08-22
 * */
function apiUrlSet(materialId){
    var fileserver = api.getServicePrefix("file")
        ,customTileCatalogServer = api.getServicePrefix("customcatalog")
        ,commonUrl=fileserver + "/uploadFile" + "?id=" + materialId + "&category=product&"
    this.uploadObjUrl = commonUrl+"type=obj"/*obj目录*/
    this.uploadMaxUrl = commonUrl+"type=max"/*zip渲染压缩包目录*/
    this.uploadTopUrl = commonUrl+"type=top"/*top图*/
    this.uploadThumbUrl = commonUrl+"type=thumb"/*thumb图*/
    this.uploadTopJpgUrl = commonUrl+"type=texture"/*png大图*/
    this.saveCustomTileUrl=customTileCatalogServer+"/addCustomTileFurnitureView/";

}

// var modelUploadImgAction=function(uuid,objResultArg,imgTopResultArg,zip,top,thumb){
//     var materialId =uuid || 'um_'+ globalUsrObj.globalPartyId;
//     var errorTips={ "sava":"保存失败,请重试!!",
//         "upload":"上传失败,请重试!!"
//     }
//     apiUrlSet.call(this,materialId);
//     /*上传文件的action
//      *uploadFile接口在 file/index.js 定义
//      * 上传接口会先保存到本地，再上传阿里云
//      * add by oxl 2017-03-08
//      * */
//     var $title="自定义模型"
//     /*id产品id，globalPartyId：用户目录id*/
//     /*cid暂时用 um_+data.globalPartyId -2017-08-30 -oxl*/
//     var $objData={cid:"um_"+globalUsrObj.globalPartyId,pid:materialId,"title":$title,"globalPartyId":globalUsrObj.globalPartyId,"globalUserLoginId":globalUsrObj.globalUserLoginId,"globalAccessTokenValue":globalUsrObj.globalAccessTokenValue}
//     if(uuid){
//         var valiate=modelValidate('uploadModel_oceano6')
//         if(!valiate)return;
//         var $objNewData={ title:valiate.title,style:valiate.style,brand:valiate.brand,
//             category:valiate.category,subcategory:valiate.subcategory,
//             xlen:valiate.xlen,ylen:valiate.ylen,zlen:valiate.zlen,
//             tags:valiate.tag}
//     }
//     api.getServiceJSONResponsePromise({
//         url: (  api.getServicePrefix("customcatalog") )+ "/checklogin",
//         type: "POST",
//         data: {
//             "globalUserLoginId":globalUsrObj.globalUserLoginId,
//             "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue
//         }
//
//     }).then(function (resp) {
//         //var formData=new FormData();
//         //formData.append("data",imgThumbResultArg)
//         if(resp.msg=="existsUser"){//注册用户
//             /*先上传obj*/
//             if(uuid)$('#uploadModel_oceano6 .save_doing').show()
//             api.getServiceJSONResponsePromiseUpload({
//                 url: uploadObjUrl,
//                 type: "POST",
//                 cache: false,
//                 contentType: false,
//                 processData: false,
//                 data: objResultArg,
//             }).catch(function (e) {
//                 layer.alert('上传失败,请重试!! ', {
//                     closeBtn: 0,
//                     skin: 'layui-layer-default'
//                 });
//                 setIncrementNormal()
//             }).then(function(resp){
//                 //上传top图
//                 if(resp.error || !resp){
//                     setIncrementNormal()
//                     return ;
//                 }
//                 return api.getServiceJSONResponsePromiseUpload({
//                     url: uploadTopUrl,
//                     type: "POST",
//                     cache: false,
//                     contentType: false,
//                     processData: false,
//                     data: top,
//
//                 })//可以用buffer或者formData，这里是buffer
//
//             }).catch(function (e) {
//                 layer.alert('上传失败,请重试!! ', {
//                     closeBtn: 0,
//                     skin: 'layui-layer-default'
//                 });
//                 setIncrementNormal()
//             }).then(function(resp){
//                 //上传thumb图
//                 if(resp.error || !resp){
//                     setIncrementNormal()
//                     return ;
//                 }
//                 return api.getServiceJSONResponsePromiseUpload({
//                     url: uploadThumbUrl,
//                     type: "POST",
//                     cache: false,
//                     contentType: false,
//                     processData: false,
//                     data: thumb,
//
//                 })//可以用buffer或者formData，这里是buffer
//
//             }).catch(function (e) {
//                 layer.alert('上传失败,请重试!! ', {
//                     closeBtn: 0,
//                     skin: 'layui-layer-default'
//                 });
//                 setIncrementNormal()
//             }).then(function (resp) {
//                 if(resp.error || !resp){
//                     setIncrementNormal()
//                     return ;
//                 }
//                 /*模型zip文件*/
//                 return api.getServiceJSONResponsePromiseUpload({
//                     url: uploadMaxUrl,
//                     type: "POST",
//                     cache: false,
//                     contentType: false,
//                     processData: false,
//                     data: zip,
//                 })//可以用buffer或者formData，这里是buffer
//             }).then(function(resp){
//                 /*大图内容为0，但不是错误的情况*/
//                 if(resp.error || !resp){
//                     setIncrementNormal()
//                     return ;
//                 }
//                 /*product.png图*/
//                 return api.getServiceJSONResponsePromiseUpload({
//                     url: uploadTopJpgUrl,
//                     type: "POST",
//                     cache: false,
//                     contentType: false,
//                     processData: false,
//                     data: imgTopResultArg,//可以用buffer或者formData，这里是buffer,
//                 })//可以用buffer或者formData，这里是buffer
//
//             }).then(function (resp) {
//                 var layerTxt="";
//                 var cb;
//                 if(uuid){
//                     $.extend($objData,$objNewData);
//                     layerTxt=errorTips.sava//最后的保存
//                     cb=saveCallBack;
//                     $('#uploadModel_oceano6 .save_doing').hide()
//                 }/*如果是保存到服务器，重新组织$objData的数据*/
//                 else{
//                     layerTxt=errorTips.upload;//第一次上传
//                     cb=uploadCallBack;
//                 }
//                 if(resp){
//                     /*保存其他参数*/
//                     /*$objData要组合的参数比临时保存的多*/
//                     api.getServiceJSONResponsePromise({
//                         url: saveCustomTileUrl,
//                         type: "POST",
//                         cache: false,
//                         data: $objData
//                     }).then(function (r) {
//                         if(!uuid){
//                             cb(materialId,resp,layerTxt);
//                             return;
//                         }
//                         cb(r,layerTxt);
//                     })
//
//
//
//
//                 }else{
//                     layer.alert(layerTxt, {
//                         closeBtn: 0,
//                         skin: 'layui-layer-default'
//                     });
//                     setIncrementNormal()
//                 }
//             });
//         }
//         else{
//             $material.tips("请登录");
//             setIncrementNormal()
//         }
//     });
// }
function uploadProductMaxZip(uuid,zip) {
    /*模型max.zip文件*/
    var fileserver = api.getServicePrefix("file")
        ,customTileCatalogServer = api.getServicePrefix("customcatalog")
        ,commonUrl=fileserver + "/uploadFile" + "?id=" + uuid + "&category=product&";
    var uploadMaxUrl = commonUrl+"type=product.temp.zip"/*zip渲染压缩包目录*/;
    var saveCustomTileUrl=customTileCatalogServer+"/addCustomTileFurnitureView/";
    api.getServiceJSONResponsePromise({
        url: (  api.getServicePrefix("customcatalog") )+ "/checklogin",
        type: "POST",
        data: {
            "globalUserLoginId":globalUsrObj.globalUserLoginId,
            "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue
        }

    }).then(function (resp) {
        if(resp.msg=="existsUser") {//注册用户
            api.getServiceJSONResponsePromiseUpload({
                url: uploadMaxUrl,
                type: "POST",
                cache: false,
                contentType: false,
                processData: false,
                data: zip,
            }).then(function(resp) {
                if (resp.error || !resp) {
                    setIncrementNormal()
                    return;
                }
                var $objData={cid:"um_"+globalUsrObj.globalPartyId,pid:uuid,"title":"自定义模型","globalPartyId":globalUsrObj.globalPartyId,"globalUserLoginId":globalUsrObj.globalUserLoginId,"globalAccessTokenValue":globalUsrObj.globalAccessTokenValue,
                    style:"",brand:"", category:"",subcategory:"", xlen:"",ylen:"",zlen:"", tags:""
                }
                api.getServiceJSONResponsePromiseUpload({
                    url: saveCustomTileUrl,
                    type: "POST",
                    cache: false,
                    data: $objData
                }).then(function (resp) {
                    if(resp.error || !resp){
                        $material.tips('上传失败，请重试！');
                        setIncrementNormal()
                        return;
                    }
                    $('#uploadModel_oceano6').find('div.model').find('input[name="pid"]').val(uuid);
                    /*提示上传成功*/
                    layer.msg("上传成功",{time:1000},function () {
                        $("#uploadModel_oceano2").dialog("close");
                        $("#uploadModel_oceano3").dialog("open");
                        setIncrementNormal();
                        api.getServiceJSONResponsePromise({
                            url:api.getServicePrefix("packMax")+"/postPackMaxRequest",
                            type: "POST",
                            cache: false,
                            data: {jobid:uuid,roomstr:"http://pic.oceano.com.cn/h5filesystem/products/"+uuid+"/product.max.zip",decobj:20,decmax:30,optionobj:{decobj:20,decmax:30}},
                        }).then(function (res) {
                            if(!res.error){
                                var getPackMaxStatus=setInterval(function () {
                                    api.getServiceJSONResponsePromise({
                                        url:api.getServicePrefix("packMax")+"/getPackMaxStatus?jobid="+uuid,
                                        type: "GET",
                                        cache: false,
                                    }).then(function (res) {
                                        console.log(res)
                                        if(res.jobstatus==2){
                                            clearInterval(getPackMaxStatus);
                                            $("#uploadModel_oceano3").dialog("close");
                                            setIncrementNormal()
                                            //测试渲染弹出框
                                            $("#uploadModel_oceano4").dialog("open");
                                            TestRenderModel(uuid);
                                        }else if(res.jobstatus==3){
                                            $material.tips('获取模型失败，请重新上传');
                                            clearInterval(getPackMaxStatus);
                                            setIncrementNormal();
                                            $("#uploadModel_oceano2").dialog("open");
                                            $("#uploadModel_oceano3").dialog("close");
                                        }
                                    })
                                },2000)
                            }else{
                                $material.tips('数据存入失败，请重新上传');
                                setIncrementNormal()
                            }
                        })
                    });
                })
            })
        }else{
            $material.tips("请登录");
            setIncrementNormal()
        }
    })
}
var modelUploadImgAction=function(uuid){
    var materialId =uuid || 'um_'+ globalUsrObj.globalPartyId;
    var errorTips={ "sava":"保存失败,请重试!!",
        "upload":"上传失败,请重试!!"
    }
    apiUrlSet.call(this,materialId);
    /*上传文件的action
     *uploadFile接口在 file/index.js 定义
     * 上传接口会先保存到本地，再上传阿里云
     * add by oxl 2017-03-08
     * */
    var $title="自定义模型"
    /*id产品id，globalPartyId：用户目录id*/
    /*cid暂时用 um_+data.globalPartyId -2017-08-30 -oxl*/
    var $objData={cid:"um_"+globalUsrObj.globalPartyId,pid:materialId,"title":$title,"globalPartyId":globalUsrObj.globalPartyId,"globalUserLoginId":globalUsrObj.globalUserLoginId,"globalAccessTokenValue":globalUsrObj.globalAccessTokenValue}
    if(uuid){
        var valiate=modelValidate('uploadModel_oceano6')
        if(!valiate)return;
        var $objNewData={ title:valiate.title,style:valiate.style,brand:valiate.brand,
            category:valiate.category,subcategory:valiate.subcategory,
            xlen:valiate.xlen,ylen:valiate.ylen,zlen:valiate.zlen,
            tags:valiate.tag}
    }
    api.getServiceJSONResponsePromise({
        url: (  api.getServicePrefix("customcatalog") )+ "/checklogin",
        type: "POST",
        data: {
            "globalUserLoginId":globalUsrObj.globalUserLoginId,
            "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue
        }

    }).then(function (resp) {
        if(resp.msg=="existsUser"){//注册用户
            if(uuid)$('#uploadModel_oceano6 .save_doing').show()
            var layerTxt="";
            var cb;
            $.extend($objData,$objNewData);
            layerTxt=errorTips.sava//最后的保存
            cb=saveCallBack;
            /*如果是保存到服务器，重新组织$objData的数据*/
            if(resp){
                /*保存其他参数*/
                /*$objData要组合的参数比临时保存的多*/
                api.getServiceJSONResponsePromise({
                    url: saveCustomTileUrl,
                    type: "POST",
                    cache: false,
                    data: $objData
                }).then(function (resp) {
                    $('#uploadModel_oceano6 .save_doing').hide()
                    if(resp.error || !resp){
                        $material.tips('保存失败，请重试');
                        return;
                    }
                    cb(r,layerTxt);
                })
            }else{
                layer.alert(layerTxt, {
                    closeBtn: 0,
                    skin: 'layui-layer-default'
                });
                setIncrementNormal()
            }
        }
        else{

        }
    });
}
//上传，保存,编辑 用户自定义模型 TODO 编辑修改，删除接口 -2017-08-23

/*TODO 要添加上传成功后的弹出框提示 -2017-08-23*/
function saveCallBack(resp,layerTxt){
    if(resp.error==2 || !resp){
        layer.alert(layerTxt, {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
        return
    }
    layer.msg("保存成功",{time:1000},function () {
        $("#uploadModel_oceano,#uploadModel_oceano6,#edit_Model_oceano3").dialog("close");
        var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:$('#threeModelCatalogInputSelect').val(),style:$('#oneModelCatalogInputSelect').val(),tags:$('#fourModelCatalogInputSelect').val()};
        //从新加载数据
        loadCustomModelProducts(dataObj, 0, 10);
    });
}
function uploadCallBack(materialId,resp,layerTxt){
    if(resp.error==2 || !resp){
        $("#uploadModel_oceano3").dialog("close");
        return
    }
    if($('#uploadModel_oceano2').parent().is(':hidden'))return;
    setTimeout(function () {
        /*提示上传成功*/
        layer.msg("上传成功",{time:1000},function () {
            $("#uploadModel_oceano2").dialog("close");
            $("#uploadModel_oceano3").dialog("open");
            setIncrementNormal();
        });
    },1000)
    /*关闭弹出框*/
    setTimeout(function () {
        $("#uploadModel_oceano3").dialog("close");
        setIncrementNormal()

        //测试渲染弹出框
        $("#uploadModel_oceano4").dialog("open");
        TestRenderModel(materialId);
    },3000)
}

/**
 * 加载自定义目录下的产品
 * @param cid
 * @param viewindex
 * @param viewsize
 */
function loadCustomModelProducts(dataObj, viewindex, viewsize) {
    $("#custom_productsList").empty();
    /*dataObj.cid 的值暂时 写死为 "um_"+globalUsrObj.globalPartyId,添加一个ucid作用用户标识；
    TODO 到时读取 对应的目录分类提交真正的cid -2017-08-31 -oxl*/
    var data = {
        "cid": dataObj.cid,
        "ucid": "um_"+globalUsrObj.globalPartyId,
        "ENUM_CODE":dataObj.ENUM_CODE,
        "brand": dataObj.brand,
        "style":dataObj.style,
        "tags":dataObj.tags,
        "viewindex": viewindex,
        "viewsize": viewsize
    };
    api.getServiceJSONResponsePromise({
        type: 'get',
        // TODO 下一个版本使用这个接口
        // url: ( api.getServicePrefix("customcatalog") )+ "/getCustomModelByCatalogId",
        //当前版本用这个api
        url: ( api.getServicePrefix("customcatalog") )+ "/getModelByIdAndCategory",
        cache: false,
        data: data
    }).then(function (products) {
        renderCustomModelProducts(products);
        /*初始化分页属性*/
        if (products && products.length > 0) {
            $(".catalogMaterialPagination").show();
            resizePage();
            $(".catalogMaterialPagination .pagination").pagination(products[0].count, {
                callback: function (page_index, jq) {
                    /*分页切换时需要传递参数，TODO 直接用js取 */
                    var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:$('#threeModelCatalogInputSelect').val(),style:$('#oneModelCatalogInputSelect').val(),tags:$('#fourModelCatalogInputSelect').val()};
                    loadCustomModelProducts(dataObj, page_index, viewsize);
                },
                prev_text: '<',
                next_text: '>',
                items_per_page: 10,
                num_display_entries: 4, //连续分页主体部分显示的分页条目数
                current_page: viewindex,
                num_edge_entries: 2 //两侧显示的首尾分页的条目数
            });
        } else {
            $(".catalogMaterialPagination").hide();
        }
    }).catch(function (e) {
        layer.alert('send getModelByIdAndCategory request to server failed!! ', {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
    });
}

/*渲染[自定义模型] 目录里面的数据
 * add by oxl
 * */
function renderCustomModelProducts(products) {
    if (!products || products.length == 0) return;
    var $productZoom = $('#materialZoom').css({"height":"400px"});
    //console.clear();
    products.forEach(function (leaf) {
        var $productItem = $("<div>");
        $productItem.attr({
            pid: leaf.pid,
            title: leaf.title
        })
            .addClass("img_container")
            .appendTo($("<li>")
                .appendTo("#custom_productsList"))
            .on("click", customModelProductClick)
            .each(function () {
                var pid = leaf.pid;
                var _self = this;

                //loadProductImage(api.catalogGetFileUrl("product", pid, "iso"), _self);
                //目录的小预览图，修正为自适应宽高 oxl
                $("<img>").attr({
                    src: ui.catalogGetFileUrl("product", pid, "iso"),
                    class: 'prodimg'
                }).load(function(e){
                    var imgSize={"width":this.naturalWidth,"height":this.naturalHeight};
                    imgSize=adjustImageWH(imgSize, 100, 100);
                    $(this).css({ width: imgSize.width, height: imgSize.height });
                }).appendTo(this);


                $("<div>").addClass("img_oper")
                    .append($("<div>").addClass("bookremark").attr("title", "收藏"))
                    .append($("<div>").addClass("info").hover(function (e) {
                        $productZoom.empty();
                        $("<div>").addClass("wrap-product-zoom-img")
                            .append(
                                $("<img>")
                                    .addClass("prodimg product-zoom-img")
                                    .attr({
                                        src: ui.catalogGetFileUrl("product", leaf.pid, "iso"),
                                        objid:pid
                                    }).load(function(e){
                                    var imgSize={"width":this.naturalWidth,"height":this.naturalHeight};
                                    imgSize=adjustImageWH(imgSize, 256, 256);
                                    $(this).css({ width: imgSize.width, height: imgSize.height });
                                })
                            ).appendTo($productZoom);

                        var product_size = (Math.ceil(leaf.xlen * 1000) / 1000) + "x" + (Math.ceil(leaf.ylen * 1000) / 1000);
                        if (leaf.zlen > 0) product_size += "x" + (Math.ceil(leaf.zlen * 1000) / 1000);
                        var product_brand = leaf.productbrand//fakeUnnicodeToChinese(leaf.productbrand);
                        if ('full' == product_brand) product_brand = "无";

                        $("<div>").addClass("product-short-info")
                            .append($("<div>").addClass("size").text("名称：" + (leaf.model || "") + leaf.title + ""))
                            .append($("<div>").addClass("size").text("尺寸：" + product_size + "(m)"))
                            .append($("<div>").addClass("size").text("品牌：" + product_brand))
                            .append($("<div>").addClass("model_delete_btn button").text("删除"))
                            .append($("<div>").addClass("model_edit_btn button").text("修改"))
                            .attr({
                                pid: leaf.pid,
                                titles: leaf.title,
                                brand:leaf.productbrand,
                                style:leaf.style,
                                category_orgin:leaf.category_orgin,
                                subcategory:leaf.subcategory,
                                xlen: leaf.xlen,
                                ylen: leaf.ylen,
                                zlen: leaf.zlen,
                                tags:leaf.tags
                            })
                            .appendTo($productZoom);
                        var position = $(_self).position();


                        var zoomTop = position.top;
                        var zoomLeft = (position.left + 98) + 'px';
                        var zoomHeight = $productZoom.height();
                        var catalogHeight = jQuery('.catalogRoomRight').height();

                        if (catalogHeight - zoomTop - zoomHeight < 30) {
                            var productItemHeight = $productItem.parent().height();
                            zoomTop = position.top + productItemHeight - zoomHeight;
                        }
                        zoomTop = (zoomTop + 20) + 'px';
                        $productZoom
                            .css({
                                left: zoomLeft,
                                top: zoomTop
                            })
                            .show()
                            .hover(function (e) {
                                $(this).show();
                            }, function (e) {
                                $(this).hide();
                            });

                    }, function (e) {
                        $productZoom.hide();
                    }))
                    .appendTo(this);
            }).hover(function (e) {
            $(this).find(".img_oper").addClass("img_oper_cur");
        }, function (e) {
            $(this).find(".img_oper").removeClass("img_oper_cur");
        });
        lazyLoad.init();
    });

}

/*素材hover删除事件*/
$("#materialZoom").on("click",".model_delete_btn",function(){
    var that = $(this);
    layer.confirm('确定删除该模型？',{},function () {
        var $img = that.parents("#materialZoom").find("img");
        var objid = $img.attr("objid");
        api.getServiceJSONResponsePromise({
            url: ( api.getServicePrefix("customcatalog") )+ "/delCustomTile",
            type: "POST",
            data: {
                "globalUserLoginId":globalUsrObj.globalUserLoginId,
                "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue,
                "globalPartyId":globalUsrObj.globalPartyId,
                "pid":objid
            }
        }).then(function (v) {
            if(v.error==0){
                //that.parent().parent().hide();
               // $("#custom_productsList li div[pid="+objid+"]").parent().remove()
                layer.msg("删除成功");
                var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:$('#threeModelCatalogInputSelect').val(),style:$('#oneModelCatalogInputSelect').val(),tags:$('#fourModelCatalogInputSelect').val()};
                loadCustomModelProducts(dataObj, 0, 10);
                return
            }
            v=JSON.parse(v)
            layer.msg(v.msg);
        }).catch(function (v) {
            $material.tips("删除失败");
        });
    })
});

/*素材修改事件*/
$("#materialZoom").on("click",".model_edit_btn",function(){
    $('#edit_model_ul li').eq(0).trigger("click")
    initUploadMessage()
    var that=$(this),modelInfoDiv=that.parent('.product-short-info');
    var $img = that.parents("#materialZoom").find("img");
    var imgSrc = $img.attr("src");
    $("#edit_Model_oceano3 #edit_model_property .right img").attr({"src":imgSrc})
    initUploadSelectModelCatalog("edit_wrap_custom_select_model_style", window.furnitureModelStyleDateJson);
    initUploadSelectModelCatalog("edit_wrap_custom_select_model",window.furnitureModelDateJson);
    $('#edit_custom_select_model_style').val(modelInfoDiv.attr('style'))
    $('#edit_custom_select_model_two').val(modelInfoDiv.attr('category_orgin'))
    $('#edit_custom_select_model_two').trigger('change')
    $('#edit_Model_oceano3').find('input[name="title"]').val(modelInfoDiv.attr('titles'))
    $('#edit_Model_oceano3').find('input[name="brand"]').val(modelInfoDiv.attr('brand')=="full"?"":modelInfoDiv.attr('brand'))
    $('#edit_Model_oceano3').find('input[name="xlen"]').val(modelInfoDiv.attr('xlen'))
    $('#edit_Model_oceano3').find('input[name="ylen"]').val(modelInfoDiv.attr('ylen'))
    $('#edit_Model_oceano3').find('input[name="zlen"]').val(modelInfoDiv.attr('zlen'))
    $('#edit_Model_oceano3').find('input[name="pid"]').val(modelInfoDiv.attr('pid'))
    $('#edit_custom_select_model_three').val(modelInfoDiv.attr('subcategory'))
    tagsShow('edit_Model_oceano3',modelInfoDiv.attr('tags'))
    $("#edit_Model_oceano3").dialog('open')
});
function  updateTage() {
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: api.getServicePrefix("customcatalog")+ "/getProductAllTag",
        cache: false,
        data: {ucid:globalUsrObj.globalPartyId}
    }).then(function (r) {
        if(r){
            window.furnitureModelTagDateJson=JSON.parse(r);
            initSelectTagModelCatalog()
        }
    })
}

function tagsShow(id,tags) {
        var html='';
        window.furnitureModelTagDateJson.forEach(function (e,i) {
            if(tags){
                var checked='';
                var arr=tags.split(',')
                arr.forEach(function (t) {
                     if(t==e.tid){
                         checked='checked'
                     }
                })
                html+='<span val='+e.description+'><input type="checkbox" '+checked+' value="'+e.tid+'" tag="'+e.description+'"/>'+e.description+'<i></i></span>';
            }else{
                html+='<span val='+e.description+'><input type="checkbox" value="'+e.tid+'" tag="'+e.description+'"/>'+e.description+'<i></i></span>';
            }
        })
        if (html)$('#'+id).find('.model').find('div.buttom').html(html)

}
//修改保存
$('#ModeleditButton').click(function () {
    updateModelInfo('edit_Model_oceano3')
})
function updateModelInfo(id,message) {
    var validate=modelValidate(id);
    if(!validate)return;
    var $objData={"globalPartyId":globalUsrObj.globalPartyId,"globalAccessTokenValue":globalUsrObj.globalAccessTokenValue,"globalUserLoginId":globalUsrObj.globalUserLoginId,}
    var saveCustomTileUrl=api.getServicePrefix("customcatalog")+"/updateCustomFurniture/";
    var $objNewData={ title:validate.title,style:validate.style,brand:validate.brand,
        category:validate.category,subcategory:validate.subcategory,
        xlen:validate.xlen,ylen:validate.ylen,zlen:validate.zlen,pid:validate.pid,tags:validate.tag}
    $.extend($objData,$objNewData);
    /*$objData要组合的参数比临时保存的多*/
    api.getServiceJSONResponsePromise({
        url: saveCustomTileUrl,
        type: "POST",
        cache: false,
        data: $objData
    }).then(function (r) {
        if(r.error!=2 || r){
            //编辑成功时，清除缓存，再次获取数据
            api.catalogGetCustomModelProductsMetaPromise([validate.pid],true).then(function (rv) {
                saveCallBack(r,message?message:"修改失败,请重试!!");
            });
        }else{
            saveCallBack(r,message?message:"修改失败,请重试!!");
        }
    })
}
/**
 * 加载搜索后的产品
 * @param searchstring
 * @param viewindex
 * @param viewsize
 * todo 搜索待定还没修改
 */

function searchModelAction() {
    var searchstring = $("#materialSearch").find(".valueText").val();
    if (searchstring == ''){
        return
    };
    loadSearchedModles(searchstring, 0, 10);
}

function loadSearchedModles(searchstring, viewindex, viewsize) {
    $("#custom_productsList").empty();
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: api.getServicePrefix("customcatalog") + "/searchModelFromCustomCatalog",
        cache: false,
        data: {
            "searchstring": searchstring,
            "globalPartyId":globalUsrObj.globalPartyId,
            "viewindex": viewindex,
            "viewsize": viewsize
        }
    }).then(function (products) {
        renderCustomModelProducts(products);
        /*初始化分页属性*/
        if (products && products.length > 0) {
            $(".catalogMaterialPagination").show();
            $(".catalogMaterialPagination .pagination").pagination(products[0].count, {
                callback: function (page_index, jq) {
                    loadSearchedModles(searchstring, page_index, viewsize);
                },
                prev_text: '<',
                next_text: '>',
                items_per_page: 10,
                num_display_entries: 4, //连续分页主体部分显示的分页条目数
                current_page: viewindex,
                num_edge_entries: 2 //两侧显示的首尾分页的条目数
            });
        } else {
            $(".catalogMaterialPagination").hide();
        }
    }).catch(function (e) {
        layer.alert('send searchProductsFromCustomCatalog request to server failed!! ', {
            title: '提示',
            skin: 'layui-layer-default'
        });
    });
}

/*我的品牌-左边栏选项卡 点击事件*/
var $MaterialLi = jQuery('.catalogRoomLeft .MaterialLi');
var MaterialLiId;
$MaterialLi.on('click', 'li', function (e) {
    MaterialLiId = $(this).attr("id");
    $MaterialLi.find('.selected').removeClass('selected');
    jQuery(e.currentTarget).addClass('selected');
});

/*初始化下拉框目录信息*/
function initSelectModelCatalog(catalogLevel1, catalogLevel2, catalogLevel3) {
    /*一级、二级当前目录值*/
    var oneCatalogDivSelectStr = "#oneModelCatalogDivSelect";/*div*/
    var twoCatalogDivSelectStr = "#twoModelCatalogDivSelect";/*div*/
    var threeCatalogDivSelectStr = "#threeModelCatalogDivSelect";
    var oneCatalogInputSelectStr = "#oneModelCatalogInputSelect";/*hidden input*/
    var twoCatalogInputSelectStr = "#twoModelCatalogInputSelect";/*hidden input*/
    var threeCatalogInputSelectStr = "#threeModelCatalogInputSelect";

    var oneCatalogObj = $(oneCatalogDivSelectStr + ' ul').empty();
    var twoCatalogObj = $(twoCatalogDivSelectStr + ' ul').empty();
    var threeCatalogObj = $(threeCatalogDivSelectStr + ' ul').empty();

    catalogLevel1.children.forEach(function (level2, index2) {
        $("<li>").append($("<a>").attr({
            "href": "javascript:;",
            "selectid": level2.ENUM_CODE
        }).text(level2.DESCRIPTION)).appendTo(twoCatalogObj);
    });
    catalogLevel2.children.forEach(function (level3, index3) {
        $("<li>").append($("<a>").attr({
            "href": "javascript:;",
            "selectid": level3.ENUM_CODE
        }).text(level3.DESCRIPTION)).appendTo(threeCatalogObj);
    });
    window.furnitureModelStyleDateJson.forEach(function (level1, index1) {
        $("<li>").append($("<a>").attr({
            "href": "javascript:;",
            "selectid": level1.sid
        }).text(level1.title)).appendTo(oneCatalogObj);
    });
    $.divselect("风格", oneCatalogDivSelectStr, oneCatalogInputSelectStr, function (value) {
        var dataObj={cid:"um_"+globalUsrObj.globalPartyId,style:value,ENUM_CODE:$('#threeModelCatalogInputSelect').val(),tags:$('#fourModelCatalogInputSelect').val()};
        loadCustomModelProducts(dataObj, 0, 10);
    });

    /*初始化第一次出现的值，第一联和第二联*/
    $.divselectInit( window.furnitureModelStyleDateJson[0].title,window.furnitureModelStyleDateJson[0].sid, oneCatalogDivSelectStr, oneCatalogInputSelectStr);
    $.divselectInit(catalogLevel2.DESCRIPTION, catalogLevel2.ENUM_CODE, twoCatalogDivSelectStr, twoCatalogInputSelectStr);
    $.divselectInit(catalogLevel3.DESCRIPTION, catalogLevel3.ENUM_CODE, threeCatalogDivSelectStr, threeCatalogInputSelectStr);

    /*点击二级目录时*/
    /*二级目录联动三级目录，默认显示三级目录中的第一个目录值，并加载出该目录下的产品数据*/
    $.divselect("二级目录", twoCatalogDivSelectStr, twoCatalogInputSelectStr, function (value) {
        threeCatalogObj.empty();

        catalogLevel1.children.forEach(function (level2, index2) {
            if (level2.ENUM_CODE == value) {
                level2.children.forEach(function (level3, index3) {
                    /*硬编码逻辑：一级菜单硬装点击不显示风格和色系
                     1、不需要风格和色系查询
                     2、品牌只显示【欧神诺】
                     * */
                    $("<li>").append($("<a>").attr({
                        "href": "javascript:;",
                        "selectid": level3.ENUM_CODE
                    }).text(level3.DESCRIPTION)).appendTo(threeCatalogObj);
                    if (index3 == 0) {
                        $.divselectInit(level3.DESCRIPTION, level3.ENUM_CODE, threeCatalogDivSelectStr, threeCatalogInputSelectStr);
                        //loadCatalogProducts(level3.cid, 0, 20);
                        var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:level3.ENUM_CODE,style:$('#oneModelCatalogInputSelect').val(),tags:$('#fourModelCatalogInputSelect').val()};
                        loadCustomModelProducts(dataObj, 0, 10);
                    }
                });
            }
        });

        $.divselect("三级目录", threeCatalogDivSelectStr, threeCatalogInputSelectStr, function (value) {
            //loadCatalogProducts(value, 0, 20);
            var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:value,style:$('#oneModelCatalogInputSelect').val(),tags:$('#fourModelCatalogInputSelect').val()};
            loadCustomModelProducts(dataObj, 0, 10);
        });
    });
    /*单独点击三级目录时*/
    /*三级目录加载该目录下数据*/
    $.divselect("三级目录", threeCatalogDivSelectStr, threeCatalogInputSelectStr, function (value) {
        //loadCatalogProducts(value, 0, 20);
        var dataObj={cid:"um_"+globalUsrObj.globalPartyId,ENUM_CODE:value,style:$('#oneModelCatalogInputSelect').val(),tags:$('#fourModelCatalogInputSelect').val()};
        loadCustomModelProducts(dataObj, 0, 10);
    });
}

/*初始化标签下拉框目录信息*/
function initSelectTagModelCatalog() {
    /*一级、二级当前目录值*/
    var fourCatalogDivSelectStr = "#fourModelCatalogDivSelect";/*div*/
    var fourCatalogInputSelectStr = "#fourModelCatalogInputSelect";/*hidden input*/

    var fourCatalogObj = $(fourCatalogDivSelectStr + ' ul').empty();
    $("<li>").append($("<a>").attr({
        "href": "javascript:;",
        "selectid": "all"
    }).text("全部")).appendTo(fourCatalogObj);
    window.furnitureModelTagDateJson.forEach(function (level1, index1) {
        $("<li>").append($("<a>").attr({
            "href": "javascript:;",
            "selectid": level1.tid
        }).text(level1.description)).appendTo(fourCatalogObj);
    });
    $.divselectInit("标签", "all", fourCatalogDivSelectStr, fourCatalogInputSelectStr);
    $.divselect("标签", fourCatalogDivSelectStr, fourCatalogInputSelectStr, function (value) {
        var dataObj={cid:"um_"+globalUsrObj.globalPartyId,style:$('#oneModelCatalogInputSelect').val(),ENUM_CODE:$('#threeModelCatalogInputSelect').val(),tags:value};
        loadCustomModelProducts(dataObj, 0, 10);
    });
}

///我的品牌-左边栏鼠标经过显示，计算显示框高度
function setBrandSubMenuPos($selectedMenu, $subMenu) {

    var bodyHeight = $body.height();
    var menuOffset = $selectedMenu.offset();
    var menuTop = menuOffset.top;
    var menuWidth = $selectedMenu.width();
    var menuHeight = $selectedMenu.height();
    var bottomSpace = bodyHeight - menuTop;
    var topBarSpace = 120;
    var maxTopSpace = bodyHeight - topBarSpace;

    var subMenuHeight = $subMenu.find(".content_catalog").height();
    var subMenuLeft = (menuOffset.left + menuWidth) + 'px';
    var subMenuTop = bottomSpace < subMenuHeight ?
        (menuTop + menuHeight - subMenuHeight + 1) :
        menuTop;

    $subMenu.height(subMenuHeight+10);
    if (subMenuTop < 0) {
        subMenuTop = 0;
        $subMenu.height(bodyHeight -subMenuTop );
        $subMenu.css("overflow","auto");
    }
    $subMenu.css({
        left: subMenuLeft,
        top: subMenuTop + 'px'
    }).show();
}

//监听拖拽事件,阻止浏览器默认行为
$(function () {
    document.addEventListener('dragleave',function (e) {
        e.preventDefault();
    })
    document.addEventListener('drop',function (e) {
        e.preventDefault();
    })
    document.addEventListener('dragenter',function (e) {
        e.preventDefault();
    })
    document.addEventListener('dragover',function (e) {
        e.preventDefault();
    })
})

//# sourceURL=ui\catalog\catalog_oceano_model.js
