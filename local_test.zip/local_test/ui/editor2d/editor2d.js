$(window).bind('resize', function () {
    api.viewFit("2d");
});

//# sourceURL=ui\editor2d\editor2d.js