/*====================================墙3d[begin]==========================================*/

/* 矩形区域 离地 */
$(threed_rectarea3d_ground_slider)
    .on("slidestart", function (e, ui) {
        this._model = api.pickGetPicked()[0].model;
        if(this._model.type == "RECTAREA" || 
           this._model.type == "ROUNDAREA" || 
           this._model.type == "FREEAREA"){
        	api.actionBegin("SetGeneralProp", this._model);
        }else{
          api.actionBegin("SetGeneralProp", this._model.center);
        }
    })
    .on("slide", function (e, ui) {
    	  if(this._model.type == "RECTAREA" || 
           this._model.type == "ROUNDAREA" || 
           this._model.type == "FREEAREA"){
          api.actionRun("set", "z", ui.value);
        }else{
        	api.actionRun("set", "y", ui.value + this._model.height / 2);
        }
    })
    .on("slidestop", function (e, ui) {
        delete this._model;
        api.actionEnd("SetGeneralProp");
    });

$(threed_rectarea3d_ground_text).bind("keypress blur", function (event) {
     var _this = $(this);
    if(event.type=="blur"){
        //saveValue();
    }else{
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model;
        
        if(model.type == "RECTAREA" || 
           model.type == "ROUNDAREA" || 
           model.type == "FREEAREA"){
        	api.actionBegin("SetGeneralProp", model);
          api.actionRun("set", "z", parseFloat(_this.val() / 1000));
          api.actionEnd("SetGeneralProp");
        }else{
        	api.actionBegin("SetGeneralProp", model.center);
          api.actionRun("set", "y", parseFloat(_this.val() / 1000) + model.height / 2);
          api.actionEnd("SetGeneralProp");
        }

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val() / 1000));
        return false;
    }
});

/* 矩形区域 厚度 */
$(threed_rectarea3d_height3d_slider)
    .on("slidestart", function (e, ui) {
        this._model = api.pickGetPicked()[0].model;
        if(this._model.type == "RECTAREA" || 
           this._model.type == "ROUNDAREA" || 
           this._model.type == "FREEAREA"){
        	api.actionBegin("SetGeneralProp", this._model);
        }
    })
    .on("slide", function (e, ui) {
    	  if(this._model.type == "RECTAREA" || 
           this._model.type == "ROUNDAREA" || 
           this._model.type == "FREEAREA"){
          api.actionRun("set", "height3d", ui.value);
        }
    })
    .on("slidestop", function (e, ui) {
        delete this._model;
        api.actionEnd("SetGeneralProp");
    });

$(threed_rectarea3d_height3d_text).bind("keypress blur", function (event) {
     var _this = $(this);
    if(event.type=="blur"){
        //saveValue();
    }else{
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model;
        
        if(model.type == "RECTAREA" || 
           model.type == "ROUNDAREA" || 
           model.type == "FREEAREA"){
	        api.actionBegin("SetGeneralProp", model);
	        api.actionRun("set", "height3d", _this.val()/1000);
	        api.actionEnd("SetGeneralProp");
	      }

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val() / 1000));
        return false;
    }
});

/* 矩形区域 旋转 add by mdx */
$(threed_rectarea3d_angle_rotate_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "rot", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(threed_slider_rectarea3d_angle_rotate_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        var rot = parseFloat(_this.val());

        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "rot", rot);
        api.actionEnd("SetGeneralProp");

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()));
        return false;
    }

});

/* 圆形区域 离地 */
$(threed_roundarea3d_ground_slider)
    .on("slidestart", function (e, ui) {
        this._model = api.pickGetPicked()[0].model;
        if(this._model.type == "ROUNDAREA"){
          api.actionBegin("SetGeneralProp", this._model);
        }else{
        	api.actionBegin("SetGeneralProp", this._model.center);
        }
    })
    .on("slide", function (e, ui) {
    	  if(this._model.type == "ROUNDAREA"){
    	  	api.actionRun("set", "z", ui.value);
        }else{
        	api.actionRun("set", "y", ui.value + this._model.radius);
        }
    })
    .on("slidestop", function (e, ui) {
        delete this._model;
        api.actionEnd("SetGeneralProp");
    });

$(threed_roundarea3d_ground_text).bind("keypress blur", function (event) {
     var _this = $(this);
    if(event.type=="blur"){
        //saveValue();
    }else{
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model;
        if(model.type == "ROUNDAREA"){
        	api.actionBegin("SetGeneralProp", model);
	        api.actionRun("set", "z", parseFloat(_this.val() / 1000));
	        api.actionEnd("SetGeneralProp");
        }else{
	        api.actionBegin("SetGeneralProp", model.center);
	        api.actionRun("set", "y", parseFloat(_this.val() / 1000) + model.radius);
	        api.actionEnd("SetGeneralProp");
	      }

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val() / 1000));
        return false;
    }
});

/* 圆形区域 厚度 */
$(threed_roundarea3d_height3d_slider)
    .on("slidestart", function (e, ui) {
        this._model = api.pickGetPicked()[0].model;
        if(this._model.type == "ROUNDAREA"){
        	api.actionBegin("SetGeneralProp", this._model);
        }
    })
    .on("slide", function (e, ui) {
    	  if(this._model.type == "ROUNDAREA"){
          api.actionRun("set", "height3d", ui.value);
        }
    })
    .on("slidestop", function (e, ui) {
        delete this._model;
        api.actionEnd("SetGeneralProp");
    });
    
$(threed_roundarea3d_height3d_text).bind("keypress blur", function (event) {
     var _this = $(this);
    if(event.type=="blur"){
        //saveValue();
    }else{
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model;
        
        if(model.type == "ROUNDAREA"){
	        api.actionBegin("SetGeneralProp", model);
	        api.actionRun("set", "height3d", _this.val()/1000);
	        api.actionEnd("SetGeneralProp");
	      }

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val() / 1000));
        return false;
    }
});


/* 自由区域 离地 */
$(threed_freearea3d_ground_slider)
    .on("slidestart", function (e, ui) {
        this._model = api.pickGetPicked()[0].model;
        if(this._model.type == "FREEAREA"){
          api.actionBegin("SetGeneralProp", this._model);
        }
    })
    .on("slide", function (e, ui) {
    	  if(this._model.type == "FREEAREA"){
    	  	api.actionRun("set", "z", ui.value);
        }
    })
    .on("slidestop", function (e, ui) {
        delete this._model;
        api.actionEnd("SetGeneralProp");
    });

$(threed_freearea3d_ground_text).bind("keypress blur", function (event) {
     var _this = $(this);
    if(event.type=="blur"){
        //saveValue();
    }else{
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model;
        if(model.type == "FREEAREA"){
        	api.actionBegin("SetGeneralProp", model);
	        api.actionRun("set", "z", parseFloat(_this.val() / 1000));
	        api.actionEnd("SetGeneralProp");
        }
        
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val() / 1000));
        return false;
    }
});

/* 自由区域 厚度 */
$(threed_freearea3d_height3d_slider)
    .on("slidestart", function (e, ui) {
        this._model = api.pickGetPicked()[0].model;
        if(this._model.type == "FREEAREA"){
        	api.actionBegin("SetGeneralProp", this._model);
        }
    })
    .on("slide", function (e, ui) {
    	  if(this._model.type == "FREEAREA"){
          api.actionRun("set", "height3d", ui.value);
        }
    })
    .on("slidestop", function (e, ui) {
        delete this._model;
        api.actionEnd("SetGeneralProp");
    });
    
$(threed_freearea3d_height3d_text).bind("keypress blur", function (event) {
     var _this = $(this);
    if(event.type=="blur"){
        //saveValue();
    }else{
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model;
        
        if(model.type == "FREEAREA"){
	        api.actionBegin("SetGeneralProp", model);
	        api.actionRun("set", "height3d", _this.val()/1000);
	        api.actionEnd("SetGeneralProp");
	      }

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val() / 1000));
        return false;
    }
});
/***高级3d墙面区域铺贴***/
$("#advancedpaint").on(click, function () {
    var wall3d = api.pickGetPicked()[0];
    advancedPaintPrompt(wall3d);
    //advancedPaintExportPrompt(wall3d);
});

/***高级3d墙面区域铺贴***/
$("#area_advancedpaint").on(click, function () {
    var area = api.pickGetPicked()[0];
    if(!area)return;
    
    if(area.model.type == "RECTAREA" || 
       area.model.type == "ROUNDAREA" || 
       area.model.type == "FREEAREA"){
    	advancedPaintPrompt({model:area.model, opt:{src:"3d",elementName:area.opt.elementName}});    
    }else{
    	area.model.host && advancedPaintPrompt({model:area.model.host, opt:{src:"3d",elementName:area.model.category}});    
    }    
});

/*====================================墙3d[end]==========================================*/

/*====================================结构部件3d[start]==========================================*/
// 面隐藏
var CUBE_SIDE_META = {
    left: [4, "y", "z"],
    right: [8, "y", "z"],
    top: [16, "x", "y"],
    bottom: [32, "x", "y"],
    front: [64, "x", "z"],
    back: [128, "x", "z"]
};

// 面隐藏事件
$(".cube-face-hidden-checkbox").on("change", function () {
    var side = $(this).val();
    var shouldHidden = $(this).is(':checked');

    var cube = api.pickGetPicked()[0].model;
    var before = cube.faceHiddenFlag;

    var after = (shouldHidden ? before | CUBE_SIDE_META[side][0] : before & ~CUBE_SIDE_META[side][0]);

    api.actionBegin("SetGeneralProp", cube);
    api.actionRun("set", "faceHiddenFlag", after);
    api.actionEnd("SetGeneralProp");
});

function initContextMenuCube3d(type) {
    var cube = api.pickGetPicked()[0].model;
    Object.keys(CUBE_SIDE_META).forEach(function (side) {
        var mask = CUBE_SIDE_META[side][0];
        var isHidden = ((cube.faceHiddenFlag & mask) != 0);
        var name = "." + type + " .cube-face-hidden-checkbox[value='" + side + "']";
        $(name).prop("checked", (isHidden ? "checked" : false));
    });
}

//start add by gaoning -- 2017.3.27
/***高级地台区域铺贴***/
$("#button_area_advanced_pattern").on(click, function () {
    var basement = api.pickGetPicked()[0];
    //advancedPaintPrompt(basement);
    //advancedPaintPromptBasement(basement);
});
//end add by gaoning -- 2017.3.27
/*====================================结构部件3d[end]==========================================*/

/*波打线 start */
$("#contextmenu3d .boundary .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu3d .boundary .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/*波打线尺寸*/
$(threed_boundary_size_slider)
    .slider({min: 0.01, max: 2, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        
        var boundary = api.pickGetPicked()[0].model;
		    if(!api.actionBegin("SetBoundarySize", boundary, Number(ui.value))){
		    	  layer.alert('波打线尺寸超过空间大小', {title: '提示', skin: 'layui-layer-default'}, function (index) {
		            layer.close(index);
		        });
		    }
		    
		    $(twod_boundary_size_text).val(boundary.size);
    });
   
/*删除波打线*/
$(threed_boundary_delete_icon).on(click, function (e) {    
    var boundary = api.pickGetPicked()[0].model;
    api.actionBegin("DeleteBoundary", boundary);
    closeContextMenu();
});

$(threed_boundary_size_text).bind("keypress", function (event) {
    var _this = $(this);
    
    /*回车键*/
    if (event.keyCode == 13) {
        saveValue();
        _this.select();
    }

    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val())))
            return false;
        if (parseFloat(_this.val()) < 0.01)
            return false;

        var boundary = api.pickGetPicked()[0].model;
        if(!api.actionBegin("SetBoundarySize", boundary, parseFloat(_this.val()))){
        	  layer.alert('波打线尺寸超过空间大小', {title: '提示', skin: 'layui-layer-default'}, function (index) {
		            layer.close(index);
		        });
        }
        
        _this.parents(".attr_content").find(".slider_widget").slider("value", boundary.size);
        return false;
    }
});
//调整波打线砖缝偏移 开始
$(threed_boundary_bmove_slider)
    .on("slide", function (e, ui) {
        var boundary = api.pickGetPicked()[0].model;
        var pickedOpt = api.pickGetPicked()[0].opt;
        var pickedSide = pickedOpt.side.split("_");
        if(pickedSide[0] == "base"){
            $(".gap_attr_content").show();
            //只有base段提供砖缝偏移
            api.actionBegin("SetBoundaryGapOffsetX", boundary, parseInt(pickedSide[1]), Number(ui.value));
        }else{
            $(".gap_attr_content").hide();
        }
    });

$(threed_boundary_bmove_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        var boundary = api.pickGetPicked()[0].model;
        var pickedOpt = api.pickGetPicked()[0].opt;
        var pickedSide = pickedOpt.side.split("_");
        var baseMaterialLen = (boundary.baseMaterial.meta.xlen)/2*1000;
        var textVal = parseFloat(_this.val());
        if(textVal > baseMaterialLen){
            textVal = baseMaterialLen;
            _this.val(baseMaterialLen);
        }
        if(textVal < -baseMaterialLen){
            textVal = -baseMaterialLen;
            _this.val(-baseMaterialLen);
        }
        if (!positive_float.test(textVal)) return false;
        api.actionBegin("SetBoundaryGapOffsetX", boundary, parseInt(pickedSide[1]), textVal / 1000);
        $(threed_boundary_bmove_slider).slider({value:textVal/1000});
        return false;
    }
});
//调整波打线砖缝偏移 结束
/*波打线 end*/


//# sourceURL=ui/contextpopup/contextpopup_api_3d.js