//所有弹出框下的详情按钮
var global_info_icon = ".contextmenu  .popup .button_info";

//详情按钮单击事件
/*$(global_info_icon).on(click, function (e) {
    closeContextMenu();
    $("#contextmenuinfo").show();
    $("#contextmenuinfo").offset({top:0,left:0});
    $("#contextmenuinfo").width($(window).width()).height($(window).height());
    $("#contextmenuinfo .productinfo").fadeIn(2000);
 
    $("#product_content_wrapper canvas").remove();
    $("#product_content_wrapper ul li.rotation").addClass('active').siblings().removeClass("active");
    var meta = api.pickGetPicked()[0].model.meta,
        length = parseInt(meta.xlen * 1000),
        productId = meta.pid,
        zoom = 1000 / length,
        urlImg = api.catalogGetFileUrl("product", productId, "texture");
        loadObj(productId, urlImg, zoom);
});*/

//加载obj模型方法函数
function loadObj(productId, urlImg, zoom) {
    
    var enable = false,
        moveType = "rotate",
        _startMove = new THREE.Vector2(),
        _endMove = new THREE.Vector2(),
        _changeVar = new THREE.Vector2(),
        productObj;

    var clock = new THREE.Clock();

    var _width = $("#product_content_wrapper").width(),
        _height = $("#product_content_wrapper").height();

    var scene = new THREE.Scene();

    var camera = new THREE.PerspectiveCamera(45, _width / _height, 0.1, 1000);
    
    //antialias抗锯齿属性设置为true
    var renderer = new THREE.WebGLRenderer({antialias:true});
    
    renderer.setClearColor(0xCDCBCD, 1.0);
    renderer.setSize(_width * 1.2, _height * 1.2);
    renderer.shadowMapEnabled = true;

    camera.position.x = -0.0;
    camera.position.y = -4.0;
    camera.position.z = 2.33;
    camera.lookAt(new THREE.Vector3(0, 0, 0));

    var ambient = new THREE.AmbientLight( 0xffffff);
    scene.add(ambient);

    var bulbGeometry = new THREE.SphereGeometry( 0.02, 16, 8 );
    bulbLight = new THREE.PointLight( 0xffee88, 0.6, 100, 2 );

    bulbMat = new THREE.MeshStandardMaterial( {
        emissive: 0xffffee,
        emissiveIntensity: 1,
        color: 0x000000
    });
    bulbLight.add( new THREE.Mesh( bulbGeometry, bulbMat ) );
    bulbLight.position.set( 0, 0,  4);
    bulbLight.castShadow = true;
    scene.add( bulbLight );

    hemiLight = new THREE.HemisphereLight( 0xddeeff, 0x0f0e0d, 0.02 );
    scene.add( hemiLight );

    var texture = THREE.ImageUtils.loadTexture(urlImg);
    texture.needsUpdate = true;

    // model

    var loader = new THREE.OBJLoaderDetail();

     api.catalogGetFileContentPromise("product", productId, "obj")
        .then(function(content){
            productObj = loader.parse(content);
            productObj.traverse(function (child) {

            if (child instanceof THREE.Mesh) {

                child.material.map = texture;
                 child.material.roughnessMap =  texture;
					 child.material.needsUpdate = true;

            }});
        productObj.scale.set(zoom, zoom, zoom);
        productObj.receiveShadow = true;
        
        scene.add(productObj);

        });

    $("#product_content_wrapper").append(renderer.domElement);

    render();

    function render() {

        var delta = clock.getDelta();

        requestAnimationFrame(render);
        renderer.render(scene, camera);
    }
    
    function mousedown(event){
        event.preventDefault();
        event.stopPropagation();
        
        enable = true;
        _startMove.set(event.clientX, event.clientY);
        _endMove.copy(_startMove);
        
    }
    
    function mousemove(event){
        
        event.preventDefault();
        event.stopPropagation();
        
        var _target = event.target;
        
        
        if(enable){
            _startMove.set(event.clientX, event.clientY);
            _changeVar.set(_startMove.x - _endMove.x, _startMove.y - _endMove.y);
            _endMove.copy(_startMove);
            if(moveType == "move"){
                
               productObj.position.set(productObj.position.x + _changeVar.x/110,productObj.position.y ,productObj.position.z - _changeVar.y/105);
                
            }else{
               productObj.rotation.set(productObj.rotation.x + Math.sin(_changeVar.y/100),productObj.rotation.y ,productObj.rotation.z  + Math.sin(_changeVar.x/100)); 
            }
         
            
        }
        
    }
    
    function mouseup(event){
        event.preventDefault();
        event.stopPropagation();
        
        enable = false;
        
    }
    
     function mousewheel(event) {

        event.preventDefault();
        event.stopPropagation();

        var delta = 0;

        if (event.wheelDelta) { // WebKit / Opera / Explorer 9

            delta = event.wheelDelta / 40;

        } else if (event.detail) { // Firefox

            delta = -event.detail / 3;

        }
        
        zoom += delta * 0.01;
        productObj.scale.set(zoom, zoom, zoom);

    }
    
    function magnify(){
        zoom += 0.04;
        productObj.scale.set(zoom, zoom, zoom);
    }
    
    function shrink(){
        zoom -= 0.04;
        productObj.scale.set(zoom, zoom, zoom);
    }
    
    $("#product_content_wrapper ul li").off().on("click",function(event){
        
         event.preventDefault();
        event.stopPropagation();
        
        var _this = $(this);
        
        if(_this.hasClass("rotation")){
            
            moveType = "rotate";
             _this.addClass("active");
             _this.siblings().removeClass("active");
            
        }else if(_this.hasClass("move")){
            
            moveType = "move";
            _this.addClass("active");
             _this.siblings().removeClass("active");
            
        }else if(_this.hasClass("magnify")){
            magnify();
        }else if(_this.hasClass("shrink")){
            shrink();
        }
        
    });
    
    $("#product_content_wrapper .mask").off('click').on('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
    });
    
    $("#contextmenuinfo,#contextmenuinfo .close").off().on("click",function(){
        $("#contextmenuinfo").slideUp("slow");
    });
    
    $("#product_content_wrapper .mask").off('contextmenu').on('contextmenu', function (event) {
        event.preventDefault();
    });

    $("#product_content_wrapper .mask").off('mousedown').on('mousedown', mousedown);
    $("#product_content_wrapper .mask").off('mousemove').on('mousemove', mousemove);
    $(document).off("mouseup").on('mouseup', mouseup);
    ($("#product_content_wrapper .mask")[0]).removeEventListener('mousewheel', mousewheel,false);
    ($("#product_content_wrapper .mask")[0]).addEventListener('mousewheel', mousewheel,false);
    $("#product_content_wrapper .mask").off('DOMMouseScroll').on('DOMMouseScroll', mousewheel); // firefox

}