/*
 * 下拉框图片控件
 */
(function ($) {
    function ImageSelectorOpenFilter(onSuccess, onFail) {
        if (api.floorplanIsLocked() == false) {
            // need to lock first:
            var picked = api.pickGetPicked(), pickType = "default";
            if (picked && picked.length > 0) {
                pickType = picked[0].model.type.toLowerCase();
            }
            if ("pillar" == pickType || "basement" == pickType || "beam" == pickType || "wall" == pickType) {
                if (onSuccess)onSuccess();
                return;
            }

            layer.confirm('更换瓷砖类商品需要首先锁定户型。<br>是否需要锁定户型？', {
                btn: ['确定', '取消'], //按钮
                shade: 0.3, //不显示遮罩
                skin: 'layui-layer-default',
                title: '提示'
            }, function (index) {//layer.msg('确定', {icon: 1});
                layer.close(index);
                $("#toolLockFloorplan").trigger("click");

                if (onSuccess)onSuccess();
            }, function () {//layer.msg('取消', {shift: 6});
                if (onFail)onFail();
            });
        } else {
            if (onSuccess)onSuccess();
        }
    }

    var methods = {
        init: function (options) {
            if (!/select/i.test(this.tagName)) return false;
            var element = $(this);
            var selectName = element.attr('name');
            var jq_imageselect_id = 'jq_imageselect_' + selectName;
            var jqis_header_id = 'jqis_header_' + selectName;
            var jqis_header_img_id = 'jqis_header_img_' + selectName;
            var jqis_dropdown_id = 'jqis_dropdown_' + selectName;

            if ($('#' + jq_imageselect_id).length > 0) return;

            var imageSelect = $('<div>')
                .attr('id', jq_imageselect_id)
                .addClass('jqis')
                .css('width', options.width + 'px')
                .css('height', options.height + 'px');

            var header = $('<div>').addClass('jqis_header');
            header.css('width', (options.width + 20) + 'px')
                .css('height', options.height + 'px')
                .css('text-align', 'left')
                .css('background-color', options.backgroundColor)
                .css('border', '1px solid ' + options.borderColor)
                .attr("id", jqis_header_id)
                .append($("<img>").attr("id", jqis_header_img_id).css({
                    height: options.height + 'px',
                    width: options.width + 'px'
                }))
                .click(function (e) {
                    ImageSelectorOpenFilter(function () {
                        $('select[name=' + selectName + ']').ImageSelect('open', options);
                    });
                })
                .appendTo(imageSelect);

            var dropdown = $('<div>').addClass('jqis_dropdown');
            dropdown.css('width', options.dropdownWidth + 'px')
                .css('z-index', options.z)
                .css('top', 0)
                .css('left', options.positionLeft)
                .css('background-color', options.backgroundColor)
                .css('border', '1px solid ' + options.borderColor)
                .css('max-height', options.dropdownHeight + 'px')
                .attr("id", jqis_dropdown_id)
                .hide()
                .draggable({cursor: 'move'})
                .appendTo(imageSelect);

            var $options = $('option', element);
            var map = new Map();
            $options.each(function (index, el) {
                var _obj = JSON.parse($(el).val());
                if (options.widget == 'img') {
                    $("<img>").attr({"src": $(el).text(), "title": _obj.title})
                        .css({"width": options.width, "height": options.height})
                        .click(function (e) {
                            options.src = $(el).text();
                            $("select[name='" + selectName + "']").val(_obj.pid)
                                .ImageSelect("close")
                                .ImageSelect("update", options);
                            if (options.additionalImgClick) options.additionalImgClick(_obj);
                        }).appendTo(dropdown);
                } else if (options.widget == 'div') {
                    /* if ( index == 0  ){
                     $("<div>").html("1111")
                     .css({"width": options.dropdownWidth - 20 , "height": 25})
                     .appendTo(dropdown);
                     }*/
                    //map.put(_obj.roomtype,"") ;

                    $("<div>").html($(el).text())
                        .attr({"title": "类型:" + _obj.roomtype + "  名称:" + _obj.name})
                        .css({"width": options.width, "height": options.height})
                        .click(function (e) {
                            if (options.additionalImgClick) options.additionalImgClick(_obj);
                        }).appendTo(dropdown);
                    //console.log(index) ;
                }


            });

            /*select框的后面加入图片选择器*/
            element.after(imageSelect).hide();

            /*控件之后点击隐藏下拉框内容*/
            $(document).on("click", "body", function (e) {
                if (e.target.id == jqis_header_id
                    || e.target.id == jqis_dropdown_id
                    || e.target.id == jqis_header_img_id
                ) {
                } else {
                    $("#" + jqis_dropdown_id).hide();
                }
            });

            /* 设置默认值 */
            /* var selectedImage = $('option:selected',element).text();
             options.src= selectedImage ;
             element.ImageSelect('update',options);*/
        },

        update: function (options) {
            var element = $(this);
            var selectName = element.attr('name');
            var id = 'jq_imageselect_' + selectName;
            var jqis_header_obj = '#' + id + ' .jqis_header';
            var jqis_header_img_obj = '#' + id + ' .jqis_header img';

            if ($(jqis_header_obj).length == 1) {
                $(jqis_header_img_obj).attr('src', options.src).css('opacity', 0.1);
                $(jqis_header_img_obj).unbind('load');
                $(jqis_header_img_obj).one('load', function () {
                    $(this).parent().stop();
                    $(this).parent().parent().stop();
                    $(this).parent().animate({width: options.width + 20});
                    $(this).parent().parent().animate({width: options.width});

                }).each(function () {
                    if (this.complete) $(this).load();
                });
                $(jqis_header_img_obj).animate({opacity: 1});
            }

        },
        open: function () {
            var element = $(this);
            var selectName = element.attr('name');
            var id = 'jq_imageselect_' + selectName;
            var jq_imageselect_obj = $('#' + id);
            var jqis_dropdown_obj = $('#' + id + ' .jqis_dropdown');

            if (jq_imageselect_obj.length == 1) {
                if (jqis_dropdown_obj.is(':visible')) {
                    jqis_dropdown_obj.stop();
                    jqis_dropdown_obj.slideUp().fadeOut();
                } else {
                    jqis_dropdown_obj.stop();
                    jqis_dropdown_obj.show();
                }
            }
        },
        close: function () {
            var element = $(this);
            var selectName = element.attr('name');
            var id = 'jq_imageselect_' + selectName;
            if ($('#' + id).length == 1) {
                $('#' + id + ' .jqis_dropdown').slideUp().hide();
            }
        },
        remove: function () {
            if (!/select/i.test(this.tagName)) {
                return false;
            }
            var element = $(this);
            var selectName = element.attr('name');
            var id = 'jq_imageselect_' + selectName;
            if ($('#' + id).length > 0) {
                $('#' + id).remove();
                $('select[name=' + selectName + ']').show();
                return;
            }
        }
    };

    $.fn.ImageSelect = function (method, options) {
        if (method == undefined) method = 'init';
        var settings = {
            width: 200,
            height: 75,
            widget: 'img',
            dropdownHeight: 250,
            dropdownWidth: 200,
            z: 99999,
            positionLeft: 0,
            backgroundColor: '#ffffff',
            border: true,
            borderColor: '#cccccc'
        };

        if (options) $.extend(true, settings, options);
        if (typeof method === 'object') $.extend(settings, method);

        return this.each(function () {
            if (methods[method]) {
                return methods[method].apply(this, Array(settings));
            } else if (typeof method === 'object' || !method) {
                return methods.init.apply(this, Array(settings));
            } else {
                $.error('Method ' + method + ' does not exist on jQuery.ImageSelect');
            }
        });
    };
})(jQuery);
//# sourceURL=ui/contextpopup/imageselect.js
