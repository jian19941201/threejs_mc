/*鼠标悬浮提示ui样式*/
$(".contextmenu").tooltip();

/*右键菜单窗口可拖动*/
$('.contextmenu .tab_head').draggable({"helper": null, "opacity": 0.3})
    .on("drag", function (event, ui) {
        $('.contextmenu').offset(ui.offset);
    });

/*渲染参数*/
function renderReflection_keyPress(field, event) {
    var current = $(event.target);
    /*回车键*/
    if (event.keyCode == 13) {
        /*浮点数*/
        var val = parseFloat(current.val());
        val = Math.max(0.0, Math.min(1.0, val));
        var mat = pickedMaterial();
        if (mat) {
            mat[field] = val;
        }
        current.val(val).select();
    }
}
$(reflection_input).bind("keypress", renderReflection_keyPress.bind(undefined, "reflection"));
$(reflection_glossiness_input).bind("keypress", renderReflection_keyPress.bind(undefined, "reflection_glossiness"));

/*
 获取选中对象的材质名称
 * 如：leftMaterial
 *    floorMaterial
 * */
function pickedMaterialName() {
    var picked = api.pickGetPicked()[0];
    if (!picked)return undefined;
    var model = picked.model;
    if (model.type == "FLOOR" ||
        model.type == "RECTAREA" || model.type == "ROUNDAREA" || model.type == "FREEAREA" ||
        model.type == "WALLBOARD" || model.type == "BASEBOARD") {
        //解决天花不能移动的Bug add by gaoning 2017.4.27
        var opt = picked.opt;        
        if (opt){
        	if(opt.src == "3d" && opt.elementName){
            return opt.elementName + "Material";
          }else if(opt.src == "2d" && opt.side){
          	return opt.side + "Material";
          }
        }
        return "floorMaterial";  //  "ceilingMaterial";
    } else if (model.type.toLowerCase().indexOf("area") != -1) {
        return "areaMaterial";
    } else if (model.type == "PRODUCTREPLACEMENT") {
        var opt = picked.opt;
        return opt.elementName + "Material";
    } else if (model.type == "GROUP") {
        return "none" + "Material";
    } else if (model.type == "BOUNDARY") {
    	  if(picked.opt.src == "3d"){
    	  	 if(picked.opt.elementName.indexOf("base") != -1){
    	  	 	 return "baseMaterial";  
    	  	 }else if(picked.opt.elementName.indexOf("corner") != -1){
    	  	 	 return "cornerMaterial";  
    	  	 }else if(picked.opt.elementName.indexOf("left") != -1){
    	  	 	 return "leftMaterial";  
    	  	 }else if(picked.opt.elementName.indexOf("right") != -1){
    	  	 	 return "rightMaterial";  
    	  	 }    	  	          
    	  }else if(picked.opt.src == "2d"){
    	  	 var sideIndex = picked.opt.side.split("_");
           return sideIndex[0] + "Material";// + sideIndex[1] + "Material";
    	  }    	  
    } else {
        var opt = picked.opt;
        return opt.elementName + "Material";
    }
}

/*获取选中对象的材质对象*/
function pickedMaterial() {

    //console.log("获取选中对象的材质对象");

    var picked = api.pickGetPicked()[0];
    if (!picked)
        return undefined;
    var model = picked.model;
    if (!model)
        return undefined;
    var matName = pickedMaterialName();
    var materialobj = model[matName];

    //console.log(materialobj);

    if (!materialobj)
        return undefined;
    if (!materialobj.meta)
        return undefined;
    /*默认填充色，作为没有添加材质*/
    if (materialobj.meta.pid == 'lightyellow')
        return undefined;
    return materialobj;
}

function materialSliderCommand(paramobj) {
    var $sliderobj = paramobj.sliderobj;
    var action = paramobj.action;
    $sliderobj.on("slidestart", function (e, ui) {
        switch (action) {
            case "rotate":
                api.actionBegin("RotMat", pickedMaterial());
                break;
            case "hmove":
            case "vmove":
                api.actionBegin("MoveMat", pickedMaterial());
                break;
            case "heightzoom":
            case "widthzoom":
                api.actionBegin("SetGeneralProp", pickedMaterial());
                break;

        }
    })
        .on("slide", function (e, ui) {
            switch (action) {
                case "rotate":
                    api.actionRun("rot", "", ui.value);
                    break;
                case "hmove":
                    api.actionRun("move", "x", "delta", ui.value);
                    break;
                case "vmove":
                    api.actionRun("move", "y", "delta", ui.value);
                    break;
                case "heightzoom":
                    api.actionRun("set", "sy", parseFloat(ui.value) / pickedMaterial().meta.ylen);
                    break;
                case "widthzoom":
                    api.actionRun("set", "sx", parseFloat(ui.value) / pickedMaterial().meta.xlen);
                    break;
            }
        })
        .on("slidestop", function (e, ui) {
            switch (action) {
                case "rotate":
                    api.actionEnd("RotMat");
                    break;
                case "hmove":
                case "vmove":
                    api.actionEnd("MoveMat");
                    break;
                case "heightzoom":
                case "widthzoom":
                    api.actionEnd("SetGeneralProp");
                    break;
            }
        });
}


function materialTextCommand(paramobj, event) {
    var current = $(event.target);
    var action = paramobj.action;
    var validate = paramobj.validate;
    var cascade = paramobj.cascade;
    if (event.keyCode == 13) {
        switch (validate) {
            case "plusint":
                var positive_int = /^\d+$/;
                if (!positive_int.test(current.val())) return false;
                break;

            case "float":
                var positive_float = /^(-?\d+)(\.\d+)?$/;
                if (!positive_float.test(parseFloat(current.val()))) return false;
                break;
            case "plusfloat":
                var positive_float = /^(-?\d+)(\.\d+)?$/;
                if (!positive_float.test(parseFloat(current.val()))) return false;
                if (parseFloat(current.val()) < 0) return false;
                break;
        }

        switch (action) {
            case "rotate":
                api.actionBegin("SetGeneralProp", pickedMaterial());
                api.actionRun("set", "rot", current.val());
                api.actionEnd("SetGeneralProp");
                break;

            case "hmove":
                api.actionBegin("SetGeneralProp", pickedMaterial());
                api.actionRun("set", "tx", parseFloat(current.val()));
                api.actionEnd("SetGeneralProp");
                break;
            case "vmove":
                api.actionBegin("SetGeneralProp", pickedMaterial());
                api.actionRun("set", "ty", parseFloat(current.val()));
                api.actionEnd("SetGeneralProp");
                break;
            case "heightzoom":
                api.actionBegin("SetGeneralProp", pickedMaterial());
                api.actionRun("set", "sy", parseFloat(current.val()) / pickedMaterial().meta.ylen);
                api.actionEnd("SetGeneralProp");
                break;
            case "widthzoom":
                api.actionBegin("SetGeneralProp", pickedMaterial());
                api.actionRun("set", "sx", parseFloat(current.val()) / pickedMaterial().meta.xlen);
                api.actionEnd("SetGeneralProp");
                break;
        }
        current.select();
        if (cascade)current.parents(".attr_content").find(".slider_widget").slider("value", current.val());
        return false;
    }
}


//# sourceURL=ui/contextpopup/contextpopup_common.js