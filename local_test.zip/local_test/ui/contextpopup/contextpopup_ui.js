/*====================================文字标注[start]==========================================*/
/*加载颜色选择控件*/
$(twod_annotation_content_color).spectrum({
    theme: "sp-light",
    color: "#000000", /*默认值*/
    preferredFormat: "hex",
    showInput: true,
    showPalette: false,
    cancelText: "取消",
    chooseText: "选择"
});


/*文字标注 复制 */
$(twod_annotation_copy_icon).on("click", function (e) {
    closeContextMenu();
});

/*文字标注 删除 */
$(twod_annotation_delete_icon).on("click", function (e) {
    closeContextMenu();
});
/*====================================文字标注[end]==========================================*/

/*====================================2d 摄像机[start]==========================================*/
/**右键菜单tab页切换*/
$(".contextmenu .camera .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $(".contextmenu .default .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});
/*摄像机高度*/
$(twod_camera_height_slider)
    .slider({min: 0.2, max: 8, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        $(twod_camera_height_text).val(ui.value * 1000);
    });

/*摄像机视角*/
$(twod_camera_visualangle_slider)
    .slider({min: 30, max: 150, step: 5})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        $(twod_camera_visualangle_text).val(ui.value);
    });

/*====================================2d 摄像机[end]==========================================*/


/*====================================2d 组合[start]==========================================*/
/*组合 旋转*/
$(twod_group_rotateangle_slider)
    .slider({min: 0, max: 360, step: 5})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        $(twod_group_rotateangle_text).val(ui.value);
    });
/*====================================2d 组合[end]==========================================*/



/*====================================地板[start]==========================================*/
/*地板*右键菜单tab页切换*/
$(".contextmenu .floor .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $(".contextmenu .floor .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/*房间高度*/
$(twod_room_height_slider)
    .slider({min: 2.5, max: 8, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        $(twod_room_height_text).val(ui.value);
    });


$(twod_room_name_select_li).each(function () {
    $(this).on(click, function (e) {
        $(twod_room_name_text).val($(this).text());
        $(twod_room_name_select).css("display", "none");
    });
});

$(twod_room_name_text)
    .on("mouseup", function (e) {
        $(this).parents(".room_content").css("height","auto");
        $(this).siblings(".room-name-select").css("display", "inline-block");
    });

/*打开房间套用页面*/
$(twod_room_apply_button).on(click, function (e) {
    if (typeof openModelRoomPanelPrompt == "function"){ openModelRoomPanelPrompt();}
    else{ $("#tab_panelModelRoomId").trigger(click);}

    closeContextMenu();
});

$(twod_room_save_as_modelroom_button).on(click, function (e) {
    if (typeof saveCloudDesignPanelPromptExternal == "function")saveCloudDesignPanelPromptExternal("modelroom");
    closeContextMenu();
});

$(".contextmenu .floor .popup .save-model-room-old-button").on(click, function (e) {
    if (typeof saveCloudDesignPanelPrompt == "function")saveCloudDesignPanelPrompt("modelroom");
    closeContextMenu();
});
$(".contextmenu .floor .popup .reset-empty-room-button").on(click, function (e) {
    //if (typeof saveCloudDesignPanelPrompt == "function")saveCloudDesignPanelPrompt("modelroom");
    layer.alert("确实要恢复成毛坯房吗？这将清空房间内所有的家具和地面墙面布置。",{title: '提示', skin: 'layui-layer-default'}, function (index) {
        layer.close(index);
        var picked = api.pickGetPicked()[0];
        var room = picked && picked.model;
        if (!room || room.type != "FLOOR")return;
        room.reset({
            product_remove_old: true,
            floorarea: true,
            floorMaterial: true, //清空房间里不清除地砖
            wallarea: true,
            wallMaterial: true,
            product_other_model_delete: true
        });
        closeContextMenu();
    });

});

/*波打线 与墙距离*/
$(twod_floor_boundary_slider)
    .slider({min: 0.08, max: 0.2, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        $(twod_floor_boundary_text).val(ui.value);
    });
/*====================================地板[end]==========================================*/


/*====================================区域[start]==========================================*/
/*区域*右键菜单tab页切换*/
$(".contextmenu .area .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $(".contextmenu .area .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/*拼花旋转*/
$(global_material_rot_slider)
    .slider({min: 0, max: 360, step: 15})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        $(global_material_rot_text).val(ui.value);
    });

/*拼花水平移动*/
$(global_material_hmove_slider)
    .slider({min: -0.5, max: 0.5, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var unit_value = $(global_material_hmove_text).val() / 1000;
        var cumulation_value = parseFloat(unit_value) + ui.value;
        $(global_material_hmove_text).val(Math.ceil(cumulation_value * 100) * 10);
        $(this).slider({value: 0});
    });

/*拼花竖直移动*/
$(global_material_vmove_slider)
    .slider({min: -0.5, max: 0.5, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var unit_value = $(global_material_vmove_text).val() / 1000;
        var cumulation_value = parseFloat(unit_value) + ui.value;
        $(global_material_vmove_text).val(Math.ceil(cumulation_value * 100) * 10);
        $(this).slider({value: 0});
    });

/*拼花高度缩放*/
$(global_material_zoom_height_slider)
    .slider({min: 0, max: 10, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        $(global_material_zoom_height_text).val(ui.value * 1000);
    });

/*拼花宽度缩放*/
$(global_material_zoom_width_slider)
    .slider({min: 0, max: 10, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        $(global_material_zoom_width_text).val(ui.value * 1000);
    });

/*拼花半径缩放*/
$(global_material_zoom_radius_slider)
    .slider({min: 0, max: 10, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        $(global_material_zoom_radius_text).val(ui.value * 1000);
    });


/*拼花重新设置*/
$(global_material_reset_button).on(click, function (e) {
    $(global_material_rot_slider).slider({value: 0});
    $(global_material_rot_text).val(0);
    $(global_material_hmove_slider).slider({value: 0});
    $(global_material_hmove_text).val(0);
    $(global_material_vmove_slider).slider({value: 0});
    $(global_material_vmove_text).val(0);
});

/*矩形区域 角度  */
$(twod_rectarea_angle_slider)
    .slider({min: 0, max: 360, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: ""})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(twod_rectarea_angle_text).val(Math.ceil(cumulation_value * 100) / 100);
    });


/*矩形区域 高度  */
$(global_rectarea_height_slider)
    .slider({min: 0.4, max: 5, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_rectarea_height_text).val(Math.ceil(cumulation_value * 100) * 10);
    });
/* 矩形区域 宽度 */
$(global_rectarea_width_slider)
    .slider({min: 0.4, max: 5, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_rectarea_width_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/*2d和3d下select 固定 同步*/
$(global_rectarea_height_align_select).on("change", function () {
    $(global_rectarea_height_align_select).val($(this).val());
});
/*2d和3d下select 固定 同步*/
$(global_rectarea_width_align_select).on("change", function () {
    $(global_rectarea_width_align_select).val($(this).val());
});

/* 圆形区域 半径 */
$(global_roundarea_radius_slider)
    .slider({min: 0.4, max: 5, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_roundarea_radius_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/*====================================区域[end]==========================================*/

/*=================================== 结构部件[start]==========================================*/
/* 柱子 地台 横梁 长度 */
$(global_structure_length_slider)
    .slider({min: 0.04, max: 10, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_structure_length_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/* 柱子 地台 横梁 宽度 */
$(global_structure_width_slider)
    .slider({min: 0.04, max: 10, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_structure_width_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/* 柱子 地台 横梁 高度 */
$(global_structure_height_slider)
    .slider({min: 0.04, max: 10, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_structure_height_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/* 柱子 地台 横梁 离地 */
$(global_structure_ground_slider)
    .slider({min: 0, max: 5, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_structure_ground_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/*地台旋转 add by gaoning 2017.4.25*/
$(global_structure_ground_rotate_slider)
    .slider({min: 0, max: 360, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_structure_ground_rotate_text).val(Math.ceil(cumulation_value));
    });

/* 柱子 地台 横梁 删除 */
$(global_structure_delete_icon).on("click", function (e) {
    closeContextMenu();
});
/*柱子 地台 横梁 隐藏 --add by zk*/
$(global_structure_hide_icon).on(click, function (event) {
    var structureobj = api.pickGetPicked()[0].model;
    var offset = $("#viewShowHideGoodsId").offset();
    var imgsrc = api.catalogGetFileUrl("product", structureobj.pid, "iso");
    var flyer = $('<img style="width:41px;height:41px;" class="u-flyer" src="' + imgsrc + '">');
    flyer.fly({
        start: {
            left: event.pageX,
            top: event.pageY
        },
        end: {
            left: offset.left + 10,
            top: offset.top + 10,
            width: 0,
            height: 0
        },
        onEnd: function () {
            //this.destory();
        }
    });
    closeContextMenu();
});
/*====================================结构部件[end]==========================================*/


/*====================================墙[start]==========================================*/
/*墙*右键菜单tab页切换*/
$("#contextmenu2d .wall .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu2d .wall .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/*墙厚*/
$(twod_wall_thickness_slider)
    .slider({min: 0.1, max: 1, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(twod_wall_thickness_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

$(twod_wall_transparent_slider)
    .slider({min: 0, max: 1, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: ""})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(twod_wall_transparent_text).val(cumulation_value);
    });
/*墙高*/
$(twod_wall_height_slider)
    .slider({min: 2.5, max: 5, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        //console.log("移动结束");
        var cumulation_value = parseFloat(ui.value);
        $(twod_wall_height_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/*墙重新设置*/
$(twod_wall_reset_button).on(click, function (e) {
    $(twod_wall_height_slider).slider({value: 0});
    $(twod_wall_height_text).val(0);
    $(twod_wall_thickness_slider).slider({value: 0});
    $(twod_wall_transparent_slider).slider({value: 0});
    $(twod_wall_thickness_text).val(0);
    $(twod_wall_transparent_text).val(0);
});


/* 墙隐藏 */
$(twod_wall_hide_icon).on("click", function (e) {
    $(this).hide().siblings(".button_show").show();
});

/* 墙显示 */
$(twod_wall_show_icon).on("click", function (e) {
    $(this).hide().siblings(".button_hide").show();
});

/* 墙删除 */
$(twod_wall_delete_icon).on("click", function (e) {
    closeContextMenu();
});
/*====================================墙[end]==========================================*/

/*====================================墙3d[begin]==========================================*/
/*墙*右键菜单tab页切换*/
$("#contextmenu3d .wall .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu3d .wall .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});


/*区域*右键菜单tab页切换*/
$("#contextmenu3d .area .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu3d .area .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/* 矩形区域 离地 */
$(threed_rectarea3d_ground_slider)
    .slider({min: 0, max: 8, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(threed_rectarea3d_ground_text).val(Math.ceil(cumulation_value * 100) * 10);
    });
    
/* 矩形区域 厚度 */
$(threed_rectarea3d_height3d_slider)
    .slider({min: -10, max: 10, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(threed_rectarea3d_height3d_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/* 3d矩形区域 旋转*/
$(threed_rectarea3d_angle_rotate_slider)
    .slider({min: 0, max: 360, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: ""})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(threed_slider_rectarea3d_angle_rotate_text).val(Math.ceil(cumulation_value * 100) / 100);
    });

/* 圆形区域 离地 */
$(threed_roundarea3d_ground_slider)
    .slider({min: 0, max: 8, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(threed_roundarea3d_ground_text).val(Math.ceil(cumulation_value * 100) * 10);
    });
    
/* 圆形区域 厚度 */
$(threed_roundarea3d_height3d_slider)
    .slider({min: -10, max: 10, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(threed_roundarea3d_height3d_text).val(Math.ceil(cumulation_value * 100) * 10);
    });
    
/* 自由区域 离地 */
$(threed_freearea3d_ground_slider)
    .slider({min: 0, max: 8, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(threed_freearea3d_ground_text).val(Math.ceil(cumulation_value * 100) * 10);
    });
    
/* 自由区域 厚度 */
$(threed_freearea3d_height3d_slider)
    .slider({min: -10, max: 10, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(threed_freearea3d_height3d_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/***高级3d墙面区域铺贴***/
$("#advancedpaint").on(click, function () {
    closeContextMenu();
});

/*详细信息*/
$(threed_wall_details_tab).html("3d墙信息");

/*====================================墙3d[end]==========================================*/

/*====================================结构部件3d[begin]==========================================*/
/*右键菜单tab页切换*/
$("#contextmenu3d .pillar .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu3d .pillar .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

$("#contextmenu3d .basement .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu3d .basement .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

$("#contextmenu3d .beam .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu3d .beam .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

//start add by gaoning 2017.3.28
/***高级地台区域铺贴***/
$("#button_area_advanced_pattern").on(click, function () {
    closeContextMenu();
});
//end add by gaoning 2017.3.28

/*====================================结构部件3d[end]==========================================*/

/*====================================家具[start]==========================================*/
/*右键菜单tab页切换*/
$("#contextmenu2d .product .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu2d .product .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

$("#contextmenu3d .product .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#contextmenu3d .product .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/*长度*/
$(global_product_length_slider)
    .slider({min: 0, max: 200, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "%"})
    .on("slide", function (e, ui) {
        if ($(global_product_zoom_checkbox).is(":checked")) {
            var model = api.pickGetPicked()[0].model, meta = model.meta;
            //灯光尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
            if(meta.subcategory=='ies'||meta.subcategory=='filllight'){
                if(ui.value<5) return false;
            }
            $(global_product_width_slider).slider({value: ui.value});
            $(global_product_height_slider).slider({value: ui.value});
        }
    })
    .on("slidestop", function (e, ui) {
        var meta = api.pickGetPicked()[0].model.meta;
        var cumulation_value = parseFloat(ui.value / 100 * meta.xlen);
        $(global_product_length_text).val(Math.ceil(cumulation_value * 100) * 10);

        if ($(global_product_zoom_checkbox).is(":checked")) {
            cumulation_value = parseFloat(ui.value / 100 * meta.ylen);
            $(global_product_width_text).val(Math.ceil(cumulation_value * 100) * 10);

            cumulation_value = parseFloat(ui.value / 100 * meta.zlen);
            $(global_product_height_text).val(Math.ceil(cumulation_value * 100) * 10);
        }
    });

/*宽度*/
$(global_product_width_slider)
    .slider({min: 0, max: 200, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "%"})
    .on("slide", function (e, ui) {
        if ($(global_product_zoom_checkbox).is(":checked")) {
            var model = api.pickGetPicked()[0].model, meta = model.meta;
            //灯光尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
            if(meta.subcategory=='ies'||meta.subcategory=='filllight'){
                if(ui.value<5) return false;
            }
            $(global_product_length_slider).slider({value: ui.value});
            $(global_product_height_slider).slider({value: ui.value});
        }
    })
    .on("slidestop", function (e, ui) {
        var meta = api.pickGetPicked()[0].model.meta;
        var cumulation_value = parseFloat(ui.value / 100 * meta.ylen);
        $(global_product_width_text).val(Math.ceil(cumulation_value * 100) * 10);

        if ($(global_product_zoom_checkbox).is(":checked")) {
            cumulation_value = parseFloat(ui.value / 100 * meta.xlen);
            $(global_product_length_text).val(Math.ceil(cumulation_value * 100) * 10);

            cumulation_value = parseFloat(ui.value / 100 * meta.zlen);
            $(global_product_height_text).val(Math.ceil(cumulation_value * 100) * 10);
        }
    });

/*高度*/
$(global_product_height_slider)
    .slider({min: 0, max: 200, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "%"})
    .on("slide", function (e, ui) {
        if ($(global_product_zoom_checkbox).is(":checked")) {
            var model = api.pickGetPicked()[0].model, meta = model.meta;
            //灯光尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
            if(meta.subcategory=='ies'||meta.subcategory=='filllight'){
                if(ui.value<5) return false;
            }
            $(global_product_length_slider).slider({value: ui.value});
            $(global_product_width_slider).slider({value: ui.value});
        }
    })
    .on("slidestop", function (e, ui) {
        var meta = api.pickGetPicked()[0].model.meta;
        var cumulation_value = parseFloat(ui.value / 100 * meta.zlen);
        $(global_product_height_text).val(Math.ceil(cumulation_value * 100) * 10);

        if ($(global_product_zoom_checkbox).is(":checked")) {
            cumulation_value = parseFloat(ui.value / 100 * meta.xlen);
            $(global_product_length_text).val(Math.ceil(cumulation_value * 100) * 10);

            cumulation_value = parseFloat(ui.value / 100 * meta.ylen);
            $(global_product_width_text).val(Math.ceil(cumulation_value * 100) * 10);
        }
    });

/*离地*/
$(global_product_ground_slider)
    .slider({min: 0, max: 2.8, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_product_ground_text).val(Math.ceil(cumulation_value * 100) * 10);
    });

/*产品旋转 add by gaoning 2017.4.24*/
$(global_product_rotate_slider)
    .slider({min: 0, max: 360, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_product_rotate_text).val(Math.ceil(cumulation_value));
    });
/*产品X旋转 add by gaoning 2017.4.27*/
$(global_product_x_rotate_slider)
    .slider({min: -90, max: 90, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_product_x_rotate_text).val(Math.ceil(cumulation_value));
    });
/*产品Y旋转 add by gaoning 2017.4.29*/
$(global_product_y_rotate_slider)
    .slider({min: -90, max: 90, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        var cumulation_value = parseFloat(ui.value);
        $(global_product_y_rotate_text).val(Math.ceil(cumulation_value));
    });

/*复制*/
$(global_product_copy_icon).on(click, function (e) {
    closeContextMenu();
});

/*删除*/
$(global_product_delete_icon).on(click, function (e) {
    closeContextMenu();
});

/*隐藏*/
$(global_product_hide_icon).on(click, function (event) {
    var productobj = api.pickGetPicked()[0].model;
    var offset = $("#viewShowHideGoodsId").offset();
    var imgsrc = api.catalogGetFileUrl("product", productobj.pid, "iso");
    var flyer = $('<img style="width:41px;height:41px;" class="u-flyer" src="' + imgsrc + '">');
    flyer.fly({
        start: {
            left: event.pageX,
            top: event.pageY
        },
        end: {
            left: offset.left + 10,
            top: offset.top + 10,
            width: 0,
            height: 0
        },
        onEnd: function () {
            //this.destory();
        }
    });
    closeContextMenu();
});

/*重新设置*/
$(global_product_reset_button).on(click, function (e) {
    var meta = api.pickGetPicked()[0].model.meta;
    $(global_product_length_slider).slider({value: 100});
    $(global_product_length_text).val(parseFloat(meta.xlen).toFixed(2) * 1000);
    $(global_product_width_slider).slider({value: 100});
    $(global_product_width_text).val(parseFloat(meta.ylen).toFixed(2) * 1000);
    $(global_product_height_slider).slider({value: 100});
    $(global_product_height_text).val(parseFloat(meta.zlen).toFixed(2) * 1000);
    $(global_product_ground_slider).slider({value: 0});
    $(global_product_ground_text).val(0);

    //产品 add by gaoning 2017.4.24
    $(global_product_rotate_slider).slider({value: 0});
    $(global_product_rotate_text).val(0);

    //产品X add by gaoning 2017.4.27
    $(global_product_x_rotate_slider).slider({value: 0});
    $(global_product_x_rotate_text).val(0);

    //产品Y add by gaoning 2017.4.29
    $(global_product_y_rotate_slider).slider({value: 0});
    $(global_product_y_rotate_text).val(0);
});


/*等比缩放*/
$(global_product_zoom_checkbox).on(click, function (e) {
    if ($(this).is(":checked")) {
        var meta = api.pickGetPicked()[0].model.meta;
        $(global_product_length_slider).slider({value: 100});
        $(global_product_length_text).val(parseFloat(meta.xlen).toFixed(2) * 1000);
        $(global_product_width_slider).slider({value: 100});
        $(global_product_width_text).val(parseFloat(meta.ylen).toFixed(2) * 1000);
        $(global_product_height_slider).slider({value: 100});
        $(global_product_height_text).val(parseFloat(meta.zlen).toFixed(2) * 1000);

        $(global_product_zoom_checkbox).each(function (index) {
            $(this).prop("checked", true);
        });

    } else {
        $(global_product_zoom_checkbox).each(function (index) {
            $(this).prop("checked", false);
        });
    }
});

/*镜像翻转*/
$(global_product_flip_checkbox).on(click, function (e) {
    if ($(this).is(":checked")) {
        

    } else {
        
    }
});

/* 家具==》灯光  开始 */

/*加载颜色选择控件*/
$(twod_product_light_color_widget).spectrum({
    theme: "sp-light",
    color: "#f0f0f0", /*默认值*/
    preferredFormat: "hex",
    showInput: true,
    showPalette: true,
    palette: [["white", "#787878", "black"],
        ["#fff3d9", "#ffe59f", "#ffb573"],
        ["#d2e7ff", "#a8dbff", "#6ec3ff"]],
    cancelText: "取消",
    chooseText: "选择"
});

/*颜色控件事件*/
$(twod_product_light_color_widget).on("change.spectrum", function (e, color) {
    $(this).parents(".light_color_value").attr({
        "value": color.toHexString(),
        "rgb": color.toRgbString()
    }).trigger("change");
});

/*亮度*/
$(twod_product_light_brightness_slider)
    .slider({min: 0.1, max: 10, step: 0.1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: ""})
    .on("slide", function (e, ui) {

    })
    .on("slidestop", function (e, ui) {
        $(twod_product_light_brightness_text).val(ui.value).trigger("change");
    });

function initContextMenuProduct_ui() {
    $(global_material_single_advanced_icon).parents("li").hide();
    var model = api.pickGetPicked()[0].model;
    var meta = model.meta;

    $(global_product_info_icon).attr("title", meta.title);

    var lightsElement = $(twod_product_light_elements), groupElement = $(twod_product_group_elements);
    var tileElement = $(threed_product_tile_elements);

    lightsElement.hide(), groupElement.hide(), tileElement.hide();
    if (showLightRenderSettings(model)) {
        lightsElement.show();
        initContextMenuLightRenderSettings(model);
    }
    $("#contextmenu2d .product .popup .tab:first").trigger(click);
    $("#contextmenu3d .product .popup .tab:first").trigger(click);

    if (model && model.group) {
        groupElement.show();
        $("#contextmenu2d .product .popup .tab_head .group").trigger(click);
    }
    if (pickedMaterial()) {
        tileElement.show();
        $("#contextmenu3d .product .popup .tab_head .tile").trigger(click);
        if (pickedMaterial().type == 'MATERIAL' || pickedMaterial().type == 'TILESINGLE') {
            $(global_material_single_advanced_icon).parents("li").show();
        }
    }
}

function showLightRenderSettings(prod) {
    var meta = prod.meta;
    return (meta && (meta.subcategory == "light"
    || meta.subcategory == "ies"
    || meta.subcategory == "ceiling"
    || meta.subcategory == "backgroundwall_light"
    || meta.subcategory == "filllight"));
}

function initContextMenuLightRenderSettings(prod) {
    resetLightRenderSettingsUI(prod);
    if (prod && prod.userDefined && prod.userDefined.light_settings) {
        var setting = prod.userDefined.light_settings;
        if (setting.on !== undefined)$(twod_product_light_switch_checkbox).prop("checked", setting.on);
        if (setting.multiplier !== undefined)$(twod_product_light_brightness_text).val(setting.multiplier);
        if (setting.multiplier !== undefined)$(twod_product_light_brightness_slider).slider("value", setting.multiplier);
        if (setting.colorHex !== undefined)$(twod_product_light_color_widget).spectrum("set", setting.colorHex);
    }
}

function resetLightRenderSettingsUI(prod) {
    var brightness = prod.meta.subcategory == "ies" ? 1.0 : 30;
    $(twod_product_light_brightness_text).val(brightness);
    $(twod_product_light_switch_checkbox).prop("checked", true);
    $(twod_product_light_color_widget).spectrum("set", "#f0f0f0");
    $(twod_product_light_brightness_text).parent().find(".title").html(prod.meta.subcategory == "ies" ? "IES倍增" : "灯光倍增");
}

/* 家具==》灯光  结束 */

/*====================================家具[end]==========================================*/

/*====================================波打线[start]==========================================*/
/*波打线*右键菜单tab页切换*/
$(".contextmenu .boundary .popup .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $(".contextmenu .boundary .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/*波打线尺寸*/
$(twod_boundary_size_slider)
    .slider({min: 0.01, max: 2, step: 0.01})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        
        var boundary = api.pickGetPicked()[0].model;
		    if(!api.actionBegin("SetBoundarySize", boundary, Number(ui.value))){
		    	  layer.alert('波打线尺寸超过空间大小', {title: '提示', skin: 'layui-layer-default'}, function (index) {
		            layer.close(index);
		        });
		    }
		    
		    $(twod_boundary_size_text).val(boundary.size);
    });
   
/*删除波打线*/
$(twod_boundary_delete_icon).on(click, function (e) {    
    var boundary = api.pickGetPicked()[0].model;
    api.actionBegin("DeleteBoundary", boundary);
    closeContextMenu();
});

$(twod_boundary_size_text).bind("keypress", function (event) {
    var _this = $(this);
    
    /*回车键*/
    if (event.keyCode == 13) {
        saveValue();
        _this.select();
    }

    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val())))
            return false;
        if (parseFloat(_this.val()) < 0.01)
            return false;

        var boundary = api.pickGetPicked()[0].model;
        if(!api.actionBegin("SetBoundarySize", boundary, parseFloat(_this.val()))){
        	  layer.alert('波打线尺寸超过空间大小', {title: '提示', skin: 'layui-layer-default'}, function (index) {
		            layer.close(index);
		        });
        }
        
        _this.parents(".attr_content").find(".slider_widget").slider("value", boundary.size);
        return false;
    }
});

/*波打线 旋转90度*/
$(twod_boundary_rotate_icon).on("click",function(){
    var fitRot = function(rot){
    	return rot %= 360;
    }
    
    if($(this).attr("class")=="cxrotate90"){//衬线
    	  var boundary = api.pickGetPicked()[0].model;
    	  var rot = fitRot(boundary.baseRot + 90);
        $(this).closest('div').find('.serif').css('transform','rotate('+rot+'deg)');        
        api.actionBegin("SetBoundaryRot", boundary, "base", rot);
    }else if($(this).attr("class")=="zjrotate90"){//转角
    	  var boundary = api.pickGetPicked()[0].model;
    	  var rot = fitRot(boundary.cornerRot + 90);
        $(this).closest('div').find('.corner').css('transform','rotate('+rot+'deg)');        
        api.actionBegin("SetBoundaryRot", boundary, "corner", rot);
    }else if($(this).attr("class")=="leftrotate90"){//left
    	  var boundary = api.pickGetPicked()[0].model;
    	  var rot = fitRot(boundary.leftRot + 90);
        $(this).closest('div').find('.left').css('transform','rotate('+rot+'deg)');
        api.actionBegin("SetBoundaryRot", boundary, "left", rot);
    }else if($(this).attr("class")=="rightrotate90"){//right
    	  var boundary = api.pickGetPicked()[0].model; 
    	  var rot = fitRot(boundary.rightRot + 90);
        $(this).closest('div').find('.right').css('transform','rotate('+rot+'deg)');        
        api.actionBegin("SetBoundaryRot", boundary, "right", rot);
    }

});
/*波打线砖缝偏移--开始*/
function boundarySlider(modelSlider,modelText){
    var boundary = api.pickGetPicked()[0].model;
    var baseMaterialLen = boundary.baseMaterial.meta.xlen;
    $(modelSlider)
        .slider({
            min: -baseMaterialLen/2,
            max: baseMaterialLen/2,
            step: 0.02
        })
        .slider("pips", {
            first: false,
            last: false,
            rest: false
        })
        .slider("float", {suffix: "m"})
        .on("slidestop", function (e, ui) {
            var pickedOpt = api.pickGetPicked()[0].opt;
            var pickedSide = pickedOpt.side.split("_");
            if(pickedSide[0] == "base"){
                $(modelText).val(Math.ceil(ui.value * 1000));
            }else{
                $(modelText).val(0);
                $(this).slider({value: 0});
            }
        });
};
//boundarySlider(twod_boundary_bmove_slider,twod_boundary_bmove_text);
//boundarySlider(threed_boundary_bmove_slider,threed_boundary_bmove_text);
/*波打线砖缝偏移--结束*/
/*====================================波打线[end]==========================================*/

/*2d 自由画 区域*/
function initContextMenuFreearea_ui() {
    var area = api.pickGetPicked()[0].model;
    var customTileFlag=area.areaMaterial && (area.areaMaterial.category=="custom_tile" || area.areaMaterial.category=="customparquet" );
    $(".contextmenu .area .popup .tab").each(function (index) {
        if ($(this).hasClass("rectarea") || $(this).hasClass("roundarea"))
            $(this).hide();

        $(this).find(".rectarea_content").hide();
        $(this).find(".roundarea_content").hide();
    });

    /*非自定义拼花显示宽高设置 2017-05-27*/
    if(!customTileFlag){
        $(".contextmenu .area .popup .rectarea_content").show();
    }else{
        $(".contextmenu .area .popup .rectarea_content").hide();
    }
    $(".contextmenu .area .popup .roundarea_content").hide();

    $(".contextmenu .area .popup .tab:first").trigger(click);

    initContextMenuAreaGroup_ui();
}

/*2d 画矩形 区域*/
function initContextMenuRectarea_ui() {
    var area = api.pickGetPicked()[0].model;
    var customTileFlag=area.areaMaterial && (area.areaMaterial.category=="custom_tile" || area.areaMaterial.category=="customparquet" );
    $(".contextmenu .area .popup .tab").each(function (index) {
        if ($(this).hasClass("roundarea")) $(this).hide();
        if ($(this).hasClass("freearea")) $(this).hide();
    });
    /*非自定义拼花显示宽高设置 2017-05-27*/
    if(!customTileFlag){
        $(".contextmenu .area .popup .rectarea_content").show();
    }else{
        $(".contextmenu .area .popup .rectarea_content").hide();
    }

    $(".contextmenu .area .popup .roundarea_content").hide();
    $(".contextmenu .area .popup .tab:first").trigger(click);

    initContextMenuAreaGroup_ui();
}

/*2d 画圆形 区域*/
function initContextMenuRoundarea_ui() {
        $(".contextmenu .area .popup .tab").each(function (index) {
        if ($(this).hasClass("rectarea")) $(this).hide();
        if ($(this).hasClass("freearea")) $(this).hide();
    });
    var area = api.pickGetPicked()[0].model;
    if(area.type == "ROUNDAREA"){
        $(".contextmenu .area .popup .rectarea_content").hide();
    }
    /*非自定义拼花显示半径设置 2017-05-27*/
    if(!customTileFlag){
        $(".contextmenu .area .popup .roundarea_content").show();
    }else{
        $(".contextmenu .area .popup .roundarea_content").hide();
    }

    $(".contextmenu .area .popup .tab:first").trigger(click);

    initContextMenuAreaGroup_ui();
}
function initContextMenuAreaGroup_ui() {
    var area = api.pickGetPicked()[0].model;
    
    var groupElement = $(".contextmenu .area .popup .group");
    groupElement.hide();
    if (area.type != "RECTAREA" && area.type != "ROUNDAREA")return;
    if (area && area.group) {
        groupElement.show();
        $(".contextmenu .area .popup .tab_head .group").trigger(click);
    }
}

/*2d 墙 flag=2 show ; flag=6 hide*/
function initContextMenuWall_ui() {
    if ((api.pickGetPicked()[0].model.flag & 4) == 0) {
        $(twod_wall_hide_icon).show();
        $(twod_wall_show_icon).hide();
    } else {
        $(twod_wall_hide_icon).hide();
        $(twod_wall_show_icon).show();
    }
}

/*3d 墙 矩形区域*/
function initContextMenuRectarea3d_ui() {
    $("#contextmenu3d .area .popup .tab").each(function (index) {
    	  if ($(this).hasClass("rectarea3d")) $(this).show();
        if ($(this).hasClass("roundarea3d")) $(this).hide();
        if ($(this).hasClass("freearea3d")) $(this).hide();
    });
    $(".contextmenu .area .popup .rectarea_content").show();
    $(".contextmenu .area .popup .roundarea_content").hide();
    $("#contextmenu3d .area .popup .tab:first").trigger(click);      

    /*拼花*/
    var patternMat = pickedMaterial();
    if (patternMat && patternMat.type == "PARQUET") {
        $(global_material_parquet_edit_icon).parents("li").show();
        $(global_material_single_advanced_icon).parents("li").hide();
    } else {
        $(global_material_parquet_edit_icon).parents("li").hide();
        $(global_material_single_advanced_icon).parents("li").show();
    }
     if(customTileFlag){
         $(global_material_group_advanced_icon).parents("li").hide();
         $(global_material_single_advanced_icon).parents("li").hide();
         $(".contextmenu .area .popup .rectarea_content").hide();
     }
}

/*3d 墙 圆形区域*/
function initContextMenuRoundarea3d_ui() {
    $("#contextmenu3d .area .popup .tab").each(function (index) {
        if ($(this).hasClass("rectarea3d")) $(this).hide();
        if ($(this).hasClass("roundarea3d")) $(this).show();
        if ($(this).hasClass("freearea3d")) $(this).hide();
    });
    $(".contextmenu .area .popup .rectarea_content").hide();
    $(".contextmenu .area .popup .roundarea_content").show();
    $("#contextmenu3d .area .popup .tab:first").trigger(click);

    /*拼花*/
    var patternMat = pickedMaterial();
    if (patternMat && patternMat.type == "PARQUET") {
        $(global_material_parquet_edit_icon).parents("li").show();
        $(global_material_single_advanced_icon).parents("li").hide();
    } else {
        $(global_material_parquet_edit_icon).parents("li").hide();
        $(global_material_single_advanced_icon).parents("li").show();
    }

    var area = api.pickGetPicked()[0].model;
    var customTileFlag=area.areaMaterial && (area.areaMaterial.category=="custom_tile" || area.areaMaterial.category=="customparquet");
     if(customTileFlag){
         $(global_material_group_advanced_icon).parents("li").hide();
         $(global_material_single_advanced_icon).parents("li").hide();
         $(".contextmenu .area .popup .roundarea_content").hide();
     }
}

/*3d 墙 自由区域*/
function initContextMenuFreearea3d_ui() {
    $("#contextmenu3d .area .popup .tab").each(function (index) {
        if ($(this).hasClass("rectarea3d")) $(this).hide();
        if ($(this).hasClass("roundarea3d")) $(this).hide();
        if ($(this).hasClass("freearea3d")) $(this).show();
    });
    $(".contextmenu .area .popup .rectarea_content").hide();
    $(".contextmenu .area .popup .roundarea_content").hide();
    $("#contextmenu3d .area .popup .tab:first").trigger(click);

    /*拼花*/
    //var patternMat = pickedMaterial();
    //if (patternMat && patternMat.type == "PARQUET") {
    //    $(global_material_parquet_edit_icon).parents("li").show();
    //    $(global_material_single_advanced_icon).parents("li").hide();
    //} else {
    //    $(global_material_parquet_edit_icon).parents("li").hide();
    //    $(global_material_single_advanced_icon).parents("li").show();
    //}
    //
    //var area = api.pickGetPicked()[0].model;
    //var customTileFlag=area.areaMaterial && (area.areaMaterial.category=="custom_tile" || area.areaMaterial.category=="customparquet");
    // if(customTileFlag){
    //     $(global_material_group_advanced_icon).parents("li").hide();
    //     $(global_material_single_advanced_icon).parents("li").hide();
    //     $(".contextmenu .area .popup .roundarea_content").hide();
    // }
}

api.application_ready_event.add(function (settings) {
    if (typeof io != "undefined" && settings.brand == "full")$(".collaboration_div").show();
    api.pickChangedEvent.add(function (changedType, result) {
        closeContextMenu();
    });
});


//# sourceURL=ui/contextpopup/contextpopup_ui.js