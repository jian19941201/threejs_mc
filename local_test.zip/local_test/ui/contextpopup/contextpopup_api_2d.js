/*====================================2d 摄像机[start]==========================================*/

/*颜色控件事件*/
$(twod_annotation_content_color).on("hide.spectrum dragstop.spectrum", function (e, color) {
    var colorValue = color.toHexString();
    api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    api.actionRun("set", "textcolor", colorValue);
    api.actionEnd("SetGeneralProp");
});

$(twod_annotation_content_size).on("change", function (e) {
    api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    api.actionRun("set", "fontsize", $(this).val());
    api.actionEnd("SetGeneralProp");
});

/*文字标注 填充内容 */
$(twod_annotation_content_text).on("input", function (e) {
    api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    api.actionRun("set", "text", $(this).val());
    api.actionEnd("SetGeneralProp");
});

/*文字标注 复制 */
$(twod_annotation_copy_icon).on(click, function (e) {
    var annotation = api.pickGetPicked()[0].model
    if(annotation.texttype==2){
        api.actionBegin("AddSimpleAnnotation", annotation);
        api.actionRun("setPos", undefined, {x: annotation.x -1.5, y: annotation.y });
        api.actionEnd("AddSimpleAnnotation");
    }else{
        api.actionBegin("AddAnnotation", annotation);
        api.actionRun("setPos", undefined, {x: annotation.x - 2, y: annotation.y});
        api.actionEnd("AddAnnotation");
    }
});

/*文字标注 删除 */
$(twod_annotation_delete_icon).on(click, function (e) {
    api.actionBegin("DeleteProduct", api.pickGetPicked()[0].model);
    api.actionEnd("DeleteProduct");
});

/*摄像机高度*/
$(twod_camera_height_slider)
    .on("slide", function (e, ui) {
        api.documentGetActiveCamera().z = ui.value;
    });

$(twod_camera_height_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 200) return false;
        api.documentGetActiveCamera().z = parseFloat(_this.val()) / 1000;
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/*摄像机俯仰角度 add by zk */
$(twod_camera_pitch_slider).
    slider({min: -75, max: 75, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "度"})
    .on("slidestop", function (e, ui) {
        $(twod_camera_pitch_text).val(ui.value);
    }).on("slide", function (e, ui) {
        var camera = api.documentGetActiveCamera();
        camera.pitch = parseFloat(ui.value);
    });
$(twod_camera_pitch_text).bind("keypress blur", function (event) {
    var _this = $(this);
    /*回车键*/
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*整数*/
        var positive_int = /^-?\d+$/;
        if (!positive_int.test(_this.val())) return false;
        var camera = api.documentGetActiveCamera();
        camera.pitch = parseFloat(_this.val());
        $(twod_camera_pitch_slider).slider("value", _this.val());
        return false;
    }
});

/*摄像机视角*/
$(twod_camera_visualangle_slider)
    .on("slide", function (e, ui) {
        api.documentGetActiveCamera().hfov = ui.value;
    });
$(twod_camera_visualangle_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*非负整数*/
        var positive_int = /^\d+$/;
        if (!positive_int.test(_this.val())) return false;
        if (parseInt(_this.val()) < 30) return false;
        api.documentGetActiveCamera().hfov = _this.val();
        _this.parents(".attr_content").find(".slider_widget").slider("value", _this.val());
        return false;
    }
});
/*摄像机名称*/
$(twod_camera_name_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        api.documentGetActiveCamera().name = (_this.val());
        return false;
    }
});

/* 相机隐藏*/
$(twod_camera_hide).on(click, function () {
    toggleCameraVisible();
    closeContextMenu();
});

/*相机上锁*/
$(twod_camera_lock).on(click, function () {
    lockCamera();
    closeContextMenu();
});
/*====================================2d 摄像机 [end]==========================================*/


/*====================================2d 组合 [start]==========================================*/

/*组合旋转*/
$(twod_group_rotateangle_slider)
    .on("slidestart", function (e, ui) {
        this._start = ui.value;
        log(api.pickGetPicked()[0].model)
        api.actionBegin("RotateGroup", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("contextmenu", e, ui.value - this._start,parseFloat(ui.value));
        this._start = ui.value;
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("RotateGroup");
        delete this._start;
    });

$(twod_group_rotateangle_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*非负整数*/
        var positive_int = /^\d+$/;
        if (!positive_int.test(_this.val())) return false;
        if (parseInt(_this.val()) > 360) return false;

        var valueBefore = parseFloat($(twod_group_rotateangle_slider).slider("value"));
        var valueAfter = parseFloat(_this.val());

        api.actionBegin("RotateGroup", api.pickGetPicked()[0].model);
        api.actionRun("contextmenu", event, valueAfter - valueBefore,parseFloat(_this.val()));
        api.actionEnd("RotateGroup");

        _this.parents(".attr_content").find(".slider_widget").slider("value", valueAfter);
        return false;
    }
});

/*组合名称*/
$(twod_group_name_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        var group = api.pickGetPicked()[0].model;
        group.name = _this.val();

        return false;
    }
});

/*编辑*/
$(twod_group_edit_icon).on(click, function (e) {
    var group = api.pickGetPicked()[0].model;
    api.actionBegin("SetGeneralFlag", group);
    api.actionRun("set", 1 << 9, true);
    api.actionEnd("SetGeneralFlag");
});

/*组合*/
$(twod_group_makegroup_icon).on(click, function (e) {
    var groupCount = api.floorplanFilterEntity(function (e) {
        return e.type == "GROUP";
    }).length;
    var group = api.actionBegin("MakeGroup");
    api.actionRun("fromTempGroup");
    api.actionEnd("MakeGroup");
    group.name = "我的组合-" + (groupCount <= 10 ? "0" : "") + groupCount;
    closeContextMenu();
});

/*取消组合*/
$(twod_group_ungroup_icon).on(click, function (e) {
    var group = api.pickGetPicked()[0].model;
    api.actionBegin("ExplodeGroup", group);
    api.actionEnd("ExplodeGroup");
    closeContextMenu();
});

/*复制*/
$(twod_group_copy_icon).on(click, function (e) {
    var group = api.pickGetPicked()[0].model;
    api.actionBegin("CopyGroup", group);
    api.actionEnd("CopyGroup");
    closeContextMenu();
});

/*删除*/
$(twod_group_delete_icon).on(click, function (e) {
    var group = api.pickGetPicked()[0].model;
    var rv = api.actionBegin("DeleteGroup", group);
    api.actionEnd("DeleteGroup");
    closeContextMenu();

});

/*退出组合编辑*/
$(twod_group_close_button).on(click, function (e) {
    var product = api.pickGetPicked()[0].model;
    var group = product.group;
    if (group) {
        api.actionBegin("SetGeneralFlag", group);
        api.actionRun("set", 1 << 9, false);
        api.actionEnd("SetGeneralFlag");
    }
    closeContextMenu();
});

/*从当前组合中分离*/
$(twod_group_detach_button).on(click, function (e) {
    var product = api.pickGetPicked()[0].model;
    var group = product.group;
    if (group) {
        api.actionBegin("MakeGroup", group);
        api.actionRun("detach", undefined, product);
        api.actionEnd("MakeGroup");
    }
    closeContextMenu();
});

/*====================================2d 组合 [end]==========================================*/


/*====================================地板[start]==========================================*/

/*房间高度*/
$(twod_room_height_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetHeight3d", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetHeight3d");
    });

$(twod_room_height_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }

    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 1.5) return false;
        api.actionBegin("SetHeight3d", api.pickGetPicked()[0].model);
        api.actionRun("set", parseFloat(_this.val()));
        api.actionEnd("SetHeight3d");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()));
        return false;
    }
});

$(twod_room_name_select_li).each(function () {
    $(this).on(click, function (e) {
        var textvalue = $(this).text();
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "label", textvalue);
        api.actionEnd("SetGeneralProp");

        var curPid = null;
        if(api.pickGetPicked()[0].model.floorMaterial){
             curPid = api.pickGetPicked()[0].model.floorMaterial.meta.pid;
        }
        var hasChange = getPidFromRoomdefaulttile(curPid);

        log(hasChange);

        //增加判断是否已改变过地面材质 ，如果有改变就不用去调整为默认材质-- add by gaoning 2017.9.27
        if(hasChange || curPid == "beechwoodhoney"){
            /**默认地板处理*/
            appSettings.roomdefaulttile && appSettings.roomdefaulttile.forEach(function (obj, index) {
                if (textvalue == obj.label) {
                    //api.actionBegin("SetMat", api.pickGetPicked()[0].model, "floor", obj.pid);
                    //api.actionEnd("SetMat");

                    api.catalogGetProductsMetaPromise([obj.pid]).then(function (meta) {
                        advancedPatternShowObj = {
                            pid: obj.pid,
                            xlen: meta[obj.pid].xlen,
                            ylen: meta[obj.pid].xlen,
                            model: meta[obj.pid].model
                        };

                        $("#advancedpattern_single_dialog .pavet li:first").trigger("click");
                        /* 缝隙宽度  */
                        $("#advancedpattern_single_dialog .gap_width li").each(function (index) {
                            if ($(this).children("span").attr("widthvalue") == obj.gap) {
                                $("#advancedpattern_single_dialog .gap_width li:eq(" + index + ")").trigger("click");
                            }
                        });
                        /* 缝隙颜色*/
                        $("#advancedpattern_single_dialog .gap_color li").each(function (index) {
                            if ($(this).children("div").attr("value") == obj.color) {
                                $("#advancedpattern_single_dialog .gap_color li:eq(" + index + ")").trigger("click");
                            }
                        });

                        $("#advancedpattern_single_dialog .apply").trigger("click");
                    });
                }
            });
        }
        closeContextMenu();
    });
});

function getPidFromRoomdefaulttile(pid){

    var hasPid = false;
    appSettings.roomdefaulttile && appSettings.roomdefaulttile.forEach(function (obj, index) {

        if(obj.pid == pid){
            hasPid = true;
        }

    });

    return hasPid;
}

$(twod_room_name_text).bind("keypress", function (event) {
    var _this = $(this);
    if (event.keyCode == 13) {
        if ($.trim(_this.val()) == '') return false;
        var label = $.trim(_this.val());
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "label", label);
        api.actionEnd("SetGeneralProp");
        _this.select();
        $(twod_room_name_select).css("display", "none");
        return false;
    }
});


/* 3d下隐藏房顶 */
$(twod_room_roof_checkbox).on(click, function (e) {
    var ceilingFlag = 1 << 12;
    var room = api.pickGetPicked()[0].model;
    if ($(this).is(":checked")) {/*隐藏*/
        api.actionBegin("SetGeneralFlag", room);
        api.actionRun("set", ceilingFlag, true);
        api.actionEnd("SetGeneralFlag");
    } else { /*显示*/
        api.actionBegin("SetGeneralFlag", room);
        api.actionRun("set", ceilingFlag, false);
        api.actionEnd("SetGeneralFlag");
    }

});

/*波打线 与墙距离*/
$(twod_floor_boundary_slider)
    .on("slidestart", function (e, ui) {

    })
    .on("slide", function (e, ui) {

    })
    .on("slidestop", function (e, ui) {

    });

$(twod_floor_boundary_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/* 有无波打线 */
$(twod_floor_boundary_checkbox).on(click, function (e) {
    if ($(this).is(":checked")) {
        alert("boundary-checkbox");
    } else {
        alert("not boundary-checkbox");
    }
});
$(".room_collaboration").on(click, function (e) {
    var room = api.pickGetPicked()[0].model;
    var op = $(this).attr("operation");
    if (typeof popCollaborationDialog != "undefined")popCollaborationDialog(room, op, function () {
        closeContextMenu();
    });
});
//调整波打线砖缝偏移 开始
$(twod_boundary_bmove_slider)
    .on("slide", function (e, ui) {
        var boundary = api.pickGetPicked()[0].model;
        var pickedOpt = api.pickGetPicked()[0].opt;
        var pickedSide = pickedOpt.side.split("_");
        if(pickedSide[0] == "base"){
            $(".gap_attr_content").show();
            //只有base段提供砖缝偏移
            api.actionBegin("SetBoundaryGapOffsetX", boundary, parseInt(pickedSide[1]), parseFloat(ui.value));
        }else{
            $(".gap_attr_content").hide();
        }
    });

$(twod_boundary_bmove_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        var boundary = api.pickGetPicked()[0].model;
        var pickedOpt = api.pickGetPicked()[0].opt;
        var pickedSide = pickedOpt.side.split("_");
        var baseMaterialLen = (boundary.baseMaterial.meta.xlen)/2*1000;
        var textVal = parseFloat(_this.val());
        if(textVal > baseMaterialLen){
            textVal = baseMaterialLen;
            _this.val(baseMaterialLen);
        }
        if(textVal < -baseMaterialLen){
            textVal = -baseMaterialLen;
            _this.val(-baseMaterialLen);
        }
        if (!positive_float.test(textVal)) return false;
        api.actionBegin("SetBoundaryGapOffsetX", boundary, parseInt(pickedSide[1]), textVal / 1000);
        $(twod_boundary_bmove_slider).slider({value:textVal/1000});
        return false;
    }
});

//调整波打线砖缝偏移 结束
/*====================================地板[end]==========================================*/


/*====================================区域[start]==========================================*/
/*拼花旋转*/
$(global_material_rot_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("RotMat", pickedMaterial());
    })
    .on("slide", function (e, ui) {
        api.actionRun("rot", "", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("RotMat");
    });

$(global_material_rot_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*非负整数*/
        var positive_int = /^\d+$/;
        if (!positive_int.test(_this.val())) return false;
        api.actionBegin("RotMat", pickedMaterial());
        api.actionRun("rot", "", _this.val());
        api.actionEnd("RotMat");
        _this.parents(".attr_content").find(".slider_widget").slider("value", _this.val());
        return false;
    }
});

/*拼花水平移动*/
$(global_material_hmove_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("MoveMat", pickedMaterial());
    })
    .on("slide", function (e, ui) {
        api.actionRun("move", "x", "delta", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("MoveMat");
    });

$(global_material_hmove_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        api.actionBegin("MoveMat", pickedMaterial());
        api.actionRun("move", "x", "", parseFloat(_this.val()) / 1000);
        api.actionEnd("MoveMat");
        return false;
    }
});


/*拼花竖直移动*/
$(global_material_vmove_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("MoveMat", pickedMaterial());
    })
    .on("slide", function (e, ui) {
        api.actionRun("move", "y", "delta", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("MoveMat");
    });

$(global_material_vmove_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        api.actionBegin("MoveMat", pickedMaterial());
        api.actionRun("move", "y", "", parseFloat(_this.val()) / 1000);
        api.actionEnd("MoveMat");
        return false;
    }
});


/*拼花高度缩放*/
$(global_material_zoom_height_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", pickedMaterial());
    })
    .on("slide", function (e, ui) {
        var meta = pickedMaterial().meta;
        var scale = Math.max(0.125, parseFloat(ui.value) / meta.ylen);
        api.actionRun("set", "sy", scale);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_material_zoom_height_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var areaMaterial = pickedMaterial();
        var meta = areaMaterial.meta;
        api.actionBegin("SetGeneralProp", areaMaterial);
        var scale = Math.max(0.125, parseFloat(_this.val()) / 1000 / meta.ylen);
        api.actionRun("set", "sy", scale);
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", _this.val() / 1000);
        return false;
    }
});


/*拼花宽度缩放*/
$(global_material_zoom_width_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", pickedMaterial());
    })
    .on("slide", function (e, ui) {
        var meta = pickedMaterial().meta;
        var scale = Math.max(0.125, parseFloat(ui.value) / meta.ylen);
        api.actionRun("set", "sx", scale);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_material_zoom_width_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var areaMaterial = pickedMaterial();
        var meta = areaMaterial.meta;
        api.actionBegin("SetGeneralProp", areaMaterial);
        var scale = Math.max(0.125, parseFloat(_this.val()) / 1000 / meta.xlen);
        api.actionRun("set", "sx", scale);
        api.actionEnd("SetGeneralProp");

        _this.parents(".attr_content").find(".slider_widget").slider("value", _this.val() / 1000);
        return false;
    }
});


/*拼花半径缩放*/
$(global_material_zoom_radius_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", pickedMaterial());
    })
    .on("slide", function (e, ui) {
        if(pickedMaterial()){
            var meta = pickedMaterial().meta;
            var scaleX = Math.max(0.125, (parseFloat(ui.value) * 2) / meta.xlen);
            var scaleY = Math.max(0.125, (parseFloat(ui.value) * 2) / meta.ylen);
            api.actionRun("set", "sx", scaleX);
            api.actionRun("set", "sy", scaleY);
        }else {
            //还没添加拼花。所以没有拼花半径缩放操作
        }
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_material_zoom_radius_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var areaMaterial = pickedMaterial();
        var meta = areaMaterial.meta;
        api.actionBegin("SetGeneralProp", areaMaterial);
        var scaleX = Math.max(0.125, (parseFloat(_this.val()) / 1000 * 2) / meta.xlen);
        var scaleY = Math.max(0.125, (parseFloat(_this.val()) / 1000 * 2) / meta.ylen);
        api.actionRun("set", "sx", scaleX);
        api.actionRun("set", "sy", scaleY);
        api.actionEnd("SetGeneralProp");

        _this.parents(".attr_content").find(".slider_widget").slider("value", _this.val() / 1000);
        return false;
    }
});

/* 加入清单 */
$(global_material_add_goodslist_checkbox).on(click, function (e) {
    var isAddGoodsList = $(this).is(":checked");
    api.actionBegin("SetGeneralFlag", pickedMaterial());
    api.actionRun("set", 1 << 9, !isAddGoodsList);
    api.actionEnd("SetGeneralFlag");
});

/*拼花重新设置*/
$(global_material_reset_button).on(click, function (e) {
    var patternMat = pickedMaterial();
    api.actionBegin("MoveMat", patternMat);
    api.actionRun("move", "x", "", 0);
    api.actionRun("move", "y", "", 0);
    api.actionEnd("MoveMat");

    api.actionBegin("RotMat", patternMat);
    api.actionRun("rot", "", 0);
    api.actionEnd("RotMat");

    api.actionBegin("ScaleMaterial", patternMat);
    api.actionRun("mousemove", undefined, {x: 1, y: 1});
    api.actionEnd("ScaleMaterial");

});

/*主砖高级拼花*/
$(global_material_single_advanced_icon).on(click, function (e) {
    var patternMat = pickedMaterial();
    if (!patternMat) return;
    var meta = patternMat.meta;
    advancedSinglePatternPrompt({
        pid: meta.pid,
        xlen: meta.xlen * 1000,
        ylen: meta.ylen * 1000,
        title: meta.title,
        model: meta.model
    });
    closeContextMenu();
});

/*选择拼花模板*/
$(global_material_group_advanced_icon).on(click, function (e) {
    log("选择拼花模板");
});

/*编辑拼花模板*/
$(global_material_parquet_edit_icon).on(click, function (e) {
    closeContextMenu();
    var patternMat = pickedMaterial(); // todo , use other materials..
    ParquetEditorPopup(patternMat);
});


/* 区域置顶 */
$(global_material_area_place_top_icon).on(click, function (e) {
    api.actionBegin("SetAreaLevel", api.pickGetPicked()[0].model);
    api.actionRun("set", true);
    api.actionEnd("SetAreaLevel");
});

/* 区域置底 */
$(global_material_area_place_buttom_icon).on(click, function (e) {
    api.actionBegin("SetAreaLevel", api.pickGetPicked()[0].model);
    api.actionRun("set", false);
    api.actionEnd("SetAreaLevel");
});
/* 区域复制 */
$(global_material_area_copy_icon).on(click, function (e) {
    api.actionBegin("CopyArea", api.pickGetPicked()[0].model);
    api.actionEnd("CopyArea");
});
/* 区域扩展 */
$(global_material_area_expand_icon).on(click, function (e) {
    expandAreaPanelPrompt(function () {
        closeContextMenu();
    });
});
/* 区域删除 */
$(global_material_area_delete_icon).on(click, function (e) {
    layer.confirm('确定要删除该区域吗？', {
        btn: ['确定', '取消'],
        shade: 0.3,
        skin: 'layui-layer-default',
        title: '提示'
    }, function (index) {
        layer.close(index);
        closeContextMenu();
        api.actionBegin("DeleteArea", api.pickGetPicked()[0].model);
        api.actionEnd("DeleteArea");
    }, function () {
    });
});

/*编辑*/
$(global_material_area_edit_icon).on(click, function (e) {
    var area = api.pickGetPicked()[0].model, wall3d = area.host;
    advancedPaintPrompt({model: wall3d, opt: {src: "3d", elementName: area.category}});
    closeContextMenu();
});

/*矩形区域 角度  */
$(twod_rectarea_angle_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "rot", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(twod_rectarea_angle_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        var rot = parseFloat(_this.val());

        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "rot", rot);
        api.actionEnd("SetGeneralProp");

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()));
        return false;
    }
});
/*矩形区域 高度  */
$(global_rectarea_height_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        //api.actionRun("set", "height", ui.value);
        var alignMode = $(global_rectarea_height_align_select).val();
        var model = api.pickGetPicked()[0].model, Vec2 = api.Vec2;
        var center = model.center, oldheight = model.height, newheight = ui.value;
        if (alignMode == "center") {
            api.actionRun("set", "height", newheight);
        } else {
            var align_dir = (alignMode == "top" ? -1 : 1);
            var newcenter = new Vec2(center.x, center.y + (newheight - oldheight) * align_dir / 2);
            var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
            var batch = {};
            batch[model.id] = {height: newheight};
            batch[model.center.id] = {x: center.x, y: center.y};
            api.actionRun("manymodelsetbatch", batch);
        }
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_rectarea_height_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var alignMode = $(global_rectarea_height_align_select).val();
        var model = api.pickGetPicked()[0].model, Vec2 = api.Vec2;
        var center = model.center, oldheight = model.height, newheight = parseFloat(_this.val()) / 1000;
        api.actionBegin("SetGeneralProp", model);
        if (alignMode == "center") {
            api.actionRun("set", "height", newheight);
        } else {
            var align_dir = (alignMode == "top" ? -1 : 1);
            var newcenter = new Vec2(center.x, center.y + (newheight - oldheight) * align_dir / 2);
            var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
            var batch = {};
            batch[model.id] = {height: newheight};
            batch[model.center.id] = {x: center.x, y: center.y};
            api.actionRun("manymodelsetbatch", batch);
        }
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});
/* 矩形区域 宽度 */
$(global_rectarea_width_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        //api.actionRun("set", "width", ui.value);
        var alignMode = $(global_rectarea_width_align_select).val();
        var model = api.pickGetPicked()[0].model, Vec2 = api.Vec2;
        var center = model.center, oldwidth = model.width, newwidth = ui.value;
        if (alignMode == "center") {
            api.actionRun("set", "width", newwidth);
        } else {
            var align_dir = (alignMode == "left" ? 1 : -1);
            var newcenter = new Vec2(center.x + (newwidth - oldwidth) * align_dir / 2, center.y);
            var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
            var batch = {};
            batch[model.id] = {width: newwidth};
            batch[model.center.id] = {x: center.x, y: center.y};
            api.actionRun("manymodelsetbatch", batch);
        }
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_rectarea_width_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;

        var alignMode = $(global_rectarea_width_align_select).val();
        var model = api.pickGetPicked()[0].model, Vec2 = api.Vec2;
        var center = model.center, oldwidth = model.width, newwidth = parseFloat(_this.val()) / 1000;

        api.actionBegin("SetGeneralProp", model);
        if (alignMode == "center") {
            api.actionRun("set", "width", newwidth);
        } else {
            var align_dir = (alignMode == "left" ? 1 : -1);
            var newcenter = new Vec2(center.x + (newwidth - oldwidth) * align_dir / 2, center.y);
            var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
            var batch = {};
            batch[model.id] = {width: newwidth};
            batch[model.center.id] = {x: center.x, y: center.y};
            api.actionRun("manymodelsetbatch", batch);
        }
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/* 圆形区域 半径 */
$(global_roundarea_radius_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "radius", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_roundarea_radius_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "radius", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/*====================================区域[end]==========================================*/


/*====================================结构部件[start]========================================*/

/* 柱子 地台 横梁 长度 */
$(global_structure_length_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "sx", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_structure_length_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 40) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "sx", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/* 柱子 地台 横梁 宽度 */
$(global_structure_width_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "sy", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_structure_width_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 40) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "sy", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/* 柱子 地台 横梁 高度 */
$(global_structure_height_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "sz", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_structure_height_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0.04) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "sz", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/* 柱子 地台 横梁 离地 */
$(global_structure_ground_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "z", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_structure_ground_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
//        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
//        if (parseFloat($(this).val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "z", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/*地台旋转   add by gaoning 2017.4.25 */
$(global_structure_ground_rotate_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "rot", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });
//地台旋转提示--add by gaoning 2017.4.25
$(global_structure_ground_rotate_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
//        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        //       if (!positive_float.test(parseFloat($(this).val()))) return false;
        //    if (parseFloat($(this).val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "rot", parseFloat(_this.val() ));
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()/100));
        return false;
    }
});

/* 柱子 地台 横梁 删除 */
$(global_structure_delete_icon).on(click, function (e) {
    api.actionBegin("DeleteProduct", api.pickGetPicked()[0].model);
    api.actionEnd("DeleteProduct");
});

/*柱子 地台 横梁 隐藏 -add by zk*/
$(global_structure_hide_icon).on(click, function (event) {
    var structureobj = api.pickGetPicked()[0].model;
    api.actionBegin("SetGeneralFlag", structureobj);
    api.actionRun("set", 1 << 2, true);
    api.actionEnd("SetGeneralFlag");
});

/*====================================结构部件[end]==========================================*/


/*====================================墙[start]==========================================*/
//透明度
$(twod_wall_transparent_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "transparent", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(twod_wall_transparent_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0.1) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "transparent", parseFloat(_this.val()));
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()));
        return false;
    }
});

/*墙厚*/
$(twod_wall_thickness_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetThickness", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        //console.log(ui.value);
        api.actionRun("set", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetThickness");
    });

$(twod_wall_thickness_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 100) return false;
        api.actionBegin("SetThickness", api.pickGetPicked()[0].model);
        api.actionRun("set", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetThickness");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});

/*墙高*/
$(twod_wall_height_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetHeight3d", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetHeight3d");
    });

$(twod_wall_height_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 1500) return false;
        api.actionBegin("SetHeight3d", api.pickGetPicked()[0].model);
        api.actionRun("set", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetHeight3d");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()) / 1000);
        return false;
    }
});
/*墙长度*/
$(twod_wall_length_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        var fixed = _this.parent().find(".fix-point").val();
        /*浮点数*/
        var length = parseFloat(_this.val());

        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(length)) return false;
        if (length < 150) return false;// min wall length: 0.3m change by gaoning 2016
        length = length / 1000.0;

        api.actionBegin("SetWallLength", api.pickGetPicked()[0].model, fixed);
        var success = api.actionRun("set", length);
        api.actionEnd("SetWallLength");
        return false;
    }
});
/*墙重新设置*/
$(twod_wall_reset_button).on(click, function (e) {
    var wall = api.pickGetPicked()[0].model;
    api.actionBegin("SetHeight3d", wall);
    api.actionRun("reset");
    api.actionEnd("SetHeight3d");

    api.actionBegin("SetThickness", wall);
    api.actionRun("reset");
    api.actionEnd("SetThickness");
});

/* 墙拆分 */
$(twod_wall_break_icon).on(click, function (e) {
    if (api.floorplanIsLocked() == true) {
        layer.alert('拆分墙需要首先解锁户型', {title: '提示', skin: 'layui-layer-default'}, function (index) {
            layer.close(index);
        });
        return;
    }
    var wall = api.pickGetPicked()[0].model;
    api.actionBegin("SplitWall", wall);
    api.actionEnd("SplitWall");
});

/* 墙删除 */
$(twod_wall_delete_icon).on(click, function (e) {
    if (api.floorplanIsLocked() == true) {
        layer.alert('删除墙需要首先解锁户型', {title: '提示', skin: 'layui-layer-default'}, function (index) {
            layer.close(index);
        });
        return;
    }
    var wall = api.pickGetPicked()[0].model;
    api.actionBegin("DeleteWall", wall);
    api.actionEnd("DeleteWall");
});

/* 墙隐藏 */
$(twod_wall_hide_icon).on(click, function (e) {
    var wall = api.pickGetPicked()[0].model;
    api.actionBegin("SetGeneralFlag", wall);
    api.actionRun("set", 1 << 2, true);
    api.actionEnd("SetGeneralFlag");
});

/* 墙显示 */
$(twod_wall_show_icon).on(click, function (e) {
    var wall = api.pickGetPicked()[0].model;
    api.actionBegin("SetGeneralFlag", wall);
    api.actionRun("set", 1 << 2, false);
    api.actionEnd("SetGeneralFlag");
});

/* 称重墙 */
$(twod_wall_bearing_checkbox).on(click, function (e) {
    var wall = api.pickGetPicked()[0].model;
    if (!wall) return;
    var isBearingWall = $(this).is(":checked");

    api.actionBegin("SetGeneralFlag", wall);
    api.actionRun("set", 1 << 10, isBearingWall);
    api.actionEnd("SetGeneralFlag");

});

/* 曲线模式 */
$(twod_wall_bezier_checkbox).on(click, function (e) {
    var wall = api.pickGetPicked()[0].model;
    if (!wall) return;
    var beziered = $(this).is(":checked");

    api.actionBegin("SetWallBezier", wall);
    api.actionRun("set", beziered);

});
/*====================================墙[end]==========================================*/

/*====================================家具[start]==========================================*/

function context_popup_api_scaleProduct(product, isUniformScale, property/*{x|y|z}*/, value) {
    api.actionBegin("ScaleProduct", product);
    var scale = {};
    if (isUniformScale)scale = {x: value, y: value, z: value};
    else scale[property] = value;
    api.actionRun("set", undefined, scale);
    api.actionEnd("ScaleProduct");
}
function context_popup_api_flipProduct(product, flip) {
    api.actionBegin("FlipProduct", product);
    api.actionRun("set", undefined, flip);
    api.actionEnd("FlipProduct");
}
/*长度*/
$(global_product_length_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        var scale = $(global_product_zoom_checkbox).is(":checked") ?
        {x: ui.value / 100, y: ui.value / 100, z: ui.value / 100} :
        {x: ui.value / 100};
        //灯光长度尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        if(meta.subcategory=='ies'||meta.subcategory=='filllight') {
            if((ui.value / 100)<0.05)return false;
        }
        api.actionRun("set", e, scale);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("ScaleProduct");
    });

$(global_product_length_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 200) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;

        var model = api.pickGetPicked()[0].model, meta = model.meta;
        //灯光长度尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
        var val=(_this.val() / 1000) / meta.xlen;
        if(meta.subcategory=='ies'||meta.subcategory=='filllight'){
            if(parseFloat(val)<0.05){
                val=0.05
            _this.val(parseFloat(Math.ceil(val*1000*meta.xlen)));
            }
        }
        context_popup_api_scaleProduct(model, $(global_product_zoom_checkbox).is(":checked"), "x", parseFloat(val));

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(val * 100));
      /*  context_popup_api_scaleProduct(model, $(global_product_zoom_checkbox).is(":checked"), "x", parseFloat((_this.val() / 1000) / meta.xlen));

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat((_this.val() / 1000) / meta.xlen * 100));*/

        if ($(global_product_zoom_checkbox).is(":checked")) {
            $(global_product_width_slider).slider("value", parseFloat(val * 100));
            $(global_product_height_slider).slider("value", parseFloat(val * 100));

            var width_text_value = val*1000 * meta.ylen;
            $(global_product_width_text).val(parseFloat(Math.ceil(width_text_value)));
            var height_text_value = val*1000 * meta.zlen;
            $(global_product_height_text).val(parseFloat(Math.ceil(height_text_value)));
          /*  $(global_product_width_slider).slider("value", parseFloat((_this.val() / 1000) / meta.xlen * meta.ylen * 100));
            $(global_product_height_slider).slider("value", parseFloat((_this.val() / 1000) / meta.xlen * meta.zlen * 100));

            var width_text_value = _this.val() / meta.xlen * meta.ylen;
            $(global_product_width_text).val(parseFloat(Math.ceil(width_text_value)));
            var height_text_value = _this.val() / meta.xlen * meta.zlen;
            $(global_product_height_text).val(parseFloat(Math.ceil(height_text_value)));*/
        }

        return false;
    }
});


/*宽度*/
$(global_product_width_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        var scale = $(global_product_zoom_checkbox).is(":checked") ?
        {x: ui.value / 100, y: ui.value / 100, z: ui.value / 100} :
        {y: ui.value / 100};
        //灯光宽度尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        if(meta.subcategory=='ies'||meta.subcategory=='filllight') {
            if((ui.value / 100)<0.05)return false;
        }
        api.actionRun("set", e, scale);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("ScaleProduct");
    });


$(global_product_width_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0.2) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;

        var model = api.pickGetPicked()[0].model, meta = model.meta;
        //灯光宽度尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
        var val=(_this.val() / 1000) / meta.ylen
        if(meta.subcategory=='ies'||meta.subcategory=='filllight'){
            if(parseFloat(val)<0.05){
                val=0.05
                _this.val(parseFloat(Math.ceil(val*1000*meta.ylen)));
            }
        }
        context_popup_api_scaleProduct(model, $(global_product_zoom_checkbox).is(":checked"), "y", parseFloat(val));

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(val * 100));

        /*context_popup_api_scaleProduct(model, $(global_product_zoom_checkbox).is(":checked"), "y", parseFloat((_this.val() / 1000) / meta.ylen));

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat((_this.val() / 1000) / meta.ylen * 100));*/
        if ($(global_product_zoom_checkbox).is(":checked")) {
            $(global_product_length_slider).slider("value", parseFloat(val * 100));
            $(global_product_height_slider).slider("value", parseFloat(val * 100));

            var length_text_value = val*1000 * meta.xlen;
            $(global_product_length_text).val(parseFloat(Math.ceil(length_text_value)));
            var height_text_value = val*1000 * meta.zlen;
            $(global_product_height_text).val(parseFloat(Math.ceil(height_text_value)));
          /*  $(global_product_height_text).val(parseFloat(Math.ceil(height_text_value)));
            $(global_product_length_slider).slider("value", parseFloat((_this.val() / 1000) / meta.ylen * meta.xlen * 100));
            $(global_product_height_slider).slider("value", parseFloat((_this.val() / 1000) / meta.ylen * meta.zlen * 100));

            var length_text_value = _this.val() / meta.ylen * meta.xlen;
            $(global_product_length_text).val(parseFloat(Math.ceil(length_text_value)));
            var height_text_value = _this.val() / meta.ylen * meta.zlen;
            $(global_product_height_text).val(parseFloat(Math.ceil(height_text_value)));*/
        }

        return false;
    }
});

/*高度*/
$(global_product_height_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        var scale = $(global_product_zoom_checkbox).is(":checked") ?
        {x: ui.value / 100, y: ui.value / 100, z: ui.value / 100} :
        {z: ui.value / 100};
        //灯光高度尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        if(meta.subcategory=='ies'||meta.subcategory=='filllight') {
            if((ui.value / 100)<0.05)return false;
        }
        api.actionRun("set", e, scale);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("ScaleProduct");
    });

$(global_product_height_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0.2) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;

        var model = api.pickGetPicked()[0].model, meta = model.meta;
        //灯光高度尺寸只能缩小到原尺寸的5%，不能再缩小 add by hcw
        var val=(_this.val() / 1000) / meta.zlen
        if(meta.subcategory=='ies'||meta.subcategory=='filllight'){
            if(parseFloat(val)<0.05){
                val=0.05
                _this.val(parseFloat(Math.ceil(val*1000*meta.zlen)));
            }
        }
        context_popup_api_scaleProduct(model, $(global_product_zoom_checkbox).is(":checked"), "z", parseFloat(val));

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(val * 100));
        /*context_popup_api_scaleProduct(model, $(global_product_zoom_checkbox).is(":checked"), "z", parseFloat((_this.val() / 1000) / meta.zlen));

        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat((_this.val() / 1000) / meta.zlen * 100));*/

        if ($(global_product_zoom_checkbox).is(":checked")) {
            $(global_product_length_slider).slider("value", parseFloat(val * 100));
            $(global_product_width_slider).slider("value", parseFloat(val * 100));

            var length_text_value = val*1000 * meta.xlen;
            $(global_product_length_text).val(parseFloat(Math.ceil(length_text_value)));
            var width_text_value = val*1000 * meta.ylen;
            $(global_product_width_text).val(parseFloat(Math.ceil(width_text_value)));
           /* $(global_product_length_slider).slider("value", parseFloat((_this.val() / 1000) / meta.zlen * meta.xlen * 100));
            $(global_product_width_slider).slider("value", parseFloat((_this.val() / 1000) / meta.zlen * meta.ylen * 100));

            var length_text_value = _this.val() / meta.zlen * meta.xlen;
            $(global_product_length_text).val(parseFloat(Math.ceil(length_text_value)));
            var width_text_value = _this.val() / meta.zlen * meta.ylen;
            $(global_product_width_text).val(parseFloat(Math.ceil(width_text_value)));*/
        }

        return false;
    }
});

/*离地*/
$(global_product_ground_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "z", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

/*产品旋转   add by gaoning 2017.4.24 */
$(global_product_rotate_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "rot", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

/*产品X轴旋转   add by gaoning 2017.4.27 */
$(global_product_x_rotate_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "rotx", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

/*产品Y轴旋转   add by gaoning 2017.4.29 */
$(global_product_y_rotate_slider)
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("set", "roty", ui.value);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    });

$(global_product_ground_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
//        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        //       if (!positive_float.test(parseFloat($(this).val()))) return false;
        //    if (parseFloat($(this).val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "z", parseFloat(_this.val() / 1000));
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val() / 1000));
        return false;
    }
});

//产品旋转提示--add by gaoning 2017.4.24
$(global_product_rotate_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
//        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        //       if (!positive_float.test(parseFloat($(this).val()))) return false;
        //    if (parseFloat($(this).val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "rot", parseFloat(_this.val() ));
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()/100));
        return false;
    }
});

//产品X旋转提示--add by gaoning 2017.4.27
$(global_product_x_rotate_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
//        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        //       if (!positive_float.test(parseFloat($(this).val()))) return false;
        //    if (parseFloat($(this).val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "rotx", parseFloat(_this.val() ));
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()/100));
        return false;
    }
});

//产品Y旋转提示--add by gaoning 2017.4.29
$(global_product_y_rotate_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
//        if (parseFloat($(this).val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        //       if (!positive_float.test(parseFloat($(this).val()))) return false;
        //    if (parseFloat($(this).val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "roty", parseFloat(_this.val() ));
        api.actionEnd("SetGeneralProp");
        _this.parents(".attr_content").find(".slider_widget").slider("value", parseFloat(_this.val()/100));
        return false;
    }
});

/*复制*/
$(global_product_copy_icon).on(click, function (e) {
    api.actionBegin("CopyProduct", api.pickGetPicked()[0].model);
    api.actionEnd("CopyProduct");
});

/*删除*/
$(global_product_delete_icon).on(click, function (e) {
    api.actionBegin("DeleteProduct", api.pickGetPicked()[0].model);
    api.actionEnd("DeleteProduct");
});


/*等比缩放*/
$(global_product_zoom_checkbox).on(click, function (e) {
    if ($(this).is(":checked")) {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        context_popup_api_scaleProduct(model, true, "x", 1);
    }
});

/*镜像翻转*/
$(global_product_flip_checkbox).on(click, function (e) {
    if ($(this).is(":checked")) {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        context_popup_api_flipProduct(model, true);
    } else {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        context_popup_api_flipProduct(model, false);
    }
});

//区域边缘锁定 add by   gaoning 2017.3.9
$(global_rectarea_fixation).on(click, function (e) {
    if ($(this).is(":checked")) {
        //console.log("选中");
        //api.AeraScaleFixation(true);

        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "fixation",true);
        api.actionEnd("SetGeneralProp");
    } else {
        //console.log("未选中");
        //api.AeraScaleFixation(false);

        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "fixation",false);
        api.actionEnd("SetGeneralProp");
    }
});

//区域挖空
function onAreaCanvrnClick(){
	  try{
	    if ($(this).is(":checked")) {
	        api.pickGetPicked()[0].model.cavern = true;
	    } else {
	        api.pickGetPicked()[0].model.cavern = false;
	    }
	    
	  }catch(e){
	  	//...
	  	log(e);
	  }
}
$(global_freearea_cavern).on(click, function (e) {
    onAreaCanvrnClick.bind(this)();
});
$(global_rectarea_cavern).on(click, function (e) {
    onAreaCanvrnClick.bind(this)();
});
$(global_roundarea_cavern).on(click, function (e) {
    onAreaCanvrnClick.bind(this)();
});

/*隐藏*/
$(global_product_hide_icon).on(click, function (event) {
    var productobj = api.pickGetPicked()[0].model;
    api.actionBegin("SetGeneralFlag", productobj);
    api.actionRun("set", 1 << 2, true);
    api.actionEnd("SetGeneralFlag");
});

/*重新设置*/
$(global_product_reset_button).on(click, function (e) {
    var model = api.pickGetPicked()[0].model, meta = model.meta;
    context_popup_api_scaleProduct(model, true, "x", 1);
});

/* 灯光颜色选择 */
$(twod_product_light_color_value).on("change", function () {
    var model = api.pickGetPicked()[0].model;
    var ud = model.userDefined = model.userDefined || {};
    var setting = ud.light_settings = ud.light_settings || {};
    setting.colorHex = $(this).attr("value");
    setting.colorRgb = $(this).attr("rgb");
});

/*IES倍增*/
$(twod_product_light_brightness_text).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        //saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var model = api.pickGetPicked()[0].model;
        var ud = model.userDefined = model.userDefined || {};
        var setting = ud.light_settings = ud.light_settings || {};
        setting.multiplier = parseFloat(_this.val());
        return false;
    }
});

/*灯光属性 是否开启*/
$(twod_product_light_switch_checkbox).on(click, function (e) {
    var isOn = $(this).is(":checked");

    var model = api.pickGetPicked()[0].model;
    var ud = model.userDefined = model.userDefined || {};
    var setting = ud.light_settings = ud.light_settings || {};
    setting.on = isOn;
});

/* 灯光属性 重设 */
$(twod_product_light_reset).on(click, function (e) {
    var model = api.pickGetPicked()[0].model;
    var ud = model.userDefined = model.userDefined || {};
    if (ud) delete ud.light_settings;
    resetLightRenderSettingsUI(model);
});


/*====================================家具[end]==========================================*/

/*无缝铺贴扩展*/
$("#advanced_wall3d_material_extends").on(click, function () {
    if (typeof extendMaterialWall3d_start == "function") extendMaterialWall3d_start();
});

/*替换为颜色铺贴*/
$(".button_change_to_color_pattern").on(click, function () {
    closeContextMenu();
    var initColor = 0;
    popup_color_picker_dialog(initColor, function (color) {
        var picked = api.pickGetPicked()[0];
        var mat = api.actionBegin("AddProduct", "color", 0, 0, {category: "rawcolor"});
        api.actionEnd("AddProduct");
        mat.diffuse_r = color.r;
        mat.diffuse_g = color.g;
        mat.diffuse_b = color.b;

        api.actionBegin("SetGeneralProp", picked.model);
        api.actionRun("set", pickedMaterialName(), mat);
        api.actionEnd("SetGeneralProp");
    })
});

/*测试*/
//$("#productContent").on("click",".draw-line",function(){
//    $("#contextmenu2d .ceramic").show();
//});

$("#productContent").on("click",".draw-line", function (e) {//自由画
    api.actionBegin("AddFreeArea", "inner");
});
$("#productContent").on("click",".draw-rectangle", function (e) {//画矩形
    api.actionBegin("AddRectArea", "inner");
});
$("#productContent").on("click",".draw-circle", function (e) {//画圆形
    api.actionBegin("AddRoundArea", "inner");
});

$(".ceramic .tab_ul").on("click",".tab",function(){
    $(this).addClass("hover").siblings().removeClass("hover");
});

$(".revise_ceramic").on("click","",function(){
    $(".ceramic .tab_0").show().siblings().hide();
    $(".contextmenu .ceramic .popup").css("width","430px");
});
$(".ceramic_KC").on("click","",function(){
    $(".ceramic .tab_1").show().siblings().hide();
    $(".contextmenu .ceramic .popup").css("width","576px");

    $('.vertical-slider .slider_bar').each(function(){
        $(this).dragging({
            move : 'y',
            randomPosition : false
        });
    });
});
$('.vertical-slider').click(function(){
    $('.vertical-slider .slider_bar').each(function(){
        $(this).dragging({
            move : 'y',
            randomPosition : false
        });
    });
});

$(".slider_A").mousemove(function(event){
    var top = $(".slider_A").css("top").replace("px","")*1;
    var slider_bar_height = ($(this).css("height").replace("px",""))/2*1;
    $("#A_label .label_position").val(top+slider_bar_height);
});
$("#A_label .label_width").change(function(){
    var top = $(".slider_A").css("top").replace("px","")*1;
    var label_width_text = $(this).val()*1;
    if((top+label_width_text)>210){
        top = 210-label_width_text;
        $(".slider_A").css("top",top);
        $(".slider_A").css("height",label_width_text);
        $("#A_label .label_position").val(top+label_width_text/2);
    }else{
        $(".slider_A").css("height",label_width_text);
        $("#A_label .label_position").val(top+label_width_text/2);
    }
});
$("#A_label .label_position").change(function(){
    var label_position_text = $("#A_label .label_position").val()*1;
    var slider_bar_height = ($(".slider_A").css("height").replace("px",""))/2*1;
    var top;
    if((label_position_text+slider_bar_height)>210){
        top = 210 - slider_bar_height*2;
        label_position_text = 210 - slider_bar_height;
        $("#A_label .label_position").val(label_position_text);
        $(".slider_A").css("top",top);
    }else if(label_position_text-slider_bar_height<0){
        top = 0;
        label_position_text = slider_bar_height;
        $("#A_label .label_position").val(label_position_text);
        $(".slider_A").css("top",top);
    } else{
        top = label_position_text-slider_bar_height;
        $(".slider_A").css("top",top);
    }
});

$(".slider_B").mousemove(function(event){
    var top = $(".slider_B").css("top").replace("px","")*1;
    var slider_bar_height = ($(this).css("height").replace("px",""))/2*1;
    $("#B_label .label_position").val(top+slider_bar_height);
});
$("#B_label .label_width").change(function(){
    var top = $(".slider_B").css("top").replace("px","")*1;
    var label_width_text = $(this).val()*1;
    if((top+label_width_text)>210){
        top = 210-label_width_text;
        $(".slider_B").css("top",top);
        $(".slider_B").css("height",label_width_text);
        $("#B_label .label_position").val(top+label_width_text/2);
    }else{
        $(".slider_B").css("height",label_width_text);
        $("#B_label .label_position").val(top+label_width_text/2);
    }
});
$("#B_label .label_position").change(function(){
    var label_position_text = $("#B_label .label_position").val()*1;
    var slider_bar_height = ($(".slider_B").css("height").replace("px",""))/2*1;
    var top;
    if((label_position_text+slider_bar_height)>210){
        top = 210 - slider_bar_height*2;
        label_position_text = 210 - slider_bar_height;
        $("#B_label .label_position").val(label_position_text);
        $(".slider_B").css("top",top);
    }else if(label_position_text-slider_bar_height<0){
        top = 0;
        label_position_text = slider_bar_height;
        $("#B_label .label_position").val(label_position_text);
        $(".slider_B").css("top",top);
    } else{
        top = label_position_text-slider_bar_height;
        $(".slider_B").css("top",top);
    }
});

$(".slider_C").mousemove(function(event){
    var top = $(".slider_C").css("top").replace("px","")*1;
    var slider_bar_height = ($(this).css("height").replace("px",""))/2*1;
    $("#C_label .label_position").val(top+slider_bar_height);
});
$("#C_label .label_width").change(function(){
    var top = $(".slider_C").css("top").replace("px","")*1;
    var label_width_text = $(this).val()*1;
    if((top+label_width_text)>210){
        top = 210-label_width_text;
        $(".slider_C").css("top",top);
        $(".slider_C").css("height",label_width_text);
        $("#C_label .label_position").val(top+label_width_text/2);
    }else{
        $(".slider_C").css("height",label_width_text);
        $("#C_label .label_position").val(top+label_width_text/2);
    }
});
$("#C_label .label_position").change(function(){
    var label_position_text = $("#C_label .label_position").val()*1;
    var slider_bar_height = ($(".slider_C").css("height").replace("px",""))/2*1;
    var top;
    if((label_position_text+slider_bar_height)>210){
        top = 210 - slider_bar_height*2;
        label_position_text = 210 - slider_bar_height;
        $("#C_label .label_position").val(label_position_text);
        $(".slider_C").css("top",top);
    }else if(label_position_text-slider_bar_height<0){
        top = 0;
        label_position_text = slider_bar_height;
        $("#C_label .label_position").val(label_position_text);
        $(".slider_C").css("top",top);
    } else{
        top = label_position_text-slider_bar_height;
        $(".slider_C").css("top",top);
    }
});

$(".slider_D").mousemove(function(event){
    var top = $(".slider_D").css("top").replace("px","")*1;
    var slider_bar_height = ($(this).css("height").replace("px",""))/2*1;
    $("#D_label .label_position").val(top+slider_bar_height);
});
$("#D_label .label_width").change(function(){
    var top = $(".slider_D").css("top").replace("px","")*1;
    var label_width_text = $(this).val()*1;
    if((top+label_width_text)>210){
        top = 210-label_width_text;
        $(".slider_D").css("top",top);
        $(".slider_D").css("height",label_width_text);
        $("#D_label .label_position").val(top+label_width_text/2);
    }else{
        $(".slider_D").css("height",label_width_text);
        $("#D_label .label_position").val(top+label_width_text/2);
    }
});
$("#D_label .label_position").change(function(){
    var label_position_text = $("#D_label .label_position").val()*1;
    var slider_bar_height = ($(".slider_D").css("height").replace("px",""))/2*1;
    var top;
    if((label_position_text+slider_bar_height)>210){
        top = 210 - slider_bar_height*2;
        label_position_text = 210 - slider_bar_height;
        $("#D_label .label_position").val(label_position_text);
        $(".slider_D").css("top",top);
    }else if(label_position_text-slider_bar_height<0){
        top = 0;
        label_position_text = slider_bar_height;
        $("#D_label .label_position").val(label_position_text);
        $(".slider_D").css("top",top);
    } else{
        top = label_position_text-slider_bar_height;
        $(".slider_D").css("top",top);
    }
});

$(".slider_E").mousemove(function(event){
    var top = $(".slider_E").css("top").replace("px","")*1;
    var slider_bar_height = ($(this).css("height").replace("px",""))/2*1;
    $("#E_label .label_position").val(top+slider_bar_height);
});
$("#E_label .label_width").change(function(){
    var top = $(".slider_E").css("top").replace("px","")*1;
    var label_width_text = $(this).val()*1;
    if((top+label_width_text)>210){
        top = 210-label_width_text;
        $(".slider_E").css("top",top);
        $(".slider_E").css("height",label_width_text);
        $("#E_label .label_position").val(top+label_width_text/2);
    }else{
        $(".slider_E").css("height",label_width_text);
        $("#E_label .label_position").val(top+label_width_text/2);
    }
});
$("#E_label .label_position").change(function(){
    var label_position_text = $("#E_label .label_position").val()*1;
    var slider_bar_height = ($(".slider_E").css("height").replace("px",""))/2*1;
    var top;
    if((label_position_text+slider_bar_height)>210){
        top = 210 - slider_bar_height*2;
        label_position_text = 210 - slider_bar_height;
        $("#E_label .label_position").val(label_position_text);
        $(".slider_E").css("top",top);
    }else if(label_position_text-slider_bar_height<0){
        top = 0;
        label_position_text = slider_bar_height;
        $("#E_label .label_position").val(label_position_text);
        $(".slider_E").css("top",top);
    } else{
        top = label_position_text-slider_bar_height;
        $(".slider_E").css("top",top);
    }
});

$(".ceramic_DJ").on("click","",function(){
    $(".ceramic .tab_2").show().siblings().hide();
    $(".contextmenu .ceramic .popup").css("width","318px");
});
$(".revise_room").on("click","",function(){
    $(".ceramic .tab_3").show().siblings().hide();
    $(".contextmenu .ceramic .popup").css("width","436px");
});

$('#Expandable').jPicker({window:{expandable:true,title:'Expandable Example'}});
$('#Binded').jPicker({window:{title:'Binded Example'},color:{active:new $.jPicker.Color({ahex:'993300ff'})}});

$("#clip").on("click","",function(){
    layer.open({
        type: 1,
        title:'切砖',
        shade:false,
        move:false,
        skin: 'layui-layer-rim', //加上边框
        area: ['435px', '315px'], //宽高
        content: $('#clip_content'),
        success: function () {
            $(".clip_content").parents(".layui-layer").draggable();
            var jcropApi;
            $('#clip_img').Jcrop({
                bgOpacity: 0.5,
                bgColor: 'white',
                addClass: 'jcrop-normal',
                onChange:   showCoords,
                onSelect:   showCoords,
                allowSelect: false
            },function(){
                jcropApi = this;
                jcropApi.setSelect([50,50,50+130,50+130]);
                jcropApi.setOptions({ bgFade: true });
                jcropApi.ui.selection.addClass('jcrop-selection');
            });

            $("#clip_content").on("change","input",function(){
                var w = $('#clip_img_width').val(),
                    h = $('#clip_img_height').val()
                jcropApi.setSelect([0,0,w,h]);
            });
        }
    });
});

function showCoords(c) {
    $('#clip_img_width').val(c.w);
    $('#clip_img_height').val(c.h);
};

/*切砖应用按钮*/
$("#clip_use_btn").click(function(){
    layer.confirm('您选择的新瓷砖与原有的瓷砖规格不同,选择哪种尺寸规格？', {
        title: "提示",
        btn: ['新瓷砖','原瓷砖']
    }, function(){
        layer.msg('的确很重要', {icon: 1});
    }, function(){
        layer.msg('也可以这样', {
            time: 20000, //20s后自动关闭
            btn: ['明白了', '知道了']
        });
    });
});

/*$(".slider").slider({
    min: 0,
    max: 70,
    values:[0,10,20,30,40],
    orientation: "vertical"
}).slider("pips", {
    rest: "label",
    step: "10"
}).slider("float", {
    suffix: ""
}).on("slidestop", function (e, ui) {
    $("#A_label .label_position").val(ui.value);
});*/

/*开槽数量*/
$(".groove_number").change(function(){
    var groove_number = $(".groove_number option:selected").val();
    if(groove_number == 1){
        $("#A_label").nextAll().hide();
        $(".slider_A").nextAll().hide();
    }
    else if(groove_number == 2){
        $("#B_label").nextAll().hide();
        $("#C_label").prevAll().show();
        $(".slider_B").nextAll().hide();
        $(".slider_C").prevAll().show();
    }
    else if(groove_number == 3){
        $("#C_label").nextAll().hide();
        $("#D_label").prevAll().show();
        $(".slider_C").nextAll().hide();
        $(".slider_D").prevAll().show();
    }
    else if(groove_number == 4){
        $("#D_label").nextAll().hide();
        $("#E_label").prevAll().show();
        $(".slider_D").nextAll().hide();
        $(".slider_E").prevAll().show();
    }
    else{
        $("#E_label").show().prevAll().show();
        $(".slider_E").show().prevAll().show();
    };
});

/*瓷砖倒角*/
$(".chamfer_width_text").on("change",function(){
    var chamfer_width_text = $(".chamfer_width_text").val();
/*    var chamfer_img_width = $(".chamfer_img").attr("width");
    var chamfer_img_height = $(".chamfer_img").attr("height");*/
    if(chamfer_width_text>=90){
        chamfer_width_text = 90;
        $(".tab_2 .chamfer_width_text").val(90);
    }
    //$(".chamfer_side_A").change(function(){
        if($(".chamfer_side_A").is(":checked")){
            $(".chamfer_img").css("border-top",chamfer_width_text+"px solid #838383");
        }else{
            $(".chamfer_img").css("border-top","1px solid #838383");
        }
    //});
    if($(".chamfer_side_B").is(":checked")){
        $(".chamfer_img").css("border-left",chamfer_width_text+"px solid #b6b6b6");
    }else{
        $(".chamfer_img").css("border-left","1px solid #b6b6b6");
    }
    if($(".chamfer_side_C").is(":checked")){
        $(".chamfer_img").css("border-right",chamfer_width_text+"px solid #b6b6b6");
    }else{
        $(".chamfer_img").css("border-right","1px solid #b6b6b6");
    }
    if($(".chamfer_side_D").is(":checked")){
        $(".chamfer_img").css("border-bottom",chamfer_width_text+"px solid #838383");
    }else{
        $(".chamfer_img").css("border-bottom","1px solid #838383");
    }

    if($(".chamfer_side_A").is(":checked")&&$(".chamfer_side_D").is(":checked")){
        $(".chamfer_img").css("height",180-2*chamfer_width_text);
    }
    else if($(".chamfer_side_A").is(":checked")==false&&$(".chamfer_side_D").is(":checked")==false){
        $(".chamfer_img").css("height",180);
    }else{
        $(".chamfer_img").css("height",180-chamfer_width_text);
    }

    if($(".chamfer_side_B").is(":checked")&&$(".chamfer_side_C").is(":checked")){
        $(".chamfer_img").css("width",180-2*chamfer_width_text);
    }
    else if($(".chamfer_side_B").is(":checked")==false&&$(".chamfer_side_C").is(":checked")==false){
        $(".chamfer_img").css("width",180);
    }else{
        $(".chamfer_img").css("width",180-chamfer_width_text);
    }
});



/*墙体高度*/
$(ceramic_wall_height_slider)
    .slider({
        mix:0,
        max:5000
    }).slider("float", {
        suffix: ""
    }).on("slidestop", function (e, ui) {
        $(".tab_3 .slider-wall-height-text").val(ui.value);
    });

$(".slider-wall-height-text").change(function(){
    var slider_wall_height = $(".tab_3 .slider-wall-height-text").val();
    if(slider_wall_height>=5000){
        slider_wall_height = 5000;
        $(".tab_3 .slider-wall-height-text").val(5000);
    }
    $(ceramic_wall_height_slider).slider("option","value",slider_wall_height);
});


//# sourceURL=ui/contextpopup/contextpopup_api_2d.js