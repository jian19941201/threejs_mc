/*文字标注*/
var twod_annotation_content_size = '.contextmenu .annotation .popup .font_size';
var twod_annotation_content_color = '.contextmenu .annotation .popup .font_color';
var twod_annotation_content_text = '.contextmenu .annotation .popup .annotation_content_text';
var twod_annotation_copy_icon = ".contextmenu .annotation .popup .button_copy";
var twod_annotation_delete_icon = ".contextmenu .annotation .popup .button_delete";


/*摄像机*/
/*摄像机高度*/
var twod_camera_height_slider = '.contextmenu .camera .popup .slider-camera-height-move';
var twod_camera_height_text = '.contextmenu .camera .popup .slider-camera-height-text';
/*摄像机俯仰角度*/
var twod_camera_pitch_slider = '.contextmenu .camera .popup .slider-camera-pitch-move';
var twod_camera_pitch_text = '.contextmenu .camera .popup .slider-camera-pitch-text';
/*摄像机视角*/
var twod_camera_visualangle_slider = '.contextmenu .camera .popup .slider-visual-angle-move';
var twod_camera_visualangle_text = '.contextmenu .camera .popup .slider-visual-angle-text';

var twod_camera_name_text = '.contextmenu .camera .popup .camera-name-text';
var twod_camera_hide = '.contextmenu .camera .popup .button_hide';
var twod_camera_lock = '.contextmenu .camera .popup .button_lock';

/*组合  开始*/
var twod_group_rotateangle_slider = '.contextmenu .group .popup .slider-rotate-angle';
var twod_group_rotateangle_text = '.contextmenu .group .popup .slider-rotate-angle-text';
var twod_group_name_text = '.contextmenu .group .popup .group-name-text';

var twod_group_dialog_caption = ".contextmenu .group .popup .group_caption";
var twod_group_edit_icon = ".contextmenu .group .popup .button_edit";
var twod_group_makegroup_icon = ".contextmenu .group .popup .button_makegroup";
var twod_group_ungroup_icon = ".contextmenu .group .popup .button_ungroup";
var twod_group_copy_icon = ".contextmenu .group .popup .button_copy";
var twod_group_delete_icon = ".contextmenu .group .popup .button_delete";

/*组合  结束 */

var twod_room_height_slider = ".contextmenu .floor .popup .slider-height-move";
var twod_room_height_text = '.contextmenu .floor .popup .slider-height-text';

var twod_room_roof_checkbox = ".contextmenu .floor .popup .roof-checkbox";
var twod_room_name_text = ".contextmenu .floor .popup .room-name-text";
var twod_room_name_select = ".contextmenu .floor .popup .room-name-select";
var twod_room_name_select_li = ".contextmenu .floor .popup .room-name-select li";
var twod_room_apply_select = "select[name='room2dApplyReplaceSelect']";
var twod_room_apply_button = ".contextmenu .floor .popup .open-apply-room-button";
var twod_room_save_as_modelroom_button = ".contextmenu .floor .popup .save-model-room-button";

var twod_floor_boundary_slider = ".contextmenu .floor .popup .slider-boundary-move";
var twod_floor_boundary_text = ".contextmenu .floor .popup .slider-boundary-text";
var twod_floor_boundary_checkbox = ".contextmenu .floor .popup .boundary-checkbox";

/*所有材质  开始*/
var global_material_rot_slider = '.contextmenu .material .slider_pattern_angle';
var global_material_rot_text = '.contextmenu .material .slider_pattern_angle_text';

var global_material_hmove_slider = '.contextmenu .material .slider_pattern_horizontal_move';
var global_material_hmove_text = '.contextmenu .material .slider_pattern_horizontal_text';

var global_material_vmove_slider = ".contextmenu .material .slider_pattern_vertical_move";
var global_material_vmove_text = '.contextmenu .material .slider_pattern_vertical_text';

var global_material_zoom_height_slider = ".contextmenu .material .slider_pattern_zoom_height";
var global_material_zoom_height_text = '.contextmenu .material .slider_pattern_zoom_height_text';

var global_material_zoom_width_slider = ".contextmenu .material .slider_pattern_zoom_width";
var global_material_zoom_width_text = '.contextmenu .material .slider_pattern_zoom_width_text';

var global_material_zoom_radius_slider = ".contextmenu .material .slider_pattern_zoom_radius";
var global_material_zoom_radius_text = '.contextmenu .material .slider_pattern_zoom_radius_text';

var global_material_reset_button = ".contextmenu .material .tab_footer .reset";
var global_material_add_goodslist_checkbox = ".contextmenu .material .add_goodslist_checkbox";

var global_material_single_advanced_icon = ".contextmenu .material .button_single_advanced_pattern";
var global_material_group_advanced_icon = ".contextmenu .material .button_group_advanced_pattern";
var global_material_parquet_edit_icon = ".contextmenu .material .button_parquet_edit";

var global_material_area_place_top_icon = ".contextmenu .material .button_area_place_top";
var global_material_area_place_buttom_icon = ".contextmenu .material .button_area_place_bottom";
var global_material_area_delete_icon = ".contextmenu .material .button_area_delete";
var global_material_area_copy_icon = ".contextmenu .material .button_area_copy";
var global_material_area_expand_icon = ".contextmenu .material .button_area_expand";
var global_material_area_edit_icon = ".contextmenu .material .button_area3d_edit";

/*所有材质  结束*/

/* 区域操作  开始 */
//add by  gaoning 2017.3.9
var global_freearea_cavern = '.contextmenu .area .free-cavern-checkbox'

var global_rectarea_fixation = '.contextmenu .area  .fixation';
var global_rectarea_cavern = '.contextmenu .area .rect-cavern-checkbox';

var twod_rectarea_angle_slider = '.contextmenu .area .popup .slider-rectarea-angle-move';
var twod_rectarea_angle_text = '.contextmenu .area .popup .slider-rectarea-angle-text';

var global_rectarea_height_slider = '.contextmenu .area .popup .slider-rectarea-height-move';
var global_rectarea_height_text = '.contextmenu .area .popup .slider-rectarea-height-text';
var global_rectarea_height_align_select = '.contextmenu .area .popup .align-height-select';

var global_rectarea_width_slider = ".contextmenu .area .popup .slider-rectarea-width-move";
var global_rectarea_width_text = '.contextmenu .area .popup .slider-rectarea-width-text';
var global_rectarea_width_align_select = '.contextmenu .area .popup .align-width-select';

var global_roundarea_radius_slider = '.contextmenu .area .popup .slider-roundarea-radius-move';
var global_roundarea_radius_text = ".contextmenu .area .popup .slider-roundarea-radius-text";
var global_roundarea_cavern = '.contextmenu .area .round-cavern-checkbox'

var threed_rectarea3d_ground_slider = ".contextmenu .area .popup .slider-rectarea3d-ground-move";
var threed_rectarea3d_ground_text = '.contextmenu .area .popup .slider-rectarea3d-ground-text';

var threed_rectarea3d_height3d_slider = ".contextmenu .area .popup .slider-rectarea3d-height3d-move";
var threed_rectarea3d_height3d_text = '.contextmenu .area .popup .slider-rectarea3d-height3d-text';

var threed_roundarea3d_ground_slider = '.contextmenu .area .popup .slider-roundarea3d-ground-move';
var threed_roundarea3d_ground_text = ".contextmenu .area .popup .slider-roundarea3d-ground-text";

var threed_roundarea3d_height3d_slider = '.contextmenu .area .popup .slider-roundarea3d-height3d-move';
var threed_roundarea3d_height3d_text = ".contextmenu .area .popup .slider-roundarea3d-height3d-text";

var threed_freearea3d_ground_slider = '.contextmenu .area .popup .slider-freearea3d-ground-move';
var threed_freearea3d_ground_text = ".contextmenu .area .popup .slider-freearea3d-ground-text";

var threed_freearea3d_height3d_slider = '.contextmenu .area .popup .slider-freearea3d-height3d-move';
var threed_freearea3d_height3d_text = ".contextmenu .area .popup .slider-freearea3d-height3d-text";

var threed_rectarea3d_angle_rotate_slider = '.contextmenu .area .popup .slider-rectarea3d-angle-rotate';
var threed_slider_rectarea3d_angle_rotate_text = ".contextmenu .area .popup .slider-rectarea3d-angle-rotate-text";

/* 区域操作  结束 */



/*柱子 地台 横梁*/
var global_structure_length_slider = '.contextmenu .structure .popup .slider-structure-length-move';
var global_structure_length_text = '.contextmenu .structure .popup .slider-structure-length-text';
var global_structure_width_slider = '.contextmenu .structure .popup .slider-structure-width-move';
var global_structure_width_text = '.contextmenu .structure .popup .slider-structure-width-text';
var global_structure_height_slider = '.contextmenu .structure .popup .slider-structure-height-move';
var global_structure_height_text = '.contextmenu .structure .popup .slider-structure-height-text';
var global_structure_ground_slider = '.contextmenu .structure .popup .slider-structure-ground-move';
var global_structure_ground_text = '.contextmenu .structure .popup .slider-structure-ground-text';
//add by gaoning 2017.4.26
var global_structure_ground_rotate_slider = '.contextmenu .structure .popup .slider-structure-ground-rotate';
var global_structure_ground_rotate_text = '.contextmenu .structure .popup .slider-structure-ground-rotate-text';

var global_structure_hide_icon = ".contextmenu .structure .popup .button_hide";  //柱子 地台 横梁隐藏按钮 add by zk
//add by zk 2017.5.8
var global_structure_modelName = ".contextmenu .structure .tab_ul .name";
var global_structure_delete_icon = ".contextmenu .structure .popup .button_delete";


/*墙*/
var twod_wall_length_text = '.contextmenu .wall .popup .slider-length-text';
var twod_wall_thickness_slider = '.contextmenu .wall .popup .slider-thickness-move';
var twod_wall_thickness_text = '.contextmenu .wall .popup .slider-thickness-text';
var twod_wall_transparent_slider = '.contextmenu .wall .popup .slider-transparent-move';
var twod_wall_transparent_text = '.contextmenu .wall .popup .slider-transparent-text';
var twod_wall_height_slider = ".contextmenu .wall .popup .slider-height-move";
var twod_wall_height_text = '.contextmenu .wall .popup .slider-height-text';
var twod_wall_reset_button = ".contextmenu .wall .popup .wall_footer .reset";
var twod_wall_break_icon = ".contextmenu .wall .popup .button_page_break";
var twod_wall_hide_icon = ".contextmenu .wall .popup .button_hide";
var twod_wall_show_icon = ".contextmenu .wall .popup .button_show";
var twod_wall_delete_icon = ".contextmenu .wall .popup .button_delete";
var twod_wall_bearing_checkbox = ".contextmenu .wall .popup .bearing-checkbox";
var twod_wall_bezier_checkbox = ".contextmenu .wall .popup .bezier-checkbox";

/*家具*/
var global_product_length_slider = ".contextmenu .product .popup .slider-length";
var global_product_length_text = ".contextmenu .product .popup .slider-length-text";

var global_product_width_slider = ".contextmenu .product .popup .slider-width";
var global_product_width_text = ".contextmenu .product .popup .slider-width-text";

var global_product_height_slider = ".contextmenu .product .popup .slider-height";
var global_product_height_text = ".contextmenu .product .popup .slider-height-text";

var global_product_ground_slider = ".contextmenu .product .popup .slider-ground";
var global_product_ground_text = ".contextmenu .product .popup .slider-ground-text";

//add by gaoning 2017.4.24
var global_product_rotate_slider = ".contextmenu .product .popup .slider-rotate";
var global_product_rotate_text = ".contextmenu .product .popup .slider-rotate-text";

//add by gaoning 2017.4.27
var global_product_x_rotate_slider = ".contextmenu .product .popup .slider-x-rotate";
var global_product_x_rotate_text = ".contextmenu .product .popup .slider-x-rotate-text";

var global_product_x_rotate_slider_div = ".contextmenu .product .popup .slider-x-rotate-div";
var global_product_y_rotate_slider_div = ".contextmenu .product .popup .slider-y-rotate-div";

//add by gaoning 2017.4.29
var global_product_y_rotate_slider = ".contextmenu .product .popup .slider-y-rotate";
var global_product_y_rotate_text = ".contextmenu .product .popup .slider-y-rotate-text";

//add by zk 2017.5.8
var global_product_modelName = ".contextmenu .product .tab_ul .name";

var global_product_hide_icon = ".contextmenu .product .popup .button_hide";
var global_product_copy_icon = ".contextmenu .product .popup .button_copy";
var global_product_delete_icon = ".contextmenu .product .popup .button_delete";
var global_product_info_icon = ".contextmenu .product .popup .button_info";

var global_product_zoom_checkbox = ".contextmenu .product .popup .tab_footer .zoom";
var global_product_flip_checkbox = ".contextmenu .product .popup .tab_footer .flip";
var global_product_flip_label = ".contextmenu .product .popup .tab_footer .fliplabel";
var global_product_reset_button = ".contextmenu .product .popup .tab_footer .reset";

var twod_product_light_elements = ".contextmenu .product .lighting_render";
var twod_product_group_elements = ".contextmenu .product .group";
var threed_product_tile_elements = ".contextmenu .product .tile";
var threed_product_material_color = ".contextmenu .product .popup .product3d-material-color_choose_widget";

var twod_group_close_button = ".contextmenu  .group_close";
var twod_group_detach_button = ".contextmenu  .group_detach";

var twod_product_light_switch_checkbox = ".contextmenu .product .light-switch-checkbox";
var twod_product_light_color_widget = ".contextmenu .product .light_color_widget";
var twod_product_light_color_value = ".contextmenu .product .light_color_value";
var twod_product_light_brightness_slider = ".contextmenu .product .popup .slider-light-brightness";
var twod_product_light_brightness_text = ".contextmenu .product .popup .slider-light-brightness-text";
var twod_product_light_reset = ".contextmenu .product .popup .light-reset";

var threed_wall_material_color = ".contextmenu .wall .popup .wall3d-material-color_choose_widget";
var threed_wall_details_tab = "#contextmenu3d .wall .popup .wall3d_info";

var reflection_input = ".contextmenu .render_reflection_input";
var reflection_glossiness_input = ".contextmenu .render_reflection_glossiness_input";

var ceramic_wall_height_slider = '.contextmenu .ceramic .popup .slider-wall-height-move';

//add by mond 波打线
var twod_boundary_size_slider = ".contextmenu .boundary .popup .slider-size-move";
var twod_boundary_size_text = ".contextmenu .boundary .popup .slider-size-text";
var twod_boundary_delete_icon = ".contextmenu .boundary .popup .button_delete";
var twod_boundary_rotate_icon = ".contextmenu .boundary .popup .rotate a";
var twod_boundary_bmove_slider = ".contextmenu .boundary .popup .slider_pattern_boundary_move";
var twod_boundary_bmove_text = ".contextmenu .boundary .popup .slider_pattern_boundary_text";

var twod_boundary_serif_icon = ".contextmenu .boundary .popup .rotate .serif";
var twod_boundary_corner_icon = ".contextmenu .boundary .popup .rotate .corner";
var twod_boundary_left_icon = ".contextmenu .boundary .popup .rotate .left";
var twod_boundary_right_icon = ".contextmenu .boundary .popup .rotate .right";

var threed_boundary_size_slider = "#contextmenu3d .boundary .popup .slider-size-move";
var threed_boundary_size_text = "#contextmenu3d .boundary .popup .slider-size-text";
var threed_boundary_delete_icon = "#contextmenu3d .boundary .popup .button_delete";
var threed_boundary_bmove_slider = "#contextmenu3d .boundary .popup .slider_pattern_3d_boundary_move";
var threed_boundary_bmove_text = "#contextmenu3d .boundary .popup .slider_pattern_3d_boundary_text";



//# sourceURL=ui/contextpopup/contextpopup_variable.js