/*关闭右键窗口*/
function closeContextMenu() {
    $(".area ").removeClass("hidden_menu")
    $(".contextmenu_root").hide();

}

/*右键窗口*/
var customTileFlag;
/*自定义拼花标记*/
function contextMenuPopup(viewType, position) {
    var picked = api.pickGetPicked(), pickType = "default";
    //console.warn(picked)
    if (picked && picked.length > 0) {
        pickType = picked[0].model.type.toLowerCase();
    }
    if (picked[0] && picked[0].model) {   //customTileFlag=pickedMaterial().category=="custom_tile";//TODO 这个方法貌似更简便 2017-05-27
        customTileFlag = picked[0].model.areaMaterial && (picked[0].model.areaMaterial.category == "custom_tile" || picked[0].model.areaMaterial.category =="customparquet") ;
        if(customTileFlag && picked[0].model.areaMaterial.category =="customparquet"){customTileFlag=2;}
        popContextMenu(viewType, pickType, position);
        initContextMenu(viewType, pickType);
    }

}

/*弹出右键窗口*/
function popContextMenu(viewType, type, position) {
    //console.warn(viewType)
    //console.warn(type)
    //console.warn(position)
    closeContextMenu();
    //pickedMaterial().type;//获取大类
    $("#contextmenu" + viewType).offset(position);
    $("#contextmenu" + viewType + " ." + type).show();
    /*计算最佳位置打开，默认显示在鼠标点的右下角*/
    var offset = $("#contextmenu" + viewType).offset();
    var height = $("#contextmenu" + viewType).height();
    var width = $("#contextmenu" + viewType).width();
    var winHeight = $(window).height();
    var winWidth = $(window).width();

    if (offset.top + height > winHeight) {
        $("#contextmenu" + viewType).offset({"top": position.top - ( offset.top + height - winHeight )});
    }

    if (offset.left + width > winWidth) {
        $("#contextmenu" + viewType).offset({"left": position.left - ( offset.left + width - winWidth )});
    }
    /*自定义拼花添加一个父类，控制滑动组件的显示隐藏*/
    if (customTileFlag) {
        $(".area ").addClass("hidden_menu");
        if(customTileFlag==2){
            $(".area ").removeClass("hidden_menu");
            $(global_material_group_advanced_icon).closest('li').hide()
        }
    }

}

/*点击关闭右键窗口*/
$("#paper2dsvg").on(click, function (e) {
    closeContextMenu();
    $('#contextmenu2d').appendTo($("body"));
});

$("#paper3d").on(click, function () {
    closeContextMenu();
    $('#contextmenu3d').appendTo($("body"));
});

$("#paper3dwebgl").on(click, function () {
    closeContextMenu();
});


/*2d添加右键菜单事件*/
$("#paper2dsvg").on("contextmenu", function (e) {
    if ($("#main-design-area").has("#paper2dsvg").length == 0)return;
    $('#contextmenu2d').appendTo($('#main-design-area'));
    e = e || window.event;
    contextMenuPopup("2d", {top: e.pageY + 15, left: e.pageX});
});

/*3d添加右键菜单事件*/
$("#paper3dwebgl").on("contextmenu", function (e) {
    if ($("#main-design-area").has("#paper3dwebgl").length == 0)return;
    $('#contextmenu3d').appendTo($('#main-design-area'));
    e = e || window.event;
    contextMenuPopup("3d", {top: e.pageY, left: e.pageX});
});

/*初始化右键窗口页面属性*/
function initContextMenu(viewType, type) {
    log("init===" + viewType + "  " + type);
    initContextMenuRenderReflectionFields();
    if (viewType == "3d") {
        switch (type) {
            case "wall":
                initContextMenuWall3d();
                break;

            case "pillar":
            case "basement":
            case "beam":
                initContextMenuMaterial();
                initContextMenuStructure();
                initContextMenuCube3d(type);
                break;

            case "rectarea":
            case "rectarea3d":
            case "wallboard":
            case "baseboard":
                initContextMenuRectarea3d_ui();
                initContextMenuRectarea3d();
                break;

            case "roundarea":
            case "roundarea3d":
                initContextMenuRoundarea3d_ui();
                initContextMenuRoundarea3d();
                break;
            case "freearea":
            case "freearea3d":
                initContextMenuFreearea3d_ui();
                initContextMenuFreearea3d();
                break;
            case "product":
            case "productreplacement":
            case "window":
            case "door":
                initContextMenuProduct("3d");
                initContextMenuProduct_ui();
                break;
            case "floor" :
                initContextMenuFloor();
                break;
            case "boundary":
                initContextMenuBoundary3d();
                break;
        }
    } else {//2d
        switch (type) {
            case "annotation":
                initContextMenuAnnotation();
                break;
            case "camera":
                initContextMenuCamera();
                break;
            case "group":
                initContextMenuGroup();
                break;
            case "floor" :
                initContextMenuFloor();
                break;
            case "product" :
            case "productreplacement":
            case "window":
            case "door":
                initContextMenuProduct();
                initContextMenuProduct_ui();
                break;
            case "freearea":
                initContextMenuArea();
                initContextMenuFreearea();
                initContextMenuFreearea_ui();
                break;
            case "rectarea":
                initContextMenuArea();
                initContextMenuRectarea();
                initContextMenuRectarea_ui();
                break;
            case "roundarea":
                initContextMenuArea();
                initContextMenuRoundarea();
                initContextMenuRoundarea_ui();
                break;
            case "wall":
                initContextMenuWall();
                initContextMenuWall_ui();
                break;

            case "pillar":
            case "basement":
            case "beam":
                initContextMenuStructure();
                break;
            case "boundary":
                initContextMenuBoundary();
                break;
        }
    }
}

/*初始化渲染参数*/
function initContextMenuRenderReflectionFields() {
    var mat = pickedMaterial();
    var disabled = "disabled";
    if (mat) {
        $(reflection_input).removeAttr(disabled).val(mat.reflection);
        $(reflection_glossiness_input).removeAttr(disabled).val(mat.reflection_glossiness);
    } else {
        $(reflection_input).attr(disabled, disabled).val("");
        $(reflection_glossiness_input).attr(disabled, disabled).val("");
    }
}

/*初始化瓷砖贴图信息*/
function initContextMenuChartletInfo(type, meta) {
    if (meta == undefined) {
        $(".contextmenu ." + type + " .chartlet_content .chartlet_img").attr({"src": ''});
        $(".contextmenu ." + type + " .chartlet_content .chartlet_model").html("");
        $(".contextmenu ." + type + " .chartlet_content .chartlet_title").html("");
        $(".contextmenu ." + type + " .chartlet_content .chartlet_size").html("");
        return;
    }

    if (meta.pid === 'color') return;
    var imgUrl = api.catalogGetFileUrl("product", meta.pid, "iso");
    $(".contextmenu ." + type + " .chartlet_content .chartlet_img").attr({
        "src": imgUrl,
        "style": "width:82px;height:82px;"
    });
    $(".contextmenu ." + type + " .chartlet_content .chartlet_model").html((meta.model || ""));
    $(".contextmenu ." + type + " .chartlet_content .chartlet_title").html((meta.title || ""));
    $(".contextmenu ." + type + " .chartlet_content .chartlet_size").html((meta.xlen || 0) * 1000 + "x" + (meta.ylen || 0) * 1000 + "(mm)");


}

function initContextMenuAnnotation() {
    var model = api.pickGetPicked()[0].model;

    $(twod_annotation_content_color).spectrum({
        cancelText: "取消",
        chooseText: "选择", /*这两个属性其实初始化过了，这里不加显示英文，不知道咋回事*/
        color: model.textcolor
    });
    $(twod_annotation_content_size).val(model.fontsize);
    var text = model.text == undefined ? "" : model.text;
    $(twod_annotation_content_text).val(text);
    $(twod_annotation_content_text).focus();
}

function initContextMenuCamera() {
    var camera = api.documentGetActiveCamera();
    if (camera.lock) {
        closeContextMenu();
    }
    $(twod_camera_name_text).val(camera.name);
    $(twod_camera_height_text).val(camera.z * 1000);
    $(twod_camera_visualangle_text).val(camera.hfov);
    $(twod_camera_pitch_text).val(camera.pitch);//增加俯仰角度

    $(twod_camera_height_slider).slider("value", camera.z);
    $(twod_camera_visualangle_slider).slider("value", camera.hfov);
    $(twod_camera_pitch_slider).slider("value", camera.pitch);//增加俯仰角度
}


function initContextMenuGroup() {
    var group = api.pickGetPicked()[0].model;
    $(twod_group_rotateangle_text).val(0);
    $(twod_group_rotateangle_slider).slider("value", 0);
    $(twod_group_name_text).val(group.name);
    if (group.id == "TempGroup") {
        $(twod_group_dialog_caption).html("临时组合");
        $(twod_group_edit_icon).hide();
        $(twod_group_makegroup_icon).show();
        $(twod_group_ungroup_icon).hide();
        $(twod_group_name_text).attr("disabled", "disabled");
    } else {
        $(twod_group_dialog_caption).html("组合");
        $(twod_group_edit_icon).show();
        $(twod_group_makegroup_icon).hide();
        $(twod_group_ungroup_icon).show();
        $(twod_group_name_text).removeAttr("disabled");
    }
}

function initContextMenuFloor() {
    var roomMat = api.pickGetPicked()[0].model;

    console.log(roomMat);

    $(twod_room_height_slider).slider("value", roomMat.height3d);
    $(twod_room_height_text).val(roomMat.height3d);

    var roomRoof = roomMat.flag & (1 << 12);
    if (roomRoof == 0) {
        $(twod_room_roof_checkbox).prop("checked", false);
    } else {
        $(twod_room_roof_checkbox).prop("checked", true);
    }

    $(twod_room_name_select).css("display", "none");
    $(twod_room_name_text).val(roomMat.label);

    if (pickedMaterial().type == 'PARQUET') {
        $(global_material_single_advanced_icon).parents("li").hide();
        $(global_material_parquet_edit_icon).parents("li").show();
    } else if (pickedMaterial().type == 'MATERIAL' || pickedMaterial().type == 'TILESINGLE') {
        $(global_material_single_advanced_icon).parents("li").show();
        $(global_material_parquet_edit_icon).parents("li").hide();
    }
    initContextMenuMaterial();
}

function initContextMenuProduct() {
    var model = api.pickGetPicked()[0].model;
    //console.warn(model);
    var meta = model.meta;
    $(global_product_length_text).val(Math.ceil(model.sx * meta.xlen * 1000));
    $(global_product_width_text).val(Math.ceil(model.sy * meta.ylen * 1000));
    $(global_product_height_text).val(Math.ceil(model.sz * meta.zlen * 1000));
    $(global_product_ground_text).val(Math.ceil(model.z * 1000));
    //产品 add by gaoning 2017.4.24
    $(global_product_rotate_text).val(Math.ceil(model.rot));
    //产品X add by gaoning 2017.4.27
    $(global_product_x_rotate_text).val(Math.ceil(model.rotx));
    //产品Y add by gaoning 2017.4.29
    $(global_product_y_rotate_text).val(Math.ceil(model.roty));
    //地台 add by gaoning 2017.4.25
    $(global_structure_ground_rotate_text).val(Math.ceil(model.rot));

    //右键窗口标题显示模型名称add by zk  2017.5.8
    $(global_product_modelName).text(model.meta.title + model.index);

    $(global_product_length_slider).slider("value", model.sx * 100);
    $(global_product_width_slider).slider("value", model.sy * 100);
    $(global_product_height_slider).slider("value", model.sz * 100);
    $(global_product_ground_slider).slider("value", Math.ceil(model.z * 1000) / 1000);

    //产品 add by gaoning 2017.4.24
    $(global_product_rotate_slider).slider("value", model.rot);
    //产品X add by gaoning 2017.4.27
    $(global_product_x_rotate_slider).slider("value", model.rotx);
    //产品Y add by gaoning 2017.4.27
    $(global_product_y_rotate_slider).slider("value", model.roty);
    //地台 add by gaoning 2017.4.5
    $(global_structure_ground_rotate_slider).slider("value", model.rot);

    /*
     if(model.type == "DOOR" || model.type == "WINDOW"){
     $(global_product_flip_checkbox).css("display","none");
     $(global_product_flip_label).css("display","none");
     }else{
     $(global_product_flip_checkbox).css("display","inline-block");
     $(global_product_flip_label).css("display","inline-block");
     }*/

    if (model.flip) {
        $(global_product_flip_checkbox).prop("checked", true);
    } else {
        $(global_product_flip_checkbox).prop("checked", false);
    }

    //点击的物体为门窗时，不显示XY轴的旋转。-- add by gaoning 2017.11.7
    if(model.type == "DOOR" || model.type == "WINDOW"){
        $(global_product_x_rotate_slider_div).hide();
        $(global_product_y_rotate_slider_div).hide();
    }else{
        $(global_product_x_rotate_slider_div).show();
        $(global_product_y_rotate_slider_div).show();
    }

    initContextMenuMaterial();
    if (arguments[0] == '3d') {
    	  $(global_material_parquet_edit_icon).parents("li").hide();
    	  
        var productMat = pickedMaterial();
        if (productMat) {
            /*物体涂颜色*/
            if ("MATERIALRAWCOLOR" === productMat.type) {
                $(".tile_pattern_content").hide();
                $(".color_pattern_content").show();
                var hexColor = colorHexString(productMat.diffuse_r, productMat.diffuse_g, productMat.diffuse_b);

                $(threed_product_material_color).spectrum({
                    theme: "sp-light",
                    color: hexColor,
                    preferredFormat: "hex",
                    showInput: true,
                    showPalette: false,
                    cancelText: "取消",
                    chooseText: "选择"
                });

                $(threed_product_material_color).on("change.spectrum dragstop.spectrum", function (e, color) {

                    var colorRGB = color.toRgb();
                    api.actionBegin("SetGeneralProp", productMat);
                    api.actionRun("setbatch", {diffuse_r: colorRGB.r, diffuse_g: colorRGB.g, diffuse_b: colorRGB.b});
                    api.actionEnd("SetGeneralProp");
                });
                /*物体涂瓷砖*/
            } else if ("MATERIAL" === productMat.type) {
                $(".tile_pattern_content").show();
                $(".color_pattern_content").hide();
            } else if ("PARQUET" === productMat.type){
            	  $(global_material_parquet_edit_icon).parents("li").show();
                $(global_material_single_advanced_icon).parents("li").hide();
            }
        } else {
            $(".tile_pattern_content").show();
            $(".color_pattern_content").hide();
        }
    }

}

function initContextMenuArea() {
    /*拼花*/
    var patternMat = pickedMaterial();
    if (patternMat && patternMat.type == "PARQUET") {
        $(global_material_parquet_edit_icon).parents("li").show();
        $(global_material_single_advanced_icon).parents("li").hide();
    } else {
        $(global_material_parquet_edit_icon).parents("li").hide();
        $(global_material_single_advanced_icon).parents("li").show();
    }

    initContextMenuMaterial();
}

/*自由区域*/
function initContextMenuFreearea(){
    var freearea = api.pickGetPicked()[0].model;
    $(global_freearea_cavern).prop("checked", !!freearea.cavern);
}

/*矩形区域*/
function initContextMenuRectarea() {
    var rectarea = api.pickGetPicked()[0].model;
    $(global_rectarea_height_slider).slider("value", rectarea.height);
    $(global_rectarea_width_slider).slider("value", rectarea.width);
    $(twod_rectarea_angle_slider).slider("value", rectarea.rot);
    $(twod_rectarea_angle_text).val(Math.ceil(rectarea.rot * 1000) / 1000);
    $(global_rectarea_height_text).val(Math.ceil(rectarea.height * 1000));
    $(global_rectarea_width_text).val(Math.ceil(rectarea.width * 1000));
    
    $(global_rectarea_width_slider).slider({disabled: false});
    $(global_rectarea_width_text).attr({disabled: false});

    //区域边缘锁定
    $(global_rectarea_fixation).prop("checked", !!rectarea.fixation);
    $(global_rectarea_cavern).prop("checked", !!rectarea.cavern);
}

/*圆形区域*/
function initContextMenuRoundarea() {
    var roundarea = api.pickGetPicked()[0].model;
    $(global_roundarea_radius_slider).slider("value", roundarea.radius);
    $(global_roundarea_radius_text).val(Math.ceil(roundarea.radius * 1000));

    $(global_roundarea_cavern).prop("checked", !!roundarea.cavern);
}

/*3D墙面*/
function initContextMenuWall3d() {
    initContextMenuMaterial();

    var wallMat = pickedMaterial();
    if (wallMat) {
        /*墙面涂颜色*/
        if ("MATERIALRAWCOLOR" === wallMat.type) {
            $(".tile_pattern_content").hide();
            $(".color_pattern_content").show();
            var hexColor = colorHexString(wallMat.diffuse_r, wallMat.diffuse_g, wallMat.diffuse_b);

            $(threed_wall_material_color).spectrum({
                theme: "sp-light",
                color: hexColor,
                preferredFormat: "hex",
                showInput: true,
                showPalette: false,
                cancelText: "取消",
                chooseText: "选择"
            });

            $(threed_wall_material_color).on("change.spectrum dragstop.spectrum", function (e, color) {
                var colorRGB = color.toRgb();
                api.actionBegin("SetGeneralProp", wallMat);
                api.actionRun("setbatch", {diffuse_r: colorRGB.r, diffuse_g: colorRGB.g, diffuse_b: colorRGB.b});
                api.actionEnd("SetGeneralProp");
            });
            /*墙面涂瓷砖*/
        } else if ("MATERIAL" === wallMat.type) {
            $(".tile_pattern_content").show();
            $(".color_pattern_content").hide();
        }
        /*墙面涂印花*/
        if (pickedMaterial().type == 'PARQUET') {
            $(".tile_pattern_content").show();
            $(".color_pattern_content").hide();
            $(global_material_single_advanced_icon).parents("li").hide();
            $(global_material_parquet_edit_icon).parents("li").show();
        } else if (pickedMaterial().type == 'MATERIAL' || pickedMaterial().type == 'TILESINGLE') {
            $(global_material_single_advanced_icon).parents("li").show();
            $(global_material_parquet_edit_icon).parents("li").hide();
        }

    } else {
        $(".tile_pattern_content").show();
        $(".color_pattern_content").hide();
        $(global_material_single_advanced_icon).parents("li").hide();
        $(global_material_parquet_edit_icon).parents("li").hide();
    }
}

/*3d结构表面材质*/
function initContextMenuMaterial() {
    var patternMat = pickedMaterial();
    if (patternMat) {
        contextMenuMaterialDisabled(false);
        var patternMeta = patternMat.meta;
        $(global_material_rot_slider).slider("value", patternMat.rot);
        $(global_material_rot_text).val(patternMat.rot);

        $(global_material_hmove_text).val(patternMat.tx * 1000);
        //$(twod_boundary_bmove_text).val(patternMat.tx * 1000);
        $(global_material_vmove_text).val(patternMat.ty * 1000);

        var xlen = patternMeta.xlen || 0, ylen = patternMeta.ylen || 0;
        $(global_material_zoom_height_slider).slider("value", Math.ceil(patternMat.sy * ylen * 1000) / 1000);
        $(global_material_zoom_height_text).val(Math.ceil(patternMat.sy * ylen * 1000));

        $(global_material_zoom_width_slider).slider("value", Math.ceil(patternMat.sx * xlen * 1000) / 1000);
        $(global_material_zoom_width_text).val(Math.ceil(patternMat.sx * xlen * 1000));

        var isAddGoodsList = patternMat.flag & (1 << 9);
        $(global_material_add_goodslist_checkbox).prop("checked", !isAddGoodsList);

        initContextMenuChartletInfo("material", patternMeta);
    } else {
        contextMenuMaterialDisabled(true);
        initContextMenuChartletInfo("material", undefined);
    }
}

/*柱子 地台 横梁 */
function initContextMenuStructure() {
    var model = api.pickGetPicked()[0].model;
    $(global_structure_length_slider).slider("value", model.sx);
    $(global_structure_length_text).val(Math.ceil(model.sx * 1000));

    $(global_structure_width_slider).slider("value", model.sy);
    $(global_structure_width_text).val(Math.ceil(model.sy * 1000));

    $(global_structure_height_slider).slider("value", model.sz);
    $(global_structure_height_text).val(Math.ceil(model.sz * 1000));

    $(global_structure_ground_slider).slider("value", model.z);
    $(global_structure_ground_text).val(Math.ceil(model.z * 1000));

    //地台 add by gaoning 2017.4.25
    $(global_structure_ground_rotate_slider).slider("value", model.rot);
    $(global_structure_ground_rotate_text).val(Math.ceil(model.rot));

    //右键窗口标题显示模型名称add by zk  2017.5.8
    $(global_structure_modelName).text(model.meta.title + model.index);
}

/*3d表面材质控件是否可用*/
function contextMenuMaterialDisabled(value) {
    $(global_material_rot_slider).slider({disabled: value});
    $(global_material_rot_text).attr("disabled", value);
    $(global_material_vmove_slider).slider({disabled: value});
    $(global_material_vmove_text).attr("disabled", value);
    $(global_material_hmove_slider).slider({disabled: value});
    $(global_material_hmove_text).attr("disabled", value);
    $(global_material_zoom_height_slider).slider({disabled: value});
    $(global_material_zoom_height_text).attr("disabled", value);
    $(global_material_zoom_width_slider).slider({disabled: value});
    $(global_material_zoom_width_text).attr("disabled", value);
    $(global_material_add_goodslist_checkbox).attr("disabled", value);
    //$(twod_boundary_bmove_slider).slider({disabled: value});
    //$(twod_boundary_bmove_text).attr("disabled", value);
}

function initContextMenuRectarea3d() {
    var model = api.pickGetPicked()[0].model;


    /*矩形区域*/
    $(global_rectarea_height_slider).slider("value", model.height);
    $(global_rectarea_width_slider).slider("value", model.width);
    $(global_rectarea_height_text).val(Math.ceil(model.height * 1000));
    $(global_rectarea_width_text).val(Math.ceil(model.width * 1000));
                        
    if(model.type == "WALLBOARD" || model.type == "BASEBOARD" || model.type == "RECTAREA3D" || model.type == "ROUNDAREA3D"){
	    var groundvalue = Math.ceil((model.center.y - model.height / 2) * 1000) / 1000;
	    $(	threed_rectarea3d_ground_slider).slider("value", groundvalue);
	    $(	threed_rectarea3d_ground_text).val(groundvalue * 1000);
	    
	    $(threed_rectarea3d_height3d_slider).hide();   
      $(threed_rectarea3d_height3d_text).hide();
	  }else{
	    $(	threed_rectarea3d_ground_slider).slider("value", model.z);
	    $(	threed_rectarea3d_ground_text).val(model.z * 1000);
	    
	    $(	threed_rectarea3d_height3d_slider).slider("value", model.height3d);
	    $(	threed_rectarea3d_height3d_text).val(model.height3d * 1000);
	    
	    $(  threed_rectarea3d_height3d_slider).show();   
      $(  threed_rectarea3d_height3d_text).show();
	  }

    /* Rectarea3d's value is saved at file(//# sourceURL=src\display\wall.js -》 RectArea.prototype -》 object: model) ，
     * 1：initialing the data here -》 contextpopup_init.js。
     * 2：get the model and data what we want(model.rot)
     * 3: onload  and show the data
     *  add by mdx 2017-07-13*/
    $(threed_rectarea3d_angle_rotate_slider).slider("value", model.rot);
    $(threed_slider_rectarea3d_angle_rotate_text).val(Math.ceil(model.rot * 1000) / 1000);
    
    initContextMenuMaterial();
}

function initContextMenuRoundarea3d() {
    var model = api.pickGetPicked()[0].model;

    /*圆形区域*/
    $(global_roundarea_radius_slider).slider("value", model.radius);
    $(global_roundarea_radius_text).val(Math.ceil(model.radius * 1000));

    if(model.type == "ROUNDAREA3D"){
	    var groundvalue = Math.ceil((model.center.y - model.radius) * 1000) / 1000;
	    $(threed_roundarea3d_ground_slider).slider("value", groundvalue);
	    $(threed_roundarea3d_ground_text).val(groundvalue * 1000);
	    
	    $(threed_roundarea3d_height3d_slider).hide();   
      $(threed_roundarea3d_height3d_text).hide();
	  }else{
	  	$(	threed_roundarea3d_ground_slider).slider("value", model.z);
	    $(	threed_roundarea3d_ground_text).val(model.z * 1000);
	    
	    $(	threed_roundarea3d_height3d_slider).slider("value", model.height3d);
	    $(	threed_roundarea3d_height3d_text).val(model.height3d * 1000);
	    
	    $(  threed_roundarea3d_height3d_slider).show();   
      $(  threed_roundarea3d_height3d_text).show();
	  }
    

    initContextMenuMaterial();
}

function initContextMenuFreearea3d() {
    var model = api.pickGetPicked()[0].model;

    /*自由区域*/
    if(model.type == "FREEAREA"){
	    $(threed_freearea3d_ground_slider).slider("value", model.z);
	    $(threed_freearea3d_ground_text).val(model.z * 1000);	 
	    
	    $(threed_freearea3d_height3d_slider).slider("value", model.height3d);
	    $(threed_freearea3d_height3d_text).val(model.height3d * 1000);   
	  }    

    initContextMenuMaterial();
}

/*2d墙*/
function initContextMenuWall() {
    var wall = api.pickGetPicked()[0].model;
    $(twod_wall_height_slider).slider("value", wall.height3d);
    $(twod_wall_height_text).val(wall.height3d * 1000);

    $(twod_wall_thickness_slider).slider("value", wall.width);
    $(twod_wall_transparent_slider).slider("value", wall.transparent || 0);
    $(twod_wall_thickness_text).val(wall.width * 1000);
    $(twod_wall_transparent_text).val(wall.transparent || 0);

    var length = 0;
    if (wall && wall.begin && wall.end) length = Math.round(Math.sqrt((wall.begin.x - wall.end.x) * (wall.begin.x - wall.end.x) + (wall.begin.y - wall.end.y) * (wall.begin.y - wall.end.y)) * 1000);
    $(twod_wall_length_text).val(length);

    var isBearingWall = wall.flag & (1 << 10);
    $(twod_wall_bearing_checkbox).prop("checked", isBearingWall);
        
    $(twod_wall_bezier_checkbox).prop("checked", !!wall.bezier);
}

/*波打线*/
function initContextMenuBoundary() {
    var boundary = api.pickGetPicked()[0].model;

    $(twod_boundary_size_slider).slider("value", boundary.size);
    $(twod_boundary_size_text).val(boundary.size);

    boundarySlider(twod_boundary_bmove_slider,twod_boundary_bmove_text);

    var pickedOpt = api.pickGetPicked()[0].opt;
    var pickedSide = pickedOpt.side.split("_");
    if(pickedSide[0] == "base"){
        $(".gap_attr_content").show();
        if(boundary.baseOffsetX[parseInt(pickedSide[1])]){
            $(twod_boundary_bmove_text).val((boundary.baseOffsetX[parseInt(pickedSide[1])])*1000);
            $(twod_boundary_bmove_slider).slider("value", (boundary.baseOffsetX[parseInt(pickedSide[1])]));
        }else{
            $(twod_boundary_bmove_text).val(0);
            $(twod_boundary_bmove_slider).slider("value",0);
        }
    }else{
        $(".gap_attr_content").hide();
        //$(twod_boundary_bmove_text).val(0);
    }

    if (boundary.corner == "corner") {
        $(twod_boundary_corner_icon).attr("src", boundary.cornerMaterial.getUrl()).css("transform", "rotate(" + boundary.cornerRot + "deg)");
        $(twod_boundary_corner_icon).closest("div").show();
        $(twod_boundary_left_icon).closest("div").hide();
        $(twod_boundary_right_icon).closest("div").hide();
    }else if (boundary.corner == "cblr") {
    	  $(twod_boundary_corner_icon).attr("src", boundary.cornerMaterial.getUrl()).css("transform", "rotate(" + boundary.cornerRot + "deg)");
        $(twod_boundary_corner_icon).closest("div").show();        
        $(twod_boundary_left_icon).attr("src", boundary.leftMaterial.getUrl()).css("transform", "rotate(" + boundary.leftRot + "deg)");
        $(twod_boundary_left_icon).closest("div").show();        
        $(twod_boundary_right_icon).attr("src", boundary.rightMaterial.getUrl()).css("transform", "rotate(" + boundary.rightRot + "deg)");
        $(twod_boundary_right_icon).closest("div").show();
    }else {
        $(twod_boundary_corner_icon).closest("div").hide();
        $(twod_boundary_left_icon).closest("div").hide();
        $(twod_boundary_right_icon).closest("div").hide();
    }

    $(twod_boundary_serif_icon).attr("src", boundary.baseMaterial.getUrl()).css("transform", "rotate(" + boundary.baseRot + "deg)");

    var pm = pickedMaterial();
    if (pm.type == 'PARQUET') {
        $(global_material_single_advanced_icon).parents("li").hide();
        $(global_material_parquet_edit_icon).parents("li").show();
    } else if (pm.type == 'MATERIAL' || pm.type == 'TILESINGLE') {
        $(global_material_single_advanced_icon).parents("li").show();
        $(global_material_parquet_edit_icon).parents("li").hide();
    }

    //测试调整波打线砖缝偏移 开始
/*    var pickedOpt = api.pickGetPicked()[0].opt;
    var pickedSide = pickedOpt.side.split("_");
    if(pickedSide[0] == "base"){
    	//只有base段提供砖缝偏移
    	api.actionBegin("SetBoundaryGapOffsetX", boundary, parseInt(pickedSide[1]), 0.5);
    	//boundary.baseOffsetX[parseInt(pickedSide[1])]
    }*/
    //调整波打线砖缝偏移 结束
    initContextMenuMaterial();
}

function initContextMenuBoundary3d() {
    var boundary = api.pickGetPicked()[0].model;
    $(threed_boundary_size_slider).slider("value", boundary.size);
    $(threed_boundary_size_text).val(boundary.size);

    boundarySlider(threed_boundary_bmove_slider,threed_boundary_bmove_text);

    var pickedOpt = api.pickGetPicked()[0].opt;
    var pickedSide = pickedOpt.side.split("_");
    if(pickedSide[0] == "base"){
        $(".gap_attr_content").show();
        if(boundary.baseOffsetX[parseInt(pickedSide[1])]){
            $(threed_boundary_bmove_text).val((boundary.baseOffsetX[parseInt(pickedSide[1])])*1000);
            $(threed_boundary_bmove_slider).slider("value", (boundary.baseOffsetX[parseInt(pickedSide[1])]));
        }else{
            $(threed_boundary_bmove_text).val(0);
            $(threed_boundary_bmove_slider).slider("value",0);
        }
    }else{
        $(".gap_attr_content").hide();
        //$(threed_boundary_bmove_text).val(0);
    }

    if (boundary.corner == "corner") {
        $(twod_boundary_corner_icon).attr("src", boundary.cornerMaterial.getUrl()).css("transform", "rotate(" + boundary.cornerRot + "deg)");
        $(twod_boundary_corner_icon).closest("div").show();
        $(twod_boundary_left_icon).closest("div").hide();
        $(twod_boundary_right_icon).closest("div").hide();
    }else if (boundary.corner == "cblr") {
    	  $(twod_boundary_corner_icon).attr("src", boundary.cornerMaterial.getUrl()).css("transform", "rotate(" + boundary.cornerRot + "deg)");
        $(twod_boundary_corner_icon).closest("div").show();        
        $(twod_boundary_left_icon).attr("src", boundary.leftMaterial.getUrl()).css("transform", "rotate(" + boundary.leftRot + "deg)");
        $(twod_boundary_left_icon).closest("div").show();        
        $(twod_boundary_right_icon).attr("src", boundary.rightMaterial.getUrl()).css("transform", "rotate(" + boundary.rightRot + "deg)");
        $(twod_boundary_right_icon).closest("div").show();
    }else {
        $(twod_boundary_corner_icon).closest("div").hide();
        $(twod_boundary_left_icon).closest("div").hide();
        $(twod_boundary_right_icon).closest("div").hide();
    }

    $(twod_boundary_serif_icon).attr("src", boundary.baseMaterial.getUrl()).css("transform", "rotate(" + boundary.baseRot + "deg)");

    var pm = pickedMaterial();
    if (pm.type == 'PARQUET') {
        $(global_material_single_advanced_icon).parents("li").hide();
        $(global_material_parquet_edit_icon).parents("li").show();
    } else if (pm.type == 'MATERIAL' || pm.type == 'TILESINGLE') {
        $(global_material_single_advanced_icon).parents("li").show();
        $(global_material_parquet_edit_icon).parents("li").hide();
    }
    initContextMenuMaterial();
}

//# sourceURL=ui/contextpopup/contextpopup_init.js