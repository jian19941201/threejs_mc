
/*左键弹出框*/

var global_leftcontextmenu_close_btn = '.leftcontextmenu .leftcontextmenu_root .leftpopup .close_btn';
var global_leftcontextmenu_leftpopup = '.leftcontextmenu .leftcontextmenu_root .leftpopup';
var global_leftcontextmenu_subpopup = '.leftcontextmenu .leftcontextmenu_root .sub_popup';
var global_leftcontextmenu_subpopup_close_btn = '.leftcontextmenu .leftcontextmenu_root .sub_popup .close_btn';
var global_leftcontextmenu_popup_content = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container .popup_content';
var global_leftcontextmenu_subProduceList = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container .subProduceList';
var global_leftcontextmenu_pavesubpopup = '.leftcontextmenu .leftcontextmenu_root .pave_sub_popup';
var global_leftcontextmenu_changesubpopup = '.leftcontextmenu .leftcontextmenu_root .change_sub_popup';

//地板
var global_leftcontextmenu_floor_leftpopup = '.leftcontextmenu .floor.leftcontextmenu_root .leftpopup';

//区域
var global_leftcontextmenu_area_leftpopup = '.leftcontextmenu .area.leftcontextmenu_root .leftpopup';
var globalRectAreaRot = '.leftcontextmenu .area  .leftpopup .sliderAreaRotMove';
var globalRectAreaText = '.leftcontextmenu .area  .leftpopup .sliderAreaRotText';
var globalRectAreaWidthSlide = '.leftcontextmenu .area  .leftpopup .sliderAreaWidthMove';
var globalRectAreaWidthText = '.leftcontextmenu .area  .leftpopup .sliderAreaWidthText';
var globalRectAreaHeightSlide = '.leftcontextmenu .area  .leftpopup .sliderAreaHeightMove';
var globalRectAreaHeightText = '.leftcontextmenu .area  .leftpopup .sliderAreaHeightText';
var globalAreaFloorHeightSlide = '.leftcontextmenu .area  .leftpopup .sliderAreaFloorHeightMove';
var globalAreaFloorHeightText = '.leftcontextmenu .area  .leftpopup .sliderAreaFloorHeightText';
var globalRoundAreaRadiusSlide = '.leftcontextmenu .area  .leftpopup .sliderAreaRadiusMove';
var globalRoundAreaRadiusText = '.leftcontextmenu .area  .leftpopup .sliderAreaRadiusText';
var globalAreaSizeSlide = '.leftcontextmenu .area  .leftpopup .sliderAreaSizeMove';
var globalAreaSizeText = '.leftcontextmenu .area  .leftpopup .sliderAreaSizeText';
var globalAreaEdgeLocking = '.leftcontextmenu .area  .leftpopup .edgeLocking';
var globalAreaHollowedOut = '.leftcontextmenu .area  .leftpopup .hollowedOut';
var globalAreaSettingContentList  = '.leftcontextmenu .area  .leftpopup .setting_contentList';
//对齐方式
var horizonMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderHorizonMove';
var horizonTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderHorizonText';

var verticalMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderVerticalMove';
var verticalTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderVerticalText';

var rotateMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderRotateMove';
var rotateTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderRotateText';


var brickMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderBrickWidthMove';
var brickTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .sliderBrickWidthText';

var brickColorWidget = ".leftcontextmenu .leftcontextmenu_root .leftpopup .brickSetting .brickColorWidget";
var brickShowColor = ".leftcontextmenu .leftcontextmenu_root .leftpopup .brickSetting .showBrickColor";
var brickShowColorTemp = ".leftcontextmenu .leftcontextmenu_root .leftpopup .brickSetting .showBrickColor_Temp";
var brickShowColorList = ".leftcontextmenu .leftcontextmenu_root .leftpopup .brickSetting .normalColor li";
var brickShowWidthList = ".leftcontextmenu .leftcontextmenu_root .leftpopup .brickSetting .normalBrickWidth li";
//房间设置
var roomHeightMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container04 .sliderRoomHeightMove';
var roomHeightTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container04 .sliderRoomHeightText';
var roomNameTextValue = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container04 .room_name_text';
var roomNameSelectspan='.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container04 .roomLabelInfo li.labelInfo';

//摄像机设置
var CameraHeightMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .sliderCameraHeightMove';
var CameraHeightTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .sliderCameraHeightText';
var CameraPitchMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .sliderCameraPitchMove';
var CameraPitchTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .sliderCameraPitchText';
var CameraVisionMoveSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .sliderCameraVisionMove';
var CameraVisionTextSlider = '.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .sliderCameraVisionText';

// 区域扩展

var AreaExpandAreaAdd ='.leftcontextmenu .leftcontextmenu_root.expand .radioDiv div';
var AreaExpandButton ='.leftcontextmenu .leftcontextmenu_root.expand .buttondiv button';

// 家具
var productLeftContextMenuUl = '.leftcontextmenu .product .tab_ul';
var productLeftContextMenuLl = '.leftcontextmenu .product .tab_ul li';
var ProductSliderLengthMove='.leftcontextmenu .product .sliderProductLengthMove';
var ProductSliderLengthText='.leftcontextmenu .product .sliderProductLengthText';
var ProductSliderWidthMove='.leftcontextmenu .product .sliderProductWidthMove';
var ProductSliderWidthText='.leftcontextmenu .product .sliderProductWidthText';
var ProductSliderHeightMove='.leftcontextmenu .product .sliderProductHeightMove';
var ProductSliderHeightText='.leftcontextmenu .product .sliderProductHeightText';
var ProductSliderFloorHeightMove='.leftcontextmenu .product .sliderProductFloorHeightMove';
var ProductSliderFloorHeightText='.leftcontextmenu .product .sliderProductFloorHeightText';
var ProductSliderRotMove='.leftcontextmenu .product .sliderProductRotMove';
var ProductSliderRotText='.leftcontextmenu .product .sliderProductRotText';
var GlobalProductZoom='.leftcontextmenu .product input.zoom ';
var GlobalProductflip='.leftcontextmenu .product input.mirror ';
var ProductSetReset='.leftcontextmenu .product button.productReset ';
var GroupDetach = '.leftcontextmenu .product .leftpopup .groupDetach';
var GroupClose = '.leftcontextmenu .product .leftpopup .groupClose';
var productLightColorWidget = ".leftcontextmenu .product .lightColorWidget";
var productLightShowColor = ".leftcontextmenu .product .showLightColor";
var productLightShowColorTemp = ".leftcontextmenu .product .showLightColor_Temp";
var productLightShowColorList = ".leftcontextmenu .product .normalColor li";
var productLightShowColorCheckBox = ".leftcontextmenu .product .box input[type='checkbox']";
var productLightShowColorBrightnessText= ".leftcontextmenu .product .box input[type='text']";
var productLightName= ".leftcontextmenu .product .box span.LightName";
var productLightAddNum= ".leftcontextmenu .product .box span.addNum";
var productLightSubNum= ".leftcontextmenu .product .box span.subNum";
var productLightReset= ".leftcontextmenu .product .lightReset";
//组合
var GroupSliderRotMove='.leftcontextmenu .group .sliderGroupRotMove';
var GroupSliderRotText='.leftcontextmenu .group .sliderGroupRotText';
var GroupNameText='.leftcontextmenu .group .GroupName';
var GroupReset='.leftcontextmenu .group .leftpopup  .groupReset';
//结构
var structureSliderWidthMove= ".leftcontextmenu .basementBeamPillar .sliderStructureWidthMove";
var structureSliderLengthMove='.leftcontextmenu .basementBeamPillar .sliderStructureLengthMove';
var structureSliderHeightMove='.leftcontextmenu .basementBeamPillar .sliderStructureHeightMove';
var structureSliderWidthText= ".leftcontextmenu .basementBeamPillar .sliderStructureWidthText";
var structureSliderLengthText='.leftcontextmenu .basementBeamPillar .sliderStructureLengthText';
var structureSliderHeightText='.leftcontextmenu .basementBeamPillar .sliderStructureHeightText';
var structureSliderFloorHeightMove='.leftcontextmenu .basementBeamPillar .sliderStructureFloorHeightMove';
var structureSliderFloorHeightText='.leftcontextmenu .basementBeamPillar .sliderStructureFloorHeightText';
var structureSliderRotMove='.leftcontextmenu .basementBeamPillar .sliderStructureRotMove';
var structureSliderRotText='.leftcontextmenu .basementBeamPillar .sliderStructureRotText';
//# sourceURL=ui/contextleftpopup/contextleftpopup_variable.js