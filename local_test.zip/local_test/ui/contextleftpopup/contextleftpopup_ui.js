/*关闭按钮事件*/
$(global_leftcontextmenu_close_btn).on("click", function (e) {
    popLeftContextMenuClose();
});

/*标签切换*/
$(global_leftcontextmenu_leftpopup).slide({
    trigger:"click",
    startFun: function (i,c) {
        $(".sub_popup").hide();
    }
});
$(global_leftcontextmenu_subpopup).slide({
    trigger:"click"
});
$(global_leftcontextmenu_popup_content).slide({
    trigger:"click",
    titCell:".attr_title .tab",
    mainCell:".wrap_produceList",
    startFun:function () {
        $(global_leftcontextmenu_changesubpopup).find(".close_btn").trigger('click')
    }
});

/*换砖收起详情*/
$(global_leftcontextmenu_leftpopup).on("click",".detail_btn",function(){
    $(this).parent().siblings(".subProduceList").toggle();
    $(this).toggleClass("on");
});
/*波打线弹出框*/
$('.waveLine .buttonDiv').on("click", function (e) {
    if($('.waveLineDiv .list li:visible').length>=3&&$('.waveLine_sub_popup').css('top')!='138px'){$('.waveLine_sub_popup').hide();layer.msg('一个空间内波打线最多3条');return;}
    if($('.waveLine_sub_popup').css('top')=='138px'&&$('.waveLine_sub_popup').is(':visible')){
        $('.waveLine_sub_popup').hide();
    }
    $('.waveLine_sub_popup').css({'left':'360px','top':'38px'}).toggle();
});

/*地板铺贴方式切换子弹出框*/
$(global_leftcontextmenu_floor_leftpopup).on("click",".pave_content .img_change", function (e) {
    $('.pave_sub_popup').show();
    $('.change_sub_popup').hide();
    $(".produceList .right_box").show();
    $(".produceList .arrow_box").hide();
});
/*区域铺贴方式切换子弹出框*/
$(global_leftcontextmenu_area_leftpopup).on("click",".pave_content .img_change", function (e) {
    $('.pave_sub_popup').show();
    $('.change_sub_popup').hide();
    $(".produceList .right_box").show();
    $(".produceList .arrow_box").hide();
});
/*波打线方式切换子弹出框*/
$(global_leftcontextmenu_leftpopup).on("click",".waveLine_content .img_change", function (e) {
    if($('.waveLine_sub_popup').css('top')=='38px'&&$('.waveLine_sub_popup').is(':visible')){
        $('.waveLine_sub_popup').hide();
    }
    $('.waveLine_sub_popup').css({'left':'360px','top':'138px'}).toggle();
});
$('.waveLine_sub_popup').on('click','.close_btn',function(){
    $(this).closest('.waveLine_sub_popup').hide();
});

/*替换瓷砖切换子弹出框*/
$(global_leftcontextmenu_leftpopup).on("click",".produceList .img_change", function (e) {
    $('.change_sub_popup').show();
    $('.pave_sub_popup').hide();
    $(this).parents(".produceList").find(".arrow_box").hide();
    $(this).parents(".produceList").find(".right_box").show();
    $(this).parents(".produceList").find(".items").removeClass("current");
    $(this).parents(".produceList").find(".subItems").removeClass("current");
    $(this).parents(".produceList").find(".subProduceList").removeClass("currentSubProduceList");

    $(this).parent().hide();
    // $(this).parent().next().show();
    $(this).parent().parent().addClass("current");
    $(this).parent().parent().siblings().removeClass("current");

    if($(this).parent().parent().attr("class") == "subItems current"){
        $(this).parent().parent().parent().addClass("currentSubProduceList");
    }else{
        $(".subProduceList ").removeClass("currentSubProduceList");
    }
});
/*子弹出框关闭*/
$(global_leftcontextmenu_pavesubpopup).on("click",".close_btn", function (e) {
    $(".produceList").find(".items").removeClass("current");
    $(".produceList").find(".subItems").removeClass("current");
    $(".produceList").find(".subProduceList").removeClass("currentSubProduceList");
    $(".pave_sub_popup").hide();
});
$(global_leftcontextmenu_changesubpopup).on("click",".close_btn", function (e) {
    $(".change_sub_popup").hide();
    $(".produceList").find(".items").removeClass("current");
    $(".produceList").find(".subItems").removeClass("current");
    $(".produceList").find(".subProduceList").removeClass("currentSubProduceList");
    $(".produceList .right_box").show();
    $(".produceList .arrow_box").hide();
});

/*ESC键关闭弹框*/
document.onkeydown = function(event){
    var e = event || window.event || arguments.callee.caller.arguments[0];
    if(e && e.keyCode == 27){
        $(".leftcontextmenu_root").hide();
    }
}

/*房间设置  --start--*/
//砖缝设置
/*加载砖缝颜色选择控件*/
$(brickColorWidget).spectrum({
    theme: "sp-light",
    color: "#f0f0f0", /*默认值*/
    preferredFormat: "hex",
    showInput: true,
    cancelText: "取消",
    chooseText: "选择",
    move:function (color) {
        var suffix =getBrickWorkType(this);
        $(brickShowColorTemp+suffix).css({
            "background":color.toHexString()
        }).show()
    },
    change:function (color) {
        var suffix =getBrickWorkType(this);
        $(brickShowColor+suffix).attr({
            "value": color.toHexString(),
            "rgb": color.toRgbString()
        }).css({
            "background":color.toHexString()
        })
        $(brickShowColorList+suffix).removeClass('on');
        setBrickColor( color.toHexString())
    },
    hide:function () {
        var suffix =getBrickWorkType(this);
        $(brickShowColorTemp+suffix).hide();
    }
});
$(brickShowColorList).click(function () {
    var suffix =getBrickWorkType(this);
    $(brickShowColorList+suffix).removeClass('on');
    $(this).addClass('on');
    var color=$(this).attr('value');
    var rgb=$(this).attr('rgb');
    $(brickColorWidget+suffix).spectrum("set",color);
    $(brickShowColor+suffix).attr({
        "value": color,
        "rgb": rgb
    }).css({
        "background":color
    })
    setBrickColor(color)
})
$(brickShowWidthList).click(function () {
    var suffix =getBrickWorkType(this);
    $(brickShowWidthList+suffix).removeClass('on');
    $(this).addClass('on');
    var value=$(this).attr('widthValue');
    $(brickTextSlider+suffix).val(parseFloat(value)*1000)
    $(brickMoveSlider+suffix).slider("value", parseFloat(value*1000));
    setBrickWidth(value);
})

$(brickTextSlider).bind("keypress blur", function (event) {
    var suffix =getBrickWorkType(this);
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        $(brickShowWidthList+suffix).removeClass('on');
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) <0){
            _this.val(0)
        }
        if (parseFloat(_this.val()) > 20){
            _this.val(20)
        }
        $(brickShowWidthList+suffix).each(function () {
            if ($(this).attr("widthValue") ==_this.val()/1000) {
                $(this).addClass('on')
            }
        });
        setBrickWidth(_this.val()/1000);
        _this.prev(".sliderContainer").find(".sliderBrickWidthMove ").slider("value", parseFloat(_this.val()));
        return false;
    }
});
$(verticalTextSlider).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;

        var model = modelType.type=="FLOOR"?modelType.floorMaterial:modelType.host.floorMaterial;
        api.actionBegin("MoveMat", model);
        api.actionRun("move", "y", "delta", _this.val()/1000);
        api.actionEnd("MoveMat");
        return false;
    }
});
$(horizonTextSlider).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;

        var model = modelType.type=="FLOOR"?modelType.floorMaterial:modelType.host.floorMaterial;
        api.actionBegin("MoveMat", model);
        api.actionRun("move", "x", "delta", _this.val()/1000);
        api.actionEnd("MoveMat");
        return false;
    }
});
$(rotateTextSlider).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) <0){
            _this.val(0)
        }
        if (parseFloat(_this.val()) > 360){
            _this.val(360)
        }
        var model = modelType.type=="FLOOR"?modelType.floorMaterial:modelType.host.floorMaterial;
        api.actionBegin("RotMat", model);
        api.actionRun("rot", "", _this.val());
        api.actionEnd("RotMat");
        _this.prev(".sliderContainer").find(".sliderRotateMove").slider("value", parseFloat(_this.val()));
        return false;
    }
});
//墙高设置
$(roomHeightMoveSlider).
slider({min: 2500, max: 8000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestop", function (e, ui) {
        $(roomHeightTextSlider).val(ui.value);
    }).on("slide", function (e, ui) {
});

$(roomHeightMoveSlider)
    .on("slidestart", function (e, ui) {
        var modelPick=api.pickGetPicked()[0].model;
        var model=modelPick;
        if(modelPick.type=='BOUNDARY'){
            model=modelPick.host
        }
        api.actionBegin("SetHeight3d", model);
    })
    .on("slide", function (e, ui) {
        var action = api.getCurrentAction();
        var modelPick=api.pickGetPicked()[0].model;
        var model=modelPick;
        if(modelPick.type=='BOUNDARY'){
            model=modelPick.host
        }
        !action && api.actionBegin("SetHeight3d", model);
        api.actionRun("set", ui.value/1000);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetHeight3d");
    });

$(roomHeightTextSlider).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()/1000) < 2.5){
            _this.val(2500)
        }
        if (parseFloat(_this.val()/1000) > 8){
            _this.val(8000)
        }
        var modelPick=api.pickGetPicked()[0].model;
        var model=modelPick;
        if(modelPick.type=='BOUNDARY'){
            model=modelPick.host
        }
        api.actionBegin("SetHeight3d",model);
        api.actionRun("set", parseFloat(_this.val()/1000));
        api.actionEnd("SetHeight3d");
        _this.prev(".sliderContainer").find(".sliderRoomHeightMove ").slider("value", parseFloat(_this.val()));
        return false;
    }
});

//波打线宽度调整
$('.sliderWaveLineWidthText').bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 1){
            _this.val(1)
        }
        if (parseFloat(_this.val()) > 200){
            _this.val(200)
        }

        var boundary = getSelectBoundary();

        if(!api.actionBegin("SetBoundarySize", boundary, Number(_this.val()/100))){
            layer.alert('波打线尺寸超过空间大小', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                layer.close(index);
            });
        }
        $(".sliderWaveLineWidth").slider("value",parseFloat(_this.val()));
        return false;
    }
});
//房间名称设置
$(roomNameTextValue).bind("keypress", function (event) {
    var _this = $(this);
    if (event.keyCode == 13) {
        if ($.trim(_this.val()) == '') return false;
        var label = $.trim(_this.val());
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "label", label);
        api.actionEnd("SetGeneralProp");
        _this.select();
        return false;
    }
});
/*房间设置  --end--*/
//波打线宽度
$('.sliderWaveLineWidth').slider({min: 1, max: 200, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestop", function (e, ui) {

        var boundary = getSelectBoundary();

        if(!api.actionBegin("SetBoundarySize", boundary, Number(ui.value/100))){
            layer.alert('波打线尺寸超过空间大小', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                layer.close(index);
            });
        }

        $('.sliderWaveLineWidthText').val(boundary.size*100);
    }).on("slide", function (e, ui) {

    //api.documentGetActiveCamera().z = ui.value/1000;
});
/*摄像机设置  --start--*/
///摄像机高度
$(CameraHeightMoveSlider).
slider({min: 200, max: 8000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestop", function (e, ui) {
        $(CameraHeightTextSlider).val(ui.value);
    }).on("slide", function (e, ui) {
    api.documentGetActiveCamera().z = ui.value/1000;
});

$(CameraHeightTextSlider).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()/1000) < 0.2){
            _this.val(200)
        }
        if (parseFloat(_this.val()/1000) > 8){
            _this.val(8000)
        }
        api.documentGetActiveCamera().z = parseFloat(_this.val()) / 1000;
        $(CameraHeightMoveSlider).slider("value",parseFloat(_this.val()));
        return false;
    }
});

///摄像机俯仰角度
$(CameraPitchMoveSlider).
slider({min: -75, max: 75, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        $(CameraPitchTextSlider).val(ui.value);
    }).on("slide", function (e, ui) {
    var camera = api.documentGetActiveCamera();
    camera.pitch = parseFloat(ui.value);
});

$(CameraPitchTextSlider).bind("keypress blur", function (event) {
    var _this = $(this);
    /*回车键*/
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*整数*/
        var positive_int = /^-?\d+$/;
        if (!positive_int.test(_this.val())) return false;
        if(parseFloat(_this.val()) < -75)_this.val(-75);
        if (parseFloat(_this.val()) > 75)_this.val(75);
        var camera = api.documentGetActiveCamera();
        camera.pitch = parseFloat(_this.val());
        $(CameraPitchMoveSlider).slider("value", _this.val());
        return false;
    }
});

///摄像机视角
$(CameraVisionMoveSlider).
slider({min: 30, max: 150, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "°"})
    .on("slidestop", function (e, ui) {
        $(CameraVisionTextSlider).val(ui.value);
    }).on("slide", function (e, ui) {
    api.documentGetActiveCamera().hfov = ui.value;
});
$(CameraVisionTextSlider).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*非负整数*/
        var positive_int = /^\d+$/;
        if (!positive_int.test(_this.val())) return false;
        if(parseFloat(_this.val()) < 30)_this.val(30);
        if (parseFloat(_this.val()) > 150)_this.val(150);
        api.documentGetActiveCamera().hfov = _this.val();
       $(CameraVisionMoveSlider).slider("value", _this.val());
        return false;
    }
});


$(document).on("keyup", null, "pageup", function () {
    var camera=api.documentGetActiveCamera();
    $(CameraHeightMoveSlider).slider("value", camera.z*1000);
    $(CameraHeightTextSlider).val(camera.z*1000);
})

$(document).on("keyup", null, "pagedown", function () {
    var camera=api.documentGetActiveCamera();
    $(CameraHeightMoveSlider).slider("value", camera.z*1000);
    $(CameraHeightTextSlider).val(camera.z*1000);
})

$(document).on("keydown", null, "alt+c", function () {
    var cameras = api.floorplanFilterEntity(function (e) {
        return e.type == "CAMERA";
    });
    var activeCamera = api.documentGetActiveCamera();
    var index=0;
    for (var i = 0; i < cameras.length; ++i) {
        var camera = cameras[i];
        if(activeCamera.id==camera.id){
            index=i+1;
            if(index>cameras.length-1)index=0;
        }
    }
    setCameraState(cameras[index])
})
/*摄像机设置  --end--*/

/*区域设置  --start--*/
$(globalRectAreaRot).
slider({min: 0, max: 360, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "°"})
    .on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(globalRectAreaText).val(ui.value)
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    var changeModel=getChangeModel(modelType)
    !action && api.actionBegin("SetGeneralProp", changeModel);
      api.actionRun("set", "rot", ui.value);
});

$(globalRectAreaText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        var rot = parseFloat(_this.val());
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp",changeModel);
        api.actionRun("set", "rot", rot);
        api.actionEnd("SetGeneralProp");
       $(globalRectAreaRot).slider("value", parseFloat(_this.val()));
        return false;
    }
});

$(globalRectAreaWidthSlide).
slider({min: 0, max: 4990, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(globalRectAreaWidthText).val(ui.value);
    }).on("slide", function (e, ui) {
        var alignMode = $(this).parents('.alignmentItem').find('.area-align-height-select').val();
        var model = getChangeModel(modelType), Vec2 = api.Vec2;
        var center = model.center, oldheight = model.height, newheight = ui.value/1000;
        var action = api.getCurrentAction();
        var changeModel=getChangeModel(modelType);
        !action && api.actionBegin("SetGeneralProp", changeModel);
        if (alignMode == "center") {
            api.actionRun("set", "width", newheight);
        } else {
            var align_dir = (alignMode == "top" ? -1 : 1);
            var newcenter = new Vec2(center.x, center.y + (newheight - oldheight) * align_dir / 2);
            var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
            var batch = {};
            batch[model.id] = {height: newheight};
            batch[model.center.id] = {x: center.x, y: center.y};
            api.actionRun("manymodelsetbatch", batch);
        }
    });

$(globalRectAreaWidthText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var alignMode = _this.parents('.alignmentItem').find('.area-align-height-select').val();
        var model = getChangeModel(modelType), Vec2 = api.Vec2;
        var center = model.center, oldheight = model.height, newheight = parseFloat(_this.val()) / 1000;
        api.actionBegin("SetGeneralProp", model);
        if (alignMode == "center") {
            api.actionRun("set", "width", newheight);
        } else {
            var align_dir = (alignMode == "top" ? -1 : 1);
            var newcenter = new Vec2(center.x, center.y + (newheight - oldheight) * align_dir / 2);
            var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
            var batch = {};
            batch[model.id] = {height: newheight};
            batch[model.center.id] = {x: center.x, y: center.y};
            api.actionRun("manymodelsetbatch", batch);
        }
        api.actionEnd("SetGeneralProp");
       $(globalRectAreaWidthSlide).slider("value", parseFloat(_this.val()));
        return false;
    }
});
$(globalRectAreaHeightSlide).
slider({min: 0, max: 4990, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(globalRectAreaHeightText).val(ui.value);
    }).on("slide", function (e, ui) {
    var alignMode = $(this).parents('.alignmentItem').find('.area-align-height-select').val();
    var model = getChangeModel(modelType), Vec2 = api.Vec2;
    var center = model.center, oldheight = model.height, newheight = ui.value/1000;
    var action = api.getCurrentAction();
    var changeModel=getChangeModel(modelType)
    !action &&  api.actionBegin("SetGeneralProp", changeModel);
    if (alignMode == "center") {
        api.actionRun("set", "height", newheight);
    } else {
        var align_dir = (alignMode == "top" ? -1 : 1);
        var newcenter = new Vec2(center.x, center.y + (newheight - oldheight) * align_dir / 2);
        var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
        var batch = {};
        batch[model.id] = {height: newheight};
        batch[model.center.id] = {x: center.x, y: center.y};
        api.actionRun("manymodelsetbatch", batch);
    }
});

$(globalRectAreaHeightText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var alignMode = _this.parents('.alignmentItem').find('.area-align-height-select').val();
        var model = getChangeModel(modelType), Vec2 = api.Vec2;
        var center = model.center, oldheight = model.height, newheight = parseFloat(_this.val()) / 1000;
        api.actionBegin("SetGeneralProp", model);
        if (alignMode == "center") {
            api.actionRun("set", "height", newheight);
        } else {
            var align_dir = (alignMode == "top" ? -1 : 1);
            var newcenter = new Vec2(center.x, center.y + (newheight - oldheight) * align_dir / 2);
            var center = Vec2.rotateAroundPoint(newcenter, center, model.rot * Math.PI / 180);
            var batch = {};
            batch[model.id] = {height: newheight};
            batch[model.center.id] = {x: center.x, y: center.y};
            api.actionRun("manymodelsetbatch", batch);
        }
        api.actionEnd("SetGeneralProp");
        $(globalRectAreaHeightSlide).slider("value", parseFloat(_this.val()));
        return false;
    }
});
$(globalAreaFloorHeightSlide).
slider({min: 0, max: 8000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(globalAreaFloorHeightText).val(ui.value);
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    var changeModel=getChangeModel(modelType)
    !action &&  api.actionBegin("SetGeneralProp", changeModel);
      api.actionRun("set", "z", ui.value/1000);
});

$(globalAreaFloorHeightText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
        api.actionRun("set", "z", _this.val()/1000);
        api.actionEnd("SetGeneralProp");
        $(globalAreaFloorHeightSlide).slider("value", parseFloat(_this.val()));
        return false;
    }
});

$(globalRoundAreaRadiusSlide).
slider({min: 0, max: 4990, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(globalRoundAreaRadiusText).val(ui.value);
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    var changeModel=getChangeModel(modelType)
    !action &&  api.actionBegin("SetGeneralProp", changeModel);
    api.actionRun("set", "radius", ui.value/1000);
});

$(globalRoundAreaRadiusText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "radius", parseFloat(_this.val()) / 1000);
        api.actionEnd("SetGeneralProp");
        $(globalRoundAreaRadiusSlide).slider("value", parseFloat(_this.val()));
        return false;
    }
});

$(globalAreaSizeSlide).
slider({min: -10000, max: 10000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(globalAreaSizeText).val(ui.value);
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    var changeModel=getChangeModel(modelType)
    !action &&  api.actionBegin("SetGeneralProp", changeModel);
      api.actionRun("set", "height3d", ui.value/1000);
});

$(globalAreaSizeText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        if (parseFloat(_this.val()) < 0) return false;
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0) return false;
        var changeModel=getChangeModel(modelType)
        api.actionBegin("SetGeneralProp", changeModel);
        api.actionRun("set", "height3d", _this.val()/1000);
        api.actionEnd("SetGeneralProp");
        $(globalAreaSizeSlide).slider("value", parseFloat(_this.val()));
        return false;
    }
});

$(AreaExpandAreaAdd).on('click',function(){
    $(this).siblings('div').find('span').removeClass('active')
    $(this).find('span').addClass('active');
})
$(AreaExpandButton).on("click",function () {
    var time =$('.leftcontextmenu .leftcontextmenu_root.expand .radioDiv div:eq(1) span').hasClass('active')?-1:1;
    var margin = time*$(".leftcontextmenu .leftcontextmenu_root.expand .sliderText").val() / 1000;

    var area = api.pickGetPicked()[0].model;

    var action = (area.type == "FREEAREA" ? "AddFreeArea" : (area.type == "RECTAREA" ? "AddRectArea" : "AddRoundArea"));
    api.actionBegin(action, area.category);
    api.actionRun("expand", area, margin);
    api.actionEnd(action);
})
/*区域设置 --end--*/

/*家具设置 ---start---*/
$(ProductSliderLengthMove).
slider({min: 0, max: 200, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "%"})
    .on("slidestart", function (e, ui) {
        $(this).parents('div.alignmentItem').find('input[type="text"]').blur();
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        var meta = api.pickGetPicked()[0].model.meta;
        var value=ui.value;
        value=value < 5 ? 5 : value;
        var cumulation_value = parseFloat(value / 100 * meta.xlen);
        var scale={x: value / 100}
        $(ProductSliderLengthText).val(Math.ceil(cumulation_value * 1000));
        $(this).slider({value:value});
        if ($(GlobalProductZoom).is(":checked")) {
            cumulation_value = parseFloat(value / 100 * meta.ylen);
            $(ProductSliderWidthText).val(Math.ceil(cumulation_value * 1000));
            $(ProductSliderWidthMove).slider({value:value});
            cumulation_value = parseFloat(value / 100 * meta.zlen);
            $(ProductSliderHeightText).val(Math.ceil(cumulation_value * 1000));
            $(ProductSliderHeightMove).slider({value:value});
            scale={x: value / 100, y: value / 100, z: value / 100};
        }
        api.actionRun("set", e, scale);
        api.actionEnd("ScaleProduct");
    })
    .on("slide", function (e, ui) {
    var model = api.pickGetPicked()[0].model, meta = model.meta;
    var scale = $(GlobalProductZoom).is(":checked") ? {x: ui.value / 100, y: ui.value / 100, z: ui.value / 100} : {x: ui.value / 100};
    if($(GlobalProductZoom).is(":checked")){
        $(ProductSliderWidthMove).slider({value: ui.value});
        $(ProductSliderHeightMove).slider({value: ui.value});
    }
    var action = api.getCurrentAction();
    !action && api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    api.actionRun("set", e, scale);
});

$(ProductSliderLengthText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        var val=(_this.val() / 1000) / meta.xlen;
        if(val< 0.05){
            val=0.05;
            _this.val(Math.ceil(val *1000 * meta.xlen))
        }
        if(val > 2){
            val=2;
            _this.val(Math.ceil(val *1000 * meta.xlen))
        }
        context_popup_api_scaleProduct(model, $(GlobalProductZoom).is(":checked"), "x", parseFloat(val));
       $(ProductSliderLengthMove).slider("value", parseFloat(val * 100));
        if ($(GlobalProductZoom).is(":checked")) {
            $(ProductSliderWidthMove).slider("value", parseFloat(val * 100));
            $(ProductSliderHeightMove).slider("value", parseFloat(val * 100));
            var width_text_value = val*1000 * meta.ylen;
            $(ProductSliderWidthText).val(parseFloat(Math.ceil(width_text_value)));
            var height_text_value = val*1000 * meta.zlen;
            $(ProductSliderHeightText).val(parseFloat(Math.ceil(height_text_value)));
        }
        return false;
    }
});
$(ProductSliderWidthMove).
slider({min: 0, max: 200, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "%"})
    .on("slidestart", function (e, ui) {
        $(this).parents('div.alignmentItem').find('input[type="text"]').blur();
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        var meta = api.pickGetPicked()[0].model.meta;
        var value=ui.value;
        value=value < 5 ? 5 : value;
        var cumulation_value = parseFloat(value / 100 * meta.ylen);
        var scale={y: value / 100};
        $(ProductSliderWidthText).val(Math.ceil(cumulation_value * 1000));
        $(this).slider({value:value});
        if ($(GlobalProductZoom).is(":checked")) {
            cumulation_value = parseFloat(value / 100 * meta.xlen);
            $(ProductSliderLengthText).val(Math.ceil(cumulation_value * 1000));
            $(ProductSliderLengthMove).slider({value: value});
            cumulation_value = parseFloat(value / 100 * meta.zlen);
            $(ProductSliderHeightText).val(Math.ceil(cumulation_value * 1000));
            $(ProductSliderHeightMove).slider({value: value});
            scale={x: value / 100, y: value / 100, z: value / 100};
        }
        api.actionRun("set", e, scale);
        api.actionEnd("ScaleProduct");
    }).on("slide", function (e, ui) {
    var model = api.pickGetPicked()[0].model, meta = model.meta;
    var scale = $(GlobalProductZoom).is(":checked") ? {x: ui.value / 100, y: ui.value / 100, z: ui.value / 100} : {y: ui.value / 100};
    if($(GlobalProductZoom).is(":checked")){
        $(ProductSliderLengthMove).slider({value: ui.value});
        $(ProductSliderHeightMove).slider({value: ui.value});
    }
    var action = api.getCurrentAction();
    !action && api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    api.actionRun("set", e, scale);
});

$(ProductSliderWidthText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        var val=(_this.val() / 1000) / meta.ylen;
        if(val< 0.05){
            val=0.05;
            _this.val(Math.ceil(val *1000 * meta.ylen))
        }
        if(val > 2){
            val=2;
            _this.val(Math.ceil(val *1000 * meta.ylen))
        }
        context_popup_api_scaleProduct(model, $(GlobalProductZoom).is(":checked"), "y", parseFloat(val));
        $(ProductSliderWidthMove).slider("value", parseFloat(val * 100));
        if ($(GlobalProductZoom).is(":checked")) {
            $(ProductSliderLengthMove).slider("value", parseFloat(val * 100));
            $(ProductSliderHeightMove).slider("value", parseFloat(val * 100));
            var width_text_value = val*1000 * meta.xlen;
            $(ProductSliderLengthText).val(parseFloat(Math.ceil(width_text_value)));
            var height_text_value = val*1000 * meta.zlen;
            $(ProductSliderHeightText).val(parseFloat(Math.ceil(height_text_value)));
        }
        return false;
    }
});
$(ProductSliderHeightMove).
slider({min: 0, max: 200, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "%"})
    .on("slidestart", function (e, ui) {
        $(this).parents('div.alignmentItem').find('input[type="text"]').blur();
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        var meta = api.pickGetPicked()[0].model.meta;
        var value=ui.value;
        value=value < 5 ? 5 : value;
        var cumulation_value = parseFloat(value / 100 * meta.zlen);
        var scale={z: value / 100};
        $(ProductSliderHeightText).val(Math.ceil(cumulation_value * 1000));
        $(this).slider({value: value});
        if ($(GlobalProductZoom).is(":checked")) {
            cumulation_value = parseFloat(value / 100 * meta.xlen);
            $(ProductSliderLengthText).val(Math.ceil(cumulation_value * 1000));
            $(ProductSliderLengthMove).slider({value: value});
            cumulation_value = parseFloat(value / 100 * meta.ylen);
            $(ProductSliderWidthText).val(Math.ceil(cumulation_value * 1000));
            $(ProductSliderWidthMove).slider({value: value});
            scale={x: value / 100, y: value / 100, z: value / 100};
        }
        api.actionRun("set", e, scale);
        api.actionEnd("ScaleProduct");
    }).on("slide", function (e, ui) {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        var scale = $(GlobalProductZoom).is(":checked") ? {x: ui.value / 100, y: ui.value / 100, z: ui.value / 100} : {z: ui.value / 100};
        if($(GlobalProductZoom).is(":checked")){
            $(ProductSliderLengthMove).slider({value: ui.value});
            $(ProductSliderWidthMove).slider({value: ui.value});
        }
        var action = api.getCurrentAction();
        !action && api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
        api.actionRun("set", e, scale);
});

$(ProductSliderHeightText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        var val=(_this.val() / 1000) / meta.zlen;
        if(val< 0.05){
            val=0.05;
            _this.val(Math.ceil(val *1000 * meta.zlen))
        }
        if(val > 2){
            val=2;
            _this.val(Math.ceil(val *1000 * meta.zlen))
        }
        context_popup_api_scaleProduct(model, $(GlobalProductZoom).is(":checked"), "z", parseFloat(val));
        $(ProductSliderHeightMove).slider("value", parseFloat(val * 100));
        if ($(GlobalProductZoom).is(":checked")) {
            $(ProductSliderLengthMove).slider("value", parseFloat(val * 100));
            $(ProductSliderWidthMove).slider("value", parseFloat(val * 100));
            var width_text_value = val*1000 * meta.xlen;
            $(ProductSliderLengthText).val(parseFloat(Math.ceil(width_text_value)));
            var height_text_value = val*1000 * meta.ylen;
            $(ProductSliderWidthText).val(parseFloat(Math.ceil(height_text_value)));
        }
        return false;
    }
});
$(ProductSliderFloorHeightMove).
slider({min: 0, max: 2800, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(ProductSliderFloorHeightText).val(ui.value);
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    !action && api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
     api.actionRun("set", "z", ui.value/1000);
});

$(ProductSliderFloorHeightText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 0){
            _this.val(0)
        }
        if (parseFloat(_this.val()/1000) > 2.8){
            _this.val(2800)
        }
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "z", parseFloat(_this.val() / 1000));
        api.actionEnd("SetGeneralProp");
       $(ProductSliderFloorHeightMove).slider("value", parseFloat(_this.val()));
        return false;
    }
});
$(ProductSliderRotMove).
slider({min: 0, max: 360, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "°"})
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    !action && api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    api.actionRun("set", "rot", ui.value);
    $(ProductSliderRotText).val(ui.value);
});

$(ProductSliderRotText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 0)_this.val(0)
        if( parseFloat(_this.val()) > 360) _this.val(360)
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "rot", parseFloat(_this.val() ));
        api.actionEnd("SetGeneralProp");
        $(ProductSliderRotMove).slider("value", parseFloat(_this.val()));
        return false;
    }
});

/*镜像翻转*/
$(GlobalProductflip).on("click", function (e) {
    if ($(this).is(":checked")) {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        context_popup_api_flipProduct(model, true);
    } else {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        context_popup_api_flipProduct(model, false);
    }
});
/*等比缩放*/
$(GlobalProductZoom).on("click", function (e) {
    if ($(this).is(":checked")) {
        var model = api.pickGetPicked()[0].model, meta = model.meta;
        $(ProductSliderLengthMove).slider({value: 100});
        $(ProductSliderLengthText).val(Math.ceil(parseFloat(meta.xlen) * 1000));
        $(ProductSliderWidthMove).slider({value: 100});
        $(ProductSliderWidthText).val(Math.ceil(parseFloat(meta.ylen) * 1000));
        $(ProductSliderHeightMove).slider({value: 100});
        $(ProductSliderHeightText).val(Math.ceil(parseFloat(meta.zlen) * 1000));
        context_popup_api_scaleProduct(model, true, "x", 1);
    }
});

$(ProductSetReset).on("click",function () {
    var model = api.pickGetPicked()[0].model;
    context_popup_api_scaleProduct(model, true, "x", 1);
    api.actionBegin("SetGeneralProp", model);
    api.actionRun("set", "rot", 0);
    api.actionRun("set", "z", 0);
    api.actionEnd("SetGeneralProp");
    productInfoListInt(model)
})


/*加载颜色选择控件*/
$(productLightColorWidget).spectrum({
    theme: "sp-light",
    color: "#f0f0f0", /*默认值*/
    preferredFormat: "hex",
    showInput: true,
    cancelText: "取消",
    chooseText: "选择",
    move:function (color) {
        $(productLightShowColorTemp).css({
            "background":color.toHexString()
        }).show()
    },
    change:function (color) {
        $(productLightShowColor).attr({
            "value": color.toHexString(),
            "rgb": color.toRgbString()
        }).css({
            "background":color.toHexString()
        })
        $(productLightShowColorList).removeClass('on');
        changeLightColor(color.toHexString(),color.toRgbString())
    },
    hide:function () {
        $(productLightShowColorTemp).hide();
    }
});

/*颜色修改事件*/
function changeLightColor(color,rgb) {
    if(color && rgb){
        var model = api.pickGetPicked()[0].model;
        var ud = model.userDefined = model.userDefined || {};
        var setting = ud.light_settings = ud.light_settings || {};
        setting.colorHex =color;
        setting.colorRgb = rgb;
    }
}
$(productLightShowColorList).click(function () {
    $(productLightShowColorList).removeClass('on');
    $(this).addClass('on');
    var color=$(this).attr('value');
    var rgb=$(this).attr('rgb');
    $(productLightColorWidget).spectrum("set",color);
    $(productLightShowColor).attr({
        "value": color,
        "rgb": rgb
    }).css({
        "background":color
    })
    changeLightColor(color,rgb)
})
$(productLightShowColorCheckBox).change(function () {
    var isOn = $(this).is(":checked");
    var model = api.pickGetPicked()[0].model;
    var ud = model.userDefined = model.userDefined || {};
    var setting = ud.light_settings = ud.light_settings || {};
    setting.on = isOn;
})

/*灯光倍增*/
$(productLightShowColorBrightnessText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    /*回车键*/
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)(\.\d+)?$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if (parseFloat(_this.val()) < 0)_this.val(0);
        var model = api.pickGetPicked()[0].model;
        var ud = model.userDefined = model.userDefined || {};
        var setting = ud.light_settings = ud.light_settings || {};
        setting.multiplier = parseFloat(_this.val());
        return false;
    }
});
$(productLightAddNum).click(function () {
    var text=$(this).parent('div').find('input[type="text"]');
    var Num=parseFloat($(text).val())+1;
    $(text).val(Num);
    $(text).trigger('blur');
})
$(productLightSubNum).click(function () {
    var text=$(this).parent('div').find('input[type="text"]');
    var Num=parseFloat($(text).val())-1;
    $(text).val(Num);
    $(text).trigger('blur');
})
/* 灯光属性 重设 */
$(productLightReset).on(click, function (e) {
    var model = api.pickGetPicked()[0].model;
    var ud = model.userDefined = model.userDefined || {};
    if (ud) delete ud.light_settings;
    initLeftContextMenuLightRenderSettings(model);
});
/*家具设置 ---end---*/

/*组合 --start--*/
/*退出组合编辑*/
$(GroupClose).on("click", function (e) {
    var product = api.pickGetPicked()[0].model;
    var group = product.group;
    if (group) {
        api.actionBegin("SetGeneralFlag", group);
        api.actionRun("set", 1 << 9, false);
        api.actionEnd("SetGeneralFlag");
        $('#ui_toolTipBnt').remove();
        popLeftContextMenuClose()
    }
});

/*从当前组合中分离*/
$(GroupDetach).on("click", function (e) {
    var product = api.pickGetPicked()[0].model;
    var group = product.group;
    if (group) {
        api.actionBegin("MakeGroup", group);
        api.actionRun("detach", undefined, product);
        api.actionEnd("MakeGroup");
        $(productLeftContextMenuUl).find('li.group').hide();
        $(productLeftContextMenuUl).find('li.name').trigger(click);
    }
});

$(GroupSliderRotMove).
slider({min: 0, max: 360, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "°"})
    .on("slidestart", function (e, ui) {
        this._start = ui.value;
        var model=api.pickGetPicked()[0].model;
        var group=(model.group?model.group:model);
        api.actionBegin("RotateGroup", group);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("RotateGroup");
        delete this._start;
    }).on("slide", function (e, ui) {
        var action = api.getCurrentAction();
        var model=api.pickGetPicked()[0].model;
        var group=(model.group?model.group:model);
        !action && api.actionBegin("RotateGroup", group);
        api.actionRun("contextmenu", e, ui.value - this._start,ui.value);
        this._start = ui.value;
        $(GroupSliderRotText).val(ui.value);
});

$(GroupSliderRotText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 0)_this.val(0)
        if( parseFloat(_this.val()) > 360) _this.val(360)
        var valueBefore = parseFloat($(GroupSliderRotMove).slider("value"));
        var valueAfter = parseFloat(_this.val());
        api.actionBegin("RotateGroup", api.pickGetPicked()[0].model);
        api.actionRun("contextmenu", event, valueAfter - valueBefore,parseFloat(_this.val()));
        api.actionEnd("RotateGroup");
        $(GroupSliderRotMove).slider("value", parseFloat(_this.val()));
        return false;
    }
});



/*组合名称*/
$(GroupNameText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        var group = api.pickGetPicked()[0].model;
        group.name = _this.val();
        return false;
    }
});
$(GroupReset).click(function () {
    return;
    var model=api.pickGetPicked()[0].model;
    var group=(model.group?model.group:model);
       group.children.forEach(function (e,i) {
           e.rot=0
       })
    api.actionBegin("RotateGroup", group);
    api.actionRun("contextmenu", event, 0);
    api.actionEnd("RotateGroup");
    $(GroupSliderRotMove).slider("value", 0);
})

/*组合 --end--*/

$('.osnAddSubControl').on('click','span',function(){
    var isAdd = $(this).hasClass('addNum'),
        p = $(this).closest('.osnAddSubControl'),
        step = p.attr('step')*1,
        max = p.attr('max')*1,
        min = p.attr('min')*1,
        parent=p.parent('div'),
        text=parent.find('input[type="text"]');
    var num = isAdd ? $(text).val()*1+step : $(text).val()*1-step;
    min && num<min && (num = min);
    max && num>max && (num = max);
    $(text).val(num);
    $(text).trigger('blur');
})
/*结构 --start--*/
$(structureSliderLengthMove).
slider({min: 40, max: 10000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        $(structureSliderLengthText).val(ui.value);
        api.actionEnd("ScaleProduct");
    })
    .on("slide", function (e, ui) {
        var action = api.getCurrentAction();
        !action && api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
        var scale = {x: ui.value / 1000};
        api.actionRun("set", e, scale);
    });

$(structureSliderLengthText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 40)_this.val(40)
        if(parseFloat(_this.val()) > 10000) _this.val(10000)
        var model = api.pickGetPicked()[0].model;
        var val=(_this.val() / 1000);
        context_popup_api_scaleProduct(model, false, "x", parseFloat(val));
        $(structureSliderLengthMove).slider("value", parseFloat(val * 1000));
        return false;
    }
});
$(structureSliderWidthMove).
slider({min: 40, max: 10000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    }).on("slidestop", function (e, ui) {
        $(structureSliderWidthText).val(ui.value);
        api.actionEnd("ScaleProduct");
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    !action && api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    var scale = {y: ui.value / 1000};
    api.actionRun("set", e, scale);
});

$(structureSliderWidthText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 40)_this.val(40)
        if(parseFloat(_this.val()) > 10000) _this.val(10000)
        var val=(_this.val() / 1000);
        var model = api.pickGetPicked()[0].model;
        context_popup_api_scaleProduct(model, false, "y", parseFloat(val));
        $(structureSliderWidthMove).slider("value", parseFloat(val * 1000));
        return false;
    }
});
$(structureSliderHeightMove).
slider({min: 40, max: 10000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        $(structureSliderHeightText).val(ui.value);
        api.actionEnd("ScaleProduct");
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    !action && api.actionBegin("ScaleProduct", api.pickGetPicked()[0].model);
    var scale = {z: ui.value / 100};
    api.actionRun("set", e, scale);
});

$(structureSliderHeightText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 40)_this.val(40)
        if(parseFloat(_this.val()) > 10000) _this.val(10000)
        var model = api.pickGetPicked()[0].model;
        var val=(_this.val() / 1000);
        context_popup_api_scaleProduct(model, false, "z", parseFloat(val));
        $(structureSliderHeightMove).slider("value", parseFloat(val * 1000));
        return false;
    }
});
$(structureSliderFloorHeightMove).
slider({min: 0, max: 5000, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
        $(structureSliderFloorHeightText).val(ui.value);
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    !action && api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    api.actionRun("set", "z", ui.value/1000);
});

$(structureSliderFloorHeightText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 0){
            _this.val(0)
        }
        if (parseFloat(_this.val()/1000) > 5){
            _this.val(5000)
        }
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "z", parseFloat(_this.val() / 1000));
        api.actionEnd("SetGeneralProp");
        $(structureSliderFloorHeightMove).slider("value", parseFloat(_this.val()));
        return false;
    }
});
$(structureSliderRotMove).
slider({min: 0, max: 360, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "°"})
    .on("slidestart", function (e, ui) {
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    })
    .on("slidestop", function (e, ui) {
        api.actionEnd("SetGeneralProp");
    }).on("slide", function (e, ui) {
    var action = api.getCurrentAction();
    !action && api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
    api.actionRun("set", "rot", ui.value);
    $(structureSliderRotText).val(ui.value);
});

$(structureSliderRotText).bind("keypress blur", function (event) {
    var _this = $(this);
    if (event.type == "blur") {
        saveValue();
    } else {
        /*回车键*/
        if (event.keyCode == 13) {
            saveValue();
            _this.select();
        }
    }
    function saveValue() {
        /*浮点数*/
        var positive_float = /^(-?\d+)$/;
        if (!positive_float.test(parseFloat(_this.val()))) return false;
        if(parseFloat(_this.val()) < 0)_this.val(0)
        if( parseFloat(_this.val()) > 360) _this.val(360)
        api.actionBegin("SetGeneralProp", api.pickGetPicked()[0].model);
        api.actionRun("set", "rot", parseFloat(_this.val() ));
        api.actionEnd("SetGeneralProp");
        $(structureSliderRotMove).slider("value", parseFloat(_this.val()));
        return false;
    }
});

/*结构 --end--*/
//# sourceURL=ui/contextleftpopup/contextleftpopup_ui.js