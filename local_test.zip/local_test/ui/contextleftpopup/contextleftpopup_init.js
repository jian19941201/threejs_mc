/*;(function(window){
    var h = {};

    window.$contextleftpopup = h;
})(window);*/
var tool_tip_bnt;
/*左键窗口*/
var modelType;
var paveMaterialType;
var host = window.location.hostname;

function renderLeftPopupFun(model,materialType){
    var paveType = model.paveType;  //铺贴类型
    if(!paveType)return;
    var imgUrl = paveActionObj[paveType].url;  //对应的url
    if(host == "localhost" || host == "127.0.0.1"){
        imgUrl = "ui/catalog/"+imgUrl;
    };

    /*渲染铺贴样式*/
    var pave_content = '';
    pave_content+= '<img class="img_container" src="'+imgUrl+'"/>';
    pave_content+= '<div class="img_change"></div>';
    $(".leftcontextmenu .tab_container01 .pave_content").html(pave_content);

    /*渲染主砖*/
    var modelCategoryType = model[materialType].category;

    var floorMaterialUrl = model[materialType].getUrl();  //主砖url
    var floorMaterialName = model[materialType].meta.title || "请换砖";  //主砖名称
    var floorMaterialSize = (model[materialType].meta.xlen*1000 || 0)+'mm*'+(model[materialType].meta.ylen*1000 || 0)+'mm';  //主砖大小
    var itemsContent = '';
    itemsContent+= '<li class="items"  id="'+materialType+'" ><div class="left_box">';
    itemsContent+= '<img class="detail_img" src="'+floorMaterialUrl+'" category="'+model[materialType].category+'" pid="'+model[materialType].pid+'"/></div>';
    itemsContent+= '<div class="middle_box"><p>'+floorMaterialName+'</p><p>'+floorMaterialSize+'</p>';
    if(modelCategoryType == "parquet" || modelCategoryType == "customparquet"){
        itemsContent+= '<div class="detail_btn" style="display: none">收起详情</div>';
    }
    itemsContent+= '</div><div class="right_box"><div class="img_change"></div></div><div class="arrow_box" style="display:none"><div class="preArrow"></div><div class="nextArrow"></div></div>';
    itemsContent+= '</li>';
    $(".leftcontextmenu .tab_container01 .wrap_produceList .produceList").html(itemsContent);

    /*如果主砖是硬装拼花*/
    if(modelCategoryType == "parquet" || modelCategoryType == "customparquet"){
        $("<ul></ul>").addClass("subProduceList").appendTo(".leftcontextmenu .tab_container01 .wrap_produceList .produceList .items");
        var data = JSON.parse(model[materialType].meta.extra);
        renderParquet(data,"#"+materialType);
    }else{
        $(".detail_btn").hide();
    };
    /*渲染硬装拼花channels子砖*/
    function renderParquet(channelsData,paveIMaterial){
        $(".detail_btn").show();
        //客户自定义拼花
        var paveIMaterialCurrent = paveIMaterial.substring(1);
        if(paveIMaterial == "#"+materialType && model[materialType].userDefined && model[materialType].userDefined.parquet){
            channelsData = model[materialType].userDefined.parquet;
        }
        else if(paveIMaterial && model[paveIMaterialCurrent].userDefined && model[paveIMaterialCurrent].userDefined.parquet){
            channelsData = model[paveIMaterialCurrent].userDefined.parquet;
        }
        var channels = channelsData.channels;
        var channelsId = Object.keys(channels);
        var channelPidArray = [];
        for(var i = 0;  i < channelsId.length; ++i){
            channelPidArray.push(channels[channelsId[i]].pid);
        }
        api.catalogGetProductsMetaPromise(channelPidArray).then(function (rv) {
            $(".leftcontextmenu .tab_container01 .wrap_produceList .produceList "+paveIMaterial+" .subProduceList").empty();

            for (var i = 0; i < channelPidArray.length; ++i) {
                var channelPid =rv[channelPidArray[i]].pid;
                var channel_id = channelsId[i];
                var channelPidName = rv[channelPid].title;
                var channelPidSize = rv[channelPid].xlen*1000+'mm*'+rv[channelPid].ylen*1000+'mm';
                var url = channelPid == "none" ? "" : api.catalogGetFileUrl("product", channelPid, "top");
                var subItemsContent = "";
                subItemsContent+= '<li class="subItems"><div class="left_box">';
                subItemsContent+= '<img class="detail_img" src="'+url+'" pid="'+channelPid+'" category="'+rv[channelPid].category+'" channel_id="'+channel_id+'"/></div>';
                subItemsContent+= '<div class="middle_box"><p>'+channelPidName+'</p><p>'+channelPidSize+'</p></div>';
                subItemsContent+= '<div class="right_box"><div class="img_change"></div></div><div class="arrow_box" style="display:none"><div class="preArrow"></div><div class="nextArrow"></div></div></li>';
                $(".leftcontextmenu  .tab_container01 .wrap_produceList .produceList "+paveIMaterial+" .subProduceList").append(subItemsContent);
            }
        });
    };

    /*渲染次砖*/
    var paveType = model.paveType;  //铺贴类型
    var paveModel = api.getPaveTypeInfo(paveType);
    var paveModePidsLength;
    if(paveModel.pids !== undefined){
        paveModePidsLength = paveModel.pids.length;
    }
    if(paveModePidsLength){
        for(var i=0;i<paveModePidsLength;i++){
            var subItemsContent = '';
            var paveIMaterial = "pave" + i + "Material";
            if(model[paveIMaterial]){
                var modelCategory = model[paveIMaterial].category;
                
                var floorMaterialUrl = model[paveIMaterial].getUrl();  //次砖
                var floorMaterialName = model[paveIMaterial].meta.title;  //次砖名称
                var floorMaterialSize = model[paveIMaterial].meta.xlen*1000+'mm*'+model[paveIMaterial].meta.ylen*1000+'mm';  //次砖大小

                subItemsContent+= '<li class="items '+paveIMaterial+'" paveIMaterial="'+paveIMaterial+'"><div class="left_box">';
                subItemsContent+= '<img class="detail_img" src="'+floorMaterialUrl+'" category="'+model[paveIMaterial].category+'" paveMaterialType="'+paveIMaterial+'" pid="'+model[paveIMaterial].pid+'"/></div>';
                subItemsContent+= '<div class="middle_box"><p>'+floorMaterialName+'</p><p>'+floorMaterialSize+'</p>';
                if(modelCategory == "parquet" || modelCategory == "customparquet"){
                    subItemsContent+= '<div class="detail_btn" style="display: none">收起详情</div>';
                }
                subItemsContent+= '</div><div class="right_box"><div class="img_change"></div></div><div class="arrow_box" style="display:none"><div class="preArrow"></div><div class="nextArrow"></div></div></li>';
                $(".leftcontextmenu .tab_container01 .wrap_produceList .produceList").append(subItemsContent);
                if(modelCategory == "parquet" || modelCategory == "customparquet"){
                    $(".detail_btn").show();
                    $("<ul></ul>").addClass("subProduceList").appendTo(".leftcontextmenu .tab_container01 .wrap_produceList .produceList .items."+paveIMaterial);
                    var data = JSON.parse(model[paveIMaterial].meta.extra);
                    renderParquet(data,"."+paveIMaterial);
                }
            }
        }
    }
    $(rotateMoveSlider).slider("value", model[materialType].rot);
    $(rotateTextSlider).val(model[materialType].rot);

    $(horizonMoveSlider).slider("value", 0);
    $(horizonTextSlider).val(model[materialType].tx*1000);

    $(verticalMoveSlider).slider("value", 0);
    $(verticalTextSlider).val(model[materialType].ty*1000);

};

api.application_ready_event.add(function (setting) {
    var linksChangedFun = function(propertyName, oldValue, newValue){
        if(this.type == "FLOOR"){
          $(global_leftcontextmenu_subProduceList).remove();
          renderLeftPopupFun(this,"floorMaterial");
        }
        else if(this.type == "RECTAREA" || this.type == "ROUNDAREA" || this.type =="FREEAREA"){
            if(this.isdelete)return;
            $(global_leftcontextmenu_subProduceList).remove();
            renderLeftPopupFun(this,"areaMaterial");
        }
    };
    var modelLinksChangedFun = null;
    api.pickChangedEvent.add(function (event, result) {
        //evtAll.button == "0"点击鼠标左键,evtAll.button == "2"点击鼠标右键
        if(window.event && window.event.button == "0" ){
            switch(event){
                case "select":
                    var pickType = "default";
                    //var modelType;
                    modelType = result.model;
                    if (modelType) {
                        pickType = modelType.constructor.name.toLowerCase();
                        if(pickType=='door' || pickType=='windows' || pickType=='productreplacement')pickType='product';
                        if(pickType=='basement' || pickType=='beam' || pickType=='pillar')pickType='basementBeamPillar';
                    }
                    if (result && result.model) {
                        if(modelType.group){
                            var isGroup=api.getIsGroupFlag(modelType.group, 512);
                            isGroup && (modelType=modelType.group,pickType='group');
                        }
                        popLeftContextMenu(modelType,pickType);
                        modelLinksChangedFun = linksChangedFun.bind(result.model);
                        result.model.propertyChangedEvent.add(modelLinksChangedFun);
                         if(modelType.type=='BOUNDARY'){
                             //如果是波打线，并且监听host改动
                             modelLinksChangedFun = linksChangedFun.bind(result.model.host);
                             result.model.host.propertyChangedEvent.add(modelLinksChangedFun);
                         }
                        if(pickType=='group'){
                            setTimeout(function () {
                                tool_tip_bnt = new toolTipBnt(modelType,pickType,result.screenPos)
                            },100)
                        }else{
                            tool_tip_bnt = new toolTipBnt(modelType,pickType,result.screenPos);
                            tool_tip_bnt.type=="cameraClass" && (tool_tip_bnt.update('group_lock',modelType.lock?1:0))
                        }
                    }
                    break;
                case "unselect":
                   // if(result.model.group)return;
                    if(modelLinksChangedFun){
	                    result.model.propertyChangedEvent.remove(modelLinksChangedFun);
	                    if(modelType.type=='BOUNDARY'){
	                        //如果是波打线，移除监听host改动
	                        result.model.host.propertyChangedEvent.remove(modelLinksChangedFun);
	                    }
	                  }
	                  tool_tip_bnt&&tool_tip_bnt.destroy();
	                  popLeftContextMenuClose()
                    break;
            }
        }else{
            tool_tip_bnt&&tool_tip_bnt.destroy();
            popLeftContextMenuClose()
        }
    });
});
function popLeftContextMenuClose() {
    $(".produceList .right_box").show();
    $(".produceList .arrow_box").hide();
    $(".leftcontextmenu_root").hide();
    $(this).parents(".produceList").find(".items").removeClass("current");
    $(this).parents(".produceList").find(".subItems").removeClass("current");
    $(".produceList").find(".subProduceList").removeClass("currentSubProduceList");
};
/*弹出左键窗口*/
function popLeftContextMenu(model,type) {
	  if(type == "floor" || type == "rectarea" || type == "camera" || type == "expand" || type == 'product'
          || type == 'group' || type== 'basementBeamPillar' || type == 'boundary' || type =="roundarea" || type =="freearea"){
	  	if((type == 'boundary' && model.host.type=="FLOOR")){
            $("#leftcontextmenu2d .floor" ).show();
        }else if((type == 'boundary' && model.host.type!="FLOOR")){
            $("#leftcontextmenu2d .area" ).show();
        }else{
            $("#leftcontextmenu2d"+ " ." + type).show();
        }
	  	if( type == "floor" || (type == 'boundary' && model.host.type=="FLOOR")){
            var boundary = '',
                boundaries = '',
                currentBoundaries=[],
                floor = '',
                floorId = '',
                floors = '';
	        if(type == 'boundary'){
                boundary = model;
                floorId = model.host.id;
                $('.boundary.leftcontextmenu_root .tab_head .tab_ul li:eq(2)').click()
            }else{
                floor = model;
                floorId = model.id;
                $('.boundary.leftcontextmenu_root .tab_head .tab_ul li:eq(0)').click()
            }

            boundaries = api.floorplanFilterEntity(function (e) {
                return e.type == "BOUNDARY";
            })
            for(var i=0; i<boundaries.length; i++){
	            if(floorId == boundaries[i].host.id){
                    currentBoundaries[currentBoundaries.length] = boundaries[i];
                }
            }
            floors = api.floorplanFilterEntity(function (e) {
                return e.type == "FLOOR";
            })
            if(floor == ''){
	            for(var i=0; i<floors.length; i++){
	                if(floorId == floors[i].id ){
                        floor = floors[i];
                    }
                }
            }
            $(".sub_popup").hide();

            // if(floor==''){
            //     var area = api.floorplanFilterEntity(function (e) {
            //         return e.id == floorId;
            //     });
            //     if(area.length>0){
            //         $("#leftcontextmenu2d"+ " ." + type).hide();
            //         type=area[0].constructor.name.toLowerCase();
            //         $("#leftcontextmenu2d"+ " ." + type).show();
            //         /*铺贴加工*/
            //         paveProcessInit(area[0],type);
            //         /*砖缝设置*/
            //         setBrickWorkInit(area[0]);
            //         renderLeftPopupFun(area[0],"areaMaterial");
            //         /*波打线初始化*/
            //         setTimeout(function() {
            //             boundariesInit(currentBoundaries, boundary);
            //         },500)
            //         /*区域*/
            //         setAreaInit();
            //     }
            //     return;
            // }
            renderLeftPopupFun(floor,"floorMaterial");
            /*房间设置*/
            setRoomInit(floor);
            /*铺贴加工*/
            paveProcessInit(floor,type);
            /*波打线初始化*/
            setTimeout(function() {
                boundariesInit(currentBoundaries, boundary);
            },500)
            /*砖缝设置*/
            setBrickWorkInit(floor)
        }else if(type=='rectarea' || type=='roundarea' || type=='freearea' || (type == 'boundary' && model.host.type!="FLOOR")){
	        $(".sub_popup").hide();
            if(type == 'boundary'){
                var area = api.floorplanFilterEntity(function (e) {
                    return e.id == model.host.id;
                });
                if(area.length>0){
                    type=area[0].constructor.name.toLowerCase();
                    model=area[0];
                }
            }
            /*铺贴加工*/
            paveProcessInit(model,type);
            /*砖缝设置*/
            setBrickWorkInit(model);
            renderLeftPopupFun(model,"areaMaterial");
            if(type!='roundarea'){
                var boundaries = api.floorplanFilterEntity(function (e) {
                    return e.type == "BOUNDARY";
                })
                var   currentBoundaries=[];
                for(var i=0; i<boundaries.length; i++){
                    if(model.id == boundaries[i].host.id){
                        currentBoundaries[currentBoundaries.length] = boundaries[i];
                    }
                }
                setTimeout(function() {
                    boundariesInit(currentBoundaries, boundary);
                },500);
                $('#leftcontextmenu2d').find('.area.leftcontextmenu_root .tab_ul li').eq(2).show();
            }else{
                $('#leftcontextmenu2d').find('.area.leftcontextmenu_root .tab_ul li').eq(2).hide();
                $('#leftcontextmenu2d').find('.area.leftcontextmenu_root .tab_ul li').eq(0).trigger('click')
            }
            /*区域*/
            setAreaInit();
        }else if(type=='camera'){
            allCameraInit();
        }else if(type=='product'){
            productInfoListInt(model);
            productModelUiInit(model);
        }
        else if(type=='group'){
            GroupInfoListInit(model)
        }else if(type=='basementBeamPillar'){
            StructureInfoListInit(model)
        }
      }
};


/*铺贴方式列表渲染函数*/
function renderCeramicContent(ceramicType,ceramic){
    var CeramicContent = '';
    var host = window.location.hostname;
    pavingModelObj[ceramicType].forEach(function(e){
    	  var ceramicUrl = e.url;
        var ceramicName = e.name;
        var imgTitle = e.id;
        if(host == "localhost" || host == "127.0.0.1"){
            ceramicUrl = "ui/catalog/"+ceramicUrl;
        }
        CeramicContent+= '<li class="items"><img class="items_img" imgTitle="'+imgTitle+'" title="'+ceramicName+'" src="'+ ceramicUrl+'"/></li>';
    });
    $(".leftcontextmenu .sub_popup ."+ceramic).html(CeramicContent);
};
/*初始化单砖列表*/
renderCeramicContent("singleCeramic","singleCeramic");
renderCeramicContent("pavingModelList","pavingModelList");
/*点击标签刷新列表*/
$(global_leftcontextmenu_subpopup).on("click",".tab_head .tab",function(){
    var tabId = $(this).attr("id");
    if(tabId == "singleCeramicTab"){
        renderCeramicContent("singleCeramic","singleCeramic");
    }
    else if(tabId == "doubleCeramicTab"){
        renderCeramicContent("shuangzhuanModelList","doubleCeramic");
    }
    else{
        renderCeramicContent("duozhuanModelList","moreCeramic");
    }
});

$(global_leftcontextmenu_subpopup).on("click",".items_img",function(){
    var failAlert = function(){
        layer.alert('波打线添加失败', {title: '提示', skin: 'layui-layer-default'}, function (index) {
            layer.close(index);
        });
    }
    var title = $(this).attr("imgTitle");
    var id = paveIdObj[title].id;
    if(id.indexOf("waveLine") >=0){
        if($('.waveLineDiv .list li:visible').length>=3&&$('.waveLine_sub_popup').css('top')!='138px'){layer.msg('一个空间内波打线最多3条');return;}
        switch(id) {
            //波打线部分
            case "waveLine01":
                //转角波打线 "corner" 转角类型
                api.actionBegin("AddBoundary", {
                    type: "corner",
                    base: "paa17fb28c6b74500bbafcd81e5da7354",
                    corner: "p561cafec23e944ab89634bd0cbdc6b23",
                    size: 0.12
                }, failAlert);
                break;
            case "waveLine02":
                //切角波打线
                api.actionBegin("AddBoundary", {
                    type: "base",
                    base: "p2d0ccb1015624c2596555b0aaf501377",
                    corner: "p8f9b024e43e64dc0bf51d7da321ac613",
                    size: 0.12
                }, failAlert);
                break;
            case "waveLine03":
                //四件套波打线 corner + base + left + right 四件套
                api.actionBegin("AddBoundary", {
                    type: "cblr",
                    base: "p01212d0d2b2646f6a943cb3bf38b9b7c",
                    corner: "p8f9b024e43e64dc0bf51d7da321ac613",
                    left: "p4f8e2bc0c83240d4bc378ec81ffb4a40",
                    right: "p6abd67bb2bcf4104a3a3e79cf477484c",
                    cornerRot: 90,
                    size: 0.15
                }, failAlert);
                break;
        }

        var currentBoundaries=[],boundary,
            floorId = '',
            boundaries ='';

        var floor = [];
        // if(modelType.type=='BOUNDARY'){
        //     floorId = modelType.host.id;
        //     var floors = api.floorplanFilterEntity(function (e) {
        //         return e.type == "FLOOR";
        //     })
        //     for(var i=0; i<floors.length; i++){
        //         if(floorId == floors[i].id){
        //             floor = [floors[i]];
        //             break;
        //         }
        //     }
        //
        // }else{
        //     floorId = modelType.id;
        //     floor =[modelType];
        // }
        var changeModel=getChangeModel(modelType);
        floorId = changeModel.id;
        floor =[changeModel];
        if($('.waveLine_sub_popup').css('top')=='138px'){
            boundaries = api.floorplanFilterEntity(function (e) {
                return e.type == "BOUNDARY";
            })
            for(var i=0; i<boundaries.length; i++){
                if(floorId == boundaries[i].host.id){
                    currentBoundaries[currentBoundaries.length] = boundaries[i];
                }
            }
            floor = [currentBoundaries[$('.waveLineDiv .list li.active').index()]]
        }

        api.actionRun("view2d_mouseup", null,null,floor);
        api.actionEnd("AddBoundary");
        setTimeout(function(){
            currentBoundaries=[];
            boundaries = api.floorplanFilterEntity(function (e) {
                return e.type == "BOUNDARY";
            })
            for(var i=0; i<boundaries.length; i++){
                if(floorId == boundaries[i].host.id){
                    currentBoundaries[currentBoundaries.length] = boundaries[i];
                }
            }
            if($('.waveLine_sub_popup').css('top')=='138px'){
                boundary = currentBoundaries[$('.waveLineDiv .list li.active').index()];
            }else{
                boundary = currentBoundaries[currentBoundaries.length-1];
            }

            boundariesInit(currentBoundaries,boundary);
        },500)
    }else{
        var changeModel=getChangeModel(modelType);
        paveIdObj[title] && api.actionBegin("TilesingleChangePave", changeModel, paveIdObj[title].action);
    }
});

api.application_ready_event.add(function () {

    var currentSelectedCatalogId = undefined;

    var firstLevelSelect = "#firstLevelSelect";
    var firstLevelSelectUl = "#firstLevelSelect ul";
    var firstLevelSelectInput = "#firstLevelSelectInput";
    var secondLevelSelect = "#secondLevelSelect";
    var secondLevelSelectUl = "#secondLevelSelect ul";
    var secondLevelSelectInput = "#secondLevelSelectInput";
    var thirdLevelSelect = "#thirdLevelSelect";
    var thirdLevelSelectUl = "#thirdLevelSelect ul";
    var thirdLevelSelectInput = "#thirdLevelSelectInput";
    var styleSelect = "#styleSelect";
    var styleSelectUl = "#styleSelect ul";
    var styleSelectInput = "#styleSelectInput";
    var colorSelect = "#colorSelect";
    var colorSelectUl = "#colorSelect ul";
    var colorSelectInput = "#colorSelectInput";

    /*渲染替换瓷砖列表*/
    function renderProductSaturation(currentCategory){
        api.catalogGetCatalogTreePromise()
            .then(function (root) {
                $('#catalogList').empty();
                $('#areaCatalogList').empty();
                /*初始化一、二、三级目录 start*/
                var rootLevel = [root.children[0],root.children[1],root.children[4]];
                // var catalogLevel1;
                // if(currentCategory == "tile"){
                //     catalogLevel1 = root.children[0];
                // }else if(currentCategory == "parquet" ||currentCategory == "customparquet"){
                //     catalogLevel1 = root.children[4];
                // }
                var catalogLevel1= root.children[0];
                if(currentCategory == "parquet" ||currentCategory == "customparquet"){
                    catalogLevel1 = root.children[4];
                }
                var catalogLevel2 = undefined;
                var catalogLevel3 = undefined;
                catalogLevel1.children.forEach(function (level2, index2) {
                    if (index2 == 0) {
                        catalogLevel2 = level2;
                        level2.children.forEach(function (level3, index3) {
                            if (index3 == 0) {
                                catalogLevel3 = level3;
                            }
                        });
                    }
                });
                initSelectCatalog01(rootLevel,catalogLevel1, catalogLevel2, catalogLevel3);
                /*初始化一、二、三级目录 end*/
                $.divselectInit("风格", "all", styleSelect, styleSelectInput);
                $.divselectInit("色系", "all", colorSelect, colorSelectInput);
                initProductColor("tile");
                initLeftProductStyle();
                loadLeftCatalogProducts(catalogLevel3.cid,0,20);
            });
    };

    /*初始化下拉框目录信息*/
    function initSelectCatalog01(rootLevel,catalogLevel1, catalogLevel2, catalogLevel3) {
        /*二、三级当前目录值*/
        var oneCatalogObj = $(firstLevelSelectUl).empty();
        var twoCatalogObj = $(secondLevelSelectUl).empty();
        var threeCatalogObj = $(thirdLevelSelectUl).empty();
        rootLevel.forEach(function (level1, index2) {
            $("<li>").append($("<a>").attr({
                "href": "javascript:;",
                "selectid": level1.cid
            }).text(level1.label)).appendTo(oneCatalogObj);
        });
        catalogLevel1.children.forEach(function (level2, index2) {
            $("<li>").append($("<a>").attr({
                "href": "javascript:;",
                "selectid": level2.cid
            }).text(level2.label)).appendTo(twoCatalogObj);
        });
        catalogLevel2.children.forEach(function (level3, index3) {
            $("<li>").append($("<a>").attr({
                "href": "javascript:;",
                "selectid": level3.cid
            }).text(level3.label)).appendTo(threeCatalogObj);
        });
        $.divselectInit(catalogLevel1.label, catalogLevel1.cid, firstLevelSelect, firstLevelSelectInput);
        $.divselectInit(catalogLevel2.label, catalogLevel2.cid, secondLevelSelect, secondLevelSelectInput);
        $.divselectInit(catalogLevel3.label, catalogLevel3.cid, thirdLevelSelect, thirdLevelSelectInput);

        /*一级目录联动二级目录，二级目录联动三级目录,目录中的第一个目录值，并加载出该目录下的产品数据*/
        $.divselect("一级目录", firstLevelSelect, firstLevelSelectInput, function (value) {
            twoCatalogObj.empty();
            rootLevel.forEach(function (level1, index1) {
                if (level1.cid == value) {
                    level1.children.forEach(function (level2, index2) {
                        $("<li>").append($("<a>").attr({
                            "href": "javascript:;",
                            "selectid": level2.cid
                        }).text(level2.label)).appendTo(twoCatalogObj);
                        if (index2 == 0) {
                            $.divselectInit(level2.label, level2.cid, secondLevelSelect, secondLevelSelectInput);
                            threeCatalogObj.empty();
                            level2.children.forEach(function (level3, index3) {
                                $("<li>").append($("<a>").attr({
                                    "href": "javascript:;",
                                    "selectid": level3.cid
                                }).text(level3.label)).appendTo(threeCatalogObj);
                                if (index3 == 0) {
                                    $.divselectInit(level3.label, level3.cid, thirdLevelSelect, thirdLevelSelectInput);
                                    loadLeftCatalogProducts(level3.cid, 0, 20);
                                };
                            });
                        }
                    });

                    $.divselect("二级目录", secondLevelSelect, secondLevelSelectInput, function (value) {
                        threeCatalogObj.empty();
                        level1.children.forEach(function (level2, index2) {
                            if (level2.cid == value) {
                                level2.children.forEach(function (level3, index3) {
                                    $("<li>").append($("<a>").attr({
                                        "href": "javascript:;",
                                        "selectid": level3.cid
                                    }).text(level3.label)).appendTo(threeCatalogObj);
                                    if (index3 == 0) {
                                        $.divselectInit(level3.label, level3.cid, thirdLevelSelect, thirdLevelSelectInput);
                                        loadLeftCatalogProducts(level3.cid,0,20);
                                    }
                                });
                            }
                        });
                        $.divselect("三级目录", thirdLevelSelect, thirdLevelSelectInput, function (value) {
                            loadLeftCatalogProducts(value,0,20);
                        });
                    });
                }
            });
            $.divselect("三级目录", thirdLevelSelect, thirdLevelSelectInput, function (value) {
                loadLeftCatalogProducts(value,0,20);
            });
        });

        /*二级目录联动三级目录，默认显示三级目录中的第一个目录值，并加载出该目录下的产品数据*/
        $.divselect("二级目录", secondLevelSelect, secondLevelSelectInput, function (value) {
            threeCatalogObj.empty();
            catalogLevel1.children.forEach(function (level2, index2) {
                if (level2.cid == value) {
                    level2.children.forEach(function (level3, index3) {
                        $("<li>").append($("<a>").attr({
                            "href": "javascript:;",
                            "selectid": level3.cid
                        }).text(level3.label)).appendTo(threeCatalogObj);
                        if (index3 == 0) {
                            $.divselectInit(level3.label, level3.cid, thirdLevelSelect, thirdLevelSelectInput);
                            loadLeftCatalogProducts(level3.cid,0,20);
                        }
                    });
                }
            });
            $.divselect("三级目录", thirdLevelSelect, thirdLevelSelectInput, function (value) {
                loadLeftCatalogProducts(value,0,20);
            });
        });

        /*三级目录加载该目录下数据*/
        $.divselect("三级目录", thirdLevelSelect, thirdLevelSelectInput, function (value) {
            loadLeftCatalogProducts(value,0,20);
        });
    };
    /*初始化色调区域-色系*/
    function initProductColor(typeid) {
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductSaturationData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {}
        }).then(function (res) {
            var colorObj = $(colorSelectUl).empty();
            $("<li>").append($("<a>").attr({
                "href": "javascript:;",
                "selectid": "all"
            }).text("全部")).appendTo(colorObj);
            res.forEach(function (obj) {
                if (typeid == obj.typeid) {
                    $("<li>").append($("<a>").attr({
                        "href": "javascript:;",
                        "selectid": obj.satid
                    }).text(obj.title)).appendTo(colorObj);
                }
            });
            $.divselect("色系", colorSelect, colorSelectInput, function (value) {
                loadLeftCatalogProducts(currentSelectedCatalogId, 0, 20);
            });
            $.divselectInit("色系", "all", colorSelect,colorSelectInput);
        }).catch(function (e) {
            layer.alert('send getProductSaturationData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    };
    /*初始化风格区域*/
    function initLeftProductStyle() {
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductStyleData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {}
        }).then(function (res) {
            var styleObj = $(styleSelectUl).empty();
            $("<li>").append($("<a>").attr({"href": "javascript:;", "selectid": "all"}).text("全部")).appendTo(styleObj);
            res.forEach(function (obj) {
                $("<li>").append($("<a>").attr({
                    "href": "javascript:;",
                    "selectid": obj.sid
                }).text(obj.title)).appendTo(styleObj);
            });
            $.divselect("风格", styleSelect, styleSelectInput, function (value) {
                loadLeftCatalogProducts(currentSelectedCatalogId,0,20);
            });
        }).catch(function (e) {
            layer.alert('send getProductStyleData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    };
    /*渲染产品列表*/
    window.swapUsagecount={};
    function renderLeftCatalogProducts(products) {
        var changeModel=getChangeModel(modelType);
        var pickType = changeModel.constructor.name.toLowerCase();
        if(pickType == "floor"){
            var parentId="#catalogList";
        }else if(pickType == "rectarea" || pickType == "roundarea" || pickType == "freearea"){
            var parentId="#areaCatalogList";
        }

        $("#catalogContent .items").remove();
        $(".produceList li").find('.arrow_box').hide();
        if (!products || products.length == 0) return;
        var $productZoom = $('#productHoverZoom');
        products.forEach(function (leaf) {
            var $productItem =$("<div>",{
                pid: leaf.pid,
                "title": leaf.title,
                "class":'img_container',
            }).appendTo($("<li>")
                .appendTo(parentId))
                .on("click", function(){
                    leftProductClick(leaf.pid);
                })
                .each(function () {
                    var pid = leaf.pid;
                    var _self = this;
                    window.swapUsagecount[pid]=leaf.usagecount;
                    $("<img>",{
                        src: ui.catalogGetFileUrl("product", pid, "iso"),
                        width: '100%',
                        height: '100%',
                        class: 'prodimg'
                    }).appendTo(this);

                    $("<div>").addClass("img_oper")
                        .append($("<div>").addClass("info").hover(function (e) {
                            $productZoom.empty();

                            $("<img>",{
                                'class':"prodimg product-zoom-img",
                                src: ui.catalogGetFileUrl("product", leaf.pid, "iso")
                            }).appendTo($productZoom);

                            var product_size = (Math.ceil(leaf.xlen * 1000) / 1000) + "x" + (Math.ceil(leaf.ylen * 1000) / 1000);
                            if (leaf.zlen > 0) product_size += "x" + (Math.ceil(leaf.zlen * 1000) / 1000);
                            var product_brand = fakeUnnicodeToChinese(leaf.productbrand);
                            if ('' == product_brand) product_brand = "无";

                            var usagecount = window.swapUsagecount[pid];

                            var div=$("<div>").addClass("product-short-info")
                                .append($("<div>").addClass("name").text("【" + (leaf.model || "") + leaf.title + "】"))
                                .append($("<div>").addClass("size").text("尺寸：" + product_size + "(m)"))
                                .append($("<div>").addClass("size").text("品牌：" + product_brand))
                                .append($("<div>").addClass("hotPoint").text("热度：" + usagecount))
                                .attr({
                                    pid: leaf.pid
                                });
                            div.appendTo($productZoom);

                            var position = $(_self).position();
                            var zoomTop = position.top - 10;
                            var zoomLeft = (position.left + 78) + 'px';
                            var zoomHeight = $productZoom.height();
                            var catalogHeight = jQuery('.change_sub_popup').height();
                            if (catalogHeight - zoomTop - zoomHeight < -40) {
                                zoomTop = catalogHeight - zoomHeight;
                            }
                            zoomTop = (zoomTop - 40) + 'px';
                            $productZoom
                                .css({
                                    left: zoomLeft,
                                    top: zoomTop
                                })
                                .show()
                                .hover(function (e) {
                                    $(this).show();
                                }, function (e) {
                                    $(this).hide();
                                });
                        }, function (e) {
                            $productZoom.hide();
                        }))
                        .appendTo(this);
                }).hover(function (e) {
                    $(this).find(".img_oper").addClass("img_oper_cur");
                }, function (e) {
                    $(this).find(".img_oper").removeClass("img_oper_cur");
                });
        });
    };

    function loadLeftCatalogProducts(cid,viewindex,viewsize) {
        currentSelectedCatalogId = cid;
        var styleValue = $(styleSelectInput).val();
        var saturationValue = $(colorSelectInput).val();
        $("#catalogList").empty();
        $("#areaCatalogList").empty();
        var data = {
            "cid": cid,
            "viewindex": viewindex,
            "viewsize": viewsize,
            "saturation": saturationValue,
            "style": styleValue,
        };
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: api.getServicePrefix("catalog") + "/getProductsByCatalogId",
            cache: false,
            data: data
        }).then(function (products) {
            renderLeftCatalogProducts(products);
            /*初始化分页属性*/
            if (products && products.length > 0) {
                $(".catalogProductPagination").show();
                resizePage();
                $(".catalogProductPagination .pagination").pagination(products[0].count, {
                    callback: function (page_index, jq) {
                        loadLeftCatalogProducts(cid, page_index, viewsize);
                    },
                    prev_text: '<',
                    next_text: '>',
                    items_per_page: 20,
                    num_display_entries: 4, //连续分页主体部分显示的分页条目数
                    current_page: viewindex,
                    num_edge_entries: 2 //两侧显示的首尾分页的条目数
                });
            } else {
                $(".catalogProductPagination").hide();
            }
        }).catch(function (e) {
            layer.alert('send getProductsByCatalogId request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    };

    function leftParquetGetModelFromUI() {
        var model = {channels: {}};
        var channels = model.channels;
        $(".subProduceList.currentSubProduceList .subItems").each(function () {
            var channelUI = $(this);
            var cid = channelUI.find(".detail_img").attr("channel_id");
            var pid = channelUI.find(".detail_img").attr("pid");
            var channel = channels[cid] = {pid: pid, rot: "0"};
        });
        return model;
    }

    //更新拼花channels功能
    function updateParquetChannels(pid,paveimaterial){
        var currentModel;
        var changeModel=getChangeModel(modelType);
        if(paveimaterial){
            currentModel = changeModel[paveimaterial];
        }else{
            var pickType = changeModel.constructor.name.toLowerCase();
            if(pickType == "floor"){
                currentModel = changeModel.floorMaterial;
            }else if(pickType == "rectarea" || pickType == "roundarea" || pickType == "freearea"){
                currentModel = changeModel.areaMaterial;
            }
        }
        api.catalogGetProductsMetaPromise([pid]).then(function (rv) {
            //更新subProduceList 列表数据 start
            var parquetCurrentItemsUrl  = pid == "none" ? "" : api.catalogGetFileUrl("product", pid, "top");
            var parquetCurrentItemsPid = rv[pid].pid;
            var parquetCurrentItemsName = rv[pid].title;
            var parquetCurrentItemsSize = rv[pid].xlen*1000+'mm*'+rv[pid].ylen*1000+'mm';
            $(".subItems.current").find(".detail_img").attr("src",parquetCurrentItemsUrl);
            $(".subItems.current").find(".detail_img").attr("pid",parquetCurrentItemsPid);
            $(".subItems.current").find(".middle_box p:first-child").text(parquetCurrentItemsName);
            $(".subItems.current").find(".middle_box p:last-child").text(parquetCurrentItemsSize);
            //更新subProduceList 列表数据 end

            var model = leftParquetGetModelFromUI();
            var url = currentModel.getUrl(1024, model);
            $(".subProduceList.currentSubProduceList").siblings(".left_box").find(".detail_img").attr("src", url);
            model = leftParquetGetModelFromUI();
            currentModel.update(model);
        });
    };
    function updateParquet(pid){
        if($(".subItems").hasClass("current")){
            var paveimaterial = $(".subItems.current").parent().parent().attr("paveimaterial");
            api.catalogGetProductsMetaPromise([pid]).then(function (rv) {
                var category = rv[pid].category;
                if("parquet" == category || category=='customparquet'){
                    //channels不能用拼花代替
                    layer.msg('不能替换拼花');
                    return;
                }else{
                    var changeModel=getChangeModel(modelType);
                    updateParquetChannels(pid,paveimaterial);
                    var pickType = changeModel.constructor.name.toLowerCase();
                    paveProcessInit(changeModel,pickType)
                }
            });
        }else{
            api.catalogGetProductsMetaPromise([pid]).then(function (rv) {
                if(osnfuzzy){
                    if(osnfuzzy.data.step==0){layer.msg('请先完成颜色填充，再选砖');return;}
                    if(osnfuzzy.data.step==1){layer.msg('请先点击下一步，再选砖');return;}
                    osnfuzzy.data.selectTile=rv[Object.keys(rv)[0]];
                }else {
                    var changeModel=getChangeModel(modelType);
                    if(!paveMaterialType){
                        var pickType = changeModel.constructor.name.toLowerCase();
                        if(pickType == "floor"){
                            api.actionBegin("ChangeProduct", changeModel, rv[pid], "floorMaterial");
                        }else if(pickType == "rectarea" || pickType == "roundarea" || pickType == "freearea"){
                            api.actionBegin("ChangeProduct", changeModel, rv[pid], "areaMaterial");
                        }
                        $(".produceList .items:first-child .arrow_box").show();
                        $(".produceList .items:first-child .right_box").hide();
                    }else{
                        api.actionBegin("ChangeProduct", changeModel, rv[pid], paveMaterialType);
                        $(".produceList .items."+paveMaterialType+" .arrow_box").show();
                        $(".produceList .items."+paveMaterialType+" .right_box").hide();
                    }
                    paveProcessInit(changeModel,pickType);
                    api.actionEnd("ChangeProduct");
                }
            });
        }
    };

    window.undoRedoArray = [];
    window.undoRedoArrayIndex = 0;

    $(global_leftcontextmenu_leftpopup).on("click",".produceList .img_change", function (e) {
        $('.change_sub_popup').hide();
        $('.change_sub_popup').show();
        var currentCategory = $(this).parent().siblings(".left_box").find(".detail_img").attr("category");
        var currentPid = $(this).parent().siblings(".left_box").find(".detail_img").attr("pid");
        paveMaterialType = $(this).parent().siblings(".left_box").find(".detail_img").attr("paveMaterialType");
        undoRedoArray = [];
        // undoRedoArray.push(currentPid);
        undoRedoArrayIndex=0;
        renderProductSaturation(currentCategory);

        ///////////////////////////////////////////
        // undoRedoArray = [];
        // undoRedoArray.push(currentPid);
    });

    function leftProductClick(pid) {
        $(".produceList li.current").find('.arrow_box').show();
        // undoRedoArray=undoRedoArray.splice(0,1);
        undoRedoArray=[];
        var changeModel=getChangeModel(modelType);
        var pickType = changeModel.constructor.name.toLowerCase();
        var parentId="#catalogList";
        if(pickType!="floor"){
            parentId="#areaCatalogList";
        }
        $(parentId).find('li').each(function(index,item){
            undoRedoArray.push($(item).find('div.img_container').attr("pid"));
            // if($(item).find('div.img_container').attr("pid")==undoRedoArray[0])undoRedoArray=undoRedoArray.splice(1);
        })
        undoRedoArrayIndex=$.inArray(pid,undoRedoArray);

        ///////////////////////////////////////////
        // if(pid != undoRedoArray[undoRedoArrayIndex]){
        //     undoRedoArray =  undoRedoArray.slice(0,undoRedoArrayIndex+1);
        //     undoRedoArray.push(pid);
        //     undoRedoArrayIndex = undoRedoArray.length - 1;
        // }else{
        //     log("同一款产品");
        // }
        updateParquet(pid);
    };

    //上一页
    $("#leftcontextmenu2d .produceList").on("click",".preArrow", function () {
        if(undoRedoArrayIndex == 0){
            layer.msg("已经是第一款砖");
        }else{
            if(undoRedoArrayIndex>0){
                undoRedoArrayIndex--;
                var pid = undoRedoArray[undoRedoArrayIndex];
                updateParquet(pid);
            }
        }

        ///////////////////////////////////////////
        // if(undoRedoArrayIndex == 0){
        //     layer.msg("已经是第一款砖");
        // }else{
        //     if(undoRedoArrayIndex>0){
        //         undoRedoArrayIndex--;
        //         var pid = undoRedoArray[undoRedoArrayIndex]
        //         updateParquet(pid);
        //     }
        // }
    });

    //下一页
    $("#leftcontextmenu2d .produceList").on("click",".nextArrow",function(){
        if(undoRedoArray[undoRedoArrayIndex+1]){
            ++undoRedoArrayIndex;
            var pid = undoRedoArray[undoRedoArrayIndex];
            updateParquet(pid);
        }else{
            layer.msg("已经是最后一款砖");
        }

        ///////////////////////////////////////////
        // if(undoRedoArray[undoRedoArrayIndex+1]){
        //     var index = undoRedoArrayIndex+1
        //     var pid = undoRedoArray[index]
        //     updateParquet(pid);
        //     undoRedoArrayIndex++;
        // }else{
        //     layer.msg("已经是最后一款砖");
        // }
    });


    /*目录中的搜索框，第一个字符禁止输空格*/
    $("#catalogSearch .valueText").keypress(function (e) {
        if (e.keyCode == 32 && $(this).val().length == 0) {
            $(this).val('');
            return false;
        }
        /*回车键*/
        if (event.keyCode == 13) {
            $(this).siblings(".searchButton").trigger("click");
        }
    });
    /*目录中的搜索按钮事件*/
    $("#catalogSearch .searchButton").on("click", function (e) {
        var searchstring = $(this).siblings(".valueText").val();
        if (searchstring == '')return;
        loadLeftSearchedProducts(searchstring, 0, 20);
    });
    /**
     * 加载搜索后的产品
     * @param searchstring
     * @param viewindex
     * @param viewsize
     */
    function loadLeftSearchedProducts(searchstring, viewindex, viewsize) {
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: api.getServicePrefix("catalog") + "/searchProductsFromCatalog",
            cache: false,
            data: {
                "searchstring": searchstring,
                "viewindex": viewindex,
                "viewsize": viewsize
            }
        }).then(function (products) {
            $("#catalogList").empty();
            $("#areaCatalogList").empty();
            renderLeftCatalogProducts(products);
            /*初始化分页属性*/
            if (products && products.length > 0) {
                $(".catalogProductPagination").show();
                $(".catalogProductPagination .pagination").show().pagination(products[0].count, {
                    callback: function (page_index, jq) {
                        loadLeftSearchedProducts(searchstring, page_index, viewsize);
                    },
                    prev_text: '<',
                    next_text: '>',
                    items_per_page: 20,
                    num_display_entries: 4, //连续分页主体部分显示的分页条目数
                    current_page: viewindex,
                    num_edge_entries: 2 //两侧显示的首尾分页的条目数
                });
            } else {
                $(".catalogProductPagination").hide();
            }
        }).catch(function (e) {
            layer.alert('send searchProductsFromCatalog request to server failed!! ', {
                title: '提示',
                skin: 'layui-layer-default'
            });
        });
    };
});
function getChangeModel(model) {
    var modelPick=model;
    if(model.type=='BOUNDARY'){
        modelPick=model.host;
    }
    return modelPick;
}
/*对齐方式*/
/*箭头控制*/
$("#leftcontextmenu2d .alignmentBox").on("click","div.box",function(){
    var p = $(this).parent('div'),
        arr = ['-51px 2px','-88px 2px','-123px 2px','-51px -34px','-87px -33px','-123px -34px','-51px -69px',"-87px -70px",'-123px -70px'],
        none = '-999px -999px',
        index = $(this).index();
    p.find('div').css('background-position',none)
    $(this).css("background-position",arr[4]);
    (index-1>=0) && (index%3!=0) ? p.find('div:eq('+(index-1)+')').css('background-position',arr[3]):'';
    (index-2>=0) &&( (index-1)%3!=1) ? p.find('div:eq('+(index-2)+')').css('background-position',arr[2]):'';
    (index-3>=0) ? p.find('div:eq('+(index-3)+')').css('background-position',arr[1]):'';
    (index-4>=0) && ((index-4)%3!=2) ? p.find('div:eq('+(index-4)+')').css('background-position',arr[0]):'';

    (index+1<=8) && (index+1)%3!=0 ? p.find('div:eq('+(index+1)+')').css('background-position',arr[5]):'';
    (index+2<=8) && ((index+2)%3!=2) ? p.find('div:eq('+(index+2)+')').css('background-position',arr[6]):'';
    (index+3<=8) ? p.find('div:eq('+(index+3)+')').css('background-position',arr[7]):'';
    (index+4<=8) && ((index+4)%3!=0) ? p.find('div:eq('+(index+4)+')').css('background-position',arr[8]):'';
    var changeModel=getChangeModel(modelType);
    if(changeModel.direction==index)return;
    api.actionBegin("SetFloorDirection", changeModel);
    api.actionRun(index);
    api.actionEnd("SetFloorDirection");
});

//水平对齐
$(horizonMoveSlider).
    slider({min: -500, max: 500, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestop", function (e, ui) {
        var val = $(horizonTextSlider).val()*1 + ui.value;
        $(horizonTextSlider).val(val);
        $(this).slider({value: 0});
        api.actionEnd("MoveMat");
    }).on("slide", function (e, ui) {
        api.actionRun("move", "x", "delta", ui.value/1000);
    }).on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType);
        var model = changeModel.type=="FLOOR"?changeModel.floorMaterial:changeModel.areaMaterial;
        api.actionBegin("MoveMat", model);

    });

//垂直对齐
$(verticalMoveSlider).
    slider({min: -500, max: 500, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestop", function (e, ui) {
        var val = $(verticalTextSlider).val()*1 + ui.value;
        $(verticalTextSlider).val(val);
        $(this).slider({value: 0});
        api.actionEnd("MoveMat");
    }).on("slide", function (e, ui) {
        api.actionRun("move", "y", "delta", ui.value/1000);
    }).on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType);
        var model = changeModel.type=="FLOOR"?changeModel.floorMaterial:changeModel.areaMaterial;
        api.actionBegin("MoveMat", model);

    });

//旋转角度
$(rotateMoveSlider).
slider({min: 0, max: 360, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "°"})
    .on("slidestart", function (e, ui) {
        var changeModel=getChangeModel(modelType);
        var model = changeModel.type=="FLOOR"?changeModel.floorMaterial:changeModel.areaMaterial;
        api.actionBegin("RotMat", model);
    })
    .on("slide", function (e, ui) {
        api.actionRun("rot", "", ui.value);
    })
    .on("slidestop", function (e, ui) {
        $(rotateTextSlider).val(ui.value);
        api.actionEnd("RotMat");
    })/*.on('slidechange',function (e, ui) {
        var model = modelType.type=="FLOOR"?modelType.floorMaterial:modelType.host.floorMaterial;
        api.actionBegin("RotMat", model);
        api.actionRun("rot", "", ui.value);
        api.actionEnd("RotMat");
        $(rotateTextSlider).val(ui.value);
    })*/;
//砖缝大小
$(brickMoveSlider).
slider({min: 0, max: 20, step: 1, range:"min"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "mm"})
    .on("slidestop", function (e, ui) {
        var suffix =getBrickWorkType(this);
        $(brickTextSlider+suffix).val(ui.value);
        setBrickWidth(ui.value/1000);
    }).on("slide", function (e, ui) {
    var suffix =getBrickWorkType(this);
    $(brickShowWidthList+suffix).removeClass('on');
    $(brickShowWidthList+suffix).each(function () {
        if ($(this).attr("widthValue") == ui.value/1000) {
            $(this).addClass('on')
        }
    });
});
function setBrickWidth(value) {
    var model = BrickModelPick();
    api.actionBegin("ActionSetGapwidth",model,value);
    api.actionRun();
    api.actionEnd();
    if(model.type!='FLOOR' && model.type!='RECTAREA' && model.type!="ROUNDAREA" && model.type!="FREEAREA"){
        var boundary = getSelectBoundary();
        if(boundary.gapwidth != undefined ){
            boundary.gapwidth = value;
        }
    }
}
function setBrickColor(value) {
    var model = BrickModelPick();
    api.actionBegin("ActionSetGapcolor",model,value.substring(1,value.length));
    api.actionRun();
    api.actionEnd();
    if(model.type!='FLOOR' && model.type!='RECTAREA' && model.type!="ROUNDAREA" && model.type!="FREEAREA"){
        var boundary = getSelectBoundary();
        if( boundary.gapcolor != undefined){
            boundary.gapcolor = value.substring(1,value.length);
        }
    }
}
function BrickModelPick(){
    var Pick ;
    var parentDiv=$('#leftcontextmenu2d').find(".leftcontextmenu_root").has(":visible");;
    if(parentDiv.find('.tab_head .on').index() == 2){
        var boundary = getSelectBoundary();
        if('TILESINGLE'==boundary.baseMaterial.type){
            Pick = boundary.baseMaterial;
        }else{
            Pick = api.tileSingleCreate(boundary.baseMaterial.meta.pid);
            boundary.baseMaterial=Pick;
        }
    }else{
        var modelPick=api.pickGetPicked()[0].model;
        Pick=modelPick;
        if(modelPick.type=='BOUNDARY'){
            Pick=modelPick.host
        }
    }
    return Pick;
}
function getSelectBoundary() {
    var bid = $('.waveLineDiv li.active').attr('bid');
    var boundary = '';
    var boundaries  = api.floorplanFilterEntity(function (e) {
        return e.type == "BOUNDARY";
    })
    for(var i=0; i<boundaries.length; i++){
        if(bid == boundaries[i].id){
            boundary = boundaries[i];break;
        }
    }
    return boundary;
}

//初始化区域设置
function setAreaInit() {
    var changeModel=getChangeModel(modelType);
    if(changeModel.type=="RECTAREA"){
        initSetMenuRectarea(changeModel);
    }else if(changeModel.type=="ROUNDAREA"){
        initSetMenuRoundarea(changeModel);
    }else{
        initSetMenuFreearea(changeModel);
    }
    $(globalAreaSizeText).val(changeModel.height3d * 1000);
    $(globalAreaSizeSlide).slider("value", changeModel.height3d * 1000);
    $(globalAreaFloorHeightText).val(changeModel.z * 1000)
    $(globalAreaFloorHeightSlide).slider("value", changeModel.z * 1000);
}
/*自由区域*/
function initSetMenuFreearea(changeModel){
    $('#leftcontextmenu2d .area .tab_ul').find('li[cid="areaType"]').html('自由区域')
    var activeViewId = $("#paper2d").has("#paper2dsvg").length == 0 ? "3D" : "2D";
    $(globalAreaHollowedOut).prop("checked", !!changeModel.cavern);
    $(globalAreaSettingContentList).find('.alignment').hide();
    if(activeViewId=='2D'){
        $(globalAreaSettingContentList).find('.areaSet').show();
        $(globalAreaSettingContentList).find('.areaSet').find('p').eq(0).hide()
    }
     $(globalAreaSettingContentList).find('.areaSet').find('p').eq(0).hide()
    $(globalAreaSettingContentList).find('.freeArea ').each(function (index,item) {
        if($(item).hasClass("view_"+activeViewId)){
            $(item).show();
        }else{
            $(item).hide();
        }
    });;
}

/*矩形区域*/
function initSetMenuRectarea(changeModel) {
    $('#leftcontextmenu2d .area .tab_ul').find('li[cid="areaType"]').html('矩形区域')
    var rectarea = changeModel;
    var activeViewId = $("#paper2d").has("#paper2dsvg").length == 0 ? "3D" : "2D";
    $(globalRectAreaHeightSlide).slider("value", rectarea.height * 1000);
    $(globalRectAreaWidthSlide).slider("value", rectarea.width * 1000);
    $(globalRectAreaRot).slider("value", rectarea.rot);
    $(globalRectAreaText).val(Math.ceil(rectarea.rot * 1000) / 1000);
    $(globalRectAreaHeightText).val(Math.ceil(rectarea.height * 1000));
    $(globalRectAreaWidthText).val(Math.ceil(rectarea.width * 1000));
    //区域边缘锁定
    $(globalAreaEdgeLocking).prop("checked", !!rectarea.fixation);
    $(globalAreaHollowedOut).prop("checked", !!rectarea.cavern);
    $(globalAreaSettingContentList).find('.alignment').hide();
    $(globalAreaSettingContentList).find('.rectArea ').each(function (index,item) {
        if($(item).hasClass("view_"+activeViewId)){
            $(item).show();
        }else{
            $(item).hide();
        }
    });
    if(activeViewId=='2D'){
        $(globalAreaSettingContentList).find('.areaSet').show();
    }else{
        $(globalAreaSettingContentList).find('.areaSet').hide();
    }
}

/*圆形区域*/
function initSetMenuRoundarea(changeModel) {
    $('#leftcontextmenu2d .area .tab_ul').find('li[cid="areaType"]').html('圆形区域')
    var roundarea =changeModel;
    var activeViewId = $("#paper2d").has("#paper2dsvg").length == 0 ? "3D" : "2D";
    $(globalRoundAreaRadiusSlide).slider("value", roundarea.radius * 1000);
    $(globalRoundAreaRadiusText).val(Math.ceil(roundarea.radius * 1000));
    $(globalAreaHollowedOut).prop("checked", !!roundarea.cavern);
    $(globalAreaSettingContentList).find('.alignment').hide();
    $(globalAreaSettingContentList).find('.roundArea ').each(function (index,item) {
        if($(item).hasClass("view_"+activeViewId)){
            $(item).show();
        }else{
            $(item).hide();
        }
    });
    if(activeViewId=='2D'){
        $(globalAreaSettingContentList).find('.areaSet').show();
        $(globalAreaSettingContentList).find('.areaSet').find('p').eq(0).hide()
    }else{
        $(globalAreaSettingContentList).find('.areaSet').hide();
    }
}

//区域边缘锁定
$(globalAreaEdgeLocking).on("click", function (e) {
    var check=($(this).is(":checked"))?true:false;
    var changeModel=getChangeModel(modelType);
    api.actionBegin("SetGeneralProp", changeModel);
    api.actionRun("set", "fixation",check);
    api.actionEnd("SetGeneralProp");
});

//区域挖空
$(globalAreaHollowedOut).on("click", function (e) {
    var changeModel=getChangeModel(modelType);
    changeModel.cavern = $(this).is(":checked")?true:false;
})

//初始化砖缝设置
function setBrickWorkInit(model) {
    // var suffix = model.type=="FLOOR"?'.floorBrick':'.boundaryBrick';
    var suffix =getBrickWorkType(model);
    $(brickShowWidthList+suffix).removeClass('on');
    $(brickShowColorList+suffix).removeClass('on');
    // var model = api.pickGetPicked()[0].model;
    // var opt = api.pickGetPicked()[0].opt;
    // var areaMaterial = model.areaMaterial;
    // if (model.floorMaterial) {
    //     areaMaterial = model.floorMaterial;
    // }
    // if (opt.elementName && model[opt.elementName + "Material"]) {
    //     areaMaterial = model[opt.elementName + "Material"];
    // }
    // if(model.type == "BOUNDARY"){
    //     if(opt.src == "2d"){
    //         var side = opt.side.split("_");
    //         areaMaterial = model[side[0] + "Material"];// + side[1] + "Material"];
    //     }else if(opt.src == "3d"){
    //         if(opt.elementName.indexOf("base") != -1){
    //             areaMaterial = model["baseMaterial"];
    //         }else if(opt.elementName.indexOf("corner") != -1){
    //             areaMaterial = model["cornerMaterial"];
    //         }else if(opt.elementName.indexOf("left") != -1){
    //             areaMaterial = model["leftMaterial"];
    //         }else if(opt.elementName.indexOf("right") != -1){
    //             areaMaterial = model["rightMaterial"];
    //         }
    //     }
    // }
    $(brickTextSlider+suffix).val(0);
    $(brickMoveSlider+suffix).slider("value", 0);
    if (model && model.gapwidth) {
        $(brickTextSlider+suffix).val(model.gapwidth * 1000);
        $(brickMoveSlider+suffix).slider("value", model.gapwidth * 1000);
        $(brickShowWidthList+suffix).each(function () {
            if ($(this).attr("widthValue") == model.gapwidth) {
                $(this).addClass('on')
                $(brickShowWidthList+suffix).val("");
            }
        });
        $(brickColorWidget+suffix).spectrum("set","#" + model.gapcolor);
        $(brickShowColor+suffix).attr({
            "value": "#" + model.gapcolor
        }).css({
            "background":"#" + model.gapcolor
        })
        $(brickShowColorList+suffix).each(function () {
            if ($(this).attr("value") == "#"+model.gapcolor) {
                $(this).addClass('on')
            }
        });
    }else{
        //$(brickShowWidthList+suffix).eq(0).addClass('on');
        $(brickShowColorList+suffix).eq(0).addClass('on');
    }
}
function getBrickWorkType(model) {
    var suffix = '.floorBrick';
    if(model.type && model.type!='submit' && model.type!='button'){
        if(model.type=="RECTAREA" || model.type=="ROUNDAREA" || model.type=="FREEAREA"){
            suffix='.areaBrick';
        } else if(model.type=="BOUNDARY"){
            suffix='.boundaryBrick';
        }
    }else{
         suffix = $(model).hasClass('floorBrick')?'.floorBrick':$(model).hasClass('boundaryBrick')?".boundaryBrick":".areaBrick";
    }
    return suffix
}
//$('#ex1').slider({
//    formatter: function(value) {
//        return 'Current value: ' + value;
//    }
//});

/*铺贴加工*/
//初始化铺贴加工页面
function paveProcessInit(model,elem) {
    var elemType="."+elem;
    pickedPaveMaterial(model)
    var floorMaterial=model.floorMaterial || model.areaMaterial;
    //拼花不显示铺贴加工页面
    var show=hidePaveProcess(floorMaterial.type,elemType);
    if(!show)return;

    var ProcessImageUrl = api.catalogGetFileUrl("product", floorMaterial.meta.pid, "iso");
    var paveProcessing_content = '';
    var lenght=(floorMaterial.meta.xlen/floorMaterial.meta.ylen)*115
    var imgWH='width:'+lenght.toFixed(0)+'px;height:115px;left:'+(57.5-lenght/2).toFixed(0)+'px';
    if(floorMaterial.meta.ylen<floorMaterial.meta.xlen){
        lenght=(floorMaterial.meta.ylen/floorMaterial.meta.xlen)*115
        imgWH='width:115px;height:'+lenght.toFixed(0)+'px;top:'+(57.5-lenght/2).toFixed(0)+'px';
    }
    paveProcessing_content+='<div class="verticalLenght"><span>'+(floorMaterial.meta.ylen*1000 || 0)+'mm</span></div><div class="horizontalLenght"><span>'+(floorMaterial.meta.xlen*1000 || 0)+'mm</span></div>'
    paveProcessing_content+= '<div class="img_box"><img style="'+imgWH+'" class="img_container" src="'+ProcessImageUrl+'"/></div>';
    $(".leftcontextmenu "+elemType+" .tab_container02 .pave_content").html(paveProcessing_content);
    var horizontalcuttingDiv = $("#leftcontextmenu2d "+elemType+" .leftpopup .tab_container02 .horizontalcutting");//        /*横切*/
    var verticalcuttingDiv = $("#leftcontextmenu2d "+elemType+" .leftpopup .tab_container02 .verticalcutting");//        /*竖切*/
    horizontalcuttingDiv.children("select").empty();
    verticalcuttingDiv.children("select").empty();
    for (var i = 1; i <= 10; i++) {
        var name = (i == 1) ? "无" : ("开" + i);
        horizontalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
        verticalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
    }
    horizontalcuttingDiv.children("select").val("1");
    verticalcuttingDiv.children("select").val("1");
    advancedPatternCurrentMaterial=floorMaterial;
    if (floorMaterial && floorMaterial.gapwidth) {
        $("#leftcontextmenu2d "+elemType+" .leftpopup .tab_container02 .horizontalcutting select").val(floorMaterial.cutv);
        $("#leftcontextmenu2d "+elemType+" .leftpopup .tab_container02 .verticalcutting select").val(floorMaterial.cuth)
    }
    $('.alignmentBox div:eq('+model.direction+')').click();
}
function hidePaveProcess(MaterialType,elemType) {
    if(MaterialType=="PARQUET"){
        $(".leftcontextmenu "+elemType+" .leftpopup .tab_ul li").eq(1).hide();
        return false;
    }else{
        $(".leftcontextmenu "+elemType+" .leftpopup .tab_ul li").eq(1).show();
        return true;
    }
}
function boundariesInit(currentBoundaries,boundary){
    boundary=boundary||currentBoundaries[currentBoundaries.length-1];
    var arr={
        "corner":0,
        "base":1,
        "cblr":2
    }
    if(boundary){
        var host = window.location.hostname;
        var url = '';
        if(host == "localhost" || host == "127.0.0.1"){
            url += "ui/catalog/";
        };
        url += pavingModelObj['pavingModelList'][arr[boundary.corner]].url;
        $('.waveLine_content .img_container').attr('src',url);
        $('.sliderWaveLineWidth').slider("value", boundary.size*100);
        $('.sliderWaveLineWidthText').val(boundary.size*100);
    }

    $('.waveLineDiv .list').empty();
    var len = currentBoundaries.length,
        title = $('<ul>');
    len>0?$('.tab_container03 .popup_content').show():$('.tab_container03 .popup_content').hide()
    for(var i=0; i<len; i++){
        var activeClass = '';
        if(boundary && boundary.id == currentBoundaries[i].id){activeClass='active';}
        title.append($('<li>',{text:"第"+(i+1)+"条",class:activeClass,bid:boundary.id}).append($('<a>',{title:"删除"})))
    }
    $('.waveLineDiv .list').append(title)

    $('.waveLineDiv .list li a').on('click',function(){
        var boundary = currentBoundaries[$(this).closest('li').index()];
        currentBoundaries.splice($(this).closest('li').index(),1)
        api.actionBegin("DeleteBoundary", boundary);
        boundariesInit(currentBoundaries)
    })
    $('.waveLineDiv .list li').on('click',function(){
        boundariesInit(currentBoundaries,currentBoundaries[$(this).closest('li').index()])
    })
    $('.waveLineChange').empty();
    arr = ['corner','base','left','right'];
    for(var i=0; i<arr.length; i++){
        if(boundary && boundary[arr[i]+'Material']){
            if(arr[i]=='corner' && boundary.corner=='base')continue;
            $('.waveLineChange').append(
                $('<div>',{class:"boundaryMaterial",id:arr[i]})
                    .append($('<div>',{class:'boundaryImg'})
                        .append($('<img>',{src:boundary[arr[i]+'Material'].getUrl(),style:"transform:rotate(" + boundary[arr[i]+'Rot'] + "deg);"}))
                        .append($('<p>',{})))
                    .append($('<div>',{class:'boundaryButton'})
                        .append($('<div>',{class:'change_box'}).append($('<div>',{class:'imgChange'})).append($('<div>',{class:"imgRotate"})))
                        .append($('<div>',{class:'arrow_box'}).append($('<div>',{class:'preArrow'})).append($('<div>',{class:"nextArrow"}))))
            )
        }
    }
    $('.change_box .imgChange').on('click',function(){
        var fitRot = function(rot){
            return rot %= 360;
        }
        var p = $(this).closest('.boundaryMaterial');
        var id = p.attr('id');
        var rot = fitRot(boundary[id+'Rot'] + 90);
        p.find('.boundaryImg img').css('transform','rotate('+rot+'deg)')
        api.actionBegin("SetBoundaryRot", boundary, id, rot);
    })
    boundary && setBrickWorkInit(boundary)
}
/*铺贴加工应用按钮*/
$("#leftcontextmenu2d .paveProcessButton button").on("click", function (e) {
    paveView();
    if (!advancedPatternCurrentUsedTile)
        return;
    var pick = api.pickGetPicked()[0];
    var modelPick = pick.model;
    var model;
    if(modelPick.constructor.name.toLowerCase() == 'boundary'){
        model = modelPick.host;
    }else{
        model = modelPick;
    }
    if (model.areaMaterial){
        model.areaMaterial = advancedPatternCurrentUsedTile;
    }else if (model.floorMaterial) {
        model.floorMaterial = advancedPatternCurrentUsedTile;
    }else if (pick.opt.src == "3d" &&
        (   model.type == "WALL" ||
            model.type == "PILLAR" ||
            model.type == "BASEMENT" ||
            model.type == "BEAM" ||
            model.type == "PRODUCTREPLACEMENT"
        )) {
        model[pick.opt.elementName + "Material"] = advancedPatternCurrentUsedTile;
    }else if (model.type == "BOUNDARY"){
        if(pick.opt.src == "2d"){
            var side = pick.opt.side.split("_")[0];
            model[side+"Material"] = advancedPatternCurrentUsedTile;
        }else if(pick.opt.src == "3d"){
            if(pick.opt.elementName.indexOf("base") != -1){
                model["baseMaterial"] = advancedPatternCurrentUsedTile;
            }else if(pick.opt.elementName.indexOf("corner") != -1){
                model["cornerMaterial"] = advancedPatternCurrentUsedTile;
            }else if(pick.opt.elementName.indexOf("left") != -1){
                model["leftMaterial"] = advancedPatternCurrentUsedTile;
            }else if(pick.opt.elementName.indexOf("right") != -1){
                model["rightMaterial"] = advancedPatternCurrentUsedTile;
            }
        }
    }
    advancedPatternCurrentUsedTile.psx += 1;
    advancedPatternCurrentUsedTile.psx -= 1;
    //给 preview 中新建的 tile 赋值
    api.actionBegin("RotMat", pickedMaterial());
    api.actionRun("rot", "", advancedPatternCurrentMaterial.rot);
    api.actionEnd("RotMat");
    api.actionBegin("MoveMat", pickedMaterial());
    api.actionRun("move", "x", "delta", advancedPatternCurrentMaterial.tx);
    api.actionRun("move", "y", "delta", advancedPatternCurrentMaterial.ty);
    api.actionEnd("MoveMat");
    api.actionBegin("SetGeneralProp", pickedMaterial());
    api.actionRun("set", "sx", advancedPatternCurrentMaterial.sx);
    api.actionRun("set", "sy", advancedPatternCurrentMaterial.sy);
    api.actionEnd("SetGeneralProp");
    api.actionBegin("SetGeneralProp", pickedMaterial());
    api.actionRun("set", "reflection", advancedPatternCurrentMaterial.reflection);
    api.actionEnd("SetGeneralProp");
    api.actionBegin("SetGeneralProp", pickedMaterial());
    api.actionRun("set", "reflection_glossiness", advancedPatternCurrentMaterial.reflection_glossiness);
    api.actionEnd("SetGeneralProp");
});
function paveView() {
    var showParentDiv=$("#leftcontextmenu2d .leftcontextmenu_root").has(':visible');
    var gapwidth = $("#advancedpattern_single_dialog .gap_width li").find(".hover").attr("widthvalue");//    /*缝隙宽度*/
    var gapcolor = $("#advancedpattern_single_dialog .gap_color li").find(".hover").attr("value");//    /*缝隙颜色*/
    var pavetype = $("#advancedpattern_single_dialog .pavet li").find(".hover").attr("value");//    /*铺贴方式*/
    var cutv = showParentDiv.find(" .leftpopup .tab_container02 .horizontalcutting select").val();//   /*横切*/
    var cuth = showParentDiv.find(" .leftpopup .tab_container02 .verticalcutting select").val();//    /*竖切*/
    //var pavetype =0;
     gapwidth=0.001;
    //var gapcolor="f8f8ff";
    log("gapwidth==" + gapwidth + "  gapcolor==" + gapcolor + "  pavetype==" + pavetype + " cuth==" + cuth + "  cutv==" + cutv);
    var tile = advancedPatternCurrentUsedTile = api.tileSingleCreate(advancedPatternShowObj.pid);
    tile.gapwidth = gapwidth;
    tile.gapcolor = gapcolor;
    tile.pavetype = pavetype;
    tile.cuth = cuth;
    tile.cutv = cutv;
    if (pavetype == 0) {//ping
        tile.psx = tile.psy = 1;
    } else if (pavetype == 1) {//gong
        tile.psx = tile.psy = 1;
    } else if (pavetype == 2) {//ren
        tile.psx = tile.psy = 2;
    } else if (pavetype == 3) {//hengshu
        tile.psx = tile.psy = 2;
    }
    var processUrl = api.tileSingleGetUrl(tile, true, "diffuse");
    //$("#advancedpattern_single_dialog .after_process_prod img").attr("src", processUrl);
}
function pickedPaveMaterial(model) {
    // var patternMat = pickedMaterial();
    // if (!patternMat) return;
    // console.log(patternMat)
    var meta = model.floorMaterial || model.areaMaterial;
    advancedPatternShowObj={
        pid: meta.pid,
        xlen: meta.xlen * 1000,
        ylen: meta.ylen * 1000,
        title: meta.title,
        model: meta.model
    }
}
/*房间设置*/
function setRoomInit(roomMat) {
    //var roomMat = api.pickGetPicked()[0].model;
    $(roomNameTextValue).val(roomMat.label);
    $(roomHeightMoveSlider).slider("value", roomMat.height3d*1000);
    $(roomHeightTextSlider).val(roomMat.height3d*1000);
}

$(roomNameSelectspan).each(function () {
    $(this).on(click, function (e) {
        var textvalue = $(this).text();
        var modelPick=api.pickGetPicked()[0].model;
        var model=modelPick;
        if(modelPick.type=='BOUNDARY'){
            model=modelPick.host
        }
        api.actionBegin("SetGeneralProp", model);
        api.actionRun("set", "label", textvalue);
        api.actionEnd("SetGeneralProp");
        $(roomNameTextValue).val(textvalue);
        var curPid = null;
        if(model.floorMaterial){
            curPid =model.floorMaterial.meta.pid;
        }
        var hasChange = getPidFromRoomdefaulttile(curPid);
        //增加判断是否已改变过地面材质 ，如果有改变就不用去调整为默认材质-- add by gaoning 2017.9.27
        if(hasChange || curPid == "beechwoodhoney"){
            /**默认地板处理*/
            appSettings.roomdefaulttile && appSettings.roomdefaulttile.forEach(function (obj, index) {
                if (textvalue == obj.label) {
                    api.catalogGetProductsMetaPromise([obj.pid]).then(function (meta) {
                        advancedPatternShowObj = {
                            pid: obj.pid,
                            xlen: meta[obj.pid].xlen,
                            ylen: meta[obj.pid].xlen,
                            model: meta[obj.pid].model
                        };
                        $("#leftcontextmenu2d .floor .leftpopup .tab_container02 .paveProcessButton button").trigger("click");
                    });
                }
            });
        }
    });
});

/*相机设置*/
//初始化
function allCameraInit() {
    initContextCameraSetting();
    newAllCameraDialogInit();
}
function initContextCameraSetting() {
    var camera = api.documentGetActiveCamera();
    $(CameraHeightTextSlider).val(camera.z * 1000);
    $(CameraVisionTextSlider).val(camera.hfov);
    $(CameraPitchTextSlider).val(camera.pitch);//增加俯仰角度

    $(CameraHeightMoveSlider).slider("value", camera.z * 1000);
    $(CameraVisionMoveSlider).slider("value", camera.hfov);
    $(CameraPitchMoveSlider).slider("value", camera.pitch);//增加俯仰角度
}
/*摄像机操作*/
$('.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .cameraDetailContent table tbody').on('click','span',function () {
    var _this=$(this);
    var cameraName=_this.parent('td').parent('tr').attr('cid');
    var activeCamera = api.documentGetActiveCamera();
    var dealType=_this.attr('class');
    if(_this.hasClass('act'))dealType='act';
    var dealCamera
    api.floorplanFilterEntity(function (e) {
        return e.id == cameraName;
    }).forEach(function (c) {
        dealCamera=c;
    });
    if(dealType=='act'){
        setCameraState(dealCamera);
    }else if(dealType=='del'){
        delCustomCamera(dealCamera,activeCamera)
    }else if(dealType=='lock'){
        if(cameraName==activeCamera.id && $('#ui_toolTipBnt').length>0)tool_tip_bnt.update('group_lock',0)
        lockAdnUnlockCamera(cameraName,dealCamera,'lock')
    }else if(dealType=='unlock'){
        if(cameraName==activeCamera.id && $('#ui_toolTipBnt').length>0) tool_tip_bnt.update('group_lock',1)
        lockAdnUnlockCamera(cameraName,dealCamera,'unlock')
    }else if(dealType=='show' || dealType=='hide') {
        if(cameraName==activeCamera.id){
            hideActiveCamera()
        }
    }
})
//隐藏相机
function hideActiveCamera() {
    var cameraTag = $("#paper2dsvg").find("g[type='CAMERA']");
    var cameraTagLock = $("#paper2dsvg").find("g[type='LOCKCAMERA']");
    cameraTag.css("display", (cameraTag.css("display") == "none" ? "block" : "none"));
    cameraTagLock.css("display", (cameraTagLock.css("display") == "none" ? "block" : "none"));
    allCameraInit();
}
//激活相机
function setCameraState(camera) {
    if(camera.lock){
        camera.lock=false;
        api.documentSetActiveCameras([camera.id]);
        setTimeout(function () {
            camera.lock=true;
            allCameraInit();
        },100)
    }else{
        api.documentSetActiveCameras([camera.id]);
        allCameraInit();
    }
    tool_tip_bnt && (tool_tip_bnt.model.type=='CAMERA' && tool_tip_bnt.destroy())

}
//相机命名
$('.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .cameraDetailContent table tbody').on('change','input',function () {
    var text=$.trim($(this).val());
    var _this=$(this);
    var cameraName=_this.parent('td').parent('tr').attr('cid');
    var activeCamera = api.floorplanFilterEntity(function (e) {
        return e.id == cameraName;
    });
    activeCamera[0].name = text;
})
//锁定相机
function lockAdnUnlockCamera(cameraName,dealCamera,del) {
    var activeCamera=api.documentGetActiveCamera();
    var cameraTag = $("#paper2dsvg").find("g[type='CAMERA']");
    var cameraTagLock = $("#paper2dsvg").find("g[type='LOCKCAMERA']");
    cameraTagLock.css("display","block");
    if(cameraTag.css("display") == "none")cameraTagLock.css("display","none");
    if(del=='lock'){
        dealCamera.lock=false;
    }else{
        dealCamera.lock=true;
    }
    allCameraInit();
}
//删除相机
function delCustomCamera(dealCamera,activeCamera) {
    if (dealCamera.id.indexOf("id") == -1) {
        layer.alert("只可以删除自定义的摄像机");
        return;
    } else if (dealCamera.id == activeCamera.id) {
        layer.alert("当前正在使用的摄像机不可以删除");
        return;
    }
    api.actionBegin("DeleteProduct",dealCamera);
    allCameraInit();
}

/*家具设置*/
//家具初始化
function productModelUiInit(model) {
    // var picked = api.pickGetPicked()[0];
    // var model = picked.model;
    var meta = model.meta;
    $(productLeftContextMenuLl).hide();
    $(productLeftContextMenuUl).find('li.name').html(meta && meta.title)
    var lightsElement = $(productLeftContextMenuUl).find('li.lighting_render');
    var tileElement = $(productLeftContextMenuUl).find('li.name');
    var groupElement = $(productLeftContextMenuUl).find('li.group');
    lightsElement.hide();
    tileElement.show();
    $(productLeftContextMenuUl).find('li.name').trigger(click);
    if (showLightRenderSettings(model)) {
        lightsElement.show();
        initLeftContextMenuLightRenderSettings(model);
    }
    if (model && model.group) {
        groupElement.show();
        $(productLeftContextMenuUl).find('li.group').trigger(click);
    }

    $("#contextmenu3d .product .popup .tab:first").trigger(click);
    return;
    if (pickedMaterial()) {
        tileElement.show();
        $("#contextmenu3d .product .popup .tab_head .tile").trigger(click);
        if (pickedMaterial().type == 'MATERIAL' || pickedMaterial().type == 'TILESINGLE') {
            $(global_material_single_advanced_icon).parents("li").show();
        }
    }
}

function initLeftContextMenuLightRenderSettings(prod) {
    leftContextResetLightRenderSettingsUI(prod);
    $(productLightShowColorList).removeClass('on')
    if (prod && prod.userDefined && prod.userDefined.light_settings) {
        log(productLightShowColorCheckBox,productLightShowColorBrightnessText,productLightColorWidget)
        var setting = prod.userDefined.light_settings;
        if (setting.on !== undefined)$(productLightShowColorCheckBox).prop("checked", setting.on);
        if (setting.multiplier !== undefined)$(productLightShowColorBrightnessText).val(setting.multiplier);
        if (setting.colorHex !== undefined){
            $(productLightColorWidget).spectrum("set", setting.colorHex);
            $(productLightShowColor).attr({
                "value": setting.colorHex,
                "rgb": setting.colorRgb
            }).css({
                "background":setting.colorHex
            })
            for(var i=0;i<$(productLightShowColorList).length-1;i++){
                var _this=$(productLightShowColorList)[i];
                if($(_this).attr('value')==setting.colorHex){
                    $(_this).addClass('on')
                }
            }
        }
    }
}
function leftContextResetLightRenderSettingsUI(prod) {
    var brightness = prod.meta.subcategory == "ies" ? 1.0 : 30;
    $(productLightShowColorBrightnessText).val(brightness);
    $(productLightShowColorCheckBox).prop("checked", true);
    $(productLightColorWidget).spectrum("set", "#f0f0f0");
    $(productLightShowColor).attr({
        "value": "#f0f0f0",
        "rgb": "rgb(240, 240, 240)"
    }).css({
        "background":"#f0f0f0"
    })
    $(productLightName).html(prod.meta.subcategory == "ies" ? "IES倍增" : "灯光倍增");
}

function productInfoListInt(model) {
    //var model = api.pickGetPicked()[0].model;
    var meta = model.meta;
    $(ProductSliderLengthText).val(Math.ceil(model.sx * meta.xlen * 1000));
    $(ProductSliderWidthText).val(Math.ceil(model.sy * meta.ylen * 1000));
    $(ProductSliderHeightText).val(Math.ceil(model.sz * meta.zlen * 1000));
    $(ProductSliderFloorHeightText).val(Math.ceil(model.z * 1000));
    $(ProductSliderRotText).val(Math.ceil(model.rot));
    //右键窗口标题显示模型名称add by zk  2017.5.8
    //$(global_product_modelName).text(model.meta.title + model.index);
    $(ProductSliderLengthMove).slider("value", model.sx * 100);
    $(ProductSliderWidthMove).slider("value", model.sy * 100);
    $(ProductSliderHeightMove).slider("value", model.sz * 100);
    $(ProductSliderFloorHeightMove).slider("value", Math.ceil(model.z * 1000));
    $(ProductSliderRotMove).slider("value", model.rot);
    if (model.flip) {
        $(GlobalProductflip).prop("checked", true);
    } else {
        $(GlobalProductflip).prop("checked", false);
    }
}
/*柱子 地台 横梁 */
function StructureInfoListInit(model) {
    $(structureSliderLengthMove).slider("value", model.sx * 1000);
    $(structureSliderLengthText).val(Math.ceil(model.sx * 1000));
    $(structureSliderWidthMove).slider("value", model.sy * 1000);
    $(structureSliderWidthText).val(Math.ceil(model.sy * 1000));
    $(structureSliderHeightMove).slider("value", model.sz * 1000);
    $(structureSliderHeightText).val(Math.ceil(model.sz * 1000));
    $(structureSliderFloorHeightMove).slider("value", model.z * 1000);
    $(structureSliderFloorHeightText).val(Math.ceil(model.z * 1000));
    $(structureSliderRotMove).slider("value", model.rot);
    $(structureSliderRotText).val(Math.ceil(model.rot));
}
/*组合设置*/
function GroupInfoListInit(model) {
    var group =model;
    $(GroupSliderRotText).val(group.rot);
    $(GroupSliderRotMove).slider("value", group.rot);
    $(GroupNameText).val(group.name);
    if (group.id == "TempGroup") {
        $(GroupNameText).html("临时组合");
        $(GroupNameText).attr("disabled", "disabled");
    } else {
        $(GroupNameText).removeAttr("disabled");
    }
}
//# sourceURL=ui/contextleftpopup/contextleftpopup_init.js