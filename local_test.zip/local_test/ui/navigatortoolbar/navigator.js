api.application_ready_event.add(function (setting) {
    if (isMobileDevice()) {
        $("#toolbar_navigator").hide();
    }
});
$(".header").draggable({"helper": null, "opacity": 0.3})
    .on("drag", function (event, ui) {
        $(this).parent().offset(ui.offset);
    });

$(document).on('keydown', null, "Alt+w", function () {
    var svgIsActive = ($("#main-design-area").has("#paper2dsvg").length != 0);
    svgIsActive ? view3DFirstPersonActiveHandler() : view2DActiveHandler();
});

/*2D视图*/
$("#viewButtonUndoId").on(click, function (e) {
    api.actionUndo();
});

$("#viewButtonRedoId").on(click, function (e) {
    api.actionRedo();
});

/*2D视图*/
$("#viewButton2DId").on(click, view2DActiveHandler);

$("#viewButton2DNoCeilingId").on(click, function () {
    tool_tip_bnt && tool_tip_bnt.show();
    view2DActiveHandler();
});
$("#viewButton2DCeilingId").on(click, function () {
    view2DActiveHandler();
    var mode = "showCeilingProductLayer";
    var view2d = api.getViewById("2d");
    var isChecked = view2d.settings[mode];
    view2d.changeSettings(mode, !isChecked);
});

/*3D平视*/
$("#viewButton3DId").on(click, view3DFirstPersonActiveHandler);

/*3D鸟瞰*/
$("#viewButton3DRoamId").on(click, view3DBirdViewActiveHandler);

/*全屏*/
$("#viewButtonFullScreenId").on(click, view3dFullScreenHandler);

/**/
$("#viewShowHideGoodsId").on(click, function () {
    showHideProductPanelPrompt();
});
/*清空房间*/
$("#viewClear").on(click, function (e) {
    /*layer.confirm('确定要清空当前设计吗？', {
     btn: ['确定', '取消'], //按钮
     shade: 0.3, //不显示遮罩
     skin: 'layui-layer-default',
     title: '提示'
     }, function (index) { //layer.msg('确定', {icon: 1});
     layer.close(index);
     view2DActiveHandler();
     fileNewHandler();
     }, function () { //layer.msg('取消', {shift: 6});
     });*/
    //if (typeof saveCloudDesignPanelPrompt == "function")saveCloudDesignPanelPrompt("modelroom");

    var picked = api.pickGetPicked()[0];
    var room = picked && picked.model;

    if (!room || room.type != "FLOOR") {
        layer.alert("请先选中房间！", {title: '提示', skin: 'layui-layer-default'});

    } else {


        layer.alert("确实要恢复成毛坯房吗？这将清空房间内所有的家具和地面墙面布置。", {title: '提示', skin: 'layui-layer-default'}, function (index) {
            layer.close(index);
            if (!room || room.type != "FLOOR")return;
            room.reset({
                product_remove_old: true,
                floorarea: true,
                floorMaterial: true, //清空房间里不清除地砖
                wallarea: true,
                wallMaterial: true,
                product_other_model_delete: true
            });
            closeContextMenu();
        });

    }
});

/*重新设计*/
$("#redesign").on(click, function (e) {

    layer.confirm('您确定要重新设计吗？', {
        btn: ['确定', '取消'],
        shade: 0.3,
        skin: 'layui-layer-default',
        title: '提示'
    }, function (s) {
        laberFrame()//清空物体标注线输入框 add by hcw
        layer.close(s);
        fileNewHandler();
        $(".contextmenu_root").hide();
        tool_tip_bnt.destroy();
        index = 1;
    }, function () {
    });

});


$("#viewButtonLightToggleId").on(click, function () {
    var mode = "showIESProductLayer";
    var view2d = api.getViewById("2d"), view3d = api.getViewById("3d");
    var isChecked = view2d.settings[mode];
    view2d.changeSettings(mode, !isChecked);
    view3d.changeSettings(mode, !isChecked);
});
//# sourceURL=ui\navigatortoolbar\navigator.js