var Util = function(){
return {
    'processDropdownlist': function() {
      var _this = this;

      jQuery( '.dropdownlist' ).each( function() {
        _this.simpleDropdownlist( this );
      });
    },
    // create dropdown list
    'simpleDropdownlist': function( /* dropdownlist selector */ selector ) {

      var ddContainer = jQuery( selector );

      var iset = {
        'name': ddContainer, //容器
        //'select': jQuery('.dropdownlist>dl'), //dl列表
        'select': jQuery( 'dl', ddContainer ), //dl列表
        'drop_class': 'drop', //收藏状态dt的样式
        'shrink_class': 'shrink', //展开状态dt的样式
        'hover_class': 'hover', //鼠标划过dd时的样式
        'default_value_class': 'default-value',
        'clearTime': 100, //允许用户快速划过不触发的时间(ms)
        'dropTime': 100, //展开时间(ms)
        'shrinkTime': 100, //收缩时间(ms)
        'selectVal': null //选择的值传到此元素中
      };

      var mainHeight = iset.name.height();//容器高度
      var selectHeight = iset.select.height(); //dl实际高度
      var curTxt = jQuery( 'dt', iset.select ).text(); //dt默认内容
      var _self = null;
      var hoverElem = null; //避免用户快速划过时触发事件

      iset.name.each(function() {
          var _self = this;
          var $self = jQuery( this );

        $self.hover(function(){
            hoverElem = setTimeout(function(){
                //鼠标划过时,展开dl
                jQuery(_self)
                .stop( true, false )
                .velocity({ height: selectHeight }, iset.dropTime );

                // if ( jQuery( 'dt', $self ).text() == curTxt ) {
                    //判断是否有选择下拉列表,若无则改变dt样式
                    jQuery( 'dt', $self ).attr('class', iset.drop_class );
                // }
                //dd的鼠标事件
              }, iset.clearTime);
            },
            function() {
              //鼠标移出后触发的事件
              clearTimeout(hoverElem);

              $self
              .stop(true, false)
              .velocity({ height: mainHeight }, iset.shrinkTime);

              //if ( jQuery( 'dt', $self ).text() == curTxt ) {
                  jQuery( 'dt', $self ).attr('class', iset.shrink_class);
              //}
            }
        );

        jQuery(this).find('dd')
        .mouseover(function(){
          jQuery(this)
          .addClass(iset.hover_class)
          .siblings()
          .removeClass(iset.hover_class);
        })
        .click(function(){
          //鼠标点击时取值并赋给dt
          var $self = jQuery(_self);
          var $select = jQuery(this);
          var selectText = $select.text();
          var selectValue = $select.attr( 'data-dropdown-value' );

          jQuery( 'dt', $self ).text( selectText );
          //为表单传值
          var selectedText = !$select.hasClass( iset[ 'default_value_class' ] ) ? selectText : '';
          var selectedValue = !$select.hasClass( iset[ 'default_value_class' ] ) ? selectValue : '';

          jQuery( 'input.select-text', $self ).val( selectedText );
          jQuery( 'input.select-value', $self ).val( selectValue );

          $self
          .stop(true, false)
          .velocity({height: mainHeight}, iset.shrinkTime);
        })
        //.removeClass(iset.hover_class);
      });
    }
}

}();
