var typeTipMap = {
    "door": "按空格鍵旋转开门方向",
    "product": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制"
};

var typeTipMap2 = {
    "door#casementdoor": "按空格鍵旋转开门方向",
    "door#slidingdoor": "按空格鍵旋转开门方向",
    "furniture#surface": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#seat": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#decoration": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#light": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#ceiling": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#carpet": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#ies": "",
    "furniture#filllight": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#backgroundwall": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制",
    "furniture#backgroundwall_light": "按空格鍵快速旋转,Ctrl多选成组<br>3D下按Alt以视点旋转,Z键居中<br>拖动时按Shift可复制"
};


function MakeTip(msg) {
    var layerTipsIndex = layer.msg(msg, {
        offset: '110px',
        //icon: 0,
        //skin:'layui-layer-lan',
        time: 2000
    });
}
api.application_ready_event.add(function () {
    api.pickChangedEvent.add(function (changedType, result) {
        if (isMobileDevice() == true)return;// mobile will not show tip.

        if (changedType != 'select') return;
        if (!result || !result.model) return;
        
        if (result.model.type == "FREEAREA"|| result.model.type == "ROUNDAREA" || result.model.type == "RECTAREA"){
 
            MakeTip("默认按中心点或边缘对齐吸附，按住Alt取消");
            return;
        }
        
        
        var model = result.model;
        if (!model.meta) return;
        //var msg = typeTipMap[model.type.toLowerCase()];
        var msg = typeTipMap2[model.meta.category + "#" + model.meta.subcategory];
        if ("furniture" == model.meta.category && "ies" == model.meta.subcategory) {
            var userDefined = model.userDefined || {};
            var light_settings = userDefined.light_settings || {};
            var colorHex = light_settings.colorHex || "";
            var multiplier = light_settings.multiplier || "";
            msg = "<span style='float:left;'>颜色值:</span>" + "<span style='float:left;display:block;width:20px;height:20px;background-color: " + colorHex + "'></span>" + "&nbsp;IES倍增值:" + multiplier;
        }
        if (!msg)return;
        MakeTip(msg);
    });

    api.actionBeginEvent.add(function (action, actionType, args) {
        return;
        if (actionType == "AddProduct") {
        }
    });
    api.actionEndEvent.add(function (action, actionType, args) {
        return;
        if (actionType == "AddWall") {
        }
    });
});

//# sourceURL=ui/tipbar/tip.js