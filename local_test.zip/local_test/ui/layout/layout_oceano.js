
$("#tab-container .tab").off('click') ;
$("#tab-container .tab").on('click', function (e) {
    var pandelId = $(this).attr('id').substring(4);
    if (pandelId == 'panelModelRoomId') {/*点击样板间tab页加载数据*/
        openModelRoomPanelPrompt() ;
        return ;
    }
    if (pandelId == 'panelProductMaterialId') {/*点击我的素材tab页加载自定义标签*/
        $("#productMaterialdefaultId").trigger("click");
    }
    $('#' + pandelId).css({"visibility": "visible"});
    $('#' + pandelId).siblings().css({"visibility": "hidden"});
});


//# sourceURL=ui\layout\layout_oceano.js
