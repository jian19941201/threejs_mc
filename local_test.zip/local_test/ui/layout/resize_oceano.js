function brandPageResized() {
    $("body").height( $(window).height() );
    var bannerHeight = $('#comp-banner').height();
    var tabContainerWidth = $('#tab-container').width();

    $("#menu-container").offset({top: 0, left: tabContainerWidth + 20}).width("auto");
    $("#compass-container").offset({top: bannerHeight + 20, left: tabContainerWidth + 37});

    /*margin-top:12px */
    $('.catalog .catalogRoomLeft,.catalog .catalogRoomRight').css('height', $('.catalog .catalogRoomLeft').height()-12 + 'px');

    /*margin-bottom:12px */
    $('#productContent').css('height', ($('#productContent').height()-12) + 'px');

    /*视图预览窗口，editor3d.js*/
   /* var classobj = {"top": $(window).height() - 275, "left": $(window).width() - 230};
    $("div[aria-describedby='threedViewId']").css(classobj);*/
}

//# sourceURL=ui/layout/resize_oceano.js
