/*页面遮罩代码  开始*/
$.blockUI({
    message: '页面加载中，请稍后。。。',
    growlCSS: {
        border: '2px solid #646464'
    }
});
/*页面遮罩代码  结束*/

$(window).bind('resize', function () {
    resizePage();
});

api.application_ready_event.add(function (setting) {
    if (isMobileDevice()) {
        $("#tab-container").hide();
        $("#viewcontent").hide();
        $("#banner-container").hide();
        $("#footer-container").hide();
        $("#all-spacearea-container").hide();
        $("#compass-container").hide();
    }
});
$(window).ready(function () {
    resizePage();
});

function resizePage() {
    var documentHeight = $(document).height();///*文档高度*/
    var windowHeight = $(window).height();///*窗口高度*/
    var windowWidth = $(window).width();

    $("body").height(windowHeight);
    var menuHeight = $("#menu-container").height();
    var bannerHeight = $("#comp-banner").is(":hidden") ? 0 : $('#comp-banner').outerHeight();///*logo区域高度*/
    var tabContainerHeight = $("#tab-container").is(":hidden") ? 0 : $('#tab-container').height();///*左侧边栏tab页高度*/
    var tabContainerHeight = $("#tab-container").is(":hidden") ? 0 : $('#tab-container').height();///*左侧边栏tab页高度*/compassI
    var tabContainerWidth = $("#tab-container").is(":hidden") ? 0 : $('#tab-container').width();///*左侧边栏tab页width*/
    var footerHeight = 0;
    if ($("#comp-footer").height()) {
        footerHeight = $("#comp-footer").is(":hidden") ? 0 : $('#comp-footer').height();///*文档高度*/
    }
    var paper2dHeight = windowHeight - bannerHeight - footerHeight;///*2d画布高度*/

    $("#main-design-area").offset({top: bannerHeight, left: tabContainerWidth});
    $('#main-design-area').height(paper2dHeight);
    $('#main-design-area').width(windowWidth - tabContainerWidth);

    $('#tab-container').height(paper2dHeight);
    $("#menu-container").offset({top: bannerHeight, left: tabContainerWidth});
    $("#menu-container").width($("#mainLayoutId").width() - tabContainerWidth);

    $("#compass-container").css("position", "absolute");
    $("#compass-container").offset({top: bannerHeight + menuHeight + 5, left: tabContainerWidth});

    $("#all-spacearea-container").css("position", "absolute");
    $("#all-spacearea-container").offset({left: tabContainerWidth});

    $("#ruler-measure-container").css("position", "absolute");
    $("#ruler-measure-container").offset({left: tabContainerWidth});

    var etabsHeight = $('.tab-container .etabs').outerHeight(true);///*tab页面类别高度*/
    $('.tab-container .modelroom').css('height', (paper2dHeight - etabsHeight) + 'px');
    var modelroom_style = $('.tab-container .modelroom .style_content').height();
    var modelroom_pagination = $('.tab-container .modelroom .pagination_content').height();
    $('.tab-container .modelroom .list_content').css('height', (paper2dHeight - etabsHeight - modelroom_style - modelroom_pagination) + 'px');

    $('.catalog .catalogRoomLeft,.catalog .catalogRoomRight').css('height', (paper2dHeight - etabsHeight ) + 'px');

    var searchHeight = $("#search").is(":hidden") ? 0 : $('#search').outerHeight(true);

    /*只计算一次分页div的高度*/
    var pageObj=$(".catalog .catalogProductPagination");
    var pageHeight=pageObj.outerHeight(true);
    if( !pageObj.attr("data-height") ) {
        pageObj.attr("data-height",pageHeight);
    }
    var catalogProductPagination = pageObj.is(":hidden")?0: pageHeight;
    $('#productContent').css('height', (paper2dHeight - searchHeight - etabsHeight - catalogProductPagination) + 'px');

    /*只计算一次分页div的高度*/
    var searchHeightMaterial = $("#materialSearch").is(":hidden") ? 0 : $('#materialSearch').outerHeight(true);
    var pageObjMaterial=$(".catalogMaterial .catalogMaterialPagination");
    var pageHeightMaterial=pageObjMaterial.outerHeight(true);
    if( !pageObjMaterial.attr("data-height") ) {
        pageObjMaterial.attr("data-height",pageHeightMaterial);
    }
    var catalogMaterialPagination = pageObjMaterial.is(":hidden")?0: pageHeightMaterial;
    $('#materialContent').css('height', (paper2dHeight - searchHeightMaterial - etabsHeight - catalogMaterialPagination-12) + 'px');
    //console.log(paper2dHeight - searchHeightMaterial - etabsHeight - catalogMaterialPagination);

    brandPageResized();
}
function brandPageResized() {
    // todo overwrite this function in your brand js code.
}

//# sourceURL=ui/layout/resize.js
