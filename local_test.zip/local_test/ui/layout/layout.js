var $body = jQuery('body');

$("#tab-container .tab").on('click', function (e) {
    var pandelId = $(this).attr('id').substring(4);
    if (pandelId == 'panelModelRoomId') {/*点击样板间tab页加载数据*/
        $(".modelroom .modelroomList").empty();
        initModelRoomData();
        $('#' + pandelId).show();
        $('#' + pandelId).siblings().hide();
        return ;
    }
    $('#' + pandelId).show();
    $('#' + pandelId).siblings().hide();
});

$("#comp-banner").appendTo("#banner-container");
$("#comp-footer").appendTo("#footer-container");
$("#paper2d").appendTo("#main-design-area");
$("#menubar").appendTo("#menu-container");
$("#compassId").appendTo("#compass-container");
$("#scale_barId").appendTo("#compass-container");
$("#allSpaceAreaId").appendTo("#all-spacearea-container");
$("#rulerMeasurmentId").appendTo("#ruler-measure-container");

//# sourceURL=ui\layout\layout.js
