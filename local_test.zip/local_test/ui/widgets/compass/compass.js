var initCompassData = function (degree) {
    var init = degree;
    var initdeg = 360 - init;
    transformRotateObj($("#compass-container .compass_img"), initdeg);
    $("#compass-container .compass_img")
        .on("mousedown", function (e) {
            var r = 0;
            init = init + 45;
            if (init == 360) init = 0;
            r = 360 - init;
            transformRotateObj($(this), r);
            api.floorplanSetCompassRotation(init);
        });
};

var transformRotateObj = function (jqueryobj, degress) {
    jqueryobj.css("transform", "rotate(-" + degress + "deg)");
    jqueryobj.css("-moz-transform", "rotate(-" + degress + "deg)");
    jqueryobj.css("-webkit-transform", "rotate(-" + degress + "deg)");
    jqueryobj.css("-o-transform", "rotate(-" + degress + "deg)");
};

api.application_ready_event.add(function () {
    initCompassData(0);
    api.documentReadyEvent.add(function () {
        transformRotateObj($("#compass-container .compass_img"), 360 - api.floorplanGetCompassRotation());
    })
});

//# sourceURL=ui\widgets\compass.js