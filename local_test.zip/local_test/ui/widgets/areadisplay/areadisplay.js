$("#all-spacearea-container input[name='spaceAreaRadio']").on("click", function (e) {
    $("#all-spacearea-container .explain ." + $(this).val()).removeClass("hide");
    $("#all-spacearea-container .explain ." + $(this).val()).siblings().addClass("hide");

    var area_name = "套内面积";
    if ($(this).val() == "inner") area_name = "净面积";
    $("#all-spacearea-container .area_name").text(area_name);
    api.structureChangedEvent.dispatch();
});

$("#all-spacearea-container .question_mark").on("mouseover", function (e) {
    $("#all-spacearea-container .area_hide_content").show();
}).on("mouseleave", function (e) {
    $("#all-spacearea-container .area_hide_content").on("mouseover", function (e) {
        $(this).show();
    }).on("mouseleave", function (e) {
        $(this).hide();
    }).hide();
});


api.application_ready_event.add(function () {
    api.structureChangedEvent.add(function () {
        var outerArea = api.floorplanFilterEntity(function (e) {
            return e.type == "FLOOR";
        }).map(function (e) {
            return e.getMeasurement();
        }).reduce(function (p, c) {
            return p + c;
        }, 0);

        var innerArea = api.floorplanFilterEntity(function (e) {
            return e.type == "FLOOR";
        }).map(function (e) {
            return e.getMeasurement("inner");
        }).reduce(function (p, c) {
            return p + c;
        }, 0);

        var spaceAreaRadio = $("#all-spacearea-container input[name='spaceAreaRadio']:checked").val();
        var area_value = 0;
        if ("outer" == spaceAreaRadio) area_value = Math.ceil(outerArea * 100) / 100;
        if ("inner" == spaceAreaRadio) area_value = Math.ceil(innerArea * 100) / 100;
        $("#all-spacearea-container .area_value").text(area_value);
        $(".saveCloudDesignPanel input[name='roommeasurement']").val( Math.ceil(innerArea * 100) / 100 ) ; /*保存时使用*/
    });
});

//# sourceURL=ui\widgets\areadisplay.js