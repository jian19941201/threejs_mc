//标注框显示
function laberFrame(product) {
    $(".label_box .label_length").blur();
    $("#line_input_id_l").hide();
    $("#line_input_id_r").hide();
    $("#line_input_id_b").hide().css({
        "transform": "rotate(90deg)",
        "-webkit-transform":"rotate(90deg)",
        "-moz-transform":"rotate(90deg)"});
    $("#line_input_id_t").hide().css({
        "transform": "rotate(90deg)",
        "-webkit-transform":"rotate(90deg)",
        "-moz-transform":"rotate(90deg)"});
    var view = api.getViewById("2d");
    if(product&&is2DViewActive()){
        if(product.type=='GROUP' && product.children.length==0)return;
        if(product.hasOwnProperty('textpos')&&product.isdelete==0){
            var textpos=product.textpos;
            if(textpos.length>0){
                textpos.forEach(function (text,i) {
                    //获取物体所在的位置
                    var svgInfo=view.domElement.getBoundingClientRect()
                    var left=svgInfo.width/view.viewport.width*Math.abs(view.viewport.left)+$('#tab-container').width()+text.x*svgInfo.width/view.viewport.width
                        ,top=svgInfo.height/view.viewport.height*Math.abs(view.viewport.top)+$('#banner-container').height()+text.y*svgInfo.height/view.viewport.height
                    if(view.viewport.left>0){
                        left=$('#tab-container').width()+text.x*svgInfo.width/view.viewport.width-svgInfo.width/view.viewport.width*Math.abs(view.viewport.left)
                    }
                    if(view.viewport.top>0){
                        top=$('#banner-container').height()+text.y*svgInfo.height/view.viewport.height-svgInfo.height/view.viewport.height*Math.abs(view.viewport.top)
                    }
                    var pos = {top:top,left:left};
                    var minshow=text.dis2*(svgInfo.width/view.viewport.width);//输入框最小距离显示
                    if(left>$('#tab-container').width()&&top>$('#banner-container').height()&&minshow>$("#line_input_id_"+text.type).width()){
                        //输入框显示
                        $("#line_input_id_"+text.type).show();
                        $("#line_input_id_"+text.type).find('.label_length').val(text.text).attr('cid',text.type).css({'width':(text.text).toString().length*8+'px'})
                        if(text.type=='l'||text.type=='r'){
                            pos.top=pos.top-$("#line_input_id_"+text.type).find('.label_length').height()
                            pos.left=pos.left-$("#line_input_id_"+text.type).find('.label_length').width()/2
                        }
                        if(text.type=='b'||text.type=='t'){
                            pos.top=pos.top-$("#line_input_id_"+text.type).find('.label_length').width()/2
                            pos.left=pos.left-($("#line_input_id_"+text.type).find('.label_length').height()/3)*2
                        }
                        $("#line_input_id_"+text.type).offset(pos);
                    }
                })
            }else{
                $("#line_input_id_r").offset({top: -200, left: -200}).hide()
                $("#line_input_id_l").offset({top: -200, left: -200}).hide()
                $("#line_input_id_t").offset({top: -200, left: -200}).hide()
                $("#line_input_id_b").offset({top: -200, left: -200}).hide()
            }
        }
   }
}

$(".label_box .label_length").bind(
    {
        click:function (event) {
            $(this).focus().select()
        },
        keydown: function (event) {
            if (event.keyCode == 13) {/*回车键*/
                var pickObjs = api.pickGetPicked(function (e) {
                    return e;
                });
                if(pickObjs[0].model.textpos){
                    var texttype=$(this).attr('cid');
                    var positive_float = /^(-?\d+)(\.\d+)?$/; //浮点数
                    var length = parseFloat($(this).val());
                    if (!positive_float.test(length)) return false;
                    if (length < 0) return false;
                    $(this).select();
                   var l=0,r=0,t=0,b=0;
                    pickObjs[0].model.textpos.forEach(function(text,i){
                        if(text.type=='l')l=text.text
                        if(text.type=='r')r=text.text
                        if(text.type=='t')t=text.text
                        if(text.type=='b')b=text.text
                    })
                    pickObjs[0].model.textpos.forEach(function(text,i){
                        if(texttype==text.type){
                            var model=pickObjs[0].model.hasOwnProperty("center")?pickObjs[0].model.center:pickObjs[0].model;
                            var move=length-text.text;
                            if(texttype=='l'){
                                    if(length>=text.text){
                                        if(length>=text.text+r){
                                            move=r
                                        }
                                        model.type=="GROUP"?actionMoveGroupTo(model,{x:move/1e3,y:0},{x:move/1e3,y:0}): model.x+=move/1e3;
                                    }else{
                                        move=text.text-length;
                                        model.type=="GROUP"?actionMoveGroupTo(model,{x:-move/1e3,y:0},{x:-move/1e3,y:0}):model.x-=move/1e3
                                    }
                            }
                            if(texttype=='r'){
                                if(length>=text.text){
                                    if(length>=text.text+l){
                                        move=l
                                    }
                                    model.type=="GROUP"?actionMoveGroupTo(model,{x:-move/1e3,y:0},{x:-move/1e3,y:0}):model.x-=move/1e3
                                }else{
                                    move=text.text-length;
                                    model.type=="GROUP"?actionMoveGroupTo(model,{x:move/1e3,y:0},{x:move/1e3,y:0}):model.x+=move/1e3
                                }
                            }
                            if(texttype=='t'){
                                if(length>=text.text){
                                    if(length>=text.text+b){
                                        move=b
                                    }
                                    model.type=="GROUP"?actionMoveGroupTo(model,{y:-move/1e3,x:0},{y:-move/1e3,x:0}):model.y-=move/1e3
                                }else{
                                    move=text.text-length;
                                    model.type=="GROUP"?actionMoveGroupTo(model,{y:move/1e3,x:0},{y:move/1e3,x:0}):model.y+=move/1e3
                                }
                            }
                            if(texttype=='b'){
                                if(length>=text.text){
                                    if(length>=text.text+t){
                                        move=t
                                    }
                                    model.type=="GROUP"?actionMoveGroupTo(model,{y:move/1e3,x:0},{y:move/1e3,x:0}):model.y+=move/1e3
                                }else{
                                    move=text.text-length;
                                    model.type=="GROUP"?actionMoveGroupTo(model,{y:-move/1e3,x:0},{y:-move/1e3,x:0}):model.y-=move/1e3
                                }
                            }
                        }
                    })
                }
            }
        }
    }
    );

$('#line_input_id_t,#line_input_id_b').click(function(){
    $(this).css({
        "transform": "rotate(0deg)",
        "-webkit-transform":"rotate(0deg)",
        "-moz-transform":"rotate(0deg)"
    })
})
function actionMoveGroupTo(mode,position) {
    api.actionBegin("MoveGroup",mode);
    api.actionRun("mousemove2d","",position,position)
    api.actionEnd()
}
//# sourceURL=ui\widgets\drawwall_input.js