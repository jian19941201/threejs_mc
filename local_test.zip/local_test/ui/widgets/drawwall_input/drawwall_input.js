api.application_ready_event.add(function () {
    api.actionBeginEvent.add(function (action, actionType, args) {
        if (actionType == "AddWall") {
            $("#draw_wall_input_id").show();
            action.mouseMoveEvt.add(drawWall_onMouseMove);
        }
    });
    api.actionEndEvent.add(function (action, actionType, args) {
        if (actionType == "AddWall") {
            action.mouseMoveEvt.remove(drawWall_onMouseMove);
            $("#draw_wall_input_id").offset({top: -200, left: -200}).hide();
        }
    });
});
function drawWall_onMouseMove(cmd, e) {
    var pos = {top: e.pageY + 10, left: e.pageX + 10};
    $("#draw_wall_input_id").offset(pos);
    $("#draw_wall_input_id .wall_length").focus();
    //$("#draw_wall_input_id .wall_length").select();
}

$("#draw_wall_input_id .wall_length").bind("keydown", function (event) {
    if (event.keyCode == 13) {/*回车键*/
        var positive_float = /^(-?\d+)(\.\d+)?$/; //浮点数
        var length = parseFloat($(this).val());

        if (!positive_float.test(length)) return false;
        if (length < 20) return false;
        $(this).select();

        api.actionRun("setLength", event, (length + 150) / 1000);
    } else if (event.keyCode == 27) {// ESC
        api.actionRun("ESC");
    } else if (event.keyCode == 115) { // F4
        api.actionRun("keydown", event);
    }
});
//# sourceURL=ui\widgets\drawwall_input.js