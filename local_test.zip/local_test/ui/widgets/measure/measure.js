api.application_ready_event.add(function () {
    api.rulerMeasurementChanged.add(function (measure) {
        if (measure == undefined) {
            $("#rulerMeasurmentId").hide();
        } else {
            $("#rulerMeasurmentId").show();
            $("#rulerMeasurmentId .length_value").text(toFixedNumber(measure, 2));
        }

    });
})
;

//# sourceURL=ui\widgets\measure.js