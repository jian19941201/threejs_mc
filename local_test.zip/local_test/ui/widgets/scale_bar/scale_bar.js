var Scale_bar_fit_viewport = undefined;

$("#scale_barId .zoom-in").on(click, function () {
    var value = $("#scale_barId .slider-2d-nopole-zoom").slider("value");
    value += 5;
    if (value > 200) return;
    var view = api.getViewById("2d");
    if (!Scale_bar_fit_viewport)Scale_bar_fit_viewport = view.viewport;
    view.zoom(1);
    $("#scale_barId .slider-2d-nopole-zoom").slider({value: value});

});
$("#scale_barId .zoom-out").on(click, function () {
    var value = $("#scale_barId .slider-2d-nopole-zoom").slider("value");
    value -= 5;
    if (value < 20) return;
    var view = api.getViewById("2d");
    if (!Scale_bar_fit_viewport)Scale_bar_fit_viewport = view.viewport;
    view.zoom(-1);
    $("#scale_barId .slider-2d-nopole-zoom").slider({value: value});

});
$("#scale_barId .zoom-location").on(click, function () {
    var view = api.getViewById("2d");
    view.fit();
    view.resetFontSize();  //重设字体位置。
    Scale_bar_fit_viewport = view.viewport;
    $("#scale_barId .slider-2d-nopole-zoom").slider({value: 110});

    //再调用设置，让字体排列好。
    view.fit();
    view.resetFontSize();
});

$("#scale_barId .slider-2d-nopole-zoom")
    .slider({min: 20, max: 200, step: 5, value: 110, orientation: "vertical"})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "%"})
    .on("slidestart", function (e, ui) {
        this._current = ui.value;
    })
    .on("slide", function (e, ui) {
        api.getViewById("2d").zoom(ui.value - this._current);
        this._current = ui.value;
    })
    .on("slidestop", function (e, ui) {
        delete this._current;
    });

api.application_ready_event.add(function () {
    var view2d = api.getViewById("2d");
    view2d.zoomChangedEvent.add(function (viewport, factor) {
        var oldValue = $("#scale_barId .slider-2d-nopole-zoom").slider("value");
        $("#scale_barId .slider-2d-nopole-zoom").slider("value", oldValue + (factor < 1 ? 5 : -5));
    });
});
