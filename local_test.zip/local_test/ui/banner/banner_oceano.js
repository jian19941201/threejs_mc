$("#comp-banner").tooltip() ;
$("#comp-banner .fullscreen").on(click, view3dFullScreenHandler);
$("#comp-banner .save").on(click, function () {
    $("#menuFileNewSaveCloud").trigger("click") ;
});
$("#comp-banner .measure").on(click, rulerMeasure);
$("#comp-banner .show").on(click, function () {
    showHideProductPanelPrompt();
});
$("#comp-banner .text #textnode").on(click, addTextAnnotation2);
$("#comp-banner .text #textlabel").on(click, addTextAnnotation);
$("#comp-banner .text ").on("mouseover", function (e) {
    $(this).find('.options').addClass("hover");
}).on("mouseleave", function (e) {
    $(this).find('.options').removeClass("hover");
});


$("#comp-banner .setting").on(click, function(){
    viewOptionsPanelPrompt();
});
$("#comp-banner .camera").on(click, selectCamera);
$("#comp-banner .new").on(click, function (e) {
    //newCloudDesignPanelPrompt();
    //index = 1;
    window.open(getHomeDesignFullUrl({"notEdit":"0"}));
/*    layer.confirm('您确定要新建吗？', {
        btn: ['确定', '取消'],
        shade: 0.3,
        skin: 'layui-layer-default',
        title: '提示'
    }, function (index) {
        layer.close(index);
        fileNewHandler();
    }, function () {
    });*/

});
//# sourceURL=ui\banner\banner_oceano.js