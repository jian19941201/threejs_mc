

 //# sourceURL=ui\banner\banner.js