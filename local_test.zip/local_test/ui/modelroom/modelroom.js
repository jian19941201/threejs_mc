$("#panelModelRoomId").empty();
$("#modelroom").appendTo($("#panelModelRoomId"));

var modelRoomDesigns = [];

function initModelRoomData(dstyle) {
    var modelRoomQueryUrl = api.getServicePrefix("design") + "/getDesignList?dtype=model";
    if (dstyle) modelRoomQueryUrl += "&dstyle=" + dstyle;
    api.getServiceJSONResponsePromise({
        type: 'GET',
        url: modelRoomQueryUrl
    }).then(function (res) {
        modelRoomDesigns = res;
        initModelRoomPanel();
    });
}

function applyGhostRoomStyle(ghostfp) {
    var ghostFloorplan = ghostfp;
    var floors = Object.keys(ghostfp).map(function (id) {
        return ghostfp[id];
    }).filter(function (item) {
        return item.type == "FLOOR";
    });

    if (!floors || floors.length == 0) {
        layer.alert("样板间中没有发现房间。", {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
        return;
    } else if (floors.length > 1) {
        layer.alert("样板间中有多个房间，不知道套用哪个房间~", {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
        return;
    }

    var picked = api.pickGetPicked();
    var pickFloor = picked[0].model;
    var pickFloorMeasurment = pickFloor.getMeasurement();
    var pickFloorHeight = pickFloor.height3d;

    var ghostFloor = floors[0];
    var ghostFloorMeasurement = ghostFloor._m || 0;
    var ghostFloorHeight = ghostFloor.height3d;

    var matchPercent = 1 - Math.abs(pickFloorMeasurment - ghostFloorMeasurement) / Math.max(ghostFloorMeasurement, pickFloorMeasurment);

    var applyconfirmdialog_LayerIndex = layer.open({
        zIndex: 500,
        type: 1,
        title: '替换确认',
        moveType: 1,
        moveOut: true,
        skin: 'layui-layer-default',
        fix: false,
        shade: false,
        shadeClose: true,
        maxmin: false,
        area: ['400px', undefined],
        content: $('#modelroom_applyconfirm_dialog'),
        success: function (idx) {
            var match_percentage = Math.max(0, Math.round(matchPercent * 100));
            $("#modelroom_applyconfirm_dialog .match_percentage").text(match_percentage);
            if (match_percentage >= 80) {
                $("#modelroom_applyconfirm_dialog .green").show();
                $("#modelroom_applyconfirm_dialog .green").siblings().hide();
            } else if (match_percentage >= 60 && match_percentage < 80) {
                $("#modelroom_applyconfirm_dialog .oranage").show();
                $("#modelroom_applyconfirm_dialog .oranage").siblings().hide();
            } else if (match_percentage < 60) {
                $("#modelroom_applyconfirm_dialog .red").show();
                $("#modelroom_applyconfirm_dialog .red").siblings().hide();
            }

            $("#modelroom_applyconfirm_dialog .modelroom_measurment").text(toFixedNumber(ghostFloorMeasurement));
            $("#modelroom_applyconfirm_dialog .currentroom_measurment").text(toFixedNumber(pickFloorMeasurment));

            $("#modelroom_applyconfirm_dialog .modelroom_height").text(toFixedNumber(ghostFloorHeight));
            $("#modelroom_applyconfirm_dialog .currentroom_height").text(toFixedNumber(pickFloorHeight));

            var applyconfig = {
                floorarea: false,
                wallarea: false,
                product_remove_old: false,
                product_add_new: false,
                floorMaterial: false,
                areaMaterial: false,
                wallMaterial: false,
                //add by gaoning
                product_other_model:false,
                product_other_model_delete:false
                //product_model_material:false
            };

            $("#modelroom_applyconfirm_dialog .checkboxset").each(function () {
                var mode = $(this).attr("mode");
                if ($(this).is(':checked')) {
                    applyconfig[mode] = true;
                } else {
                    applyconfig[mode] = false;
                }
            });

            $("#modelroom_applyconfirm_dialog .checkboxset").parent().on(click, function (e) {
                if (e.target.type == 'checkbox') return;
                var inputObj = $(this).children(".checkboxset");
                var mode = inputObj.attr("mode");
                if (inputObj.is(':checked')) { /*取消设定*/
                    inputObj.prop("checked", false);
                    applyconfig[mode] = false;
                } else { /*设定*/
                    inputObj.prop("checked", true);
                    applyconfig[mode] = true;
                }
            });

            $("#modelroom_applyconfirm_dialog .checkboxset").on(click, function (e) {
                var mode = $(this).attr("mode");
                if ($(this).is(':checked')) { /*设定*/
                    applyconfig[mode] = true;
                } else { /*取消设定*/
                    applyconfig[mode] = false;
                }
            });

            if (applyconfig.floorarea || applyconfig.wallarea) {
                applyconfig.areaMaterial = true;
            }

            if (!applyconfig.floorarea && !applyconfig.wallarea) {
                applyconfig.areaMaterial = false;
            }


            $("#modelroom_applyconfirm_dialog .ok_btn").unbind(click);

            $("#modelroom_applyconfirm_dialog .ok_btn").bind(click, function (e) {
                layer.close(applyconfirmdialog_LayerIndex);

                var picked = api.pickGetPicked();
                if (picked.length == 0) {
                    layer.alert("没有选定的房间。", {
                        closeBtn: 0,
                        skin: 'layui-layer-default'
                    });
                    return;
                }
                var pickFloor = picked[0].model;

                if (pickFloor.type != "FLOOR") return;

                if (!pickFloor.applyModelRoomComplete.has(modelRoomApplyComplete)) {
                    pickFloor.applyModelRoomComplete.add(modelRoomApplyComplete)
                }
                //log(applyconfig);

                var action = api.actionBegin("ApplyModelroom", pickFloor, ghostFloorplan, ghostFloor);
                api.actionRun("setconfig", applyconfig);
                //api.actionRun("apply");
                //api.actionEnd("ApplyModelroom");

                showModelRoomTip();
            });

        },
        end: function () {
        }
    });
}
function modelRoomApplyComplete(room, ghostRoom, addedObjects,removedObjects) {
    //todo;
       //保存墙的信息
       var roomWalls = [];
      
       room.profile.forEach(function(e,i){
           var wallitem = new api.Line(e.begin.x,e.begin.y,e.end.x,e.end.y);
           wallitem.width = e.width;
           roomWalls.push(wallitem);
       });
       
       function equal(a,b){
            return (a.x == b.x) && (a.y == b.y);
       }

      addedObjects.forEach(function(e,i){

           //吊顶吸靠房间顶
           if(e.meta && e.meta.subcategory &&  e.meta.subcategory == "ceiling"){
              
               e.z = room.height3d - e.meta.zlen;
               
           }
           //背景墙吸靠墙面
           if(e.meta && e.meta.subcategory &&  e.meta.subcategory =="backgroundwall"){
               var angle = e.rot - 90,
                   x = Math.cos(angle/180*Math.PI),
                   y = Math.sin(angle/180*Math.PI);
                   
                roomWalls.forEach(function($1,$2){
                    var point = $1.getClosestPoint(e.x,e.y);
                    var point1 =$1.getClosestSegmentPoint(e.x,e.y);
                    var wallvec = new THREE.Vector2(e.x - point.x,e.y - point.y);
                    var objvec = new THREE.Vector2(x,y);
 
                    //计算夹角
                     var includedangle = Math.acos(wallvec.dot(objvec)/(wallvec.length()*objvec.length()));
                            includedangle = includedangle/Math.PI*180;
                      //计算旋转角度
                      var rotationangle = wallvec.angle()/Math.PI*180 - objvec.angle()/Math.PI*180;
                      
                      var flag = includedangle < 90 && equal(point,point1);
                      
                       $1.includedangle = includedangle;
                       $1.rotationangle = rotationangle;
                       $1.flag = flag;
                       
                       
                        var length = e.meta.ylen/2+$1.width/2;
                        //背景墙移动后的点
                        $1.point = {x:point.x+length*Math.cos(wallvec.angle()),
                             y:point.y+length*Math.sin(wallvec.angle())};

               });
 
               roomWalls.sort(function(a,b){return a.includedangle- b.includedangle});
               
               var move = true;
               
               for(var i = 0, l = roomWalls.length; i < l; i++){
                   if(roomWalls[i].flag){
                        e.rot += roomWalls[i].rotationangle;  
                        e.x = roomWalls[i].point.x;
                        e.y = roomWalls[i].point.y;
                        move = false;
                        break;
                   }
               }
               
               if(move){
                  e.rot += roomWalls[0].rotationangle;  
                        e.x = roomWalls[0].point.x;
                        e.y = roomWalls[0].point.y; 
               }
           }
 
       });
   
}
function showModelRoomTip() {
    var left = ($(window).width() - $("#modelroom_tipbar").width()) / 2;
    $("#modelroom_tipbar").show().offset({top: 110, left: left});
}

$(".modelroom_tipbar .ok").on(click, function () {
    api.actionRun("apply");
    api.actionEnd("ApplyModelroom");
});
$(".modelroom_tipbar .cancel").on(click, function () {
    api.actionEnd("ApplyModelroom");
});
api.application_ready_event.add(function () {
    api.actionEndEvent.add(function (action, actionType, args) {
        if (actionType == "ApplyModelroom") {
            $("#modelroom_tipbar").hide();
        }
    });
});


function clickModelRoomImg(operation, did) {
    var modelRoomDetailQueryUrl = api.getServicePrefix("design") + "/getDesignById?designId=" + did;

    api.getServiceJSONResponsePromise({
        type: 'GET',
        url: modelRoomDetailQueryUrl
    }).then(function (res) {
        if (res.length > 0) {
            var content = res[0].content;
            if (operation == "open") {
                getTextDataFromAliyun("design", res[0].did, "design.content", function (data) {
                    api.documentLoad(data);
                });
            } else if (operation == "merge") {
                /*getTextDataFromAliyun("design", res[0].did, "design.content", function (data) {
                 api.documentLoad(data);
                 });*/
            } else if (operation == "apply") {
                var picked = api.pickGetPicked();
                if (picked.length < 1 || picked[0].model.type != "FLOOR") {
                    layer.alert("先选择一个房间，然后才能应用样板间。", {
                        closeBtn: 0,
                        skin: 'layui-layer-default'
                    });
                    return;
                }

                getTextDataFromAliyun("design", res[0].did, "design.content", function (data) {
                    var doc = api.documentLoadGhost(data);
                    if (!doc.floorplanGhostLoadCompleteEvent.has(applyGhostRoomStyle)) {
                        doc.floorplanGhostLoadCompleteEvent.add(applyGhostRoomStyle);
                    }
                });
            }
        } else {
            layer.alert("获得户型数据失败", {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        }
    });
}
function initModelRoomPanel() {
    modelRoomDesigns.forEach(function (modelRoomDesign) {
        var modelRoomItemContainer = $("<div>").addClass("modelroomItem").appendTo($("<li>").appendTo($(".modelroomList")));
        var modelRoomItemImg = undefined;
        switch (modelRoomDesign.thumbnail_type) {
            case undefined:
            case null:
            case "2d":
                getTextDataFromAliyun("design", modelRoomDesign.did, "design.thumbnail", function (data) {
                    modelRoomItemImg = $("<div>").addClass("modelroomImg").appendTo(modelRoomItemContainer).html(data)
                        .on("mouseover", modelRoomItemImgMouseOver).on("mouseout", modelRoomItemImgMouseOut);
                });
                break;
            case "3d":
                getTextDataFromAliyun("design", modelRoomDesign.did, "design.thumbnail", function (data) {
                    modelRoomItemImg = $("<div>").addClass("modelroomImg").appendTo(modelRoomItemContainer).append(
                        $("<img>").attr({src: data}).css({
                            width: "100%",
                            height: "100%"
                        }))
                        .on("mouseover", modelRoomItemImgMouseOver).on("mouseout", modelRoomItemImgMouseOut);
                });

                break;
            case "render":

                getTextDataFromAliyun("design", modelRoomDesign.did, "design.thumbnail", function (data) {
                    var jobid = data;
                    var renderUrl = api.catalogGetFileUrl("render", jobid, "render");
                    modelRoomItemImg = $("<div>").addClass("modelroomImg").appendTo(modelRoomItemContainer).append(
                        $("<img>").attr({src: renderUrl}).css({
                            width: "100%",
                            height: "100%"
                        }))
                        .on("mouseover", modelRoomItemImgMouseOver).on("mouseout", modelRoomItemImgMouseOut);
                });
                break;
        }

        var modelRoomItemMask = $("<div>").attr({
            did: modelRoomDesign.did,
            title: modelRoomDesign.roomtype
        }).addClass("modelroomMask")
            .on("mouseover", function (e) {
                $(this).addClass("mask_hover");
            })
            .on("mouseout", function (e) {
                $(this).removeClass("mask_hover");
            }).appendTo(modelRoomItemContainer);


        function modelRoomItemImgMouseOver(e) {
            $(this).siblings(".modelroomMask").addClass("mask_hover");
        }

        function modelRoomItemImgMouseOut(e) {
            $(this).siblings(".modelroomMask").removeClass("mask_hover");
        }

        //modelRoomItemImg
        //    .on("mouseover", function (e) {
        //        $(this).siblings(".modelroomMask").addClass("mask_hover");
        //    })
        //    .on("mouseout", function (e) {
        //        $(this).siblings(".modelroomMask").removeClass("mask_hover");
        //    });

        var openRoomBtn = $("<input>").attr({
            type: "button",
            value: "打开"
        }).addClass("button button_orange")
            //.appendTo($("<div>").appendTo(modelRoomItemMask))
            .on(click, clickModelRoomImg.bind(undefined, "open", modelRoomDesign.did));

        var mergeRoomBtn = $("<input>").attr({
            type: "button",
            value: "导入房间"
        }).addClass("button button_orange")
            //.appendTo($("<div>").appendTo(modelRoomItemMask))
            .on(click, clickModelRoomImg.bind(undefined, "merge", modelRoomDesign.did));

        var applyRoomBtn = $("<input>").attr({
            type: "button",
            value: "套用到选定房间"
        }).addClass("button button_orange")
            .appendTo($("<div>").appendTo(modelRoomItemMask))
            .on(click, clickModelRoomImg.bind(undefined, "apply", modelRoomDesign.did));


    });
}


$(".modelroom select[name='dstyle']").on("change", function (e) {
    $(".modelroom .modelroomList").empty();
    initModelRoomData($(this).val());
});


//# sourceURL=ui\modelroom/modelroom.js