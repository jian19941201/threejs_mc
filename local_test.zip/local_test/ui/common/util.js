function log(msg) {
    //DEBUG_BEGIN
    console.log(msg);
    //DEBUG_END
}

function isEmail(str) {
    var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
    return reg.test(str);
}
function isNumber(obj) {
    return !isNaN(parseFloat(obj));
}

function toFixedNumber(num, digits) {
    //var factor = Math.pow(10, digits);
    var factor = (digits == 2 ? 100 : (digits == 3 ? 1000 : 10));
    return Math.ceil(num * factor) / factor;
}
function colorHexString(r, g, b) {
    var color = ( r || Math.random() * 255 ) << 16 ^ ( g || Math.random() * 255 ) << 8 ^ (b || Math.random() * 255 ) << 0;
    return "#" + ( '000000' + color.toString(16) ).slice(-6);//random color
}
function colorDecimalToHex(decimal) {
    var hex = Number(decimal).toString(16);
    return "#000000".substr(0, 7 - hex.length) + hex;
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null)return unescape(r[2]);
    return null;
}

function urlParamsToObj() {
    var result = {};
    var str = window.location.search.substr(1);
    str.split("&").forEach(function (obj) {
        var key = obj.split("=")[0];
        var value = obj.split("=")[1];
        result[key] = value;
    });
    return result;
}

function getPaper3dImage(opt) {
    var data = api.threeExport("JPG", opt);
    return data;
}

function getPaper2dsvg() {
    api.viewFit("2d", undefined, {extFactor: 0.01});
    var paperTmp2dObj = $("#paper2dsvg").parent().clone();
    paperTmp2dObj.find("svg").attr({
        id: "svg_" + createInternalTime().toString()
        //preserveAspectRatio: "xMidYMid slice"
    }).css({width: "100%", height: "100%"});
    paperTmp2dObj.find("g[type='CAMERA']").remove();
    paperTmp2dObj.find("g[type='ROOMLABEL']").remove();
    paperTmp2dObj.find("g[type='INDIMENSION']").remove();
    paperTmp2dObj.find("g[type='CEILING']").remove();
    paperTmp2dObj.find("g[type='BEAM']").remove();
    paperTmp2dObj.find("g[type='ANNOTATION']").remove();
    paperTmp2dObj.find("g[type='WALKTHROUGH']").remove();
    paperTmp2dObj.find("g[type='Temp']").remove();
    var html = paperTmp2dObj.html();
    html = html.replace('preserveAspectRatio="xMinYMin"', 'preserveAspectRatio="xMidYMid"');
    return html;
}

/*js 防Map对象*/
function Map() {
    var struct = function (key, value) {
        this.key = key;
        this.value = value;
    };

    var put = function (key, value) {
        for (var i = 0; i < this.arr.length; i++) {
            if (this.arr[i].key === key) {
                this.arr[i].value = value;
                return;
            }
        }
        this.arr[this.arr.length] = new struct(key, value);
    };

    var get = function (key) {
        for (var i = 0; i < this.arr.length; i++) {
            if (this.arr[i].key === key) {
                return this.arr[i].value;
            }
        }
        return '';
    };

    var remove = function (key) {
        var v;
        for (var i = 0; i < this.arr.length; i++) {
            v = this.arr.pop();
            if (v.key === key) {
                continue;
            }
            this.arr.unshift(v);
        }
    };

    var size = function () {
        return this.arr.length;
    };

    var removeAll = function () {
        while (this.arr.length > 0) {
            this.arr.pop();
        }
    };

    var isEmpty = function () {
        return this.arr.length <= 0;
    };

    var containsKey = function (key) {
        for (var i = 0; i < this.arr.length; i++) {
            if (this.arr[i].key === key) {
                return true;
            }
        }
        return false;
    };

    this.arr = new Array();
    this.get = get;
    this.put = put;
    this.remove = remove;
    this.size = size;
    this.isEmpty = isEmpty;
    this.removeAll = removeAll;
    this.containsKey = containsKey;
}

/*unnicode与中文互换*/
function unnicodeSwitch(str) {
    var methods = {
        toUnicode: function (str) {
            return escape(str).replace(/%/g, "\\").toLowerCase();
        },
        unUnicode: function (str) {
            return unescape(str.replace(/\\/g, "%"));
        }
    };
    return methods;
}

function fakeUnnicodeToChinese(str) {
    if (!str || '' == str) return "";
    var _str = str.substring(1);
    var array = _str.split("");
    var newArray = [];
    array.forEach(function (obj, index) {
        if (index % 4 == 0) newArray.push("\\u");
        newArray.push(obj);
    });
    return unnicodeSwitch().unUnicode(newArray.join(""));
}

// 仅能输入数字
function keyCodeIsNumber(keyCode) {
    // 数字
    if (keyCode >= 48 && keyCode <= 57) return true
    // 小数字键盘
    if (keyCode >= 96 && keyCode <= 105) return true
    // Backspace键
    if (keyCode == 8) return true
    return false
}

/*从阿里云获取文本格式数据 &d表示不读缓存*/
function getTextDataFromAliyun(category,did, type,callback) {
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: api.catalogGetFileUrl(category, did, type)+"&d",
        cache: false,
        data: {}
    }).then(function (res) {
        if (callback) callback(res);
    }).catch(function (e) {
    });
}
//# sourceURL=ui/common/util.js

//add by   gaoning 2016.8.17 判断点是否在多边形内
//*****************************************************************************************
//计算向量叉乘  
var crossMul = function(v1,v2){
    return   v1.x*v2.y-v1.y*v2.x;
}
//javascript判断两条线段是否相交  
var checkCross = function(p1,p2,p3,p4){
    var v1={x:p1.x-p3.x,y:p1.y-p3.y};
    v2={x:p2.x-p3.x,y:p2.y-p3.y};
    v3={x:p4.x-p3.x,y:p4.y-p3.y};
    v=crossMul(v1,v3)*crossMul(v2,v3);
    v1={x:p3.x-p1.x,y:p3.y-p1.y};
    v2={x:p4.x-p1.x,y:p4.y-p1.y};
    v3={x:p2.x-p1.x,y:p2.y-p1.y};
    return (v<=0&&crossMul(v1,v3)*crossMul(v2,v3)<=0)?true:false;
}
//判断点是否在多边形内  
var checkPointInPolygon = function(point,polygon){
    var p1,p2,p3,p4;
    p1=point;
    p2={x:-100,y:point.y};
    var count=0;
    //对每条边都和射线作对比  
    for(var i=0;i<polygon.length-1;i++){
        p3=polygon[i];
        p4=polygon[i+1];
        if(checkCross(p1,p2,p3,p4)==true){
            count++;
        }
    }
    p3=polygon[polygon.length-1];
    p4=polygon[0];
    if(checkCross(p1,p2,p3,p4)==true){
        count++;
    }
    //console.log(count)  
    return (count%2==0)?false:true;
}
//*********************************************************************************