function ptInPoly(pt, polygon) {
    var pt = new ClipperLib.IntPoint(pt.x * 1000, pt.y * 1000);
    var poly = polygon.map(function (pt) {
        return {X: pt.x * 1000, Y: pt.y * 1000}
    });
    return ClipperLib.Clipper.PointInPolygon(pt, poly);
}
function getPolyBound(points) {
    var bound_min = {x: Infinity, y: Infinity}, bound_max = {x: -Infinity, y: -Infinity};
    points.forEach(function (pt) {
        if (bound_min.x > pt.x)bound_min.x = pt.x;
        if (bound_min.y > pt.y)bound_min.y = pt.y;
        if (bound_max.x < pt.x)bound_max.x = pt.x;
        if (bound_max.y < pt.y)bound_max.y = pt.y;
    });
    return {min: bound_min, max: bound_max};
}
function lineLength(pt0, pt1) {
    return Math.sqrt((pt0.x - pt1.x) * (pt0.x - pt1.x) + (pt0.y - pt1.y) * (pt0.y - pt1.y));
}
//# sourceURL=ui/common/math.js