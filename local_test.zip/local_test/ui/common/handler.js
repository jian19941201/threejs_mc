function fileInputOpenLocalChangeHandler(e) {
    globalModelIndex = 1;
    var file = e.target.files[0];
    var reader = new FileReader();
    reader.readAsText(file);
    reader.onload = function (e) {
        var content = this.result;
        if (typeof readRenderParamDataFromSaved != "undefined") readRenderParamDataFromSaved(content);
        api.documentLoad(content);
    }
    var fileInputOpenLocalClone = $("#fileInputOpenLocal").clone(true);
    $("#fileInputOpenLocal").remove();
    $("#menubar").append(fileInputOpenLocalClone);
}

//保存log到服务器
function saveLogToServer(contents) {
    var servicePrefix = api.getServicePrefix("logstore");
    var url = servicePrefix + "/putLogs?contents=" + JSON.stringify(contents) + "&topic=" + globalUsrObj.globalPartyId;
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: url,
        data: {}
    }).then(function (res) {
        console.log(res);
    })
}

function fileSaveLocalHandler() {
    var content = api.documentSave();
    var filename = "我的设计-" + (new Date()).toLocaleString() + ".design";
    api.saveAs(new Blob([content], {type: "text/plain;charset=" + document.characterSet}), filename);
}
function fileNewHandler() {
    api.documentLoad();
    //新建时清除已渲染的图片  --add by gaoning 2017.3.8
    clearRenderedJobTaskToList();
}

function is2DViewActive() {
    return $("#paper2d").find("#paper2dsvg").length != 0;
}

function view2DActiveHandler() {
    if (is2DViewActive()) {
        console.log("已经是2D视图！");
        return;
    }
    //左边弹出菜单关闭
    popLeftContextMenuClose();

    $("#paper2dsvg").appendTo("#paper2d");
    $("#paper3dwebgl").appendTo("#paper3d");

    //change by gaoning -- 2016.12.2
    //  修改切换视图时不改变相机为默认相机
    var curCameraID = "cameraPerson";
    var curCameraList = api.floorplanFilterEntity(function (e) {
        return e.type == "CAMERA";
    });
    for (var i = 0; i < curCameraList.length; i++) {
        if (curCameraList[i].active == true) {
            curCameraID = curCameraList[i].id;
        }
    }
    //从鸟瞰视图切换过来时，要特殊处理
    if (curCameraID == "cameraFly") {
        api.documentSetActiveCameras(["cameraPerson"]);
    } else {
        api.documentSetActiveCameras([curCameraID]);
    }
    //change by gaoning -- 2016.12.2

    //切换视图，改变字体初始大小--add by gaoning 2017.12.28
    var view = api.getViewById("2d");
    view.viewFontSizeMin(false);

    //api.documentSetActiveCameras(["cameraPerson"]);
    api.viewFit('2d');
    api.viewFit('3d');

    $('#viewButton2DId').addClass("two_select");
    $('#viewButton3DId').removeClass("three_select");

    if (closeContextMenu)closeContextMenu();
}

function view3DFirstPersonActiveHandler() {
    $("#paper2dsvg").appendTo("#paper3d");
    $("#paper3dwebgl").appendTo("#paper2d");
    tool_tip_bnt && tool_tip_bnt.hide();
    //change by gaoning -- 2016.12.2
    //  修改切换视图时不改变相机为默认相机
    var curCameraID = "cameraPerson";
    var curCameraList = api.floorplanFilterEntity(function (e) {
        return e.type == "CAMERA";
    });
    for (var i = 0; i < curCameraList.length; i++) {
        if (curCameraList[i].active == true) {
            curCameraID = curCameraList[i].id;
        }
    }
    //  从鸟瞰视图切换过来时，要特殊处理
    if (curCameraID == "cameraFly") {
        api.documentSetActiveCameras(["cameraPerson"]);
    } else {
        api.documentSetActiveCameras([curCameraID]);
    }
    //change by   gaoning -- 2016.12.2


    //切换视图，改变字体初始大小--add by gaoning 2017.12.28
    var view = api.getViewById("2d");
    view.viewFontSizeMin(true);

    api.viewFit('2d');
    var view3d = api.viewFit('3d');


    if (!view3d || !view3d.context) {
        layer.tips('浏览器不支持WebGL', '#menuFileNew', {
            tips: [1, '#CC3525'],
            time: 3000
        });
    }
    $('#viewButton2DId').removeClass("two_select");
    $('#viewButton3DId').addClass("three_select");
    //左边弹出菜单关闭
    popLeftContextMenuClose();

    if (closeContextMenu)closeContextMenu();
}
function view3DBirdViewActiveHandler() {

    //console.log("open 3d birdview camera.");
    var curCamera = api.floorplanFilterEntity(function(e)
    {
        return e.type=="CAMERA";
    });
    if(curCamera && curCamera.length > 0){
        curCamera.forEach(function(ca){

        });
    }

    var app = api.getViewById("3d").app;
    var viewss =app.views;

    console.log(viewss);

   // app.updateViews(newCamera);
    $("#paper2dsvg").appendTo("#paper3d");
    $("#paper3dwebgl").appendTo("#paper2d");
    api.documentSetActiveCameras(["cameraFly"]);
    api.viewFit('2d');
    api.viewFit('3d');
    //setOrthographicCamera();
    if (closeContextMenu)closeContextMenu();
}


function view3dFullScreenHandler() {
    api.viewFit("3d", {width: screen.width, height: screen.height});
    var element = document.getElementById("paper3dwebgl");
    if (element.requestFullscreen) {
        element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
    }
}

function exportData() {
    var data = api.documentSave({encrypt: false});
    var filename = "我的设计-" + (new Date()).toLocaleString() + ".json";
    api.saveAs(new Blob([data], {type: "text/plain;charset=ascii"}), filename);
}

//function exportCAD() {
//    var cadid = api.uuid();
//    var designcontent = api.documentSave();
//    var exportServer = api.getServicePrefix("export");
//    api.snapExport("DXF", function (cadcontent) {
//        api.getServiceJSONResponsePromise({
//            type: "POST", url: exportServer + "/saveExportCADDataToDB",
//            data: {caddata: cadcontent, cadid: cadid, fpdesign: designcontent}
//        }).then(function (res) {
//
//            //var res = JSON.parse(resp.body);
//            if (res.error != 0) {
//                alert("export dxf failed, save to db error.");
//                return;
//            }
//            $.get(exportServer + "/getExportCADRawData?cadid=" + cadid, function (content) {
//                var filename = "我的设计-" + (new Date()).toLocaleString() + ".dxf";
//                api.saveAs(new Blob([content], {type: "octet-stream"}), filename);
//            });
//        });
//    });
//
//}

//初始化CAD导出选项UI--add by gaoning 2017.7.7
function InitExportCADUI() {
    $("#exportCAD .Lebel_Table input.showDimensionLayer").prop("checked", true);
    $("#exportCAD .Lebel_Table input.showRoomLabel").prop("checked", true);
    $("#exportCAD .Lebel_Table input.showTextAnnotation").prop("checked", true);
    $("#exportCAD .Lebel_Table input.showOutRoomLabel").prop("checked", true);
    $("#exportCAD .Lebel_Table input.showOutLabel").prop("checked", true);
    api.setDimensionLayer(true);
    api.setRoomLabel(true);
    api.setTextAnnotation(true);
    api.setOutRoomLabel(true);
    api.setOutLabel(true);

    $("#exportCAD .Lebel_Table input").on("click", function (e) {
        if ($(this).hasClass("showDimensionLayer")) {
            if ($(this).is(":checked")) {
                api.setDimensionLayer(true);
            } else {
                api.setDimensionLayer(false);
            }
        }
        if ($(this).hasClass("showRoomLabel")) {
            if ($(this).is(":checked")) {
                api.setRoomLabel(true);
            } else {
                api.setRoomLabel(false);
            }
        }
        if ($(this).hasClass("showTextAnnotation")) {
            if ($(this).is(":checked")) {
                api.setTextAnnotation(true);
            } else {
                api.setTextAnnotation(false);
            }
        }
        if ($(this).hasClass("showOutRoomLabel")) {
            if ($(this).is(":checked")) {
                api.setOutRoomLabel(true);
            } else {
                api.setOutRoomLabel(false);
            }
        }
        if ($(this).hasClass("showOutLabel")) {
            if ($(this).is(":checked")) {
                api.setOutLabel(true);
            } else {
                api.setOutLabel(false);
            }
        }
    });
}

function exportCAD() {

    //if (!designId){
    //    layer.msg('请保存方案！');
    //    return;
    //}

    //init ui
    InitExportCADUI();
    //api.InitLabels();
    // 增加选项弹出框--add by gaoning 2017.7.7
    getCADSettingDialog()(console.log("open the dialog"));
}

//add by gaoning
function exportCADForWall() {

    var picked = api.pickGetPicked();
    var dialogIndex = undefined;
    /**没有选择房间为打开设计*/
    if (picked.length < 1 || picked[0].model.type != "FLOOR") {
        dialogIndex = layer.confirm('未选中房间！', {
            btn: ['确定'], //按钮
            shade: 0.3, //不显示遮罩
            skin: 'layui-layer-default',
            title: '提示'
        }, function () {
            layer.close(dialogIndex);
        });

    }else {

        //开始加载，添加标注--add by gaoning
        $("body").append($("<div id='cadMaskLayer' " +
            "style='position: absolute;width: 100%;height: 100%;top: 0;    text-align: center;line-height: 500px;" +
            " color: white; left: 0;background: rgba(0,0,0,0.6);z-index: 10000000000000000;'>正在导出CAD工程图，请稍后...</div>"));
        try {
            api.utilExportJSONData3(picked[0],function (jsonData) {
                var exportServer = api.getServicePrefix("export");
                var contentBase64 = api.utilEncryptString(JSON.stringify(jsonData));
                //支持返回二进制文件 2017-09-22 oxl
                $.ajax({
                    url: exportServer + "/postExportDXF2?userLoginId=" + ui.getCurrentUserData.userLoginId,
                    type: "post",
                    data: {data: contentBase64},
                    dataType: 'binary',
                    timeout:30000,
                    success: function(result){
                        var filename = "立面CAD图-" + (new Date()).toLocaleString() + ".dxf";
                        api.saveAs(result,filename);
                        $("#cadMaskLayer").remove();
                    },
                    complete:function (req,status) {
                        if(status=='timeout'){
                            tmallError('请求超时');
                            $("#cadMaskLayer").remove();
                            alert("请求超时,立面CAD工程图导出失败:");
                        }
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        console.log(xhr.status);
                        console.log(thrownError);
                        $("#cadMaskLayer").remove();
                        alert("异常出错，立面CAD工程图导出失败:");
                    }
                });
            });
        } catch (e) {
            $("#cadMaskLayer").remove();
            alert("立面CAD工程图导出失败:" + e);
        }
    }
}

function getCADSettingDialog() {

    var dialogIndex = undefined;

    function optionsDialog(elem) {
        var dialogWidth = 320;
        var dialogHeight = 300;  //修改弹出边框的大小 --by gaoning 2017.7.4
        dialogIndex = layer.open({
            type: 1,
            title: '导出CAD',
            skin: 'layui-layer-default',
            fix: false,
            //closeBtn: false,
            shadeClose: false,
            maxmin: false,
            move: false,
            area: [dialogWidth + 'px', dialogHeight + 'px'],
            content: $('#exportCAD'),
            success: function () {
                $("#exportCAD").parents(".layui-layer-default").draggable();
                $("#exportCAD .buttons button").off("click").on("click", function () {
                    layer.close(dialogIndex);

                    if ($(this).hasClass("cancel")) {
                        //关闭UI同时要清理标注信息--gaoning 2017.7.14
                    }

                    if ($(this).hasClass("submit")) {

                        //开始加载，添加标注--add by gaoning
                        //console.log("#@#@@##3213#atart......");
                        //api.InitLabels();
                        $("body").append($("<div id='cadMaskLayer' " +
                            "style='position: absolute;width: 100%;height: 100%;top: 0;    text-align: center;line-height: 500px;" +
                            " color: white; left: 0;background: rgba(0,0,0,0.6);z-index: 10000000000000000;'>正在导出CAD工程图，请稍后...</div>"));
                        try {
                            api.utilExportJSONData2(function (jsonData) {
                                var exportServer = api.getServicePrefix("export");
                                var contentBase64 = api.utilEncryptString(JSON.stringify(jsonData));
                                //支持返回二进制文件 2017-09-22 oxl
                                $.ajax({
                                    url: exportServer + "/postExportDXF2?userLoginId=" + ui.getCurrentUserData.userLoginId,
                                    type: "post",
                                    data: {data: contentBase64},
                                    dataType: 'binary',
                                    timeout:30000,
                                    success: function(result){
                                        var filename = "我的设计-" + (new Date()).toLocaleString() + ".dxf";
                                        api.saveAs(result,filename);
                                        $("#cadMaskLayer").remove();
                                    },
                                    complete:function (req,status) {
                                        if(status=='timeout'){
                                             tmallError('请求超时');
                                            $("#cadMaskLayer").remove();
                                            alert("请求超时,CAD工程图导出失败:");
                                        }
                                    },
                                    error: function (xhr, ajaxOptions, thrownError) {
                                        console.log(xhr.status);
                                        console.log(thrownError);
                                        $("#cadMaskLayer").remove();
                                        alert("异常出错，CAD工程图导出失败:");
                                    }
                                });
                            });
                        } catch (e) {
                            $("#cadMaskLayer").remove();
                            alert("CAD工程图导出失败:" + e);
                        }
                    }
                });
            }
        });
    }

    return optionsDialog;
}

function exportCADJSON() {
    api.utilExportJSONData2(function (jsonData) {
        var content = JSON.stringify(jsonData);
        var filename = "我的设计-" + (new Date()).toLocaleString() + ".json";
        api.saveAs(new Blob([content], {type: "text/plain;charset=ascii"}), filename);
    });
}

function exportDXF() {
    var exportServer = api.getServicePrefix("export");
    var exportUrl = exportServer + "/postExportDXF?userLoginId=" + ui.getCurrentUserData.userLoginId;
    api.snapExport("DXF", function (content) {
        api.getServiceJSONResponsePromise({type: "POST", url: exportUrl, data: {data: content}})
            .then(function (res) {
                //var res = JSON.parse(resp.body);
                if (res.error != 0) {
                    alert("export dxf failed!");
                    return;
                }
                var exportid = res.exportid;
                var fileServer = api.getServicePrefix("file");
                var fileUrl = api.catalogGetFileUrl("export", exportid, "dxf");
                //fileServer + "/getFile" + "?id=" + exportid + "&category=export&type=dxf";
                $.get(fileUrl, function (content) {
                    var filename = "我的设计-" + (new Date()).toLocaleString() + ".dxf";
                    api.saveAs(new Blob([content], {type: "text/plain;charset=ascii"}), filename);
                });

            });
    });


}
function exportBOM() {
    var bomData = api.getBomData();
    var pids = bomData.pids;
    delete bomData.pids;

    var bomid = api.uuid();
    // todo, add BOM id to Database??

    var bomservice = api.getServicePrefix("bom");
    var bompostdata_url = bomservice + "/postbom";
    var bomlist_url = bomservice + "/listbom?id=" + bomid;

    api.catalogGetProductsMetaPromise(pids).then(function (meta) {
        bomData.meta = meta;
        $.ajax({
            type: 'post',
            url: bompostdata_url,
            cache: false,
            data: {data: bomData, id: bomid}
        }).done(function () {
            if (bomDialogPrompt)bomDialogPrompt(bomlist_url);
        });
    });
}
function rulerMeasure() {
    var p = api.actionBegin("RulerMeasure");
}
function renderBtnHandler() {
    function renderDialogOKBtnClick(opt) {
        render_sendRenderRequest(opt, function (job) {
            if (renderview_renderrequestSendComplete)renderview_renderrequestSendComplete(job);
        });
    }

    if (renderDialogPrompt)renderDialogPrompt(renderDialogOKBtnClick);
}

function hideOrShowAllProduct(flag) {
    var prods = api.floorplanFilterEntity(function (e) {
        return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT');
    });
    api.actionBegin("SetGeneralFlag", prods);
    api.actionRun("set", 1 << 2, flag);
    api.actionEnd("SetGeneralFlag");
}

function hideOrShowAllOtherStructure(flag) {
    var prods = api.floorplanFilterEntity(function (e) {
        return (e.type == "PILLAR" || e.type == 'BEAM' || e.type == 'BASEMENT');
    });
    api.actionBegin("SetGeneralFlag", prods);
    api.actionRun("set", 1 << 2, flag);
    api.actionEnd("SetGeneralFlag");
}

function addTextAnnotation() {
    var p = api.actionBegin("AddAnnotation");
}
function addTextAnnotation2() {
    var p = api.actionBegin("AddSimpleAnnotation");
}

function addCamera() {
    var camera = api.actionBegin("AddCamera");
    var cameraCount = api.documentGetCameras().length;
    camera.name = "我的摄像机-" + (cameraCount <= 10 ? "0" : "") + (cameraCount - 1);

    camera.camerahasadd="true";
}

function selectCamera() {
    if (typeof promptAllCameraDialog == "function")promptAllCameraDialog();
}
//UI系统添加键盘事件
$(document).on('keydown', null, "c", selectCamera);
$(document).on('keydown', null, "p", toggleCameraVisible);
$(document).on('keydown', null, "l", toggleCameraLock);
function toggleCameraVisible(e) {
    var cameraTag = $("#paper2dsvg").find("g[type='CAMERA']");
    cameraTag.css("display", (cameraTag.css("display") == "none" ? "block" : "none"));

    var cameraTagLock = $("#paper2dsvg").find("g[type='LOCKCAMERA']");
    cameraTagLock.css("display", (cameraTagLock.css("display") == "none" ? "block" : "none"));
}
function toggleCameraLock(){
    luckAndUnlock();
}
//相机上锁
//相机上锁
function lockCamera(e) {
    var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
    });
    if(pickObjs_product){
        // lock the camera means change the camera property's value into "true".
        pickObjs_product[0].model.lock = true;
        var cameraTag = $("#paper2dsvg").find("image[cid="+pickObjs_product[0].model.id+"]");
        cameraTag.css("display","block");
        var cameraTag2 = $("#paper2dsvg").find("image[did="+pickObjs_product[0].model.id+"]");
        cameraTag2.css("cursor","default");
    }else{
        //提示没有选中相机

    }

}
function addPillar() {
    //var pid = "pillar";
    //api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
    //    var p = api.actionBegin("AddCube", "pillar", rv);
    //    p.sx = 0.4, p.sy = 0.4, p.sz = 3.0;
    //});
    var p = api.actionBegin("AddCube", "pillar", {});
    p.sx = 0.4, p.sy = 0.4, p.sz = 3.0;
}
function addBasement() {
    //var pid = "cube";
    //api.catalogGetProductsMetaPromise([pid, pid, pid]).then(function (rv) {
    //    var p = api.actionBegin("AddCube", "basement", rv);
    //    p.sx = 1.2, p.sy = 1.2, p.sz = 0.2;
    //});
    var p = api.actionBegin("AddCube", "basement", {});
    p.sx = 1.2, p.sy = 1.2, p.sz = 0.2;
}
function addBeam() {
    var p = api.actionBegin("AddCube", "beam", {});
    p.sx = 2.5, p.sy = 0.2, p.sz = 0.2, p.z = 2.8 - p.sz;
}

$(document).on('keydown', null, "F2", function () {
    var filename = "我的设计-" + (new Date()).toLocaleString() + ".design";
    var content = api.documentSave({}, function () {
        if (typeof collectRenderParamDataToSaved != "undefined") {
            return collectRenderParamDataToSaved();
        } else {
            return {};
        }
    }());
    api.saveAs(new Blob([content], {type: "text/plain;charset=" + document.characterSet}), filename);
});

function downloadSnapshot(viewId, width, height) {
    var view = api.getViewById(viewId);
    var filename = "我的设计-" + (new Date()).toLocaleString();
    if (viewId == "2d") {
        var svgString = $("#paper2dsvg").parent().html();
        api.saveAs(new Blob([svgString], {type: "xml/svg"}), filename + ".svg");
    } else if (viewId == "3d") {
        getPaper3dImage({
            width: width, height: height, quality: 1.0,
            onSuccess: function (data) {
                var dataarr = data.split(";base64,");
                var dtype = dataarr[0].replace("data:", "");
                var content = new Uint8Array(api.decodeStringToByteArray(dataarr[1]));
                api.saveAs(new Blob([content], {type: dtype}), filename + ".jpg");
            }
        });
    }
}

// autoLight functions:
function autoLightFilter() {
    return api.floorplanFilterEntity(function (e) {
        var ud = e.userDefined || {};
        return e.type == "PRODUCT" && ud.isAutoLighting === true;
    });
}
function autoLightRemove() {
    autoLightFilter().forEach(function (light) {
        api.actionBegin("DeleteAutoLight", light);
    });
}
function autoLightAdd(horizentalLightPID, verticalLightPID, iesLightPID) {
    var rooms = api.floorplanFilterEntity(function (e) {
        return e.type == "FLOOR";
    });
    var walls = api.floorplanFilterEntity(function (e) {
        return e.type == "WALL";
    });
    var products = api.floorplanFilterEntity(function (e) {
        return e.type == "PRODUCT";
    });
    if (rooms.length == 0)return;
    var floorplan = rooms[0].lt[Object.keys(rooms[0].lt)[0]];


    api.catalogGetProductsMetaPromise([horizentalLightPID, verticalLightPID, iesLightPID]).then(function (meta) {
        var lights = [];//{type: top|wall|ies, size:{x:x,y:Number,z,sx,sy,sz}}

        var gap = 0.6; // distance of neighbor lights.
        var tol = 0.8; // the nearest distance from light to wall.

        rooms.forEach(function (room) {
            var loop = room.getLoop();
            var bound = getPolyBound(loop);
            var bound_min = bound.min, bound_max = bound.max;

            for (var i = bound_min.x + tol; i <= bound_max.x; i += gap) {
                for (var j = bound_min.y + tol; j <= bound_max.y; j += gap) {
                    var pt = {x: i, y: j};
                    if (!ptInPoly(pt, loop))continue;
                    var distance = Infinity;
                    walls.forEach(function (wall) {
                        if (!wall || !wall.begin || !wall.end)return;
                        var nearest = new api.Line(wall.begin.x, wall.begin.y, wall.end.x, wall.end.y).getClosestSegmentPoint(pt.x, pt.y);
                        if (nearest.x == undefined) return;
                        if (isNaN(nearest.x) || isNaN(nearest.y)) return;
                        distance = Math.min(distance, lineLength(pt, nearest));
                    });
                    if (distance < tol - 0.05)continue;
                    var height = room.height3d - 0.1 * distance;
                    var heightNoCollision = height;
                    products.forEach(function (product) {
                        if (product.z < 1.2 || heightNoCollision - 0.1 > product.z + product.meta.zlen * product.sz)return;
                        var outline = product.getLoop();
                        if (!ptInPoly(pt, outline))return;
                        height = Math.min(height, product.z - 0.05);
                    });
                    var size = {x: pt.x, y: pt.y, z: height, distance: distance};
                    lights.push({type: "top", size: size});
                }
            }
            // todo todo
        });

        // last, add to scene......
        for (var i = 0; i < lights.length; ++i) {
            var light = lights[i];
            var pid = (light.type == "ies" ? iesLightPID : (light.type == "wall" ? verticalLightPID : horizentalLightPID )); // default top

            var opt = {light_settings: {multiplier: 15}, isAutoLighting: true};
            api.actionBegin("AddAutoLight", pid, meta[pid], light.size, opt);
            api.actionEnd("AddAutoLight");
        }
    });

}

//# sourceURL=ui\common/hanlder.js