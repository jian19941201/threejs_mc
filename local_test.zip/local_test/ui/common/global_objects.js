var appSettings = undefined;
var isMobileDevice = undefined;
var click = "click";

api.application_ready_event.add(function (setting) {
    appSettings = setting;
    isMobileDevice = function () {
        return setting.device == "mobile";
    };

    /*3d鼠标滚轮事件*/
    $("#paper3dwebgl").on("mousewheel", function (event, delta) {
        var key = "";
        if (delta > 0)
            key = "up";
        else if (delta < 0)
            key = "down";

        var Vec3 = function (x, y, z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
        Vec3.prototype.normalize = function () {
            return this.scale(1 / this.magnitude());
        };
        Vec3.prototype.magnitude = function () {
            return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
        };
        Vec3.prototype.scale = function (s) {
            this.x *= s;
            this.y *= s;
            this.z *= s;
            return this;
        };


        var cam = api.documentGetActiveCamera();
        var angle = cam.pitch;
        var line = new api.Line(cam.tx, cam.ty, cam.x, cam.y);
        var length = line.length();
        var tz = length * Math.tan(angle / 180 * Math.PI);
        var dir = api.Vec2.difference({x: cam.tx, y: cam.ty}, {x: cam.x, y: cam.y}).normalize().scale(0.05);

        var dir2 = (new Vec3(cam.tx - cam.x, cam.ty - cam.y, tz)).normalize().scale(0.05);

        switch (key) {
            case "up":
                if (cam.id == "cameraFly") {
                    cam.x += dir2.x;
                    cam.y += dir2.y;
                    cam.z += dir2.z;
                    cam.tx += dir2.x;
                    cam.ty += dir2.y;
                } else {
                    cam.x += dir.x;
                    cam.y += dir.y;
                    cam.tx += dir.x;
                    cam.ty += dir.y;
                }
                break;
            case "down":
                if (cam.id == "cameraFly") {
                    cam.x -= dir2.x;
                    cam.y -= dir2.y;
                    cam.z -= dir2.z;
                    cam.tx -= dir2.x;
                    cam.ty -= dir2.y;
                } else {
                    cam.x -= dir.x;
                    cam.y -= dir.y;
                    cam.tx -= dir.x;
                    cam.ty -= dir.y;
                }

                break;
            case "left":
                cam.x -= dir.y;
                cam.y += dir.x;
                cam.tx -= dir.y;
                cam.ty += dir.x;
                break;
            case "right":
                cam.x += dir.y;
                cam.y -= dir.x;
                cam.tx += dir.y;
                cam.ty -= dir.x;
                break;
            case "pageup":
                cam.z += 0.05;
                break;
            case "pagedown":
                cam.z = Math.max(cam.z - 0.05, 0.1);
                break;
        }

    });

    $("#paper3dwebgl").on("mousemove", function () {
        var cam = api.documentGetActiveCamera();
        var angle = cam.pitch;
        if (cam.id == "cameraFly" && angle > 80) {
            cam.pitch = 80;
            setTimeout(function () {
                cam.pitch = 80;
            }, 1);
        }
        if (cam.id == "cameraFly" && angle < -80) {
            cam.pitch = -80;
            setTimeout(function () {
                cam.pitch = -80;
            }, 1);
        }
    });
});
//# sourceURL=ui/common/global_objects.js