function timeDiff(start, end) {
    // return seconds.
    if (!start || !end) return "无法获取";
    var startStr = start + "", endStr = end + "";

    var start_day = parseInt(startStr.slice(6, 8));
    var start_hour = parseInt(startStr.slice(8, 10));
    var start_min = parseInt(startStr.slice(10, 12));
    var start_sec = parseInt(startStr.slice(12, 14));

    var end_day = parseInt(endStr.slice(6, 8));
    var end_hour = parseInt(endStr.slice(8, 10));
    var end_min = parseInt(endStr.slice(10, 12));
    var end_sec = parseInt(endStr.slice(12, 14));

    var start_total = start_sec + start_min * 60 + start_hour * 60 * 60 + start_day * 60 * 60 * 24;
    var end_total = end_sec + end_min * 60 + end_hour * 60 * 60 + end_day * 60 * 60 * 24;
    return Math.abs(end_total - start_total);
}


var createInternalTime = function (useMS/*default : false*/) {
    var n = new Date();
    return n.getSeconds() * 1 +
        n.getMinutes() * 100 +
        n.getHours() * 10000 +
        n.getDate() * 10000 * 100 +
        (n.getMonth() + 1) * 10000 * 10000 +
        n.getFullYear() * 10000 * 10000 * 100 +
        (useMS == true ? n.getMilliseconds() * 0.001 : 0);
};

//# sourceURL=common/time.js