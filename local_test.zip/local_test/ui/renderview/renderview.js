$('#renderViewId').appendTo($('#viewcontent'));
$('#renderViewId').tooltip();
$('#renderViewId .open').click(function () {
    $(this).fadeOut();
    $('#renderViewId .close').fadeIn();
    $('#renderId').fadeOut();

});
$('.renderlistBtn').click(function(){
    $('#renderPanel_oceano').is(':visible') && $('#renderPanel_oceano').dialog("close");
    !$("#renderlisttab").is(':visible')&&
    $("#renderlisttab").dialog({
        width:600,
        height:600,
        resizable:false,
        draggable:false,
        open:function(){
            $('[aria-describedby="renderlisttab"] .ui-dialog-titlebar').hide();
            if($("#rlrendering .content .hint").length==1){
                $('#renderlistul li:eq(1)').click()
            }

        }
    })
})
$('#renderViewId .close').click(function () {
    $(this).fadeOut();
    $('#renderViewId .open').fadeIn();
    $('#renderId').fadeIn();
});


/*渲染点击事件*/
$('.renderStart').click(function () {
    $('#renderlisttab').is(':visible') && $('#renderlisttab').dialog("close");
    $('#menuRender').trigger("click");
});

/************************* RENDRE view functions: ***********************/

var renderview_jobidArray = [];
//renderview_jobidArray = ["id6CF40B13052F69AABA8CC47A320B22", "id0AB68A75C78A271F9A8BB4A2965F0F", "id0B577D3B50C2398FC8BEE3EF183FC9", "id0B9734052126B72A9B27ABFD3FB8B6"];
//renderview_jobidArray = ["id0AB68A75C78A271F9A8BB4A2965F0F", "id8401443C9E238BE0CA5CC3337BBE30", "id1E492F23C02D47217B75C15107CF1F", "id26A88A8E40687C1BDA3688E75BD9C8"];// pano view for test design.
var isRetry = false;
var isOpenTimeoutDialog = false;
var renderview_jobMeta = {};
var renderview_job_timeout_container = {};
var renderview_currentJob_evaluateRenderTime = undefined;
var renderview_latestRenderBeginTime = undefined;
var renderview_currentJob_timeout = undefined;
var custom_renderview_currentJob_timeout = undefined;
var renderview_retry_interval_time = 10; // 单位：分钟
/*渲染转圈本地时间对比辅助对象*/
var renderview_jobid_localtime_Map = new Map();

api.application_ready_event.add(function () {
    renderview_jobidArray.forEach(function (jobid, index) {
        var queryJobUrl = api.getServicePrefix("render") + "/getJobStatus?jobid=" + jobid;
        api.getServiceJSONResponsePromise({type: "GET", url: queryJobUrl})
            .then(function (res) {
                var imgUrl = api.catalogGetFileUrl("render", jobid, "render");
                var thumbImgUrl = api.catalogGetFileUrl("render", jobid, "thumb");
                addJobTaskToList(res, imgUrl, thumbImgUrl);
            });
    });
});


function renderview_renderrequestSendComplete(res) {
    addRenderingJobTaskToList(res.jobid);
    renderview_latestRenderBeginTime = Date.now();
    renderview_currentJob_timeout = setTimeout(renderview_inprogress_queryJobStatus, 1000, res.jobid);
    renderview_job_timeout_container[res.jobid] = renderview_currentJob_timeout;
}

/*查询渲染任务状态*/
function renderview_inprogress_queryJobStatus(jobid) {
    var renderServer = api.getServicePrefix("render");
    var queryJobUrl = renderServer + "/getJobStatus?jobid=" + jobid;
    var retryJobUrl = renderServer + "/retryJob?jobid=" + jobid;
    var fileServer = api.getServicePrefix("file");
    var imgUrl = ui.catalogGetFileUrl("render", jobid, "render");
    var thumbImgUrl = ui.catalogGetFileUrl("render", jobid, "thumb");
    var notifyServer = api.getServicePrefix("notify");

    api.getServiceJSONResponsePromise({type: "GET", url: queryJobUrl})
        .then(function (res) {
            //console.log(res);
            var status = res && res.jobstatus;
            var wait = $('#renderViewId .renderReady').attr('wait')*1;
            if(isNaN(wait))wait=0;
            if(wait<0)wait=0;
            var rendering=$('#rlrendering ul li').length - wait;
            if(isNaN(rendering))rendering=0;
            if(rendering<0)rendering=0;
            $('.AllTask span:eq(1)').html("剩余"+$('#rlrendering ul li').length+"项");
            $('.nowTask span:eq(1)').html(rendering + "项任务渲染");
            if( $('#renderViewId .renderReady').attr('wait') == 1 ){
                if($('#renderViewId .renderReady').attr('tempjobid')==jobid){
                    if(status!=0){
                        $('.renderBegin .Progressbar').html('');
                        $('#renderViewId .renderReady').attr('wait',0)
                        $('#renderViewId .renderReady').attr('tempjobid','');
                    }
                }

            }
            if(status!=0) {
                $('#rlrendering li[jobid="' + jobid + '"] .InQueue').html('')
            }
            if(0==$('#rlrendering .erorrMsg').length){
                $('.renderDescribe .erorrMsgDiv').remove();
            }
            res.retryJobUrl = retryJobUrl;
            //var res = JSON.parse(resp);

            renderview_currentJob_evaluateRenderTime = (renderview_currentJob_evaluateRenderTime === undefined ?
                (res && res.evaluationtime) :
                (renderview_currentJob_evaluateRenderTime === 0 ? (res && res.evaluationtime) / 2 : renderview_currentJob_evaluateRenderTime));
            renderview_currentJob_evaluateRenderTime = Math.ceil(renderview_currentJob_evaluateRenderTime);

            var renderquality=res.renderquality;
            var renderwidth=res.renderwidth;
            var renderheight=res.renderheight;
            var outputtype=res.outputtype;
            var renderfetchtime=res.masterfetchtime;
            if(renderquality=="high"){
                if((renderwidth<=800||renderwidth<=600)&&(renderheight<=600||renderheight<=800)){
                    res.evaluationtime=renderview_currentJob_evaluateRenderTime/3; //high 800x600 和以下的 时间设定为 15分钟
                }
                if((renderwidth==2000||renderwidth==1000)&&(renderheight==1000||renderheight==2000)){
                    res.evaluationtime=renderview_currentJob_evaluateRenderTime-15;
                }
            }else if(renderquality=="super_high"){
                if(outputtype=="panorama"){
                    res.evaluationtime=renderview_currentJob_evaluateRenderTime*6; // VR为90
                }else {
                    if((renderwidth>800||renderwidth<=4096)&&(renderheight>600||renderheight<=4096)){
                        res.evaluationtime=renderview_currentJob_evaluateRenderTime*4; //其余为60
                    }
                }
            }

            /*清空排队信息*/
            switch (status) {
                case 0:// still in queue.
                    renderview_latestRenderBeginTime = Date.now();
                    api.getServiceJSONResponsePromise({type: "GET", url: renderServer + "/jobsInQueue"})
                        .then(function (res) {
                            jobsInQueueUpdateJobTaskToList(jobid, res);
                        }).catch(function (err) {
                            console.log("ERROR:" + err);
                        });
                    break;
                case 1:// fetch by max renderer
                    renderview_rendering_info(res);
                    break;
                case 2: // finished
                    updateRenderedJobTaskToList(res, imgUrl, thumbImgUrl);
                    renderview_jobid_localtime_Map.remove(res.jobid);
                    return;
                case 3:// failed
                    if(!isOpenTimeoutDialog){
                        timeoutEvent(res,'渲染失败');
                        isOpenTimeoutDialog = true;
                    }
                    api.getServiceJSONResponsePromise({
                        type: "POST", url: notifyServer + "/emailNotify", data: {
                            to: "sunny@mvt-inc.com", subject: "render engine report error,jobid=" + jobid,
                            text: "Render timeout. check the render job detail:\n\n" + JSON.stringify(res)
                        }
                    });

                    break;
                default:
                    console.log("failed. status=" + status + ",masterid=" + res.masterid);
                    break;
            }
            // Solution：timeconsuming can not greater than the specifiled time,and timeconsuming = Date.now() - renderfetchtime

            // formarted the time coming form the database into the milisecond style
            function masterfetchtimeformat(str){
                var str1 = str.substring(0,4)+"/";
                var str2 = str.substring(4,6)+"/";
                var str3 = str.substring(6,8)+" ";
                var str4 = str.substring(8,10)+":";
                var str5 = str.substring(10,12)+":";
                var str6 = str.substring(12,14);

                return str1+str2+str3+str4+str5+str6;
            }
            var combine='';
            if(renderfetchtime){
                combine = masterfetchtimeformat(renderfetchtime.toString());
            }

            renderfetchtime = Date.parse(new Date(combine));

            var specifiledtime = res.evaluationtime*60*1000*2;//超时加倍
            var timeconsuming = ( Date.parse(new Date(masterfetchtimeformat(res.servernowtime.toString())))||Date.now()) - renderfetchtime;// Time has been used
            
            if (timeconsuming > specifiledtime) {
                api.getServiceJSONResponsePromise({
                    type: "POST", url: notifyServer + "/emailNotify", data: {
                        to: "sunny@mvt-inc.com", subject: "render timeout and retry on client,jobid=" + jobid,
                        text: "Render timeout. check the render job detail:\n\n" + JSON.stringify(res)
                    }
                }).then(function (res) {
                });
                timeoutEvent(res, '渲染超时');
            } else {
                renderview_currentJob_timeout = setTimeout(renderview_inprogress_queryJobStatus, 1000, jobid);
                renderview_job_timeout_container[jobid] = renderview_currentJob_timeout;
            }
        });
}

//自定义模型渲染请求 add by hcw
function renderview_renderrequestSendComplete_uploadCustomModel(res) {
    renderview_latestRenderBeginTime = Date.now();
    custom_renderview_currentJob_timeout = setTimeout(renderview_inprogress_queryJobStatus__uploadCustomModel, 1000, res.jobid);
    renderview_job_timeout_container[res.jobid] = custom_renderview_currentJob_timeout;
}

/*查询自定义模型渲染任务状态 add by hcw*/
function renderview_inprogress_queryJobStatus__uploadCustomModel(jobid) {
    var renderServer = api.getServicePrefix("render");
    var queryJobUrl = renderServer + "/getJobStatus?jobid=" + jobid;
    var retryJobUrl = renderServer + "/retryJob?jobid=" + jobid;
    var imgUrl = ui.catalogGetFileUrl("render", jobid, "render");
    var notifyServer = api.getServicePrefix("notify");

    api.getServiceJSONResponsePromise({type: "GET", url: queryJobUrl})
        .then(function (res) {
            //console.log(res);
            var status = res && res.jobstatus;
            var wait = $('#renderViewId .renderReady').attr('wait')*1;
            if(isNaN(wait))wait=0;
            if(wait<0)wait=0;
            var rendering=$('#rlrendering ul li').length - wait;
            if(isNaN(rendering))rendering=0;
            if(rendering<0)rendering=0;
            res.retryJobUrl = retryJobUrl;
            //var res = JSON.parse(resp);

            renderview_currentJob_evaluateRenderTime = (renderview_currentJob_evaluateRenderTime === undefined ?
                (res && res.evaluationtime) :
                (renderview_currentJob_evaluateRenderTime === 0 ? (res && res.evaluationtime) / 2 : renderview_currentJob_evaluateRenderTime));
            renderview_currentJob_evaluateRenderTime = Math.ceil(renderview_currentJob_evaluateRenderTime);

            var renderfetchtime=res.masterfetchtime;

            res.evaluationtime=renderview_currentJob_evaluateRenderTime/3; //high 800x600 和以下的 时间设定为 15分钟

            /*清空排队信息*/
            switch (status) {
                case 0:// still in queue.
                    $('#uploadModel_oceano4 .model .model_top .loading_render span').html('正在排队渲染，请稍后');
                    renderview_latestRenderBeginTime = Date.now();
                    api.getServiceJSONResponsePromise({type: "GET", url: renderServer + "/jobsInQueue"})
                        .then(function (res) {
                        }).catch(function (err) {
                        $('#uploadModel_oceano4 .model .model_top .loading_render ').hide();
                        console.log("ERROR:" + err);
                    });
                    break;
                case 1:// fetch by max renderer
                    $('#uploadModel_oceano4 .model .model_top .loading_render span').html('正在渲染');
                    break;
                case 2: // finished
                    $('#uploadModel_oceano4 .model .model_top .loading_render ').hide();
                    $('#uploadModel_oceano4 .model .model_top .render_pic p').html("<img src='"+imgUrl+"' width='400' height='400'/>")
                    renderview_jobid_localtime_Map.remove(res.jobid);
                    return;
                case 3:// failed
                   $('#uploadModel_oceano4 .model .model_top .loading_render ').hide();
                   layer.msg('渲染失败，请重新渲染！')
                    api.getServiceJSONResponsePromise({
                        type: "POST", url: notifyServer + "/emailNotify", data: {
                            to: "sunny@mvt-inc.com", subject: "render engine report error,jobid=" + jobid,
                            text: "Render timeout. check the render job detail:\n\n" + JSON.stringify(res)
                        }
                    });
                    return;
                    break;
                default:
                    console.log("failed. status=" + status + ",masterid=" + res.masterid);
                    break;
            }
            // Solution：timeconsuming can not greater than the specifiled time,and timeconsuming = Date.now() - renderfetchtime
            var combine;
            // formarted the time coming form the database into the milisecond style
            function masterfetchtimeformat(str){
                var str1 = str.substring(0,4)+"/";
                var str2 = str.substring(4,6)+"/";
                var str3 = str.substring(6,8)+" ";
                var str4 = str.substring(8,10)+":";
                var str5 = str.substring(10,12)+":";
                var str6 = str.substring(12,14);

                combine = str1+str2+str3+str4+str5+str6;
            }
            if(renderfetchtime){
                masterfetchtimeformat(renderfetchtime.toString());
            }

            renderfetchtime = new Date(combine).getTime();

            var specifiledtime = res.evaluationtime*60*1000;
            var timeconsuming = Date.now() - renderfetchtime;// Time has been used

            if (timeconsuming > specifiledtime) {
                api.getServiceJSONResponsePromise({
                    type: "POST", url: notifyServer + "/emailNotify", data: {
                        to: "sunny@mvt-inc.com", subject: "render timeout and retry on client,jobid=" + jobid,
                        text: "Render timeout. check the render job detail:\n\n" + JSON.stringify(res)
                    }
                }).then(function (res) {
                });
                $('#uploadModel_oceano4 .model .model_top .loading_render ').hide();
                layer.msg('渲染超时');
            } else {
                custom_renderview_currentJob_timeout = setTimeout(renderview_inprogress_queryJobStatus__uploadCustomModel, 1000, jobid);
                renderview_job_timeout_container[jobid] = custom_renderview_currentJob_timeout;
            }
        });
}

/*添加正在渲染的任务加入列表*/
function addRenderingJobTaskToList(jobid) {
    if (renderview_jobidArray.indexOf(jobid) == -1)renderview_jobidArray.push(jobid);
    renderListData.rlrendering.state = 1;
    renderListData.rlrendering.length++;
    renderListData.rlrendering.content.unshift({
        previewpic:arguments[1]?arguments[1]:$('#paper3dwebgl')[0].toDataURL(),
        progessbar:$("<div>",{"id": "renderIndicatorContainer_" + jobid, "style": "text-align: center;margin: 20px 30px;"}).radialIndicator({
            radius: 45,
            barColor: '#ff5a0a',
            barWidth: 10,
            initValue: 0,
            roundCorner: true,
            percentage: true
        }),
        roomName:arguments[2]?arguments[2]:GetCurrentRoomName(),
        icons:[{'target':'<a>','class':'closeIcon',title:'终止渲染',href:'javascript:'}],
        jobid:jobid
    });

    doRenderLIstUI('rlrendering');
}

/*任务排队更新列表信息*/
function jobsInQueueUpdateJobTaskToList(jobid, res) {
    if (res && res.error == 0 && res.jobids) {
        var jobIdx = res.jobids.indexOf(jobid) + 1;
        var waitcount=0;
        var tempjobid='';
        for(var i=0;i<renderListData.rlrendering.length;i++){
            for(var j=0;j<res.jobids.length;j++){
                if(renderListData.rlrendering.content[i].jobid == res.jobids[j]){
                    waitcount++;
                    tempjobid=res.jobids[j];
                }
            }
        }
        if(waitcount==1){
            $('#renderViewId .renderReady').attr('tempjobid',tempjobid);
        }
        $('#renderViewId .renderReady').attr('wait',waitcount);
        var jobCount = res.jobids.length;
        var html = "<div class='queueShowInfo'><label style='color:black;'>共有" + "<span style='color:red;font-size:20px;font-weight: bold;'>" + jobCount + "</span>" + "个渲染任务排队中";
        var text="等待中,您排在第<span style='color:red;font-size:25px;font-weight: bold;'>" + jobIdx + "</span>" + "位。</label></div>";
        $('#rlrendering li[jobid="'+jobid+'"] .InQueue').html(text)
        $('.renderBegin .Progressbar').html(html);
    }
}

/*更新渲染结束任务列表信息*/
function updateRenderedJobTaskToList(res, imgUrl, thumbImgUrl) {
    renderview_jobMeta[res.jobid] = res;
    var type='rleffectdrawing';
    if (res.outputtype === "panorama") {
        type='rlvreffectdrawing';
    }
    for(var i = 0;i <renderListData.rlrendering.length ; i++){
        if(renderListData.rlrendering.content[i].jobid == res.jobid){
            renderListData[type].length++;
            renderListData[type].state = 1;
            renderListData[type].content.unshift({
                type:type,
                jobid:res.jobid,
                checked:false,
                roomName:renderListData.rlrendering.content[i].roomName,
                icons:[
                    {'target':'<a>','class':'deleteIcon',title:'删除',href:'javascript:'},
                    {'target':'<a>','class':'saveIcon',title:'保存',href:'javascript:',url:ui.catalogGetFileUrl("render", res.jobid, "render")},
                    {'target':'<a>','class':'qrIcon',title:'二维码',href:'javascript:'},
                    {'target':'<a>','class':'detailIcon',title:'详情',href:'javascript:'}
                ],
                pic:{
                    "renderwidth": res.renderwidth,
                    "renderheight": res.renderheight,
                    "src": thumbImgUrl
                }
            })
            renderListData.rlrendering.content.splice(i,1);
            renderListData.rlrendering.length --;
            if(renderListData.rlrendering.length == 0){
                renderListData.rlrendering.state=0;
            }
            --i;
            break;
        }
    }
    doRenderLIstUI('All');
}

//start add by   gaoning
//新建时清除已渲染出来的效果图 。
function clearRenderedJobTaskToList() {
    var server = api.getServicePrefix("design");
    var url = server + "/removeDesignAndRenderRelation";
    var designMeta = ui.getOpenedDesignMeta();
    var did = designMeta ? designMeta.designId : "";
    $.ajax({
        type: 'post',
        url: url,
        cache: false,
        data: {
            did: did,
            jobid: renderview_jobidArray
        }
    }).done(function () {
        renderview_jobidArray=[];
        renderListData={
            rlrendering:{
                length:0,
                state:0,
                hint:"<span  class='render_tooltip'></span><br/>当前没有效果图<br>请点击“开始渲染”添加渲染任务",
                content:[]
            },
            rleffectdrawing:{
                length:0,
                state:0,
                hint:"<span class='render_tooltip'></span><br/>当前没有效果图<br>请点击“开始渲染”添加渲染任务",
                content:[]
            },
            rlvreffectdrawing:{
                length:0,
                state:0,
                hint:"<span class='render_tooltip'></span><br/>当前没有效果图<br>请点击“开始渲染”添加渲染任务",
                content:[]
            },
            rlrecyclebin:{
                length:0,
                state:0,
                hint:"<span class='render_tooltip'></span><br/>当前没有可恢复的效果图",
                content:[]

            }
        };
        doRenderLIstUI("All");
    }).fail(function () {
        console.log("删除失败！");
    });
}
//end add by gaoning

/**渲染进行中信息*/
function renderview_rendering_info(res) {
    var jobcreatetime = createInternalTime().toString();
    if (renderview_jobid_localtime_Map.containsKey(res.jobid)) {
        if(isRetry){
            isRetry = false;
            renderview_jobid_localtime_Map.remove(res.jobid);
            renderview_jobid_localtime_Map.put(res.jobid, jobcreatetime);
        }else{
            jobcreatetime = renderview_jobid_localtime_Map.get(res.jobid);
        }
        //jobcreatetime = renderview_jobid_localtime_Map.get(res.jobid);
    } else {
        renderview_jobid_localtime_Map.put(res.jobid, jobcreatetime);
    }
    var nowTime = createInternalTime().toString();
    var _timeDiff = timeDiff(jobcreatetime, nowTime);

    var animate;

    /*if (window.global_quality_advanced) {
        animate = 2 * Math.atan(_timeDiff / (45*60)) / Math.PI;
        if(res.outputtype == "panorama"){
            animate = 2 * Math.atan(_timeDiff / (90*60)) / Math.PI;
        }
    } else {
        animate = 2 * Math.atan(_timeDiff / (10*60)) / Math.PI;
        if(res.outputtype == "panorama"){
            animate = 2 * Math.atan(_timeDiff / (45*60)) / Math.PI;
        }
    }*/

    if (window.global_quality_advanced) {
        animate = 2 * Math.atan(_timeDiff / 200) / Math.PI;
    } else {
        animate = 2 * Math.atan(_timeDiff / 20) / Math.PI;
    }

    animate = Math.floor(animate * 100);

    $("#renderIndicatorContainer_" + res.jobid).data('radialIndicator').animate(animate);
    var master = res.masterdata && JSON.parse(res.masterdata);
    if (master)$("#rendermachine_" + res.jobid).html("渲染机名称:" + master.hostname + "  渲染机IP:" + master.ip);

}

/*读取渲染任务加入列表*/
function addJobTaskToList(res, imgUrl, thumbImgUrl) {
    if (renderview_jobidArray.indexOf(res.jobid) == -1)renderview_jobidArray.push(res.jobid);
    renderview_jobMeta[res.jobid] = res;
    var type = 'rleffectdrawing';
    if (res.outputtype === "panorama") {
        type = 'rlvreffectdrawing';
    }
    if (res.isdelete == 1) {
        type = 'rlrecyclebin';
    }

    renderListData[type].state = 1;
    renderListData[type].length++;
    renderListData[type].content.unshift({
        type: type,
        jobid: res.jobid,
        icons:[
            {'target':'<a>','class':'deleteIcon',title:'删除',href:'javascript:'},
            {'target':'<a>','class':'saveIcon',title:'保存',href:'javascript:',url:ui.catalogGetFileUrl("render", res.jobid, "render")},
            {'target':'<a>','class':'qrIcon',title:'二维码',href:'javascript:'},
            {'target':'<a>','class':'detailIcon',title:'详情',href:'javascript:'}
        ],
        pic: {
            "renderwidth": res.renderwidth,
            "renderheight": res.renderheight,
            "src": thumbImgUrl
        }
    })
    doRenderLIstUI("All");
}

function renderview_loadimage(imgUrl) {
    var img = new Image();
    img.src = imgUrl;
    var $div = $("<div>").addClass("retry").html("图片正在加载中，请稍候。。。");
    $("#renderViewBrowseId .image_div").empty().append($div);
    if (img.complete) {
        $("#renderViewBrowseId .image_div").empty().append($(img));
    } else {
        img.onload = function (e) {
            $("#renderViewBrowseId .image_div").empty().append($(img));
        }
        img.onerror = function (e) {
            var $retry = $("<input>").attr({
                "type": "button",
                "value": "点击重试"
            }).addClass("button button_orange").on("click", function (e) {
                renderview_loadimage(imgUrl);
            });
            var $div = $("<div>").addClass("retry").append("图片加载失败，请 ").append($retry).append("，或者下载图片到本地浏览。");
            $("#renderViewBrowseId .image_div").empty().append($div);
        }
    }
}

function renderview_OpenPanorama(jobid) {
    // 1. open dialog:
    var url = api.getServicePrefix("bom") + "/panoView?id=" + jobid;
    // todo open qrcode dialog.
    bomDialogPrompt(url, "全景VR");
    // window.open(url);

    // 2. update others:
    var jobMeta = renderview_jobMeta[jobid];
}

function GetCurrentRoomName(){
    var cameraPos = new vector2();
    var curCamera = api.floorplanFilterEntity(function(e)
    {
        return e.type=="CAMERA";
    });
    for(var i= 0;i < curCamera.length;i ++)
    {
        if(curCamera[i].active == true)
        {
            //得到相机的三维坐标
            cameraPos.x = curCamera[i].x;
            cameraPos.y = curCamera[i].y;
        }
    }
    var roomsPos = new Array();
    var index = 0;
    var roomName = '';
    var rooms = api.floorplanFilterEntity(function(e){return e.type=="FLOOR";});
    for(var i = 0; i < rooms.length;i ++)
    {
        index = 0;
        for(var r =0;r < rooms[i].getLoop().length; r ++)
        {
            var pos = new vector2();
            pos.x = rooms[i].getLoop()[r].x;
            pos.y = rooms[i].getLoop()[r].y;
            roomsPos[index] = pos;
            index ++;
        }
        var check = checkPointInPolygon(cameraPos,roomsPos);
        if(check == true){
            roomName = rooms[i].label;
            break ;
        }

    }
    return roomName;
}

function timeoutEvent(res, text){
    for(var i = 0 ;i<renderListData.rlrendering.length ;i++){
        if(renderListData.rlrendering.content[i].jobid==res.jobid){
            renderListData.rlrendering.content[i].res=res;
        }
    }
    doRenderLIstUI('rlrendering');
    if($('.renderDescribe .erorrMsgDiv').length){
        $('.renderDescribe .erorrMsgDiv').html(text+"，请重新渲染");
    }else{
        $('.renderDescribe').append($('<div>',{"class":"erorrMsgDiv","text":text+"，请重新渲染","style":"color:blue"}))
    }

}
//# sourceURL=ui\renderview\renderview.js