/*菜单添加事件 start*/
$("#menubar .menu .title").on("mouseover", function (e) {
    $(this).siblings(".options").addClass("hover");
}).on("mouseleave", function (e) {
    $(this).siblings(".options").removeClass("hover");
});

$("#menubar .menu .options").on("mouseover", function (e) {
    $(this).addClass("hover");
}).on("mouseleave", function (e) {
    $(this).removeClass("hover");
});

$("#menubar .menu .option").on(click, function (e) {
    $(this).parents().find(".options").removeClass("hover");
});


$("#menubar .menu .options .submenu").on("touchend mouseover mouseup", function (e) {
    if (isMobileDevice() && e.type == "mouseover")return;

    var offset = $(this).offset(), width = $(this).outerWidth();
    var suboptions = $(this).next(".submenu_options");
    suboptions.addClass("hover");
    suboptions.offset({left: offset.left + width, top: offset.top});
}).on("mouseleave", function (e) {
    $(this).next(".submenu_options").removeClass("hover");
});
/*菜单添加事件 end*/


/*保存到云*/
$("#menuFileSaveCloud").on(click, function () {
    if (0){//!api.floorplanIsNormalized()) {
        layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再保存", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
            layer.close(idx);
            api.actionBegin("AnalyzeNormalized");
            var result = api.actionRun("analyze");
        });
    } else saveCloudDesignPanelPrompt();
});
$("#menuFileSaveLocal").on(click, function () {
    if (0){//!api.floorplanIsNormalized()) {
        layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再保存", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
            layer.close(idx);
            api.actionBegin("AnalyzeNormalized");
            var result = api.actionRun("analyze");
        });
    } else fileSaveLocalHandler();
});
$("#menuFileOpenCloud").on(click, function () {
    globalModelIndex = 1;
    openCloudDesignPanelPrompt();
});
$("#fileInputOpenLocal").on("change", fileInputOpenLocalChangeHandler);

$("#menuFileNew").on(click, fileNewHandler);
$("#menuFileOpenLocal").on(click, function () {
    $("#fileInputOpenLocal").trigger(click);
});

/*2D视图*/
$("#view2DActive").on(click, view2DActiveHandler);

/*3D平视*/
$("#view3DFirstPersonActive").on(click, view3DFirstPersonActiveHandler);

/*3D鸟瞰*/
$("#view3DBirdViewActive").on(click, view3DBirdViewActiveHandler);

$("#viewFullscreen").on(click, view3dFullScreenHandler);
$("#viewOculusVR").on(click, function () {
    if (typeof OculusVRPrompt == "function")OculusVRPrompt();
});
$("#viewWalkThrough3D").on(click, function () {
    if (typeof WalkThroughPrompt == "function")WalkThroughPrompt();
});
/*画墙*/
$("#drawFreeWall").on(click, function (e) {
    api.actionBegin("AddWall", {continuous: !isMobileDevice()});
});
$("#drawRectWall").on(click, function (e) {
    api.actionBegin("AddRectRoom", {continuous: !isMobileDevice()});
});
/*画区域*/
$("#drawInnerFreeArea").on(click, function (e) {
    api.actionBegin("AddFreeArea", "inner");
});
$("#drawInnerRectArea").on(click, function (e) {
    api.actionBegin("AddRectArea", "inner");
});
$("#drawInnerCircleArea").on(click, function (e) {
    api.actionBegin("AddRoundArea", "inner");
});
$("#drawOuterFreeArea").on(click, function (e) {
    api.actionBegin("AddFreeArea", "outer");
});
$("#drawOuterRectArea").on(click, function (e) {
    api.actionBegin("AddRectArea", "outer");
});
$("#drawOuterCircleArea").on(click, function (e) {
    api.actionBegin("AddRoundArea", "outer");
});
/*2d 居中*/
$("#view2dFit").on(click, function () {
    api.viewFit("2d");
    api.viewFit("3d");
});
$("#viewNavigationToolbar").on(click, function () {
    var toolbar = $("#toolbar_navigator");
    toolbar.is(":hidden") ? toolbar.show() : toolbar.hide();
});
$("#viewCatalogTabContainer").on(click, function () {
    $("#mainLayoutId .tab-container").toggle();
    resizePage();
    $("#view2dFit").trigger(click);
});
$("#viewRenderShow").on(click, function () {
    if (typeof renderImageShowPanelPrompt == "function")renderImageShowPanelPrompt();
});
$("#menuSnapshot").on(click, function () {
    var activeViewId = $("#paper2d").has("#paper2dsvg").length == 0 ? "3d" : "2d";
    downloadSnapshot(activeViewId, $("#paper2d").width(), $("#paper2d").height());
});
function hideProductDialog() {
    if (typeof showHideProductPanelPrompt == "function")showHideProductPanelPrompt();
}
$("#viewHiddenProductDialog").on(click, hideProductDialog);
$(document).on('keydown', null, "h", hideProductDialog);

/*3d 物体操作*/
$("#menubar .menu input[name='transform3d']").parent().on(click, function (e) {
    var inputObj = $(this).children("input");
    inputObj.prop("checked", true);
    api.threeSetTransformMode(inputObj.attr("mode"));
});
$("#menubar .menu div[name='transform3d']").on(click, function (e) {
    var inputObj = $(this);
    api.threeSetTransformMode(inputObj.attr("mode"));
});
$("#importBackImage").on(click, function (e) {
    $("#importUnderlay").trigger(click);
});
$("#exportOBJ").on(click, function (e) {
    var content = api.threeExport("OBJ");
    var filename = "我的设计-" + (new Date()).toLocaleString() + ".obj";
    api.saveAs(new Blob([content], {type: "text/plain;charset=" + document.characterSet}), filename);
});
$("#exportMAX").on(click, function (e) {
    alert("in progress...");
});
$("#exportDXF").on(click, exportDXF);
$("#exportCAD").on(click, exportCAD);
$("#toolLockFloorplan").on(click, function (e) {
    if (api.floorplanIsLocked()) return;
    api.floorplanLock(true);
    // todo notify other view.
});
$("#toolUnLockFloorplan").on(click, function (e) {
    if (!api.floorplanIsLocked()) return;

    layer.confirm('解锁户型后可以修改户型。<br>是否继续解锁户型？', {
        btn: ['确定', '取消'], //按钮
        shade: 0.3, //不显示遮罩
        skin: 'layui-layer-default',
        title: '提示'
    }, function (index) {
        api.floorplanLock(false);
        layer.close(index);
    }, function () {
        //layer.msg('取消', {shift: 6});
    });
    // todo notify other view.
});
$("#menuBom").on(click, exportBOM);
$("#menuRulerMeasure").on(click, rulerMeasure);

// render dialog prompt
$(document).on('keydown', null, "F10", renderBtnHandler);
$("#menuRender").on(click, renderBtnHandler);
$("#menuMaterialDropper").on(click, function (e) {
    api.actionBegin("MaterialDropper");
});
$("#menuHelpGuide").on(click, function (e) {
});
$("#menuBeginCollaboration").on(click, function (e) {
    if (typeof startCollaborationMode != "undefined")startCollaborationMode();
});
$("#menuHelpHotkey").on(click, function (e) {
    $('#hotkeyTable').dialog("open");
});
$("#menuHelpFeedback").on(click, function (e) {
});
$("#menuHelpAbout").on(click, function (e) {
    var aoubtUsDialogIndex = layer.open({
        type: 1,
        title: '关于',
        skin: 'layui-layer-default',
        fix: false,
        //closeBtn: false,
        shadeClose: false,
        maxmin: false,
        area: ['422px', '280px'],
        content: $('#aboutUs')
    });
});
$("#viewOptions").on(click, function (e) {
    viewOptionsPanelPrompt();
});

$('#menuHideAllProductId').on(click, hideOrShowAllProduct.bind(undefined, true));
/*添加物品*/
$('#menuAddProductPageId').on(click, function () {
    addProductPanelPrompt();
});
$('#menuAddTextAnnotation').on(click, addTextAnnotation);
$('#menuAddPillar').on(click, addPillar);
$('#menuAddBasement').on(click, addBasement);
$('#menuAddBeam').on(click, addBeam);
$('#menuAddCamera').on(click, addCamera);
$('#viewSelectCamera').on(click, selectCamera);

/*********************************************/
$("#menuAnalyzeNormalizedFloorplan").on(click, function () {
    api.actionBegin("AnalyzeNormalized");
    var result = api.actionRun("analyze");
    var msg = "恭喜您，已经是标准户型";
    if (result.length != 0) {
        var errorCode = result[0].error;// todo
        if (errorCode == 1)msg = "发现非标准化墙体，请分割墙体或移动点";
    }
    layer.msg(msg, {offset: '60px', time: 3500});
});
$("#menuMakeNormalizedFloorplan").on(click, function () {
    api.actionEnd();
    //if (!api.floorplanIsNormalized()) {
        //api.floorplanMakeNormalized();
    //}
});
$("#menuAddAutoLight").on(click, function () {
    if (autoLightFilter().length != 0) {
        layer.alert("当前设计中已经有自动打的灯光。<br>如果需要进行灯光重新布置，请首先删除一键布置的灯光，然后重新一键打灯。");
        return;
    }
    autoLightAdd("p369dc8ca8e98492eaa8486a33d33eeb4", "p9a85c56025e2454f975f223d68bf934a", "aaa");
});
$("#menuRemoveAutoLight").on(click, function () {
    autoLightRemove();
});
//# sourceURL=ui\menu\menu.js