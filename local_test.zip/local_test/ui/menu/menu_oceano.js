/*菜单添加事件 start*/
$("#menubar .menu .title").on("mouseover", function (e) {
    $(this).siblings(".options").addClass("hover");
}).on("mouseleave", function (e) {
    $(this).siblings(".options").removeClass("hover");
});

$("#menubar .menu .options").on("mouseover", function (e) {
    $(this).addClass("hover");
}).on("mouseleave", function (e) {
    $(this).removeClass("hover");
});

$("#menubar .menu .option").on(click, function (e) {
    //change by gaoning 2013.3.13--
    //console.log(e.currentTarget.id); //menuLoadOceanoHouseImage
    //if (e.currentTarget.id == "menuLoadOceanoHouseImage") {
    //    $("#importUnderlay").trigger("click");
    //} else {
    //    $(this).parents().find(".options").removeClass("hover");
    //}

    $(this).parents().find(".options").removeClass("hover");
});


$("#menubar .menu .options .submenu").on("touchend mouseover mouseup", function (e) {
    if (isMobileDevice() && e.type == "mouseover")return;

    var offset = $(this).offset(), width = $(this).outerWidth();
    var suboptions = $(this).next(".submenu_options");
    suboptions.addClass("hover");
    suboptions.offset({left: offset.left + width, top: offset.top});
}).on("mouseleave", function (e) {
    $(this).next(".submenu_options").removeClass("hover");
});
/*菜单添加事件 end*/

$("#fileInputOpenLocal").on("change", fileInputOpenLocalChangeHandler);
$('#menuHideAllProductId').on(click, hideOrShowAllProduct.bind(undefined, true));
$('#menuShowAllProductId').on(click, hideOrShowAllProduct.bind(undefined, false));

//add by gaoning 2016.8.29
//$('#menuExportOceanoWallImage').on(click, hideOrShowAllProduct.bind(undefined, true));

$('#menuHideAllOtherStructureId').on(click, hideOrShowAllOtherStructure.bind(undefined, true));
$('#menuShowAllOtherStructureId').on(click, hideOrShowAllOtherStructure.bind(undefined, false));

/*保存到云*/
/*$("#menuFileSaveCloud").on(click, function () {
 if (!api.floorplanIsNormalized()) {
 layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再保存", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
 layer.close(idx);
 api.actionBegin("AnalyzeNormalized");
 var result = api.actionRun("analyze");
 });
 } else saveCloudDesignPanelPrompt(undefined, "false");
 });*/

/*保存到云*/
$("#menuFileNewSaveCloud").on(click, function () {
     //api.viewFit('3d');
    //显示3d预览视图
    $('#threedViewId .close').fadeOut();
    $('#threedViewId .open').fadeIn();
    $('#paper3d').fadeIn(function () {
        api.viewFit("3d");
    });
    if (typeof (globalTradeIds) != 'undefined') {
        if (globalTradeIds) {
            var Area = api.floorplanFilterEntity(function (e) {
                return e.type == "FLOOR";
            })
            var countName = 0;
            for (var i = 0; i < Area.length; i++) {
                if (Area[i].label != '')countName++
            }
            if (countName != Area.length) {
                layer.msg('请将所有房间命名！')
                return;
            }
        }
    }
    if (0) {//!api.floorplanIsNormalized()) {
        layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再保存", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
            layer.close(idx);
            api.actionBegin("AnalyzeNormalized");
            var result = api.actionRun("analyze");
        });
    } else saveCloudDesignPanelPromptExternal(undefined, "false");
});

/*保存到云-另存为*/
$("#menuFileNewSaveAsCloud").on(click, function () {
    api.viewFit('3d');
    if (0) {//!api.floorplanIsNormalized()) {
        layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再保存", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
            layer.close(idx);
            api.actionBegin("AnalyzeNormalized");
            var result = api.actionRun("analyze");
        });
    } else saveCloudDesignPanelPromptExternal(undefined, "true");
});

/*保存到云-另存为*/
/*$("#menuFileSaveAsCloud").on(click, function () {
 if (!api.floorplanIsNormalized()) {
 layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再保存", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
 layer.close(idx);
 api.actionBegin("AnalyzeNormalized");
 var result = api.actionRun("analyze");
 });
 } else saveCloudDesignPanelPrompt(undefined, "true");
 });*/

$("#menuFileSaveAs").on(click, function () {
    if (0) {//!api.floorplanIsNormalized()) {
        layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再保存", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
            layer.close(idx);
            api.actionBegin("AnalyzeNormalized");
            var result = api.actionRun("analyze");
        });
    } else fileSaveLocalHandler();
});

$("#menuFileOpenLocal").on(click, function () {
    $("#fileInputOpenLocal").trigger(click);
});

$("#menuFileOpenCloud").on(click, function () {
    //openCloudDesignPanelPrompt();
    window.open(appSettings.designjavadomain + "/startdesign");

});

/*新建*/
/*$("#menuFileNew").on(click, function (e) {
 //newCloudDesignPanelPrompt();

 layer.confirm('您确定要新建吗？', {
 btn: ['确定', '取消'],
 shade: 0.3,
 skin: 'layui-layer-default',
 title: '提示'
 }, function (index) {
 layer.close(index);
 fileNewHandler();
 }, function () {
 });
 });*/

$("#menuFileNew").click(function (e) {
    window.open(getHomeDesignFullUrl({"notEdit": "0"}));
});
function getHomeDesignFullUrl(paramobj) {
    var url = window.location.host;
    var designId = paramobj.designId || "";
    var entityId = paramobj.entityId || "";
    var designType = paramobj.designType || "";
    var notEdit = paramobj.notEdit || "1";
    url = url.concat("/diy/did").concat(designId);
    url = url.concat("eid").concat(entityId);
    url = url.concat("dt").concat(designType);
    url = url.concat("ne").concat(notEdit);
    url = "http://" + url;
    log(url);
    return url;
}

//设置是否显示墙线--add by gaoning 2017.8.16
$("#exportHouseImage .Lebel_Table input.showAllDimensionLayer").on(click, function (e) {
    if ($(this).is(':checked')) { /*设定*/
        //console.log("1111111111");
    } else { /*取消设定*/
        //console.log("2222222222");
    }
});

var isShowOutRoomLabel = true;
var isShowOutLabel = true;
var getHouseImageValue = false;

//初始化选择框内容及响应事件--add by gaoning 2017.7.5
//var layerState = api.getSnapLayerState();
function InitSelectUI() {
    $("#exportHouseImage .Lebel_Table input.showAllDimensionLayer").prop("checked", true);

    //$("#exportHouseImage .Lebel_Table input.showDimensionLayer").prop("checked", true);
    $("#exportHouseImage .Lebel_Table input.showUnderlayLayer").prop("checked", true);
    $("#exportHouseImage .Lebel_Table input.showGridLayer").prop("checked", true);
    $("#exportHouseImage .Lebel_Table input.showRoomLabel").prop("checked", true);
    $("#exportHouseImage .Lebel_Table input.showTextAnnotation").prop("checked", true);
    $("#exportHouseImage .Lebel_Table input.showOutRoomLabel").prop("checked", true);
    $("#exportHouseImage .Lebel_Table input.showOutLabel").prop("checked", true);
    api.setShowOutRoomLabel(true);
    api.setShowOutLabel(true);

    //恢复默认值
    layerState = api.getSnapLayerState();
    api.getViewById("2d").changeSettings("showInnerDimensionLayer", false);
    api.getViewById("2d").changeSettings("showDimensionLayer", false);//新需求，不显示墙中线和内墙线showInnerDimensionLayer

    api.getViewById("2d").changeSettings("showUnderlayLayer", true);
    api.getViewById("2d").changeSettings("showGridLayer", true);
    api.getViewById("2d").changeSettings("showGridLayer", true);
    api.getViewById("2d").changeSettings("showRoomLabel", true);
    api.getViewById("2d").changeSettings("showTextAnnotation", true);

    $("#exportHouseImage .Lebel_Table input").on("click", function (e) {
        if ($(this).hasClass("showDimensionLayer")) {
            if ($(this).is(":checked")) {
                api.getViewById("2d").changeSettings("showDimensionLayer", true);
            } else {
                api.getViewById("2d").changeSettings("showDimensionLayer", false);
            }
        }

        if ($(this).hasClass("showUnderlayLayer")) {
            if ($(this).is(":checked")) {
                api.getViewById("2d").changeSettings("showUnderlayLayer", true);
            } else {
                api.getViewById("2d").changeSettings("showUnderlayLayer", false);
            }
        }

        if ($(this).hasClass("showGridLayer")) {
            if ($(this).is(":checked")) {
                api.getViewById("2d").changeSettings("showGridLayer", true);
            } else {
                api.getViewById("2d").changeSettings("showGridLayer", false);
            }
        }

        if ($(this).hasClass("showRoomLabel")) {
            if ($(this).is(":checked")) {
                api.getViewById("2d").changeSettings("showRoomLabel", true);
            } else {
                api.getViewById("2d").changeSettings("showRoomLabel", false);
            }
        }

        if ($(this).hasClass("showTextAnnotation")) {
            if ($(this).is(":checked")) {
                api.getViewById("2d").changeSettings("showTextAnnotation", true);
            } else {
                api.getViewById("2d").changeSettings("showTextAnnotation", false);
            }
        }

        if ($(this).hasClass("showOutRoomLabel")) {
            if ($(this).is(":checked")) {
                isShowOutRoomLabel = true;
                api.setShowOutRoomLabel(true);
            } else {
                isShowOutRoomLabel = false;
                api.setShowOutRoomLabel(false);
            }
        }

        if ($(this).hasClass("showOutLabel")) {
            if ($(this).is(":checked")) {
                isShowOutLabel = true;
                api.setShowOutLabel(true);
            } else {
                isShowOutLabel = false;
                api.setShowOutLabel(false);
            }
        }
    });
}

//获取户型图信息，点击确认时才获取--change by gaoning 2017.7.5
function getExportHouseImagePrompt() {
    //init other
    $(".zoom-location").click();

    var objBox = $("#paper2dsvg").parent().find("svg").find("g[type='INDIMENSION']")[0].getBBox();//getBoundingClientRect,这个方法备用
    //console.log(objBox);

    //console.log("----------------");
    //console.log(paperTmp2dObj.find("svg")[0].viewBox.baseVal);
    var view = api.getViewById("2d");
    var lengthIndex = api.getLengthIndex();
    var centerPoint = api.getLabelCenterPoint();

    var imageLength = getSVGImageLength(); //0:wLength
    if(getHouseImageValue){
        view.fitToExport(imageLength[1] + 50, imageLength[0] + 50,centerPoint);
    }else{
        view.fitToExport(imageLength[1] + 100, imageLength[0] + 100,centerPoint);
    }
    //console.log(lengthIndex);
    //if(getHouseImageValue){
    //    view.fitToExport(objBox.height + 50, objBox.width + 50);
    //} else if (isShowOutRoomLabel) {
    //    //if (lengthIndex == 1) {
    //    //    view.fitToExport(objBox.height + 300, objBox.width + 100);
    //    //} else if (lengthIndex == 2) {
    //    //    view.fitToExport(objBox.height + 400, objBox.width + 100);
    //    //} else if (lengthIndex == 3) {
    //    //    view.fitToExport(objBox.height + 500, objBox.width + 100);
    //    //} else if (lengthIndex == 4) {
    //    //    view.fitToExport(objBox.height + 600, objBox.width + 100);
    //    //}
    //
    //    view.fitToExport(objBox.height + 200, objBox.width + 200);
    //
    //} else if (isShowOutLabel) {
    //    view.fitToExport(objBox.height + 100, objBox.width + 100);
    //} else {
    //    view.fitToExport(objBox.height + 100, objBox.width + 100);
    //}

    var paperTmp2dObj = $("#paper2dsvg").parent().clone();
    paperTmp2dObj.find("svg").attr({
        id: "svg_" + createInternalTime().toString()
        //viewBox: "-512 -512 1024 1024"
        //preserveAspectRatio: "xMinYMin"
        //preserveAspectRatio: "xMidYMid slice"
    }).css({width: "100%", height: "100%"});

    //if(isShowOutRoomLabel){
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.height += 200;
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.width += 200;
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.x -= 100;
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.y -= 200;
    //}else if(isShowOutLabel){
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.height += 50;
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.width += 50;
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.x -= 20;
    //    paperTmp2dObj.find("svg")[0].viewBox.baseVal.y -= 30;
    //}

    paperTmp2dObj.find("g[type='CAMERA']").remove();
    paperTmp2dObj.find("g[type='Grid']").remove();
    paperTmp2dObj.find("g[type='IES']").remove();
    paperTmp2dObj.find("g[type='FILLLIGHT']").remove();
    paperTmp2dObj.find("g[type='CEILING']").remove();
    paperTmp2dObj.find("g[type='PRODUCT_MARK']").remove();
    paperTmp2dObj.find("g[type='AUXILLARY_ARROW']").remove();
    paperTmp2dObj.find("g[type='SEAT']").find("rect").remove();
    paperTmp2dObj.find("g[type='SURFACE']").find("rect").remove();
    if (!api.getViewById("2d").settings.showUnderlayLayer) {
        paperTmp2dObj.find("g[type='UNDERLAY']").remove();
    }
    //通过透明度隐藏辅助显示对象
    paperTmp2dObj.find("path").each(function () {
        if ($(this).css("fill-opacity") == 0.65) {
            $(this).css("fill-opacity", "0.0");
        }
    });
    paperTmp2dObj.find("path").each(function () {
        if ($(this).css("stroke-opacity") == 0.85) {
            $(this).css("stroke-opacity", "0.0");
        }
    });
    //通过透明度隐藏辅助显示对象 end
    
    return paperTmp2dObj.find("svg")[0];
}

/*导出户型图*/
$("#menuExportOceanoHouseImage").on("click", function (e) {

    getHouseImageValue = false;

    //init ui
    InitSelectUI();

    api.getTmallOrderinfo().then(function (data) {
        var jsonData = data;
        if(jsonData){
            exportHouseImagePrompt(jsonData)();
        }else{
            layer.msg('请先保存方案')
        }
    });
});

/*add by   gaoning 2016.8.29*/
/*导出墙面图*/
$("#menuExportOceanoWallImage").on("click", function (e) {
    var picked = api.pickGetPicked()[0];
    if(picked && picked.model.type == "FLOOR"){
    	advancedPaintExportPrompt(picked.model);
    	
    	api.getTmallOrderinfo().then(function (data) {
	        var jsonData = data;
	        getFloorWallsImage(jsonData,true,function(data){	 
	        	$("#advancedpaintexport_dialog").dialog("close");       	
	        });
	    });
    	
    }else{
    	layer.alert('请先选中导出的房间', {
          title: '提示',
          skin: 'layui-layer-default'
      }, function (index) {
          layer.close(index);
      });
    }
});


/*导出户型图设置弹出层*/
var exportHouseImagePrompt = function (jsonData) {

    var dialogIndex = undefined;

    function optionsDialog() {
        var dialogWidth = 300;
        var dialogHeight = 400;  //修改弹出边框的大小 --by gaoning 2017.7.4
        dialogIndex = layer.open({
            type: 1,
            title: '导出户型图',
            skin: 'layui-layer-default',
            fix: false,
            //closeBtn: false,
            shadeClose: false,
            maxmin: false,
            move: false,
            area: [dialogWidth + 'px', dialogHeight + 'px'],
            content: $('#exportHouseImage'),
            success: function () {
                $("#exportHouseImage").parents(".layui-layer-default").draggable();
                $("#exportHouseImage .buttons button").off("click").on("click", function () {
                    layer.close(dialogIndex);

                    if ($(this).hasClass("cancel")) {
                        //关闭UI同时要清理标注信息--gaoning 2017.7.4
                        api.SetLabelActive();

                        //恢复默认值
                        //api.getViewById("2d").changeSettings("showDimensionLayer", true);
                        if(layerState == "OUT"){
                            api.getViewById("2d").changeSettings("showDimensionLayer", true);
                            api.getViewById("2d").changeSettings("showInnerDimensionLayer", false);
                        }else {
                            api.getViewById("2d").changeSettings("showDimensionLayer", false);
                            api.getViewById("2d").changeSettings("showInnerDimensionLayer", true);
                        }

                        api.getViewById("2d").changeSettings("showUnderlayLayer", true);
                        api.getViewById("2d").changeSettings("showGridLayer", true);
                        api.getViewById("2d").changeSettings("showGridLayer", true);
                        api.getViewById("2d").changeSettings("showRoomLabel", true);
                        api.getViewById("2d").changeSettings("showTextAnnotation", true);
                    }
                    if ($(this).hasClass("submit")) {
                        getHouseImage(jsonData,true);
                    }
                });
            }
        });
    }
    return optionsDialog;
};


function getHouseImage(jsonData,saveImage,callback) {

    var blob;
    var elem;

    //提交后，锁定房型
    api.floorplanLock(true);
    //开始加载，添加标注--add by gaoning
    api.InitLabels();
    setTimeout(function () {
        //确认时才加载户型图信息--add by gaoning 2017.7.4
        elem = getExportHouseImagePrompt();

        if(saveImage){
            $("body").append($("<div id='maskLayer' " +
                "style='position: absolute;width: 100%;height: 100%;top: 0;    text-align: center;line-height: 500px;" +
                " color: white; left: 0;background: rgba(0,0,0,0.6);z-index: 10000000000000000;'>户型图正在导出中，请稍后...</div>"));
        }

        var outputSize = 5792;
        var times = 5;//放大倍数
        switch ($("#exportHouseImage select").val()) {
            case "1":
                outputSize = 5792;
                times = 5;
                break;
            case "2":
                outputSize = 10000;
                times = 7;
                break;
            default:
                outputSize = 5792;
                times = 5;
                break;
        }
        saveLogToServer([{"key": "action", "value": "exportHouseImage"}]);

        var elemXML = "";
        elemXML += '<div class="wrap" style="width: 1117px; height: 788px;border:3px solid #bcbcbc;position: absolute;left: 50%;top: 50%; transform: scale(' + times + ',' + times + ') translate(-50%,-50%) ;-webkit-transform:  scale(' + times + ',' + times + ') translate(-50%,-50%);-webkit-transform-origin:0 0;">';
        elemXML += new XMLSerializer().serializeToString(elem);

        elemXML += '<div class="information" style="width: 19.9%;height: 100%;float: left;border-left: 1px solid #bcbcbc;">';
        elemXML += '<div class="items logo" style="height: 100px;background: url(http://pic.oceano.com.cn/h5filesystem/export/oceano_logo.png) no-repeat 0 0;background-size: 120px 58px;background-position: 50px 26px;"></div>';
        elemXML += '<div class="items projectName" style="min-height: 80px;line-height: normal;"><p>工程名称</p><p>' + jsonData.Project + '</p></div>';
        elemXML += '<div class="items projectName" style="min-height: 60px;line-height: normal;"><p>图名</p><p>' + jsonData.Title + '</p></div>';
        elemXML += '<div class="items customerName"><span class="tit">客户名称:</span><span>' + jsonData.Client + '</span></div>';
        elemXML += '<div class="items"><span class="tit">客户电话:</span><span>' + jsonData.ClientTel + '</span></div>';
        //elemXML += '<div class="items"><span>服务门店:</span><span>'+jsonData.storeAddress+'</span></div>';
        elemXML += '<div class="items"><span class="tit">家居顾问:</span><span>' + jsonData.Manager + '</span></div>';
        elemXML += '<div class="items"><span class="tit">设计总监:</span><span>' + jsonData.Designer + '</span></div>';
        //elemXML += '<div class="items"><span>联系电话:</span><span>'+jsonData.designerPhone+'</span></div>';
        elemXML += '<div class="items"><span class="tit">门店电话:</span><span>' + jsonData.OfficeTel + '</span></div>';
        elemXML += '<div class="items"><span class="tit">比例:</span><span>' + jsonData.Scale + '</span></div>';
        elemXML += '<div class="items"><span class="tit">图号:</span><span>' + jsonData.DrawingNo + '</span></div>';
        elemXML += '<div class="items"><span class="tit">日期:</span><span>' + jsonData.Date + '</span></div>';
        elemXML += '<div class="items projectName" style="min-height: 80px;line-height: normal;"><p>门店与地址:</p><p>' + jsonData.Address + '</p></div>';
        elemXML += '<div class="items mark" style="min-height: 75px;line-height: normal;"><p>备注</p><p>图纸所标尺寸均为饰面及贴完砖的完成面的尺寸!</p></div>';
        //elemXML += '<div class="items signYourName" style="height: 10%;min-height: 102px;line-height: normal;"><p>客户签字</p></div>';
        elemXML += '<div class="items warnings" style="height: 20%;min-height: 110px;line-height: normal;border-bottom: none"><p>敬告:</p><p>1.本图纸之所有权属本公司所有,未经许可不得翻印</p><p>2.承建商必须实地复核所有尺寸,如现场尺寸和图纸尺寸有出入的请必须与设计师联系</p><p>3.承建商必须按照图施工,如有不明之处应及时与设计师联系,如擅自改动方案与图纸的,后果自负</p></div></div></div>';
        elemXML = '<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\"\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\"><head><style>p{padding: 0;margin: 0;}.items{line-height: 25px;border-bottom: 1px solid #bcbcbc;padding: 0 4px;}.tit{border-right: 1px solid #bcbcbc;display: inline-block;width:36%;margin-right: 5px;}svg{width:80% !important; float: left;}</style></head><body style=\"background:#fff;font-size: 14px;color: #333;position: relative;\">' + elemXML + '</body>';
        var uuid = api.uuid();
        var contentBase64 = api.utilEncryptString(elemXML);
        outputSize = outputSize > 8000 ? 8000 : outputSize;
            
         var svg2jpgServer = api.getServicePrefix("export") + "/postSvgToJpg?"
              + "userLoginId=" + globalUsrObj.globalUserLoginId
              + "&uuid=" + uuid
              + "&width=" + Math.round(outputSize)
              + "&height=" + Math.round(outputSize / 1.414);

          $.ajax({
            url: svg2jpgServer,
            type: "post",
            data: {data: contentBase64},
            dataType: 'binary',
            success: function(result){ 
            	    var blob = result;
                  callback && callback(blob);
                  if(saveImage){
                      var name = "户型图-" + (new Date()).toLocaleString() + ".jpg";
                      var saveLink = document.createElement('a');
                      var downloadSupported = 'download' in saveLink;
                      if (downloadSupported) {
                          saveLink.download = name;
                          saveLink.style.display = 'none';
                          document.body.appendChild(saveLink);
                          try {
                              var url = URL.createObjectURL(blob);
                              saveLink.href = url;
                              saveLink.onclick = function () {
                                  requestAnimationFrame(function () {
                                      URL.revokeObjectURL(url);
                                  })
                              };
                          } catch (e) {
                              console.warn('This browser does not support object URLs. Falling back to string URL.');
                              saveLink.href = uri;
                          }
                          saveLink.click();
                          document.body.removeChild(saveLink);
                      }
                      else {
                          window.open(uri, '_temp', 'menubar=no,toolbar=no,status=no');
                      }
                      $("#maskLayer").remove();
                  }

                  //图片保存后清除标注信息--add by gaoning 2017.7.4
                  api.SetLabelActive();

                  //恢复默认值
                  api.getViewById("2d").changeSettings("showDimensionLayer", true);
                  api.getViewById("2d").changeSettings("showUnderlayLayer", true);
                  api.getViewById("2d").changeSettings("showGridLayer", true);
                  api.getViewById("2d").changeSettings("showGridLayer", true);
                  api.getViewById("2d").changeSettings("showRoomLabel", true);
                  api.getViewById("2d").changeSettings("showTextAnnotation", true);	 
                //}

                var view = api.getViewById("2d");
                view.fit();

                isShowOutRoomLabel = true;
                isShowOutLabel = true;
            },
            error: function (xhr, ajaxOptions, thrownError) {
            	  layer.msg(thrownError);
                $("#maskLayer").remove();
            }
          });

    }, 500);
}

function getHouseImagePromise(callback) {

    getHouseImageValue = true;

    api.getTmallOrderinfo().then(function (data) {
        var jsonData = data;
        getHouseImage(jsonData,false,function(value){
            callback && callback(value);
        });
    });
}


/*2D视图*/
$("#view2DActive").on(click, view2DActiveHandler);

/*3D平视*/
$("#view3DFirstPersonActive").on(click, view3DFirstPersonActiveHandler);

/*3D鸟瞰*/
$("#view3DBirdViewActive").on(click, view3DBirdViewActiveHandler);

$("#viewFullscreen").on(click, view3dFullScreenHandler);
$("#viewOculusVR").on(click, function () {
    if (typeof OculusVRPrompt == "function")OculusVRPrompt();
});
$("#viewWalkThrough3D").on(click, function () {
    if (typeof WalkThroughPrompt == "function")WalkThroughPrompt();
});
/*画墙*/
$("#drawFreeWall").on(click, function (e) {
    api.actionBegin("AddWall", {continuous: !isMobileDevice()});
});
$("#drawRectWall").on(click, function (e) {
    api.actionBegin("AddRectRoom", {continuous: !isMobileDevice()});
});
/*画区域*/
$("#drawInnerFreeArea").on(click, function (e) {
    api.actionBegin("AddFreeArea", "inner");
});
$("#drawInnerRectArea").on(click, function (e) {
    api.actionBegin("AddRectArea", "inner");
});
$("#drawInnerCircleArea").on(click, function (e) {
    api.actionBegin("AddRoundArea", "inner");
});
$("#drawOuterFreeArea").on(click, function (e) {
    api.actionBegin("AddFreeArea", "outer");
});
$("#drawOuterRectArea").on(click, function (e) {
    api.actionBegin("AddRectArea", "outer");
});
$("#drawOuterCircleArea").on(click, function (e) {
    api.actionBegin("AddRoundArea", "outer");
});
/*2d 居中*/
$("#view2dFit").on(click, function () {
    api.viewFit("2d");
    api.viewFit("3d");
});
$("#viewNavigationToolbar").on(click, function () {
    var toolbar = $("#toolbar_navigator");
    toolbar.is(":hidden") ? toolbar.show() : toolbar.hide();
});
$("#viewCatalogTabContainer").on(click, function () {
    $("#mainLayoutId .tab-container").toggle();
    resizePage();
    $("#view2dFit").trigger(click);
});

/*3d 物体操作*/
$("#menubar .menu input[name='transform3d']").parent().on(click, function (e) {
    var inputObj = $(this).children("input");
    inputObj.prop("checked", true);
    api.threeSetTransformMode(inputObj.attr("mode"));
});
$("#menubar .menu div[name='transform3d']").on(click, function (e) {
    var inputObj = $(this);
    api.threeSetTransformMode(inputObj.attr("mode"));
});
$("#importBackImage").on(click, function (e) {
    $("#importUnderlay").trigger(click);
});
$("#exportOBJ").on(click, function (e) {
    var content = api.threeExport("OBJ");
    var filename = "我的设计-" + (new Date()).toLocaleString() + ".obj";
    api.saveAs(new Blob([content], {type: "text/plain;charset=" + document.characterSet}), filename);
});
$("#exportMAX").on(click, function (e) {
    alert("in progress...");
});
$("#exportDXF").on(click, exportDXF);
$("#menuExportJSON").on(click, exportCADJSON);
$("#menuExportCAD").on(click, exportCAD);
$("#menuExportCADForWall").on(click, exportCADForWall);
$("#menuExportDATA").on(click, exportData);
$("#toolLockFloorplan").on(click, function (e) {
    if (api.floorplanIsLocked()) return;
    api.floorplanLock(true);
    // todo notify other view.
});
$("#toolUnLockFloorplan").on(click, function (e) {
    if (!api.floorplanIsLocked()) return;

    layer.confirm('解锁户型后可以修改户型。<br>是否继续解锁户型？', {
        btn: ['确定', '取消'], //按钮
        shade: 0.3, //不显示遮罩
        skin: 'layui-layer-default',
        title: '提示'
    }, function (index) {
        api.floorplanLock(false);
        layer.close(index);
    }, function () {
        //layer.msg('取消', {shift: 6});
    });
    // todo notify other view.
});

$("#menuBom").on(click, function () {
    if (0) {//!api.floorplanIsNormalized()) {
        layer.alert("该户型为非标准户型，请首先在<工具>菜单中将户型标准化后再打开商品清单", {closeBtn: 0, skin: 'layui-layer-default'}, function (idx) {
            layer.close(idx);
            api.actionBegin("AnalyzeNormalized");
            var result = api.actionRun("analyze");
        });
    } else {
        var bomData = api.getBomData();
        var pids = bomData.pids;
        delete bomData.pids;

        var materials = bomData.materials;

        function getMaterialByMaterialId(materialid) {
            var result = {};
            materials.forEach(function (materialobj) {
                if (materialobj.pid === materialid) {
                    result = materialobj;
                    return;
                }
            });
            return result;
        }

        var designMeta = ui.getOpenedDesignMeta();
        var bomUrl = appSettings.designjavadomain + "/goodslist";
        if (designMeta && designMeta.envConfig && designMeta.envConfig == 'local') {
            bomUrl = "http://127.0.0.1:8070/goodslist";
        }
        api.catalogGetProductsMetaPromise(pids).then(function (meta) {
            /*获取拼花模板中用到的材质id信息*/
            var parquetPidMap = new Map();
            var parquetPidArray = [];
            Object.keys(meta).forEach(function (tmppid) {
                var metaobj = meta[tmppid];
                if ('parquet' === metaobj.category) {
                    var extra = metaobj.extra;
                    extra = JSON.parse(extra);
                    var channelsObj = extra.channels;
                    var pMaterials = getMaterialByMaterialId(tmppid);

                    if (pMaterials.userDefined) {

                        var newChannels = pMaterials.userDefined.parquet.channels;
                        Object.keys(newChannels).forEach(function (key) {

                            extra.channels[key]["pid"] = newChannels[key]["pid"];

                        });
                    }
                    Object.keys(channelsObj).forEach(function (key) {
                        var parquetPid = channelsObj[key].pid;
                        if (!parquetPidMap.containsKey(parquetPid)) {
                            parquetPidArray.push(parquetPid);
                        }
                        parquetPidMap.put(parquetPid);
                    });
                }
            });

            api.catalogGetProductsMetaPromise(parquetPidArray).then(function (parquetmeta) {
                bomData.meta = $.extend(true, {}, meta, parquetmeta);
                var formObject = document.createElement('form');
                document.body.appendChild(formObject);
                formObject.setAttribute('method', 'post');
                formObject.target = '_blank';
                formObject.action = bomUrl;
                var inputObject = document.createElement('input');
                inputObject.setAttribute('type', 'hidden');
                inputObject.setAttribute('name', 'bomData');
                inputObject.setAttribute('value', JSON.stringify(bomData));
                formObject.appendChild(inputObject);
                formObject.submit();
            });
        });
    }
});

$("#menuRulerMeasure").on(click, rulerMeasure);

function hideProductDialog() {
    if (typeof showHideProductPanelPrompt == "function")showHideProductPanelPrompt();
}
$(document).on('keydown', null, "h", hideProductDialog);

// render dialog prompt
$(document).on('keydown', null, "F10", renderBtnHandler);
//渲染流程：第一步，点击菜单按钮 弹出渲染控制面板
$("#menuRender").on(click, renderBtnHandler);

$("#menuMaterialDropper").on(click, function (e) {
    api.actionBegin("MaterialDropper");
});
$("#menuHelpGuide").on(click, function (e) {
});
$("#menuHelpHotkey").on(click, function (e) {
    $('#hotkeyTable').dialog("open");
});
$("#menuHelpFeedback").on(click, function (e) {
});
$("#menuHelpAbout").on(click, function (e) {
    var aoubtUsDialogIndex = layer.open({
        type: 1,
        title: '关于',
        skin: 'layui-layer-default',
        fix: false,
        //closeBtn: false,
        shadeClose: false,
        maxmin: false,
        area: ['422px', '280px'],
        content: $('#aboutUs')
    });
});
$("#viewOptions").on(click, function (e) {
    viewOptionsPanelPrompt();
});


/*添加物品*/
$('#menuAddProductPageId').on(click, function () {
    addProductPanelPrompt();
});
$('#menuAddTextAnnotation').on(click, addTextAnnotation);
$('#menuAddPillar').on(click, addPillar);
$('#menuAddBasement').on(click, addBasement);
$('#menuAddBeam').on(click, addBeam);

/*********************************************/
$("#menuAnalyzeNormalizedFloorplan").on(click, function () {
    api.actionBegin("AnalyzeNormalized");
    var result = api.actionRun("analyze");
    var msg = "恭喜您，已经是标准户型";
    if (result.length != 0) {
        var errorCode = result[0].error;// todo
        if (errorCode == 1)msg = "发现非标准化墙体，请分割墙体或移动点";
    }
    layer.msg(msg, {offset: '60px', time: 3500});
});
$("#menuMakeNormalizedFloorplan").on(click, function () {
    api.actionEnd();
    //测试占用
    //一键生成波打线
    log("当前房间生成波打线");

    //if (!api.floorplanIsNormalized()) {
    //    api.floorplanMakeNormalized();
    //}
});

$("#menuLoadOceanoHouseImage").on(click, function () {
    oceanoImportUnderlayChanged();
});

$("#viewOculusVR").on(click, function () {
    if (typeof OculusVRPrompt == "function")OculusVRPrompt();
});
$("#viewWalkThrough3D").on(click, function () {
    if (typeof WalkThroughPrompt == "function")WalkThroughPrompt();
});

$("#viewRenderShow").on(click, function () {
    if (typeof renderImageShowPanelPrompt == "function")renderImageShowPanelPrompt();
});

$("#menuHelpGuide").on(click, function () {
    var currentHostName = document.location.hostname;
    var helpUrl = "http://yun.oceano.com.cn/help/QUICK_START_GUIDE";
    switch (currentHostName) {
        case "yuntest.oceano.com.cn":
            helpUrl = "http://yuntest.oceano.com.cn/help/QUICK_START_GUIDE";
            break;
        case "yunbeta.oceano.com.cn":
            helpUrl = "http://yunbeta.oceano.com.cn/help/QUICK_START_GUIDE";
            break;
        case "yuntmall.oceano.com.cn":
            helpUrl = "http://yuntmall.oceano.com.cn/help/QUICK_START_GUIDE";
            break;
        default:
            helpUrl = "http://yun.oceano.com.cn/help/QUICK_START_GUIDE";
            break;
    }
    window.open(helpUrl);
});
$("#menuAddAutoLight").on(click, function () {
    if (autoLightFilter().length != 0) {
        layer.alert("当前设计中已经有自动打的灯光。<br>如果需要进行灯光重新布置，请首先删除一键布置的灯光，然后重新一键打灯。");
        return;
    }
    autoLightAdd("pa21d30c2d8c540cb94a73bf2ee04ee4d", "pid002", "pid003");
});
$("#menuRemoveAutoLight").on(click, function () {
    autoLightRemove();
});






//# sourceURL=ui\menu\menu_oceano.js
