function onGroup_group() {
    promptNewGroupDialog(function (groupName) {

    });
}
function onGroup_ungroup() {

}
function onGroup_open() {

}
function onGroup_close() {

}
function onGroup_attach() {

}
function onGroup_detach() {

}
function onGroup_explode() {

}

$("#menu_group_group").on(click, onGroup_group);
$("#menu_group_ungroup").on(click, onGroup_ungroup);
$("#menu_group_open").on(click, onGroup_open);
$("#menu_group_close").on(click, onGroup_close);
$("#menu_group_attach").on(click, onGroup_attach);
$("#menu_group_detach").on(click, onGroup_detach);
$("#menu_group_explode").on(click, onGroup_explode);

//# sourceURL=ui\menu\menu_group.js