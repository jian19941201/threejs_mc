//2017.1.13 add by xph
function toolTipBnt(model, pickType, dot, param) {
    this.type = this.type(pickType, model);
    //var p = $("#paper2dsvg").parent().find("svg").find("g[type='"+pickType+"']").find('[did="'+model.id+'"]')
    if (pickType == 'group' || pickType == 'TempGroup') {
        this.obj = $("#paper2dsvg").parent().find("svg").find('[fid="' + model.id + '"]')[0];
    } else if (this.type == 'areaClass') {
        this.obj = $("#paper2dsvg").parent().find("svg").find('[did="' + model.id + '"]').next()[0]
    } else {
        this.obj = $("#paper2dsvg").parent().find("svg").find('[did="' + model.id + '"]')[0]
    }
    this.model = model;
    this.dot = dot;
    if (param) {
        this[this.type] = param;
    }
    this.id = 'ui_toolTipBnt';
    this.init();
}
toolTipBnt.prototype.type = function (type, model) {
    var typeClass = '';
    if (type == 'group' && model.id == 'TempGroup') {
        typeClass = 'TempGroup';
    }
    if (typeClass == '') {
        var typeObj = {
            rectarea: 'area',
            roundarea: 'area',
            freearea: 'area'
        }
        typeClass = typeObj[type] || type;
    }
    return typeClass + "Class";
}
toolTipBnt.prototype.groupClick = function () {
    var T = this;
    T.html.find('div').on('click', function () {
        var classArr = $(this).attr('class').split(' ');
        var classGroupName = '';
        for (var i = 0; i < 3; i++) {
            classArr[i].indexOf('group_') == 0 ? classGroupName = classArr[i] : ''
        }
        if (classGroupName != '') {
            T.update(classGroupName);
        }
    })
}
toolTipBnt.prototype.init = function () {
    try {
        this.info = this.obj.getBoundingClientRect();
        this.conf = this[this.type]();
    } catch (e) {
        return;
    }
    this.destroy();
    this.iconArr = Object.keys(this.conf);
    var left = this.info.left + this.info.width + 5;
    var top = this.info.top - 45;
    top = top > ($('body').height() - 45) ? ($('body').height() - 45) : top;
    top = top < 45 ? 45 : top;
    left = left > ($('body').width() - 45 * this.iconArr.length) ? ($('body').width() - 45 * this.iconArr.length) : left;
    left = left < 45 * this.iconArr.length ? 45 * this.iconArr.length : left;
    this.html = $('<div>', {id: this.id, style: "left:" + left + "px;top:" + top + "px;"})
    this.showView()
    this.hoverTip();
    this.groupClick();
}
toolTipBnt.prototype.hoverTip = function () {
    $("#ui_toolTipBnt .icon").tooltip({
        tooltipClass: this.id,
        position: {
            my: "center top-35",
            at: "center top"
        },
        content: function () {
            return "<div class='tooltip_content'>" + $(this).attr('title') + "<div class='arrow'></div></div>";
        },
        open: function (event, ui) {
            $('#' + ui.tooltip[0].id).css('background', '#febe39')
        }
    });
    $("#ui_toolTipBnt .icon").on('mouseout', function () {
        $(this).removeClass('active')
    }).on('mouseenter', function () {
        $(this).addClass('active')
    })
}
toolTipBnt.prototype.showView = function (type, showState) {
    var T = this, param = this.iconArr;
    this.html.empty();
    for (var i = 0; i < param.length; i++) {
        if (0 == param[i].indexOf('group_')) {
            var conf = this[this.type][param[i]];
            var obj = this.conf[param[i]]
            var flag = obj[Object.keys(obj)[0]].flag || 0;
            if (!conf) {
                this[this.type][param[i]] = {
                    conf: Object.keys(this.conf[param[i]]),
                    showState: flag || 0,
                    nextState: 1
                }
            }
            if (type) {
                this[this.type][param[i]].showState = this[this.type][param[i]].showState == -1 ? 0 : this[this.type][param[i]].showState
            } else {
                this[this.type][param[i]].showState = flag;
            }
            this.html.append($('<div>', {
                class: "icon " + param[i] + " " + this[this.type][param[i]].conf[this[this.type][param[i]].showState],
                click: T.conf[param[i]][T[T.type][param[i]].conf[T[T.type][param[i]].showState]].method,
                title: this.conf[param[i]][this[this.type][param[i]].conf[this[this.type][param[i]].showState]].title || ''
            }))
        } else {
            this.html.append($('<div>', {
                class: "icon " + param[i],
                click: this.conf[param[i]].method,
                title: this.conf[param[i]].title || ''
            }))
        }
    }
    $('body').append(this.html);
}
toolTipBnt.prototype.update = function (type, showState, param) {
    if (!param) {
        param = this[this.type][type]
    }
    if (typeof showState != 'undefined') {
        param.showState = showState;
    } else {
        param.showState += param.nextState;
        param.showState == param.conf.length ? param.showState = 0 : '';
    }

    this.showView(type, showState);
    this.hoverTip();
    this.groupClick();

}
toolTipBnt.prototype.destroy = function () {
    $('#ui_toolTipBnt').remove();
}
toolTipBnt.prototype.hide = function () {
    $('#ui_toolTipBnt').hide();
}
toolTipBnt.prototype.show = function () {
    $('#ui_toolTipBnt').show();
}
toolTipBnt.prototype.cameraClass = function () {
    var T = this;
    return {
        group_lock: {
            lock: {
                title: "锁定",
                method: function () {
                    var activeCamera = api.documentGetActiveCamera();
                    lockAdnUnlockCamera(activeCamera.id, activeCamera, 'unlock')
                }
            },
            unlock: {
                title: "解锁",
                method: function () {
                    var activeCamera = api.documentGetActiveCamera();
                    lockAdnUnlockCamera(activeCamera.id, activeCamera, 'lock')
                }
            }
        },
        hide: {
            title: "隐藏",
            method: function () {
                hideActiveCamera()
                T.destroy();
                popLeftContextMenuClose();
            }
        }
    }
}
toolTipBnt.prototype.wallClass = function () {
    var T = this;
    return {
        group_line: {
            curve: {
                flag: !!T.model.bezier ? 1 : 0,
                title: "曲线",
                method: function () {
                    var wall = T.model;
                    if (!wall) return;

                    api.actionBegin("SetWallBezier", wall);
                    api.actionRun("set", true);
                }
            },
            beeline: {
                title: "直线",
                method: function () {
                    var wall = T.model;
                    if (!wall) return;

                    api.actionBegin("SetWallBezier", wall);
                    api.actionRun("set", false);
                }
            }
        },
        split: {
            title: "拆分",
            method: function () {
                if (api.floorplanIsLocked() == true) {
                    layer.alert('拆分墙需要首先解锁户型', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                        layer.close(index);
                    });
                    return;
                }
                var wall = T.model;
                api.actionBegin("SplitWall", wall);
                api.actionEnd("SplitWall");
            }
        },
        group_wall: {
            basewall: {
                flag: T.model.flag & (1 << 10) ? 1 : 0,
                title: "承重墙",
                method: function () {
                    var wall = T.model;
                    if (!wall) return;
                    api.actionBegin("SetGeneralFlag", wall);
                    api.actionRun("set", 1 << 10, true);
                    api.actionEnd("SetGeneralFlag");
                }
            },
            weightwall: {
                title: "取消承重墙",
                method: function () {
                    var wall = T.model;
                    if (!wall) return;
                    api.actionBegin("SetGeneralFlag", wall);
                    api.actionRun("set", 1 << 10, false);
                    api.actionEnd("SetGeneralFlag");
                }
            }
        },
        group_hide: {
            hide: {
                flag: T.model.flag & 4 ? 1 : 0,
                title: "隐藏",
                method: function () {
                    var wall = T.model;
                    api.actionBegin("SetGeneralFlag", wall);
                    api.actionRun("set", 1 << 2, true);
                    api.actionEnd("SetGeneralFlag");
                }
            },
            show: {
                title: "显示",
                method: function () {
                    var wall = api.pickGetPicked()[0].model;
                    api.actionBegin("SetGeneralFlag", wall);
                    api.actionRun("set", 1 << 2, false);
                    api.actionEnd("SetGeneralFlag");
                }
            }
        },
        delete: {
            title: "删除",
            method: function () {
                if (api.floorplanIsLocked() == true) {
                    layer.alert('删除墙需要首先解锁户型', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                        layer.close(index);
                    });
                    return;
                }
                var wall = T.model;
                api.actionBegin("DeleteWall", wall);
                api.actionEnd("DeleteWall");
                T.destroy();
            }
        }

    }
}
toolTipBnt.prototype.areaClass = function () {
    var T = this;
    return {
        top: {
            title: "置顶",
            method: function () {
                api.actionBegin("SetAreaLevel", T.model);
                api.actionRun("set", true);
                api.actionEnd("SetAreaLevel");
            }
        },
        bottom: {
            title: "置底",
            method: function () {
                api.actionBegin("SetAreaLevel", T.model);
                api.actionRun("set", false);
                api.actionEnd("SetAreaLevel");
            }
        },
        expand: {
            title: "扩展",
            method: function () {
                popLeftContextMenu(T.model, 'expand');
            }
        },
        copy: {
            title: "复制",
            method: function () {
                api.actionBegin("CopyArea", T.model);
                api.actionEnd("CopyArea");
            }
        },
        delete: {
            title: "删除",
            method: function () {
                layer.confirm('确定要删除该区域吗？', {
                    btn: ['确定', '取消'],
                    shade: 0.3,
                    skin: 'layui-layer-default',
                    title: '提示'
                }, function (index) {
                    layer.close(index);
                    closeContextMenu();
                    popLeftContextMenuClose()
                    api.actionBegin("DeleteArea", T.model);
                    api.actionEnd("DeleteArea");
                    T.destroy();
                }, function () {
                });

            }
        }
    }
}
toolTipBnt.prototype.productClass = function () {
    var T = this;
    return {
        copy: {
            title: "复制",
            method: function () {
                api.actionBegin("CopyProduct", T.model);
                api.actionEnd("CopyProduct");
            }
        },
        hide: {
            title: "隐藏",
            method: function () {
                api.actionBegin("SetGeneralFlag", T.model);
                api.actionRun("set", 1 << 2, true);
                api.actionEnd("SetGeneralFlag");
                T.destroy();
                popLeftContextMenuClose();
            }
        },
        delete: {
            title: "删除",
            method: function () {
                layer.confirm('确定要删除该模型吗？', {
                    btn: ['确定', '取消'],
                    shade: 0.3,
                    skin: 'layui-layer-default',
                    title: '提示'
                }, function (index) {
                    api.actionBegin("DeleteProduct", T.model);
                    api.actionEnd("DeleteProduct");
                    layer.close(index);
                    popLeftContextMenuClose()
                    T.destroy();
                });
            }
        }
    }
}
toolTipBnt.prototype.groupClass = function () {
    var T = this;
    return {
        edit: {
            title: "编辑",
            method: function () {
                var group = api.pickGetPicked()[0].model;
                api.actionBegin("SetGeneralFlag", group);
                api.actionRun("set", 1 << 9, true);
                api.actionEnd("SetGeneralFlag");
                popLeftContextMenuClose();
                T.destroy();
            }
        },
        ungroup: {
            title: "解除组合",
            method: function () {
                var group = api.pickGetPicked()[0].model;
                api.actionBegin("ExplodeGroup", group);
                api.actionEnd("ExplodeGroup");
                popLeftContextMenuClose();
                T.destroy();
            }
        },
        copy: {
            title: "复制",
            method: function () {
                var group = api.pickGetPicked()[0].model;
                api.actionBegin("CopyGroup", group);
                api.actionEnd("CopyGroup");
            }
        },
        delete: {
            title: "删除",
            method: function () {
                layer.confirm('确定要删除该组合吗？', {
                    btn: ['确定', '取消'],
                    shade: 0.3,
                    skin: 'layui-layer-default',
                    title: '提示'
                }, function (index) {
                    var group = api.pickGetPicked()[0].model;
                    var rv = api.actionBegin("DeleteGroup", group);
                    api.actionEnd("DeleteGroup");
                    layer.close(index);
                    popLeftContextMenuClose();
                    T.destroy();
                });
            }
        }
    }
}
toolTipBnt.prototype.TempGroupClass = function () {
    var T = this;
    return {
        makegroup: {
            title: "生成组合",
            method: function () {
                var groupCount = api.floorplanFilterEntity(function (e) {
                    return e.type == "GROUP";
                }).length;
                var group = api.actionBegin("MakeGroup");
                api.actionRun("fromTempGroup");
                api.actionEnd("MakeGroup");
                group.name = "我的组合-" + (groupCount <= 10 ? "0" : "") + groupCount;
                popLeftContextMenuClose();
                T.destroy();
            }
        },
        copy: {
            title: "复制",
            method: function () {
                var model = api.pickGetPicked()[0].model;
                var group = model.group ? model.group : model;
                api.actionBegin("CopyGroup", group);
                api.actionEnd("CopyGroup");
            }
        },
        delete: {
            title: "删除",
            method: function () {
                layer.confirm('确定要删除该组合吗？', {
                    btn: ['确定', '取消'],
                    shade: 0.3,
                    skin: 'layui-layer-default',
                    title: '提示'
                }, function (index) {
                    var model = api.pickGetPicked()[0].model;
                    var group = model.group ? model.group : model;
                    var rv = api.actionBegin("DeleteGroup", group);
                    api.actionEnd("DeleteGroup");
                    layer.close(index);
                    popLeftContextMenuClose();
                    T.destroy();
                });
            }
        }
    }
}
toolTipBnt.prototype.basementBeamPillarClass = function () {
    var T = this;
    return {
        hide: {
            title: "隐藏",
            method: function () {
                api.actionBegin("SetGeneralFlag", T.model);
                api.actionRun("set", 1 << 2, true);
                api.actionEnd("SetGeneralFlag");
                T.destroy();
                popLeftContextMenuClose();
            }
        },
        delete: {
            title: "删除",
            method: function () {
                layer.confirm('确定要删除该模型吗？', {
                    btn: ['确定', '取消'],
                    shade: 0.3,
                    skin: 'layui-layer-default',
                    title: '提示'
                }, function (index) {
                    api.actionBegin("DeleteProduct", T.model);
                    api.actionEnd("DeleteProduct");
                    layer.close(index);
                    popLeftContextMenuClose()
                    T.destroy();
                });
            }
        }
    }
}
//# sourceURL=ui/toolTipBnt/toolTipBnt.js


