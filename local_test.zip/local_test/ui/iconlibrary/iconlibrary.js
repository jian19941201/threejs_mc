function initSVG() {
    var svgMask = $("#svg-template .svg-mask:first") ;
    $("div[inline-svg-id]:empty")
        .append(function () {
            var iid = $(this).attr("inline-svg-id");
            var vbox = document.getElementById(iid).parentElement.getAttribute("viewBox");
            var svg = $("<div>").append($("<svg>").attr({"viewBox": vbox})
                    .append($("#" + iid).clone(false).removeAttr("id"))
                    .append(svgMask.clone())
            );
            return $(svg).html();
        });

    $(".svg-mask").attr({opacity: 0})
        .on("mouseover", function () {
            $(this).siblings().attr({fill: '#ff590b'})
        }).on("mouseout", function () {
            $(this).siblings().attr({fill: '#0'});
        });

}
initSVG();


//#sourceURL=ui\iconlibrary\iconlibrary.js