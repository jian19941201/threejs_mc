var PARQUET_Template = undefined;
var ParquetSelectorPopup = function () {

};
//# sourceURL=ui\parquet/parquet_select.js