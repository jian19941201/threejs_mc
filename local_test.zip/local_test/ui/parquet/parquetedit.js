var PARQUET_EDIT_MODE = false;
$(".parquet_edit").dialog({
    minWidth: 300, minHeight: 200,
    autoOpen: false,
    resizable: false,
    width: 450,
    height: 500
}).on("dialogclose", function (event, ui) {
    PARQUET_EDIT_MODE = false;
    parquet_current_edit = undefined;
}).on("dialogopen", function (event, ui) {
    PARQUET_EDIT_MODE = true;
});

var parquet_current_edit = undefined;

var initParquetEditData = function (mat) {
    parquet_current_edit = mat;
    $(".parquet_edit .selector_container .block_show").remove();

    var pid = mat.pid;
    var data = JSON.parse(mat.meta.extra);
    if (mat.userDefined && mat.userDefined.parquet)data = $.extend(true, data, mat.userDefined.parquet);

    var channels = data.channels;
    var channelsId = Object.keys(channels);
    for (var i = 0; i < channelsId.length; ++i) {
        var channelId = channelsId[i];
        var channel = channels[channelId];
        var newBlock = $(".parquet_edit .selector_container .block_hide").clone(true)
            .removeClass("block_hide").addClass("block_show")
            .attr("channel_id", channelId)
            .appendTo(".parquet_edit .selector_container");
        if (i == 0)newBlock.addClass("block_pick");

        // child style:
        newBlock.find(".color_indicator").css("background-color", colorDecimalToHex(channel.color));
        var url = channel.pid == "none" ? "" : api.catalogGetFileUrl("product", channel.pid, "top");
        newBlock.find(".tileImgImg").attr({"src": url, "pid": channel.pid});
        var rot = channel.rot || 0;
        newBlock.find(".rotSelect").val(rot);
    }

    // right panel:
    var url = api.catalogGetFileUrl("product", pid, "top");
    $(".parquet_edit .show_img_div .srcImgImg").attr({"src": url, "pid": pid});
    $(".parquet_edit .show_img_div .previewImgImg").attr("src", mat.getUrl());
};

function ParquetGetModelFromUI() {
    var model = {channels: {}};
    var channels = model.channels;
    $(".parquet_edit .selector_container .block_show").each(function () {
        var channelUI = $(this);
        var cid = channelUI.attr("channel_id");
        var pid = channelUI.find(".tileImgImg").attr("pid");
        var rot = parseInt(channelUI.find(".rotSelect").val());
        var channel = channels[cid] = {pid: pid, rot: rot};
    });
    return model;
}
//--------------------------------------------
// UI handler:
//
var ParquetEditorPopup = function (mat) {
    $(".parquet_edit").dialog("open");
    initParquetEditData(mat);
    $("div[aria-describedby='parquet_edit']").css("z-index", 501);
};
$(".parquet_edit .selector_block").on(click, function (e) {
    $(".parquet_edit .selector_container .selector_block").removeClass("block_pick");
    $(e.target).closest(".selector_block").addClass("block_pick");
});
$(".parquet_edit .clear_href").on(click, function (e) {
    $(e.target).closest(".selector_block").find(".tileImgImg").attr({src: "", pid: "none"});
});
function ParquetEditor_CatalogImageClick(pid) {
    var pickBlock = $(".parquet_edit .selector_container .block_pick");
    var url = api.catalogGetFileUrl("product", pid, "top");
    pickBlock.find(".tileImgImg").attr({src: url, pid: pid});
}

// ----------------------------------------
// buttons:
//
$(".parquet_edit .previewBtn").on(click, function (e) {
    var model = ParquetGetModelFromUI();
    var url = parquet_current_edit.getUrl(1024, model);
    $(".parquet_edit .show_img_div .previewImgImg").attr("src", url);
});
$(".parquet_edit .applyBtn").on(click, function (e) {
    var model = ParquetGetModelFromUI();
    parquet_current_edit.update(model);
});
$(".parquet_edit .closeBtn").on(click, function (e) {
    $(".parquet_edit").dialog("close");
});


//# sourceURL=ui\parquet/parquet_edit.js