$(window).bind('resize', function () {
    api.viewFit("3d");
});

$('#threedViewId').appendTo($('#viewcontent'));
$('#threedViewId').tooltip();
$('#threedViewId .browse').click(function () {
    $(this).parent().fadeOut();
    $('#threedViewId .close').fadeIn();
    $('#paper3d').fadeOut();
});

$('#threedViewId .resize').mousedown(function (event) {
    var currentPageX = event.pageX;
    var currentPagey = event.pageY;
    var titleWidth = $(this).parent().width();
    var paper3dWidth = $("#paper3d").width();
    var paper3dHeight = $("#paper3d").height();

    $(document).on("mousemove", function (e) {
        var changeX = e.pageX - currentPageX;
        var changey = e.pageY - currentPagey;
        var titleW=titleWidth - changeX;
        var paper3dW=paper3dWidth - changeX;
        var paper3dH=paper3dHeight - changey;
        if((titleW)>$(window).width()-5)titleW=paper3dW=$(window).width()-5;
        if((paper3dH)>$(window).height()-37)paper3dH=$(window).height()-37;
        $(this).parent().width(titleW);
        $("#paper3d").width(paper3dW);
        $("#paper3d").height(paper3dH);
    });
});

$('#threedViewId .resize').mouseup(function () {
    if ($.contains($("#paper3d")[0], $("#paper3dwebgl")[0])) api.viewFit("3d");
    if ($.contains($("#paper3d")[0], $("#paper2dsvg")[0]))api.viewFit("2d");
});

$(document).mouseup(function () {
    $(document).off("mousemove");
});


$('#threedViewId .close').click(function () {
    $(this).fadeOut();
    $('#threedViewId .open').fadeIn();
    $('#paper3d').fadeIn(function () {
        api.viewFit("3d");
    });
});

/*
 * 视图浏览内置小窗口初始尺寸：200x200(像素)
 * 视图浏览外置dialog窗口初始尺寸:275x230(像素)
 * 它们的宽高差值为【75】和【30】像素
 * 当dialog窗口改变结束后，动态的修改内置小窗口尺寸
 * */
/*$('#threedViewId').dialog({
 dialogClass: "threedViewWindow",
 minWidth: 230,
 minHeight: 280,
 width: 230,
 height: 275
 }).on("dialogresize", function (event, ui) {
 $("#paper3d").css("width", ui.size.width - 30);
 $("#paper3d").css("height", ui.size.height - 75);
 });*/
/*dialog的position属性设置不起效，只能设置样式了*/
/*var classobj = {"z-index": 999, "top": $(window).height() - 275, "left": $(window).width() - 230};
 $("div[aria-describedby='threedViewId']").css(classobj);*/

//# sourceURL=ui\editor3d\editor3d.js