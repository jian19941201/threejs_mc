api.application_ready_event.add(function (setting) {
    function catalogGetFileUrl_oceano(category, id, type) {
        var typeMap = {
            iso: 'thumb.jpg',
            thumb: 'thumb.jpg',
            top: 'top.png',
            texture: 'product.png',
            render: "output.jpg"
        };
        var prefixMap = {
            product: setting.imgcdndomain + '/h5filesystem/products/',
            render: setting.imgcdndomain + '/h5filesystem/render/'
        };
        var url = prefixMap[category] + id + "/" + typeMap[type];
        return url;
    }

    window.ui.catalogGetFileUrl = catalogGetFileUrl_oceano.bind(undefined);
    api.laberFrameEntry(laberFrame);
    api.showCustomModelProgress(CustomModelProgress);
    api.allCameraInit2D(allCameraInit);
});


//# sourceURL=ui\api\api_oceano.js