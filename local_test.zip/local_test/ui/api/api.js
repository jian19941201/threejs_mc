var catalog_init_complete_event = new signals.Signal();
window.ui = {
    // design:
    openDesign: openDesign.bind(undefined),
    openDesignByExtra: openDesignByExtra.bind(undefined),
    setOpenedDesignMeta: setOpenedDesignMeta.bind(undefined),
    getOpenedDesignMeta: getOpenedDesignMeta.bind(undefined),

    //user:
    userLogin: userLogin.bind(undefined),
    userLogout: userLogout.bind(undefined),
    getCurrentUserData: getCurrentUserData.bind(undefined),

    catalog_init_complete_event: catalog_init_complete_event,
    catalogGetFileUrl: catalogGetFileUrl.bind(undefined)
};

function catalogGetFileUrl(category, id, type) {
    return api.catalogGetFileUrl(category,id,type);
}

//# sourceURL=ui\api\api.js