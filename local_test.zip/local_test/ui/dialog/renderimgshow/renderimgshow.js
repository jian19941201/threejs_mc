$("#renderImageShowPanel").dialog({
    minWidth: 300, minHeight: 200,
    autoOpen: false,
    resizable: false,
    width: Math.round($(window).width() * 3 / 4),
    height: Math.round($(window).height() * 3 / 4)
}).on("dialogclose", function (event, ui) {
}).on("dialogopen", function (event, ui) {
    initImageShowPanelData();
});

var renderImageShowPanel_currentShowIndex = 0;
//renderview_jobidArray = ["idB71B485C3887452A3AB0CFF851B6C7", "id280B9F7506E8DBEF79760F07DB9279", "idA6605C86B6B795A77A083AD6A657EE", "id956EBE642AE69082B99F1018C93FF2"];

function initImageShowPanelData() {
    var renderViewJobArray = renderview_jobidArray || [];
    $("#renderImageShowPanel .footer .total").html(renderViewJobArray.length);
    $("#renderImageShowPanel .footer .current").html(renderViewJobArray.length == 0 ? 0 : 1);
    if (renderViewJobArray.length == 0) {
        $("#renderImageShowPanel .body .img").removeAttr("src");
        return;
    }
    renderImageShowPanel_currentShowIndex = 0;
    ImageShowPanel_showImage();
}
var ImageShowPanel_showImage = (function () {
    var maxHeight, maxWidth;
    var img = new Image();
    img.onload = function (e) {
        var target = e.target;
        var width = target.width, height = target.height;
        var acturalWidth = maxWidth, actualHeight = maxHeight;
        if (width / height < maxWidth / maxHeight) {
            acturalWidth = width / height * maxHeight;
        } else {
            actualHeight = height / width * maxWidth;
        }
        $("#renderImageShowPanel .body .img").attr({
            src: target.src,
            width: acturalWidth + 'px',
            height: actualHeight + "px"
        });
        $("#renderImageShowPanel .body .img-container").css({
            width: acturalWidth,
            height: actualHeight
        });

    };
    return function () {
        var currentJobid = renderview_jobidArray[renderImageShowPanel_currentShowIndex];
        var url = api.catalogGetFileUrl("render", currentJobid, "render");
        //api.getServicePrefix("file") + "/getFile?category=render&type=render&id=" + currentJobid;
        maxHeight = $("#renderImageShowPanel .body").height();
        maxWidth = $("#renderImageShowPanel .body").width();
        img.src = url;
    };
})();

function renderImageShowPanelPrompt() {
    $("#renderImageShowPanel").dialog("open");
    $("div[aria-describedby='renderImageShowPanel']").css("z-index", 500);
}

$("#renderImageShowPanel .footer .previous").on(click, function () {
    renderImageShowPanel_currentShowIndex = Math.max(0, renderImageShowPanel_currentShowIndex - 1);
    $("#renderImageShowPanel .footer .current").html(renderImageShowPanel_currentShowIndex + 1);
    ImageShowPanel_showImage();
});
$("#renderImageShowPanel .footer .next").on(click, function () {
    renderImageShowPanel_currentShowIndex = Math.min(renderview_jobidArray.length, renderImageShowPanel_currentShowIndex + 1);
    $("#renderImageShowPanel .footer .current").html(Math.min(renderview_jobidArray.length, renderImageShowPanel_currentShowIndex + 1));
    ImageShowPanel_showImage();
});

//# sourceURL=ui\renderimgshow\renderimgshow.js