//var advancedPaintWall = undefined;// this will be initialed when this dialog opened..
//var advacedPaintWallOption = undefined;// this will be initialed when this dialog opened..
//var advacedPaintView = undefined;// this will be initialed when application startup.
//
//    advancedPaintPrompt({model: db[wallid], opt: {src: "3d", elementName: "left"}});

/*******************************************************************/

function ViewSVGExport(view2d, view3d) {
    // needed for creation:
    this.domElement = undefined;
    this.context = undefined;
    this.doc = undefined;

    this.layers = {};
    this.layerOrder = [           
        "WALL",
        "WALLDIM",
        "BOARD",
        "AREA",
        "AREADIM",
        "FLOOR"
    ];

    // view related data:
    this.wall3dData = undefined; //{ f: f, v: v, vn: vn, vt: vt, b3d: boundProfile, h3d: holesPos,h2d: holeProfiles, b2d: boundUVWProfile, hmodel: holesModel};
    this.wallBound = undefined; //{max: {x: -100, y: -100}, min: {x: 100, y: 100}};
    this.sortedViewAreas = [];
    this.pickedViewArea = undefined;
    var self = this;
    /************************* METHODS ********************************/

    this.create = function () {
        view2d.init.call(this);
    };

    this.show = function () {
        // step 0: init datas:
        this.doc = view2d.doc;
        this.wallBound = {max: {x: -100, y: -100}, min: {x: 100, y: 100}};

        // step1: clear all existing layers:
        for (var i = 0; i < this.layerOrder.length; ++i) {
            this.layers[this.layerOrder[i]].clear();
        }
        this.sortedViewAreas = [];

        // step2: 绘制墙面铺贴
        var wallOffset = {x:0,y:0};
        var wallModels = api.getWallInsideLoopFromProfile(advancedPaintExportWallFloor);
        var wallWidthMax = 0;
        var wallColumnNum = 4;
		var wallIndex = 0;  // 记录处理到第几面墙
        wallModels.forEach(function(wallInfo, index){
        	var wallModel = wallInfo[0];
        	var wallInsidePoint = wallInfo[1];
	        var side = wallInfo[2];//advacedPaintExportWallOption.elementName;
	        var wall3d = view3d.dl[wallModel.id].de;
	        var wallSideMesh = undefined;
	        var wallSideMaterial = wallModel[side + "Material"];
	        var wallWidth = 0;
	        
	        wallWidth = api.utilModelWallGetSideLength(wallModel, side);
	        if(wallWidth > 0){
              wall3d.traverse(function (child) {
			            if (child.name == (side) && (child.type == "Mesh")) {
			                wallSideMesh = child;
			            }
			        });
			        if (wallSideMesh)
			            this.wall3dData = wallSideMesh._rawData;
			        var wallBoundProfile = [];
			        this.wall3dData.b2d.forEach(function(p){
			        	wallBoundProfile.push({x:p.x + wallOffset.x, y:p.y + wallOffset.y});	        	
			        });
			        //wallWidth = this.wall3dData.b2d[1].x;
			        
			        //for(var i=1;i<wallSideMesh._rawDatas.length;++i){
			        //	wallBoundProfile[1].x += wallSideMesh._rawDatas[i].b2d[1].x + wallOffset.x;
			        //	wallBoundProfile[2].x += wallSideMesh._rawDatas[i].b2d[2].x + wallOffset.x;
			        	//wallWidth += wallSideMesh._rawDatas[i].b2d[1].x;
			        //}			        
			        wallBoundProfile[1].x = wallWidth + wallOffset.x;
			        wallBoundProfile[2].x = wallWidth + wallOffset.x;
			            
			        var path = "";
			        for (var i = 0, len = wallBoundProfile.length; i < len; ++i) {
			            var pt = wallBoundProfile[i];
			            path += (i == 0 ? "M" : "L") + toFixedNumber(pt.x * 100, 2) + "," + toFixedNumber(-pt.y * 100, 2);
			            this.wallBound.max.x = Math.max(this.wallBound.max.x, pt.x);
			            this.wallBound.max.y = Math.max(this.wallBound.max.y, pt.y);
			            this.wallBound.min.x = Math.min(this.wallBound.min.x, pt.x);
			            this.wallBound.min.y = Math.min(this.wallBound.min.y, pt.y);
			        }
			        path += "Z";
			
			        // step3: create wall:
			        var wallSideColor = (wallSideMaterial && wallSideMaterial.type == "MATERIALRAWCOLOR") ? "#" + wallSideMaterial.getColor().getHexString() : "darkgrey";
			        var wall = this.context.path(path).attr({
			            fill: wallSideColor,
			            stroke: 'darkblue',
			            'stroke-width': 0,
			            'stroke-opacity': 1,
			            'stroke-linejoin': 'round',
			            'opacity': 1
			        }).click(function () {
			            self.unpickAll();
			        });
			        this.layers["WALL"].add(wall);
			
			        // openings:
			        var holeProfiles = api.utilModelWallGetSmoothHoleprofiles(wallModel, side);//this.wall3dData.h2d;
			        holeProfiles.forEach(function (holeProfile) {
			            var path = '';
			            for (var i = 0, len = holeProfile.length; i < len; ++i) {
			                var pt = holeProfile[i];
			                path += (i == 0 ? "M" : "L") + toFixedNumber((pt.x + wallOffset.x) * 100, 2) + "," + toFixedNumber(-(pt.y + wallOffset.y) * 100, 2);
			            }
			            path += "Z";
			            var hole = this.context.path(path).attr({
			                fill: "lightgrey",
			                stroke: 'darkblue',
			                'stroke-width': 1, 
			                'stroke-opacity': 1,
			                'stroke-linejoin': 'round',
			                'stroke-dasharray': "8,6",
			                'opacity': 1
			            });
			            this.layers["WALL"].add(hole);
			        }, this);
			
			        //wall dimension:
			        var dimTextWidth = this.context.text().attr({  //标尺字体
		              stroke: "none",
		              "font-size": 20,
		              fill: "#5f5f5f",
		              "font-family": "Calibri,Arial,Helvetica,sans-serif",
		              "text-anchor": "middle"
		          }), dimLineWidth = this.context.path().attr({  //标尺
		              fill: "none",
		              stroke: "#5f5f5f",
		              "stroke-width": 1
		          });
		          var dimTextHeight = this.context.text().attr({  //标尺字体
		              stroke: "none",
		              "font-size": 20,
		              fill: "#5f5f5f",
		              "font-family": "Calibri,Arial,Helvetica,sans-serif",
		              "text-anchor": "middle"
		          }), dimLineHeight = this.context.path().attr({  //标尺
		              fill: "none",
		              stroke: "#5f5f5f",
		              "stroke-width": 1
		          }), dimTextLabel= context.text().attr({  //墙体标注              
		              "font-size": 40,
		              fill: "#5f5f5f",
		              "font-family": "Calibri,Arial,Helvetica,sans-serif",
		              "text-anchor": "middle"
		          });
		          this.layers["WALL"].add([dimTextWidth,dimLineWidth,dimTextHeight,dimLineHeight,dimTextLabel]);
		          var cx = function (coord) {
		              return Math.ceil(100 * coord);
		          };
		          var cy = function (coord) {
		              return Math.ceil(-100 * coord);
		          };
		          var widthDimBegin = {x:wallOffset.x, y:wallOffset.y - 0.25};
		          var widthDimEnd = {x:wallOffset.x + wallWidth, y:wallOffset.y - 0.25};
		          var widthDimMiddle = {x:wallOffset.x + wallWidth/2.0, y:wallOffset.y - 0.25};
		          var linePath = "M" + cx(widthDimBegin.x) + "," + cy(widthDimBegin.y) + "L" + cx(widthDimEnd.x) + "," + cy(widthDimEnd.y) + "M" + cx(widthDimBegin.x) + "," + cy(widthDimBegin.y + 0.10) + "L" + cx(widthDimBegin.x) + "," + cy(widthDimBegin.y - 0.10) + "M" + cx(widthDimEnd.x) + "," + cy(widthDimEnd.y + 0.10) + "L" + cx(widthDimEnd.x) + "," + cy(widthDimEnd.y - 0.10);
		          var length = Math.round(1e3 * api.utilMathLineLength(widthDimBegin, widthDimEnd));
		          dimLineWidth.attr({
		              path: linePath
		          }), dimTextWidth.attr({
		              x: 100 * widthDimMiddle.x,
		              y: -100 * widthDimMiddle.y,
		              text: length
		          });
		          var heightDimBegin = {x:wallOffset.x - 0.25, y:wallOffset.y };
		          var heightDimEnd = {x:wallOffset.x - 0.25, y:wallOffset.y + wallModel.height3d };
		          var heightDimMiddle = {x:wallOffset.x - 0.25, y:wallOffset.y + wallModel.height3d/2.0 };
		          var linePath = "M" + cx(heightDimBegin.x) + "," + cy(heightDimBegin.y) + "L" + cx(heightDimEnd.x) + "," + cy(heightDimEnd.y) + "M" + cx(heightDimBegin.x + 0.10) + "," + cy(heightDimBegin.y) + "L" + cx(heightDimBegin.x - 0.10) + "," + cy(heightDimBegin.y) + "M" + cx(heightDimEnd.x + 0.10) + "," + cy(heightDimEnd.y ) + "L" + cx(heightDimEnd.x - 0.10) + "," + cy(heightDimEnd.y);
		          var length = Math.round(1e3 * api.utilMathLineLength(heightDimBegin, heightDimEnd));
		          dimLineHeight.attr({
		              path: linePath
		          }), dimTextHeight.attr({
		              x: 100 * heightDimMiddle.x,
		              y: -100 * heightDimMiddle.y,
		              text: length
		          }), dimTextLabel.attr({
		              x: 100 * (heightDimMiddle.x + wallWidth + 0.5),
		              y: -100 * heightDimMiddle.y,
		              text: String.fromCharCode(65 + Number(wallIndex))
		          });
		            
			        // area
			        var boards = api.floorplanGetBoardsByWall(wallModel, side);
			        boards.forEach(function(board){
			        	  var viewBoard = createViewBoardFromModelBoard(board, wallOffset);
			        	  //updateViewBoardFromModelBoard(viewBoard);
			        });
			        
			        var sortedModelAreas = api.floorplanGetAreasByHostId(undefined, wallModel.id, side);
			        sortedModelAreas.forEach(function(area){
			        	  var viewArea = createViewBoardFromModelBoard(area, wallOffset);
			        });        
			        //for (var i = 0, len = sortedModelAreas.length; i < len; ++i) {
			        //    var viewArea = createViewAreaFromModelArea(sortedModelAreas[i]);
			        //    this.sortedViewAreas.push(viewArea);
			        //    updateViewAreaFromModelArea(viewArea);
			        //}
			        // area dimensions:
			        
			        wallOffset.y += (wallModel.height3d + 1);
			        
			        wallColumnNum--;
			        if(wallColumnNum == 0){
			        	wallOffset.x += wallWidthMax + 2;
			        	wallOffset.y = 0;
			        	wallWidthMax = 0;
			        	wallColumnNum = 4;
			        }else{
			        	wallWidthMax = Math.max(wallWidthMax, wallWidth);
			        }

				wallIndex ++;

	        }//if(width >0)



        }.bind(this));
        
        //step3: 绘制地面铺贴
        var minXmaxY = createViewFloorFromModelFloor(advancedPaintExportWallFloor, wallModels, {x:0,y:0});        
        this.wallBound.min.x = minXmaxY[0];
        this.wallBound.max.y = Math.max(this.wallBound.max.y, minXmaxY[1]);
        advacedPaintExportBoundbox = this.wallBound;
    };
    this.update = function () {

    };
    this.zoom = function (delta, mouseX, mouseY) {
        view2d.zoom.call(this, delta, mouseX, mouseY);
    };
    this.zoomWithFactor = function (delta, mouseX, mouseY) {
        view2d.zoomWithFactor.call(this, delta, mouseX, mouseY);
    };
    this.pan = function (delta_x, delta_y) {
        view2d.pan.call(this, delta_x, delta_y);
    };
    this.fit = function () {
        if (!this.wallBound) return;
        var bound = {
            left: this.wallBound.min.x + 3,
            top: this.wallBound.min.y,
            width: this.wallBound.max.x - this.wallBound.min.x - 6,
            height: this.wallBound.max.y - this.wallBound.min.y - 1
        };
        view2d.fit.call(this, bound);
    };
    this.getBoundingClientRect = function () {
        return view2d.getBoundingClientRect.call(this);
    };
    /**************************  PICK and Operation  *********************************************/
    this.pick = function (areaView) {
        this.pickedViewArea = areaView;
        areaView.pick(true);
    };
    this.unpickAll = function () {
        this.pickedViewArea = undefined;
        this.sortedViewAreas.forEach(function (areaView) {
            areaView.pick(false);
        });
    };
    this.removeArea = function (areaView) {
        var removed = areaView || this.pickedViewArea;
        if (!removed) return;

        // delete model first:
        var action = "DeleteArea";
        var modelArea = api.actionBegin(action, removed.model);
        api.actionEnd(action);

        // delete in UI.
        removed.remove();
        this.pickedViewArea = undefined;

        // change views:
        var idx = this.sortedViewAreas.indexOf(removed);
        if (idx != -1) {
            this.sortedViewAreas.splice(idx, 1);
        }

        // change model:
        for (var i = 0, len = this.sortedViewAreas.length; i < len; ++i) {
            var viewArea = this.sortedViewAreas[i];
            viewArea.model.level = i;
        }
    };
    this.setOrder = function (areaView, order) {
        var ordered = areaView || this.pickedViewArea;
        if (!ordered) return;

        var idx = this.sortedViewAreas.indexOf(ordered);
        if (idx != -1) {
            this.sortedViewAreas.splice(idx, 1);
        }
        if (order == "bottom") this.sortedViewAreas.unshift(ordered);
        else this.sortedViewAreas.push(ordered);

        api.actionBegin("SetAreaLevel", ordered.model);
        api.actionRun("set", order != "bottom");
        api.actionEnd("SetAreaLevel");

        for (var i = 0, len = this.sortedViewAreas.length; i < len; ++i) {
            var viewArea = this.sortedViewAreas[i];
            //viewArea.model.level = i;
            var areaLayer = this.layers["AREA"];
            areaLayer.add(viewArea.groupContainer);
        }
    };
    this.changeMaterial = function (tileId) {
        var picked = this.pickedViewArea;
        if (!picked) return;


        var action = "SetMat";
        var modelArea = api.actionBegin(action, picked.model, "area", tileId);
        api.actionEnd(action);

    };

    /**********************  COORDINATE SYSTEM  ***************************/
    this.pointScreenToModel = function (screen_x, screen_y) {
        return view2d.PS2M(this, screen_x, screen_y);
    };
    this.vectorScreenToModel = function (screen_x, screen_y) {
        return view2d.VS2M(this, screen_x, screen_y);
    };
    this.pointModelToScreen = function (model_x, model_y) {
        return view2d.PM2S(this, model_x, model_y);
    };
    
    this.resetFontSize = function(){
    	//...
    };
}

api.application_ready_event.add(function () {
    var view2d = api.getViewById("2d");
    var view3d = api.getViewById("3d");
    var apview = advacedPaintExportView = new ViewSVGExport(view2d, view3d);
    apview.domElement = document.getElementById("svgAdvancedPaintExport");
    apview.context = Snap(apview.domElement);
    apview.create();
});


/****************************  FUNCTIONS  *****************************************/


//# sourceURL=ui\dialog/advancedpaintexport_svgview.js