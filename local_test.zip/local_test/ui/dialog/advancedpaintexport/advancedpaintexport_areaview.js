//var advancedPaintWall = undefined;// this will be initialed when this dialog opened..
//var advacedPaintWallOption = undefined;// this will be initialed when this dialog opened..
//var advacedPaintExportView = undefined;// this will be initialed when application startup.
//
//    advancedPaintPrompt({model: db[wallid], opt: {src: "3d", elementName: "left"}});

/*******************************************************************/
function createViewBoardFromModelBoard(model,offset) {
    return api.utilAreaCreateSnapStylesExport({model: model, offset:offset}, advacedPaintExportView);    
}

//# sourceURL=ui\dialog/advancedpaintexport_areaview.js