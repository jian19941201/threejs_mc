/*******************************************************************/

function createViewFloorFromModelFloor(model, wallModels, offset) {
    return api.utilFloorCreateSnapStylesExport({model: model, walls:wallModels, offset:offset}, advacedPaintExportView);
}


//# sourceURL=ui\dialog/advancedpaintexport_floorview.js