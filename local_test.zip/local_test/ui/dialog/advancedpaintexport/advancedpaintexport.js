var advancedPaintExportWallFloor = undefined;// this will be initialed when this dialog opened..
var advacedPaintExportWallOption = undefined;// this will be initialed when this dialog opened..
var advacedPaintExportView = undefined;// this will be initialed when application startup.
var advacedPaintExportBoundbox = undefined;

function advancedPaintExportViewOpened() {
    advacedPaintExportView.show();
}
function advancedPaintExportViewResized() {
    var dialogWidth = $("#advancedpaintexport_dialog").outerWidth(true);
    var dialogHeight = $("#advancedpaintexport_dialog").outerHeight(true);

    var dialogPopupWidth = dialogWidth - 30;
    var dialogPopupHeight = dialogHeight - 10;
    $("#advancedpaintexport_dialog .popup").outerWidth(dialogPopupWidth);
    $("#advancedpaintexport_dialog .popup").outerHeight(dialogPopupHeight);

    var operatorWidth = $("#advancedpaintexport_dialog .operator").outerWidth(true);
    var operatorHeight = $("#advancedpaintexport_dialog .operator").outerHeight(true);

    $("#advancedpaintexport_dialog .main-pannel").width(dialogPopupWidth - operatorWidth - 10);
    $("#advancedpaintexport_dialog .main-pannel").height(dialogPopupHeight - 15);

    advacedPaintExportView.fit();
}

//加载立面显示对话框
function advancedPaintExportPrompt(floorModel, show) {
    advancedPaintExportWallFloor = floorModel;

    $("#advancedpaintexport_dialog").dialog("open");
    if(show){
      $("div[aria-describedby='advancedpaintexport_dialog']").css("z-index", 500);
    }else{
    	$("div[aria-describedby='advancedpaintexport_dialog']").css("z-index", 500).hide();
    }
}

// step 2: open dialog:
$("#advancedpaintexport_dialog").dialog({minWidth: 400, width: 530, minHeight: 380, height: 400, autoOpen: false})
.on("dialogclose", function (event, ui) {
    advacedPaintExportWallOption = undefined;
    advancedPaintExportWallFloor = undefined;
}).on("dialogopen", function (event, ui) {
    advancedPaintExportViewOpened();
    advancedPaintExportViewResized();
}).on("dialogresizestop", function (event, ui) {
    advancedPaintExportViewResized();
});

function getExportFloorWallsImagePrompt() {
    //$(".zoom-location").click();

    //var objBox = $("#svgAdvancedPaintExport").parent().find("svg").find("g[type='INDIMENSION']")[0].getBBox();
    //var view = api.getViewById("2d");
    //var lengthIndex = api.getLengthIndex();
    //var centerPoint = api.getLabelCenterPoint();
    //
    //var imageLength = getSVGImageLength(); //0:wLength
    //if(getHouseImageValue){
    //    view.fitToExport(imageLength[1] + 50, imageLength[0] + 50,centerPoint);
    //}else{
    //    view.fitToExport(imageLength[1] + 100, imageLength[0] + 100,centerPoint);
    //}

    var paperTmp2dObj = $("#svgAdvancedPaintExport").parent().clone();
    paperTmp2dObj.find("svg").attr({
        id: "svg_" + createInternalTime().toString()
    }).css({width: "100%", height: "100%"});

    //if (!api.getViewById("2d").settings.showUnderlayLayer) {
    //    paperTmp2dObj.find("g[type='UNDERLAY']").remove();
    //}    
    return paperTmp2dObj.find("svg")[0];
}
function getFloorWallsImage(jsonData,saveImage,callback) {

    var blob;
    var elem;

    //提交后，锁定房型
    //api.floorplanLock(true);
    //开始加载，添加标注--add by gaoning
    //api.InitLabels();
    setTimeout(function () {
        //确认时才加载户型图信息--add by gaoning 2017.7.4
        elem = getExportFloorWallsImagePrompt();
        
        //var viewbox = elem.viewBox;
        if(advacedPaintExportBoundbox){
        	var extend = 2;
        	advacedPaintExportBoundbox.max.x += extend,advacedPaintExportBoundbox.max.y += extend;
        	advacedPaintExportBoundbox.min.x -= extend,advacedPaintExportBoundbox.min.y -= extend;
        	
        	var viewWidth = advacedPaintExportBoundbox.max.x - advacedPaintExportBoundbox.min.x;
        	var viewHeight = advacedPaintExportBoundbox.max.y - advacedPaintExportBoundbox.min.y;
        	if(viewWidth/viewHeight > 1.13){
        		var add = (viewWidth/1.13 - viewHeight)/2;
        		advacedPaintExportBoundbox.max.y += add;
        		advacedPaintExportBoundbox.min.y -= add;
        	}else{
        		var add = (viewHeight*1.13 - viewWidth)/2;
        		advacedPaintExportBoundbox.max.x += add;
        		advacedPaintExportBoundbox.min.x -= add;
        	}
        	viewWidth = advacedPaintExportBoundbox.max.x - advacedPaintExportBoundbox.min.x;
        	viewHeight = advacedPaintExportBoundbox.max.y - advacedPaintExportBoundbox.min.y;
        	
        	var vx = advacedPaintExportBoundbox.min.x*100;
        	var vy = -advacedPaintExportBoundbox.max.y*100;
        	var vwidth = viewWidth*100;
        	var vheight = viewHeight*100;
        	elem.setAttribute("viewBox","" + vx + "," + vy + "," + vwidth + "," + vheight);
        	//viewbox.animVal.x = , viewbox.baseVal.x = advacedPaintExportBoundbox.min.x*100;
        	//viewbox.animVal.y = , viewbox.baseVal.y = -advacedPaintExportBoundbox.max.y*100;
        	//
        	//viewbox.animVal.width = viewWidth*100, viewbox.baseVal.width = viewWidth*100;
        	//viewbox.animVal.height = viewHeight*100, viewbox.baseVal.height = viewHeight*100;
        }
        if(saveImage){
            $("body").append($("<div id='maskLayer' " +
                "style='position: absolute;width: 100%;height: 100%;top: 0;    text-align: center;line-height: 500px;" +
                " color: white; left: 0;background: rgba(0,0,0,0.6);z-index: 10000000000000000;'>墙面图正在导出中，请稍后...</div>"));
        }

        var outputSize = 5792;
        var times = 5;//放大倍数
        switch ("2") {
            case "1":
                outputSize = 5792;
                times = 5;
                break;
            case "2":
                outputSize = 10000;
                times = 7;
                break;
            default:
                outputSize = 5792;
                times = 5;
                break;
        }
        saveLogToServer([{"key": "action", "value": "exportFloorWallsImage"}]);

        var elemXML = "";
        elemXML += '<div class="wrap" style="width: 1117px; height: 788px;border:3px solid #bcbcbc;position: absolute;left: 50%;top: 50%; transform: scale(' + times + ',' + times + ') translate(-50%,-50%) ;-webkit-transform:  scale(' + times + ',' + times + ') translate(-50%,-50%);-webkit-transform-origin:0 0;">';
        elemXML += new XMLSerializer().serializeToString(elem);

        elemXML += '<div class="information" style="width: 19.9%;height: 100%;float: left;border-left: 1px solid #bcbcbc;">';
        elemXML += '<div class="items logo" style="height: 100px;background: url(http://pic.oceano.com.cn/h5filesystem/export/oceano_logo.png) no-repeat 0 0;background-size: 120px 58px;background-position: 50px 26px;"></div>';
        elemXML += '<div class="items projectName" style="min-height: 80px;line-height: normal;"><p>工程名称</p><p>' + jsonData.Project + '</p></div>';
        elemXML += '<div class="items projectName" style="min-height: 60px;line-height: normal;"><p>图名</p><p>' + jsonData.Title + '</p></div>';
        elemXML += '<div class="items customerName"><span class="tit">客户名称:</span><span>' + jsonData.Client + '</span></div>';
        elemXML += '<div class="items"><span class="tit">客户电话:</span><span>' + jsonData.ClientTel + '</span></div>';
        //elemXML += '<div class="items"><span>服务门店:</span><span>'+jsonData.storeAddress+'</span></div>';
        elemXML += '<div class="items"><span class="tit">家居顾问:</span><span>' + jsonData.Manager + '</span></div>';
        elemXML += '<div class="items"><span class="tit">设计总监:</span><span>' + jsonData.Designer + '</span></div>';
        //elemXML += '<div class="items"><span>联系电话:</span><span>'+jsonData.designerPhone+'</span></div>';
        elemXML += '<div class="items"><span class="tit">门店电话:</span><span>' + jsonData.OfficeTel + '</span></div>';
        elemXML += '<div class="items"><span class="tit">比例:</span><span>' + jsonData.Scale + '</span></div>';
        elemXML += '<div class="items"><span class="tit">图号:</span><span>' + jsonData.DrawingNo + '</span></div>';
        elemXML += '<div class="items"><span class="tit">日期:</span><span>' + jsonData.Date + '</span></div>';
        elemXML += '<div class="items projectName" style="min-height: 80px;line-height: normal;"><p>门店与地址:</p><p>' + jsonData.Address + '</p></div>';
        elemXML += '<div class="items mark" style="min-height: 75px;line-height: normal;"><p>备注</p><p>图纸所标尺寸均为饰面及贴完砖的完成面的尺寸!</p></div>';
        //elemXML += '<div class="items signYourName" style="height: 10%;min-height: 102px;line-height: normal;"><p>客户签字</p></div>';
        elemXML += '<div class="items warnings" style="height: 20%;min-height: 110px;line-height: normal;border-bottom: none"><p>敬告:</p><p>1.本图纸之所有权属本公司所有,未经许可不得翻印</p><p>2.承建商必须实地复核所有尺寸,如现场尺寸和图纸尺寸有出入的请必须与设计师联系</p><p>3.承建商必须按照图施工,如有不明之处应及时与设计师联系,如擅自改动方案与图纸的,后果自负</p></div></div></div>';
        elemXML = '<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 1.0//EN\"\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\"><head><style>p{padding: 0;margin: 0;}.items{line-height: 25px;border-bottom: 1px solid #bcbcbc;padding: 0 4px;}.tit{border-right: 1px solid #bcbcbc;display: inline-block;width:36%;margin-right: 5px;}svg{width:80% !important; float: left;}</style></head><body style=\"background:#fff;font-size: 14px;color: #333;position: relative;\">' + elemXML + '</body>';
        var uuid = api.uuid();
        var contentBase64 = api.utilEncryptString(elemXML);
        outputSize = outputSize > 8000 ? 8000 : outputSize;
            
         var svg2jpgServer = api.getServicePrefix("export") + "/postSvgToJpg?"
              + "userLoginId=" + globalUsrObj.globalUserLoginId
              + "&uuid=" + uuid
              + "&width=" + Math.round(outputSize)
              + "&height=" + Math.round(outputSize / 1.414);

          $.ajax({
            url: svg2jpgServer,
            type: "post",
            data: {data: contentBase64},
            dataType: 'binary',
            success: function(result){ 
            	    var blob = result;
                  callback && callback(blob);
                  if(saveImage){
                      var name = "墙面图-" + (new Date()).toLocaleString() + ".jpg";
                      var saveLink = document.createElement('a');
                      var downloadSupported = 'download' in saveLink;
                      if (downloadSupported) {
                          saveLink.download = name;
                          saveLink.style.display = 'none';
                          document.body.appendChild(saveLink);
                          try {
                              var url = URL.createObjectURL(blob);
                              saveLink.href = url;
                              saveLink.onclick = function () {
                                  requestAnimationFrame(function () {
                                      URL.revokeObjectURL(url);
                                  })
                              };
                          } catch (e) {
                              console.warn('This browser does not support object URLs. Falling back to string URL.');
                              saveLink.href = uri;
                          }
                          saveLink.click();
                          document.body.removeChild(saveLink);
                      }
                      else {
                          window.open(uri, '_temp', 'menubar=no,toolbar=no,status=no');
                      }
                      $("#maskLayer").remove();
                  }
            },
            error: function (xhr, ajaxOptions, thrownError) {
            	  layer.msg(thrownError);
                $("#maskLayer").remove();
            }
          });

    }, 0);
}
//function getFloorWallsImagePromise(callback) {
//    getFloorWallsImageValue = true;
//    api.getTmallOrderinfo().then(function (data) {
//        var jsonData = data;
//        getFloorWallsImage(jsonData,false,function(value){
//            callback && callback(value);
//        });
//    });
//}

//# sourceURL=ui\dialog/advancedpaintexport.js
