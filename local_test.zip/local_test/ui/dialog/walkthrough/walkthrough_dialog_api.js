var activeWalkThrough = undefined;
// options:
var walkThroughCurrentFrame = 0;
var walkThroughPlaySpeed = 1000 / 30;
var walkThroughIsPlaying = false;
var walkThroughTotalFrames = 100;
/************************************************************************/


function WalkThroughPrompt() {
    var WalkThroughLayerIndex = layer.open({
        zIndex: 500,
        type: 1,
        title: '3D动画漫游',
        moveType: 1,
        moveOut: true,
        skin: 'layui-layer-default',
        fix: false,
        shade: false,
        shadeClose: false,
        maxmin: false,
        area: ['640px', "220px"],
        content: $('#walkthrough3d'),
        success: WalkThroughDialogOpen,
        end: WalkThroughDialogClose
    });
}

function WalkThroughDialogOpen() {
    var allAnimation = api.floorplanGetAnimationNames();
    var walkThroughName = undefined;// todo.
    activeWalkThrough = api.floorplanGetOrCreateAnimationByName(walkThroughName, "WALKTHROUGH");
    api.getViewById("2d").changeSettings("showWalkThroughLayer", true);
    walkThroughCurrentFrame = 0;

    // ui init.
    walkThroughTotalFrames = activeWalkThrough.frames;
    $("#walkthrough3d .animationLength_input").val(walkThroughTotalFrames);
    $("#walkthrough3d .path_select").val(activeWalkThrough.path);
    WalkThroughUIRebuildKeyFrame();
}
function WalkThroughDialogClose() {
    api.getViewById("2d").changeSettings("showWalkThroughLayer", false);
    walkThroughIsPlaying = false;
}

function WalkThroughPlayOneFrame() {
    var lerpKey = api.animationGetLerpKeys(activeWalkThrough, walkThroughCurrentFrame);

    lerpKey.forEach(function (key) {
        api.animationKeyFlushToModel(key);
    });
    WalkThroughPlayUICallback && WalkThroughPlayUICallback();
}

function WalkThroughPlay() {
    if (walkThroughIsPlaying) {
        walkThroughCurrentFrame = (++walkThroughCurrentFrame) % walkThroughTotalFrames;
        WalkThroughPlayOneFrame();
    }
    setTimeout(WalkThroughPlay, Math.round(walkThroughPlaySpeed));
}
setTimeout(WalkThroughPlay, Math.round(walkThroughPlaySpeed));

/*******************  UI  ************************/

$("#walkthrough3d .addKey_btn").on(click, function (e) {
    var camera = api.documentGetActiveCamera();
    var keys = activeWalkThrough.sortedKeys();
    var matchKey = keys.filter(function (key) {
        return key.frame == walkThroughCurrentFrame;
    })[0];

    if (!matchKey) {
        var k = api.animationKeyBuildFromModel("WALKKEY", camera);
        k.frame = walkThroughCurrentFrame;
        api.animationAddKey(activeWalkThrough, k);
        WalkThroughUIRebuildKeyFrame();
    } else {
        matchKey.fromModel();
    }
});

$("#walkthrough3d .deleteKey_btn").on(click, function (e) {
    var keys = activeWalkThrough.sortedKeys();
    var matchKey = keys.filter(function (key) {
        return key.frame == walkThroughCurrentFrame;
    })[0];
    if (matchKey) {
        api.animationDeleteKey(activeWalkThrough, matchKey);
        WalkThroughUIRebuildKeyFrame();
    } else {
        layer.alert('当前帧不是关键帧', {title: '提示', skin: 'layui-layer-default'}, function (index) {
            layer.close(index);
        });
    }
});

$("#walkthrough3dresetconfirm .resetOK_btn").on(click, function (e) {
    function walkKeyOffset(key, x, y) {
        key.x += x, key.tx += x, key.cp1x += x, key.cp2x += x, key.cp1y += y, key.cp2y += y;
        key.y += y, key.ty += y, key.cp1tx += x, key.cp2tx += x, key.cp1ty += y, key.cp2ty += y;
    }

    var key_count = parseInt($("#walkthrough3dresetconfirm .key_count").val());
    log("key reset count=" + key_count);
    $("#walkthrough3dresetconfirm").dialog("close");

    // 1. delete all keys:
    var keys = undefined;
    while ((keys = activeWalkThrough.sortedKeys()).length > 0) {
        api.animationDeleteKey(activeWalkThrough, keys[0]);
    }
    // 2. add keys:
    var step = key_count > 5 ? 10 : 20;
    var camera = api.documentGetActiveCamera();
    for (var i = 0; i < key_count; ++i) {
        var frame = i * step;
        var k = api.animationKeyBuildFromModel("WALKKEY", camera);
        k.frame = frame;
        walkKeyOffset(k, 1.5 * (i % 2), 1.5 * i);
        api.animationAddKey(activeWalkThrough, k);
    }
    // 3. update UI
    WalkThroughUIRebuildKeyFrame();
});

$("#walkthrough3d .animationLength_input").on("change", function (e) {

});
function WalkThroughUIKeyFrameClick(e) {
    var frame = $(this).text();
    walkThroughCurrentFrame = frame;
    WalkThroughPlayOneFrame();
}
function WalkThroughUIRebuildKeyFrame() {
    var keyframe_container = "#walkthrough3d .keyframe_container";
    $(keyframe_container).empty();
    // <div class="keyframe" style="left:10%;margin-left:-7px">10</div>
    var keys = activeWalkThrough.sortedKeys();
    for (var i = 0; i < keys.length; ++i) {
        var frame = keys[i].frame;
        $("<div>").addClass("keyframe").css({
            left: frame + "%",
            "margin-left": "-" + (i + 1) * 7 + "px"
        }).text(frame).on(click, WalkThroughUIKeyFrameClick).appendTo(keyframe_container);
    }

}


//# sourceURL=ui\dialog/walkthrough/walkthrough_dialog_api.js