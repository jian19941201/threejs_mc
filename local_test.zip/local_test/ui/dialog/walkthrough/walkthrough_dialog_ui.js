var walkThroughSlider = "#walkthrough3d .walkthrough3d_view_slider";

$(walkThroughSlider)
    .slider({min: 0, max: 100, step: 1})
    .slider("pips", {
        first: true,
        last: true,
        rest: true
    })
    .slider("float", {})
    .on("slide", function (e, ui) {
        walkThroughIsPlaying = false;
        walkThroughCurrentFrame = parseInt(ui.value);
        WalkThroughPlayOneFrame();
    });

$("#walkthrough3d .button_play").on(click, function (e) {
    $(this).hide();
    $(this).siblings(".button_stop").show();
    walkThroughIsPlaying = true;
});

$("#walkthrough3d .button_stop").on(click, function (e) {
    $(this).hide();
    $(this).siblings(".button_play").show();
    walkThroughIsPlaying = false;
});

$("#walkthrough3d .currentframe_text").on("change", function (e) {
    var value = parseInt($(this).val());

    walkThroughIsPlaying = false;
    walkThroughCurrentFrame = value;
    WalkThroughPlayOneFrame();
});

$("#walkthrough3d .animationLength_input").on("change", function (e) {
    var value = parseInt($(this).val());
    walkThroughTotalFrames = value;
    $(walkThroughSlider).slider("option", "max", value);
    activeWalkThrough.frames = value;
});

$("#walkthrough3d .path_select").on("change", function (e) {
    activeWalkThrough.path = $(this).val();
});
function WalkThroughSetSpeed() {
    var fps = parseInt($("#walkthrough3d .fps_input").val());
    var speed = parseFloat($("#walkthrough3d .speed_select").val());
    walkThroughPlaySpeed = 1000 / ( fps * speed);
}
$("#walkthrough3d .fps_input").on("change", function (e) {
    WalkThroughSetSpeed();
});
$("#walkthrough3d .speed_select").on("change", function (e) {
    WalkThroughSetSpeed();
});

/******************************************************/
function WalkThroughPlayUICallback() {
    $("#walkthrough3d .currentframe_text").val(walkThroughCurrentFrame);
    $(walkThroughSlider).slider("value", walkThroughCurrentFrame);
}


$("#walkthrough3d .resetKey_btn").on(click, function (e) {
    $("#walkthrough3dresetconfirm").dialog("open");
    $("div[aria-describedby='walkthrough3dresetconfirm']").css("z-index", 5000);
});

$("#walkthrough3d .render_animation").on(click, function (e) {
    $("#walkthrough3drenderanimation").dialog("open");
    $("div[aria-describedby='walkthrough3drenderanimation']").css("z-index", 5000);
});
$("#walkthrough3dresetconfirm").dialog({
    //minWidth: 400, minHeight: 380,
    //width: 620, height: 480,
    autoOpen: false,
    resizable: false
}).on("dialogclose", function (event, ui) {
}).on("dialogopen", function (event, ui) {
});

$("#walkthrough3drenderanimation").dialog({
    //minWidth: 400, minHeight: 380,
    width: 440, //height: 200,
    autoOpen: false,
    resizable: false
}).on("dialogclose", function (event, ui) {
}).on("dialogopen", function (event, ui) {
});

$("#walkthrough3drenderanimation .okbutton .start").on(click, function (e) {
    $("#walkthrough3drenderanimation").dialog("close");
    layer.alert("此功能正在开发中，敬请期待!");
});
//# sourceURL=ui\dialog/walkthrough/walkthrough_ui_dialog.js