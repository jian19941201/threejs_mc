/* added by mdx 2017/7/26
*  1、create a 3D model room with webGL
*  2、add the model that we upload
*  3、render the model
* */
var UploadCamera,UploadRenderer,UploadSecne,UploadProductObj,UploadModelcontrols,UploadCustomModelRoom;
function  TestRenderModel(objid) {
    $('#uploadModel_oceano4 .model .model_top .loading_sence ').show();
    UploadProductObj={}
    UploadProductObj.id=objid?objid:"pd6b895c340224787a37103642bb507aa";
   $('#uploadModel_oceano4 .model .model_top .render_pic p').find('img').remove();
    $('#uploadModel_oceano4 .model .model_top .loading_render ').hide();
    document.getElementById("model_room").innerHTML='';
   var output = document.getElementById("model_room");
   UploadSecne = new THREE.Scene();
   var loader = new THREE.OBJLoader();

   UploadCamera = new THREE.PerspectiveCamera(80, 1, 0.01, 20);
   UploadRenderer = new THREE.WebGLRenderer();
   UploadRenderer.setClearColor(new THREE.Color(16777215));
   UploadRenderer.setSize(output.offsetWidth, output.offsetHeight);
   UploadModelcontrols = new THREE.OrbitControls( UploadCamera, UploadRenderer.domElement );
   //加载房间
   $.ajax({
       url: 'asset/customModel/room_model.obj',
       success: function (resp) {
           UploadCustomModelRoom=resp;
           var room = loader.parse(resp);
           room.rotation.x=-0.5*Math.PI;
           var roomTexture = THREE.ImageUtils.loadTexture(api.catalogGetFileUrl("product", "beechwoodhoney", "top"), void 0, function (t) {
               t.wrapS = t.wrapT = THREE.RepeatWrapping,t.needsUpdate = true;
               room.traverse(function (child) {
                   if (child instanceof THREE.Mesh) {
                       if(child.name.substr(child.name.lastIndexOf("_")+1)==21){
                           child.material = new THREE.MeshBasicMaterial();
                           child.material.map = roomTexture;
                           child.material.scUniform2 = [1, 1, 0, 0];
                           child.material.needsUpdate = true
                       }
                       if(child. name.substr(child.name.lastIndexOf("_")+1)==22){
                           child.material = new THREE.MeshBasicMaterial({"color":"#666666"});
                       }
                   }});
               UploadSecne.add(room);
               $("#uploadModel_oceano4 #model_room").empty();
               UploadModelcontrols.minDistance = 1;
               UploadModelcontrols.maxDistance = 4;
               UploadModelcontrols.minPolarAngle=Math.PI * 0.1
               UploadModelcontrols.maxPolarAngle = Math.PI * 0.495;
               UploadModelcontrols.enablePan = false;
               UploadCamera.position.set( 5.0435284564608915, 0.8767441358363766,-2.501755928452346)
               UploadModelcontrols.target.copy( {x:5.02355099923447,y:0,z:-4.988736845513668} );
               UploadModelcontrols.update();
               document.getElementById("model_room").appendChild(UploadRenderer.domElement);
               UploadRenderer.render(UploadSecne, UploadCamera);
               //模型加载
               api.catalogGetCustomFileContentPromise("product",objid, "obj")
                   .then(function(content){
                       UploadProductObj.obj = loader.parse(content);
                       var url = api.catalogGetFileUrl("product", objid, "texture");
                       if(url.substr(url.lastIndexOf("&")+1)=="d"){
                           url+="=1?"+Date.parse(new Date())/1000
                       }else{
                           url+="?"+Date.parse(new Date())/1000
                       }
                       var threeTexture = new THREE.TextureLoader();
                       threeTexture.crossOrigin = "anonymous", threeTexture.load(url, function (texture) {
                           //模型纹理加载
                           texture.wrapS = texture.wrapT = THREE.RepeatWrapping,texture.needsUpdate = true;
                           UploadProductObj.obj.traverse(function (child) {
                               if (child instanceof THREE.Mesh) {
                                   if (child.material instanceof THREE.MeshBasicMaterial)
                                       return;
                                   child.material = new THREE.MeshBasicMaterial();
                                   child.material.map = texture;
                                   child.material.scUniform2 = [1, 1, 0, 0];
                                   child.material.needsUpdate = true;
                               }});
                           computeObjBox(UploadProductObj.obj);
                           //初始相机位置
                           UploadModelcontrols.addEventListener( 'change', UploadModelRender );
                           UploadCamera.position.set( 5.0435284564608915, 0.8767441358363766,-2.501755928452346)
                           UploadProductObj.obj.position.set(5.003710357930243,0,-4.988736845513668);
                           UploadProductObj.obj.rotation.x=-0.5*Math.PI;
                          // UploadCamera.lookAt(new THREE.Vector3(5.003710357930243,0,-4.988736845513668));
                           UploadSecne.add( UploadProductObj.obj);
                           UploadModelcontrols.target.copy(  UploadProductObj.obj.position );
                           UploadModelcontrols.update();
                           UploadRenderer.render(UploadSecne, UploadCamera);
                           $('#uploadModel_oceano4 .model .model_top .loading_sence ').hide();
                   })
               })
           });
       }
   });
}
//计算物体长宽高
function computeObjBox(obj) {
    $('#uploadModel_oceano6').find('div.left_div .model_size').find('input').val('');
     var maxPos={x:0,y:0,z:0},minPos={x:0,y:0,z:0};
     obj.children.forEach(function (child) {
        child.geometry.computeBoundingBox();
        if(isFinite(child.geometry.boundingBox.max.x)){
            maxPos.x=(maxPos.x>child.geometry.boundingBox.max.x)?maxPos.x:child.geometry.boundingBox.max.x;
        }
        if(isFinite(child.geometry.boundingBox.max.y)){
            maxPos.y=(maxPos.y>child.geometry.boundingBox.max.y)?maxPos.y:child.geometry.boundingBox.max.y;
        }
        if(isFinite(child.geometry.boundingBox.max.z)){
            maxPos.z=(maxPos.z>child.geometry.boundingBox.max.z)?maxPos.z:child.geometry.boundingBox.max.z;
        }
        if(isFinite(child.geometry.boundingBox.min.x)){
            minPos.x=(minPos.x<child.geometry.boundingBox.min.x)?minPos.x:child.geometry.boundingBox.min.x;
        }
        if(isFinite(child.geometry.boundingBox.min.y)){
            minPos.y=(minPos.y<child.geometry.boundingBox.min.y)?minPos.y:child.geometry.boundingBox.min.y;
        }
        if(isFinite(child.geometry.boundingBox.min.z)){
            minPos.z=(minPos.z<child.geometry.boundingBox.min.z)?minPos.z:child.geometry.boundingBox.min.z;
        }
    })
    var x=(maxPos.x-minPos.x).toFixed(3),y=(maxPos.y-minPos.y).toFixed(3),z=(maxPos.z-minPos.z).toFixed(3);
    $('#uploadModel_oceano6').find('div.left_div .model_size').find('input').eq(0).val(x);
    $('#uploadModel_oceano6').find('div.left_div .model_size').find('input').eq(1).val(y);
    $('#uploadModel_oceano6').find('div.left_div .model_size').find('input').eq(2).val(z);
}
//更新3d模型试图
function UploadModelRender() {
    UploadRenderer.render( UploadSecne, UploadCamera );
}


// 渲染测试点击按钮
$("#uploadModel_oceano4 .btn_test_render").on("click",function(){
    if(!$("#model_room").find('canvas')[0] || $('#uploadModel_oceano4 .model .model_top .loading_render ').css("display")=="block")return;
    var Option={},OptionRender={
        image: {
            width: document.getElementById("model_room").offsetWidth,
            height: document.getElementById("model_room").offsetHeight
        },
        hdri: "default",            // default, night, daylight
        watermark: "none"
    };
    $.extend(true, Option, defaultMaxOption, oceano_default_option, OptionRender);
    render_sendCustomModelRenderRequest(Option, UploadCamera, UploadProductObj,UploadCustomModelRoom,function (job) {
        $('#uploadModel_oceano4 .model .model_top .loading_render ').show();
        if (renderview_renderrequestSendComplete_uploadCustomModel)renderview_renderrequestSendComplete_uploadCustomModel(job);
    });
    return;
});




