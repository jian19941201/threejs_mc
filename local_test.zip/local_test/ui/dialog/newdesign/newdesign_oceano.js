var newCloudDesignPanelPrompt = function () {
    var cloudDesignDialogIndex = undefined;
    var cloudSearchHouseTypeDialogIndex = undefined;
    var extra = {};

    function listDialog() {
        var dialogWidth = 800;
        cloudDesignDialogIndex = layer.open({
            type: 1,
            title: '欧神诺3D云设计装修工具',
            moveType: 1,
            moveOut: true,
            skin: 'layui-layer-white',
            fix: false,
            shadeClose: false,
            maxmin: false,
            area: [dialogWidth + 'px', undefined],
            content: $('#newCloudDesignPanel')
        });
    }

    $(".newCloudDesignPanel .underlay").on("click", function (e) {
        $("#importUnderlay").trigger("click");
        layer.close(cloudDesignDialogIndex);
    });


    $(".newCloudDesignPanel .free_drawwall").on("click", function (e) {
        api.documentLoad();
        layer.close(cloudDesignDialogIndex);
    });

    $(".newCloudDesignPanel .search_housetype").on("click", function (e) {
        layer.close(cloudDesignDialogIndex);
        cloudSearchHouseTypeDialogIndex = layer.open({
            type: 2,
            title: '查找自己喜欢的户型',
            shadeClose: true,
            skin: 'layui-layer-white',
            shade: false,
            maxmin: true, //开启最大化最小化按钮
            area: ['1150px', '650px'],
            content: appSettings.designjavadomain+'/wbmanager/control/FindBuilding'
        });
    });

    window.addEventListener('message',function(e){
        var data=e.data;
        data = JSON.parse(data);
        var entityid = data.modelId ;
        var action = data.action ;
        if ( action != 'searchmodel' ) return ;
        var param_extra = '"entityid":"' + entityid + '"';
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: api.getServicePrefix("design") + "/getDesignByExtra",
            cache: false,
            data: {
                extra: param_extra,
                dtype: 'buildingmodel'
            }
        }).then(function (designres) {
            if ( designres.length > 0 ) {
                getTextDataFromAliyun("design",designres[0].did,"design.content",function(data){
                    if (typeof readRenderParamDataFromSaved != "undefined") readRenderParamDataFromSaved(data);
                    api.documentLoad(data);
                });
            }
        }).catch(function (e) {

        });
        layer.close(cloudSearchHouseTypeDialogIndex);
    },false);

    $(".newCloudDesignPanel .cancel").on("click", function (e) {
        layer.close(cloudDesignDialogIndex);
    });

    return listDialog;
}();
//# sourceURL=ui\dialog/newdesign_oceano.js