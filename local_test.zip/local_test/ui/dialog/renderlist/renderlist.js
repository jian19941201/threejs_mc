function renderLIst() {

}
renderLIst.prototype = {
    GetrlrecyclebinIds: function () {
        var ids = [];
        $('#rlrecyclebin .content li').each(function (i) {
            ids[i] = $(this).attr('jobid')
        })
        return ids;
    },
    download: function (uri, name) {
        var saveLink = document.createElement('a');
        var downloadSupported = 'download' in saveLink;
        if (downloadSupported) {
            saveLink.download = name;
            saveLink.style.display = 'none';
            document.body.appendChild(saveLink);
            try {
                var blob = renderLIst.uriToBlob(uri);
                var url = URL.createObjectURL(blob);
                saveLink.href = url;
                saveLink.onclick = function () {
                    requestAnimationFrame(function () {
                        URL.revokeObjectURL(url);
                    })
                };
            } catch (e) {
                console.warn('This browser does not support object URLs. Falling back to string URL.');
                saveLink.href = uri;
            }
            saveLink.click();
            document.body.removeChild(saveLink);

        }
        else {
            window.open(uri, '_temp', 'menubar=no,toolbar=no,status=no');
        }
    },
    uriToBlob: function (uri) {
        var byteString = window.atob(uri.split(',')[1]);
        var mimeString = uri.split(',')[0].split(':')[1].split(';')[0]
        var buffer = new ArrayBuffer(byteString.length);
        var intArray = new Uint8Array(buffer);
        for (var i = 0; i < byteString.length; i++) {
            intArray[i] = byteString.charCodeAt(i);
        }
        return new Blob([buffer], {type: mimeString});
    },
    removeAll: function () {
        var ids = this.GetrlrecyclebinIds();
        layer.confirm('删除后将找无法找回,确定删除？', {
            btn: ['确定', '取消'], //按钮
            shade: 0.3, //不显示遮罩
            skin: 'layui-layer-default',
            title: '提示'
        }, function (index) {
            layer.close(index);
            var server = api.getServicePrefix("design");
            //var server = 'http://127.0.0.1:8090';
            var url = server + "/removeDesignAndRenderRelation";
            var did = ui.getOpenedDesignMeta().designId;
            $.ajax({
                type: 'post',
                url: url,
                cache: false,
                data: {
                    did: did,
                    jobid: ids
                }
            }).done(function (res) {
                renderListData.rlrecyclebin.content = [];
                renderListData.rlrecyclebin.length = 0;
                renderListData.rlrecyclebin.state = 0;
                doRenderLIstUI('rlrecyclebin');
                for (var i = 0; i < ids.length; i++) {
                    renderview_jobidArray.splice(renderview_jobidArray.indexOf(ids[i]), 1);
                }
            })
        }, function () {

        });

    },
    resumeAll: function () {
        var ids = this.GetrlrecyclebinIds();
        layer.confirm('全部恢复', {
            btn: ['确定', '取消'], //按钮
            shade: 0.3, //不显示遮罩
            skin: 'layui-layer-default',
            title: '提示'
        }, function (index) {
            layer.close(index);
            var server = api.getServicePrefix("render");
            //var server = 'http://127.0.0.1:8090';
            var url = server + "/resumeJob";
            $.ajax({
                type: 'get',
                url: url,
                cache: false,
                data: {
                    jobid: ids
                }
            }).done(function (res) {
                for (var i = 0; i < renderListData.rlrecyclebin.length; i++) {
                    var type = renderListData.rlrecyclebin.content[i].type;
                    renderListData[type].state = 1;
                    renderListData[type].length++
                    renderListData[type].content.unshift(
                        renderListData.rlrecyclebin.content[i]
                    )
                }
                renderListData.rlrecyclebin.content = [];
                renderListData.rlrecyclebin.length = 0;
                renderListData.rlrecyclebin.state = 0;
                doRenderLIstUI('All');
            })
        }, function () {

        })

    },
    removeJob: function (jobid, type) {
        var flag = arguments[2] == 'sicon' ? true : false;
        layer.confirm('如果确定删除，将会放入回收站', {
            btn: ['确定', '取消'], //按钮
            shade: 0.3, //不显示遮罩
            skin: 'layui-layer-default',
            title: '提示'
        }, function (index) {
            layer.close(index);
            var server = api.getServicePrefix("render");
            //var server = 'http://127.0.0.1:8090';
            var url = server + "/removeJob";
            //var did = res.did;

            $.ajax({
                type: 'get',
                url: url,
                cache: false,
                data: {
                    // did: did,
                    jobid: jobid
                }
            }).done(function (res) {
                if (res.error == 0) {
                    for (var i = 0; i < renderListData[type].length; i++) {
                        if (renderListData[type].content[i].jobid == jobid) {
                            var tem = renderListData[type].content.splice(i, 1);
                            renderListData[type].length--;
                            renderListData.rlrecyclebin.length++;
                            renderListData.rlrecyclebin.state = 1;
                            renderListData.rlrecyclebin.content.unshift(tem[0]);
                            if (renderListData[type].length == 0) {
                                renderListData[type].state = 0;
                            }
                            --i;
                            break;
                        }
                    }
                    doRenderLIstUI('rlrecyclebin');
                    doRenderLIstUI(type);
                    //renderview_jobidArray.splice(renderview_jobidArray.indexOf(jobid), 1);
                    layer.msg("删除成功", {time: 3000});
                    if (flag) {
                        var l = $(".workingsketch_wrapper .img_box img").length;
                        if (l == 1) {
                            $('.close').click();
                            return;
                        }
                        var imgUrls = [];
                        var index = 0;
                        for (var j = 0; j < l; j++) {
                            if ($(".workingsketch_wrapper .img_box img:eq(" + j + ")").attr('class') != 'active') {
                                imgUrls.push({
                                    thumbUrl: $(".workingsketch_wrapper .img_menu img:eq(" + j + ")").attr('src'),
                                    url: $(".workingsketch_wrapper .img_box img:eq(" + j + ")").attr('src'),
                                    index: imgUrls.length
                                })
                            } else {
                                index = j;
                            }
                        }
                        if (imgUrls.length <= index)index = 0;
                        $('.close').click();
                        workingsketchShow(imgUrls, index)
                    }
                } else {
                    layer.msg(res.msg, {time: 3000});
                }

            }).fail(function () {
            });

        }, function () {
        });
    },
    rlrenderingShow: function () {
        var $tab = $('#rlrendering .content');
        if (renderListData.rlrendering.state == 0) {
            $tab.html('<div class="hint">' + renderListData.rlrendering.hint + '</div>')
            $('.renderReady').show();
            $('.renderBegin').hide();

        } else {
            $('.renderReady').hide();
            $('.renderBegin').show();
            var $ui = $("<ul>"),
                $len = renderListData.rlrendering.length;
            for (var i = 0; i < $len; i++) {
                var $con = renderListData.rlrendering.content[i],
                    $icLen = $con.icons.length,
                    timeout = '',
                    icon = [];
                if ($con.res) {
                    timeout = $('<div>', {'class': 'erorrMsg'}).append($('<button>', {
                        "class": 'timeout',
                        text: "重新渲染",
                        'JobUrl': $con.res.retryJobUrl,
                        'jobretry': $con.res.jobretry,
                    }));
                }
                for (var j = 0; j < $icLen; j++) {
                    icon[j] = $($con.icons[j].target, {
                        'class': $con.icons[j].class,
                        'title': $con.icons[j].title,
                        'href': $con.icons[j].href,
                        'url': $con.icons[j].url
                    })
                }
                var $li = $ui.append(
                    $('<li>', {
                        'class': "rlli",
                        'jobid': $con.jobid
                    })
                        .append($('<img>', {'src': $con.previewpic}))
                        .append($con.progessbar)
                        .append(icon)
                        .append($('<div>', {
                            "class": "InQueue"
                        }))
                        .append($('<div>', {
                            "id": "rendermachine_" + $con.jobid,
                            'style': "display:none"
                        }))
                        .append(timeout)
                )
            }
            $tab.html($ui);

        }
    },
    rleffectdrawingShow: function () {
        var $tab = $('#rleffectdrawing .content');
        if (renderListData.rleffectdrawing.state == 0) {
            $tab.html('<div class="hint">' + renderListData.rleffectdrawing.hint + '</div>')
        } else {
            $tab.empty();
            var $muen = $('<div>', {'class': 'rlmuen'})
                .append($('<dl>')
                    .append($('<dt>', {'class': 'activ', 'text': '全部'}).append($('<span>', {text: 0})))
                    .append($('<dt>', {'text': '局部', 'style': "display:none", type: ''}).append($('<span>', {text: 0})))
                    .append($('<dt>', {'text': '预览', type: '0,960'}).append($('<span>', {text: 0})))
                    .append($('<dt>', {'text': '标清', type: '961,1536'}).append($('<span>', {text: 0})))
                    .append($('<dt>', {'text': '高清', type: '1537,2160'}).append($('<span>', {text: 0})))
                    .append($('<dt>', {'text': '4K', type: '2161,9999'}).append($('<span>', {text: 0})))
            )
            $tab.append($muen);
            $tab.append($('<ul>'));
            var $len = renderListData.rleffectdrawing.length;
            for (var i = 0; i < $len; i++) {
                var $con = renderListData.rleffectdrawing.content[i];
                $max_w = $con.pic.renderwidth > $con.pic.renderheight ? $con.pic.renderwidth : $con.pic.renderheight;
                for (var k = 0; k < $(".rlmuen dt").length; k++) {
                    var $T = $(".rlmuen dt:eq(" + k + ")");
                    if ($T.attr('type')) {
                        var T_MIN_len = $T.attr('type').split(',')[0],
                            T_MAX_len = $T.attr('type').split(',')[1];
                        if ($max_w >= T_MIN_len && T_MAX_len >= $max_w) {
                            $T.find('span').html($T.find('span').html() * 1 + 1)
                        }
                    } else {
                        $T.find('span').html($T.find('span').html() * 1 + 1)
                    }
                }
                var $icLen = $con.icons.length;
                var icon = [];
                for (var j = 0; j < $icLen; j++) {
                    icon[j] = $($con.icons[j].target, {
                        'class': $con.icons[j].class,
                        'title': $con.icons[j].title,
                        'href': $con.icons[j].href,
                        'url': $con.icons[j].url
                    })

                }
                $tab.find('ul').append(
                    $('<li>', {
                        "jobid": $con.jobid,
                        'data-renderwidth': $con.pic.renderwidth,
                        'data-renderheight': $con.pic.renderheight,
                    })
                        .append($('<img>', {'src': $con.pic.src}))
                        .append($('<div>', {"class": "rlIcon"}).append(
                            $('<div>', {"class": "iconContent"}).append(icon)
                        ))
                )
            }


        }
    },
    rlvreffectdrawingShow: function () {
        var $tab = $('#rlvreffectdrawing .content'), T = this;
        if (renderListData.rlvreffectdrawing.state == 0) {
            $tab.html('<div class="hint">' + renderListData.rlvreffectdrawing.hint + '</div>')
        } else {
            $tab.empty();
            $tab.append('<div class="explain" style="display:none">' +
                '<div class="step one"><span>1</span><label>请勾选以下效果图，用于生成全屋漫游<label></div>' +
                '<div class="step two"><span>2</span><label>点击一键生成VR全屋漫游<label></div>' +
                '<div class="bottom_icon"></div>' +
                '</div>');
            $tab.append($('<ul>'));
            var $len = renderListData.rlvreffectdrawing.length;
            for (var i = 0; i < $len; i++) {
                var $con = renderListData.rlvreffectdrawing.content[i],
                    $icLen = $con.icons.length,
                    icon = [],
                    roomName = $con.roomName ? $con.roomName : '未命名';
                for (var j = 0; j < $icLen; j++) {
                    icon[j] = $($con.icons[j].target, {
                        'class': $con.icons[j].class,
                        'title': $con.icons[j].title,
                        'href': $con.icons[j].href,
                        'url': $con.icons[j].url
                    })
                }
                var ShowFirst = $('<label>', {text: "设为首页", style: "display:none"}).append($('<input>', {
                    type: 'radio',
                    name: "firstShow"
                }))
                icon.splice(1, 0, ShowFirst);
                var checkClass = $con.checked ? "activ" : '';
                $tab.find('ul').append(
                    $('<li>', {
                        "jobid": $con.jobid,
                        'data-renderwidth': $con.pic.renderwidth,
                        'data-renderheight': $con.pic.renderheight,
                    })
                        .append(
                        $('<div>', {"class": "checkDiv", style: "display:none"})
                            .append($('<span>', {
                                'class': checkClass, 'click': function () {
                                    var c = $(this).attr('class');
                                    for (var i = 0; i < renderListData.rlvreffectdrawing.length; i++) {
                                        if ($(this).closest('li').attr("jobid") == renderListData.rlvreffectdrawing.content[i].jobid) {
                                            if ('activ' == c) {
                                                $(this).removeClass('activ');
                                                renderListData.rlvreffectdrawing.content[i].checked = false;
                                            } else {
                                                $(this).addClass('activ');
                                                renderListData.rlvreffectdrawing.content[i].checked = true;
                                            }
                                        }
                                    }

                                }
                            }))
                            .append($('<div>', {
                                text: roomName, 'click': function () {
                                    var jobid = $(this).closest('li').attr("jobid");
                                    $(this).find('input').length == 0 && $(this).html($('<input>', {
                                        val: $(this).html(), blur: function () {
                                            var val = $(this).val();
                                            $(this).closest('div').html(val);
                                            for (var i = 0; i < renderListData.rlvreffectdrawing.length; i++) {
                                                if (jobid == renderListData.rlvreffectdrawing.content[i].jobid) {
                                                    renderListData.rlvreffectdrawing.content[i].roomName = val;
                                                }
                                            }

                                        }
                                    })), $(this).find('input').focus();
                                }
                            }))
                    )
                        .append($('<img>', {'src': $con.pic.src}))
                        .append($('<div>', {"class": "rlIcon"}).append(
                            $('<div>', {"class": "iconContent"}).append(icon)
                        ))
                )
            }
            $tab.append($('<div>', {'style': "text-align: center;display:none"}).append(
                $('<button>', {
                    'text': "一键生成VR全屋漫游",
                    'click': function () {
                        T.bulidVRAllRome()
                    }
                })
            ).append(
                $('<button>', {
                    'text': "查看VR全屋漫游",
                    'class': 'disable',
                    'click': function () {
                        T.showVRAllRome()
                    }
                })
            ))
        }
    },
    rlrecyclebinShow: function () {
        var $tab = $('#rlrecyclebin .content'), T = this;
        if (renderListData.rlrecyclebin.state == 0) {
            $tab.html('<div class="hint">' + renderListData.rlrecyclebin.hint + '</div>')
        } else {
            $tab.empty();
            $tab.append($('<div>', {
                'class': "explain",
                "html": '说明：鼠标移入效果图，点击恢复按钮，即可撤销删除'
            }))
            $tab.append($('<ul>'));
            $len = renderListData.rlrecyclebin.length;
            for (var i = 0; i < $len; i++) {
                var $con = renderListData.rlrecyclebin.content[i];
                $tab.find('ul').append(
                    $('<li>', {
                        "jobid": $con.jobid,
                        'data-renderwidth': $con.pic.renderwidth,
                        'data-renderwidth': $con.pic.renderheight,
                    })
                        .append($('<img>', {'src': $con.pic.src}))
                        .append($('<div>', {"class": "rlIcon"}).append(
                            $('<div>', {"class": "iconContent"}).append('<button btntype="' + $con.type + '">恢复</button>')
                        ))
                )
            }
            $tab.append($('<div>', {'style': "text-align: center;"}).append(
                $('<button>', {
                    'text': "清空回收站",
                    'click': function () {
                        T.removeAll()
                    }
                })
            ).append(
                $('<button>', {
                    'text': "恢复全部",
                    'click': function () {
                        T.resumeAll()
                    }
                })
            ))
        }
    },
    bulidVRAllRome: function () {
        /**
         * todo 一键生成VR全屋漫游
         **/
    },
    showVRAllRome: function () {
        /**
         * todo 查看VR全屋漫游
         **/
    }
}
var renderLIst = new renderLIst();
var renderListData = {
    rlrendering: {
        length: 0,
        state: 0,
        hint: "<span  class='render_tooltip'></span><br/>当前没有效果图<br>请点击“开始渲染”添加渲染任务",
        content: []
    },
    rleffectdrawing: {
        length: 0,
        state: 0,
        hint: "<span class='render_tooltip'></span><br/>当前没有效果图<br>请点击“开始渲染”添加渲染任务",
        content: []
    },
    rlvreffectdrawing: {
        length: 0,
        state: 0,
        hint: "<span class='render_tooltip'></span><br/>当前没有效果图<br>请点击“开始渲染”添加渲染任务",
        content: []
    },
    rlrecyclebin: {
        length: 0,
        state: 0,
        hint: "<span class='render_tooltip'></span><br/>当前没有可恢复的效果图",
        content: []

    }
};
$('#renderlistul').draggable({"helper": null, "opacity": 1, "cursor": 'move'})
    .on("drag", function (event, ui) {
        $('[aria-describedby="renderlisttab"]').offset(ui.offset);
    });
$('#renderlisttab>a').click(function () {
    $("#renderlisttab").dialog('destroy')
})
$('#renderlistul li').click(function () {
    $("#renderlistul li").removeClass('active');
    $(this).addClass('active');
    $('.renderlistr').hide();
    $("#" + $(this).attr("cid")).show();
})


function doRenderLIstUI(id) {
    /*正在渲染*/
    if ('rlrendering' == id || 'All' == id) {
        renderLIst.rlrenderingShow()
    }
    /*普通效果图*/
    if ('rleffectdrawing' == id || 'All' == id) {
        renderLIst.rleffectdrawingShow();
    }
    /*VR效果图*/
    if ('rlvreffectdrawing' == id || 'All' == id) {
        renderLIst.rlvreffectdrawingShow();
    }
    /*回收站*/
    if ('rlrecyclebin' == id || 'All' == id) {
        renderLIst.rlrecyclebinShow()
    }
}

doRenderLIstUI('All')


$('.renderlistr').on("click", "li img", function () {
    var jobid = $(this).parents("li").attr("jobid");
    if ('rlvreffectdrawing' == $(this).closest('.renderlistr').attr('id')) {
        var url = api.getServicePrefix("bom") + "/panoView?id=" + jobid;
        window.open(url);
    } else if ('rleffectdrawing' == $(this).closest('.renderlistr').attr('id')) {
        var $imgs = $('#rleffectdrawing li img:visible');
        var imgUrl = [];

        $imgs.each(function (i) {
            var imgUrlLIst = {};
            //var renderwidth = $(this).parents("li").attr("data-renderwidth");
            //var renderheight = $(this).parents("li").attr("data-renderheight");
            var jobid = $(this).parents("li").attr("jobid");
            var thumbUrl = $(this).attr("src");
            imgUrlLIst.thumbUrl = thumbUrl;
            imgUrlLIst.url = ui.catalogGetFileUrl("render", jobid, "render");
            imgUrlLIst.index = i;
            imgUrl.push(imgUrlLIst);
        });

        var src = $(this).attr("src");
        var index = 0;
        for (var j = 0; j < imgUrl.length; j++) {
            if (src == imgUrl[j]["thumbUrl"]) {
                index = imgUrl[j]["index"];
            }
        }
        workingsketchShow(imgUrl, index);
    }
}).on("click", '.erorrMsg .timeout', function () {
    var jobid = $(this).closest('li').attr('jobid');

    var retryJobUrl = $(this).attr('JobUrl');
    var jobretry = $(this).attr('jobretry');
    $('.renderDescribe .erorrMsgDiv').remove();
    $('li[jobid="' + jobid + '"] .erorrMsg').remove();
    var $len = renderListData.rlrendering.length;
    for (var i = 0; i < $len; i++) {
        if (jobid == renderListData.rlrendering.content[i].jobid)
            delete renderListData.rlrendering.content[i].res;
    }
    var renderServer = api.getServicePrefix("render");
    var queryJobUrl = renderServer + "/getJobStatus?jobid=" + jobid;
    api.getServiceJSONResponsePromise({type: "GET", url: queryJobUrl})
        .then(function (res) {
            if(res.jobstatus==2){
                var imgUrl = ui.catalogGetFileUrl("render", jobid, "render");
                var thumbImgUrl = ui.catalogGetFileUrl("render", jobid, "thumb");
                updateRenderedJobTaskToList(res, imgUrl, thumbImgUrl);
                renderview_jobid_localtime_Map.remove(res.jobid);
                return;
            }else{
                api.getServiceJSONResponsePromise({type: "GET", url: retryJobUrl + "&retry=" + (parseInt(jobretry) + 1)})
                    .then(function (res2) {
                        isRetry = true;
                        isOpenTimeoutDialog = false;
                        renderview_latestRenderBeginTime = Date.now();
                        renderview_currentJob_timeout = setTimeout(renderview_inprogress_queryJobStatus, 1000, jobid);
                        renderview_job_timeout_container[jobid] = renderview_currentJob_timeout;
                    });
            }
        })

}).on("click", '.iconContent .saveIcon', function (e) {
    var uri = $(this).attr('url');
    renderLIst.download(uri, "output.jpg")
}).on("click", '.iconContent .detailIcon', function (e) {
    var jobid = $(this).closest('li').attr('jobid');
    var res = renderview_jobMeta[jobid]
    var master = JSON.parse(res.masterdata);
    var html =
        "场景渲染时间:" + "<span style='color:red;font-weight: bold;'>" + timeDiff(res.masterbeginrendertime, res.masterendrendertime) + "</span>秒,<br>" +
        "图片尺寸:" + "<span style='color:red;font-weight: bold;'>" + res.renderwidth + "x" + res.renderheight + "</span>.<br>" +
        "<span style='display:none;'>渲染机名称:" + "<span style='color:red;font-weight: bold;'>" + master.hostname + "</span>,</span><br>" +
        "<span style='display:none;'>渲染机IP:" + "<span style='color:red;font-weight: bold;'>" + master.ip + "</span>,</span><br>";

    $("#renderDetailDialog").html(html).dialog({modal: true});
}).on("click", '.iconContent .deleteIcon', function (e) {
    var T = $(this);
    var type = T.closest(".renderlistr").attr('id');
    var jobid = T.closest('li').attr('jobid');
    renderLIst.removeJob(jobid, type)
}).on("click", '.iconContent .qrIcon', function (e) {
    var jobid = $(this).closest('li').attr('jobid');
    var text = api.getServicePrefix("bom") + "/lib/krpano/krpano.html?xml=examples/mvtpano/krpano_vr.xml&html5=only&id=" + jobid;
    if ('rleffectdrawing' == $(this).closest('.renderlistr').attr('id')) {
        text = ui.catalogGetFileUrl("render", jobid, "render");
    }
    $('.render_list_qrCode').length == 0
    &&
    $('<div>', {'class': 'render_list_qrCode'})
        .appendTo('body')
        .append(
        $('<div>', {'class': 'qrCode'})
    ).append(
        $('<a>', {
            'class': 'clipboard',
            'text': '复制链接',
            'data-clipboard-text': text,
            'href': 'javascript:;',
            style: "display: block;height: 0;position: relative;top: -23px;"
        })
    ).append(
        $('<button>', {'class': 'closeQrcode', 'text': '关闭'})
    )

    var _qrCode = new QRCode($(".render_list_qrCode .qrCode")[0], {
        text: text,
        width: 160,
        height: 160
    });

    var index = layer.open({
        type: 1,
        title: false,
        moveType: 1,
        closeBtn: 0,
        moveOut: true,
        skin: 'layui-layer-default',
        fix: false,
        shadeClose: false,
        maxmin: false,
        content: $('.render_list_qrCode')
    });
    $('.render_list_qrCode .closeQrcode').click(function () {
        layer.close(index);
        $('.render_list_qrCode').remove();
    });
    //$('.render_list_qrCode .clipboard').click(function(){
    var clipboard = new Clipboard($('.clipboard')[0]);
    clipboard.on('success', function () {
        layer.msg('复制成功', {time: 3000});
    })
    clipboard.on('error', function (e) {
        layer.msg('复制失败', {time: 3000});
    })
    //});

}).on("click", '.iconContent button', function (e) {
    var jobid = $(this).closest('li').attr('jobid');
    var type = $(this).attr('btntype');
    var txt = "将恢复到普通效果图中";
    if ('rlvreffectdrawing' == type) {
        txt = "将恢复到VR效果图中"
    }
    layer.confirm(txt, {
        btn: ['确定', '取消'], //按钮
        shade: 0.3, //不显示遮罩
        skin: 'layui-layer-default',
        title: '提示'
    }, function (index) {
        layer.close(index);
        var server = api.getServicePrefix("render");
        //var server = 'http://127.0.0.1:8090';
        var url = server + "/resumeJob";
        $.ajax({
            type: 'get',
            url: url,
            cache: false,
            data: {
                // did: did,
                jobid: jobid
            }
        }).done(function (res) {
            if (res.error == 0) {
                for (var i = 0; i < renderListData.rlrecyclebin.length; i++) {
                    if (jobid == renderListData.rlrecyclebin.content[i].jobid) {
                        var tem = renderListData.rlrecyclebin.content.splice(i, 1);
                        --i;
                        renderListData[type].content.unshift(tem[0]);
                        renderListData[type].state = 1;
                        renderListData[type].length++;
                        renderListData.rlrecyclebin.length--
                        if (renderListData.rlrecyclebin.length == 0) {
                            renderListData.rlrecyclebin.state = 0;
                        }
                        break;
                    }
                }
                doRenderLIstUI('rlrecyclebin');
                doRenderLIstUI(type);
                renderview_jobidArray.push(jobid);
                layer.msg("恢复成功", {time: 3000});
            } else {
                layer.msg(res.msg, {time: 3000});
            }
        }).fail(function () {
        });

    }, function () {
    });

}).on("click", '.rlli a.closeIcon', function (e) {
    var jobid = $(this).closest('li').attr('jobid')
    layer.confirm('确定要终止当前渲染吗？', {
        btn: ['确定', '取消'], //按钮
        shade: 0.3, //不显示遮罩
        skin: 'layui-layer-default',
        title: '提示'
    }, function (index) {
        layer.close(index);
        var server = api.getServicePrefix("design");
        var url = server + "/removeDesignAndRenderRelation";
        var did = ui.getOpenedDesignMeta().designId;
        $.ajax({
            type: 'post',
            url: url,
            cache: false,
            data: {
                did: did,
                jobid: jobid
            }
        }).done(function () {
            clearTimeout(renderview_job_timeout_container[jobid]);
            $('.renderDescribe .erorrMsgDiv').remove();
            renderview_jobid_localtime_Map.remove(jobid);
            delete renderview_job_timeout_container[jobid];
            renderview_jobidArray.splice(renderview_jobidArray.indexOf(jobid), 1);
            for (var i = 0; i < renderListData.rlrendering.length; i++) {
                if (jobid == renderListData.rlrendering.content[i].jobid) {
                    renderListData.rlrendering.content.splice(i, 1);
                    renderListData.rlrendering.length--;
                    if (renderListData.rlrendering.length == 0) {
                        renderListData.rlrendering.state = 0;
                    }
                    break;
                }
            }
            doRenderLIstUI('rlrendering');
        }).fail(function () {
        });

    }, function () {
    });
}).on('click', ".rlmuen dt", function () {
    $(".rlmuen dt").removeClass('activ');
    $(this).addClass("activ");
    var len = $('#rleffectdrawing ul li').length;
    for (var i = 0; i < len; i++) {
        var tem = $('#rleffectdrawing ul li:eq(' + i + ')');
        var MAX_len = tem.data('renderwidth') > tem.data('renderheight') ? tem.data('renderwidth') : tem.data('renderheight');
        if ($(this).attr('type')) {
            var T_MIN_len = $(this).attr('type').split(',')[0];
            var T_MAX_len = $(this).attr('type').split(',')[1];
            if (MAX_len >= T_MIN_len && T_MAX_len >= MAX_len) {
                tem.show();
            } else {
                tem.hide();
            }
        } else {
            tem.show();
        }
    }
})
//显示渲染效果图
function workingsketchShow(imgUrls, index) {

    var num = index + 1 || 1;
    var len = imgUrls.length;
    var menuNum = Math.ceil(num / 4);
    var showHtml = [
        '<div class="workingsketch_wrapper">',
        '<div class="main_body">',
        '<div class="arrows left_arrows">',
        '</div>',
        '<div class="arrows right_arrows">',
        '</div>',
        '<div class="close">X</div>',
        '<div class="img_show">',
        '<div class="img_wrapper">',
        '<div class="img_box">',
        '</div>',
        '</div>',
        '<div class="show_bigimg">',
        '<a target="_blank">点击查看大图</a>',
        '</div>',
        '</div>',
        '<div class="footer">',
        '<div class="img_menu_box">',
        '<div class="img_menu">',
        '</div>',
        '</div>',
        '<div class="slider_arrow slider_left_arrow">',
        '</div>',
        '<div class="slider_arrow slider_right_arrow">',
        '</div>',
        '<div class="sicon">',
        '<a class="delete" href="javascript:"></a>',
        '<a class="save" href="javascript:"></a>',
        '</div>',
        '<div class="num_show">',
        '<span class="num"></span>',
        '&nbsp;/&nbsp;',
        '<span class="all_num"></span>',
        '</div>',
        '</div>',
        '</div>',
        '</div>'
    ].join("");

    var $showHtml = $(showHtml);

    $showHtml.find(".close").on("click", function () {
        $showHtml.remove();
    });

    for (var i = 0; i < imgUrls.length; i++) {

        //var mainBodyHeight =imgUrls[i]["height"];
        //var mainBodyWidth =imgUrls[i]["width"];
        //$showHtml.find(".main_body").css({"width":mainBodyWidth,"height":mainBodyHeigth});

        $showHtml.find(".img_box").append('<img class="' + (num == (i + 1) ? "active" : "") + '" src="' + imgUrls[i]["url"] + '" width="100%" height="100%"/>');
        $showHtml.find(".img_menu").append('<img class="' + (num == (i + 1) ? "active" : "") + '" src="' + imgUrls[i]["thumbUrl"] + '"/>');
        if (num == (i + 1)) {
            $showHtml.find(".show_bigimg a").attr("href", imgUrls[i]["url"]);
        }

    }

    //只显示当前图片

    //$showHtml.find(".img_box img.active").show().siblings().hide().change();

    if (num == 1) {
        $showHtml.find(".left_arrows").hide();
    }
    if (num == len) {
        $showHtml.find(".right_arrows").hide();
    }
    switchSliderState();

    $showHtml.find(".footer .num").text(num);
    $showHtml.find(".footer .all_num").text(len);

    $showHtml.find(".right_arrows").on("click", function () {
        num++;
        switchImgState();

    });

    $showHtml.find(".left_arrows").on("click", function () {
        num--;
        switchImgState();
    });

    $showHtml.find(".slider_right_arrow").on("click", function () {
        menuNum = menuNum + 1;
        switchSliderState();
    });

    $showHtml.find(".slider_left_arrow").on("click", function () {
        menuNum = menuNum - 1;
        switchSliderState();
    });


    $showHtml.find(".img_menu img").each(function (i) {
        $(this).on("click", function () {
            num = i + 1;
            switchImgState();
        });
    });

    function switchImgState() {
        $showHtml.find(".footer .num").text(num);
        $showHtml.find(".img_menu img.active").removeClass("active");
        $showHtml.find(".img_menu img").eq(num - 1).addClass("active");
        $showHtml.find(".img_box img.active").removeClass("active");
        $showHtml.find(".img_box img").eq(num - 1).addClass("active");
        $showHtml.find(".left_arrows").show();
        $showHtml.find(".right_arrows").show();
        $showHtml.find(".show_bigimg a").attr("href", imgUrls[num - 1]["url"]);
        if (num == 1) {
            $showHtml.find(".left_arrows").hide();
        }
        if (num == len || len == 1) {
            $showHtml.find(".right_arrows").hide();
        }
        menuNum = Math.ceil(num / 4);
        switchSliderState();
    }

    function switchSliderState() {
        $showHtml.find(".slider_left_arrow").show();
        $showHtml.find(".slider_right_arrow").show();
        if (menuNum == 1) {
            $showHtml.find(".slider_left_arrow").hide();
        }
        if (menuNum == Math.ceil(len / 4) || Math.ceil(len / 4) == 1) {
            $showHtml.find(".slider_right_arrow").hide();
        }
        $showHtml.find(".img_menu_box .img_menu").css("transform", "translate3d(-" + 340 * (menuNum - 1) + "px,0,0)");
    }

    $("body").append($showHtml);
}

$('body').on('click', '.sicon .delete', function () {
    var src = $('.workingsketch_wrapper .img_box .active').attr('src'),
        jobid = src.split('/render/')[1].split('/')[0],
        type = 'rleffectdrawing';
    renderLIst.removeJob(jobid, type, "sicon");
}).on('click', '.sicon .save', function () {
    var uri = $('.workingsketch_wrapper .img_box .active').attr('src');
    renderLIst.download(uri, "output.jpg")
})
//# sourceURL=ui\renderlist\renderlist.js