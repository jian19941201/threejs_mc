var user_currentUserData = undefined;

function userLogin(user) {
    user_currentUserData = user;
}
function userLogout() {
    user_currentUserData = undefined;
}
function getCurrentUserData() {
    return user_currentUserData;
}

//# sourceURL=ui/dialog/user/user_api.js