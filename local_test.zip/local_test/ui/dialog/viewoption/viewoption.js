/*视图设置弹出层*/

var viewOptionsPanelPrompt = (function () {
    var dialogIndex = undefined;

    function optionsDialog() {
        var dialogWidth = 450;
        var dialogHeight = 350;
        dialogIndex = layer.open({
            type: 1,
            title: '系统设置',
            skin: 'layui-layer-default',
            //fix: false,
            //closeBtn: false,
            shadeClose: false,
            maxmin: false,
            move: false,
            area: [dialogWidth + 'px', dialogHeight + 'px'],
            content: $('#viewOptionsPanel'),
            success: function () {
                $("#viewOptionsPanel").parents(".layui-layer-default").draggable();
                $("#viewOptionsPanel .tab_container .checkboxset").each(function (index) {
                    var inputObj = $(this);
                    var viewId = inputObj.attr("view");
                    var mode = inputObj.attr("mode");
                    var isChecked = api.getViewById(viewId).settings[mode];
                    if (isChecked || isChecked == undefined) {
                        inputObj.prop("checked", true);
                    } else {
                        inputObj.prop("checked", false);
                    }
                });
                var wallInfo=api.setWallInfo();
                $("#viewOptionsPanel .wall_height_input").spinner({
                    max: 10000,
                    min: 1500,
                    step: 1,
                    numberFormat: "n",
                    spin: function( event, ui ) {
                        api.setWallInfo({height:(ui.value/1000)});
                    }
                })
                    .spinner("value", (wallInfo.height * 1000))
                    .on("keyup", function (e) {
                        if (!keyCodeIsNumber(e.keyCode)) return false;
                        var text=$(this).val()
                        if($(this).val()<1500 || $(this).val()>10000){
                            text=2800;
                        }
                        api.setWallInfo({height:(text/1000)});
                    });
                $("#viewOptionsPanel .wall_thickness_input").spinner({
                    max: 500,
                    min: 50,
                    step: 1,
                    numberFormat: "n",
                    spin: function( event, ui ) {
                        api.setWallInfo({width:(ui.value/1000)});
                    }
                }).spinner("value", (wallInfo.width * 1000))
                    .on("keyup", function (e) {
                        if (!keyCodeIsNumber(e.keyCode)) return false;
                        var text=$(this).val()
                        if($(this).val()<50 || $(this).val()>500){
                            text=150;
                        }
                        api.setWallInfo({width:(text/1000)});
                    });

                //刷新设置--add by gaoning 2017.11.14
                RefreshOptionsDialog();
            }
        });
    }

    function RefreshOptionsDialog() {

        //处理内墙线或墙中线
        if (api.getViewById("2d").settings.showDimensionLayer) {
            $("#viewOptionsPanel .tab_container .radioset1").click();
        } else if (api.getViewById("2d").settings.showInnerDimensionLayer) {
            $("#viewOptionsPanel .tab_container .radioset2").click();
        } else {

        }
    }

    /*    $(window).bind('resize', function() {
     layer.full(dialogIndex);
     });*/


    $("#viewOptionsPanel .popup .tab").each(function (index) {
        $(this).on(click, function (e) {
            var tabcontainerobj = $(".viewOptionsPanel .popup .tab_container .tab_" + index);
            tabcontainerobj.show();
            tabcontainerobj.siblings().hide();
            $(this).addClass("hover");
            $(this).siblings().removeClass("hover");
        });
    });

    $("#viewOptionsPanel .tab_container .checkboxset").parent().on(click, function (e) {
        if (e.target.type == 'checkbox') return;
        var inputObj = $(this).children(".checkboxset");
        var viewId = inputObj.attr("view");
        var mode = inputObj.attr("mode");
        if (inputObj.is(':checked')) { /*取消设定*/
            inputObj.prop("checked", false);
            //alert('cancel=='+inputObj.attr("mode")) ;
            api.getViewById(viewId).changeSettings(mode, false);
        } else { /*设定*/
            inputObj.prop("checked", true);
            //alert('ok=='+inputObj.attr("mode")) ;
            api.getViewById(viewId).changeSettings(mode, true);
        }
    });

    $("#viewOptionsPanel .tab_container .checkboxset").on(click, function (e) {
        var viewId = $(this).attr("view");
        var mode = $(this).attr("mode");
        if ($(this).is(':checked')) { /*设定*/
            //alert('ok=='+$(this).attr("mode")) ;
            api.getViewById(viewId).changeSettings(mode, true);
        } else { /*取消设定*/
            //alert('cancel=='+$(this).attr("mode")) ;
            api.getViewById(viewId).changeSettings(mode, false);
        }
    });

    //设置显示墙中线或者内墙线--add by gaoning 2017.8.14
    $("#viewOptionsPanel .tab_container .radioset1").on(click, function (e) {
        var viewId = $(this).attr("view");
        //var mode = $(this).attr("mode");
        //if (mode == "showDimensionLayer") {
        api.getViewById(viewId).changeSettings("showDimensionLayer", true);
        api.getViewById(viewId).changeSettings("showInnerDimensionLayer", false);
        //} else { /*取消设定*/
        //    api.getViewById(viewId).changeSettings("showDimensionLayer", false);
        //    api.getViewById(viewId).changeSettings("showInnerDimensionLayer", true);
        //}
    });
    $("#viewOptionsPanel .tab_container .radioset2").on(click, function (e) {
        var viewId = $(this).attr("view");
        //var mode = $(this).attr("mode");
        //if (mode == "showDimensionLayer") {
        //    api.getViewById(viewId).changeSettings("showDimensionLayer", true);
        //    api.getViewById(viewId).changeSettings("showInnerDimensionLayer", false);
        //} else {
        api.getViewById(viewId).changeSettings("showDimensionLayer", false);
        api.getViewById(viewId).changeSettings("showInnerDimensionLayer", true);
        //}
    });

    //设置是否显示墙线--add by gaoning 2017.8.16
    $("#viewOptionsPanel .tab_container .showAllLayerSet").on(click, function (e) {
        if ($(this).is(':checked')) { /*设定*/
            var layerState = api.getSnapLayerState();
            if(layerState == "OUT"){
                api.getViewById("2d").changeSettings("showDimensionLayer", true);
                api.getViewById("2d").changeSettings("showInnerDimensionLayer", false);
            }else {
                api.getViewById("2d").changeSettings("showDimensionLayer", false);
                api.getViewById("2d").changeSettings("showInnerDimensionLayer", true);
            }
            //$("#viewOptionsPanel .tab_container .tab_1 input.showDimensionLayer").prop("checked", true);
            //$("#viewOptionsPanel .tab_container .tab_1 input.showInnerDimensionLayer").prop("checked", false);
            $("#viewOptionsPanel .tab_container .radioset1").prop("disabled", false);
            $("#viewOptionsPanel .tab_container .radioset2").prop("disabled", false);
        } else { /*取消设定*/
            api.getViewById("2d").changeSettings("showDimensionLayer", false);
            api.getViewById("2d").changeSettings("showInnerDimensionLayer", false);
            //$("#viewOptionsPanel .tab_container .tab_1 input.showDimensionLayer").prop("disabled", true);
            //$("#viewOptionsPanel .tab_container .tab_1 input.showInnerDimensionLayer").prop("disabled", true);
            $("#viewOptionsPanel .tab_container .radioset1").prop("disabled", true);
            $("#viewOptionsPanel .tab_container .radioset2").prop("disabled", true);
        }
    });

    return optionsDialog;
})();
