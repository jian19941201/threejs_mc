var saveCloudDesignPanelPrompt = function () {
    var cloudDesignDialogIndex = undefined;
    var extra = {};
    /**防止客户多次保存，生成远程多条客户方案记录*/
    var customerDesignIdsMap = new Map();
    var thumbnail_data = undefined;

    function displayRenderThumbnail() {
        var jobid = $(".saveCloudDesignPanel .thumbnail_container .render_index").val();
        var renderUrl = api.catalogGetFileUrl("render",jobid,"render");
        //api.getServicePrefix("file") + "/getFile" + "?id=" + jobid + "&category=render&type=render";
        $(".saveCloudDesignPanel .thumbnail").empty();
        $("<img>").attr({src: renderUrl}).css({
            width: "100%",
            height: "100%"
        }).appendTo(".saveCloudDesignPanel .thumbnail");
        thumbnail_data = jobid;
    }

    function fillThumbnail(option) {
        var thumbnailType = $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val();
        $(".saveCloudDesignPanel .thumbnail_container .render_index").empty().hide();
        var container = ".saveCloudDesignPanel .thumbnail";
        $(container).empty();

        switch (thumbnailType) {
            case "2d":
                var result = $.trim(getPaper2dsvg());
                $(container).html(result);
                thumbnail_data = result;
                break;

            case "render":
                if (typeof renderview_jobidArray != "undefined" && renderview_jobidArray.length != 0) {
                    for (var i = 0; i < renderview_jobidArray.length; ++i) {
                        $("<option>").attr({value: renderview_jobidArray[i]}).html(i).appendTo(".saveCloudDesignPanel .thumbnail_container .render_index");
                    }
                    var display = renderview_jobidArray[0];
                    $(".saveCloudDesignPanel .thumbnail_container .render_index").show().val(display);
                    displayRenderThumbnail();
                    break;
                } else {
                    layer.alert("本设计没有渲染效果图。", {
                        title: '提示',
                        skin: 'layui-layer-default'
                    });
                    $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val("3d");
                }
            case "3d":
                getPaper3dImage({
                    width: 256, height: 256, quality: 1.0, onSuccess: function (dataUrl) {
                        $("<img>").attr({src: dataUrl}).css({
                            width: "100%",
                            height: "100%"
                        }).appendTo(container);
                        thumbnail_data = dataUrl;
                    }
                });
                break;
            case "custom":
                break;
        }
        return thumbnailType;
    }

    $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").on("change", fillThumbnail);
    $(".saveCloudDesignPanel .thumbnail_container .render_index").on("change", displayRenderThumbnail);

    function listDialog(designType) {
        var dialogWidth = 700;
        cloudDesignDialogIndex = layer.open({
            type: 1,
            title: '保存设计',
            move: false,
            skin: 'layui-layer-default',
            fix: false,
            shadeClose: false,
            maxmin: false,
            area: [dialogWidth + 'px', "580px"],
            content: $('#saveCloudDesignPanel'),
            success: function (layero, index) {

                $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val("3d");
                fillThumbnail();

                if (designType === "modelroom") {
                    $(".saveCloudDesignPanel input[name='checkspace']")[0].checked = true;
                    $(".saveCloudDesignPanel .singleroomtype").show();
                    $(".saveCloudDesignPanel .mutilroomtype").hide();

                    /*选中房间面积*/
                    var singleInnerArea = api.pickGetPicked()[0].model.getMeasurement("inner");
                    $(".saveCloudDesignPanel input[name='roommeasurement']").val(Math.ceil(singleInnerArea * 100) / 100);
                    /*保存时使用*/

                } else {
                    $(".saveCloudDesignPanel input[name='checkspace']")[1].checked = true;
                    $(".saveCloudDesignPanel .singleroomtype").hide();
                    $(".saveCloudDesignPanel .mutilroomtype").css({display: "flex"});
                }

            }
        });
    }

    api.application_ready_event.add(function () {
        var designMeta = ui.getOpenedDesignMeta();
        /**没有加载到设计的时候，给默认设计名*/
        $(".saveCloudDesignPanel input[name='name']").val((designMeta && designMeta.entityId) || "");

        api.documentReadyEvent.add(function () {
            /**加载设计后初始化保存页面值*/
            var designMeta = ui.getOpenedDesignMeta();
            if (designMeta) {
                $(".saveCloudDesignPanel .formobj").each(function (index) {
                    if ($(this)[0].type == 'radio') {
                        if ($(this).val() == designMeta[$(this).attr("name")]) {
                            $(this)[0].checked = true;
                        }
                    } else {
                        $(this).val(designMeta[$(this).attr("name")]);
                    }
                });
            }

        });

        if (designMeta && designMeta.entityId) extra.entityid = designMeta.entityId ;
        extra.userloginid = (designMeta && designMeta.userLoginId) || "";
        extra.customerid = (designMeta && designMeta.customerId) || "";
    });

    function getSavedContent() {
        var saveAsModelRoom = ($(".saveCloudDesignPanel input[name='checkspace']")[0].checked == true);
        var saveUnderImage = ($(".saveCloudDesignPanel input[name='underimagesetting']")[0].checked == true);
        var pickedRoom = api.pickGetPicked()[0];

        var content = api.documentSave({
            saveUnderImage: saveUnderImage,
            pickedRoom: (saveAsModelRoom && pickedRoom &&
            pickedRoom.model && pickedRoom.model.type == "FLOOR" ? pickedRoom.model : undefined)
        });
        return content;
    }

    $(".saveCloudDesignPanel .saveToClude").on(click, function (e) {
        //if ($(this).attr("disabled") == "disabled") return;
        var content = getSavedContent();

        var server = api.getServicePrefix("design");
        var url = server + "/saveDesign";

        var dataobj = {
            content: content,
            jobidstring: JSON.stringify(renderview_jobidArray),
            extra: JSON.stringify(extra),
            thumbnail_type: $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val(),
            thumbnail: thumbnail_data
        };

        var formArray = $(".saveCloudDesignPanel form").serializeArray();
        formArray.forEach(function (obj, index) {
            dataobj[obj.name] = obj.value;
        });
        dataobj.dtype = "user";
        var designMeta = ui.getOpenedDesignMeta();
        if (designMeta && designMeta.designType) dataobj.dtype = designMeta.designType;
        /*打开其他设计，如户型，保存都是另存为【我的设计】*/
        if (designMeta && designMeta.notEdit && designMeta.notEdit == '1') {
            delete dataobj.did;
            dataobj.dtype = "user";
        }

        /*disabled属性的手动取值*/
        var checkspace = dataobj.checkspace = $(".saveCloudDesignPanel input[name='checkspace']:checked").val();
        if (dataobj.name == '') {
            layer.alert("请输入设计名。");
            return;
        }
        if (checkspace == 0) {//保存为设计方案
            dataobj.dtype = "user";
            delete dataobj.did;
        }

        $.ajax({
            type: 'post',
            url: url,
            cache: false,
            data: dataobj
        }).done(function (data) {
            data = JSON.parse(data);
            $(".saveCloudDesignPanel input[name='did']").val(data.did);

            layer.alert('保存到云成功！', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                layer.close(index);
                layer.close(cloudDesignDialogIndex);
            });
        }).fail(function () {
            layer.alert('保存到云失败！', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                layer.close(index);
                layer.close(cloudDesignDialogIndex);
            });
        });


    });


    $(".saveCloudDesignPanel .saveToLocal").on(click, function (e) {
        var content = getSavedContent();
        var filename = "我的设计-" + (new Date()).toLocaleString() + ".design";
        api.saveAs(new Blob([content], {type: "text/plain;charset=" + document.characterSet}), filename);
        layer.close(cloudDesignDialogIndex);
    });

    $(".saveCloudDesignPanel .cancel").on(click, function (e) {
        layer.close(cloudDesignDialogIndex);
    });

    return listDialog;
}();
//# sourceURL=ui\dialog/savedesign_oceano.js
