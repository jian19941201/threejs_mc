var saveCloudDesignPanelPrompt = function () {
    var openDiyDesignTime = createInternalTime();

    var isSaveAsCloud = undefined;
    var cloudDesignDialogIndex = undefined;
    var extra = {};
    /**防止客户多次保存，生成远程多条客户方案记录*/
    var customerDesignIdsMap = new Map();
    var thumbnail_data = undefined;

    function promptUserSaveDesign() {
        var newTime = createInternalTime();
        var timediff = timeDiff(openDiyDesignTime, newTime);
        var did = $(".saveCloudDesignPanel input[name='did']").val();
        if (did == '' && timediff > 5 * 60) {
            openDiyDesignTime = createInternalTime();
            layer.msg("当前设计还未保存，请及时保存~~~", {time: 3000,zIndex:888});
            return;
        }

        if (did && did != '' && timediff > 5 * 60) {
            openDiyDesignTime = createInternalTime();
            layer.msg("当前设计还未保存，请及时保存~~~", {time: 3000,zIndex:888});
            return;
            /*dialogOpenSuccess();
             window.setTimeout(function(){
             $(".saveCloudDesignPanel .saveToClude").trigger("click");
             },3000);*/
        }
    }

    window.setInterval(promptUserSaveDesign, 1000);

    function displayRenderThumbnail() {
        var jobid = $(".saveCloudDesignPanel .thumbnail_container .render_index").val();
        var renderUrl = api.catalogGetFileUrl("render", jobid, "render");
        //api.getServicePrefix("file") + "/getFile" + "?id=" + jobid + "&category=render&type=render";
        $(".saveCloudDesignPanel .thumbnail").empty();
        $("<img>").attr({src: renderUrl}).css({
            width: "100%",
            height: "100%"
        }).appendTo(".saveCloudDesignPanel .thumbnail");
        thumbnail_data = jobid;
    }

    function fillThumbnail(option) {
        var thumbnailType = $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val();
        $(".saveCloudDesignPanel .thumbnail_container .render_index").empty().hide();
        var container = ".saveCloudDesignPanel .thumbnail";
        $(container).empty();

        switch (thumbnailType) {
            case "2d":
                var result = $.trim(getPaper2dsvg());
                $(container).html(result);
                thumbnail_data = result;
                break;

            case "render":
                if (typeof renderview_jobidArray != "undefined" && renderview_jobidArray.length != 0) {
                    for (var i = 0; i < renderview_jobidArray.length; ++i) {
                        $("<option>").attr({value: renderview_jobidArray[i]}).html(i).appendTo(".saveCloudDesignPanel .thumbnail_container .render_index");
                    }
                    var display = renderview_jobidArray[0];
                    $(".saveCloudDesignPanel .thumbnail_container .render_index").show().val(display);
                    displayRenderThumbnail();
                    break;
                } else {
                    layer.alert("本设计没有渲染效果图。", {
                        title: '提示',
                        skin: 'layui-layer-default'
                    });
                    $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val("3d");
                }
            case "3d":
                getPaper3dImage({
                    width: 256, height: 256, quality: 1.0, onSuccess: function (dataUrl) {
                        $("<img>").attr({src: dataUrl}).css({
                            width: "100%",
                            height: "100%"
                        }).appendTo(container);
                        thumbnail_data = dataUrl;
                    }
                });
                break;
            case "custom":
                break;
        }
        return thumbnailType;
    }

    $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").on("change", fillThumbnail);
    $(".saveCloudDesignPanel .thumbnail_container .render_index").on("change", displayRenderThumbnail);

    function listDialog(designType, issaveas) {
        isSaveAsCloud = issaveas;
        var dialogTitle = "保存设计";
        if (isSaveAsCloud && isSaveAsCloud == 'true') {
            dialogTitle = "设计另存为";
        }
        var dialogWidth = 700;
        cloudDesignDialogIndex = layer.open({
            type: 1,
            title: dialogTitle,
            move: false,
            skin: 'layui-layer-default',
            fix: false,
            shadeClose: false,
            maxmin: false,
            area: [dialogWidth + 'px', "580px"],
            content: $('#saveCloudDesignPanel'),
            success: function (layero, index) {
                dialogOpenSuccess(designType);
            }
        });
    }

    function dialogOpenSuccess(designType) {
        $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val("3d");
        fillThumbnail();

        if (designType && designType === "modelroom") {
            $(".saveCloudDesignPanel input[name='checkspace']")[0].checked = true;
            $(".saveCloudDesignPanel .singleroomtype").show();
            $(".saveCloudDesignPanel .mutilroomtype").hide();

            /*选中房间面积*/
            var singleInnerArea = api.pickGetPicked()[0].model.getMeasurement("inner");
            $(".saveCloudDesignPanel input[name='roommeasurement']").val(Math.ceil(singleInnerArea * 100) / 100);
            /*保存时使用*/

        } else {
            $(".saveCloudDesignPanel input[name='checkspace']")[1].checked = true;
            $(".saveCloudDesignPanel .singleroomtype").hide();
            $(".saveCloudDesignPanel .mutilroomtype").css({display: "flex"});
        }
    }

    api.application_ready_event.add(function () {
        var designMeta = ui.getOpenedDesignMeta();
        /**没有加载到设计的时候，给默认设计名*/
        $(".saveCloudDesignPanel input[name='name']").val((designMeta && designMeta.entityId) || "");

        api.documentReadyEvent.add(function () {
            /**加载设计后初始化保存页面值*/
            var designMeta = ui.getOpenedDesignMeta();
            if (designMeta) {
                $(".saveCloudDesignPanel .formobj").each(function (index) {
                    if ($(this)[0].type == 'radio') {
                        if ($(this).val() == designMeta[$(this).attr("name")]) {
                            $(this)[0].checked = true;
                        }
                    } else {
                        $(this).val(designMeta[$(this).attr("name")]);
                    }
                });
            }

        });

        if (designMeta && designMeta.entityId) extra.entityid = designMeta.entityId;
        extra.userloginid = (designMeta && designMeta.userLoginId) || "";
        extra.customerid = (designMeta && designMeta.customerId) || "";

        //DEBUG_BEGIN
        extra.userloginid = "shihuaitong";
        //DEBUG_END

    });

    function getSavedContent() {
        var saveAsModelRoom = ($(".saveCloudDesignPanel input[name='checkspace']")[0].checked == true);
        var saveUnderImage = ($(".saveCloudDesignPanel input[name='underimagesetting']")[0].checked == true);
        var pickedRoom = api.pickGetPicked()[0];

        var content = api.documentSave({
            saveUnderImage: saveUnderImage,
            pickedRoom: (saveAsModelRoom && pickedRoom &&
            pickedRoom.model && pickedRoom.model.type == "FLOOR" ? pickedRoom.model : undefined)
        });
        return content;
    }

    $(".saveCloudDesignPanel .saveToClude").on(click, function (e) {
        //if ($(this).attr("disabled") == "disabled") return;
        var content = getSavedContent();

        var server = api.getServicePrefix("design");
        var url = server + "/saveDesign";

        var dataobj = {
            content: content,
            jobidstring: JSON.stringify(renderview_jobidArray),
            extra: JSON.stringify(extra),
            thumbnail_type: $(".saveCloudDesignPanel .thumbnail_container .thumbnail_type").val(),
            thumbnail: thumbnail_data
        };

        var formArray = $(".saveCloudDesignPanel form").serializeArray();
        formArray.forEach(function (obj, index) {
            dataobj[obj.name] = obj.value;
        });
        dataobj.dtype = "user";
        var designMeta = ui.getOpenedDesignMeta();
        if (designMeta && designMeta.designType) dataobj.dtype = designMeta.designType;
        /*打开其他设计，如户型，保存都是另存为【我的设计】*/
        if (designMeta && designMeta.notEdit && designMeta.notEdit == '1') {
            delete dataobj.did;
            dataobj.dtype = "user";
        }

        /*disabled属性的手动取值*/
        var checkspace = dataobj.checkspace = $(".saveCloudDesignPanel input[name='checkspace']:checked").val();
        if (dataobj.name == '') {
            layer.alert("请输入设计名。");
            return;
        }
        if (checkspace == 0) {//保存为设计方案
            dataobj.dtype = "user";
            delete dataobj.did;
        }

        /*另存为*/
        if (isSaveAsCloud && isSaveAsCloud == 'true') {
            delete dataobj.did;
        }

        $.ajax({
            type: 'post',
            url: url,
            cache: false,
            data: dataobj
        }).done(function (data) {
            data = JSON.parse(data);
            /*另存为*/
            if (isSaveAsCloud && isSaveAsCloud == 'true') {
                /*另存为之后返回过来的did，无需更新隐藏域的值*/
            } else {
                $(".saveCloudDesignPanel input[name='did']").val(data.did);
            }

            /*由搜索出来的客户，打开设计，需向crm推送数据  start*/
            if (designMeta && designMeta.customerId) {
                if (!customerDesignIdsMap.containsKey(data.did)) {
                    var _paramobj = {
                        "designId": data.did,
                        "customerId": designMeta.customerId,
                        "userLoginId": designMeta.userLoginId,
                        "partyId": designMeta.partyId,
                        "thumbType": dataobj.thumbnail_type,
                        "thumbnail": dataobj.thumbnail
                    };

                    $.ajax({
                        type: 'post',
                        url: appSettings.designjavadomain + "/control/createRemoteCustCaseRecord",
                        cache: false,
                        data: _paramobj
                    }).done(function () {
                        customerDesignIdsMap.put(data.did, "");
                    }).fail(function () {
                    });
                }

            }
            /*由搜索出来的客户，打开设计，需向crm推送数据  end */

            layer.msg('保存到云成功！', {time: 1000}, function (index) {
                layer.close(index);
                layer.close(cloudDesignDialogIndex);
            });
        }).fail(function () {
            layer.msg('保存到云失败！', {time: 1000}, function (index) {
                layer.close(index);
                layer.close(cloudDesignDialogIndex);
            });
        });


    });

    /*保存设计到本地*/
/*    $("#saveToLocal_btn").on("click", function (e) {
        var content = getSavedContent();
        var filename = "我的设计-" + (new Date()).toLocaleString() + ".design";
        window.parent.api.saveAs(new Blob([content], {type: "text/plain;charset=" + document.characterSet}), filename);
        var obj = {'action': 'savedesigntolocal'};
        window.parent.postMessage(JSON.stringify(obj), '*');
        var contents = [{"key":"action","value":"save_to_local"},{"key":"userLoginId","value":globalUsrObj.globalUserLoginId},{"key":"partyId","value":globalUsrObj.globalPartyId}];
        saveLogToServer(contents);
    });*/


    $(".saveCloudDesignPanel .saveToLocal").on(click, function (e) {
        var content = getSavedContent();
        var filename = "我的设计-" + (new Date()).toLocaleString() + ".design";
        api.saveAs(new Blob([content], {type: "text/plain;charset=" + document.characterSet}), filename);
        layer.close(cloudDesignDialogIndex);
    });

    $(".saveCloudDesignPanel .cancel").on(click, function (e) {
        layer.close(cloudDesignDialogIndex);
    });

    /*function loadRenderData(did) {
     api.getServiceJSONResponsePromise({
     type: 'get',
     url: api.getServicePrefix("design") + "/getDesignRenderData",
     cache: false,
     data: {"did": did}
     }).then(function (res) {
     res.forEach(function (obj, index) {
     $('#renderId .renderResults').empty();
     obj.children.forEach(function (renderobj) {
     var imgUrl = api.getServicePrefix("file") + "/getFile" + "?id=" + renderobj.jobid + "&category=render&type=render";
     var thumbImgUrl = api.getServicePrefix("file") + "/getFile" + "?id=" + renderobj.jobid + "&category=render&type=thumb";
     addJobTaskToList(renderobj, imgUrl, thumbImgUrl);
     });
     });
     }).catch(function (e) {
     alert('send getDesignRenderData request to server failed!! ');
     });

     }*/


    return listDialog;
}();
//# sourceURL=ui\dialog/savedesign_oceano/savedesign.js
