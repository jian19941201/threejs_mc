var saveCloudDesignPanelPromptExternal = function () {
    var openDiyDesignTime = createInternalTime();

    var isSaveAsCloud = undefined;
    var cloudDesignDialogIndex = undefined;

    function promptUserSaveDesign() {
        // designId 是项目集成后外部js中的对象
        if (typeof designId == 'undefined') return;
        var newTime = createInternalTime();
        var timediff = timeDiff(openDiyDesignTime, newTime);

        if (designId == '' && timediff > 5 * 60) {
            openDiyDesignTime = createInternalTime();
            layer.msg("当前设计还未保存，请及时保存~~~", {time: 3000,zIndex:888});
            return;
        }

        if (designId && designId != '' && timediff > 5 * 60) {
            openDiyDesignTime = createInternalTime();
            layer.msg("当前设计还未保存，请及时保存~~~", {time: 3000,zIndex:888});
            return;
        }
    }

    window.setInterval(promptUserSaveDesign, 1000);

    function listDialog(designType, issaveas) {
        var windowHeight = $(window).height();
        isSaveAsCloud = issaveas;
        var dialogTitle = "保存设计";
        if (isSaveAsCloud && isSaveAsCloud == 'true') {
            dialogTitle = "设计另存为";
        }
        var dialogWidth = 700;
        var dialogcontent = appSettings.designjavadomain + '/control/HomeDesignSaveDesign?v=' + Math.random();
        cloudDesignDialogIndex = layer.open({
            type: 2,
            title: dialogTitle,
            fix: false,
            shadeClose: true,
            skin: 'layui-layer-default',
            maxmin: false,
            moveType: 1,
            move: false,
            area: [dialogWidth + 'px', '670px'],
            content: dialogcontent,
            success: function (layero, index) {
                $(".layui-layer-title").parents(".layui-layer-default").draggable();
                var iframeobj = $(document).find("iframe[src='" + dialogcontent + "']")[0];
                var paramobj = {};

                var renderThumbnailArray = [];
                var roommeasurement = 0;
                paramobj.renderThumbnailArray = renderThumbnailArray;
                if (typeof renderview_jobidArray != "undefined" && renderview_jobidArray.length != 0) {
                    for (var i = 0; i < renderview_jobidArray.length; ++i) {
                        if (renderview_jobidArray[i] == undefined) continue;
                        var renderurl = api.catalogGetFileUrl("render", renderview_jobidArray[i], "render");
                        renderThumbnailArray.push({jobid: renderview_jobidArray[i], renderurl: renderurl});
                    }
                    paramobj.renderThumbnailArray = renderThumbnailArray;
                }
                var singleroomtypetoggle = false;
                var mutilroomtypetoggle = false;
                if (designType && designType === "modelroom") {
                    var singleInnerArea = api.pickGetPicked()[0].model.getMeasurement("inner");
                    roommeasurement = Math.ceil(singleInnerArea * 100) / 100;

                    singleroomtypetoggle = true;
                    mutilroomtypetoggle = false;

                } else {
                    var innerArea = api.floorplanFilterEntity(function (e) {
                        return e.type == "FLOOR";
                    }).map(function (e) {
                        return e.getMeasurement("inner");
                    }).reduce(function (p, c) {
                        return p + c;
                    }, 0);
                    roommeasurement = Math.ceil(innerArea * 100) / 100;
                    singleroomtypetoggle = false;
                    mutilroomtypetoggle = true;
                }
                paramobj.roommeasurement = roommeasurement;
                paramobj.singleroomtypetoggle = singleroomtypetoggle;
                paramobj.mutilroomtypetoggle = mutilroomtypetoggle;
                paramobj.isSaveAsCloud = (isSaveAsCloud && isSaveAsCloud == 'true') ? true : false;

                var designMeta = ui.getOpenedDesignMeta();
                if (designMeta && ui.getOpenedDesignMeta().designId != '') {
                    paramobj.designId = ui.getOpenedDesignMeta().designId;
                }

                if (designMeta && ui.getOpenedDesignMeta().did != '') {
                    paramobj.designId = ui.getOpenedDesignMeta().did;
                }
                paramobj.renderparam = "{}" ;
                if (typeof collectRenderParamDataToSaved != "undefined") {
                    paramobj.renderparam = JSON.stringify(collectRenderParamDataToSaved());
                }

                getPaper3dImage({
                    width: 256, height: 256, quality: 1.0, onSuccess: function (dataUrl) {
                        paramobj.thumbnail = dataUrl;
                        iframeobj.contentWindow.remoteInvokeInitAttribute(paramobj);
                    },
                    onError: function (data) {
                        paramobj.thumbnail = "";
                        iframeobj.contentWindow.remoteInvokeInitAttribute(paramobj);
                    }
                });
            }
        });
    }

    window.addEventListener('message', function (e) {
        var data = e.data;
        data = JSON.parse(data);
        var action = data.action;
        if (action === 'savedesigncancel') {
            layer.close(cloudDesignDialogIndex);
        } else if (action === 'savedesigntolocal') {
            layer.close(cloudDesignDialogIndex);
        } else if (action === 'savedesigntocloud') {
            layer.close(cloudDesignDialogIndex);
        }
    }, false);

    return listDialog;
}();

//# sourceURL=ui\dialog/savedesign_oceano/savedesign_external.js
