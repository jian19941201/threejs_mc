
$("#snapshot3d .button_play").on(click,function(e){
    $(this).hide() ;
    $(this).siblings(".button_stop").show() ;
});

$("#snapshot3d .button_stop").on(click,function(e){
    $(this).hide() ;
    $(this).siblings(".button_play").show() ;
});

$("#snapshot3d .view_angle_icon").on(click,function(e){
    var count = 0 ;
    $("#snapshot3d .single_content").each(function(index){
        count = index+1 ;
    });
    if ( count > (10-1) ) {
        alert("最多支持10个视角！") ;
        return ;
    }
    var view_angle_content = $("#snapshot3d .view_angle_content").outerWidth(true) ;
    var view_angle_sub_content = $("#snapshot3d .view_angle_sub_content").outerWidth(true) ;

    var divobj = $("<div>").addClass("single_content") ;
    $("<span>").addClass("seq_icon").text(count+1).appendTo( divobj );
    $("<span>").addClass("icon delete_icon").text("×").appendTo( divobj );
    $("<img>").addClass("angle_img").appendTo( divobj );
    $("<input>").attr({"type":"button","value":"设定"}).addClass("button").appendTo( divobj );
    $("#snapshot3d .view_angle_sub_content").append(divobj);
    var new_view_angle_sub_content = view_angle_sub_content + 71 ;
    $("#snapshot3d .view_angle_sub_content").width( new_view_angle_sub_content ) ;
    if ( new_view_angle_sub_content > view_angle_content ){
        $("#snapshot3d .view_angle_content").scrollLeft(new_view_angle_sub_content - view_angle_content);
    }

});






//# sourceURL=ui\dialog/snapshot/snapshot_ui_dialog.js