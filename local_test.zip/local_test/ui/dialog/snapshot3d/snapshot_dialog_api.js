
function Snapshot3dDialogPrompt() {
    var WalkThroughLayerIndex = layer.open({
        type: 1,
        title: '3D动画漫游',
        moveType: 1,
        moveOut: true,
        skin: 'layui-layer-default',
        fix: false,
        shade: false,
        shadeClose: false,
        maxmin: false,
        area: ['405px', '400px'],
        content: $('#snapshot3d')
    });
}


//# sourceURL=ui\dialog/snapshot3d/snapshot__dialog.js