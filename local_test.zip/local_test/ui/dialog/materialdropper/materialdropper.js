var materialDropper_pickStatus = 0;// 0- not pick; 1- already picked
function materialDropper_PickHandler() {
    var picks = api.pickGetPicked();
    var pick = picks && picks[0];
    if (pick) {
        api.actionRun(materialDropper_pickStatus == 0 ? "pick" : "drop", pick);
        if(materialDropper_pickStatus == 0){
        	materialDropper_pickStatus = 1;
        	$("body").css({cursor: ""});
        	$("body").attr("class", "");
          $("body").addClass("dropperCursor");
        }
    }
}

var wallDropper_pickStatus = 0;    // 0- not pick; 1- already picked
function wallDropper_PickHandler() {
    var picks = api.pickGetPicked();
    var pick = picks && picks[0];
    if (pick) {
        api.actionRun(wallDropper_pickStatus == 0 ? "pick" : "drop", pick);
        if(wallDropper_pickStatus == 0){
        	wallDropper_pickStatus = 1;
        	$("body").css({cursor: ""});
        	$("body").attr("class", "");
          $("body").addClass("wallCursor");
        }
    }
}

api.application_ready_event.add(function () {
    api.actionBeginEvent.add(function (action, actionType, args) {
        if (actionType == "MaterialDropper") {
            $("body").css({cursor: ""});
            $("body").attr("class", "");
            $("body").addClass("dropperCursorEmpty");
            materialDropper_pickStatus = 0;
            api.pickChangedEvent.add(materialDropper_PickHandler);
        }else if(actionType == "WallDropper") {
        	  $("body").css({cursor: ""});
        	  $("body").attr("class", "");
            $("body").addClass("wallCursorEmpty");
            wallDropper_pickStatus = 0;
            api.pickChangedEvent.add(wallDropper_PickHandler);
        }
    });
    api.actionEndEvent.add(function (action, actionType, args) {
        if (actionType == "MaterialDropper") {
        	  if(materialDropper_pickStatus == 1){
        	  	$("body").removeClass("dropperCursor");
        	  }else{
        	  	$("body").removeClass("dropperCursorEmpty");
        	  }            
            api.pickChangedEvent.remove(materialDropper_PickHandler);
            materialDropper_pickStatus = 0;
        }else if(actionType == "WallDropper") {
        	  if(wallDropper_pickStatus == 1){
        	  	$("body").removeClass("wallCursor");
        	  }else{
        	  	$("body").removeClass("wallCursorEmpty");
        	  }
            api.pickChangedEvent.remove(wallDropper_PickHandler);
            wallDropper_pickStatus = 0;
        }
    });
});
//# sourceURL=ui\dialog/materialdropper.js