/*-------------- variables --------------------*/
var groupDialog_onOK_callback = undefined;
var groupDialog_onCancel_callback = undefined;


/*-----------------callback and init functions-----------------*/
$("#dialog_group_newgroup").dialog({
    autoOpen: false,
    resizable: false,
    modal: true
}).on("dialogclose", function (event, ui) {
}).on("dialogopen", function (event, ui) {
    var groupName = "Group_" + Math.round(Math.random() * 1000);
    var nameTxtbox = $("#dialog_group_newgroup .group_name");
    nameTxtbox.val(groupName).select().focus();
});
$("#dialog_group_newgroup .ok").on(click, function () {
    $("#dialog_group_newgroup").dialog("close");
    var groupName = $("#dialog_group_newgroup .group_name").val();
    if (groupDialog_onOK_callback)groupDialog_onOK_callback(groupName);
});
$("#dialog_group_newgroup .cancel").on(click, function () {
    $("#dialog_group_newgroup").dialog("close");
    if (groupDialog_onCancel_callback)groupDialog_onCancel_callback();
});

/*-----------------dialog popups-----------------*/

function promptNewGroupDialog(onOK, onCancel) {
    groupDialog_onOK_callback = onOK;
    groupDialog_onCancel_callback = onCancel;

    $("#dialog_group_newgroup").dialog("open");
}

function promptAllGroupDialog(title, onOK, onCancel) {
    groupDialog_onOK_callback = onOK;
    groupDialog_onCancel_callback = onCancel;
}
//# sourceURL=ui\dialog/group/group.js