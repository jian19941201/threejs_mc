/*-------------- variables --------------------*/
var cameraDialog_onOK_callback = undefined;
var cameraDialog_onCancel_callback = undefined;

var cameraNamesSelector = $("#dialog_camera_allcameras .camera_names .cameras");
var cameraRenameInput = $("#dialog_camera_rename .camera-name-content .camera-name-text");
var cameraNamesList=$('.leftcontextmenu .leftcontextmenu_root .leftpopup .tab_container_camera .cameraDetailContent table tbody')

/*-----------------callback and init functions-----------------*/
cameraNamesSelector.selectable();
$("#dialog_camera_rename").dialog({
    autoOpen: false,
    resizable: true,
    width: 250,
    height: 100,
    modal: true
}).on("dialogclose", function (event, ui) {
}).on("dialogopen", function (event, ui) {
    cameraRenameInput.val($(".ui-selected", cameraNamesSelector).html()).select().focus();
});

cameraRenameInput.bind("keypress", function (e) {
    if (event.keyCode == 13) {//回车键
        var activeCameraId = $(".ui-selected", cameraNamesSelector).attr("cid");
        var activeCamera = api.floorplanFilterEntity(function (e) {
            return e.id == activeCameraId;
        });
        activeCamera[0].name = $(this).val();
        $("#dialog_camera_rename").dialog("close");
        allCameraDialogInit();
        allCameraInit();
    }
});
function allCameraDialogInit() {
    var cameras = api.floorplanFilterEntity(function (e) {
        return e.type == "CAMERA";
    });
    var activeCamera = api.documentGetActiveCamera();
    var nameBox = cameraNamesSelector.empty();

    for (var i = 0; i < cameras.length; ++i) {
        var camera = cameras[i];
        var cameraElement = $("<li>").attr({
            cid: camera.id,
            class: "ui-widget-content"
        }).html(camera.name).appendTo(nameBox);
        if (camera.id == activeCamera.id) cameraElement.addClass("ui-selected");
    }

    //init
    //摄像机隐藏与显示功能add by   gaoning 2017.6.19
    var cameraTag = $("#paper2dsvg").find("g[type='CAMERA']");
    var cameraStatus = cameraTag.css("display");
    if (cameraStatus && cameraStatus == "none") //none
    {
        $("#dialog_camera_allcameras .camera_active_ops .camera_active").prop("checked",true);
    } else {
        $("#dialog_camera_allcameras .camera_active_ops .camera_active").prop("checked", false);
    }

    //added by mdx
    if(!activeCamera.lock){
        $("#dialog_camera_allcameras .camera_unlock_ops .unlock").prop("checked",false);
    }else {
        $("#dialog_camera_allcameras .camera_unlock_ops .unlock").prop("checked",true);
    }

}
$("#dialog_camera_allcameras").dialog({
    autoOpen: false,
    resizable: true,
    width: 450,
    height: undefined,
    modal: true
}).on("dialogclose", function (event, ui) {
}).on("dialogopen", function (event, ui) {
    allCameraDialogInit();
});
$("#dialog_camera_allcameras .camera_ops .remove").on(click, function () {
    var selectedCameraId = $(".ui-selected", cameraNamesSelector).attr("cid");
    var activeCamera = api.documentGetActiveCamera();
    api.floorplanFilterEntity(function (e) {
        return e.id == selectedCameraId;
    }).forEach(function (c) {
        delCustomCamera(c,activeCamera)
    });
    allCameraDialogInit();
});
$("#dialog_camera_allcameras .camera_ops .rename").on(click, function () {
    $("#dialog_camera_rename").dialog("open");
});

//激活摄像机
$("#dialog_camera_allcameras .camera_ops .active").on(click, function () {
    var activeCameraId = $(".ui-selected", cameraNamesSelector).attr("cid");
    $("#dialog_camera_allcameras").dialog("close");
    //api.documentSetActiveCameras([activeCameraId]);
    api.floorplanFilterEntity(function (e) {
        return e.id == activeCameraId;
    }).forEach(function (c) {
        setCameraState(c)
    });
});

//摄像机隐藏与显示功能add by   gaoning 2017.6.19
$("#dialog_camera_allcameras .camera_active_ops .camera_active").on(click, function (e) {

    var cameraTag = $("#paper2dsvg").find("g[type='CAMERA']");
    var cameraTagLock = $("#paper2dsvg").find("g[type='LOCKCAMERA']");
    if ($(this).is(":checked")) {
        cameraTag.css("display", (cameraTag.css("display") == "none" ? "block" : "none"));
        cameraTagLock.css("display", (cameraTagLock.css("display") == "none" ? "block" : "none"));
    } else {
        cameraTag.css("display", (cameraTag.css("display") == "none" ? "block" : "none"));
        cameraTagLock.css("display", (cameraTagLock.css("display") == "none" ? "block" : "none"));
    }
    tool_tip_bnt && (tool_tip_bnt.model.type=='CAMERA' && cameraTag.css("display") == "none" ? tool_tip_bnt.destroy() :$('#ui_toolTipBnt').length>0 && tool_tip_bnt.init())
});

//上锁和解锁
function luckAndUnlock(){
    var activeCamera = api.documentGetActiveCamera();
    var cameraTag = $("#paper2dsvg").find("image[cid="+activeCamera.id+"]");
    var cameraTag2 = $("#paper2dsvg").find("image[did="+activeCamera.id+"]");
    var cameraTagLock = $("#paper2dsvg").find("g[type='LOCKCAMERA']");
    var cameraSvg = $("#paper2dsvg").find("g[type='CAMERA']");
    if(activeCamera.lock){ //判断摄像机是否已上锁
        //activeCamera.lock=false;
        $(cameraTag2).css("cursor","move");
    }else {
        //activeCamera.lock=true;
        $(cameraTag2).css("cursor","default");
        if(cameraTag.css("display") != "none")cameraTagLock.css("display","block");
    }
    lockAdnUnlockCamera(activeCamera.id,activeCamera,activeCamera.lock?'lock':'unlock');
    tool_tip_bnt && (
        cameraSvg.css("display") != "none" && (tool_tip_bnt.model.id==activeCamera.id ?(tool_tip_bnt.update('group_lock',tool_tip_bnt.model.lock?1:0)):tool_tip_bnt.destroy())
    );
    // allCameraInit();
    // tool_tip_bnt && (tool_tip_bnt.model.type=='CAMERA' && (tool_tip_bnt.conf.lock.show=activeCamera.lock?false:true,
    //     tool_tip_bnt.conf.unlock.show=activeCamera.lock?true:false,
    //     cameraSvg.css("display") != "none" && ($('#ui_toolTipBnt').length>0 && tool_tip_bnt.init()))
    // )
}

//摄像机解鎖
$("#dialog_camera_allcameras .camera_unlock_ops .unlock").on(click, function (e) {
    var lockchecked = $(this).is(":checked");
    if(lockchecked){
        luckAndUnlock();
    }else {
        luckAndUnlock();
    }


});

function newAllCameraDialogInit() {
    var cameras = api.floorplanFilterEntity(function (e) {
        return e.type == "CAMERA";
    });
    var activeCamera = api.documentGetActiveCamera();
    var nameBox = cameraNamesList.empty();
    //摄像机隐藏与显示
    var isHide=false;
    var cameraTag = $("#paper2dsvg").find("g[type='CAMERA']");
    var cameraStatus = cameraTag.css("display");
    if(cameraStatus && cameraStatus == "none")isHide=true;
    for (var i = 0; i < cameras.length; ++i) {
        var camera = cameras[i];
        var active=(camera.id == activeCamera.id?'active':'');
        var lock=(camera.lock)?"lock":"unlock";
        var show=(camera.id == activeCamera.id && isHide)?"hide":"show";
        // var cameraElement = $("<tr>").attr({
        //     cid: camera.id,
        //     class:camera.id == activeCamera.id?"uiSelected":""
        // }).html('<td class="active"><span class="act '+active+'"></span></td> <td class="cameraName"><input type="text" value="'+camera.name+'"></td> <td class="lock"><span class="'+lock+'"></span></td> <td class="delete"><span class="del"></span></td><td><span class="'+show+'"></span></td></tr>').appendTo(nameBox);
        var cameraElement = $("<tr>").attr({
            cid: camera.id,
            class:camera.id == activeCamera.id?"uiSelected":""
        }).html('<td class="active"><span class="act '+active+'"></span></td> <td class="cameraName"><input type="text" value="'+camera.name+'"></td> <td class="lock"><span class="'+lock+'"></span></td> <td class="delete"><span class="del"></span></td></tr>').appendTo(nameBox);
    }
}
/*-----------------dialog popups-----------------*/

function promptAllCameraDialog(title, onOK, onCancel) {
    cameraDialog_onOK_callback = onOK;
    cameraDialog_onCancel_callback = onCancel;

    $("#dialog_camera_allcameras").dialog("open");
}


//# sourceURL=ui\dialog/camera/camera.js