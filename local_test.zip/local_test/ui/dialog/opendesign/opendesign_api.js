var openDesign_designMeta;

function openDesign(designMeta, onSuccess, onFail) {// designMeta must at least have one field : "designId"
    if (!designMeta || !designMeta.designId) {
        layer.alert("打开设计，至少需要包含designId", {
            title: '提示',
            skin: 'layui-layer-default'
        });
        if (onFail)onFail();
        return;
    }
    openDesign_designMeta = designMeta;

    var servicePrefix = api.getServicePrefix("design");

    api.getServiceJSONResponsePromise({
        type: 'get',
        url: servicePrefix + "/getDesignById",
        cache: false,
        data: designMeta
    }).then(function (designres) {
        if (designres.length > 0) {
            openDesign_designMeta = $.extend(true, {}, designMeta, designres[0]);
            getTextDataFromAliyun("design", designres[0].did, "design.content", function (data) {
                if (typeof readRenderParamDataFromSaved != "undefined") readRenderParamDataFromSaved(data);
                api.documentLoad(data);
            });
            loadRenderData(designres[0].did);
            if (onSuccess)onSuccess(designMeta);
        }

    }).catch(function (e) {
        if (onFail)onFail(e);
        layer.alert('send getDesignById request to server failed!! ', {
            title: '提示',
            skin: 'layui-layer-default'
        });
    });
}

function openDesignByExtra(designMeta, onSuccess, onFail) {// designMeta must at least have one field : "designId"
    if (!designMeta || !designMeta.dtype || !designMeta.extra) {
        layer.alert("打开设计，至少需要包含dtype和extra", {
            title: '提示',
            skin: 'layui-layer-default'
        });
        if (onFail)onFail();
        return;
    }
    openDesign_designMeta = designMeta;

    var servicePrefix = api.getServicePrefix("design");
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: servicePrefix + "/getDesignByExtra",
        cache: false,
        data: designMeta
    }).then(function (designres) {
        if (designres.length > 0) {
            openDesign_designMeta = $.extend(true, {}, designMeta, designres[0]);
            delete openDesign_designMeta.thumbnail;
            delete openDesign_designMeta.content;

            getTextDataFromAliyun("design", designres[0].did, "design.content", function (data) {
                if (typeof readRenderParamDataFromSaved != "undefined") readRenderParamDataFromSaved(data);
                api.documentLoad(data);
            });
            loadRenderData(designres[0].did);
            if (onSuccess)onSuccess(designMeta);
        }else{//直接传底图url生成底图
            oceanoImportUnderlayChanged();
        }
    }).catch(function (e) {
        if (onFail)onFail(e);
        layer.alert('send getDesignByExtra request to server failed!! ', {
            title: '提示',
            skin: 'layui-layer-default'
        });
    });
}

function setOpenedDesignMeta(designMeta) {
    openDesign_designMeta = designMeta;
}

function getOpenedDesignMeta() {
    return openDesign_designMeta;
}

function loadRenderData(did) {
    api.getServiceJSONResponsePromise({
        type: 'get',
        url: api.getServicePrefix("design") + "/getDesignRenderData",
        cache: false,
        data: {"did": did}
    }).then(function (res) {
        if (!res || res.length == 0) return;
        //$('#renderId .renderResultsItemContent').empty();
        renderview_jobidArray = [];
        res.forEach(function (renderobj, index) {
            var imgUrl,thumbImgUrl;
            if(renderobj.jobstatus == 1 || renderobj.jobstatus == 0){
                var extra=JSON.parse(renderobj.renderoption).extra;
                addRenderingJobTaskToList(renderobj.jobid,extra.previewpic,extra.roomName);
                renderview_inprogress_queryJobStatus(renderobj.jobid);
            }
            else{
                imgUrl = api.catalogGetFileUrl("render", renderobj.jobid, "render");
                thumbImgUrl = api.catalogGetFileUrl("render", renderobj.jobid, "thumb");
                if(renderobj.jobstatus == 2)
                    addJobTaskToList(renderobj, imgUrl, thumbImgUrl);
            }

        //    addJobTaskToList(renderobj, imgUrl, thumbImgUrl);
        });
    }).catch(function (e) {
        layer.alert('send getDesignRenderData request to server failed!! ', {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
    });

}
//# sourceURL=ui\dialog/opendesign_api.js