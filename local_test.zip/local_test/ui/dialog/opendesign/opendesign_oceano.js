﻿/*打开云设计弹出层*/
var openCloudDesignPanelPrompt = function () {
    var cloudDesignDialogIndex = undefined;

    function listDialog() {
        var dialogWidth = 730;
        cloudDesignDialogIndex = layer.open({
            type: 1,
            title: '云设计列表',
            move: false,
            skin: 'layui-layer-default',
            fix: false,
            shadeClose: false,
            maxmin: false,
            area: [dialogWidth + 'px', undefined],
            content: $('#cloudDesignPanel'),
            success: function (layero, index) {
                $("#cloudDesignPanel").parents(".layui-layer-default").draggable();
            }
        });

        //页面一打开就执行弹层
        layer.ready(function () {
            Util.processDropdownlist();
        });

        loadCloudDesignData(0, 6);
    }

    function loadCloudDesignData(viewindex, viewsize) {
        var $data_container = $("#cloudDesignPanel .data_area .data_container");
        $data_container.empty();
        var extra = "";

        if (ui.getOpenedDesignMeta() && ui.getOpenedDesignMeta().userLoginId) {
            extra = '"userloginid":"' + ui.getOpenedDesignMeta().userLoginId + '"';
        }
        //DEBUG_BEGIN
        extra = '"userloginid":"' + "shihuaitong" + '"';
        //DEBUG_END
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: api.getServicePrefix("design") + "/getDesignList",
            cache: false,
            data: {
                viewindex: viewindex,
                viewsize: viewsize,
                extra: extra,
                name: $("#design_name").val()
            }
        }).then(function (res) {
            res.forEach(function (obj, index) {
                var $li_eliment = $("<li>").addClass("data-item").attr({
                    "data-product-id": obj.did,
                    "data-product-dtype": obj.dtype
                }).on("dblclick", function (e) {
                    openProduct.call(null, obj.did);
                }).appendTo($data_container);

                var $image_container = $("<div>").addClass("image-container").appendTo($li_eliment);

                getTextDataFromAliyun("design", obj.did, "design.thumbnail", function (data) {
                    var thumb_img_src = "";
                    if (obj.thumbnail_type == '3d') thumb_img_src = data;
                    if (obj.thumbnail_type == 'render') {
                        thumb_img_src = api.catalogGetFileUrl("render", data, "render");
                    }
                    $("<img>").addClass("thumb_img").attr({"src": thumb_img_src}).appendTo($image_container);
                });

                $("<div>").addClass("thumb_mask").appendTo($image_container);
                var $item_info = $("<div>").addClass("item-info").appendTo($li_eliment);
                $("<div>").addClass("name").text(obj.name).appendTo($item_info);
                $("<div>").addClass("remove").text("")
                    .on("click", function (e) {

                        layer.confirm('确定要删除吗？', {
                            btn: ['确定', '取消'],
                            shade: 0.3,
                            skin: 'layui-layer-default',
                            title: '提示'
                        }, function (index) {
                            $.ajax({
                                type: 'post',
                                url: appSettings.designjavadomain + '/control/ajaxCrossDomainDeleteTableDesign',
                                cache: false,
                                data: {"designId": obj.did}
                            }).done(function (data) {
                                if (!data || !data.returnValue) {
                                    fail();
                                    return;
                                }
                                var status = data.returnValue.status;
                                if (status == 'success') {
                                    success();
                                    $li_eliment.remove();
                                } else if (status == 'error') {
                                    fail();
                                }
                            }).fail(function () {
                                fail();
                            });
                            layer.close(index);
                        }, function () {

                        });

                        function success() {
                            layer.alert('删除成功！', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                                layer.close(index);
                            });
                        }

                        function fail() {
                            layer.alert('删除失败！', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                                layer.close(index);
                            });
                        }

                    })
                    .appendTo($item_info);
            });
            if (res && res.length > 0) {
                //加入分页的绑定
                $("#cloudDesignPanel .pagination").show();
                $("#cloudDesignPanel .pagination").pagination(res[0].count, {
                    callback: function (page_index, jq) {
                        $openButton.addClass('disabled');
                        loadCloudDesignData(page_index, 6)
                    },
                    prev_text: '<',
                    next_text: '>',
                    items_per_page: 6,
                    num_display_entries: 5, //连续分页主体部分显示的分页条目数
                    current_page: viewindex,
                    num_edge_entries: 3 //两侧显示的首尾分页的条目数
                });
            } else {
                $("#cloudDesignPanel .pagination").hide();
            }

        }).catch(function (e) {
            layer.alert('send getDesignList request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }


    function openProduct(id) {
        $openButton.addClass('disabled');
        var designMeta = ui.getOpenedDesignMeta();
        if (!designMeta) {
            designMeta = {"designId": id};
        } else {
            designMeta.designId = id;
        }
        openDesign(designMeta, function () {
            layer.close(cloudDesignDialogIndex);
        });
        loadRenderData(id);
    }

    var $pane = jQuery('#cloudDesignPanel');
    var $openButton = $pane.find('.openButton');
    var $applyButton = $pane.find('.applyButton');

    $pane.on('click', '.data-item', function (e) {
        var $item = jQuery(e.currentTarget);
        if (!$item.hasClass('.selected-product')) {
            // select product
            $pane.find('.selected-product').removeClass('selected-product');
            $item.addClass('selected-product');
            // set open button state
            $openButton.removeClass('disabled');
            $applyButton.removeClass('disabled');
        }
    });

    $openButton.on('click', function (e) {
        // get selectd product id
        var prodId = $pane.find('.selected-product').attr('data-product-id');
        openProduct.call(null, prodId);
    });

    $applyButton.on('click', function (e) {
        var prodId = $pane.find('.selected-product').attr('data-product-id');
        $applyButton.addClass('disabled');
        clickModelRoomImg("apply", prodId);
        layer.close(cloudDesignDialogIndex);
    });

    $pane.on('click', '.openLocalFileButton', function (e) {
        $("#fileInputOpenLocal").trigger("click");
        layer.close(cloudDesignDialogIndex);
    });

    $pane.on('click', '.queryButton', function (e) {
        loadCloudDesignData(0, 6);
    });


    return listDialog;
}();

//# sourceURL=ui\dialog/opendesign/opendesign_oceano.js
