/*打开云设计弹出层*/
var openCloudDesignPanelPrompt = function () {
    var cloudDesignDialogIndex = undefined;

    function listDialog() {
        var dialogWidth = $(window).width() - 10;
        var dialogHeight = $(window).height() - 10;
        cloudDesignDialogIndex = layer.open({
            type: 1,
            title: '云设计列表',
            moveType: 1,
            moveOut: true,
            skin: 'layui-layer-default',
            fix: false,
            //closeBtn: false,
            shadeClose: false,
            maxmin: false,
            area: [dialogWidth + 'px', dialogHeight + 'px'],
            content: $('#cloudDesignPanel')
        });

        $(window).bind('resize', function () {
            cloudDesignDialogIndex && layer.full(cloudDesignDialogIndex);
        });
        loadCloudDesignData();
        calculateHeight();
    }


    function loadCloudDesignData() {
        var servicePrefix = api.getServicePrefix("design");
        var fileServer = api.getServicePrefix("file");
        var url = servicePrefix + "/getDesignList";
        var gridtable = $("#cloudDesignPanel .data_area .gridtable");
        gridtable.html("");
        $("<tr>").append($("<th style='width:20px;'>").text("序号")).append($("<th style='width:80px;'>").text("缩略图")).append($("<th>").text("设计名称")).append($("<th style='width:105px;'>").text("创建时间")).appendTo(gridtable);

        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: false,
            data: {}
        }).then(function (res) {
            res.forEach(function (obj, index) {
                $("<tr>").append($("<td>").addClass("center_td").text(index + 1))
                    .append($("<td>").addClass("width100").append($("<div>").addClass("width100").html(obj.thumbnail)))
                    .append($("<td>").text(obj.name).on("click", function (e) {

                        openDesign({"designId": obj.did});
                        loadRenderData(obj.did);
                        /*$('#renderId .renderResultsItemContent').empty();
                         renderview_jobidArray = [];
                         obj.children.forEach(function (renderobj) {
                         var imgUrl = api.catalogGetFileUrl("render", renderobj.jobid, "render");
                         var thumbImgUrl = api.catalogGetFileUrl("render", renderobj.jobid, "thumb");
                         addJobTaskToList(renderobj, imgUrl, thumbImgUrl);
                         });*/
                        layer.close(cloudDesignDialogIndex);
                    }).addClass("click_td")
                ).append($("<td>").text(obj.createtime))
                    .appendTo(gridtable);
            });


        }).catch(function (e) {
            layer.alert('send getDesignList request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }

    /*计算数据区域高度*/
    function calculateHeight() {
        var cloudDesignPanelHeight = $('#cloudDesignPanel').outerHeight(true);
        var queryAreaHeight = $('#cloudDesignPanel .query_area').outerHeight(true);
        var paginationAreaHeight = $('#cloudDesignPanel .pagination').outerHeight(true);
        var dataAreaHeight = cloudDesignPanelHeight - queryAreaHeight - paginationAreaHeight;
        /*内容体高度。减去border的上下框各1像素 margin-bottom的5像素*/
        $('#cloudDesignPanel .data_area').innerHeight(dataAreaHeight - 7);
    }


    var pageIndex = 0;
    //加入分页的绑定
    $("#cloudDesignPanel .pagination").pagination(30000, {
        callback: pageselectCallback,
        prev_text: '< 上一页',
        next_text: '下一页 >',
        items_per_page: 50,
        num_display_entries: 5,
        current_page: pageIndex,
        num_edge_entries: 3
    });

    function pageselectCallback(page_index, jq) {
        log(page_index);
    }

    return listDialog;
}();

//# sourceURL=ui\dialog/opendesign.js