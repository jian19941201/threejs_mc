/*生成图片上传规则*/
var osnfuzzy_slider=void 0;
var upload_rule = '<div class="upload_rule">';
upload_rule+='<div class="tit">上传图片提示</div>';
upload_rule+='<span class="tip">拼花素材仅可应用在自由绘制的区域上</span>';
upload_rule+='<div class="original"><img class="original_img"></div>';
upload_rule+='</div>';
$("#uploadMaterial_oceano,#uploadCustom_tile").append(upload_rule);

/*图片上传规则hover*/
$(".uploadMaterial_img .tips").hover(function(){
        $(".upload_rule").css("display","block")
    },function(){
        $(".upload_rule").css("display","none")
    }
);
$('#loadingCustomTile').dialog({
    width:550,
    autoOpen: false,
    resizable: true,
    modal: false,
    dialogClass:"ui_whiteStyle",
    closeOnEscape:false,
    open:function(){
        $('[aria-describedby="loadingCustomTile"] .ui-dialog-titlebar-close').hide();
    },
    close:function(){
        $('#loadingCustomTile .progress-bar').css('width','0%')
        $('#loadingCustomTile  .progress-value').html('0%');
    }
})
$('#loadingCustomTile').on('click','.progress-close',function(){
    osnfuzzy && (osnfuzzy.close = true);
    if($('#edit_parquet_dialog').dialog("isOpen")){
        $('#edit_parquet_dialog').dialog("close")
    }
    $('#loadingCustomTile').dialog('close')
})
$('#edit_parquet_dialog').dialog({
    width:700,
    height:780,
    autoOpen: false,
    resizable: true,
    modal: false,
    closeOnEscape:false,
    dialogClass:"ui_whiteStyle",
    open:function(){
        $('.edit_param .fill_state span').removeClass('active')
        $('.edit_param .fill_state').show()
        $('.edit_color').removeClass('second_step').addClass('first_step').find('ul li').show();
        //$('.edit_tips .fill_area').html('0');
    },
    close:function(){
        $('#edit_parquet_content').empty();
        $('.edit_color li').empty();
        //osnfuzzy.notSaveBtnStyle();
        osnfuzzy.data.step=3;
        osnfuzzy.changButtonSecondStyle();
        osnfuzzy.data.step=0;
        osnfuzzy = void 0;
        osnfuzzy_slider = void 0;
    },
    buttons:{
        "下一步":function(){
            if(osnfuzzy && osnfuzzy.data.step==1){
                osnfuzzy.secondStep();
                osnfuzzy.layerCanvas();
                saveLogToServer([{"key": "action", "value": "editColorCADParquet"}]);
            }else if(osnfuzzy.data.step==2||osnfuzzy.data.step==3){
                osnfuzzy.firstStep()
            }/*else{
                layer.msg('请先填充完图形')
            }*/
        },
        "保存拼花":function(){
            if(osnfuzzy && osnfuzzy.data.step!=3){
                layer.msg('请先贴完砖')
            }else{
                saveLogToServer([{"key": "action", "value": "editTileCADParquet"}]);
                saveCustomTile();
            }
        }
    }
})
$('.fill_state').on('click','div',function(){
    var state = $(this).attr('state');
    if(!state)return;
    var is_active = $(this).find('span:eq(0)').attr('class');
    if(is_active=='active'){
        $(this).find('span:eq(0)').attr('class','');
        osnfuzzy.state = 0;
    }else{
        $('.fill_state div').find('span:eq(0)').attr('class','');
        $(this).find('span:eq(0)').attr('class','active');
        osnfuzzy.state = state;
    }
})
$('.edit_color li').on('click',function(){
    if(osnfuzzy.data.step==0 || osnfuzzy.data.step==1 ){
        $('.edit_color li').removeClass('active');
        $('.edit_color li').css('border-color','rgb(170, 170, 170)');
        $(this).addClass('active');
        $(this).css('border-color','#000');
        $('#edit_parquet_content').attr('class','').addClass($(this).attr("type")+'Cursor')
    }else{
        osnfuzzy.FillLayerTile($(this).css('background-color'))
    }

})
function LoadOsnfuzzySlider(){
    //var len = osnfuzzy.data.ignoreBorder?osnfuzzy.data.len:osnfuzzy.data.len-1;
    //$('.edit_tips .all_area').html(len)
    var rangeMin = osnfuzzy.data.range[0],
        rangeMax = osnfuzzy.data.range[1],
        beforeVul = 0,add=0,sub=0;
    osnfuzzy_slider = $('.parquet_range .range').slider({
        orientation:"vertical",
        range:"min",
        min:Math.floor(rangeMin*10),
        max:Math.floor(rangeMax*10),
        value:Math.floor(rangeMin*10),
        slide:function(event,ui){
            var time = Math.abs((beforeVul - ui.value) *0.1);
            var scale = osnfuzzy.data.scale;
            if(ui.value>Math.floor(osnfuzzy.data.scale*10)){
                osnfuzzy.data.scale=osnfuzzy.data.scale+time;
            }else{
                osnfuzzy.data.scale=osnfuzzy.data.scale-time;
            }
            osnfuzzy.data.scale=(osnfuzzy.data.scale>osnfuzzy.data.range[1])?osnfuzzy.data.range[1]:(osnfuzzy.data.scale);
            osnfuzzy.data.scale=(osnfuzzy.data.scale>osnfuzzy.data.range[0])?(osnfuzzy.data.scale):osnfuzzy.data.range[0]
            osnfuzzy.redraw(osnfuzzy.data.scale,scale)
            beforeVul = ui.value;
        }
    })
    $('.parquet_range .add').on('click',function(){
        var sval=osnfuzzy_slider.slider('value');
        osnfuzzy_slider.slider('value',sval+1);
        var scale = osnfuzzy.data.scale;
        osnfuzzy.data.scale = (osnfuzzy.data.scale+0.1>osnfuzzy.data.range[1])?osnfuzzy.data.range[1]:(osnfuzzy.data.scale+0.1);
        osnfuzzy.redraw(osnfuzzy.data.scale,scale)
        return;
    })
    $('.parquet_range .sub').on('click',function(){
        var sval=osnfuzzy_slider.slider('value');
        osnfuzzy_slider.slider('value',sval-1);
        var scale = osnfuzzy.data.scale;
        osnfuzzy.data.scale = (osnfuzzy.data.scale-0.1>osnfuzzy.data.range[0])?(osnfuzzy.data.scale-0.1):osnfuzzy.data.range[0];
        osnfuzzy.redraw(osnfuzzy.data.scale,scale)
        return;
    })
    $('.parquet_range .position').on('click',function(){
        osnfuzzy.redraw(osnfuzzy.data.range[0],osnfuzzy.data.scale)
        osnfuzzy_slider.slider('value',Math.floor(osnfuzzy.data.range[0]*10));
    })

    /*$('.edit_tips input').on('click',function(){
        osnfuzzy.fillAllArea();
    })
    $('.edit_tips button').on('click',function(){
        if(osnfuzzy.data.notFillLayer.length>0){
            osnfuzzy.focusFirstAreaLight();
        }
    })*/
}
$('.edit_color li').on('mouseout','.img_container img',function(e){
    if($('#osnFyzzyTips').length==1){
        $('#osnFyzzyTips').remove();
    }
})
$('.edit_color li').on('mouseenter','.img_container img',function(e){
    if((osnfuzzy.data.step==2||osnfuzzy.data.step==3) && $('#osnFyzzyTips').length==0 && Object.keys(osnfuzzy.data.selectTile).length!=0){
        $('body').append(
            $('<div>',{id:"osnFyzzyTips"})
                .append($("<div>",{style:"background:url(http://pic.oceano.com.cn/h5filesystem/products/"+osnfuzzy.data.selectTile.pid+"/thumb.jpg@38w)"})))
    }
})
$('.edit_color li').on('mouseout','.img_container div',function(e){
    $('.edit_color li').css('border-color','#aaa')
    if ($('#customparquetZoom').length) {
        $('#customparquetZoom').remove();
    }
})
$('.edit_color li').on('mousemove','.img_container img',function(e){
    if(osnfuzzy.data.step==2||osnfuzzy.data.step==3){
        if($('#osnFyzzyTips').length==1){
            $('#osnFyzzyTips').css({
                background:$(this).closest('li').css('background-color'),
                left: e.clientX + 15,
                top: e.clientY + 20
            })
        }
    }
})
$('.edit_color li').on('mouseenter','.img_container div',function(e){
    if(osnfuzzy.data.step==2||osnfuzzy.data.step==3){
        $(this).closest('li').css("border-color",'rgb(255, 120, 54)');
        var p = osnfuzzy.data.tile[$(this).closest('li').css('backgroundColor')];
        var product_size = (Math.ceil(p.xlen * 1000) / 1000) + "x" + (Math.ceil(p.ylen * 1000) / 1000);
        if (p.zlen > 0) product_size += "x" + (Math.ceil(p.zlen * 1000) / 1000);
        var product_brand = fakeUnnicodeToChinese(p.productbrand);
        if ('' == product_brand) product_brand = "无";
        var usagecount = window.swapUsagecount[p.pid];
        var tips=$('<div>',{id:"customparquetZoom",class:'product-zoom'})
            .append($('<img>',{class:"prodimg product-zoom-img",src:ui.catalogGetFileUrl("product", p.pid, "iso")}))
            .append($('<div>',{class:'product-short-info'})
                .append($('<div>',{class:'name',text:"【" + (p.model || "") + p.title + "】"}))
                .append($('<div>',{class:'size',text:"尺寸：" + product_size + "(m)"}))
                .append($('<div>',{class:'size',text:"品牌：" + product_brand}))
                .append($('<div>',{class:'hotPoint',text:"热度：" + usagecount}))
            )
        $('body').append(tips);
    }
})
$('.edit_color li').on('mousemove','.img_container div',function(e){
    if(osnfuzzy.data.step==2||osnfuzzy.data.step==3){
        if($('#customparquetZoom').length) {
            var top = e.clientY + 20+380,h=0;
            if(top>$('body').height()){h=$('body').height()-top;}
            $('#customparquetZoom').css({
                display: "block",
                zIndex: 1002,
                left: e.clientX + 15,
                top: e.clientY + 20 + h
            })
        }
    }
})
$(".edit_color.first_step ul li").tooltip({
    position:{
        my:"center bottom+40",
        at:"center bottom"
    },
    content:function(){
       return $(this).attr('title');
    }
});
function saveCustomTile(){
    $('[aria-describedby="edit_parquet_dialog"]').hide();
    $('.edit_color li').show();
    $('#loadingCustomTile .progress-bar').css('width','0%')
    $('#loadingCustomTile  .progress-value').html('0%');
    $('#loadingCustomTile').dialog('open').dialog({title:'正在上传'});
    loading_setInterval=setInterval(function(){
        var num = parseInt( $('#loadingCustomTile  .progress-value').html());
        if(num >= 20){
            clearInterval(loading_setInterval)
        }else{
            var tmp = Math.floor(Math.random()*10%2)+1;
            $('#loadingCustomTile .progress-bar').css('width',(num+tmp)+'%')
            $('#loadingCustomTile  .progress-value').html((num+tmp)+'%');
        }
    },400)
    api.getServiceJSONResponsePromise({
        url: api.getServicePrefix("file") + "/uploadFile" + "?id=" +  $('.edit_parquet_content').attr('pid') + "&category=product&type=dwg",
        type: "post",
        cache: false,
        contentType: false,
        processData: false,
        data: osnfuzzy.dwg
    }).then(function (res) {
        if(res.error==0){
            var countUpoad=0,uploadSueecss=true;
            if(!osnfuzzy)return;
            var conf = osnfuzzy.getTileConfig();
            for(var i=0;i<Object.keys(conf.img).length;i++){
                api.getServiceJSONResponsePromise({
                    url: api.getServicePrefix("file") + "/uploadImg" + "?id=" +  $('.edit_parquet_content').attr('pid') + "&category=product&type="+Object.keys(conf.img)[i],
                    type: "post",
                    cache: false,
                    async:false,
                    contentType: false,
                    processData: false,
                    data: conf.img[Object.keys(conf.img)[i]]
                }).then(function (res) {
                    $('#loadingCustomTile .progress-bar').css('width',countUpoad*10+20+'%')
                    $('#loadingCustomTile  .progress-value').html(countUpoad*10+20+'%');
                    countUpoad++;
                    if(res.error==0){
                        if(countUpoad==Object.keys(conf.img).length){
                            api.getServiceJSONResponsePromise({
                                url: (  api.getServicePrefix("customcatalog") )+ "/checklogin",
                                type: "POST",
                                data: {
                                    "globalUserLoginId":globalUsrObj.globalUserLoginId,
                                    "globalAccessTokenValue":globalUsrObj.globalAccessTokenValue
                                }
                            }).then(function (resp) {
                                if(resp.msg=="existsUser"){//注册用户
                                    var customTileCatalogServer = api.getServicePrefix("customcatalog"),saveCustomTileUrl=customTileCatalogServer+"/addCustomParquet/";
                                    var $objData={
                                        "pid":$('.edit_parquet_content').attr('pid'),
                                        "title":osnfuzzy.conf.title,
                                        "xlen":osnfuzzy.conf.xlen,
                                        "ylen":osnfuzzy.conf.ylen,
                                        "extra":conf.conf,
                                        "globalPartyId":globalUsrObj.globalPartyId};
                                    api.getServiceJSONResponsePromise({
                                        url: saveCustomTileUrl,
                                        type: "POST",
                                        cache: false,
                                        data: $objData
                                    }).then(function (r) {
                                        layer.msg("保存成功");
                                        layer.closeAll();
                                        $('#loadingCustomTile .progress-bar').css('width','100%')
                                        $('#loadingCustomTile  .progress-value').html('100%');
                                        $('#edit_parquet_dialog').dialog('close')
                                        $('#edit_parquet_content').empty();
                                        $('.edit_color li').empty();
                                        if(osnfuzzy){
                                            //osnfuzzy.notSaveBtnStyle();
                                            osnfuzzy.data.step=3;
                                            osnfuzzy.changButtonSecondStyle();
                                            osnfuzzy.data.step=0;
                                        }
                                        setTimeout(function(){
                                            $('#loadingCustomTile').dialog('close')
                                        },500)
                                    })
                                }else{
                                    $material.tips("请登录");
                                }
                            });
                        }
                    }else{
                        uploadSueecss=false
                    }
                })
                if(!uploadSueecss){
                    layer.msg('保存失败，请重试')
                    break;
                }
            }
        }else{
            layer.msg('保存失败，请重试')
        }
    });
}
//# sourceURL=openuploadmaterial_oceano.js