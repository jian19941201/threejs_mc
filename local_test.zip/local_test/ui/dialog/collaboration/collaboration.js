var CollaborationCallbacks = {};
var CollaborationSocket = undefined;
var CollaborationOperation = "";

function startCollaborationMode() {
    if (!CollaborationSocket) {
        var server = api.getServicePrefix("share");
        if (!server) {
            log("SHARE SERVER config could not be reached!!");
            return;
        }
        if (server && typeof io != "undefined") {
            var socket = CollaborationSocket = io.connect(server, {machineId: api.uuid()});
            if (!socket) {
                log("SHARE SERVER create error");
                return;
            }
            socket.on("connect", function () {
                log("socket connected");
                //socket.emit("login", desc);
                //if (onConnect)onConnect(socket, desc);
            });

            socket.on("disconnect", function () {
                log("socket disconnected")
                //socket.emit("logout", desc);
                //if (onDisconnect)onDisconnect(socket, desc);
                socket = undefined;

            });

            socket.on("login_ready", function (data) {
                log("login_ready=" + JSON.stringify(data));
                if (!socket) {
                    log("error: socket is empty.");
                    return;
                }
                if (CollaborationOperation == "create") {
                    var shareid = data.shareid;
                    bomDialogPrompt("http://" + location.hostname + ":81/cabinet?shareid=" + shareid);
                    CollaborationSendModelData(shareid);
                } else if (CollaborationOperation == "continue") {
                    socket.emit("need_update", {shareid: data.shareid, role: "master", socketid: socket.id});
                }
            });
            //socket.on("update_ready", function (data) {
            //    log("update_ready=" + JSON.stringify(data));
            //});
            socket.on("update", function (data) {
                log("update=" + JSON.stringify(data));
                if (data.role == "master")return;
                var shareid = data.shareid;

                // todo: get slave data and update room content.
            });
        }
    }
}
//DEBUG_BEGIN
//setTimeout(startCollaborationMode, 2000);// BAD!!
//DEBUG_END

function popCollaborationDialog(model, operation, onOK, onCancel) {
    if (!model || typeof io == "undefined")return;
    CollaborationCallbacks[model.id] = {onOK: onOK, onCancel: onCancel};

    if (model.type == "FLOOR") {
        roomCollaborationOKClick(model, operation);// todo call this after popup dialog and click OK.
        var callbacks = CollaborationCallbacks[model.id];
        callbacks && callbacks.onOK && callbacks.onOK();
    }
}
function CollaborationSendModelData(modelId) {
    var models = api.floorplanFilterEntity(function (e) {
        return e.id == modelId;
    });
    if (!models || models.length == 0) {
        alert("CAN not find this room:" + modelId);
        return;
    }
    var model = models[0];

    // room data:
    var roomData = api.threeExport("ROOM3D", {model: model});
    //roomData = "long json string stand for room 3d data. ";
    var shareid = modelId;
    var socket = CollaborationSocket;
    socket.emit("update", {
        role: "master",
        shareid: shareid,
        static: roomData,
        socketid: socket.id
    });
}

function roomCollaborationOKClick(model, operation) {
    log("--start room collaboration!!");
    var socket = CollaborationSocket;
    if (!socket) {
        alert("当前不是协作模式.");
        return;
    }

    // todo: check if this room is normalized....

    var shareid = model.id;

    CollaborationOperation = operation;
    if (operation == "create" || operation == "continue") {
        socket.emit("login", {shareid: shareid, role: "master", socketid: socket.id});
    }
    if (operation == "update") {
        CollaborationSendModelData(model.id);
    }


}


//# sourceURL=ui/collaboration.js