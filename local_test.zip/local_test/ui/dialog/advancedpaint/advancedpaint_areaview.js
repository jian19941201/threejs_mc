//var advancedPaintWall = undefined;// this will be initialed when this dialog opened..
//var advacedPaintWallOption = undefined;// this will be initialed when this dialog opened..
//var advacedPaintView = undefined;// this will be initialed when application startup.
//
//    advancedPaintPrompt({model: db[wallid], opt: {src: "3d", elementName: "left"}});

/*******************************************************************/

function ViewArea(opt) {// opt:{shape:"rect",level:0} or {model:modelArea}
    var svgView = advacedPaintView;
    var context = svgView.context;
    var areaLayer = svgView.layers["AREA"];
    var self = this;

    // exposure APIs and data:
    this.model = opt.model;
    this.rot = undefined;
    this.level = this.model ? this.model.level : ( opt.level || 0); // 0~10
    var shape = this.shape = this.model ? (this.model.type == "RECTAREA3D" ? "rect" : "round") : (opt.shape || "rect"); // ["rect"|"round"]

    var wallBound = svgView.wallBound;
    var levelFactor = Math.pow(1.2, -1 * parseFloat(this.level));// 1 if level =0;
    this.center = opt.center?{x:opt.center.x,y:opt.center.y}:{
        x: (wallBound.max.x + wallBound.min.x) / 2,
        y: (wallBound.max.y + wallBound.min.y) / 2
    };
    this.radius = opt.radius || Math.min(wallBound.max.x - wallBound.min.x, wallBound.max.y - wallBound.min.x) / 4 * levelFactor;
    this.width = opt.width || (wallBound.max.x - wallBound.min.x) / 2 * levelFactor;
    this.height = opt.height || (wallBound.max.y - wallBound.min.y) / 2 * levelFactor;
    this.displays = this.dimensions = undefined;

    this.pick = function (isPick) {
        var mask = this.displays[1];
        mask.attr({
            "fill-opacity": isPick ? 0.3 : 0,
            "stroke-width": isPick ? 4 : 1
        });
    };
    this.remove = function () {
        this.groupContainer.remove(this.displays);
    };

    // begin to create:
    if (this.model) {
        this.center = this.model.center || this.center;
        this.width = this.model.width || this.width;
        this.height = this.model.height || this.height;
        this.radius = this.model.radius || this.radius;
    }

    this.groupContainer = context.g();
    areaLayer.add(this.groupContainer);
    var displays = this.displays = [];
    var dimensions = this.dimensions = [];

    var fillColor = colorHexString();
    var maskAttr = {
        fill: 'white',
        stroke: "black",
        "stroke-width": 1,
        "fill-opacity": 0,
        "stroke-opacity": 1,
        "cursor": "move"
    };
    if (shape == "rect") {
        var base = context.path().attr({
            fill: fillColor,
            "fill-opacity": 0.8
        });
        //高级墙面铺贴二维图相关事件
        var mask = context.path().attr(maskAttr)
            .mouseover(function (e) {
                this.attr("stroke", "#45b0ff");
            }).mouseout(function (e) {
                this.attr("stroke", "black");
            }).click(function (e) {
                e.stopPropagation();
                if (e.button == 1)return;
                svgView.unpickAll();
                svgView.pick(self);
            }).drag(function (dx, dy, x, y, e) { // move
                e.stopPropagation();
                if (e.button == 1)return;
                var modelOffset = svgView.vectorScreenToModel(dx, dy);
                self.model.center.x = this._modelCenter.x + modelOffset.x;
                self.model.center.y = this._modelCenter.y + modelOffset.y;
                updateViewAreaFromModelArea(self);
            },
            function (x, y, e) { // down
                e.stopPropagation();
                if (e.button == 1)return;
                this._modelCenter = {x: self.model.center.x, y: self.model.center.y};
            },
            function (e) { // up
                e.stopPropagation();//
                if (e.button == 1)return;
                delete this._modelCenter;
            }, this, this, this);

        // line drag functions
        var lineDragMove = function (side, dx, dy, x, y, e) {
            e.stopPropagation();
            if (e.button == 1)return;
            var modelOffset = svgView.vectorScreenToModel(dx, dy);

            if (side == "left" || side == "right") {
                self.model.width = Math.abs(this._modelSize.width + modelOffset.x * (side == "left" ? -1 : 1));
                self.model.center.x = this._modelCenter.x + modelOffset.x / 2;
            } else if (side == "top" || side == "bottom") {
                self.model.height = Math.abs(this._modelSize.height + modelOffset.y * (side == "top" ? -1 : 1));
                self.model.center.y = this._modelCenter.y + modelOffset.y / 2;
            }
            updateViewAreaFromModelArea(self);
        };
        var lineDragDown = function (side, x, y, e) {
            e.stopPropagation();
            if (e.button == 1)return;
            this._modelCenter = {x: self.center.x, y: self.center.y};
            this._modelSize = {width: self.width, height: self.height};
        };
        var lineDragUp = function (side, e) {
            e.stopPropagation();//
            if (e.button == 1)return;
            delete this._modelCenter;
            delete this._modelSize;
        };
        var leftLine = context.path().attr({
            stroke: "#000", "stroke-opacity": 0, fill: "#000",
            "stroke-width": 6, cursor: "ew-resize"
        }).drag(lineDragMove.bind(this, "left"),
            lineDragDown.bind(this, "left"),
            lineDragUp.bind(this, "left"));

        var rightLine = context.path().attr({
            stroke: "#000", "stroke-opacity": 0, fill: "#000",
            "stroke-width": 6, cursor: "ew-resize"
        }).drag(lineDragMove.bind(this, "right"),
            lineDragDown.bind(this, "right"),
            lineDragUp.bind(this, "right"));

        var topLine = context.path().attr({
            stroke: "#000", "stroke-opacity": 0, fill: "#000",
            "stroke-width": 6, cursor: "ns-resize"
        }).drag(lineDragMove.bind(this, "top"),
            lineDragDown.bind(this, "top"),
            lineDragUp.bind(this, "top"));

        var bottomLine = context.path().attr({
            stroke: "#000", "stroke-opacity": 0, fill: "#000",
            "stroke-width": 6, cursor: "ns-resize"
        }).drag(lineDragMove.bind(this, "bottom"),
            lineDragDown.bind(this, "bottom"),
            lineDragUp.bind(this, "bottom"));

        displays.push(base, mask, leftLine, rightLine, topLine, bottomLine);

    } else if (shape = "round") {
        var base = context.circle().attr({
            fill: fillColor,
            "fill-opacity": 0.8
        });

        var mask = context.circle().attr(maskAttr).mouseover(function (e) {
            this.attr("stroke", "#45b0ff");
        }).mouseout(function (e) {
            this.attr("stroke", "black");
        }).click(function (e) {
            e.stopPropagation();
            if (e.button == 1)return;
            svgView.unpickAll();
            svgView.pick(self);
        }).drag(function (dx, dy, x, y, e) { // move
                e.stopPropagation();
                if (e.button == 1)return;
                var modelOffset = svgView.vectorScreenToModel(dx, dy);
                self.model.center.x = this._modelCenter.x + modelOffset.x;
                self.model.center.y = this._modelCenter.y + modelOffset.y;
                log("Round center=[" + self.model.center.x + "," + self.model.center.y + "]");
                updateViewAreaFromModelArea(self);
            },
            function (x, y, e) { // down
                e.stopPropagation();
                if (e.button == 1)return;
                this._modelCenter = {x: self.model.center.x, y: self.model.center.y};
            },
            function (e) { // up
                e.stopPropagation();//
                if (e.button == 1)return;
                delete this._modelCenter;
            }, this, this, this);

        var arc = context.circle()
            //context.path()
            .attr({
                stroke: "#000", "stroke-opacity": 0, fill: "none",
                "stroke-width": 6
            }).mousemove(function (e, x, y) {
                var center = self.center, mouse = svgView.pointScreenToModel(x, y);
                var angle = Math.atan2(mouse.y - center.y, mouse.x - center.x) * 180 / Math.PI;
                angle = Math.floor((Math.round(angle + 360 + 22.5) % 360) / 45.0) % 4;
                // log("angle=" + angle + ",center=[" + center.x + "," + center.y + "], mouse=[" + mouse.x + "," + mouse.y + "].");
                this.attr("cursor", circleCursors[angle]);
            }).drag(function (dx, dy, x, y, e) { // move
                //log("line dragmove");
                e.stopPropagation();
                var modelOffset = svgView.pointScreenToModel(x, y);
                self.model.radius = api.Vec2.difference(modelOffset, this._modelCenter).magnitude();
                updateViewAreaFromModelArea(self);
            },
            function (x, y, e) { // down
                e.stopPropagation();
                this._modelCenter = {x: self.center.x, y: self.center.y};
            },
            function (e) { // up
                e.stopPropagation();//
                delete this._modelCenter;
            }, this, this, this);

        displays.push(base, mask, arc);
    }


    this.groupContainer.add(displays);

    if (this.model) {
        updateViewAreaFromModelArea(this);
    }
}
var circleCursors = ["ew-resize", "nesw-resize", "ns-resize", "nwse-resize"];
function circlePath(cx, cy, r, isPos) {
    return 'M ' + cx + ' ' + cy + ' m -' + r + ', 0 a ' + r + ',' + r + ' 0 1,0 ' + (r * 2) + ',0 a ' + r + ',' + r + ' 0 1,0 -' + (r * 2) + ',0';
}
function createEmptyViewArea(opt) {
    var viewArea = new ViewArea(opt);
    return viewArea;
}
function createViewAreaFromModelArea(modelArea) {
    var viewArea = new ViewArea({model: modelArea});
    return viewArea;
}

function updateModelAreaFromViewArea(viewArea) {
    var modelArea = viewArea.model;
    modelArea.center.x = viewArea.center.x;
    modelArea.center.y = viewArea.center.y;
    modelArea.level = viewArea.level;

    if (viewArea.shape == "rect") {
        modelArea.width = viewArea.width;
        modelArea.height = viewArea.height;
    } else {
        modelArea.radius = viewArea.radius;
    }

}
function updateViewAreaFromModelArea(viewArea) {
    var shape = viewArea.shape;
    var modelArea = viewArea.model;
    viewArea.center.x = modelArea.center.x;
    viewArea.center.y = modelArea.center.y;
    viewArea.level = modelArea.level;

    if (shape == "rect") {
        viewArea.width = modelArea.width;
        viewArea.height = modelArea.height;
        viewArea.rot = modelArea.rot;
            var topLeft = {x: viewArea.center.x - viewArea.width / 2, y: viewArea.center.y - viewArea.height / 2};
            var topRight = {x: viewArea.center.x + viewArea.width / 2, y: viewArea.center.y - viewArea.height / 2};
            var bottomLeft = {x: viewArea.center.x - viewArea.width / 2, y: viewArea.center.y + viewArea.height / 2};
            var bottomRight = {x: viewArea.center.x + viewArea.width / 2, y: viewArea.center.y + viewArea.height / 2};

            var displays = viewArea.displays;
            var rect = displays[0], mask = displays[1], leftLine = displays[2], rightLine = displays[3], topLine = displays[4], bottomLine = displays[5];
            var rectPath = "M" + toFixedNumber(100 * topLeft.x, 2) + "," + toFixedNumber(-100 * topLeft.y, 2) +
                "L" + toFixedNumber(100 * topRight.x, 2) + "," + toFixedNumber(-100 * topRight.y, 2) +
                "L" + toFixedNumber(100 * bottomRight.x, 2) + "," + toFixedNumber(-100 * bottomRight.y, 2) +
                "L" + toFixedNumber(100 * bottomLeft.x, 2) + "," + toFixedNumber(-100 * bottomLeft.y, 2) +
                "Z";
            rect.attr("path", rectPath);
            rect.attr("fill", "#"+modelArea.areaColor);
            mask.attr("path", rectPath);
            leftLine.attr("path", "M" + toFixedNumber(100 * topLeft.x, 2) + "," + toFixedNumber(-100 * topLeft.y, 2) +
                "L" + toFixedNumber(100 * bottomLeft.x, 2) + "," + toFixedNumber(-100 * bottomLeft.y, 2));
            rightLine.attr("path", "M" + toFixedNumber(100 * topRight.x, 2) + "," + toFixedNumber(-100 * topRight.y, 2) +
                "L" + toFixedNumber(100 * bottomRight.x, 2) + "," + toFixedNumber(-100 * bottomRight.y, 2));
            topLine.attr("path", "M" + toFixedNumber(100 * topLeft.x, 2) + "," + toFixedNumber(-100 * topLeft.y, 2) +
                "L" + toFixedNumber(100 * topRight.x, 2) + "," + toFixedNumber(-100 * topRight.y, 2));
            bottomLine.attr("path", "M" + toFixedNumber(100 * bottomRight.x, 2) + "," + toFixedNumber(-100 * bottomRight.y, 2) +
                "L" + toFixedNumber(100 * bottomLeft.x, 2) + "," + toFixedNumber(-100 * bottomLeft.y, 2));

        if(viewArea.rot!=undefined){
            var attr_ = {
                x: topLeft.x,
                y: topRight.y,
                width: viewArea.width,
                height: viewArea.height
            };

            rect.attr(attr_).transform("r" + -viewArea.rot),
            mask.attr(attr_).transform("r" + -viewArea.rot),
            leftLine.attr(attr_).transform("r" + -viewArea.rot),
            rightLine.attr(attr_).transform("r" + -viewArea.rot),
            topLine.attr(attr_).transform("r" + -viewArea.rot),
            bottomLine.attr(attr_).transform("r" + -viewArea.rot)
        }

    } else {// round
        viewArea.radius = modelArea.radius;
        var displays = viewArea.displays;
        var round = displays[0], mask = displays[1], arc1 = displays[2], arc2 = displays[3];
        var roundGeomAttr = {
            cx: toFixedNumber(100 * viewArea.center.x),
            cy: toFixedNumber(-100 * viewArea.center.y),
            r: toFixedNumber(100 * viewArea.radius)
        };
        round.attr(roundGeomAttr);
        round.attr("fill", "#"+modelArea.areaColor);
        mask.attr(roundGeomAttr);
        /*
         var arcpath = circlePath(toFixedNumber(viewArea.center.x * 100),
         toFixedNumber(-100 * viewArea.center.y),
         toFixedNumber(100 * viewArea.radius), true);
         arc1.attr("path", arcpath);
         */
        arc1.attr({
            cx: toFixedNumber(viewArea.center.x * 100),
            cy: toFixedNumber(-100 * viewArea.center.y),
            r: toFixedNumber(100 * viewArea.radius)
        })
    }
}

//# sourceURL=ui\dialog/advancedpaint_areaview.js