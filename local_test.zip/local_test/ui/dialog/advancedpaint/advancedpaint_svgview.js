//var advancedPaintWall = undefined;// this will be initialed when this dialog opened..
//var advacedPaintWallOption = undefined;// this will be initialed when this dialog opened..
//var advacedPaintView = undefined;// this will be initialed when application startup.
//
//    advancedPaintPrompt({model: db[wallid], opt: {src: "3d", elementName: "left"}});

/*******************************************************************/

function ViewSVG(view2d, view3d) {
    // needed for creation:
    this.domElement = undefined;
    this.context = undefined;
    this.doc = undefined;

    this.layers = {};
    this.layerOrder = [
        "WALL",
        "WALLDIM",
        "AREA",
        "AREADIM"
    ];

    // view related data:
    this.wall3dData = undefined; //{ f: f, v: v, vn: vn, vt: vt, b3d: boundProfile, h3d: holesPos,h2d: holeProfiles, b2d: boundUVWProfile, hmodel: holesModel};
    this.wallBound = undefined; //{max: {x: -100, y: -100}, min: {x: 100, y: 100}};
    this.sortedViewAreas = [];
    this.pickedViewArea = undefined;
    var self = this;
    /************************* METHODS ********************************/

    this.create = function () {
        view2d.init.call(this);
    };

    this.show = function () {
        // step 0: init datas:
        this.doc = view2d.doc;
        this.wallBound = {max: {x: -100, y: -100}, min: {x: 100, y: 100}};


        // step1: clear all existing layers:
        for (var i = 0; i < this.layerOrder.length; ++i) {
            this.layers[this.layerOrder[i]].clear();
        }
        this.sortedViewAreas = [];

        // step2: get wall info from 3d view.
        var wall = advancedPaintWall, side = advacedPaintWallOption.elementName;
        var wall3d = view3d.dl[wall.id].de, wallSideMesh = undefined, wallSideMaterial = wall[side + "Material"];

        wall3d.traverse(function (child) {
            if (child.name == (side) && (child.type == "Mesh")) {
                wallSideMesh = child;
            }
        });
        if (wallSideMesh)
            this.wall3dData = wallSideMesh._rawData;
        var wallBoundProfile = [];
        this.wall3dData.b2d.forEach(function(p){
        	wallBoundProfile.push({x:p.x,y:p.y});
        });
        //for(var i=1;i<wallSideMesh._rawDatas.length;++i){
        //	wallBoundProfile[1].x += wallSideMesh._rawDatas[i].b2d[1].x;
        //	wallBoundProfile[2].x += wallSideMesh._rawDatas[i].b2d[2].x;
        //}
        var wallSideWidth = api.utilModelWallGetSideLength(wall, side);
        wallBoundProfile[1].x = wallSideWidth;
        wallBoundProfile[2].x = wallSideWidth;
        
        var path = "";
        for (var i = 0, len = wallBoundProfile.length; i < len; ++i) {
            var pt = wallBoundProfile[i];
            path += (i == 0 ? "M" : "L") + toFixedNumber(pt.x * 100, 2) + "," + toFixedNumber(-pt.y * 100, 2);
            this.wallBound.max.x = Math.max(this.wallBound.max.x, pt.x);
            this.wallBound.max.y = Math.max(this.wallBound.max.y, pt.y);
            this.wallBound.min.x = Math.min(this.wallBound.min.x, pt.x);
            this.wallBound.min.y = Math.min(this.wallBound.min.y, pt.y);
        }
        path += "Z";

        // step3: create wall:
        var wall = this.context.path(path).attr({
            fill: "darkgrey",
            stroke: 'darkblue',
            'stroke-width': 2, 
            'stroke-opacity': 1,
            'stroke-linejoin': 'round',
            'opacity': 1
        }).click(function () {
            self.unpickAll();
        });
        this.layers["WALL"].add(wall);

        // openings:
        //var openings = api.utilModelWallGetSmoothOpenings(wall,side);
        var holeProfiles = api.utilModelWallGetSmoothHoleprofiles(advancedPaintWall, side);//this.wall3dData.h2d;
        holeProfiles.forEach(function (holeProfile) {
            var path = '';
            for (var i = 0, len = holeProfile.length; i < len; ++i) {
                var pt = holeProfile[i];
                path += (i == 0 ? "M" : "L") + toFixedNumber(pt.x * 100, 2) + "," + toFixedNumber(-pt.y * 100, 2);
            }
            path += "Z";
            var hole = this.context.path(path).attr({
                fill: "lightgrey",
                stroke: 'darkblue',
                'stroke-width': 1, 'stroke-opacity': 1,
                'stroke-linejoin': 'round',
                'stroke-dasharray': "8,6",
                'opacity': 1
            });
            this.layers["WALL"].add(hole);
        }, this);

        //wall dimension:
        // area
        var sortedModelAreas = api.floorplanGetAreasByHostId(undefined, advancedPaintWall.id, side);
        for (var i = 0, len = sortedModelAreas.length; i < len; ++i) {
            var viewArea = createViewAreaFromModelArea(sortedModelAreas[i]);
            this.sortedViewAreas.push(viewArea);
            updateViewAreaFromModelArea(viewArea);
        }
        // area dimensions:

    };
    this.update = function () {

    };
    this.zoom = function (delta, mouseX, mouseY) {
        view2d.zoom.call(this, delta, mouseX, mouseY);
    };
    this.zoomWithFactor = function (delta, mouseX, mouseY) {
        view2d.zoomWithFactor.call(this, delta, mouseX, mouseY);
    };
    this.pan = function (delta_x, delta_y) {
        view2d.pan.call(this, delta_x, delta_y);
    };
    this.fit = function () {
        if (!this.wallBound) return;
        var bound = {
            left: this.wallBound.min.x,
            top: this.wallBound.min.y,
            width: this.wallBound.max.x - this.wallBound.min.x,
            height: this.wallBound.max.y - this.wallBound.min.y
        };
        view2d.fit.call(this, bound);
    };
    this.getBoundingClientRect = function () {
        return view2d.getBoundingClientRect.call(this);
    };
    /**************************  PICK and Operation  *********************************************/
    this.pick = function (areaView) {
        this.pickedViewArea = areaView;
        areaView.pick(true);
    };
    this.unpickAll = function () {
        this.pickedViewArea = undefined;
        this.sortedViewAreas.forEach(function (areaView) {
            areaView.pick(false);
        });
    };
    this.removeArea = function (areaView) {
        var removed = areaView || this.pickedViewArea;
        if (!removed) return;

        // delete model first:
        var action = "DeleteArea";
        var modelArea = api.actionBegin(action, removed.model);
        api.actionEnd(action);

        // delete in UI.
        removed.remove();
        this.pickedViewArea = undefined;

        // change views:
        var idx = this.sortedViewAreas.indexOf(removed);
        if (idx != -1) {
            this.sortedViewAreas.splice(idx, 1);
        }

        // change model:
        for (var i = 0, len = this.sortedViewAreas.length; i < len; ++i) {
            var viewArea = this.sortedViewAreas[i];
            viewArea.model.level = i;
        }
    };
    this.setOrder = function (areaView, order) {
        var ordered = areaView || this.pickedViewArea;
        if (!ordered) return;

        var idx = this.sortedViewAreas.indexOf(ordered);
        if (idx != -1) {
            this.sortedViewAreas.splice(idx, 1);
        }
        if (order == "bottom") this.sortedViewAreas.unshift(ordered);
        else this.sortedViewAreas.push(ordered);

        api.actionBegin("SetAreaLevel", ordered.model);
        api.actionRun("set", order != "bottom");
        api.actionEnd("SetAreaLevel");

        for (var i = 0, len = this.sortedViewAreas.length; i < len; ++i) {
            var viewArea = this.sortedViewAreas[i];
            //viewArea.model.level = i;
            var areaLayer = this.layers["AREA"];
            areaLayer.add(viewArea.groupContainer);
        }
    };
    this.changeMaterial = function (tileId) {
        var picked = this.pickedViewArea;
        if (!picked) return;


        var action = "SetMat";
        var modelArea = api.actionBegin(action, picked.model, "area", tileId);
        api.actionEnd(action);

    };

    /**********************  COORDINATE SYSTEM  ***************************/
    this.pointScreenToModel = function (screen_x, screen_y) {
        return view2d.PS2M(this, screen_x, screen_y);
    };
    this.vectorScreenToModel = function (screen_x, screen_y) {
        return view2d.VS2M(this, screen_x, screen_y);
    };
    this.pointModelToScreen = function (model_x, model_y) {
        return view2d.PM2S(this, model_x, model_y);
    };
    
    this.resetFontSize = function(){
    	//...
    };
}

api.application_ready_event.add(function () {
    var view2d = api.getViewById("2d"), view3d = api.getViewById("3d");
    var apview = advacedPaintView = new ViewSVG(view2d, view3d);
    apview.domElement = document.getElementById("svgAdvancedPaint");
    apview.context = Snap(apview.domElement);
    apview.create();
});


/****************************  FUNCTIONS  *****************************************/
function wall3dArea_add(opt) {
    opt = opt || {};
    var shape = opt.shape || 'rect';

    // add to Data model:
    var action = shape == "rect" ? "AddRectArea" : "AddRoundArea";
    var wall = advancedPaintWall, side = advacedPaintWallOption.elementName;

    // add to wall
    var modelArea = api.actionBegin(action, side, wall);
    api.actionEnd(action);
    if (!modelArea) {
        layer.alert(' 添加区域首先需要解锁户型。', {title: '提示', skin: 'layui-layer-default'}, function (index) {
            layer.close(index);
        });
        return;
    }

    // add to view:
    opt.level = advacedPaintView.sortedViewAreas.length;
    var viewArea = createEmptyViewArea(opt);
    advacedPaintView.sortedViewAreas.push(viewArea);
    modelArea.rot=opt.rot?opt.rot:0;
    viewArea.model = modelArea;
    updateModelAreaFromViewArea(viewArea);
    updateViewAreaFromModelArea(viewArea);
    modelArea.viewarea = viewArea;
}

/*扩展 add by zk*/
function wall3dArea_expand(margin) {
    var current = advacedPaintView.pickedViewArea;
    var w = current.width + 2 * margin, h = current.height + 2 * margin, r = current.radius + margin;
    if (w < 0.05 || h < 0.05 || r < 0.05) {
        layer.alert(' 所要生成的区域太小，无法生成。', {title: '提示', skin: 'layui-layer-default'}, function (index) {
            layer.close(index);
        });
        return;
    }
    wall3dArea_add({
        shape: (current.model.type == "RECTAREA3D" ? "rect" : "round"),
        center: current.center,
        width: w,
        height: h,
        radius: r,
        rot:current.rot
    })
}
//# sourceURL=ui\dialog/advancedpaint_svgview.js