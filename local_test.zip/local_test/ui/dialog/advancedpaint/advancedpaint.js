// global var for advanced paint:
var advancedPaintWall = undefined;// this will be initialed when this dialog opened..
var advacedPaintWallOption = undefined;// this will be initialed when this dialog opened..

var advacedPaintView = undefined;// this will be initialed when application startup.


function advancedPaintViewOpened() {
    advacedPaintView.show();
}
function advancedPaintViewResized() {
    var dialogWidth = $("#advancedpaint_dialog").outerWidth(true);
    var dialogHeight = $("#advancedpaint_dialog").outerHeight(true);

    var dialogPopupWidth = dialogWidth - 30;
    var dialogPopupHeight = dialogHeight - 10;
    $("#advancedpaint_dialog .popup").outerWidth(dialogPopupWidth);
    $("#advancedpaint_dialog .popup").outerHeight(dialogPopupHeight);

    var operatorWidth = $("#advancedpaint_dialog .operator").outerWidth(true);
    var operatorHeight = $("#advancedpaint_dialog .operator").outerHeight(true);

    $("#advancedpaint_dialog .main-pannel").width(dialogPopupWidth - operatorWidth - 10);
    $("#advancedpaint_dialog .main-pannel").height(dialogPopupHeight - 15);

    advacedPaintView.fit();
}

function advancedPaintPrompt(selectedWall3d) {
//    advancedPaintPrompt({model: db[wallid], opt: {src: "3d", elementName: "left"}});
    // step 1: check input..
    if (!selectedWall3d ||
        !(selectedWall3d.model.type == "WALL" || 
          selectedWall3d.model.type == "RECTAREA" ||
          selectedWall3d.model.type == "ROUNDAREA" ||
          selectedWall3d.model.type == "FREEAREA") ||
        !selectedWall3d.opt ||
        selectedWall3d.opt.src != "3d"
    ) {
        layer.alert('请先在3D下选择一面墙', {
            title: '提示',
            skin: 'layui-layer-default'
        }, function (index) {
            layer.close(index);
        });
        return;
    }
    
    if((selectedWall3d.model.type == "RECTAREA" ||
        selectedWall3d.model.type == "ROUNDAREA" ||
        selectedWall3d.model.type == "FREEAREA") &&
       selectedWall3d.opt.elementName == "root"){
    	layer.alert('请先在3D下选择一面墙', {
            title: '提示',
            skin: 'layui-layer-default'
        }, function (index) {
            layer.close(index);
        });
        return;
    }
    
    advacedPaintWallOption = selectedWall3d.opt;
    advancedPaintWall = selectedWall3d.model;
    
    var smoothStartWall = api.utilModelWallGetSmoothStart(advancedPaintWall, advacedPaintWallOption.elementName);
    advancedPaintWall = smoothStartWall.wall;
    advacedPaintWallOption.elementName = smoothStartWall.side;
    

    $("#advancedpaint_dialog").dialog("open");
    $("div[aria-describedby='advancedpaint_dialog']").css("z-index", 500);
}

// step 2: open dialog:
$("#advancedpaint_dialog").dialog({minWidth: 400, width: 530, minHeight: 380, height: 400, autoOpen: false})
    .on("dialogclose", function (event, ui) {
        advacedPaintWallOption = undefined;
        advancedPaintWall = undefined;
    }).on("dialogopen", function (event, ui) {
        advancedPaintViewOpened();
        advancedPaintViewResized();
    }).on("dialogresizestop", function (event, ui) {
        advancedPaintViewResized();
    });

/*$("#wall3dArea_rotateSlide")
    .slider({min: 0, max: 360, step: 15})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "°"})
    .on("slidestart", function (e, ui) {

    })
    .on("slide", function (e, ui) {
        var current = advacedPaintView.pickedViewArea;
        if (!current) return;
        current.model.areaMaterial.rot = ui.value;
    })
    .on("slidestop", function (e, ui) {

    });*/

$("#wall3dArea_expandSlide")
    .slider({min: -1, max: 1, step: 0.1, value: 0.2})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    })
    .slider("float", {suffix: "m"})
    .on("slidestart", function (e, ui) {

    })
    .on("slide", function (e, ui) {
    })
    .on("slidestop", function (e, ui) {

    });

$("#wall3dArea_addExpandArea").on(click, function (e) {
    if (!advacedPaintView.pickedViewArea) {
        layer.alert('请先选择一个区域。', {
            title: '提示',
            skin: 'layui-layer-default'
        }, function (index) {
            layer.close(index);
        });
        return;
    }
    wall3dArea_expand($("#wall3dArea_expandSlide").slider("value"));
});
/*矩形区域*/
$("#wall3dArea_addRect").on(click, function (e) {
    wall3dArea_add({shape: "rect"});
});
/*圆形区域*/
$("#wall3dArea_addCircle").on(click, function (e) {
    wall3dArea_add({shape: "round"});
});

/*置顶*/
$("#advancedpaint_dialog .button_place_top").on(click, function (e) {
    advacedPaintView.setOrder(undefined, "top");
});
/*置底*/
$("#advancedpaint_dialog .button_place_bottom").on(click, function (e) {
    advacedPaintView.setOrder(undefined, "bottom");
});
/*删除*/
$("#advancedpaint_dialog .button_delete").on(click, function (e) {
    advacedPaintView.removeArea();
});

api.application_ready_event.add(function () {
    api.pickChangedEvent.add(function (changedType, result) {
    });
});


//# sourceURL=ui\dialog/advancedpaint.js
