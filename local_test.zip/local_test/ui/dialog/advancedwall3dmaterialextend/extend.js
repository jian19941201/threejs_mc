var extendMaterialWall3d_needChangedPicked;

function extendMaterialWall3d_checkValidPick(pickResult) {
    return pickResult && pickResult.model.type == "WALL" && pickResult.opt.src == "3d";
}

function extendMaterialWall3d_pick(changedType, result) {
    if (changedType != "select") return;
    api.pickChangedEvent.remove(extendMaterialWall3d_pick);

    var picks = api.pickGetPicked();
    var pick = picks && picks[0];
    var adjacent;
    if (!extendMaterialWall3d_checkValidPick(pick) ||
        (adjacent = api.wallAdjacentPoint(
            extendMaterialWall3d_needChangedPicked.model,
            extendMaterialWall3d_needChangedPicked.opt.elementName,
            pick.model,
            pick.opt.elementName
        )) == undefined) {
        layer.alert("材质扩展失败，所选择的墙没有相邻，不是标准化的墙。<br/>请先在<工具>菜单下标准化户型后，再选择3D下的一面相邻的墙作为扩展基准墙", {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
        api.actionEnd("MaterialDropper");
        return;
    }
    var fixed = adjacent.c2at, changed = adjacent.c1at;
    var fixedMaterial = api.actionRun("pick", pick), meta = fixedMaterial.meta;
    var materialOption = {};
    var changedMaterial = extendMaterialWall3d_needChangedPicked.model[extendMaterialWall3d_needChangedPicked.opt.elementName + "Material"];
    var fixedWallLen = api.Vec2.difference(adjacent.p, adjacent.o2).magnitude();
    var changedWallLen = api.Vec2.difference(adjacent.p, adjacent.o1).magnitude();

    var uvCoord = (fixed == "end" ? {x: fixedWallLen, y: 0} : {x: -changedWallLen, y: 0});

    var imageOffset = api.materialGetRasterizedOffsetFromUV(fixedMaterial, uvCoord);
    var translation = imageOffset && api.materialComputeRasterizedTranslationFromOffset(fixedMaterial, imageOffset);
    if (translation)materialOption.tx = -translation.x, materialOption.ty = translation.y;

    api.actionRun("drop", extendMaterialWall3d_needChangedPicked, materialOption);
    api.actionEnd("MaterialDropper");
}

function extendMaterialWall3d_start() {
    var picks = api.pickGetPicked();
    var pick = picks && picks[0];
    if (!extendMaterialWall3d_checkValidPick(pick)) {
        layer.alert("请先选择3D下的一面墙", {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
        return;
    }
    extendMaterialWall3d_needChangedPicked = pick;

    layer.alert("请选择相邻的墙作为参照来无缝铺贴本墙, <br/><span style='color:red'>警告：此墙上的当前铺贴方案将会丢失。</span>", {
        closeBtn: 0,
        skin: 'layui-layer-default'
    }, function (idx) {
        layer.close(idx);
        api.actionBegin("MaterialDropper");
        api.pickChangedEvent.add(extendMaterialWall3d_pick);
    });
}

//# sourceURL=ui\dialog/advancedwall3dmaterial/extend.js