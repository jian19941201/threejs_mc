var advancedPatternShowObj = undefined;
var advancedPatternCurrentUsedTile = undefined;
var advancedPatternCurrentMaterial = undefined;

function advancedSinglePatternPrompt(paramobj) {
    //advancedSinglePatternPrompt({pid:'',xlen:800,ylen:800,title:'汉白玉'})
    advancedPatternShowObj = paramobj;
    $("#advancedpattern_single_dialog").dialog("open");
    $("div[aria-describedby='advancedpattern_single_dialog']").css("z-index", 500);
}

$("#advancedpattern_single_dialog").dialog({
    minWidth: 400,
    minHeight: 380,
    autoOpen: false,
    resizable: false,
    width: 620,
    height: 500
})
    .on("dialogclose", function (event, ui) {
        advancedPatternShowObj = undefined;
        advancedPatternCurrentUsedTile = undefined;
    }).on("dialogopen", function (event, ui) {
        console.log(advancedPatternShowObj);
        var beforeProcessImageUrl = api.catalogGetFileUrl("product", advancedPatternShowObj.pid, "iso");
        $("#advancedpattern_single_dialog .before_process_prod img").attr("src", beforeProcessImageUrl);
        $("#advancedpattern_single_dialog .desc_button_content .length").html(advancedPatternShowObj.xlen);
        $("#advancedpattern_single_dialog .desc_button_content .width").html(advancedPatternShowObj.ylen);
        $("#advancedpattern_single_dialog .desc_button_content .model").html(advancedPatternShowObj.model);
        $("#advancedpattern_single_dialog .desc_button_content .title").html(advancedPatternShowObj.title);
        $("#advancedpattern_single_dialog .after_process_prod img").attr("src", beforeProcessImageUrl);

        var model = api.pickGetPicked()[0].model;
        var opt = api.pickGetPicked()[0].opt;
        var areaMaterial = model.areaMaterial;
        if (model.floorMaterial) {
          areaMaterial = model.floorMaterial;
        }
        if (opt.elementName && model[opt.elementName + "Material"]) {
        	areaMaterial = model[opt.elementName + "Material"];
        }
        if(model.type == "BOUNDARY"){
        	if(opt.src == "2d"){   
        		var side = opt.side.split("_");     		
        		areaMaterial = model[side[0] + "Material"];// + side[1] + "Material"];
        	}else if(opt.src == "3d"){
        		if(opt.elementName.indexOf("base") != -1){
        			areaMaterial = model["baseMaterial"];
        		}else if(opt.elementName.indexOf("corner") != -1){
        			areaMaterial = model["cornerMaterial"];
        		}else if(opt.elementName.indexOf("left") != -1){
        			areaMaterial = model["leftMaterial"];
        		}else if(opt.elementName.indexOf("right") != -1){
        			areaMaterial = model["rightMaterial"];
        		}            		
        	}
        }
        
        //显示和隐藏铺贴方式
        //if(model.type == "FLOOR" || model.type == "RECTAREA" || model.type == "ROUNDAREA" || model.type == "FREEAREA" || model.type == "BOUNDARY"){
        	$("#advancedpattern_single_dialog .popup .operator_area .tab_ul li:eq(1)").hide();
        //}else{
        //	$("#advancedpattern_single_dialog .popup .operator_area .tab_ul li:eq(1)").show();
        //}        
        
        advancedPatternCurrentMaterial = areaMaterial;
        
        var gapwidth = null;
        var gapcolor = null;        
         
        if(areaMaterial && areaMaterial.gapwidth) {
        	gapwidth = areaMaterial.gapwidth;
        	gapcolor = areaMaterial.gapcolor;
        	
        	$("#advancedpattern_single_dialog .pavet li div").each(function (index) {
              if ($(this).attr("value") == areaMaterial.pavetype) $(this).parent().trigger("click");
          });
          $("#advancedpattern_single_dialog .horizontalcutting select").val(areaMaterial.cutv);
          $("#advancedpattern_single_dialog .verticalcutting select").val(areaMaterial.cuth);
        
          $("#advancedpattern_single_dialog .preview").trigger("click");
        }else{
          $("#advancedpattern_single_dialog .horizontalcutting select").val("1");
          $("#advancedpattern_single_dialog .verticalcutting select").val("1");
        }
        
        if(model.gapwidth != undefined && model.gapcolor != undefined && areaMaterial){
        	//直接model存放gapwidth和gapcolor砖缝参数
        	gapwidth = model.gapwidth;
        	gapcolor = model.gapcolor;
        }
        
        if(model.host && model.host.type == "WALL" && model.host[model.category + "Material"]){
        	//墙体部分使用墙面的颜色        	
        	//gapcolor = model.host[model.category + "Material"].getColorHexString ? model.host[model.category + "Material"].getColorHexString() : null;
        }
        
        if(gapwidth != null){
        	$("#advancedpattern_single_dialog .gap_width li:last").trigger("click");
          $("#advancedpattern_single_dialog .gap_width li .custom_gap_width").val(gapwidth * 1000);
          $("#advancedpattern_single_dialog .custom_gap_width").trigger("blur");
          $("#advancedpattern_single_dialog .gap_width li span").each(function () {
              if ($(this).attr("widthvalue") == gapwidth) {
                  $(this).parent().trigger("click");
                  $("#advancedpattern_single_dialog .gap_width li .custom_gap_width").val("");
              }
          });
        }
        if(gapcolor != null){
        	$("#advancedpattern_single_dialog .gap_color li:last").trigger("click");
          $("#advancedpattern_single_dialog .custom_gap_color").spectrum({
              color: "#" + gapcolor
          });
          $("#advancedpattern_single_dialog .gap_color .custom").attr("value", gapcolor);
          $("#advancedpattern_single_dialog .gap_color li div").each(function (index) {
              if ($(this).attr("value")) {
                  if ($(this).attr("value") == gapcolor) {
                      $(this).parent().trigger("click");
                      return false;
                  }
              }
          });
        }
    }).on("dialogresizestop", function (event, ui) {

    });


/* 重置 API */
$("#advancedpattern_single_dialog .reset").on("click", function (e) {
    $("#advancedpattern_single_dialog .gap_width li:first").trigger("click");
    $("#advancedpattern_single_dialog .gap_color li:first").trigger("click");
    $("#advancedpattern_single_dialog .pavet li:first").trigger("click");
    $("#advancedpattern_single_dialog .horizontalcutting select").val("1");
    $("#advancedpattern_single_dialog .verticalcutting select").val("1");
});

/* 预览 API */
$("#advancedpattern_single_dialog .preview").on("click", function (e) {
    preview();
});

function preview() {
    var gapwidth = $("#advancedpattern_single_dialog .gap_width li").find(".hover").attr("widthvalue");//    /*缝隙宽度*/
    var gapcolor = $("#advancedpattern_single_dialog .gap_color li").find(".hover").attr("value");//    /*缝隙颜色*/
    var pavetype = $("#advancedpattern_single_dialog .pavet li").find(".hover").attr("value");//    /*铺贴方式*/
    var cutv = $("#advancedpattern_single_dialog .horizontalcutting select").val();//   /*横切*/
    var cuth = $("#advancedpattern_single_dialog .verticalcutting select").val();//    /*竖切*/
    log("gapwidth==" + gapwidth + "  gapcolor==" + gapcolor + "  pavetype==" + pavetype + " cuth==" + cuth + "  cutv==" + cutv);

    // created
    var tile = advancedPatternCurrentUsedTile = api.tileSingleCreate(advancedPatternShowObj.pid);
    tile.gapwidth = gapwidth||0.003;
    tile.gapcolor = gapcolor;
    tile.pavetype = pavetype;
    tile.cuth = cuth;
    tile.cutv = cutv;
    if (pavetype == 0) {//ping
        tile.psx = tile.psy = 1;
    } else if (pavetype == 1) {//gong
        tile.psx = tile.psy = 1;
    } else if (pavetype == 2) {//ren
        tile.psx = tile.psy = 2;
    } else if (pavetype == 3) {//hengshu
        tile.psx = tile.psy = 2;
    }
    var processUrl = api.tileSingleGetUrl(tile, true, "diffuse");
    $("#advancedpattern_single_dialog .after_process_prod img").attr("src", processUrl);
}


/* 应用 API */
$("#advancedpattern_single_dialog .apply").on("click", function (e) {
    preview();
    if (!advancedPatternCurrentUsedTile) 
        return;
    var pick = api.pickGetPicked()[0];
    var model = pick.model;
    if (model.type == "BOUNDARY"){
    	  if(pick.opt.src == "2d"){   
      		var side = pick.opt.side.split("_")[0];     		
      		model[side+"Material"] = advancedPatternCurrentUsedTile;
      	}else if(pick.opt.src == "3d"){
      		if(pick.opt.elementName.indexOf("base") != -1){
      			 model["baseMaterial"] = advancedPatternCurrentUsedTile;
      		}else if(pick.opt.elementName.indexOf("corner") != -1){
      			 model["cornerMaterial"] = advancedPatternCurrentUsedTile;
      		}else if(pick.opt.elementName.indexOf("left") != -1){
      			 model["leftMaterial"] = advancedPatternCurrentUsedTile;
      		}else if(pick.opt.elementName.indexOf("right") != -1){
      			 model["rightMaterial"] = advancedPatternCurrentUsedTile;
      		}
      	}
    }else if(pick.opt.src == "2d"){
    	model[pick.opt.side + "Material"] = advancedPatternCurrentUsedTile;
    }else if(pick.opt.src == "3d"){
    	model[pick.opt.elementName + "Material"] = advancedPatternCurrentUsedTile;
    }

    advancedPatternCurrentUsedTile.psx += 1;
    advancedPatternCurrentUsedTile.psx -= 1;

    //给 preview 中新建的 tile 赋值
    api.actionBegin("RotMat", pickedMaterial());
    api.actionRun("rot", "", advancedPatternCurrentMaterial.rot);
    api.actionEnd("RotMat");
    api.actionBegin("MoveMat", pickedMaterial());
    api.actionRun("move", "x", "delta", advancedPatternCurrentMaterial.tx);
    api.actionRun("move", "y", "delta", advancedPatternCurrentMaterial.ty);
    api.actionEnd("MoveMat");
    api.actionBegin("SetGeneralProp", pickedMaterial());
    api.actionRun("set", "sx", advancedPatternCurrentMaterial.sx);
    api.actionRun("set", "sy", advancedPatternCurrentMaterial.sy);
    api.actionEnd("SetGeneralProp");
    api.actionBegin("SetGeneralProp", pickedMaterial());
    api.actionRun("set", "reflection", advancedPatternCurrentMaterial.reflection);
    api.actionEnd("SetGeneralProp");
    api.actionBegin("SetGeneralProp", pickedMaterial());
    api.actionRun("set", "reflection_glossiness", advancedPatternCurrentMaterial.reflection_glossiness);
    api.actionEnd("SetGeneralProp");

    if(model.gapwidth != undefined && model.gapcolor != undefined){
    	model.gapwidth = advancedPatternCurrentUsedTile.gapwidth;
    	model.gapcolor = advancedPatternCurrentUsedTile.gapcolor;
    }
    //if(model.host && model.host.type == "WALL"){
    //	//墙面的砖颜色需要特别处理
    //	if(model.host[model.category + "Material"]){
    //		model.host[model.category + "Material"].setColor(api.stringToHexCharCode(advancedPatternCurrentUsedTile.gapcolor));
    //	}else{
    //		model.host[model.category + "Material"] = api.materialRawColorCreate(api.stringToHexCharCode(advancedPatternCurrentUsedTile.gapcolor));
    //	}    	
    //}
});

/*菜单tab页切换 UI */
$("#advancedpattern_single_dialog .tab").each(function (index) {
    $(this).on(click, function (e) {
        var tabcontainerobj = $("#advancedpattern_single_dialog .popup .tab_container .tab_" + index);
        tabcontainerobj.show();
        tabcontainerobj.siblings().hide();
        $(this).addClass("hover");
        $(this).siblings().removeClass("hover");
    });
});

/* 缝隙宽度 切换 UI */
$("#advancedpattern_single_dialog .gap_width li").each(function (index) {
    $(this).on(click, function (e) {
        $(this).children("span,input").addClass("hover");
        $(this).siblings().children("span,input").removeClass("hover");
    });
});
/* 缝隙颜色 切换 UI */
$("#advancedpattern_single_dialog .gap_color li").each(function (index) {
    $(this).on(click, function (e) {
        $(this).children("div").addClass("hover");
        $(this).siblings().children("div").removeClass("hover");
    });
});
/* 铺贴方式 切换 UI */
$("#advancedpattern_single_dialog .pavet li").each(function (index) {
    $(this).on(click, function (e) {
        if ($(this).children("div").hasClass("disabled")) return;
        $(this).children("div").addClass("hover");
        $(this).siblings().children("div").removeClass("hover");

        var pavetType = $(this).find(".hover").attr("value");//        /*铺贴方式*/
        var horizontalcuttingDiv = $("#advancedpattern_single_dialog .horizontalcutting");//        /*横切*/
        var verticalcuttingDiv = $("#advancedpattern_single_dialog .verticalcutting");//        /*竖切*/

        switch (pavetType) {
            case "0":  //ping
                horizontalcuttingDiv.show();
                verticalcuttingDiv.show();
                horizontalcuttingDiv.children("select").empty();
                verticalcuttingDiv.children("select").empty();
                for (var i = 1; i <= 10; i++) {
                    var name = (i == 1) ? "无" : ("开" + i);
                    horizontalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                    verticalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                }
                horizontalcuttingDiv.children("select").val("1");
                verticalcuttingDiv.children("select").val("1");
                break;
            case "1": //gong
                horizontalcuttingDiv.show();
                verticalcuttingDiv.hide();
                horizontalcuttingDiv.children("select").empty();
                verticalcuttingDiv.children("select").empty();
                for (var i = 1; i <= 10; i++) {
                    var name = (i == 1) ? "无" : ("开" + i);
                    horizontalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                    verticalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                }
                horizontalcuttingDiv.children("select").val("2");
                verticalcuttingDiv.children("select").val("1");
                break;

            case "2": //ren
                horizontalcuttingDiv.show();
                verticalcuttingDiv.hide();
                horizontalcuttingDiv.children("select").empty();
                verticalcuttingDiv.children("select").empty();
                for (var i = 1; i <= 5; i++) {
                    var name = (i == 1) ? "无" : ("开" + i);
                    horizontalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                    verticalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                }
                horizontalcuttingDiv.children("select").val("2");
                verticalcuttingDiv.children("select").val("1");
                break;

            case "3": //hengshu
                horizontalcuttingDiv.show();
                verticalcuttingDiv.hide();
                horizontalcuttingDiv.children("select").empty();
                verticalcuttingDiv.children("select").empty();
                for (var i = 1; i <= 10; i++) {
                    var name = (i == 1) ? "无" : ("开" + i);
                    horizontalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                    verticalcuttingDiv.children("select").append($("<option>").attr("value", i).text(name));
                }
                horizontalcuttingDiv.children("select").val("2");
                verticalcuttingDiv.children("select").val("1");
                break;
        }
    });

});

$("#advancedpattern_single_dialog .pavet li:first").trigger("click");

/*title 样式*/
$("#advancedpattern_single_dialog").tooltip();

$("#advancedpattern_single_dialog .after_process_prod img").on("click", function (e) {
    openPreviewBigImage($(this).attr("src"));
});

$("#advancedpattern_single_dialog .custom_gap_width").on("blur", function (e) {
    $(this).attr("widthvalue", 0);
    /*默认值*/
    var positive_int = /^\d+$/;
    if ($(this).val() != '' && !positive_int.test($(this).val())) {
        $(this).val("0");
        return;
    }
    $(this).attr("widthvalue", $(this).val() / 1000);
});

/*加载颜色选择控件*/
$("#advancedpattern_single_dialog .custom_gap_color").spectrum({
    theme: "sp-light",
    color: "#101010", /*默认值*/
    preferredFormat: "hex",
    showInput: true,
    showPalette: false,
    //palette: [["F8F8FF", "D3D3D3", "808080","A9A9A9","101010"]],
    cancelText: "取消",
    chooseText: "选择"
});

/*颜色控件事件*/
$("#advancedpattern_single_dialog .custom_gap_color").on("hide.spectrum dragstop.spectrum", function (e, color) {
    var colorValue = color.toHexString();
    if (colorValue.indexOf("#") != -1) {
        colorValue = colorValue.substring(colorValue.indexOf("#") + 1);
    }
    $(this).parents(".custom").attr("value", colorValue);
});
/*选择子内容，相应选中父内容*/
$("#advancedpattern_single_dialog .custom .sp-preview-inner,#advancedpattern_single_dialog .custom .sp-dd").on("click", function (e) {
    $(this).parents("li").trigger("click");
});


/*打开预览大图*/
function openPreviewBigImage(imgUrl) {
    var dialogWidth = 512;
    var dialogHeight = 512;
    var index = layer.open({
        type: 1,
        moveType: 1,
        moveOut: true,
        title: '铺贴预览大图',
        skin: 'layui-layer-default',
        fix: false,
        //closeBtn: false,
        shadeClose: false,
        maxmin: false,
        move: false,
        area: [dialogWidth + 'px', dialogHeight + 'px'],
        content: "<img id='openPreviewBigImage' src='" + imgUrl + "' style='width:100%;height:100%' />",
        success: function (layero, index) {
            $("#openPreviewBigImage").parents(".layui-layer-default").draggable();
        }
    });
}


api.application_ready_event.add(function () {
    api.pickChangedEvent.add(function (changedType, result) {
        $("#advancedpattern_single_dialog").dialog("close");
    });
});
//# sourceURL=ui\dialog/advancedpattern/advancedpattern.js
