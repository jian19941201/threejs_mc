var bomlistUrl = undefined;
var bomDialogPrompt = (function () {
    var _qrCode = new QRCode("bomqrcodecontainer", {width: 256, height: 256});

    return function (url, _title) {
        var index = layer.open({
            type: 1,
            title: _title || '报价清单二维码',
            moveType: 1,
            moveOut: true,
            skin: 'layui-layer-default',
            fix: false,
            shadeClose: false,
            maxmin: false,
            content: $('#bomDialog'),
            success: function () {
                _qrCode.clear();
                _qrCode.makeCode(url);
                bomlistUrl = url;
                $("#bomDialog .url_input").val(bomlistUrl).select();
            }
        });
    }
})();
$("#openbomurl").on(click, function () {
    window.open(bomlistUrl);
});
$("#bomqrcodecontainer").on(click, function () {
    window.open(bomlistUrl);
});


/*店面订单详情开始 add by hcw*/
var storeOrderInfo={roomInfo:[]};
var storeOrderRoomInfo=[];
var storeTempRoomInfo=[];
//初始化
function tmallOrderinit() {
     storeOrderInfo={roomInfo:[]};
     storeOrderRoomInfo=[];
     storeTempRoomInfo=[];
    $('#bomOrderDialog table tbody').find('tr.content').remove();
    $('#bomOrderDialog').find('input,textarea').val('');
    $('#bomOrderDialog').find('input[type="radio"]').attr('checked',false);
    $('#bomOrderDialog').find('span.color').hide();
    $("body").append($("<div id='MaskLayer' " +
        "style='position: absolute;width: 100%;height: 100%;top: 0;    text-align: center;line-height: 500px;" +
        " color: white; left: 0;background: rgba(0,0,0,0.6);z-index: 10000000000000000;'>正在处理订单，请稍后...</div>"));
}
function orderError(msg) {
    $('#MaskLayer').remove();
    $('#show_print_wait').hide();
    $('#bomOrderDialog .printBox').show();
    layer.msg(msg?msg:'网络繁忙，请稍后重试');
    return;
}
function checkRoomInfo(all) {
    var text=''
    if(!designId){
        text='请先保存方案'
    }
    if(!globalCustomerId){
        text='请保存方案，选择客户'
    }
    var roomNameCount=0;
    if( all.rooms.length==0){
        text='请先设计方案';
    }
    all.rooms.forEach(function (room) {
        if(room.label!=''){
            roomNameCount++
        }
    })
    if( roomNameCount!=all.rooms.length){
        text='请填写房间名';
    }
    return text
}

$("#generateOrder").on(click,function () {
    tmallOrderinit();
    function addOtherRoomInfo(room) {
        storeTempRoomInfo.push({materials:room.materials,wallMaterials:room.wallMaterials,roomInfo:{label:room.rooms[0].label,measurement:room.rooms[0].measurement},floorId:room.rooms[0].floor.id,metialsList:[],brickList:[]})
        storeOrderRoomInfo.push({materials:room.materials,roomInfo:room.rooms[0],wallMaterials:room.wallMaterials})
    }
    var uuid = api.uuid();
    storeOrderInfo.uuid = uuid;
    //普通订单
    var AllRoom=api.getBomData();
    var checkResult=checkRoomInfo(AllRoom)
    if(checkResult){
        orderError(checkResult)
        return;
    }
    var loginParam = "?userLoginId=" + globalUsrObj.globalUserLoginId + "&password=" + globalUserLoginPassword;
    api.getServiceJSONResponsePromise({
        url: '/control/rpccommonrequest' + loginParam,
        type: 'post',
        data: {'method': 'ipadCrmGetCustomer', 'customerId': globalCustomerId},
        timeout:5000,
        complete:function (req,status) {
            if(status=='timeout'){
                orderError('请求超时')
            }
        },
        error:function () {
            orderError('网络繁忙，请稍后重试')
        }
    }).then(function (data) {
        if(data.returnValue.status=='10010'){
            var customerInfo = data.returnValue.data[0].customer;
            api.getServiceJSONResponsePromise({
                url: '/control/rpccommonrequest' + loginParam,
                type: 'post',
                data: {'method': 'ipadCrmListCustomerAddress', 'customerId': globalCustomerId,userLoginId:globalUsrObj.globalUserLoginId},
                timeout:5000,
                complete:function (req,status) {
                    if(status=='timeout'){
                        orderError('请求超时')
                    }
                },
                error:function () {
                    orderError('网络繁忙，请稍后重试')
                }
            }).then(function (resp) {
                if(resp.returnValue.status=='30000'){
                    var customerAddress=resp.returnValue.data[0];
                    customerInfo.customerFullAddress=customerAddress.provinceName+customerAddress.cityName+customerAddress.areaName+customerAddress.address;
                    storeOrderInfo.address = customerInfo;
                    AllRoom.rooms.forEach(function (room) {
                        var model=api.getBomOneData( room.floor.id );
                        addOtherRoomInfo(model);
                    })
                    showCustomerInfo(storeOrderInfo);
                    showOtherOrderList(storeOrderRoomInfo);
                }else{
                    orderError('网络繁忙，请稍后重试')
                }
            })
        }else{
            orderError('网络繁忙，请稍后重试')
        }
    })
})

/*生成报价单,先写入CRM后台*/
function writeOrderToCrm() {
    if(storeOrderInfo.length==0){
        $('#show_print_wait').hide();
        orderError('参数错误，请重新生成订单');
        return
    }
    var text='确定打印订单？'
    layer.confirm(text,{},function (index) {
        $('#show_print_wait').show();
        var loginParam = "?userLoginId=" + globalUsrObj.globalUserLoginId + "&password=" + globalUserLoginPassword;
        function makeCrmData(customer,proInfo) {
            var list =[];
            var data=[];
            var discount=0;
            var allPrices=0;
            proInfo.metials.forEach(function (p) {
                p.amountActual=p.priceSelling;
                data.push(p);
            })
            data.forEach(function (f) {
                allPrices+=f.amountActual*f.quantity.toString();
                discount+=f.discountAmount;
                list.push({productCode:f.productId?f.productId:"0",productId:f.productId?f.productId:"0",productName:f.productName,price:f.priceSelling.toString(),count:f.quantity.toString(),discount:f.discountAmount==0?"100":f.discountAmount.toString(),waste:"0",remark:"",title:"",img:""})
            })
            $.each(list, function (key, value) {
                value.title = '';
                value.img = '';
            });
            var postData = {};
            postData['list'] = JSON.stringify(list);     //主要商品数据
            postData['customerId'] = globalCustomerId;  //客户ID
            postData['method'] = 'ipadCreateQuotation';   //调用生成报价单方法
            postData['type'] = 'post';                    //提交方式
            postData['freight'] = "0";  //运费
            postData['processCost'] = "0";//加工费
            postData['dealFinalPrice'] = allPrices.toFixed(2).toString();//总合计（用户修改）
            postData['shopId'] = customer.shopId;            //门店ID
            postData['municipalId'] = customer.municipalId;   //加盟商ID
            postData['discountRateTotal'] = discount==0?100:discount.toFixed(2).toString();//总折扣
            postData['oppId']=globalOppId;
            return postData
        }
        api.getServiceJSONResponsePromise({
            url: '/control/rpccommonrequest' + loginParam,
            type: 'post',
            data: {'method': 'ipadCrmGetCustomer', 'customerId': globalCustomerId},
            timeout:5000,
            complete:function (req,status) {
                if(status=='timeout'){
                    orderError('请求超时')
                }
            },
            error:function () {
                orderError('网络繁忙，请稍后重试')
            }
        }).then(function (data) {
            if (data.returnValue.status == '10010') {
                var customer = data.returnValue.data[0].customer;
                if (globalCustomerId == '') {
                    orderError('当前客户信息为空，无法生成报价单。');
                    return;
                }
                var postData=makeCrmData(customer,storeOrderInfo);
                api.getServiceJSONResponsePromise({
                    url: '/control/rpccommonrequest' + loginParam,
                    type: 'post',
                    data: postData,
                    timeout:5000,
                    complete:function (req,status) {
                        if(status=='timeout'){
                            orderError('请求超时')
                        }
                    },
                    error:function () {
                        orderError('网络繁忙，请稍后重试')
                    }
                }).then(function (data) {
                    if (data.returnValue.status == "30004") {
                        /*成功写入CRM后台*/
                        api.getServiceJSONResponsePromise({
                            url: appSettings.designjavadomain+'/design/control/setQuoteId',
                            type: 'post',
                            data: {designId:designId,quoteId:data.returnValue.data.quoteId},
                            timeout:5000
                        }).then(function (res) {
                            if(res.returnValue.responseMessage && res.returnValue.responseMessage=='success'){
                                    printDesignOrder();
                                    successDealOppId();
                            }else{
                                orderError('报价单写入CRM系统失败~');
                            }
                        })
                    } else {
                        orderError('报价单写入CRM系统失败~');
                    }
                });
            } else {
                orderError("网络异常，请刷新页面重试~~");
            }
        })
        layer.close(index);
    })
}
function successDealOppId() {
    if(globalOppId){
        //发送成功后请求商机接口处理
        api.getServiceJSONResponsePromise({
            type:"get",
            data:{oppId:globalOppId},
            url:appSettings.designjavadomain+"/control/createSalesOrder"
        }).then(function (res) {

        })
    }
}
$('#bomOrderDialog .order_detial').on('click','div.textarea',function () {
    $('#bomOrderDialog .order_detial').find('tr.content').find('div.textarea').removeClass('textareaSelect');
    $(this).addClass('textareaSelect')
});
$('#bomOrderDialog .order_detial').on('blur','div.textarea',function () {
    $('#bomOrderDialog .order_detial').find('tr.content').find('div.textarea').removeClass('textareaSelect');
});
$('#bomOrderDialog .orderBottom').on('click','input[type="radio"]',function () {
    $(this).parent('p').siblings('p').find('span.color').css('display','none');
    $(this).next('span').css('display','inline-block');
})
laydate.render({
    elem: '#bomTime', //指定元素
    min: 0
});
laydate.render({
    elem: '#sendTime', //指定元素
    min: 0
});
//打印设计方案
$('#printOrderList').on('click',function () {
    writeOrderToCrm();
})
function printDesignOrder() {
    matchOtherHtmlSpace();
    $('#bomOrderDialog .printBox').hide();
    var h=$('#bomOrderDialog')[0].scrollHeight+100;
    html2canvas($('#bomOrderDialog'), {
        allowTaint:false,
        height:h,
        onrendered: function (canvas) {
            var contentWidth = canvas.width;
            var contentHeight = canvas.height;
            //一页pdf显示html页面生成的canvas高度;
            var pageHeight = contentWidth /841.89 * 595.28;
            //未生成pdf的html页面高度
            var leftHeight = contentHeight;
            //页面偏移
            var position = 0;
            //a4纸的尺寸(打横)[841.89,595.28]，html页面生成的canvas在pdf中图片的宽高

            var pageData = canvas.toDataURL('image/png', 1.0);

            var pdf = new jsPDF('l', 'pt', 'a4');

            //有两个高度需要区分，一个是html页面的实际高度，和生成pdf的页面高度(841.89)
            //当内容未超过pdf一页显示的范围，无需分页
            if (leftHeight < pageHeight) {
                pdf.addImage(pageData, 'PNG', 0, 0, 0, 0 );
            } else {
                while(leftHeight > 0) {
                    pdf.addImage(pageData, 'PNG', 0, position, 0, 0)
                    leftHeight -= pageHeight;
                    position -= 595.28;
                    //避免添加空白页
                    if(leftHeight > 0) {
                        pdf.addPage();
                    }
                }
            }
            var name = "订单详情-" + (new Date()).toLocaleString() + ".pdf";
            pdf.save(name);
            orderError('打印完成')
            $('#bomOrderDialog').find('.addSpaceHeight').remove();
        },
        background:"#fff",
        useCORS:true
    });
}
function addSpaceHeight(elem,type,h) {
    if(elem){
        var height=h?h:0;
        var html='<div class="clear addSpaceHeight" style="height:'+height+'px"></div>';
        if(type=='append'){
            $(elem).append(html)
        }else if(type=='before'){
            $(elem).before(html)
        }else if(type=='after'){
            $(elem).after(html)
        }
    }
}
function matchOtherHtmlSpace() {
    var startH=378,spaceH=794;
    var time=0;
    var Table=$('#bomOrderDialog .order_detial').find('table');
    startH+=$(Table).height();
    if(startH>spaceH){
        startH-=$(Table).height();
        var allTr=$(Table).find('tr.content');
        for (var o=0;o<allTr.length;o++){
            startH+=$(allTr[o]).height();
            if(startH>spaceH){
                time++;
                startH-=$(allTr[o]).height();
                var space=spaceH-startH;
                addSpaceHeight($(allTr[o]),'before',space);
                startH=$(allTr[o]).height();
            }
        }
    }
    if(startH>(spaceH-353) && time>0){
        addSpaceHeight($('#bomOrderDialog .order_detial'),'after',spaceH-startH);
    }
}
$('#bomOrderDialog ').find('.customerPhone,.salePhone,.builderPhone,.moneyInput,.orderBottom input.numberInput').on('input',function () {
    var num=$(this).val();
    if (isNaN(Number(num)) || num<0){
        layer.msg('请输入数字');
        num=num.substring(0,num.length-1)
        $(this).val(num);
    }
    setReceivablesMoney(this,num)
})
$('#bomOrderDialog ').find('.customerPhone,.salePhone,.builderPhone,.moneyInput,.orderBottom input.numberInput').on('keyup',function () {
    var num=$(this).val();
    if (isNaN(Number(num)) || num<0){
        num="";
        layer.msg('请输入数字');
        $(this).val("");
    }
    setReceivablesMoney(this,num,1)
})
function setReceivablesMoney(elem,num,set) {
    if($(elem).hasClass('receivablesMoney') || $(elem).hasClass('unReceivableMoney')){
        var allPrice=Number($('#bomOrderDialog').find('label.allPrice').text());
        if(allPrice==0){
            $(elem).val("");
            if(set)layer.msg('请补充单价与数量');
            return
        }
        if(num>allPrice){
            layer.msg('输入值不能大于总金额')
            $(elem).val( num.substring(0,num.length-1));
        }else
            $(elem).parent('p').siblings().find('.moneyInput').val(allPrice-num)
    }
}
//禁止输入框长按
!function addInputEvent() {
    var elemArray=[$('#bomOrderDialog ').find(".customerPhone")[0],$('#bomOrderDialog ').find(".salePhone")[0],$('#bomOrderDialog ').find(".builderPhone")[0],$('#bomOrderDialog ').find(".receivablesMoney")[0],$('#bomOrderDialog ').find(".unReceivableMoney")[0],$('#bomOrderDialog ').find(".orderBottom input[type='text']")[0]];
    elemArray.forEach(function (item) {
        var kflag = false;
        var ele = item;
        ele.addEventListener('keypress', function(e){
            if( kflag ){
                e.preventDefault();
            }else{
                kflag = true;
            }
        }, false);
        ele.addEventListener('keyup', function(e){
            kflag = false;
        }, false);
    })
}();
$('#bomOrderDialog .orderAllPrice').find('input.tmallDecPrice').on('keyup',function () {
    var mun=$(this).val()
    if (isNaN(Number(mun))){
        $(this).val('');
        mun=0;
    }
    var price= parseFloat($('#bomOrderDialog .tian_mao_detial .tianmao .detial p.allPrice').find('span').html())
    if(mun>=price){
        $(this).val('');
        mun=0
    }
    $('#bomOrderDialog .pay_order .middle .buttom .right').find("h2").html("￥:"+(price-mun))
    $('#bomOrderDialog .orderAllPrice').find('span.total').html(price-mun)
})

//订单显示
function showOtherOrderList(info) {
    if(info.length>0){
            initComputeRoomTilesAmount(info);
    }
}
function showCustomerInfo(data) {
    var address=data.address;
    $('#bomOrderDialog .pay_order .middle .top').find("span.orderNum label").html(data.uuid);
    $('#bomOrderDialog .pay_order .middle .buttom .customerName').val(address.customerName);
    $('#bomOrderDialog .pay_order .middle .buttom .customerPhone').val(address.mobile);
    $('#bomOrderDialog .pay_order .middle .buttom .customerAddress').val(address.customerFullAddress);
    $('#bomOrderDialog .pay_order .middle .buttom .storeName').val(address.shopName);
    $('#bomOrderDialog .pay_order .middle .buttom .storeAddress').val(address.shopAddress);
}

//获取当前时间
function getNowFormatDate(data) {
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
        + " " + (date.getHours()>9?date.getHours():'0'+date.getHours()) + seperator2 + (date.getMinutes()>9?date.getMinutes():'0'+date.getMinutes())
        + seperator2 + (date.getSeconds()>9?date.getSeconds():'0'+date.getSeconds());
    if(data){
        currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
    }
    return currentdate;
}



//改变砖价钱
function  changeOrtherBrickPrice() {
    var allTableTr=$('#bomOrderDialog .order_detial table tr.content');
    var allPrices=0;
    allTableTr.each(function (i,e) {
        var price=0;
        price=Number($(e).find('input.price').val())*Number($(e).find('input.brickNum').val());
        allPrices+=price;
        $(e).find('label.brickPrice').text(price);
    })
    $('#bomOrderDialog .orderBottom').find('label.allPrice').html(allPrices.toFixed(2))
    $('#bomOrderDialog .orderBottom').find('.moneyInput').val('');
    var allInput=$('#bomOrderDialog .order_detial table tr.content').find('input.price')
    var newArray=[];
    var newAllInput={};
    for(var d=0;d<allInput.length;d++){
        if(newAllInput[$(allInput[d]).attr('pid')]){
            newAllInput[$(allInput[d]).attr('pid')].quantity+=$(allInput[d]).parent('td').next('td').find('input.brickNum').val()*1
            newAllInput[$(allInput[d]).attr('pid')].priceSelling+=$(allInput[d]).val()*1
        }else{
            newAllInput[$(allInput[d]).attr('pid')]={priceSelling:$(allInput[d]).val()*1,quantity:$(allInput[d]).parent('td').next('td').find('input.brickNum').val()*1}
        }
    }
    storeOrderInfo.metials=[];
    allBrickArray.forEach(function (b) {
        if(newAllInput[b.pid]){
            b.priceSelling=0;
            b.skuCode=b.model;
            b.productName=b.title;
            b.discountAmount=0;
            b.priceSelling=newAllInput[b.pid].priceSelling;
            b.quantity=newAllInput[b.pid].quantity
            newArray.push(b)
        }
    });
    storeOrderInfo.roomInfo=storeTempRoomInfo;
    storeOrderInfo.metials=newArray;
}
$("#bomOrderDialog .order_detial table").on('keyup','input', function () {
    var value=$(this).val();
    if(value.substring(0,2)==="00")$(this).val(0);
    if($(this).attr('class')=='brickNum'){
        value=value.replace(/[.]/g,"");
        $(this).val(value);
        if (isNaN(Number(value))|| Number(value) < 1 || value=='' || !(/^\+?[1-9][0-9]*$/).test(Number(value))){
            $(this).val(0);
        }
        if(value.length>8){
            $(this).val(value.substring(0,8));
            changeOrtherBrickPrice();
            return;
        }
    }else{
        if (isNaN(Number(value))){
            $(this).val(0);
        }
    }
    value=value.replace(/\b(0+)/gi,"");
    if(value>=1)$(this).val(value);
    changeOrtherBrickPrice();
});

//读取非天猫清单 砖的价钱
var allBrickArray=[];
function loadOrtherBrickPrice(info,price) {
    info.forEach(function (f) {
        allBrickArray.push(f)
    })
    allBrickArray=removeDuplicatedItem(allBrickArray);
    if(price){
        var allPirce=[];
        allBrickArray.forEach(function (b,i) {
            api.getServiceJSONResponsePromise({
                url: appSettings.designjavadomain+'/control/getCrmProductPrice',
                type: 'post',
                async:false,
                data: {'shopId':globalUsrObj.globalShopId,productId:b.productId?b.productId:0}
            }).then(function (res) {
                if(res.returnValue && (res.returnValue.status=='10011')){
                    var p=Math.ceil(Math.random()*20)
                    allPirce.push({pid:b.pid,price:res.returnValue.data.productPrice})
                }else{
                    allPirce.push({pid:b.pid,price:0})
                }
                if(allBrickArray.length==(i+1)){
                    var allList=$('#bomOrderDialog .order_detial table tr.content').find('input.price');
                    allPirce.forEach(function (a) {
                        for(var q=0;q<allList.length;q++){
                            a.pid==$(allList[q]).attr('pid')? $(allList[q]).val(a.price):""
                        }
                    })
                    changeOrtherBrickPrice();
                }
            })
        })
    }
    function removeDuplicatedItem(arr) {
        var tmp = {}, ret = [];
        for (var i = 0, j = arr.length; i < j; i++) {
            if (!tmp[arr[i].pid]) {
                tmp[arr[i].pid] = 1;
                ret.push(arr[i]);
            }
        }
        return ret;
    }
}
//==============================计算用砖==2017-11-17完成主要功能========================================================
//以下版本是算面积并绑定相关数据输出到页面，不用画出切砖 oxl-2017-1101
function initComputeRoomTilesAmount(allInfo){
    var info=allInfo[0],roomInfo=info.roomInfo;
    allInfo.splice(0,1);
    if(!roomInfo.hasOwnProperty('floor'))return;
    api.utilFloorTileAmountCompute(roomInfo.floor);
    //0.2区域
    roomInfo.floorareas.forEach(function (val, i) {
        api.utilFloorTileAmountCompute(val);
    })
    //0.3波打线
    roomInfo.boundarys.forEach(function (val, i) {
        api.utilFloorTileAmountCompute(val);
    })
    //0.4墙砖 遍历墙体-算砖
    utilGetWallsDetails(roomInfo,api.utilWallTileAmountCompute);
    //1.克隆svg defs 标签的字符串，并将img url转成base64，才能显示图片
    var defsClone,tempHtml="";
    $("#orderListTbl tbody").empty();
    //缓存要插入图片的td选择器，运行时执行->实时更新
    localPromise(function(resolve,reject){
        //1.floor
        [roomInfo.floor].forEach(function (val, i) {
            insterDataIntoOrder(val,'',info);
            setTileDetailsToPage(val,info,resolve)
        })
    }).then(function(index){
        //2.floorareas TODO svg def defined img can public use?
        roomInfo.floorareas.forEach(function (val, i) {
            localPromise(function(resolve,reject){
                insterDataIntoOrder(val,'',info);
                setTileDetailsToPage(val,info,resolve)
            })
        })
    }).then(function(){
        //3.boundarys
        roomInfo.boundarys.forEach(function (val, i) { //val 波打线实例
            localPromise(function(resolve,reject){
                insterDataIntoOrder(val,'boundarys',info);
                setTileDetailsToPage(val,info,resolve)
            })
        })
    }).then(function () {
        //4.walls-遍历墙体-画图
        utilGetWallsDetails(roomInfo,setWallTileDetailsToPage,info)
    }).then(function () {
        var allMaterials=[];
        if(info.wallMaterials.length>0){
            allMaterials=(info.materials).concat(info.wallMaterials);
        }else{
            allMaterials=info.materials;
        }
        loadOrtherBrickPrice(allMaterials);
        if(allInfo.length>0){
            initComputeRoomTilesAmount(allInfo)
        }else{
            $("#bomOrderDialog").dialog({
                width: 1160,
                resizable: true,
                modal: false,
                height: 900,
                open:function(tag){
                    $(tag.target).parent('div[aria-describedby="bomOrderDialog"]').css({zIndex:999});
                    $('#MaskLayer').remove();
                }
            });
            loadOrtherBrickPrice(allMaterials,true);
        }
    });
}
//遍历墙砖的数据-oxl 2018-02-28
function utilGetWallsDetails(models,callback,orderInfo){
    //var wallsLength=models.rooms[0].walls.length;
    var boardsLength=0,rectArea3dsLength=0,roundArea3dsLength=0;

    //1.遍历各面墙
    models.walls.forEach(function (wallItem, i1) {
        //墙砖board（等同于地板砖，区域不算）的记录数
        //2.遍历board
        if(!boardsLength && wallItem.boards.length>0){
            boardsLength=wallItem.boards.length;
        }

        //3.遍历矩形区域
        if(!rectArea3dsLength && wallItem.rectArea3ds.length>0){
            rectArea3dsLength=wallItem.rectArea3ds.length;
        }

        //4.遍历圆形区域
        if(!roundArea3dsLength && wallItem.roundArea3ds.length>0){
            roundArea3dsLength=wallItem.roundArea3ds.length;
        }
        localPromise(function(resolve,reject){
            var temp;
            wallItem.boards.forEach(function(boardItem,i2){
                if( parseInt(i2+1) === boardsLength ){
                    temp=resolve;
                }
                if(orderInfo){
                    callback && callback.call(this,boardItem,orderInfo,temp);
                }else{
                    callback && callback.call(this,boardItem,temp);
                }

            });
        });

        localPromise(function(resolve,reject){
            var temp;
            wallItem.rectArea3ds.forEach(function(rectArea3dItem,i3){
                if( parseInt(i3+1) === rectArea3dsLength ){
                    temp=resolve;
                }
                if(orderInfo){
                    callback && callback.call(this,rectArea3dItem,orderInfo,temp);
                }else{
                    callback && callback.call(this,rectArea3dItem,temp);
                }

            });

        });

        localPromise(function(resolve,reject){
            var temp;
            wallItem.roundArea3ds.forEach(function(roundArea3dItem,i4){
                if( parseInt(i4+1) === roundArea3dsLength ){
                    temp=resolve;
                }
                if(orderInfo){
                    callback && callback.call(this,roundArea3dItem,orderInfo,temp);
                }else{
                    callback && callback.call(this,roundArea3dItem,temp);
                }
            });

        })
    })
}

function setWallTileDetailsToPage(v,parentObj,resolve) {
    var tile="",tempHtml="",tdSet="";
    var model=v,mid=model.areaMaterial.id,measurementCount=model.measurementCount,clipedTiles=model.floorRectTiles, pid=model.areaMaterial.pid;
    var tempObj=model.areaMaterial.meta;
    var svgstr=model.svgstr,fillUrl=svgstr.fillUrl,paths=svgstr.paths,clippaths=svgstr.clippaths;
    var floorId=parentObj.roomInfo.floor.id;
    var total=0;
    var tempOtherMeasurement=0;
    //单块整砖的面积
    var prdMeasurement=tempObj.xlen * tempObj.ylen;
    measurementCount && measurementCount.some(function(v2,i2){
        //不过滤直接统计
        total+=v2.count;
        //最后一个遍历结束时，拿到数量输出到页面
        if( (i2+1) ==measurementCount.length){
            //直接加上损耗
            //向上取整-2017-12-08
            total=Math.ceil( total );
            //0.调整按比例波打线的显示效果，波打线直接按数量来统计(顶角在下面再另外处理)
            tdSet='<td>'+(parentObj.roomInfo?parentObj.roomInfo.label+"(墙体)":parentObj.label+"(墙体)")+'</td><td>'+parentObj.roomInfo.measurement+'</td><td>'+tempObj.title+'</td><td>'+(tempObj.xlen*1000)+"×"+(tempObj.ylen*1000)+'</td><td ><input class="price" type="text" value="" pid="'+pid+'" /></td><td id="wall_'+pid+floorId+'_total"><input class="brickNum" type="text" value="'+total+'" ></td> <td><label class="brickPrice"></label></td><td><div class="textarea" contenteditable="true"></div><span class="printShow"></span></td>'
            tempHtml='<tr class="content" id="wall_'+pid+floorId+'">'+tdSet+'</tr>';
            if($("#wall_"+pid+floorId).length){
                var tempTotal= $("#wall_"+pid+floorId+"_total").find('input').val()*1+total;
                $("#wall_"+pid+floorId+"_total").find('input').val(tempTotal);
            }else{
               $('#bomOrderDialog table tbody').append(tempHtml)
            }
            resolve && resolve();
        }
    });
}

//填充砖的信息到页面---v：某块区域实例；parentObj：整个当前空间 oxl1101
function setTileDetailsToPage(v,parentObj,resolve) {
    var model=v,measurementCount=v.measurementCount,pid=v.pid || v.baseMaterial.pid;
    var floorId=parentObj.roomInfo.floor.id
    var tile="",tempHtml="",tdSet="";
    var tempObj={};
    parentObj.materials.some(function(v1,i1){
        if(pid==v1.pid){
            return tempObj={
                model:v1.model==null?"暂无":v1.model,
                pid:v1.pid,
                sque:v1.sque,
                title:v1.title,
                xlen:v1.xlen,
                ylen:v1.ylen,
                zlen:v1.zlen
            }
        }
    })
    var total=0;
    var tempOtherMeasurement=0;
    //单块整砖的面积
    var prdMeasurement=tempObj.xlen * tempObj.ylen;
    measurementCount && measurementCount.some(function(v2,i2){

        //统计整砖面积的块数，或者切砖的面积大于整砖面积的一半时，当成一块砖
        if( v2.value==prdMeasurement || v2.value>= prdMeasurement / 2 ){
            total+=v2.count;
        }
        //少于 1/4 砖的 都算 1/4,最小值要大于 0.01，再小就无意义
        else if( v2.value <= prdMeasurement / 4 && v2.value>=0.01){
            total=total + v2.count*0.25;
        }
        else{
            // tempOtherMeasurement=tempOtherMeasurement + v2.value * v2.count ;
            //单块砖的面积乘数量--小于1半，大于1/4的砖当半块；
            total=total + v2.count*0.5;
        }

        //最后一个遍历结束时，拿到数量输出到页面
        if( (i2+1) ==measurementCount.length){

            //自定义区域数量 +5%
            if( $.inArray(model.type,["FREEAREA"])>=0 ){
                total=total*1.05;
            }
            //地板砖，区域，需要向上取整；
            //向上取整-2017-12-08
            total=Math.ceil( total );
            //0.调整按比例波打线的显示效果，波打线直接按数量来统计(顶角在下面再另外处理)
            if( model.type=="BOUNDARY" ){
                //波打线 的base id == 切砖的 id，过滤出来边线，其余就是顶角
                var boundarysMatId=model.baseMaterial && model.baseMaterial.id;
                var boundaryTileCount=0;
                model.clipedTiles.some(function(boundaryTile,i){
                    if( boundarysMatId == boundaryTile.bounaryMaterialId ){
                        boundaryTileCount+=1;
                    }
                })

                total=boundaryTileCount;
            }
            var detialPosition="(地面)";
            tdSet='<td>'+(parentObj.roomInfo?parentObj.roomInfo.label+detialPosition:parentObj.label+detialPosition)+'</td><td>'+parentObj.roomInfo.measurement+'</td><td>'+tempObj.title+'</td><td>'+tempObj.sque+'</td><td ><input class="price" type="text" value="" pid="'+pid+'" /></td><td id="'+pid+floorId+'_total"><input class="brickNum" type="text" value="'+total+'" ></td> <td><label class="brickPrice"></label></td><td><div class="textarea" contenteditable="true"></div><span class="printShow"></span></td>';
            tempHtml='<tr class="content" id="'+pid+floorId+'">'+tdSet+'</tr>';
            //id唯一，页面存在一个id记录时,后续出现相同id的数量，都添加到这个唯一id的 数量里面
            if($("#"+pid+floorId).length){
                var tempTotal= $("#"+pid+floorId+"_total").find('input').val()*1+total;
                $("#"+pid+floorId+"_total").find('input').val(tempTotal);
            }else{
                $('#bomOrderDialog table tbody').append(tempHtml)
            }

            //TODO 如果需求改变需要将砖归类到大砖一起统计 2017-11-07
            //TODO 波打线顶角需要 统计整砖面积的块数，或者切砖的面积大于整砖面积的一半时，当成一块砖
            //1.1 插入波打线顶角:波打线4个角做了特别处理，分别统计4个角的数量，即使使用了地板的大砖也是分开计算
            //1.2 波打线第二种形式是没有顶角，加个判断，
            //1.3 添加了 left right 波打线的计算
            if(v.cornerMaterial && v.cornerMaterial.clipedTiles.length>0){
                //角砖
                genboundarys(model,"corner",genboundarysCb2,parentObj);
                //角砖的左右辅助砖
                model.leftMaterial && genboundarys(model,"left",genboundarysCb2,parentObj);
                model.rightMaterial && genboundarys(model,"right",genboundarysCb2,parentObj);

            }
            resolve();
        }
    });

}
//===============================第二版=======================================
//波打线算砖插入dom callback2
function genboundarysCb2(model,side,obj,parentObj){
    var meta=obj.meta,
        sideStr=obj.sideStr,
        boundaryRectH=obj.boundaryRectH,
        boundaryRectW=obj.boundaryRectW,
        boundaryWH=obj.boundaryWH,
        metaWH=obj.metaWH,
        sideMaterial=obj.sideMaterial,
        boundaryTotal=obj.boundaryTotal;
    var floorId=parentObj.roomInfo.floor.id;
    var boundaryTdSet="",boundaryTempHtml="";
    var detialPosition="(地面)";
    var boundarySque=boundaryRectH * boundaryRectW < meta.xlen* meta.ylen ? boundaryWH+'<br/>'+'/'+metaWH : metaWH;
    boundaryTdSet='<td>'+(parentObj.roomInfo?parentObj.roomInfo.label+detialPosition:parentObj.label+detialPosition)+'</td><td>'+parentObj.roomInfo.measurement+'</td><td>'+meta.title+'</td><td>'+boundarySque+'</td><td><input class="price" pid="'+meta.pid+'"/></td><td id="fullitem_'+side+'_'+meta.pid+floorId+'_total"><input type="text" class="brickNum" value="'+boundaryTotal+'"/></td><td><label class="brickPrice"></label><td><div class="textarea" contenteditable="true"></div><span class="printShow"></span></td>';
    boundaryTempHtml='<tr class="content" id="fullitem_'+side+'_'+meta.pid+floorId+'" >'+boundaryTdSet+'</tr>';
    //2.id唯一，页面存在一个id记录时,后续出现相同id的数量，都添加到这个唯一id的 数量里面，这里做了产品分类，地砖，波打线分开统计，
    //3.如果不按空间分类，按砖分类，需要将id 【"#fullitem_"+side+"_"+meta.pid】前缀删去，并计算相应的面积
    if($("#fullitem_"+side+"_"+meta.pid+floorId).length){
        var tempboundaryTotal= $("#fullitem_"+side+"_"+meta.pid+floorId+"_total").find('input').val()*1+boundaryTotal;
        $("#fullitem_"+side+"_"+meta.pid+floorId+"_total").find('input').val(tempboundaryTotal);
    }else{
        $('#bomOrderDialog table tbody').append(boundaryTempHtml)
    }
}

//波打线算砖，波打线算砖清单插入dom：公用计算相关数值
function genboundarys(model,side,callback,parentObj){

    var sideMaterial = side + "Material";
    //第一块角砖
    var boundaryTile0=model[sideMaterial].clipedTiles[0];
    var meta=model[sideMaterial].meta;
    //裁减后的实际尺寸 boundaryRectH ，原砖尺寸 boundaryOrginH
    var boundaryRectH=boundaryTile0.rectH,boundaryRectW=boundaryTile0.rectW,
        boundaryOrginH=boundaryTile0.paveH,boundaryOrginW=boundaryTile0.paveW;

    var boundaryTileNotCount=0;
    var boundaryTileLength=model[sideMaterial].clipedTiles.length;
    model[sideMaterial].clipedTiles.some(function(boundaryTile,boundaryTileIndex){
        if(boundaryTile.measurement==0){
            boundaryTileNotCount+=1;
        }
    })
    //实际角的数量
    var boundaryTileCount=boundaryTileLength-boundaryTileNotCount;
    //实际用砖面积
    var boundaryTempOtherMeasurement=(boundaryRectH * boundaryRectW) * boundaryTileCount ,
        //实际用砖面积/原砖尺寸=数量
        boundaryTotal=Math.ceil( boundaryTempOtherMeasurement / (boundaryRectH * boundaryRectW) );// boundaryOrginH * boundaryOrginW,大砖尺寸
    //用砖规格 metaWH 原砖尺寸,裁减后尺寸 boundaryWH
    var metaWH=meta.xlen*1000+" X "+meta.ylen*1000, boundaryWH=boundaryRectH*1000+" X "+boundaryRectW*1000;
    var sideStr=(side=="left") ? "左辅助" : (side=="right") ? "右辅助": "";

    var obj={ sideStr:sideStr,sideMaterial:sideMaterial,boundaryRectH:boundaryRectH,boundaryWH:boundaryWH,boundaryRectW:boundaryRectW,meta:meta,metaWH:metaWH,boundaryTotal:boundaryTotal }
    return callback && callback(model,side,obj,parentObj);
}

var productUrl=function(id){
    return "http://pic.oceano.com.cn/h5filesystem/products/"+id+"/top.jpg"
}


function localPromise(fun){
    return new Promise(function (resolve, reject) {
        fun(resolve,reject);
    });
}
//==============================计算用砖==2017-11-17完成主要功能========================================================


function insterDataIntoOrder(val,type,roomInfo) {
    if(type=='boundarys'){
        var infob = {
            type:val.type,
            materialid: val.id,
            pid: val.baseMaterial.pid,
            baseMaterial:{id:val.baseMaterial.id},
            measurementCount: val.measurementCount,
            clipedTiles: val.clipedTiles,
            svgstr: val.svgstr,
        }
        if(val.leftMaterial && val.leftMaterial.clipedTiles.length > 0){
            infob.leftMaterial = {};
            infob.leftMaterial.id = val.leftMaterial.id
            infob.leftMaterial.meta = val.leftMaterial.meta
            infob.leftMaterial.clipedTiles = val.leftMaterial.clipedTiles
            infob.leftMaterial.title=val.leftMaterial.title
            infob.leftMaterial.model=val.leftMaterial.model
        }
        if(val.rightMaterial && val.rightMaterial.clipedTiles.length > 0){
            infob.rightMaterial = {};
            infob.rightMaterial.id = val.rightMaterial.id
            infob.rightMaterial.meta = val.rightMaterial.meta
            infob.rightMaterial.clipedTiles = val.rightMaterial.clipedTiles
            infob.rightMaterial.title=val.rightMaterial.title
            infob.rightMaterial.model=val.rightMaterial.model
        }
        if (val.cornerMaterial && val.cornerMaterial.clipedTiles.length > 0) {
            infob.cornerMaterial = {};
            infob.cornerMaterial.id = val.cornerMaterial.id
            infob.cornerMaterial.meta = val.cornerMaterial.meta
            infob.cornerMaterial.clipedTiles = val.cornerMaterial.clipedTiles
            infob.cornerMaterial.title=val.cornerMaterial.title
            infob.cornerMaterial.model=val.cornerMaterial.model
        }
    }else{
        if(type=='wall'){
            var infob = {
                type:val.type,
                materialid: val.id,
                pid: val.areaMaterial.pid,
                measurementCount: val.measurementCount,
                svgstr: val.svgstr
            }
        }else{
            var infob = {
                type:val.type,
                materialid: val.materialid,
                pid: val.pid,
                measurementCount: val.measurementCount,
                clipedTiles: val.clipedTiles,
                svgstr: val.svgstr
            }
        }
    }
    storeTempRoomInfo.forEach(function (info) {
        if(info.floorId==roomInfo.roomInfo.floor.id){
            info.metialsList.push(infob);
        }
    })
}



//# sourceURL=ui\dialog/bom/bom.js