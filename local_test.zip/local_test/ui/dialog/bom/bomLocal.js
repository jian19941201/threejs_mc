// 清单列表
//generateOrder list_detial
window.bomDebug=true
$('#generateOrder2').on(click,function () {
    //画出具体的切砖-版本1
    // initComputeRoomTiles2();
    // $("#all_list_detial").dialog({
    //     width: 1040,
    //     resizable: 0,
    //     modal: true,
    //     height: 500,
    // })
    // 输出全砖-版本2
    initComputeRoomTilesAmount2();
    $("#wrap_orderList").dialog({
        width: 900,
        resizable: true,
        modal: true,
        height: 500
    })

})


//==============================计算用砖==2017-11-17完成主要功能========================================================
//第一第二版一起用;第一版是配件清单，第二版是所有砖的统计概览
//算砖开始
//======================第一版======================
//以下版本是算周长并画出切好砖的图片到页面
function initComputeRoomTiles2(prdIdArr){
    //0.选择房间，
    var room=api.pickGetPicked();
    //缓存本次选取的结果model集合对象；
    var models=api.getBomOneData( room[0].model.id );

    console.log(room)

    console.log(models)
    //0.执行算砖任务,地板，区域，波打线
    localPromise(function(resolve,reject){
        utilFloorTileAmountCompute(models.rooms[0].floor,resolve);
    }).then(function(){
        var temp;
        localPromise(function(resolve,reject){
            models.rooms[0].floorareas.forEach(function (val, i) {
                if(i+1==models.rooms[0].floorareas.length){
                    temp=resolve;
                }
                utilFloorTileAmountCompute(val,temp);
            })
        })

    }).then(function(){
        var temp;
        localPromise(function(resolve,reject){
            models.rooms[0].boundarys.forEach(function (val, i) {
                if(i+1==models.rooms[0].boundarys.length){
                    temp=resolve;
                }
                utilFloorTileAmountCompute(val,temp);
            })
        })

    }).then(function(){
        //算墙砖
        //TODO 如果出现bug board和矩形区域，原型区域分开遍历计算 oxl 2018-02-26

        var wallsLength=models.rooms[0].walls.length;
        var boardsLength=0,rectArea3dsLength=0,roundArea3dsLength=0;

        //1.遍历各面墙
        models.rooms[0].walls.forEach(function (wallItem, i1) {
            //console.log("扑街board外层 i1："+i1)
            //墙砖board（等同于地板砖，区域不算）的记录数
            //2.遍历board
            if(!boardsLength && wallItem.boards.length>0){
                boardsLength=wallItem.boards.length;
            }
            localPromise(function(resolve,reject){
                var temp;
                wallItem.boards.forEach(function(boardItem,i2){
                    console.log("boards的遍历111111111111111");
                    if( parseInt(i2+1) === boardsLength ){
                        temp=resolve;
                    }
                    utilWallTileAmountCompute(boardItem,temp);
                });
            });

            //3.遍历矩形区域
            if(!rectArea3dsLength && wallItem.rectArea3ds.length>0){
                rectArea3dsLength=wallItem.rectArea3ds.length;
            }
            localPromise(function(resolve,reject){
                var temp;
                wallItem.rectArea3ds.forEach(function(rectArea3dItem,i3){
                    console.log("rectArea3ds的遍历111111111111111aaaaaaaaaaaaaaaaaa");
                    if( parseInt(i3+1) === rectArea3dsLength ){
                        temp=resolve;
                    }
                    utilWallTileAmountCompute(rectArea3dItem,temp);
                });

            })

            //4.遍历圆形区域
            if(!roundArea3dsLength && wallItem.roundArea3ds.length>0){
                roundArea3dsLength=wallItem.roundArea3ds.length;
            }
            localPromise(function(resolve,reject){
                var temp;
                wallItem.roundArea3ds.forEach(function(roundArea3dItem,i4){
                    console.log("roundArea3ds的遍历111111111111111bbbbbbbbbbbbb");
                    if( parseInt(i4+1) === roundArea3dsLength ){
                        temp=resolve;
                    }
                    utilWallTileAmountCompute(roundArea3dItem,temp);
                });

            })

        })



    }).then(function(){
        console.log("进入画图2222222222222222222222");
        //1.克隆svg defs 标签的字符串，并将img url转成base64，才能显示图片
        var defsClone=null,tempHtml="";
        localPromise(function(resolve,reject){
            var outputFormat='image/jpeg';
            //#paper2dsvg 最初版本的 svg对象，换成#tempParentSvg 在floor.js里面【utilFloorTileAmountCompute】生成 -2017-11-21
            defsClone=$("#tempParentSvg").find("defs").clone();
            var imgLength=defsClone.find("image").length;
            // var flag=1;
            defsClone.find("image").each(function (i, v) {
                //指定图片尺寸
                var url=v.href.baseVal+"@600w_600h_50Q.jpg";
                convertImgToBase64(url, function(base64Img,resolve,obj){
                    v.href.baseVal=base64Img;

                    if((i+1)==imgLength){
                        setTimeout(function(){
                            resolve();
                            //api.removeTempParentSvg();//延迟删除已添加的 tempParentSvg，debug时可以隐藏这个代码
                        },500)
                    }
                },outputFormat,resolve,i)
            })
            //defsClone.children("clipPath").remove();
            //2.获取处理完后的 svg defs字符串 画图

        }).then(function(html){
            if(room.length>0 && room[0].model.type=="FLOOR"){
                // noinspection JSAnnotator
                window.imgCompleteStatus={};
                $("#itemDetailsTbl tbody").empty();
                //缓存要插入图片的td选择器，运行时执行->实时更新
                var seletorObj=function(){ return $("#itemDetailsTbl tbody").find(".content").last().find(".wrap_img") }
                localPromise(function(resolve,reject){
                    //1.floor
                    [models.rooms[0].floor].some(function (val, i) {
                        //drawItemsListImg(val,defsClone,seletorObj,resolve);
                        drawItemsListImgToPage(val,defsClone,models,seletorObj,resolve);
                    })
                }).then(function(index){
                    //2.floorareas 判断区域的数量大于0时执行promise，否则直接传递到下一个promise
                    models.rooms[0].floorareas.length >0 && models.rooms[0].floorareas.some(function (val, i) {
                        localPromise(function(resolve,reject){
                            //drawItemsListImg(val,defsClone,seletorObj,resolve);
                            drawItemsListImgToPage(val,defsClone,models,seletorObj,resolve);
                        })
                    })
                }).then(function(){
                    //3.boundarys
                    models.rooms[0].boundarys.some(function (val, i) {
                        localPromise(function(resolve,reject){
                            // drawItemsListImg(val,defsClone,seletorObj,resolve);
                            drawItemsListImgToPage(val,defsClone,models,seletorObj,resolve);
                        })
                    })
                }).then(function(){
                    //4.墙砖


                    models.rooms[0].walls.forEach(function (wallItem, i1) {
                        wallItem.boards.some(function (val, i) {
                            localPromise(function(resolve,reject){
                                // drawItemsListImg(val,defsClone,seletorObj,resolve);
                                drawWallItemsListImgToPage(val,defsClone,models,seletorObj,resolve);
                            })
                        })
                    });

                }).then(function(){
                    defsClone=null;
                });
            }
        })
    });
}
//生成html字符串插入dom，画出商品清单不同规格的砖再插入到页面dom
// v:计算好砖的对象，svgDefsClone：svg defs标签的html字符，selector 输出图片的选择器，num：容器的索引，resolve：promise完成对象
// 根据 model.perimeterCount[x] 的 index 反选对应规格的 floorRectTiles 瓷砖数据，floorRectTiles[x]的sideLength 如果有0数据，就不要输出清单
function drawItemsListImg(v,svgDefsClone,selector,resolve) {
    var model=v,mid=model.materialid || model.id;
    var perimeterCount=v.perimeterCount,floorRectTiles=v.floorRectTiles,clipedTiles=v.clipedTiles;
    var svgstr=v.svgstr,fillUrl=svgstr.fillUrl,paths=svgstr.paths,clippaths=svgstr.clippaths;
    var boundarysMatId=v.baseMaterial && v.baseMaterial.id;

    var tile="",tempHtml="",tdSet="";
    var $tableContent=$("#itemDetailsTbl tbody").find(".content");
    perimeterCount && perimeterCount.some(function(v,i){
        var moveToX=clippaths[v.index][0][1]*1-500,moveToY=clippaths[v.index][0][2]*1-500;
        var minValue=Math.min.apply( null,clipedTiles[v.index].sideLength )>0.0001 ;
        if( !v.notCount && minValue ){
            //var viewBoxVal="0,-500,1920,1080";
            var viewBoxVal=moveToX+","+moveToY+",1000,600";
            //大于0.8的砖，暂时是2.4，使用下面这个viewbox
            if(clipedTiles[0].paveH * clipedTiles[0].paveW >= 2.4*2.4){
                //viewBoxVal="0,-500,1600,1600";
                viewBoxVal=moveToX+","+moveToY+",1400,1000";
            }
            //TODO 如发现还看不到，需要遍历clippaths[v.index] 的数值，调整路径的数值；-2017-11-10
            //创建svg字符串，创建表格列表并插入到页面,如果前台不显示图片需要调整viewbox
            tile = Snap("1920","958").attr({
                //填充index方便定位是那个tiles的路径debug
                index:v.index,
                class:"tempSvg",
                viewBox:viewBoxVal

                }).path(clippaths[v.index]).attr({
                    fill: fillUrl
            });


            tile.paper.defs.innerHTML=svgDefsClone[0].innerHTML;

            tdSet='<td>'+mid+'</td><td class="wrap_img">'+""+'</td><td>'+getItemsData(clipedTiles,v).join("X")+'</td><td>'+v.count+'</td>'
            tempHtml='<tr class="content">'+tdSet+'</tr>';;
            $("#itemDetailsTbl tbody").append(tempHtml);
            var selectorExcute=selector();
            svgtocanvas( tile.paper.node.outerHTML, selectorExcute, (i+1)==perimeterCount.length,resolve,i);
            //画图后删除多余的svg,debug时注释
            $(".tempSvg").remove();

        }
        if( (i+1) ==perimeterCount.length){
            //resolve();
            if(model.cornerMaterial && model.cornerMaterial.clipedTiles.length>0){
                //角砖
                genboundarys2(model,"corner",genboundarysCb11);
                //角砖的左右辅助砖
                model.leftMaterial && genboundarys2(model,"left",genboundarysCb11);
                model.rightMaterial && genboundarys2(model,"right",genboundarysCb11);
            }


        }
    });
}

function drawItemsListImgToPage(v,svgDefsClone,parentObj,selector,resolve) {
    var model=v,mid=model.materialid || model.id,measurementCount=v.measurementCount,clipedTiles=v.clipedTiles, pid=v.pid || v.baseMaterial.pid;
    var tempObj={};
    parentObj.materials.some(function(v1,i1){
        if(pid==v1.pid){
            return tempObj={
                model:v1.model==null?"暂无":v1.model,
                pid:v1.pid,
                sque:v1.sque,
                title:v1.title,
                xlen:v1.xlen,
                ylen:v1.ylen,
                zlen:v1.zlen
            }
        }
    })

    var svgstr=v.svgstr,fillUrl=svgstr.fillUrl,paths=svgstr.paths,clippaths=svgstr.clippaths;
    // var boundarysMatId=v.baseMaterial && v.baseMaterial.id;

    var tile="",tempHtml="",tdSet="";

    var total=0;
    // var tempOtherMeasurement=0;
    //单块整砖的面积
    var prdMeasurement=tempObj.xlen * tempObj.ylen;

    //TODO 面积计算步骤需要 toFixed(3),四舍五入 -2017-12-19
    measurementCount && measurementCount.some(function(v2,i2){

        var moveToX=clippaths[v2.index][0][1]*1-500,moveToY=clippaths[v2.index][0][2]*1-500;

        //面积大于0.001才画图
        if(  v2.value>=0.001 ){
            //var viewBoxVal="0,-500,1920,1080";
            var viewBoxVal=moveToX+","+moveToY+",1000,600";
            //大于0.8的砖，暂时是2.4，使用下面这个viewbox
            if(clipedTiles[0].paveH * clipedTiles[0].paveW >= 2.4*2.4){
                //viewBoxVal="0,-500,1600,1600";
                viewBoxVal=moveToX+","+moveToY+",1400,1000";
            }
            //TODO 如发现还看不到，需要遍历clippaths[v.index] 的数值，调整路径的数值；-2017-11-10
            //创建svg字符串，创建表格列表并插入到页面,如果前台不显示图片需要调整viewbox
            tile = Snap("1920","958").attr({
                //填充index方便定位是那个tiles的路径debug
                index:v2.index,
                class:"tempSvg",
                viewBox:viewBoxVal

            }).path(clippaths[v2.index]).attr({
                fill: fillUrl
            });


            tile.paper.defs.innerHTML=svgDefsClone[0].innerHTML;
            total=v2.count;

            //暂时屏蔽区域的计算--TODO 1.5上线时，不需要就删除-2017-12-12
            if( $.inArray(model.type,["RECTAREA","FREEAREA","ROUNDAREA"])>=0 && 0 ){
                //统计整砖面积的块数，或者切砖的面积大于整砖面积的一半时，当成一块砖
                if( v2.value==prdMeasurement || v2.value> prdMeasurement / 2 ){
                    total+=v2.count;
                }
                //少于 1/4 砖的 都算 1/4,TODO 汇总时看情况，再向上取整 -2017-12-8
                else if( v2.value < prdMeasurement / 4 ){
                    total=total + v2.count*0.25;
                }
                else{
                    //单块砖的面积乘数量--小于1半，大于1/4的砖当半块；
                    total=total + v2.count*0.5;
                }
                //自定义区域数量 +5%
                if( $.inArray(model.type,["FREEAREA"])>=0 ){
                    total=total*1.05;
                }
                total=Math.ceil( total );
            }
            //暂时屏蔽波打线计算--TODO 1.5上线时，不需要就删除-2017-12-12
            var imgWH="width:100px;";
            if( model.type=="BOUNDARY" && 0 ){
                //波打线 的base id == 切砖的 id，过滤出来边线，其余就是顶角
                var boundarysMatId=model.baseMaterial && model.baseMaterial.id;
                var boundaryTileCount=0;
                model.clipedTiles.some(function(boundaryTile){
                    if( boundarysMatId == boundaryTile.bounaryMaterialId ){
                        boundaryTileCount+=1;
                    }
                })

                total=boundaryTileCount;
            }

            //返回边长规格数组，getGuigeArr(guigeArr,0.001)删除小于0.001的数组数值；
            var guigeArr=getItemsData(clipedTiles,v2);
            console.log(guigeArr)
            console.log(getGuigeArr(guigeArr,0.001).join("X"))
            tdSet='<td>'+mid+'</td><td class="wrap_img">'+""+'</td><td>'+getGuigeArr(guigeArr,0.001).join("X")+'</td><td>'+total+'</td>'
            tempHtml='<tr class="content">'+tdSet+'</tr>';
            $("#itemDetailsTbl tbody").append(tempHtml);
            var selectorExcute=selector();
            svgtocanvas( tile.paper.node.outerHTML, selectorExcute, (i2+1) ==measurementCount.length,resolve,i2);
            //画图后删除多余的svg
            $(".tempSvg").remove();
        }

        //最后一个遍历结束时，拿到数量输出到页面
        if( (i2+1) ==measurementCount.length){
            //resolve();
            if(model.cornerMaterial && model.cornerMaterial.clipedTiles.length>0){
                //角砖
                genboundarys2(model,"corner",genboundarysCb11);
                //角砖的左右辅助砖 model.leftMaterial.clipedTiles.length>0
                model.leftMaterial && model.leftMaterial.clipedTiles.length>0 && genboundarys2(model,"left",genboundarysCb11);
                model.rightMaterial && model.leftMaterial.clipedTiles.length>0 && genboundarys2(model,"right",genboundarysCb11);
            }


        }
    });
}

//画墙砖 TODO  拆分墙砖出来，先做好后面再跟上一个方法合并优化 oxl 2018-02-26
//TODO 暂时屏蔽 oxl 2018-02-27
function drawWallItemsListImgToPage(v,svgDefsClone,parentObj,selector,resolve) {
    var model=v,mid=model.areaMaterial.id,measurementCount=model.measurementCount,clipedTiles=model.floorRectTiles, pid=model.areaMaterial.pid;
    var tempObj=model.areaMaterial.meta;
    // parentObj.materials.some(function(v1,i1){
    //     if(pid==v1.pid){
    //         return tempObj={
    //             model:v1.model==null?"暂无":v1.model,
    //             pid:v1.pid,
    //             sque:v1.sque,
    //             title:v1.title,
    //             xlen:v1.xlen,
    //             ylen:v1.ylen,
    //             zlen:v1.zlen
    //         }
    //     }
    // })

    var svgstr=model.svgstr,fillUrl=svgstr.fillUrl,paths=svgstr.paths,clippaths=svgstr.clippaths;

    var tile="",tempHtml="",tdSet="";

    var total=0;
    // var tempOtherMeasurement=0;
    //单块整砖的面积
    var prdMeasurement=tempObj.xlen * tempObj.ylen;

    //TODO 面积计算步骤需要 toFixed(3),四舍五入 -2017-12-19
    measurementCount && measurementCount.some(function(v2,i2){

        var moveToX=clippaths[v2.index][0][1]*1-500,moveToY=clippaths[v2.index][0][2]*1-500;

        //面积大于0.001才画图
        if(  v2.value>=0.001 ){
            //var viewBoxVal="0,-500,1920,1080";
            var viewBoxVal=moveToX+","+moveToY+",1000,600";
            //大于0.8的砖，暂时是2.4，使用下面这个viewbox
            if(clipedTiles[0].paveH * clipedTiles[0].paveW >= 2.4*2.4){
                //viewBoxVal="0,-500,1600,1600";
                viewBoxVal=moveToX+","+moveToY+",1400,1000";
            }
            //TODO 如发现还看不到，需要遍历clippaths[v.index] 的数值，调整路径的数值；-2017-11-10
            //创建svg字符串，创建表格列表并插入到页面,如果前台不显示图片需要调整viewbox
            tile = Snap("1920","958").attr({
                //填充index方便定位是那个tiles的路径debug
                index:v2.index,
                class:"tempSvg",
                viewBox:viewBoxVal

            }).path(clippaths[v2.index]).attr({
                fill: fillUrl
            });


            tile.paper.defs.innerHTML=svgDefsClone[0].innerHTML;
            total=v2.count;

            var imgWH="width:100px;";


            //返回边长规格数组，getGuigeArr(guigeArr,0.001)删除小于0.001的数组数值；
            var guigeArr=getItemsData(clipedTiles,v2);
            console.log(guigeArr)
            console.log(getGuigeArr(guigeArr,0.001).join("X"))
            tdSet='<td>'+mid+'</td><td class="wrap_img">'+""+'</td><td>'+getGuigeArr(guigeArr,0.001).join("X")+'</td><td>'+total+'</td>'
            tempHtml='<tr class="content">'+tdSet+'</tr>';
            $("#itemDetailsTbl tbody").append(tempHtml);
            var selectorExcute=selector();
            svgtocanvas( tile.paper.node.outerHTML, selectorExcute, (i2+1) ==measurementCount.length,resolve,i2);
            //画图后删除多余的svg
            $(".tempSvg").remove();
        }

        //最后一个遍历结束时，拿到数量输出到页面
        if( (i2+1) ==measurementCount.length){
            //resolve();
            if(model.cornerMaterial && model.cornerMaterial.clipedTiles.length>0){
                //角砖
                genboundarys2(model,"corner",genboundarysCb11);
                //角砖的左右辅助砖 model.leftMaterial.clipedTiles.length>0
                model.leftMaterial && model.leftMaterial.clipedTiles.length>0 && genboundarys2(model,"left",genboundarysCb11);
                model.rightMaterial && model.leftMaterial.clipedTiles.length>0 && genboundarys2(model,"right",genboundarysCb11);
            }


        }
    });
}





//过滤不符合要求的数据,并处理小数位数
function getGuigeArr(arr,num){
    for(var i=0;i<arr;i++){
        if(arr[i]<num){
            delete arr[i]
        }
    }
    var newArr=[];
    for(var index in arr){
        if(arr[index]>0)
        newArr.push( arr[index] )
    }

    return newArr
}


function getItemsData(floorRectTiles,perimeterCountItem){
    //获取规格->各条边的长度
    return floorRectTiles[perimeterCountItem.index].sideLength

}
//svg 转canvas 删除空白透明像素-defs里面的image需要转成base64
var imgFactor=0;
function svgtocanvas(svgString,obj,flag,resolve,index){
    //svg 转 img
    var svgString = svgString//new XMLSerializer().serializeToString(document.querySelector('#test2'));
    var canvas = document.createElement("canvas");
    var ctx = canvas.getContext("2d");
    var DOMURL = self.URL || self.webkitURL || self;
    var img = new Image();
    var imgInner = new Image();
    var svg = new Blob([svgString], { type: "image/svg+xml" });
    var url = DOMURL.createObjectURL(svg);
    canvas.width=1920,canvas.height=1080;
    var temp=imgFactor+index;
    // img.src = url;
    $("<img/>").attr({src:url,id:"svgtocanvas",class:"svgtocanvas"+temp}).appendTo("body");
    var img=$(".svgtocanvas"+temp)[0];
    $(".svgtocanvas"+temp)[0].onload = function () {
    // img.onload = function () {
        imgCompleteStatus[temp]=setInterval(function(){
            if($(".svgtocanvas"+temp)[0].complete){
                ctx.drawImage($(".svgtocanvas"+temp)[0], 0, 0);
                //var png = canvas.toDataURL("image/png");
                var imgData = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
                var lOffset = canvas.width, rOffset = 0,tOffset = canvas.height, bOffset = 0;
                for (var i = 0; i < canvas.width; i++) {
                    for (var j = 0; j < canvas.height; j++) {
                        var pos = (i + canvas.width * j) * 4
                        if (imgData[pos] == 255 || imgData[pos + 1]  == 255 || imgData[pos + 2]  == 255 || imgData[pos + 3] == 255) {
                            bOffset = Math.max(j, bOffset); // 找到有色彩的最下端
                            rOffset = Math.max(i, rOffset); // 找到有色彩的最右端
                            tOffset = Math.min(j, tOffset); // 找到有色彩的最上端
                            lOffset = Math.min(i, lOffset); // 找到有色彩的最左端
                        }
                    }
                }
                lOffset++;
                rOffset++;
                tOffset++;
                bOffset++;
                var c = document.createElement("canvas");
                c.width = rOffset-lOffset;
                c.height = bOffset-tOffset;
                if( rOffset+bOffset<3){
                    //导出图像有问题时输出这个objurl debug用 2017-11-17
                    // console.log(rOffset,bOffset)
                    // console.log(url)
                }
                c.className="new_img";
                var ctx_output = c.getContext("2d");
                ctx_output.drawImage($(".svgtocanvas"+temp)[0], lOffset, tOffset, c.width, c.height, 0, 0, c.width, c.height);
                obj?obj.append(c):document.body.appendChild(c);
                clearInterval(imgCompleteStatus[temp]);
                //imgCompleteStatus[index+fuck]=null;
                $(".svgtocanvas"+temp)[0].remove();
                if(flag==true){
                    imgCompleteStatus[temp]=null;
                    resolve()
                }
            }
        },50);
    };


    imgFactor=imgFactor+10;
}
//图片url转base64
var img2Base64CompleteStatus={};
var img2Base64Factor=0;
function convertImgToBase64(url, callback, outputFormat,resolve,imgindex){
    var canvas = document.createElement('CANVAS');
    var ctx = canvas.getContext('2d');
    // var img = new Image;
    // img.crossOrigin = 'Anonymous';

    //0.canvas异步加载图片需要用 complete 事件判断-2017-12-07
    // img.src = url;
    //setInterval的索引
    var temp=imgindex+img2Base64Factor;
    $("<img/>").attr({src:url,id:"convertImgToBase64",class:"convertImgToBase64"+temp,crossOrigin:"Anonymous"}).appendTo("body");
    var img=$(".convertImgToBase64"+temp)[0];
    img.onload = function(){
    //1.检查图片是否加载完
        img2Base64CompleteStatus[temp]=setInterval(function(){
            if(img.complete){
                canvas.height = img.height;
                canvas.width = img.width;
                ctx.drawImage(img,0,0);
                var dataURL = canvas.toDataURL(outputFormat || 'image/png');
                //2.执行回调时clean 掉 setInterval
                callback.call(this, dataURL,resolve);
                img.remove();
                canvas = null;
                clearInterval(img2Base64CompleteStatus[temp]);
            }
        },50)
    };


    //3.setInterval的索引，确保索引不重复
    img2Base64Factor=img2Base64Factor+10;

}
//======================第一版======================


//==========================================第二版======================================
//以下版本是算面积并绑定相关数据输出到页面，不用画出切砖 oxl-2017-1101
function initComputeRoomTilesAmount2(prdIdArr){
    //0.选择房间，
    var room=api.pickGetPicked();
    //缓存本次选取的结果model集合对象；
    var models=api.getBomOneData( room[0].model.id );



    //0.1对应房间的 floor 区域计算一次 砖
    // utilFloorplanForEachItem(application.doc.floorplan, function (floor) {
    //     utilFloorTileAmountCompute(floor);
    // },room[0].model.id );

    //0.执行算砖任务
    //0.1地板
    utilFloorTileAmountCompute(models.rooms[0].floor);
    //0.2区域
    models.rooms[0].floorareas.forEach(function (val, i) {
        utilFloorTileAmountCompute(val);
    })
    //0.3波打线
    models.rooms[0].boundarys.forEach(function (val, i) {
        utilFloorTileAmountCompute(val);
    });

    //0.4墙砖 遍历墙体-算砖
    utilGetWallsDetails(models,utilWallTileAmountCompute);


    //1.克隆svg defs 标签的字符串，并将img url转成base64，才能显示图片
    var defsClone,tempHtml="";
    if(room.length>0 && room[0].model.type=="FLOOR"){
        $("#orderListTbl tbody").empty();
        //缓存要插入图片的td选择器，运行时执行->实时更新
        localPromise(function(resolve,reject){
            //1.floor
            [models.rooms[0].floor].forEach(function (val, i) {
                setTileDetailsToPage2(val,models,resolve)
            })
        }).then(function(index){
            //2.floorareas TODO svg def defined img can public use?
            models.rooms[0].floorareas.forEach(function (val, i) {
                localPromise(function(resolve,reject){
                    setTileDetailsToPage2(val,models,resolve)
                })
            })
        }).then(function(){
            //3.boundarys
            models.rooms[0].boundarys.forEach(function (val, i) { //val 波打线实例
                localPromise(function(resolve,reject){
                    setTileDetailsToPage2(val,models,resolve)
                })
            })
        }).then(function(){
            //4.walls-遍历墙体-画图
            utilGetWallsDetails(models,setWallTileDetailsToPage)

        });
    }
}

//填充砖的信息到页面---v：某块区域实例；parentObj：整个当前空间 oxl1101
function setTileDetailsToPage2(v,parentObj,resolve) {
    var model=v,measurementCount=v.measurementCount,floorRectTiles=v.floorRectTiles,clipedTiles=v.clipedTiles,
        pid=v.pid || v.baseMaterial.pid;
        //materialid=v.materialid || v.baseMaterial.id;//波打线的结构不一样，这样取id
    var tile="",tempHtml="",tdSet="";
    var tempObj={};
    parentObj.materials.some(function(v1,i1){
        if(pid==v1.pid){
            return tempObj={
                            model:v1.model==null?"暂无":v1.model,
                            pid:v1.pid,
                            sque:v1.sque,
                            title:v1.title,
                            xlen:v1.xlen,
                            ylen:v1.ylen,
                            zlen:v1.zlen
                   }
        }
    })


    var total=0;
    var tempOtherMeasurement=0;
    //单块整砖的面积
    var prdMeasurement=tempObj.xlen * tempObj.ylen;
    measurementCount && measurementCount.some(function(v2,i2){

        //统计整砖面积的块数，或者切砖的面积大于整砖面积的一半时，当成一块砖
        if( v2.value==prdMeasurement || v2.value>= prdMeasurement / 2 ){
            total+=v2.count;
        }
        //少于 1/4 砖的 都算 1/4,最小值要大于 0.01，再小就无意义
        else if( v2.value <= prdMeasurement / 4 && v2.value>=0.01){
            total=total + v2.count*0.25;
        }
        else{
            // tempOtherMeasurement=tempOtherMeasurement + v2.value * v2.count ;
            //单块砖的面积乘数量--小于1半，大于1/4的砖当半块；
            total=total + v2.count*0.5;
        }


        //最后一个遍历结束时，拿到数量输出到页面
        if( (i2+1) ==measurementCount.length){

            //自定义区域数量 +5%
            if( $.inArray(model.type,["FREEAREA"])>=0 ){
                total=total*1.05;
            }

            //地板砖，区域，需要向上取整；
            //向上取整-2017-12-08
            total=Math.ceil( total );


            //0.调整按比例波打线的显示效果，波打线直接按数量来统计(顶角在下面再另外处理)
            var imgWH="width:100px;";
            if( model.type=="BOUNDARY"  ){
                imgWH="height:"+(tempObj.ylen*1000)/6+"px;"+"width:"+(tempObj.xlen*1000)/6+"px";
                //波打线 的base id == 切砖的 id，过滤出来边线，其余就是顶角
                var boundarysMatId=model.baseMaterial && model.baseMaterial.id;
                var boundaryTileCount=0;
                model.clipedTiles.some(function(boundaryTile,i){
                    if( boundarysMatId == boundaryTile.bounaryMaterialId ){
                        boundaryTileCount+=1;
                    }
                })

                total=boundaryTileCount;
            }

            tdSet='<td>'+"客厅"+'</td><td class="wrap_img"><img style='+imgWH+' src="'+productUrl(tempObj.pid)+'"/>'+'</td><td>'+tempObj.title+"/"+tempObj.model+'</td><td>'+tempObj.sque+'</td><td id="'+pid+'_total">'+total+'</td><td>'+"测试方式"+'</td>'
            tempHtml='<tr class="content" id="'+pid+'">'+tdSet+'</tr>';
            //id唯一，页面存在一个id记录时,后续出现相同id的数量，都添加到这个唯一id的 数量里面
            if($("#"+pid).length){
                var tempTotal= $("#"+pid+"_total").text()*1+total;
                $("#"+pid+"_total").text(tempTotal);
            }else{
                $("#orderListTbl tbody").append(tempHtml);
            }

            //TODO 如果需求改变需要将砖归类到大砖一起统计 2017-11-07
            //TODO 波打线顶角需要 统计整砖面积的块数，或者切砖的面积大于整砖面积的一半时，当成一块砖
            //1.1 插入波打线顶角:波打线4个角做了特别处理，分别统计4个角的数量，即使使用了地板的大砖也是分开计算
            //1.2 波打线第二种形式是没有顶角，加个判断，
            //1.3 添加了 left right 波打线的计算
            if(v.cornerMaterial && v.cornerMaterial.clipedTiles.length>0){

                //角砖
                genboundarys2(model,"corner",genboundarysCb22);
                //角砖的左右辅助砖
                model.leftMaterial && genboundarys2(model,"left",genboundarysCb22);
                model.rightMaterial && genboundarys2(model,"right",genboundarysCb22);

            }
            resolve();
        }

    });

}


function setWallTileDetailsToPage(v,parentObj,resolve) {
    var tile="",tempHtml="",tdSet="";
    var model=v,mid=model.areaMaterial.id,measurementCount=model.measurementCount,clipedTiles=model.floorRectTiles, pid=model.areaMaterial.pid;
    var tempObj=model.areaMaterial.meta;
    var svgstr=model.svgstr,fillUrl=svgstr.fillUrl,paths=svgstr.paths,clippaths=svgstr.clippaths;

    var total=0;
    var tempOtherMeasurement=0;
    //单块整砖的面积
    var prdMeasurement=tempObj.xlen * tempObj.ylen;

    measurementCount && measurementCount.some(function(v2,i2){
        //不过滤直接统计
        total+=v2.count;
        //最后一个遍历结束时，拿到数量输出到页面
        if( (i2+1) ==measurementCount.length){
            //直接加上损耗
            //向上取整-2017-12-08
            total=Math.ceil( total );
            //0.调整按比例波打线的显示效果，波打线直接按数量来统计(顶角在下面再另外处理)
            var imgWH="width:100px;";

            tdSet='<td>'+"墙面"+'</td><td class="wrap_img"><img style='+imgWH+' src="'+productUrl(tempObj.pid)+'"/>'+'</td><td>'+tempObj.title+"/"+tempObj.model+'</td><td>'+(tempObj.xlen*1000)+"X"+(tempObj.ylen*1000)+'</td><td id="wall_'+pid+'_total">'+total+'</td><td>'+"测试方式"+'</td>'
            tempHtml='<tr class="content" id="wall_'+pid+'">'+tdSet+'</tr>';
            //id唯一，页面存在一个id记录时,后续出现相同id的数量，都添加到这个唯一id的 数量里面
            if($("#"+"wall_"+pid+"_total").length){
                var tempTotal= $("#"+"wall_"+pid+"_total").text()*1+total;
                $("#"+"wall_"+pid+"_total").text(tempTotal);
            }else{
                $("#orderListTbl tbody").append(tempHtml);
            }

            resolve && resolve();
        }

    });

}

//遍历墙砖的数据-oxl 2018-02-28
function utilGetWallsDetails(models,callback){
    //var wallsLength=models.rooms[0].walls.length;
    var boardsLength=0,rectArea3dsLength=0,roundArea3dsLength=0;

    //1.遍历各面墙
    models.rooms[0].walls.forEach(function (wallItem, i1) {
        //墙砖board（等同于地板砖，区域不算）的记录数
        //2.遍历board
        if(!boardsLength && wallItem.boards.length>0){
            boardsLength=wallItem.boards.length;
        }

        //3.遍历矩形区域
        if(!rectArea3dsLength && wallItem.rectArea3ds.length>0){
            rectArea3dsLength=wallItem.rectArea3ds.length;
        }

        //4.遍历圆形区域
        if(!roundArea3dsLength && wallItem.roundArea3ds.length>0){
            roundArea3dsLength=wallItem.roundArea3ds.length;
        }

        localPromise(function(resolve,reject){
            var temp;
            wallItem.boards.forEach(function(boardItem,i2){
                if( parseInt(i2+1) === boardsLength ){
                    temp=resolve;
                }
                callback && callback.call(this,boardItem,temp);
            });
        });


        localPromise(function(resolve,reject){
            var temp;
            wallItem.rectArea3ds.forEach(function(rectArea3dItem,i3){
                if( parseInt(i3+1) === rectArea3dsLength ){
                    temp=resolve;
                }
                callback && callback.call(this,rectArea3dItem,temp);
            });

        });


        localPromise(function(resolve,reject){
            var temp;
            wallItem.roundArea3ds.forEach(function(roundArea3dItem,i4){
                if( parseInt(i4+1) === roundArea3dsLength ){
                    temp=resolve;
                }
                callback && callback.call(this,roundArea3dItem,temp);
            });

        })

    })
}

//===============================第二版=======================================

//波打线算砖清单插入dom callback1
function genboundarysCb11(model,side,obj){
    var meta=obj.meta,
        sideStr=obj.sideStr,
        boundaryRectH=obj.boundaryRectH,
        boundaryRectW=obj.boundaryRectW,
        boundaryWH=obj.boundaryWH,
        metaWH=obj.metaWH,
        sideMaterial=obj.sideMaterial,
        boundaryTotal=obj.boundaryTotal;
    var imgWH="width:50px;height:50px";
    if(side=="left" || side=="right"){
        imgWH="height:"+(meta.ylen*1000)/5+"px";
    }

    var boundaryTdSet="",boundaryTempHtml="";
    var boundarySque=boundaryRectH * boundaryRectW < meta.xlen* meta.ylen ? boundaryWH+'<br/>'+'/'+metaWH : metaWH;
    boundaryTdSet='<td>'+"波打线"+sideStr+"顶角"+'<br/>'+model[sideMaterial].id+'</td><td class="wrap_img"><img style='+imgWH+' src="'+productUrl(meta.pid)+'"/>'+'</td><td>'+meta.title+"/"+meta.model+'<br/>'+boundarySque+'</td><td id="item_'+side+'_'+meta.pid+'_total">'+boundaryTotal+'</td>';

    boundaryTempHtml='<tr class="content" id="item_'+side+'_'+meta.pid+'" >'+boundaryTdSet+'</tr>';
    //2.id唯一，页面存在一个id记录时,后续出现相同id的数量，都添加到这个唯一id的 数量里面，这里做了产品分类，地砖，波打线分开统计，
    //3.如果不按空间分类，按砖分类，需要将id 【"#item_"+side+"+meta.pid】前缀删去，并计算相应的面积

    if($("#item_"+side+"_"+meta.pid).length){
        var tempboundaryTotal= $("#item_"+side+"_"+meta.pid+"_total").text()*1+boundaryTotal;
        $("#item_"+side+"_"+meta.pid+"_total").text(tempboundaryTotal);
    }else{
        $("#itemDetailsTbl tbody").append(boundaryTempHtml);
    }
}
//波打线算砖插入dom callback2
function genboundarysCb22(model,side,obj){
    var meta=obj.meta,
        sideStr=obj.sideStr,
        boundaryRectH=obj.boundaryRectH,
        boundaryRectW=obj.boundaryRectW,
        boundaryWH=obj.boundaryWH,
        metaWH=obj.metaWH,
        sideMaterial=obj.sideMaterial,
        boundaryTotal=obj.boundaryTotal;

    var imgWH="width:50px;height:50px";
    if(side=="left" || side=="right"){
        imgWH="height:"+(meta.ylen*1000)/6+"px;"+"width:"+(meta.xlen*1000)/6+"px";
    }

    var boundaryTdSet="",boundaryTempHtml="";

    var boundarySque=boundaryRectH * boundaryRectW < meta.xlen* meta.ylen ? boundaryWH+'<br/>'+'/'+metaWH : metaWH;
    boundaryTdSet='<td>'+"波打线"+sideStr+"顶角"+'</td><td class="wrap_img"><img style='+imgWH+' src="'+productUrl(meta.pid)+'"/>'+'</td><td>'+meta.title+"/"+meta.model+'</td><td>'+boundarySque+'</td><td id="fullitem_'+side+'_'+meta.pid+'_total">'+boundaryTotal+'</td><td>'+"测试方式"+'</td>';
    boundaryTempHtml='<tr class="content" id="fullitem_'+side+'_'+meta.pid+'" >'+boundaryTdSet+'</tr>';
    //2.id唯一，页面存在一个id记录时,后续出现相同id的数量，都添加到这个唯一id的 数量里面，这里做了产品分类，地砖，波打线分开统计，
    //3.如果不按空间分类，按砖分类，需要将id 【"#fullitem_"+side+"_"+meta.pid】前缀删去，并计算相应的面积
    if($("#fullitem_"+side+"_"+meta.pid).length){
        var tempboundaryTotal= $("#fullitem_"+side+"_"+meta.pid+"_total").text()*1+boundaryTotal;
        $("#fullitem_"+side+"_"+meta.pid+"_total").text(tempboundaryTotal);
    }else{
        $("#orderListTbl tbody").append(boundaryTempHtml);
    }

}

//波打线算砖，波打线算砖清单插入dom：公用计算相关数值
function genboundarys2(model,side,callback){
    var sideMaterial = side + "Material";
    //第一块角砖
    var boundaryTile0=model[sideMaterial].clipedTiles[0];
    var meta=model[sideMaterial].meta;
    //裁减后的实际尺寸 boundaryRectH ，原砖尺寸 boundaryOrginH
    var boundaryRectH=boundaryTile0.rectH,boundaryRectW=boundaryTile0.rectW,
        boundaryOrginH=boundaryTile0.paveH,boundaryOrginW=boundaryTile0.paveW;

    var boundaryTileNotCount=0;
    var boundaryTileLength=model[sideMaterial].clipedTiles.length;
    model[sideMaterial].clipedTiles.some(function(boundaryTile,boundaryTileIndex){
        if(boundaryTile.measurement==0){
            boundaryTileNotCount+=1;
        }
    })
    //实际角的数量
    var boundaryTileCount=boundaryTileLength-boundaryTileNotCount;
    //实际用砖面积
    var boundaryTempOtherMeasurement=(boundaryRectH * boundaryRectW) * boundaryTileCount ,
        //实际用砖面积/原砖尺寸=数量
        boundaryTotal=Math.ceil( boundaryTempOtherMeasurement / (boundaryRectH * boundaryRectW) );// boundaryOrginH * boundaryOrginW,大砖尺寸
    //用砖规格 metaWH 原砖尺寸,裁减后尺寸 boundaryWH
    var metaWH=meta.xlen*1000+" X "+meta.ylen*1000, boundaryWH=boundaryRectH*1000+" X "+boundaryRectW*1000;
    var sideStr=(side=="left") ? "左辅助" : (side=="right") ? "右辅助": "";

    var obj={ sideStr:sideStr,sideMaterial:sideMaterial,boundaryRectH:boundaryRectH,boundaryWH:boundaryWH,boundaryRectW:boundaryRectW,meta:meta,metaWH:metaWH,boundaryTotal:boundaryTotal }
    return callback && callback(model,side,obj);
}

var productUrl=function(id){
    //api.catalogGetFileUrl
    return "http://pic.oceano.com.cn/h5filesystem/products/"+id+"/top.jpg@1000w_81Q.jpg"

}

function localPromise(fun){
    return new Promise(function (resolve, reject) {
        fun(resolve,reject);
    });
}
//==============================计算用砖==2017-11-17完成主要功能========================================================





//# sourceURL=ui\dialog/bom/bom.js