var openModelRoomPanelPrompt = function () {
    var openModelRoomDialogIndex = undefined;
    var windowHeight = $(window).height()-45;

    function listDialog() {
        openModelRoomDialogIndex = layer.open({
            type: 2,
            title: '查找自己喜欢的样板间',
            shadeClose: true,
            skin: 'layui-layer-white',
            shade: 0.2,
            maxmin: true, //开启最大化最小化按钮
            move: false,
            area: ['1225px', windowHeight + 'px'],
            content: appSettings.designjavadomain+'/wbmanager/control/FindTableDesignModel',
            success: function () {
                $(".layui-layer-title").parents(".layui-layer").draggable();
            }
        });
    }


    window.addEventListener('message', function (e) {
        var data = e.data;
        data = JSON.parse(data);
        var roomModelId = data.roomModelId;
        var action = data.action ;
        if ( action != 'applyroom' ) return ;
        var picked = api.pickGetPicked();
        /**没有选择房间为打开设计*/
        if (picked.length < 1 || picked[0].model.type != "FLOOR") {
            layer.confirm('未选中房间，应用样板间将清空当前设计！', {
                btn: ['确定', '取消'], //按钮
                shade: 0.3, //不显示遮罩
                skin: 'layui-layer-default',
                title: '提示'
            }, function (index) {
                globalModelIndex = 1;
                layer.close(index);
                api.getServiceJSONResponsePromise({
                    type: 'get',
                    url: api.getServicePrefix("design") + "/getDesignById",
                    cache: false,
                    data: {
                        designId: roomModelId
                    }
                }).then(function (designres) {
                    if (designres.length > 0) {
                        getTextDataFromAliyun("design",designres[0].did,"design.content",function(data){
                            api.documentLoad(data);
                        });
                    }
                }).catch(function (e) {
                });
            }, function () {
            });

        } else {
            clickModelRoomImg("apply", roomModelId);
        }
        layer.close(openModelRoomDialogIndex);
    }, false);


    return listDialog;
}();



