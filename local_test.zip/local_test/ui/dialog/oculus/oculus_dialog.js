var OculusLayerIndex;
function OculusVRPrompt() {
    OculusLayerIndex = layer.open({
        type: 1,
        title: '准备好了吗？',
        moveType: 1,
        moveOut: true,
        skin: 'layui-layer-default',
        fix: false,
        //closeBtn: false,
        shade: false,
        shadeClose: false,
        maxmin: false,
        area: ['400px', '250px'],
        content: $('#oculusVRDialogPanel')
    });
}

/***********************************************/
var Camera_distance = 0.08;//    interpupillary distance
var OculusFullscreenElementId = "oculus_fullscreen_view";
var main3DViewContainerId = undefined;

$(".oculus_exit_fullscreenButton").on(click, function () {
    var element = document;
    if (element.exitFullscreen) {
        element.exitFullscreen();
    } else if (element.mozCancelFullScreen) {
        element.mozCancelFullScreen();
    } else if (element.webkitCancelFullScreen) {
        element.webkitCancelFullScreen();
    } else if (element.msCancelFullscreen) {
        element.msCancelFullscreen();
    }
    //exitFullScreenCallback();

});

$(".oculusVRDialogPanelOKButton").on(click, function () {
    layer.close(OculusLayerIndex);
    $("#" + OculusFullscreenElementId).height(screen.height).width(screen.width).offset({top: 0, left: 0}).show();

    main3DViewContainerId = ($("#paper3d").find("#paper3dwebgl").length == 0 ? "paper2d" : "paper3d");

    //api.viewFit("3d", {width: screen.width, height: screen.height});
    var element = document.getElementById(OculusFullscreenElementId);
    if (element.requestFullscreen) {
        element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
    }
});

var oculus_timer_id = undefined;
var oculus_img = document.getElementById("oculus_fullscreen_view_copy_img");

function exitFullScreenCallback() {
    log("exit oculus full screen.");
    clearInterval(oculus_timer_id);

    $("#paper3dwebgl").appendTo("#" + main3DViewContainerId);
    api.viewFit("3d", {mode: "default"});
// if ($("#" + OculusFullscreenElementId).is(":hidden") == true)return;

    $("#" + OculusFullscreenElementId).hide();


    //$("#preview3d").appendTo("#render_preview");
    //api.viewSetFPS("preview3d", 2);
    //api.viewFit("preview3d");
}
function enterFullScreenCallback() {
    $("#paper3dwebgl").appendTo("#oculus_fullscreen_view_right");

    api.viewFit("3d", {
        // width: screen.width / 2, height: screen.height
        mode: "vr"
    });
    return;

    var view3d_dom = api.getViewById("3d").domElement;

    oculus_timer_id = setInterval(function () {
        log("oculus timer runs.");
        api.viewFit("3d", {
            width: screen.width / 2, height: screen.height,
            cameraOffsetX: 0.5 * Camera_distance
        });
        //oculus_img.src = "";//view3d_dom.toDataURL();
        api.viewFit("3d", {
            width: screen.width / 2, height: screen.height,
            cameraOffsetX: -0.5 * Camera_distance
        });
    }, 250);

    /*
     $("#preview3d").appendTo("#oculus_fullscreen_view_left");
     api.viewSetFPS("preview3d", 30);
     api.viewFit("preview3d", {
     width: screen.width / 2, height: screen.height,
     cameraOffsetX: 0.5 * Camera_distance
     });
     */
}
$(document).on('webkitfullscreenchange mozfullscreenchange fullscreenchange', function (e) {
    if (e.target.id != OculusFullscreenElementId)return;
    if (document.webkitFullscreenElement) {
        log('enter fullscreen mode');
        enterFullScreenCallback();
    } else {
        exitFullScreenCallback();
    }
});

//# sourceURL=ui\dialog/oculus/render.js