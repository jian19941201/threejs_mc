/*处理渲染时间间隔记录数据对象*/
var renderview_jobid_time_interval_Map = new Map();
var renderview_jobid_time_interval_Array = new Array();

var defaultMaxOption = {
    image: {
        width: 240,
        height: 180,
        quality: "draft"     // draft, low, mid, high
    },
    scene: {
        hasproduct: true,
        hascamera: true,
        hasvraysetting: true
    },
    engine: "CUDA",             // CPU , CUDA
    camera: "cameraPerson",
    hdri: "default",            // default, night, daylight
    outputtype: "image",      // image , panorama , mono , scene
    email: "sunny@mvt-inc.com",
    watermark: "none",
    lighting: "auto", // auot, manual
    light_multiplier: 1.0,
    channel: "default" // default, hd, pano
};

var renderDialogPrompt = (function () {
    var renderDialogIndex = undefined;
    var successCB = undefined;

    var editor3d_size = {width: 300, height: 200};

    function fitPreview3d() {
        //view2DActiveHandler();
        //id="paper3d"
        //id = "paper3dwebgl"
        var view3dDOMId = "paper3d", domElement = document.getElementById(view3dDOMId);
        var size = domElement.getClientRects();
        if (size.length < 1)return;
        editor3d_size.width = size[0].width, editor3d_size.height = size[0].height;
        if (domElement) {
            var size = Math.max(editor3d_size.width, editor3d_size.height);
            var expectedSize = {width: size, height: size};
            var realSize = getSize();
            if (realSize.width > realSize.height) {
                expectedSize.height = Math.round(expectedSize.width * realSize.height / realSize.width);
            } else {
                expectedSize.width = Math.round(expectedSize.height * realSize.width / realSize.height);
            }

            $("#paper3d").css(expectedSize);
            api.getViewById("3d").fit(expectedSize);
        }
    }

    function dialogExit() {
        $("#paper3d").css(editor3d_size);
        api.getViewById("3d").fit(editor3d_size);
    }

    function dialogOpen() {
        view2DActiveHandler();
        var camera_select = $("#renderPanel .camera_select").empty();
        var cameras = api.floorplanFilterEntity(function (e) {
            return e.type == "CAMERA";
        });
        for (var i = 0; i < cameras.length; ++i) {
            var camera = cameras[i];
            var cameraElement = $("<option>").attr({
                value: camera.id
            }).html(camera.name).appendTo(camera_select);
        }
        camera_select.val(api.documentGetActiveCamera().id);
        fitPreview3d();
    }

    function renderDialog(onSuccessCB) {
        successCB = onSuccessCB;
        renderDialogIndex = layer.open({
            type: 1,
            title: '渲染设置',
            skin: 'layui-layer-default',
            fix: false,
            shade: false,
            //closeBtn: false,
            shadeClose: false,
            maxmin: false,
            area: ['405px', undefined],
            content: $('#renderPanel'),
            success: dialogOpen,
            end: dialogExit
        });
    }

    function cancelclick() {
        layer.close(renderDialogIndex);
        renderDialogIndex = undefined;
    }

    $("#renderPanel .camera_select").on("change", function () {
        var selectCameraId = $(this).val();
        api.documentSetActiveCameras([selectCameraId]);
    });
    $("#renderPanel .cancel").on('click', cancelclick);

    $("#renderPanel .size_precision_select").on("change", fitPreview3d);
    $("#renderPanel .custom_size .ratioInput").on("change", fitPreview3d);
    $("#renderPanel .direction_select").on("change", fitPreview3d);
    $("#renderPanel .custom_size .ratioInput").spinner({step: 0.1, min: 0.1, max: 10}).on("spinstop", fitPreview3d);
    $("#renderPanel .lighting_select").on("change", function () {
        if ($(this).val() == "auto") {
            $("#renderPanel .global_light_settings").hide();
        } else {
            $("#renderPanel .global_light_settings").show();
        }
    });


    function getSize() {
        var size_txt = $("#renderPanel .size_precision_select").val();
        if (size_txt == "custom") {
            var width = $("#renderPanel .custom_size .widthInput").val();
            var ratio = $("#renderPanel .custom_size .ratioInput").val();
            return {width: parseInt(width), height: parseInt(width) / parseFloat(ratio)};
        }
        var size = size_txt.split("x");
        var width = parseInt(size[0]), height = parseInt(size[1]), quality = size[2];

        /*方向*/
        var direction = $("#renderPanel .direction_select").val();
        if (direction == 'direction_x') {
            return {width: width, height: height};
        }

        if (direction == 'direction_y') {
            return {width: height, height: width};
        }
    }

    function okclick() {

        var userQualitySelect = $("#renderPanel .precision_select").val();
        var quality = userQualitySelect, size = getSize();
        var imgWidth = size.width, imgHeight = size.height;

        var maxSize = isSuperUser() ? 4000 : 2000;
        var minSize = 10;
        if (imgWidth > maxSize || imgHeight > maxSize) {
            layer.alert("图像最大大小，普通用户不能超过2000像素，高级用户不能超过4000像素。", {
                closeBtn: 0,
                skin: 'layui-layer-default'
            }, function (idx) {
                layer.close(idx);
            });
            return;
        } else if (size.width < minSize || size.height < minSize) {
            layer.alert("当前渲染支持图像最小大小为10x10像素。", {
                closeBtn: 0,
                skin: 'layui-layer-default'
            }, function (idx) {
                layer.close(idx);
            });
            return;
        }
        /*渲染引擎*/
        var engine = "CUDA";//$("#renderPanel .engine_select").val();
        /*if ('AUTO' == engine) {
         if (width < 500) engine = 'CUDA';
         if (width >= 500) engine = 'CPU';
         }*/

        /*摄像机名称*/
        var cameraId = $("#renderPanel .camera_select").val();
        /*环境贴图*/
        var hdri = $("#renderPanel .hdri_select").val();

        /*布光规则*/
        var lighting = $("#renderPanel .lighting_select").val();
        var light_multiplier = (lighting == "auto" ? 1.0 : parseFloat($("#renderPanel .global_light_settings .multiplierInput").val()));

        /*是否全景图*/
        var channel = "default";
        var outputtype = $("#renderPanel .output_select").val();
        if (outputtype == "panorama") {
            imgWidth = 2000, imgHeight = 1000;            
        }
        /*正常品质还是增强品质*/
        var quality_val = $("#renderPanel_oceano .quality input[name='render_quality']:checked").val();
        var quality = "high", engine = "CUDA";
        if ($("#renderPanel .super_hd_check").is(':checked')) {
            quality = "super_high";
            engine = "CUDA2";
            channel = "hd";
            renderview_retry_interval_time = 15;
            
            if (outputtype == "panorama") {
		            imgWidth = 6000, imgHeight = 3000;		            
		        }
        }

        /*电子邮件校验*/
        var email = undefined;
        if ($("#renderPanel .email_chk").is(':checked')) {
            var _email = $("#renderPanel .email").val();
            if (isEmail(_email)) {
                email = _email;
            }
        }

        /*不显示水印*/
        var watermark = true;
        if ($("#renderPanel .watermark_chk").is(':checked')) watermark = false;

        var option = {
            image: {width: imgWidth, height: imgHeight, quality: quality},
            engine: engine,
            hdri: hdri,
            outputtype: outputtype,
            email: email,
            watermark: (watermark ? appSettings.brand : "none"),
            lighting: lighting,
            light_multiplier: light_multiplier,
            camera: cameraId,
            channel: channel
        };
        //console.log( option );
        layer.close(renderDialogIndex);
        renderDialogIndex = undefined;

        // send to callbacks...:
        var options = {};
        $.extend(true, options, defaultMaxOption, option);

        if (successCB)successCB(options);
    }

    $("#renderPanel .submit").bind('click', okclick);

    $("#renderPanel .size_precision_select").on("change", function () {
        var selectSize = $(this).val();
        //var width = parseInt(selectSize[0]);
        var textvalue = $(this).get(0).options[$(this).get(0).selectedIndex].text;
        $("#renderPanel .custom_size").hide();
        if (!isSuperUser() && textvalue.indexOf("*") > 10) {
            $(this).get(0).selectedIndex = 0;
            layer.tips('您不是高级用户。', '.size_precision_select', {
                tips: [1, '#CC3525']
            });
        } else if (selectSize == "custom") {//自定义大小
            $("#renderPanel .custom_size").show();
        }
    });

    $("#renderPanel .panorama_chk").on("change", function () {
        var checkbox = $(this);

        if (!isSuperUser() && checkbox.is(':checked')) {
            $(this).removeAttr('checked');
            layer.tips('您不是高级用户。', '.panorama_chk', {
                tips: [1, '#CC3525']
            });
        }
    });

    $("#renderPanel .watermark_chk").on("change", function () {
        return;// todo not for now!!!

        var checkbox = $(this);

        if (!isSuperUser() && checkbox.is(':checked')) {
            $(this).removeAttr('checked');
            layer.tips('您不是高级用户。', '.watermark_chk', {
                tips: [1, '#CC3525']
            });
        }
    });
    return renderDialog;
})();

var render_sendRenderRequest = function (opt, successCB) {
    var options = opt;

    var products = api.floorplanFilterEntity(function (e) {
        return e.type == "PRODUCT";
    });
    // extra:
    var camera = api.documentGetActiveCamera();
    var cameraMatrix = api.documentGetActiveCameraMatrix();

    var products_coordinates = [];

    products.forEach(function (e, i) {
        var p1 = {x: e.x - camera.x, y: e.y - camera.y, z: e.z - camera.z};
        var p2 = {x: camera.tx - camera.x, y: camera.ty - camera.y};

        var ath = wangle(p2) - wangle(p1);

        var atv = -Math.asin(p1.z / Math.sqrt(p1.x * p1.x + p1.y * p1.y)) / Math.PI * 180;

        products_coordinates.push({ath: ath, atv: atv, id: e.pid});
    });

    function wangle(p) {
        var angle1;
        if (p.x >= 0 && p.y >= 0) {
            angle1 = Math.atan(p.y / p.x) / Math.PI * 180;
        } else if (p.x <= 0 && p.y >= 0) {
            angle1 = Math.atan(p.y / p.x) / Math.PI * 180 + 180;
        } else if (p.x <= 0 && p.y <= 0) {
            angle1 = 180 + Math.atan(p.y / p.x) / Math.PI * 180;
        } else if (p.x >= 0 && p.y <= 0) {
            angle1 = Math.atan(p.y / p.x) / Math.PI * 180 + 360;
        }
        return angle1;
    }

    options.extra = {
        camera: {
            id: camera.id,
            pos: {x: camera.x, y: camera.y, z: camera.z},
            tar: {x: camera.tx, y: camera.ty},
            atv: camera.pitch,
            matrix: cameraMatrix
        },
        products: products_coordinates,
        previewpic:  $('#paper3dwebgl')[0].toDataURL(),
        roomName: GetCurrentRoomName()
    };

    // request:
    var servicePrefix = api.getServicePrefix("render");
    var url = servicePrefix + "/postRenderRequest";

    var content = api.documentSave({extralight: options.lighting == "auto"});
    var room = api.threeExport("OBJ", {keep_group: true});
    var option = JSON.stringify(options);
    var jobid = api.uuid();
    var designMeta = ui.getOpenedDesignMeta();
    var jobuserloginid = "";
    var designid = "";
    if (designMeta) {
        jobuserloginid = designMeta.userLoginId;
        designid = designMeta.designId || designId;
    }
    api.getServiceJSONResponsePromise({
        type: 'post',
        url: url,
        cache: false,
        data: {design: content, room: room, option: option, jobid: jobid, jobuserloginid: jobuserloginid, designid: designid}
    }).then(function (res) {
        if (res.error == 0) {
            var jobid = res.jobid;
            renderview_jobid_time_interval_Map.put(jobid, createInternalTime().toString());
            renderview_jobid_time_interval_Array.push(jobid);
            log('send render request to server success, jobid=' + jobid);
            if (successCB)successCB({jobid: jobid, evaluateRenderTime: res.evaluateRenderTime});
        } else {
            alert('render server returns failed!! ' + jobid);
        }
    }).catch(function (e) {
        layer.alert('send render request to server failed!! ', {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
    });
};

//自定义模型测试渲染 add by hcw
var render_sendCustomModelRenderRequest = function (opt,cam,productObj,roomObj,successCB) {
    if(!cam||!roomObj||!productObj.id)return
    var options = opt;
    var products_coordinates = [];
    options.extra = {
        camera: {
            id: "cameraPerson",
            pos: {x: cam.position.x, y: -cam.position.z, z:cam.position.y},
            tar: {x:0, y:0},
            atv: 80
        },
        products: products_coordinates,
        previewpic:  $('#model_room').find('canvas')[0].toDataURL(),
        roomName: "testRoom"
    };
    // request:
    var servicePrefix = api.getServicePrefix("render");
    var url = servicePrefix + "/postRenderRequest";
    function time(useMS) {
            var n = new Date();
            return 1 * n.getSeconds() + 100 * n.getMinutes() + 1e4 * n.getHours() + 1e4 * n.getDate() * 100 + 1e4 * (n.getMonth() + 1) * 1e4 + 1e4 * n.getFullYear() * 1e4 * 100 + (1 == useMS ? .001 * n.getMilliseconds() : 0);
    }
    var content =
        {
            created:time(),
            version:"1.0",
            design: "kJyeIpNXZci42Zb7tlOWklmIaiojIOBRWaZ5UDMN1IDMM3UTNN2UDMNCJTOMwkzNO5MDNMGNzNM1cTRNiEzMMmJCLInFGbY1ojIOsITMM5RnIdiUGcZGJiOIP9ETTMBlUUi4UQTsJCLI6ICdIs01WXmxmIbbpjIOhNmIYyVWbZlBVYUvNnccsIibIhNmIYyVWbZsZUYRsISeIklmIaBdTMNFZjRNycjRNCNERQ3QDON5gjMO0gzMOyU0QR5gDNOyADNMiwiIL2QWaZyUDNNzMDNM0UkRRDlTRO0EUOQ2kzNOzQENR4UERRwQUORiMjMMpJCLI3MEZQ4EkNQEJEMQ3QUQR2kzMOxQURRCNjQMwATQMEFjQMBZERRsICOIklmIa1MURQ3QkRRxMzNM3MEMQxQERRBlDROwATQMFVkQRBdTON3MTNMiwiIL1QWaZGRTRN3QDNNwE0QQwU0QR4MUNQ3I0QQ1cTONEZ0QRGlzNOiEkQQpJCLIyUDZNDV0MR3QEORGJUNQxMUOQ3QkQR5YEORGNUNQwADRMyIERQsISNIlRlIVHBXbc19mcbdJCcIjJCLIlRXYdy92Zb6ISeIsIiIIhNmIYyVWbZlBVYUvNncc6IibIhNmIYyVWbZlBVYUvNnccsIibIhNmIYyVWbZsZUYR6ISeIhNmIYyVWbZsZUYRsISeIvNmIYhBXbcSN3cchR3bdvlGda6IibIs0HMfpJyeI6ICZIhNmIYyVWbZlBVYUvNnccsIibIsZmIZicWYZsAjOM5RnIdiUGcZDJiOIF1UQTiEkUQsJCLI6ICdIpJyWIwEEZQwkTNO1UjMNwcTNN5YTNN3IkMQ0ATOM3kzMOFZ0MRzUzNNdJSMIsJCLI6IiZIs01WXhNmIYnVGdZ5J3bciojIOiwiIL6ICeIx4SNLyczNN1ADNM1gTOO5ITMMsQDMNiknIeuEjOMyYDNNxQzNN5cjNN2MDMMzATMM6JCLIxojIOsIjLM4RnId1ojIO2EjLMyEzMM3ITOMwIDOMwQzMNiwCNLikHdeuQjON5cTONyUDMNwMDNMyUDMN5cDNNhJCLIpR3YdiUmdZyRnOdsUWdZmhmIaiY3bdwYjONwJCLIjRXad6ICaIiwCMLl5mebiIXYcuAjOMiwyMLtFmbY6ISZI7muI6uiOm6RaOp5DWOh5ca+j59JiuIisHLeiQWaZjJiOIl1WYbGFmcYikHbemJCLInFGbYwojIO0JCLIlBXeciojIONF0QQBJVRUiwiILiQHbdislOWBRWaZ5UDMN1IDMM3UTNN2UDMNCJTOMwkzNO5MDNMGNzNM1cTRNiEzMMiwSXLiYGbZdtlOWjJCLIlRXYdy92Zb6ISeIsIiIIignIesAjOMiknIex0iOLiwCML6IieIsATMM4RnIdwojIO0JCLI6ISeIiwCML0NWYYlZXadmpjIOzxWYbiwSZLvZGaZ6IidIsAjNMpBnIcoNGdYtojIOsUDNNupnIeyFWZYwojIOsMjLMh5mIbiUWbZpLiOIn/JunmDrnslTYkhm/4gjioLnu7xSfLklmIaiojIOxQWaZGF0NQGVkNREJzNM4I0QQycDNNzkDOODRDON0ITRM0kDOOiIDMMmJCLInFGbYwojIO0JCLIlBXeciojIOMF0VQsICTI0xmIbbpjIOklmIa1ATQMyATOM1UTNN1AzNMykjNO5cjQNzQDMNzcTON3UkRRxMTNMs0lIXmxmIbbpjIOklmIaEVjMNwE0MQCVDMNCljQOwMUOQ4YjNN4U0MRFRERRDJDRMyITQMiwiILFRWaZ5EERQ4UDRN1MTQM2AjRM3IERQ4kTQOxM0MQ2EERQxkDROiMERQpJCLIBlDZO1UzMN0YkNRDhzNOERjNNyY0QREdDON2EzMM5MDRMERjMNdJiNIjJCLIlRXYdy92Zb6ISeIsIiIIlJmIYul2ZaiojIOFRWaZ5EERQ4UDRN1MTQM2AjRM3IERQ4kTQOxM0MQ2EERQxkDROiMERQlJCLIiQmbZpJiOIBlDZO1UzMN0YkNRDhzNOERjNNyY0QREdDON2EzMM5MDRMERjMNsIiNI0NnIcl52bb0FWTYpJXZciwWYbpJiOI1IDZMBNDRM1ADMM5IkQQDljQO2YDMNFNDOMEREORyQURRyE0QQsIiMIpdnIdoRHZdwojIO1EjLMoJCLInlWZazQHad6ICZIy4CNL0JCLIuFmcYhB3ccuVmcZ6ICdIs0HMfpJyeI6ICZIklmIaEVjMNwE0MQCVDMNCljQOwMUOQ4YjNN4U0MRFRERRDJDRMyITQMiwiILhxmZb6IyZIiwCMLwlHde6ISZIB1kITSVEVRMFUSQiwiILiQHbdislOWxQWaZGF0NQGVkNREJzNM4I0QQycDNNzkDOODRDON0ITRM0kDOOiIDMMiwSXLiYGbZdtlOWjJCLIlRXYdy92Zb6ISeIyBnIc1R2bZiQ3YdwJCLIiQWaZwJiOIhdDZN5AjYMyQ2YZ3UWNZkNGNYmFWZY5UjMN5QWMZ2MTMMwQWMZicjZN0JCLI6ICeIiwCMLikHdesAjOM4NnIcxojIOzJCLI6ISeIiwSML09mcbwojIOyJCLIsZWZZ0NWZYu9WabwojIOyJCLIsZWZZ0NWZYu9Wabsd2XZzN3bcl5WabiM3ccsEjOMnlmIay9mbbWVVZVmpjIOzxWYbs0XZfpJyeI6ICZIklmIaBRURR1QUORzEEOQwYUNRCRkNR5E0NQDNDOMBRUMR5QkNRDRUMRiwiILhxmZb6IyZIiwCMLwlHde6ISZIPBlIUU5USTiwiILiQHbdislOWxQWaZGF0NQGVkNREJzNM4I0QQycDNNzkDOODRDON0ITRM0kDOOiIDMMiwSXLiYGbZdtlOWjJCLIlRXYdy92Zb6ISeIsIiIIignIew0iOLzAjLM1gTMOzEDOMwIjMMwADMM5MzNM5JCLIxojIOw4CMLyUTNNyMTNMxETOM5kDNOsEDOMionIe9BjOMisHLeiQWaZpJiOIBlDZO1UzMN0YkNRDhzNOERjNNyY0QREdDON2EzMM5MDRMERjMNsIiNIsZmIZicWYZsAjOM5RnIdiUGcZQJiOIOl0TSsICVI0xmIbbpjIOklmIaBdTMNFZjRNycjRNCNERQ3QDON5gjMO0gzMOyU0QR5gDNOyADNMs0lIXmxmIbbpjIOiwSXL0F2YYvdWZZiknceiIiOI4JCLIxojIOw4CML0gzNO3ATOMzgTOO5kTOOsUTONiknIewEjOM1AjLM1ITNM5IzMM0ETMM4kTOOiwSML6IieIs0HMfpJyeI6ICZIklmIa1QjNNzQjMNFZ0MR5UENRBlzQO5cDNNERjNNFR0MRElDOOzIDMMiwiILhxmZb6IyZIiwCMLwlHde6ISZIBdlIViwETTsJCLI6ICdIpJyWIwEEZQwkTNO1UjMNwcTNN5YTNN3IkMQ0ATOM3kzMOFZ0MRzUzNNdJSMIsJCLI6IiZIpJyWI1cDZN4gDOOGVjRNENERQ3YTRNCdDRN4cTQNCRTONxYERR0UDRNsICRIklmIaBBDOMwYkMR1UURR2UUQRyAjNM5ETRM0MUMQDBTNM5YDRN5UURRiwiIL3QWaZ3IEOQCFERQzAjQMyIzQMCN0MQBlzNOyIEOQ2UEMRzkTROiITOMiwSXL0F2YYvdWZZiknceiIiOIiJCLIpdWZZ6IibIklmIaBBDOMwYkMR1UURR2UUQRyAjNM5ETRM0MUMQDBTNM5YDRN5UURRiwiILk5WZbiojIO3QWaZ3IEOQCFERQzAjQMyIzQMCN0MQBlzNOyIEOQ2UEMRzkTROiITOMzJCLIu9Gdbh1UZTyVGdZsFWaYiojIO3QWaZ4gTNO1YEORDRkRR2UERR3Q0NR3EkQQ0kDOOGRkQR1QUMRiQENR3JCLI0RWaZ6ICaIx4CMLiwSNLpVGaZ0h2ZaiQ2MZuQjONiwiMLhJHdcwNnbclJXYciQnbd9BjOMisHLeiQWaZpJiOI1cDZN4gDOOGVjRNENERQ3YTRNCdDRN4cTQNCRTONxYERR0UDRNsICRIsZmIZicWYZsAjOM5RnIdiUGcZNJiOIFRVQVBlkUSsICTI0xmIbbpjIOklmIa1QjNNzQjMNFZ0MR5UENRBlzQO5cDNNERjNNFR0MRElDOOzIDMMs0lIXmxmIbbpjIOiwSXL0F2YYvdWZZikncewJiOIk9mcb0NWdYiwiILklGcaiojIO3QGcZwIWYYkNWOYlVjMNjRzNNhVGZZ1IjZMkFTOMzETOMkFjNM3YGMZiwiILigHdesAjOM5RnIdwojIOzJCLI6ICeIiwSMLik3cesEjOMvJnIc6ICdIiwCMLmVmcZjVGbZvlGda6IibIiwCMLmVmcZjVGbZvlGdan9lbXz9Gbbul2cazNXZcxojIOpJCLIv52ZbVVmcZ6IiVIsFmZY9V2cZisHLeiQWaZpJiOIwgDZOGJTQMFVEMRFFUNQwYjNNxUkMRDFTOMwUDNN2Q0QRFVUORsISOIsZmIZicWYZsAjOM5RnIdiUGcZQJiOIOl0TSsICVI0xmIbbpjIOklmIa1QjNNzQjMNFZ0MR5UENRBlzQO5cDNNERjNNFR0MRElDOOzIDMMs0lIXmxmIbbpjIOiwSXL0F2YYvdWZZiknceiIiOI4JCLIxojIOw4CML0gzNO3ATOMzgTOO5kTOOsUTONiknIew0iOL3AjLM2gzNO5YjNNwYTNNyADMM4MzMM6JCLIwojIO7xSfLklmIaiojIO3QWaZ3IEOQCFERQzAjQMyIzQMCN0MQBlzNOyIEOQ2UEMRzkTROiITOMmJCLInFGbYwojIO0JCLIlBXeciojIOJ9EUTiQlTVsJCLI6ICdIpJyWI0YDZN0ITNMGNzMMFRTRN5MUOQ3QTQN0YTONENDRM5gTROyADRMdJyMIsJCLI6IiZIs01WXhNmIYnVGdZ5J3bciojIOiwiIL6ICeIuATLMxMDMM4UDONyMTMMwAjMM3ADMMskzMOiknIew0iOL3AjLM2gzNO5YjNNwYTNNyADMM4MzMM6JCLIwojIO7xSfLklmIaiojIODRWaZBZzNNCBDOMEFERQ5MzNMEVkNRzIUMQwEkQQxIEMQGRERRigTQOmJCLInFGbYwojIO0JCLIlBXeciojIOMF0VQsICTI0xmIbbpjIOklmIa1ATQMyATOM1UTNN1AzNMykjNO5cjQNzQDMNzcTON3UkRRxMTNMs0lIXmxmIbbpjIOklmIawUzNNFdjQN4UzQN0QTRN5IjRM4UkNRyQ0QR0YkQRwE0QQzYDNNiwiILERWaZwAjNM5ETQM4ITRMyYUNRDZzNNwgTRODNkNQyMkRQERzMNiYERRpJCLI1MEZQGNDMMDdTMN5YkMR4E0MQFZ0QR2UEOR1ATMM4QUORBRTNNdJCNIjJCLIlRXYdy92Zb6ISeIsIiIIlJmIYul2ZaiojIOERWaZwAjNM5ETQM4ITRMyYUNRDZzNNwgTRODNkNQyMkRQERzMNiYERRlJCLIiQmbZpJiOI1MEZQGNDMMDdTMN5YkMR4E0MQFZ0QR2UEOR1ATMM4QUORBRTNNsICNI0NnIcl52bb0FWTYpJXZciwWYbpJiOI1cDZN3IEMQ1MURQ0UEORyYENRFZTONENEOQGJkMQBNENQ2QDMNsIyMIpdnIdoRHZdwojIO1EjLMoJCLInlWZazQHad6ICZIy4CNL0JCLIuFmcYhB3ccuVmcZ6ICdIs0HMfpJyeI6ICZIklmIawUzNNFdjQN4UzQN0QTRN5IjRM4UkNRyQ0QR0YkQRwE0QQzYDNNiwiILhxmZb6IyZIiwCMLwlHde6ISZIB1kITSVEVRMFUSQiwiILiQHbdislOWDRWaZBZzNNCBDOMEFERQ5MzNMEVkNRzIUMQwEkQQxIEMQGRERRigTQOiwSXLiYGbZdtlOWjJCLIlRXYdy92Zb6ISeIyBnIc1R2bZiQ3YdwJCLIiQWaZwJiOIhdDZN5AjYMyQ2YZ3UWNZkNGNYmFWZY5UjMN5QWMZ2MTMMwQWMZicjZN0JCLI6ICeIiwCMLikHdesAjOM4NnIcxojIOzJCLI6ISeIiwSML09mcbwojIOyJCLIsZWZZ0NWZYu9WabwojIOyJCLIsZWZZ0NWZYu9Wabsd2XZzN3bcl5WabiM3ccsEjOMnlmIay9mbbWVVZVmpjIOzxWYbs0XZfpJyeI6ICZIklmIawYDRNxEEMQyUUORGVDON2cjMN4U0QRDZDMNDZ0QR0MjMMGRERRiwiILhxmZb6IyZIiwCMLwlHde6ISZIPBlIUU5USTiwiILiQHbdislOWDRWaZBZzNNCBDOMEFERQ5MzNMEVkNRzIUMQwEkQQxIEMQGRERRigTQOiwSXLiYGbZdtlOWjJCLIlRXYdy92Zb6ISeIsIiIIignIew0iOLzAjLM1gTMOzEDOMwIjMMwADMM5MzNM5JCLItojIOw4CML4czNN2YjNN2UTONwADMMzMjMMiwCOL6IieIs0HMfpJyeI6ICZIklmIawUzQNxY0MRyM0NQzkjRODhTQO4UkRRxYTRN5UDMN1gDRO0EENQiwiILhxmZb6IyZIiwCMLwlHde6ISZIPBlIUU5USTiwiILiQHbdislOWDRWaZBZzNNCBDOMEFERQ5MzNMEVkNRzIUMQwEkQQxIEMQGRERRigTQOiwSXLiYGbZdtlOWjJCLIlRXYdy92Zb6ISeIsIiIIignIew0iOLzAjLM1gTMOzEDOMwIjMMwADMM5MzNM5JCLIxojIOw4CMLyUTNNyMTNMxETOM5kDNOsEDOMionIe9BjOMisHLeiQWaZpJiOIDVEZREZUNRzczNNDBTMMER0NR5QUMRwEUQQFJEMQ3kTROzUTQNsIyNIsZmIZicWYZsAjOM5RnIdiUGcZXJiOIMxUQTiwiILiQHbdislOWBRWaZ5UDMN1IDMM3UTNN2UDMNCJTOMwkzNO5MDNMGNzNM1cTRNiEzMMiwSXLiYGbZislOWDRWaZ3cTMNBVUQRDZEORDF0NQ1QEORDhzMO4gDROwMUMQwU0NRikDOOpJCLI5QDZNyI0MQyE0MQGlTQOCJkQQ1I0MQCFUOQ5UDMNEhDMOCVENRsIyNIklmIa0UUORFVkMRzIkQQwcDRN5QUMRBJTMMEFTQMzQTNN0EkMQzQDRNs0lIXhNmIYnVGdZ5J3bciojIOiwiILnVmYZi4WabpJiOI5QDZNyI0MQyE0MQGlTQOCJkQQ1I0MQCFUOQ5UDMNEhDMOCVENRsIyNIuVmIZ6ICZIklmIa0UUORFVkMRzIkQQwcDRN5QUMRBJTMMEFTQMzQTNN0EkMQzQDRNiwiILvR3cdNVmbZlRXYdhlmca6ICbIklmIa3EzQMFF0NQGhTQOBdzQNEhzQO4MTNM4Q0QRDFDOMFdDMN5gDMOiwiILkl2daigGdauAjOMsUTMNlhmIaodWaZkNDdM0ojIOsIjLMyRnIdz5WYbyFGcY05WZbwojIO7xSfLklmIaiojIODRWaZ3cTMNBVUQRDZEORDF0NQ1QEORDhzMO4gDROwMUMQwU0NRikDOOmJCLInFGbYwojIO0JCLIlBXeciojIOUFUTQJJVRUiwUQTsJCLI6ICdIpJyWIDVEZREZUNRzczNNDBTMMER0NR5QUMRwEUQQFJEMQ3kTROzUTQNdJyNIsJCLI6IiZIs01WXhNmIYnVGdZ5J3bciojIOvJHccjVHZdsICdIpBnIc6ICZIkBnIciF2NYjlDMO1IDZM0cTZNlR2YZyYWYZxkTNOxkDZOxYzMNmBDZMsIyNI4RnIdwojIO0JCLI6ISeIiwCMLig3cesEjOM5NnIcxojIOyJCLIiQ3bdsAjOMlJnIclxmZbpR3Ydi42bbsAjOMlJnIclxmZbpR3Ydf52bbvx2ZbpN3cczVmbZ6IycIiwSMLudWaZlJ3bciYVVVhZmOZlNHbc7xSfLklmIaiojIO0QWaZCNTOMBNjMM5EkMQCJkRQCNjQMBlTNO1AjQM4ATOMFRDRNicjQNmJCLInFGbYwojIO0JCLIlBXeciojIOJ9EUTiQlTVsJCLI6ICdIpJyWIDVEZREZUNRzczNNDBTMMER0NR5QUMRwEUQQFJEMQ3kTROzUTQNdJyNIsJCLI6IiZIs01WXhNmIYnVGdZ5J3bciojIOiwiIL6ICeIuATMM4cDMNwkDNO4kzNO5kzMO1kTOO5JCLIxojIOw4CMLyUTNNyMTNMxETOM5kDNOsEDOMionIe9BjOMisHLeiQWaZpJiOIFlDZOFJDNMCJURQ3Q0MREFDMMyETOMxEUQQ0UDRNBJzMM0QENRsIyMIsZmIZicWYZsAjOM5RnIdiUGcZQJiOIOl0TSsICVI0xmIbbpjIOklmIa1MURQ3QkRRxMzNM3MEMQxQERRBlDROwATQMFVkQRBdTON3MTNMs0lIXmxmIbbpjIOiwSXL0F2YYvdWZZiknceiIiOI4JCLIxojIOw4CML0gzNO3ATOMzgTOO5kTOOsUTONiknIew0iOL3AjLM2gzNO5YjNNwYTNNyADMM4MzMM6JCLIwojIO7xSfLklmIaiojIO1QWaZGRTRN3QDNNwE0QQwU0QR4MUNQ3I0QQ1cTONEZ0QRGlzNOiEkQQmJCLInFGbYwojIO0JCLIlBXeciojIOPxkRTiI1TUsJCLI6ICdIpJyWIwEEZQwkTNO1UjMNwcTNN5YTNN3IkMQ0ATOM3kzMOFZ0MRzUzNNdJSMIsJCLI6IiZIpJyWIyYEZRBV0NRxcDMNwEkNQ5QEMRzYTRNFdDONxIUQQGNkNQ3cDRNsISMIklmIa2EDRM2AjNMElzMOFhjRO4YTRN4kTQO4EURQ5YURRFlTROFRDNNiwiILxQWaZ0QzQN1cjMNyUkNR2kzMODVkRR2IEOQCNENQwEEMQDRkQRiM0QQiwSXL0F2YYvdWZZiknceiIiOImJCLIv9Gbbh1kcTyVGdZsFWaYiojIOERWaZ2YTMNzYDMNGRUORFVEORBhjNOFhTOOFhTQOFljRO0UUORiUENRjJCLIslWZan5Wab0FWTYpJXZciwWYbpJiOIDFDZMyQDNN2UzNNzITRMGZTON4MURQ0YjQNwI0QQCBTQMDNERQsIyQIvJnIcNR3bdlRXYdhlmca6ICbIklmIa3IjRMwEURQ2EzNMwATQMFlDRO4MjNMBV0NR2EjQMEZ0QRxczNNiwiILiFGbYiwWZbiIiOIsJCLIlJWYYigFbWuUjONzIDMMsJCLIlJWYYikFbWuQjON4gTOOiwSNLvJHccslmZa6ISZIpJyWI3EDZM2YUQR3YURRDRkMR0gjQO4IzNM4MTOMFNENQ4QjMNwQTONsIiMIklmIa1MURQ3QkRRxMzNM3MEMQxQERRBlDROwATQMFVkQRBdTON3MTNMiwiIL2QWaZyUDNNzMDNM0UkRRDlTRO0EUOQ2kzNOzQENR4UERRwQUORiMjMMpJCLI3MEZQ4EkNQEJEMQ3QUQR2kzMOxQURRCNjQMwATQMEFjQMBZERRdJCOIoJCLInlWZazQHad6ICZIy4CNLfJCLI6ISbI1ATMM4QjLN5gTNO1ETOM4ITOM3gTMOfJCLIig3YeuUjONzIDMM2EzMMzMzMM5kDMOykTOOfJCLIik3YeuQjON4gTOOzkjNO3kjMO0czNN4cTONwJCLIlZXYdwlHVe6ISZIJNlIUMdkTRBBVRUfVkVRiEDMMnJCLI3BXYc0RWaZ6ICaIw4CML9NDMMisHLeiQWaZpJiOIyYEZRBV0NRxcDMNwEkNQ5QEMRzYTRNFdDONxIUQQGNkNQ3cDRNsISMIsZmIZicWYZsAjOM5RnIdiUGcZNJiOIFRVQVBlkUSBJFTUPN0VQS9ETTiwiILiQHbdislOW1QWaZGRTRN3QDNNwE0QQwU0QR4MUNQ3I0QQ1cTONEZ0QRGlzNOiEkQQiwSXLiYGbZdtlOWjJCLIlRXYdy92Zb6ISeIvNmIYy9GbbiwiILklGcaiojIOs92YbiI3bc0JCLI6ICeIiwCMLikHdesAjOM4NnIcxojIOzJCLI6ISeIiwSML09mcbwojIOyJCLIsZWZZ0NWZYu9WabwojIOyJCLIsZWZZ0NWZYu9Wabsd2XZzN3bcl5WabiM3ccsEjOMnlmIay9mbbWVVZVmpjIOzxWYbiwSZLmlGZazVnZdy9VZXxojIOskjNOpRmIZ1ZmZZfV2cZ6IyZI5YTMNkJCLImZWaZlNXdciI2XY2EjOMiwSOLyV3Xd6ICbIw9jIP9QWaZs92YbmI3bc9A3bcs92YbmI3bcx0jcPmkjNOx0zZPmkjNOx0jYPikjNOfJCLI1QWbZiojIOzkDNOmNjMM4QTZN0YGZZmVmZZ3MjNMwUWOZxYGNZyImYYhVmYZiYGMZ7xSfLklmIaiojIOERWaZ2YTMNzYDMNGRUORFVEORBhjNOFhTOOFhTQOFljRO0UUORiUENRmJCLInFGbYwojIO0JCLIlBXeciojIOUFUTQJJVRUiwUQTsJCLI6ICdIpJyWIFVDZN0YENRDdDNNDBTQM1ATRMDhzQO5cjQNDVzNN3QkRRCZUORdJSQIsJCLI6IiZIs01WXhNmIYnVGdZ5J3bciojIOslGdasISZIpBnIc6ICZIlJmIYoNWZYv92dbvhGZa5VmbZiwiILigHdesAjOM5RnIdwojIOzJCLI6ICeIiwSMLik3cesEjOMvJnIc6ICdIiwCMLmVmcZjVGbZvlGda6IibIz4CMLyJCLIsZWZZ0NWZYu9Wabsd2XZzN3bcl5WabiM3ccuAjOMsITOMnlmIay9mbbWVVZV0pjIOlVncd7xSfLklmIaiojIOxQWaZ0QzQN1cjMNyUkNR2kzMODVkRR2IEOQCNENQwEEMQDRkQRiM0QQmJCLInFGbYwojIO0JCLIlBXeciojIOUFUTQJJVRUiwUQTsJCLI6ICdIpJyWIFVDZN0YENRDdDNNDBTQM1ATRMDhzQO5cjQNDVzNN3QkRRCZUORdJSQIsJCLI6IiZIs01WXhNmIYnVGdZ5J3bciojIOslGdasISZIpBnIc6ICZIpRnIdwUGbZiEDMM0JCLI6ICeIiwCMLikHdesAjOM4NnIcxojIOzJCLI6ISeIiwSML09mcbwojIOyJCLIsZWZZ0NWZYu9WabwojIOyJCLIsZWZZ0NWZYu9Wabsd2XZzN3bcl5WabiM3ccsEjOMnlmIay9mbbWVVZV0pjIOlVncd7xSfLklmIaiojIO1QWaZFNjMMEhzQOCVzNNDljROEJUMQGhzNODVTONwQkRRCREMRiUjMNmJCLInFGbYxojIO2YTONsgDMO5RnIdiUGcZQJiOIE9kUTUNUVQiwiILiQHbdislOWBRWaZ5UDMN1IDMM3UTNN2UDMNCJTOMwkzNO5MDNMGNzNM1cTRNiEzMMiwSXLiYGbZdtlOW1JCLIyV2cZmVGRZl5Wab6ICZIyJyeIsBXZclNWYYuVWbZ6ICdIwIyeIxEDMM6ISOIhJyeIhVmcZzojIO14CNLxQjNN2YDMNwcjMNyQDON91nNfiwSfL0F2YYvdWZZikncemJiOIuJXdc1RXadiUmcZ4JCLI1ojIOyAjLM1UzMN5kDMOzITOM3QDNN5JCLI0ojIO4kjLOzcDON0gjNOxUTNN2YzMNiwCOL6IieIiwCMLklGcaiojIOwkDcOklDZOjZTZNhR2NZ1QTYN5gzYO0cDMN3cjZN0gjNO4gjZOxEGOYiwiILig3cesEjOM5NnIcxojIOwAjLMzIDMMwkDNOxIzNM1YTMNsQTMN6NnIcxojIOyJCLIiQ3bdsAjOMsZmIZiAXacsAjOMvJnIcigHdesAjOMvJnIcikHdesAjOMvJnIcioHdesAjOMulmIa4VGZZxojIOxJCLI0FWdYuJXZcu9Wabig3XesAjOM1FnIclRXYdp5mcbf52bb6ISeIiwCMLhVXcdyVGdZvlmba69lbXwojIOxJCLI0FWdYuJXZcu9Wabic3Xd9FjOMisHLeiQWaZUJiOIw1WZbvJ3RciAXdcmJCLInFGbYwojIO0JCLIlBXeciojIOPJ1RUiAVVUsJCLI6ICdIpJyWIwEEZQwkTNO1UjMNwcTNN5YTNN3IkMQ0ATOM3kzMOFZ0MRzUzNNdJSMIsJCLI6IiZIs01WXhNmIYnVGdZ5J3bciojIOiwiILtFmbY6ISZI4SuI5XaOt57eut5QWOh5sICiIoNmIYkxWabuVmcZbpjIOd1XXflJCLIyRHedpxWYb0h2ZabpjIO4JyeIwojIO2cjLN0EDOM2gTMO5czNN5kTOOscjMNiknIeuAjOMyIzNMzMTMM0AzMM5kzMO2cTONiwyNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMs0HOf4JyeIwojIO2cjLN0EDOM2gTMO5czNN5kTOOscjMNiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMwADOMwADMMwADMMwADMMwADMMs0nMf4JyeIwojIO2cjLN0EDOM2gTMO5czNN5kTOOscjMNiknIeuEjOMyITOMzMTMM0AzMM5kzMO2cTONiwSOL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMwADOMwADMMwADMMwADMMwADMMs0nMf4JyeIwojIO2cjLN0EDOM2gTMO5czNN5kTOOscjMNiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CMLwADMMwADMMwADMMwADMMyADMM7xSfLignIeuAjOM4YzNNxQTMN3YDON5kzNOykTOOiwyNL6ISeIx4yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIOwgjLOwADMMwADMMwADMMwADMM9JDMMisHLe6ICeI34CMLxgjNO4EDNM3cjNN5kTOO3ITOM5JCLIzojIOycjLNzEjMMwMzMM5MDNM3kTOOiwyNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMwADOMwADMMwADMMwADMMwADMMs0nMf4JyeIwojIO2cjLN0EDOM2gTMO5czNN5kTOOscjMNiknIeuQjONyIzMMzMTMM0AzMM5kzMO3cTON6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CMLwADMMwADMMwADMMwADMMyADMM7xSfLignIeuAjOM4YzNNxQTMN3YDON5kzNOykTOOiwyNL6ISeI54CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIOwgjLOwADMMwADMMwADMMwADMM9JDMMisHLe6ICeI34CMLxgjNO4EDNM3cjNN5kTOO3ITOM5JCLI1ojIOyUjLNzEjMMwMzMM5MDNM3kTOOsUjNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIOwgjLOwADMMwADMMwADMMwADMM9JDMMisHLe6ICeI34CMLxgjNO4EDNM3cjNN5kTOO3ITOM5JCLI2ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwiNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMwADOMwADMMwADMMwADMMwADMMs0nMf4JyeIwojIO2cjLN0EDOM2gTMO5czNN5kTOOscjMNiknIeuYjONyIzNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CMLwADMMwADMMwADMMwADMMyADMM7xSfLignIeuAjOM4YzNNxQTMN3YDON5kzNOykTOOiwyNL6ISeIz4yNLxIjMMzMzMMzQDMN5kTOO1UzNN6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CMLwADMMwADMMwADMMwADMMyADMM7xSfLignIeuAjOM4YzNNxQTMN3YDON5kzNOykTOOiwyNL6ISeI54yNLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIOwgjLOwADMMwADMMwADMMwADMM9JDMMisHLe6ICeI34CMLxgjNO4EDNM3cjNN5kTOO3ITOM5JCLI4ojIOyUjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMwADOMwADMMwADMMwADMMwADMMs0nMf4JyeIwojIO2cjLN0EDOM2gTMO5czNN5kTOOscjMNiknIeukjOOyITMMzMTMM0AzMM5kzMO1cTON6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CMLwADMMwADMMwADMMwADMMyADMM7xSfLignIeuEjOM4YzMNxQTMN3YDON5kzNOykTOOiwCOL6ISeI34CMLxIjMMzMzMMzQDMN5kTOO3YzNN6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CML7xSfLignIeuEjOM4YzMNxQTMN3YDON5kzNOykTOOiwCOL6ISeIz4SMLxIjMMzMzMMzQDMN5kTOO4YzNN6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeIz4SMLxgjNO4EDNM3cjNN5kTOO4ITOM5JCLIxojIOykjLOzEjMMwMzMM5MDNM3kTOOskjNOionIeuQjONwYDMNwADMMwADMMwADMMwADMMiwSNLzlGZauFGdYiU2YZuEjOMwADNMwADMMwADMMwADMMwADMMs0XMf4JyeIxojIO2MjLM0EDOM2gTMO5czNN5kTOOsgjMOiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeIz4SMLxgjNO4EDNM3cjNN5kTOO4ITOM5JCLIzojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuEjOM4YzMNxQTMN3YDON5kzNOykTOOiwCOL6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjONwYDMNwADMMwADMMwADMMwADMMiwSNLzlGZauFGdYiU2YZuEjOMwADNMwADMMwADMMwADMMwADMMs0XMf4JyeIxojIO2MjLM0EDOM2gTMO5czNN5kTOOsgjMOiknIeuQjONyIzMMzMTMM0AzMM5kzMO3cTON6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeIz4SMLxgjNO4EDNM3cjNN5kTOO4ITOM5JCLI0ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwyNL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuEjOM4YzMNxQTMN3YDON5kzNOykTOOiwCOL6ISeI14SNLxIjMMzMzMMzQDMN5kTOO1YzNN6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeIz4SMLxgjNO4EDNM3cjNN5kTOO4ITOM5JCLI2ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwiNL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuEjOM4YzMNxQTMN3YDON5kzNOykTOOiwCOL6ISeI34iNLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuQjONwYDMNwADMMwADMMwADMMwADMMiwSNLzlGZauFGdYiU2YZuEjOMwADNMwADMMwADMMwADMMwADMMs0XMf4JyeIxojIO2MjLM0EDOM2gTMO5czNN5kTOOsgjMOiknIeucjONyIzMMzMTMM0AzMM5kzMO1cTONiwSNL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuEjOM4YzMNxQTMN3YDON5kzNOykTOOiwCOL6ISeI54yNLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjONwYDMNwADMMwADMMwADMMwADMMiwSNLzlGZauFGdYiU2YZuEjOMwADNMwADMMwADMMwADMMwADMMs0XMf4JyeIxojIO2MjLM0EDOM2gTMO5czNN5kTOOsgjMOiknIeugjOOyITNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeIz4SMLxgjNO4EDNM3cjNN5kTOO4ITOM5JCLI5ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwSNL6IieIx4CNL2YDMNwgDOOzEDMMsUjMNpRmIZhR3cdlNmbYwojIOzkjLOxEzMM4kTOO1cjNNwADMM9dTNNisHLe6ICeI54SMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuAjOMyIzNMzMTMM0AzMM5kzMO2cTONiwyNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMs0HOf4JyeIxojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4SMLxIjMMzMzMMzQDMN5kTOO4YzNN6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeI54SMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuEjOMyITOMzMTMM0AzMM5kzMO2cTONiwSOL6IieIiwCNLzlGZauFGdYiU2YZuIjOMwADMMwADMMwADMMwADMMwADMMs0HNf4JyeIxojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeI14iMLxIjMMzMzMMzQDMN5kTOOsczNNionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeI54SMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuMjOMyITMMzMTMM0AzMM5kzMO3cTON6JCLI0ojIOkJCLI0NXacj5WYb6ISZIw4iMLwADMMwADMMwADMMwADMM0ADMM7xSfLignIeuEjOM4YTONxQTMN3YDON5kzNOzkTOO5JCLIzojIOycjLNzEjMMwMzMM5MDNM3kTOOiwyNL6IieIiwCNLzlGZauFGdYiU2YZuIjOMwADMMwADMMwADMMwADMMwADMMs0HNf4JyeIxojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4CNLxIjMMzMzMMzQDMN5kTOOsczNNionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeI54SMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuQjONyITOMzMTMM0AzMM5kzMO3cTON6JCLI0ojIOkJCLI0NXacj5WYb6ISZIw4iMLwADMMwADMMwADMMwADMM0ADMM7xSfLignIeuEjOM4YTONxQTMN3YDON5kzNOzkTOO5JCLI1ojIOyUjLNzEjMMwMzMM5MDNM3kTOOsUjNNionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeI54SMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuYjONyITMMzMTMM0AzMM5kzMO2cTON6JCLI0ojIOkJCLI0NXacj5WYb6ISZIw4iMLwADMMwADMMwADMMwADMM0ADMM7xSfLignIeuEjOM4YTONxQTMN3YDON5kzNOzkTOO5JCLI2ojIOycjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieIiwCNLzlGZauFGdYiU2YZuIjOMwADMMwADMMwADMMwADMMwADMMs0HNf4JyeIxojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4yNLxIjMMzMzMMzQDMN5kTOO1UzNN6JCLI0ojIOkJCLI0NXacj5WYb6ISZIw4iMLwADMMwADMMwADMMwADMM0ADMM7xSfLignIeuEjOM4YTONxQTMN3YDON5kzNOzkTOO5JCLI3ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwSNL6IieIiwCNLzlGZauFGdYiU2YZuIjOMwADMMwADMMwADMMwADMMwADMMs0HNf4JyeIxojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeI14COLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuQjON2QDMN4gjNOxADMM0IzMM5kTOOkJCLI0NXacj5WYb6ISZI14SMLxMzMM5kTMO3YDONwATNM0UDMN7xSfLignIeuEjOM4YTONxQTMN3YDON5kzNOzkTOO5JCLI5ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwSNL6IieIx4CNL2YDMNwgDOOzEDMMsUjMNpRmIZhR3cdlNmbYwojIOzkjLOxEzMM4kTOO1cjNNwADMM9dTNNisHLe6ICeI14iMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuAjOMyIzNMzMTMM0AzMM5kzMO2cTONiwyNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMs0HOf4JyeIyojIO2UjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4SMLxIjMMzMzMMzQDMN5kTOO4YzNN6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeI14iMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuEjOMyITOMzMTMM0AzMM5kzMO2cTONiwSOL6IieIiwCNLzlGZauFGdYiU2YZuIjOMwADMMwADMMwADMMwADMMwADMMs0HNf4JyeIyojIO2UjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeI14iMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMsQTONpRmIZhR3cdlNmbYyojIOwYjLNwADMMwADMMwADMMwADMM9VDMNisHLe6ICeI14iMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuMjOMyITMMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuIjOM4YTNNxQTMN3YDON5kzNOzkTOO5JCLIzojIOycjLNzEjMMwMzMM5MDNM3kTOOiwyNL6IieI54yMLiwCNLzlGZauFGdYiU2YZuIjOMwAjNMwADMMwADMMwADMMwADMMs0XNf4JyeIyojIO2UjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMsQTONpRmIZhR3cdlNmbYyojIOwYjLNwADMMwADMMwADMMwADMM9VDMNisHLe6ICeI14iMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuQjONyITOMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuIjOM4YTNNxQTMN3YDON5kzNOzkTOO5JCLI1ojIOyUjLNzEjMMwMzMM5MDNM3kTOOsUjNNionIeuMjOMsQTONpRmIZhR3cdlNmbYyojIOwYjLNwADMMwADMMwADMMwADMM9VDMNisHLe6ICeI14iMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuYjONyITMMzMTMM0AzMM5kzMO2cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuIjOM4YTNNxQTMN3YDON5kzNOzkTOO5JCLI2ojIOycjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieI54yMLiwCNLzlGZauFGdYiU2YZuIjOMwAjNMwADMMwADMMwADMMwADMMs0XNf4JyeIyojIO2UjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4yNLxIjMMzMzMMzQDMN5kTOO1UzNN6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuIjOM4YTNNxQTMN3YDON5kzNOzkTOO5JCLI3ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwSNL6IieI54yML2YDONwgDOOzEDMM5QjMN3kTOOkJCLI0NXacj5WYb6ISZIx4iMLxMzMM5kTMO3YDONwATNM9ZDMNisHLe6ICeI14iMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeugjOOyITNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIO0AjLM4YjNNwADOMyMTMM5kDNOiwSOLzlGZauFGdYiU2YZuEjOMzMTNM5ETMM2gTOOwUzNN1ADMMs0HNf4JyeIyojIO2UjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeIx4SOLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjON2ATMM4gjNOxADMM1IzMMkJCLI0NXacj5WYb6ISZI54CMLxMzMM5kTMO3YDONwATNM3UDMN7xSfLignIeuMjOM4YTMNxQTMN3YDON5kzNOzkTOO5JCLIwojIOycjLNzEjMMwMzMM5MDNM3kTOOscjNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIO9hjLOisHLe6ICeIx4yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuMjOM4YTMNxQTMN3YDON5kzNOzkTOO5JCLIxojIOykjLOzEjMMwMzMM5MDNM3kTOOskjNOionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeIx4yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuMjOM4YTMNxQTMN3YDON5kzNOzkTOO5JCLIzojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yMLiwCOLzlGZauFGdYiU2YZuMjOMwAjMMwADMMwADMMwADMMwADMMs0nNf4JyeIzojIO2EjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMsgDOOpRmIZhR3cdlNmbYzojIOwIjLMwADMMwADMMwADMMwADMM9ZDMNisHLe6ICeIx4yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuQjONyIzMMzMTMM0AzMM5kzMO3cTON6JCLIzojIO4gjLOkJCLI0NXacj5WYb6ISZIy4yMLwADMMwADMMwADMMwADMM2ADMM7xSfLignIeuMjOM4YTMNxQTMN3YDON5kzNOzkTOO5JCLI0ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yMLiwCOLzlGZauFGdYiU2YZuMjOMwAjMMwADMMwADMMwADMMwADMMs0nNf4JyeIzojIO2EjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeI14SNLxIjMMzMzMMzQDMN5kTOO1YzNN6JCLIzojIO4gjLOkJCLI0NXacj5WYb6ISZIy4yMLwADMMwADMMwADMMwADMM2ADMM7xSfLignIeuMjOM4YTMNxQTMN3YDON5kzNOzkTOO5JCLI2ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwiNL6IieI44yMLiwCOLzlGZauFGdYiU2YZuMjOMwAjMMwADMMwADMMwADMMwADMMs0nNf4JyeIzojIO2EjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeI34iNLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuMjOMsgDOOpRmIZhR3cdlNmbYzojIOwIjLMwADMMwADMMwADMMwADMM9ZDMNisHLe6ICeIx4yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeucjONyIzMMzMTMM0AzMM5kzMO1cTONiwSNL6IieI54yML2YjMNwgDOOzEDMM5QjMN2kTOOkJCLI0NXacj5WYb6ISZI34iMLxMzMM5kTMO3YDONwATNM2UDMN7xSfLignIeuMjOM4YTMNxQTMN3YDON5kzNOzkTOO5JCLI3ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwSNL6IieI54yML2YDONwgDOOzEDMM5QjMN3kTOOkJCLI0NXacj5WYb6ISZIx4iMLxMzMM5kTMO3YDONwATNM9ZDMNisHLe6ICeIx4yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeugjOOyITNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIO0AjLM4YjNNwADOMyMTMM5kDNOiwSOLzlGZauFGdYiU2YZuEjOMzMTNM5ETMM2gTOOwUzNN1ADMMs0HNf4JyeIzojIO2EjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeIx4SOLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjON2ATMM4gjNOxADMM1IzMMkJCLI0NXacj5WYb6ISZI54CMLxMzMM5kTMO3YDONwATNM3UDMN7xSfLignIeuMjOM4YzNNxQTMN3YDON5kzNOzkTOO5JCLIwojIOycjLNzEjMMwMzMM5MDNM3kTOOscjNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIO9hjLOisHLe6ICeI34yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuMjOM4YzNNxQTMN3YDON5kzNOzkTOO5JCLIxojIOykjLOzEjMMwMzMM5MDNM3kTOOskjNOionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeI34yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuMjOM4YzNNxQTMN3YDON5kzNOzkTOO5JCLIzojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yMLiwCOLzlGZauFGdYiU2YZuMjOMwAjMMwADMMwADMMwADMMwADMMs0nNf4JyeIzojIO2cjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMwIDOMwADMMwADMMwADMMwADMMiwyMLzlGZauFGdYiU2YZuMjOMwADOMwADMMwADMMwADMMwADMMs03Nf4JyeIzojIO2cjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMwIDOMwADMMwADMMwADMMwADMMiwyMLzlGZauFGdYiU2YZuMjOMwADOMwADMMwADMMwADMMwADMMs03Nf4JyeIzojIO2cjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeI54CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMwIDOMwADMMwADMMwADMMwADMMiwyMLzlGZauFGdYiU2YZuMjOMwADOMwADMMwADMMwADMMwADMMs03Nf4JyeIzojIO2cjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeI14SNLxIjMMzMzMMzQDMN5kTOO1YzNN6JCLIzojIOygjLOwADMMwADMMwADMMwADMMsMDMMpRmIZhR3cdlNmbYzojIOwgjLOwADMMwADMMwADMMwADMM9dDMNisHLe6ICeI34yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuYjONyITMMzMTMM0AzMM5kzMO2cTON6JCLIzojIOygjLOwADMMwADMMwADMMwADMMsMDMMpRmIZhR3cdlNmbYzojIOwgjLOwADMMwADMMwADMMwADMM9dDMNisHLe6ICeI34yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuYjONyIzNMzMTMM0AzMM5kzMO2cTON6JCLIzojIO2gjLO4YjNNwADOMyMTMM5kDNOsYTONpRmIZhR3cdlNmbYzojIOzMjLMxEzMM4kTOO1cjNNwADMMs0XNf4JyeIzojIO2cjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4yNLxIjMMzMzMMzQDMN5kTOO1UzNN6JCLIzojIOykjLO4YjNNwADOMyMTMM5kDNOsYTONpRmIZhR3cdlNmbYyojIOzcjLNxEzMM4kTOO1cjNNwADMM9ZTNNisHLe6ICeI34yMLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeucjONyITOMzMTMM0AzMM5kzMO1cTON6JCLIzojIO4kjLO4YjNNwADOMyMTMM5kDNOscTONpRmIZhR3cdlNmbYyojIOzEjLMxEzMM4kTOO1cjNNwADMMs0nNf4JyeIzojIO2cjLN0EDOM2gTMO5czNN5kTOOiwyML6ISeI14COLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuQjON2QDMN4gjNOxADMM0IzMM5kTOOkJCLI0NXacj5WYb6ISZI14SMLxMzMM5kTMO3YDONwATNM0UDMN7xSfLignIeuMjOM4YzNNxQTMN3YDON5kzNOzkTOO5JCLI5ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwSNL6IieIx4CNL2YDMNwgDOOzEDMMsUjMNpRmIZhR3cdlNmbYwojIOzkjLOxEzMM4kTOO1cjNNwADMM9dTNNisHLe6ICeIz4CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuAjOMyIzNMzMTMM0AzMM5kzMO2cTONiwyNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMs0HOf4JyeI0ojIO2MjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4SMLxIjMMzMzMMzQDMN5kTOO4YzNN6JCLI0ojIO2AjLMwADMMwADMMwADMMwADMMsUDMNpRmIZhR3cdlNmbYxojIOwQjLNwADMMwADMMwADMMwADMM9FDMMisHLe6ICeIz4CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuEjOMyITOMzMTMM0AzMM5kzMO2cTONiwSOL6IieIiwCNLzlGZauFGdYiU2YZuIjOMwADMMwADMMwADMMwADMMwADMMs0HNf4JyeI0ojIO2MjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeI14iMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMsQTONpRmIZhR3cdlNmbYyojIOwYjLNwADMMwADMMwADMMwADMM9VDMNisHLe6ICeIz4CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuMjOMyITMMzMTMM0AzMM5kzMO3cTON6JCLIzojIO4gjLOkJCLI0NXacj5WYb6ISZIy4yMLwADMMwADMMwADMMwADMM2ADMM7xSfLignIeuQjON4YzMNxQTMN3YDON5kzNOzkTOO5JCLIzojIOycjLNzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yMLwAjMMwADMMwADMMwADMMzADMMkJCLI0NXacj5WYb6ISZI44yMLwADMMwADMMwADMMwADMM3ADMM7xSfLignIeuQjON4YzMNxQTMN3YDON5kzNOzkTOO5JCLI0ojIOyMjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieI34yMLwAjNMwADMMwADMMwADMMyADMMkJCLI0NXacj5WYb6ISZI04CNL7xSfLignIeuQjON4YzMNxQTMN3YDON5kzNOzkTOO5JCLI0ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwyNL6IieI34yMLwAjNMwADMMwADMMwADMMyADMMkJCLI0NXacj5WYb6ISZI04CNL7xSfLignIeuQjON4YzMNxQTMN3YDON5kzNOzkTOO5JCLI1ojIOyUjLNzEjMMwMzMM5MDNM3kTOOsUjNNionIeuMjOMwYzNNwADMMwADMMwADMMwADMMiwiMLzlGZauFGdYiU2YZuQjONs0HNf4JyeI0ojIO2MjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeIx4iNLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuMjOM2ADOM4gjNOxADMM0IzMM5kTOOiwSNLzlGZauFGdYiU2YZuMjOMzMTOM5ETMM2gTOOwUzNN1ADMM7xSfLignIeuQjON4YzMNxQTMN3YDON5kzNOzkTOO5JCLI2ojIOycjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieI44yML2YjNNwgDOOzEDMM5QjMN2kTOOkJCLI0NXacj5WYb6ISZIz4yMLxMzMM5kTMO3YDONwATNM9VDMNisHLe6ICeIz4CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeucjONyIzMMzMTMM0AzMM5kzMO1cTONiwSNL6IieI54yML2YjMNwgDOOzEDMM5QjMN2kTOOkJCLI0NXacj5WYb6ISZI34iMLxMzMM5kTMO3YDONwATNM2UDMN7xSfLignIeuQjON4YzMNxQTMN3YDON5kzNOzkTOO5JCLI3ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwSNL6IieI54yML2YDONwgDOOzEDMM5QjMN3kTOOkJCLI0NXacj5WYb6ISZIx4iMLxMzMM5kTMO3YDONwATNM9ZDMNisHLe6ICeIz4CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeugjOOyITNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIO0AjLM4YjNNwADOMyMTMM5kDNOiwSOLzlGZauFGdYiU2YZuEjOMzMTNM5ETMM2gTOOwUzNN1ADMMs0HNf4JyeI0ojIO2MjLM0EDOM2gTMO5czNN5kTOOiwyML6ISeIx4SOLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjON2ATMM4gjNOxADMM1IzMMkJCLI0NXacj5WYb6ISZI54CMLxMzMM5kTMO3YDONwATNM3UDMN7xSfLignIeuQjON4YTONxQTMN3YDON5kzNOzkTOO5JCLIwojIOycjLNzEjMMwMzMM5MDNM3kTOOscjNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIO9hjLOisHLe6ICeI54CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuQjON4YTONxQTMN3YDON5kzNOzkTOO5JCLIxojIOykjLOzEjMMwMzMM5MDNM3kTOOskjNOionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeI54CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuQjON4YTONxQTMN3YDON5kzNOzkTOO5JCLIzojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yMLiwCOLzlGZauFGdYiU2YZuMjOMwAjMMwADMMwADMMwADMMwADMMs0nNf4JyeI0ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMwIDOMwADMMwADMMwADMMwADMMiwyMLzlGZauFGdYiU2YZuMjOMwADOMwADMMwADMMwADMMwADMMs03Nf4JyeI0ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMwYzNNwADMMwADMMwADMMwADMMiwiMLzlGZauFGdYiU2YZuQjONs0HNf4JyeI0ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeI54CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMiwyNLzlGZauFGdYiU2YZ9VjONisHLe6ICeI54CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuUjONyITNMzMTMM0AzMM5kzMO2cTONiwSNL6IieI34yML2YDNNwgDOOzEDMM5QjMN1kTOOkJCLI0NXacj5WYb6ISZI14CNLxMzMM5kTMO3YDONwATNM1QDMN7xSfLignIeuQjON4YTONxQTMN3YDON5kzNOzkTOO5JCLI2ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwiNL6IieI44yML2YDMNwgDOOzEDMM5QjMN1kTOOkJCLI0NXacj5WYb6ISZI54yMLxMzMM5kTMO3YDONwATNM9VDMNisHLe6ICeI54CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeuYjONyIzNMzMTMM0AzMM5kzMO2cTON6JCLIzojIO2gjLO4YjNNwADOMyMTMM5kDNOsYTONpRmIZhR3cdlNmbYzojIOzMjLMxEzMM4kTOO1cjNNwADMMs0XNf4JyeI0ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeIz4yNLxIjMMzMzMMzQDMN5kTOO1UzNN6JCLIzojIOykjLO4YjNNwADOMyMTMM5kDNOsYTONpRmIZhR3cdlNmbYyojIOzcjLNxEzMM4kTOO1cjNNwADMM9ZTNNisHLe6ICeI54CNLxgjNO4EDNM3cjNN5kTOOsMTOMiknIeucjONyITOMzMTMM0AzMM5kzMO1cTON6JCLIzojIO4kjLO4YjNNwADOMyMTMM5kDNOscTONpRmIZhR3cdlNmbYyojIOzEjLMxEzMM4kTOO1cjNNwADMMs0nNf4JyeI0ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwyML6ISeI14COLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuQjON2QDMN4gjNOxADMM0IzMM5kTOOkJCLI0NXacj5WYb6ISZI14SMLxMzMM5kTMO3YDONwATNM0UDMN7xSfLignIeuQjON4YTONxQTMN3YDON5kzNOzkTOO5JCLI5ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwSNL6IieIx4CNL2YDMNwgDOOzEDMMsUjMNpRmIZhR3cdlNmbYwojIOzkjLOxEzMM4kTOO1cjNNwADMM9dTNNisHLe6ICeI14SNLxgjNO4EDNM3cjNN5kTOO1ITOM5JCLIwojIOycjLNzEjMMwMzMM5MDNM3kTOOscjNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIO9hjLOisHLe6ICeI14SNLxgjNO4EDNM3cjNN5kTOO1ITOM5JCLIxojIOyMjLMzEjMMwMzMM5MDNM3kTOOsgjNOionIeuQjONwYDMNwADMMwADMMwADMMwADMMiwSNLzlGZauFGdYiU2YZuEjOMwADNMwADMMwADMMwADMMwADMMs0XMf4JyeI1ojIO2UjLN0EDOM2gTMO5czNN5kTOOsUjMNiknIeuEjOMyITOMzMTMM0AzMM5kzMO2cTONiwSOL6IieIiwCNLzlGZauFGdYiU2YZuIjOMwADMMwADMMwADMMwADMMwADMMs0HNf4JyeI1ojIO2UjLN0EDOM2gTMO5czNN5kTOOsUjMNiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuUjON4YTNNxQTMN3YDON5kzNOykTOOiwSNL6ISeIx4yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMsgDOOpRmIZhR3cdlNmbYzojIOwIjLMwADMMwADMMwADMMwADMM9ZDMNisHLe6ICeI14SNLxgjNO4EDNM3cjNN5kTOO1ITOM5JCLIzojIOycjLNzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yMLwAjMMwADMMwADMMwADMMzADMMkJCLI0NXacj5WYb6ISZI44yMLwADMMwADMMwADMMwADMM3ADMM7xSfLignIeuUjON4YTNNxQTMN3YDON5kzNOykTOOiwSNL6ISeIz4CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMwYzNNwADMMwADMMwADMMwADMMiwiMLzlGZauFGdYiU2YZuQjONs0HNf4JyeI1ojIO2UjLN0EDOM2gTMO5czNN5kTOOsUjMNiknIeuQjONyITOMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0cjLN2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZI14CNLzATMM5gDNO2AzMMwADMM9NDMMisHLe6ICeI14SNLxgjNO4EDNM3cjNN5kTOO1ITOM5JCLI1ojIOyUjLNzEjMMwMzMM5MDNM3kTOOsUjNNionIeuMjOM4QzNN1YTON2ATMMsQTONpRmIZhR3cdlNmbY0ojIOxUjLN0MDMMzkDOOwYDMNwADMMs03Mf4JyeI1ojIO2UjLN0EDOM2gTMO5czNN5kTOOsUjMNiknIeuYjONyITMMzMTMM0AzMM5kzMO2cTON6JCLIzojIOwgjLO4YjNNwADOMyMTMM5kDNOsUTONpRmIZhR3cdlNmbYzojIOzkjLOxEzMM4kTOO1cjNNwADMMs0XNf4JyeI1ojIO2UjLN0EDOM2gTMO5czNN5kTOOsUjMNiknIeuYjONyIzNMzMTMM0AzMM5kzMO2cTON6JCLIzojIO2gjLO4YjNNwADOMyMTMM5kDNOsYTONpRmIZhR3cdlNmbYzojIOzMjLMxEzMM4kTOO1cjNNwADMMs0XNf4JyeI1ojIO2UjLN0EDOM2gTMO5czNN5kTOOsUjMNiknIeucjONyIzMMzMTMM0AzMM5kzMO1cTONiwSNL6IieI54yML2YjMNwgDOOzEDMM5QjMN2kTOOkJCLI0NXacj5WYb6ISZI34iMLxMzMM5kTMO3YDONwATNM2UDMN7xSfLignIeuUjON4YTNNxQTMN3YDON5kzNOykTOOiwSNL6ISeI54yNLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuMjOM2gTOO4gjNOxADMM0IzMM5kTOOiwyNLzlGZauFGdYiU2YZuIjOMzMTMM5ETMM2gTOOwUzNN2ADMM7xSfLignIeuUjON4YTNNxQTMN3YDON5kzNOykTOOiwSNL6ISeI14COLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuQjON2QDMN4gjNOxADMM0IzMM5kTOOkJCLI0NXacj5WYb6ISZI14SMLxMzMM5kTMO3YDONwATNM0UDMN7xSfLignIeuUjON4YTNNxQTMN3YDON5kzNOykTOOiwSNL6ISeIx4SOLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjON2ATMM4gjNOxADMM1IzMMkJCLI0NXacj5WYb6ISZI54CMLxMzMM5kTMO3YDONwATNM3UDMN7xSfLignIeuYjON4YTMNxQTMN3YDON5kzNOykTOO5JCLIwojIOycjLNzEjMMwMzMM5MDNM3kTOOscjNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIO9hjLOisHLe6ICeIx4iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeuYjON4YTMNxQTMN3YDON5kzNOykTOO5JCLIxojIOykjLOzEjMMwMzMM5MDNM3kTOOskjNOionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeIx4iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLIzojIO0kjLOkJCLI0NXacj5WYb6ISZI24iMLwADMMwADMMwADMMwADMM1ADMM7xSfLignIeuYjON4YTMNxQTMN3YDON5kzNOykTOO5JCLIzojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yMLiwCOLzlGZauFGdYiU2YZuMjOMwAjMMwADMMwADMMwADMMwADMMs0nNf4JyeI2ojIO2EjLM0EDOM2gTMO5czNN5kTOOiwiML6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMwIDOMwADMMwADMMwADMMwADMMiwyMLzlGZauFGdYiU2YZuMjOMwADOMwADMMwADMMwADMMwADMMs03Nf4JyeI2ojIO2EjLM0EDOM2gTMO5czNN5kTOOiwiML6ISeIz4CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOM4ADOM1YTON2ATMM5MTOM5kTOOiwyNLzlGZauFGdYiU2YZuMjOMwETOM4QzMNwMTOMwAjNMzADMM7xSfLignIeuYjON4YTMNxQTMN3YDON5kzNOykTOO5JCLI0ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwyNL6IieI44yML5gDMOxUjNN5YDMN5kzMO3kTOOkJCLI0NXacj5WYb6ISZI54yMLzATMM5gDNO2AzMMwADMM9NDMMisHLe6ICeIx4iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuUjONyITNMzMTMM0AzMM5kzMO2cTONiwSNL6IieI44yML5gDMOxUjNN5YDMN5kzMO3kTOOkJCLI0NXacj5WYb6ISZI54yMLzATMM5gDNO2AzMMwADMM9NDMMisHLe6ICeIx4iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuYjONyITMMzMTMM0AzMM5kzMO2cTON6JCLIzojIOwgjLO2kDOOwETNMzkjNO5kTOOscTONpRmIZhR3cdlNmbYzojIOxkjLO0MDMMzkDOOwYDMNwADMMs03Mf4JyeI2ojIO2EjLM0EDOM2gTMO5czNN5kTOOiwiML6ISeI34iNLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuMjOM2YDON4gjNOxADMM0IzMM5kTOOiwiNLzlGZauFGdYiU2YZuMjOMzMzMM5ETMM2gTOOwUzNN1ADMM7xSfLignIeuYjON4YTMNxQTMN3YDON5kzNOykTOO5JCLI3ojIOyMjLMzEjMMwMzMM5MDNM3kTOOsUTNNionIeuMjOM2ITOM4gjNOxADMM0IzMM5kTOOiwiNLzlGZauFGdYiU2YZuIjOMzMzNM5ETMM2gTOOwUzNN1ADMMs0nNf4JyeI2ojIO2EjLM0EDOM2gTMO5czNN5kTOOiwiML6ISeI54yNLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuMjOM2gTOO4gjNOxADMM0IzMM5kTOOiwyNLzlGZauFGdYiU2YZuIjOMzMTMM5ETMM2gTOOwUzNN2ADMM7xSfLignIeuYjON4YTMNxQTMN3YDON5kzNOykTOO5JCLI4ojIOyUjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieIw4CNL2YDNNwgDOOzEDMM5QjMNskTOOpRmIZhR3cdlNmbYxojIOzUjLNxEzMM4kTOO1cjNNwADMM9RTNNisHLe6ICeIx4iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeukjOOyITMMzMTMM0AzMM5kzMO1cTON6JCLI0ojIOwEjLM4YjNNwADOMyMTMMiwSNLzlGZauFGdYiU2YZuAjOMzMTOM5ETMM2gTOOwUzNN1ADMMs03Nf4JyeI2ojIO2cjLN0EDOM2gTMO5czNN5kTOOiwiML6ISeI34CMLxIjMMzMzMMzQDMN5kTOO3YzNN6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CML7xSfLignIeuYjON4YzNNxQTMN3YDON5kzNOykTOO5JCLIxojIOyMjLMzEjMMwMzMM5MDNM3kTOOsgjNOionIeuQjONwYDMNwADMMwADMMwADMMwADMMiwSNLzlGZauFGdYiU2YZuEjOMwADNMwADMMwADMMwADMMwADMMs0XMf4JyeI2ojIO2cjLN0EDOM2gTMO5czNN5kTOOiwiML6ISeI54SMLxIjMMzMzMMzQDMN5kTOO5YzNN6JCLI0ojIOkJCLI0NXacj5WYb6ISZIw4iMLwADMMwADMMwADMMwADMM0ADMM7xSfLignIeuYjON4YzNNxQTMN3YDON5kzNOykTOO5JCLIyojIOyUjLNzEjMMwMzMM5MDNM3kTOOiwyNL6IieI54yMLiwCNLzlGZauFGdYiU2YZuIjOMwAjNMwADMMwADMMwADMMwADMMs0XNf4JyeI2ojIO2cjLN0EDOM2gTMO5czNN5kTOOiwiML6ISeIx4yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMsgDOOpRmIZhR3cdlNmbYzojIOwIjLMwADMMwADMMwADMMwADMM9ZDMNisHLe6ICeI34iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuMjOMyIzNMzMTMM0AzMM5kzMO3cTON6JCLIzojIO2gjLO2kDOOwETNMzkjNO5kTOOscTONpRmIZhR3cdlNmbYzojIOxMjLM0MDMMzkDOOwYDMNwADMM9ZzMNisHLe6ICeI34iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuQjONyIzMMzMTMM0AzMM5kzMO3cTON6JCLIzojIO2gjLO2kDOOwETNMzkjNO5kTOOscTONpRmIZhR3cdlNmbYzojIOxMjLM0MDMMzkDOOwYDMNwADMM9ZzMNisHLe6ICeI34iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuQjONyITOMzMTMM0AzMM5kzMO3cTON6JCLIzojIO2gjLO2kDOOwETNMzkjNO5kTOOscTONpRmIZhR3cdlNmbYzojIOxMjLM0MDMMzkDOOwYDMNwADMM9ZzMNisHLe6ICeI34iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeuUjONyITNMzMTMM0AzMM5kzMO2cTONiwSNL6IieI44yML5gjNOxUjNN5YDMN5kzMO3kTOOkJCLI0NXacj5WYb6ISZIz4yMLzATMM5gDNO2AzMMwADMM2MDMM7xSfLignIeuYjON4YzNNxQTMN3YDON5kzNOykTOO5JCLI2ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwiNL6IieI44yML5gjNOxUjNN5YDMN5kzMO3kTOOkJCLI0NXacj5WYb6ISZIz4yMLzATMM5gDNO2AzMMwADMM2MDMM7xSfLignIeuYjON4YzNNxQTMN3YDON5kzNOykTOO5JCLI2ojIOycjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieI44yML5gjNOxUjNN5YDMN5kzMO3kTOOkJCLI0NXacj5WYb6ISZIz4yMLzATMM5gDNO2AzMMwADMM2MDMM7xSfLignIeuYjON4YzNNxQTMN3YDON5kzNOykTOO5JCLI3ojIOyMjLMzEjMMwMzMM5MDNM3kTOOsUTNNionIeuMjOM2ITOM4gjNOxADMM0IzMM5kTOOiwiNLzlGZauFGdYiU2YZuIjOMzMzNM5ETMM2gTOOwUzNN1ADMMs0nNf4JyeI2ojIO2cjLN0EDOM2gTMO5czNN5kTOOiwiML6ISeI54yNLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuMjOM2gTOO4gjNOxADMM0IzMM5kTOOiwyNLzlGZauFGdYiU2YZuIjOMzMTMM5ETMM2gTOOwUzNN2ADMM7xSfLignIeuYjON4YzNNxQTMN3YDON5kzNOykTOO5JCLI4ojIOyUjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieIw4CNL2YDNNwgDOOzEDMM5QjMNskTOOpRmIZhR3cdlNmbYxojIOzUjLNxEzMM4kTOO1cjNNwADMM9RTNNisHLe6ICeI34iNLxgjNO4EDNM3cjNN5kTOOsITOMiknIeukjOOyITMMzMTMM0AzMM5kzMO1cTON6JCLI0ojIOwEjLM4YjNNwADOMyMTMMiwSNLzlGZauFGdYiU2YZuAjOMzMTOM5ETMM2gTOOwUzNN1ADMMs03Nf4JyeI3ojIO2MjLM0EDOM2gTMO5czNN5kTOOsUTMNiknIeuAjOMyIzNMzMTMM0AzMM5kzMO2cTONiwyNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMs0HOf4JyeI3ojIO2MjLM0EDOM2gTMO5czNN5kTOOsUTMNiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeI54SMLxIjMMzMzMMzQDMN5kTOO5YzNN6JCLI0ojIOkJCLI0NXacj5WYb6ISZIw4iMLwADMMwADMMwADMMwADMM0ADMM7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeI14iMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOMsQTONpRmIZhR3cdlNmbYyojIOwYjLNwADMMwADMMwADMMwADMM9VDMNisHLe6ICeIz4yNLxgjNO4EDNM3cjNN5kTOO1ETOM5JCLIzojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieI54yML5gjMOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwEzNM4QzMNwMTOMwAjNM0ADMM7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOM4ITOM1YTON2ATMMsQTONpRmIZhR3cdlNmbYyojIOxcjLN0MDMMzkDOOwYDMNwADMMs0HNf4JyeI3ojIO2MjLM0EDOM2gTMO5czNN5kTOOsUTMNiknIeuQjONyIzMMzMTMM0AzMM5kzMO3cTON6JCLIzojIOykjLO2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZI34iMLzATMM5gDNO2AzMMwADMM9RDMNisHLe6ICeIz4yNLxgjNO4EDNM3cjNN5kTOO1ETOM5JCLI0ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwyNL6IieI54yML5gjMOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwEzNM4QzMNwMTOMwAjNM0ADMM7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeI14SNLxIjMMzMzMMzQDMN5kTOO1YzNN6JCLIzojIOykjLO2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZI34iMLzATMM5gDNO2AzMMwADMM9RDMNisHLe6ICeIz4yNLxgjNO4EDNM3cjNN5kTOO1ETOM5JCLI2ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwiNL6IieI54yML5gjMOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwEzNM4QzMNwMTOMwAjNM0ADMM7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeI34iNLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuMjOM4ITOM1YTON2ATMMsQTONpRmIZhR3cdlNmbYyojIOxcjLN0MDMMzkDOOwYDMNwADMMs0HNf4JyeI3ojIO2MjLM0EDOM2gTMO5czNN5kTOOsUTMNiknIeucjONyIzMMzMTMM0AzMM5kzMO1cTONiwSNL6IieI54yML5gjMOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwEzNM4QzMNwMTOMwAjNM0ADMM7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeI54yNLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuMjOM2gTOO4gjNOxADMM0IzMM5kTOOiwyNLzlGZauFGdYiU2YZuIjOMzMTMM5ETMM2gTOOwUzNN2ADMM7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeI14COLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuQjON2QDMN4gjNOxADMM0IzMM5kTOOkJCLI0NXacj5WYb6ISZI14SMLxMzMM5kTMO3YDONwATNM0UDMN7xSfLignIeucjON4YzMNxQTMN3YDON5kzNOxkTOOiwSNL6ISeIx4SOLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjON2ATMM4gjNOxADMM1IzMMkJCLI0NXacj5WYb6ISZI54CMLxMzMM5kTMO3YDONwATNM3UDMN7xSfLignIeucjON4YTONxQTMN3YDON5kzNOxkTOO5JCLIwojIOycjLNzEjMMwMzMM5MDNM3kTOOscjNNionIeuQjONsITMMpRmIZhR3cdlNmbYwojIO9hjLOisHLe6ICeI54yNLxgjNO4EDNM3cjNN5kTOOsETOMiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIw4CNLwAjNMwADMMwADMMwADMM1ADMMkJCLI0NXacj5WYb6ISZI04SMLwADMMwADMMwADMMwADMMxADMM7xSfLignIeucjON4YTONxQTMN3YDON5kzNOxkTOO5JCLIxojIOykjLOzEjMMwMzMM5MDNM3kTOOskjNOionIesQjONpRmIZhR3cdlNmbYyojIOwAjLMwADMMwADMMwADMMwADMM9RDMNisHLe6ICeI54yNLxgjNO4EDNM3cjNN5kTOOsETOMiknIeuIjOMyITNMzMTMM0AzMM5kzMO3cTON6JCLIzojIO4kjLO2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZIx4iMLzATMM5gDNO2AzMMwADMMzQDMN7xSfLignIeucjON4YTONxQTMN3YDON5kzNOxkTOO5JCLIzojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieI54yML5gDOOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwETMM4QzMNwMTOMwAjNM0ADMMs03Mf4JyeI3ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwSML6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuMjOM4gTOO1YTON2ATMMsQTONpRmIZhR3cdlNmbYyojIOxEjLM0MDMMzkDOOwYDMNwADMM9NDNMisHLe6ICeI54yNLxgjNO4EDNM3cjNN5kTOOsETOMiknIeuQjONyIzMMzMTMM0AzMM5kzMO3cTON6JCLIzojIO4kjLO2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZIx4iMLzATMM5gDNO2AzMMwADMMzQDMN7xSfLignIeucjON4YTONxQTMN3YDON5kzNOxkTOO5JCLI0ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwyNL6IieI54yML5gDOOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwETMM4QzMNwMTOMwAjNM0ADMMs03Mf4JyeI3ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwSML6ISeI14SNLxIjMMzMzMMzQDMN5kTOO1YzNN6JCLIzojIO4kjLO2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZIx4iMLzATMM5gDNO2AzMMwADMMzQDMN7xSfLignIeucjON4YTONxQTMN3YDON5kzNOxkTOO5JCLI2ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwiNL6IieI54yML5gDOOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwETMM4QzMNwMTOMwAjNM0ADMMs03Mf4JyeI3ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwSML6ISeI34iNLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuMjOM4gTOO1YTON2ATMMsQTONpRmIZhR3cdlNmbYyojIOxEjLM0MDMMzkDOOwYDMNwADMM9NDNMisHLe6ICeI54yNLxgjNO4EDNM3cjNN5kTOOsETOMiknIeucjONyIzMMzMTMM0AzMM5kzMO1cTONiwSNL6IieI54yML5gDOOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuIjOMwETMM4QzMNwMTOMwAjNM0ADMMs03Mf4JyeI3ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwSML6ISeI54yNLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuMjOM4gTOO1YTON2ATMMsQTONpRmIZhR3cdlNmbYyojIOxEjLM0MDMMzkDOOwYDMNwADMM9NDNMisHLe6ICeI54yNLxgjNO4EDNM3cjNN5kTOOsETOMiknIeugjOOyITNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIO0AjLM4YjNNwADOMyMTMM5kDNOiwSOLzlGZauFGdYiU2YZuEjOMzMTNM5ETMM2gTOOwUzNN1ADMMs0HNf4JyeI3ojIO2kjLO0EDOM2gTMO5czNN5kTOOiwSML6ISeIx4SOLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjON2ATMM4gjNOxADMM1IzMMkJCLI0NXacj5WYb6ISZI54CMLxMzMM5kTMO3YDONwATNM3UDMN7xSfLignIeugjOO4YTNNxQTMN3YDON5kzNOskTOOiknIeuAjOMyIzNMzMTMM0AzMM5kzMO2cTONiwyNL6IieIx4CNLiwiMLzlGZauFGdYiU2YZuAjOMs0HOf4JyeI4ojIO2UjLN0EDOM2gTMO5czNN5kTOO5JCLIxojIOyMjLMzEjMMwMzMM5MDNM3kTOOsgjNOionIeuQjONwYDMNwADMMwADMMwADMMwADMMiwSNLzlGZauFGdYiU2YZuEjOMwADNMwADMMwADMMwADMMwADMMs0XMf4JyeI4ojIO2UjLN0EDOM2gTMO5czNN5kTOO5JCLIxojIOykjLOzEjMMwMzMM5MDNM3kTOOskjNOionIeuQjON4QDMN1YTON2ATMMsQTONpRmIZhR3cdlNmbYxojIOxUjLN0MDMMzkDOOwYDMNwADMM9ZDNNisHLe6ICeI14COLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeI14iMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjON4QDMN1YTON2ATMMsQTONpRmIZhR3cdlNmbYxojIOxUjLN0MDMMzkDOOwYDMNwADMM9ZDNNisHLe6ICeI14COLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeIx4yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjON4QDMN1YTON2ATMMsQTONpRmIZhR3cdlNmbYxojIOxUjLN0MDMMzkDOOwYDMNwADMM9ZDNNisHLe6ICeI14COLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeI34yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjON4QDMN1YTON2ATMMsQTONpRmIZhR3cdlNmbYxojIOxUjLN0MDMMzkDOOwYDMNwADMM9ZDNNisHLe6ICeI14COLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeIz4CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjON4QDMN1YTON2ATMMsQTONpRmIZhR3cdlNmbYxojIOxUjLN0MDMMzkDOOwYDMNwADMM9ZDNNisHLe6ICeI14COLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeI54CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjON4QDMN1YTON2ATMMsQTONpRmIZhR3cdlNmbYxojIOxUjLN0MDMMzkDOOwYDMNwADMM9ZDNNisHLe6ICeI14COLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeI14SNLxIjMMzMzMMzQDMN5kTOO1YzNN6JCLI0ojIO0AjLM2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZI14SMLzATMM5gDNO2AzMMwADMM2QDMN7xSfLignIeugjOO4YTNNxQTMN3YDON5kzNOskTOOiknIeuYjONyITMMzMTMM0AzMM5kzMO2cTON6JCLI0ojIO0AjLM2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZI14SMLzATMM5gDNO2AzMMwADMM2QDMN7xSfLignIeugjOO4YTNNxQTMN3YDON5kzNOskTOOiknIeuYjONyIzNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIO0AjLM2kDOOwETNM0kjNOkJCLI0NXacj5WYb6ISZI14SMLzATMM5gDNO2AzMMwADMM2QDMN7xSfLignIeugjOO4YTNNxQTMN3YDON5kzNOskTOOiknIeucjONyIzMMzMTMM0AzMM5kzMO1cTONiwSNL6IieIw4CNL5gDNOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuEjOMwETNM4QzMNwMTOMwAjNM0ADMMs0nNf4JyeI4ojIO2UjLN0EDOM2gTMO5czNN5kTOO5JCLI3ojIOykjLOzEjMMwMzMM5MDNM3kTOOiwSNL6IieIw4CNL5gDNOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuEjOMwETNM4QzMNwMTOMwAjNM0ADMMs0nNf4JyeI4ojIO2UjLN0EDOM2gTMO5czNN5kTOO5JCLI4ojIOyUjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieIw4CNL5gDNOxUjNN5YDMNiwCNLzlGZauFGdYiU2YZuEjOMwETNM4QzMNwMTOMwAjNM0ADMMs0nNf4JyeI4ojIO2UjLN0EDOM2gTMO5czNN5kTOO5JCLI5ojIOyEjLMzEjMMwMzMM5MDNM3kTOOiwSNL6IieIx4CNL2YDMNwgDOOzEDMMsUjMNpRmIZhR3cdlNmbYwojIOzkjLOxEzMM4kTOO1cjNNwADMM9dTNNisHLe6ICeIx4SOLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeI34CMLxIjMMzMzMMzQDMN5kTOO3YzNN6JCLI0ojIOyEjLMkJCLI0NXacj5WYb6ISZI44CML7xSfLignIeukjOO4YTMNxQTMN3YDON5kzNOskTOOiknIeuEjOMyIzMMzMTMM0AzMM5kzMO2cTONiwCOL6IieIx4CNL5gDMOxUjNN5YDMN5kzMO1kTOOkJCLI0NXacj5WYb6ISZI54CMLzATMM5gDNO2AzMMwADMM9VDMNisHLe6ICeIx4SOLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeI54SMLxIjMMzMzMMzQDMN5kTOO5YzNN6JCLI0ojIOwEjLM2kDOOwETNMzkjNO5kTOOsUTONpRmIZhR3cdlNmbYwojIOxkjLO0MDMMzkDOOwYDMNwADMMs0XNf4JyeI5ojIO2EjLM0EDOM2gTMO5czNN5kTOO5JCLIyojIOyUjLNzEjMMwMzMM5MDNM3kTOOiwyNL6IieIx4CNL5gDMOxUjNN5YDMN5kzMO1kTOOkJCLI0NXacj5WYb6ISZI54CMLzATMM5gDNO2AzMMwADMM9VDMNisHLe6ICeIx4SOLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeIx4yMLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjON4ATMM1YTON2ATMM5MTOM5kTOOiwSNLzlGZauFGdYiU2YZuAjOMwETOM4QzMNwMTOMwAjNM1ADMM7xSfLignIeukjOO4YTMNxQTMN3YDON5kzNOskTOOiknIeuMjOMyIzNMzMTMM0AzMM5kzMO3cTON6JCLI0ojIOwEjLM2kDOOwETNMzkjNO5kTOOsUTONpRmIZhR3cdlNmbYwojIOxkjLO0MDMMzkDOOwYDMNwADMMs0XNf4JyeI5ojIO2EjLM0EDOM2gTMO5czNN5kTOO5JCLI0ojIOyMjLMzEjMMwMzMM5MDNM3kTOOiwyNL6IieIx4CNL5gDMOxUjNN5YDMN5kzMO1kTOOkJCLI0NXacj5WYb6ISZI54CMLzATMM5gDNO2AzMMwADMM9VDMNisHLe6ICeIx4SOLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeI54CNLxIjMMzMzMMzQDMN5kTOOsczNNionIeuQjON4ATMM1YTON2ATMM5MTOM5kTOOiwSNLzlGZauFGdYiU2YZuAjOMwETOM4QzMNwMTOMwAjNM1ADMM7xSfLignIeukjOO4YTMNxQTMN3YDON5kzNOskTOOiknIeuUjONyITNMzMTMM0AzMM5kzMO2cTONiwSNL6IieIx4CNL5gDMOxUjNN5YDMN5kzMO1kTOOkJCLI0NXacj5WYb6ISZI54CMLzATMM5gDNO2AzMMwADMM9VDMNisHLe6ICeIx4SOLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeIx4iNLxIjMMzMzMMzQDMN5kTOOsYzNNionIeuQjON4ATMM1YTON2ATMM5MTOM5kTOOiwSNLzlGZauFGdYiU2YZuAjOMwETOM4QzMNwMTOMwAjNM1ADMM7xSfLignIeukjOO4YTMNxQTMN3YDON5kzNOskTOOiknIeuYjONyIzNMzMTMM0AzMM5kzMO2cTON6JCLI0ojIOwEjLM2kDOOwETNMzkjNO5kTOOsUTONpRmIZhR3cdlNmbYwojIOxkjLO0MDMMzkDOOwYDMNwADMMs0XNf4JyeI5ojIO2EjLM0EDOM2gTMO5czNN5kTOO5JCLI3ojIOyMjLMzEjMMwMzMM5MDNM3kTOOsUTNNionIeuQjON4ATMM1YTON2ATMM5MTOM5kTOOiwSNLzlGZauFGdYiU2YZuAjOMwETOM4QzMNwMTOMwAjNM1ADMM7xSfLignIeukjOO4YTMNxQTMN3YDON5kzNOskTOOiknIeucjONyITOMzMTMM0AzMM5kzMO1cTON6JCLI0ojIOwEjLM2kDOOwETNMzkjNO5kTOOsUTONpRmIZhR3cdlNmbYwojIOxkjLO0MDMMzkDOOwYDMNwADMMs0XNf4JyeI5ojIO2EjLM0EDOM2gTMO5czNN5kTOO5JCLI4ojIOyUjLNzEjMMwMzMM5MDNM3kTOOiwiNL6IieIx4CNL5gDMOxUjNN5YDMN5kzMO1kTOOkJCLI0NXacj5WYb6ISZI54CMLzATMM5gDNO2AzMMwADMM9VDMNisHLe6ICeIx4SOLxgjNO4EDNM3cjNN5kTOOiwSOL6ISeIx4SOLxIjMMzMzMMzQDMN5kTOOsUzNNionIeuQjON4ATMM1YTON2ATMM5MTOM5kTOOiwSNLzlGZauFGdYiU2YZuAjOMwETOM4QzMNwMTOMwAjNM1ADMM91VfX"
        }
   var design= JSON.parse(api.getBase64.d(content.design));
   design.design.forEach(function (d) {
        if(d.type=="PRODUCT"){
            d.pid=productObj.id
            d.category="custom_furniture";
        }
       /* if(d.id=="cameraPerson"){
            var near=0.01;
            d.znear=near;
            var pich=-Math.atan2(cam.position.y, Math.sqrt(cam.position.x * cam.position.x + cam.position.z * cam.position.z))* 180 / Math.PI;
                d.pitch=pich
                d.x=cam.position.x;
                d.y=-cam.position.z;
                d.z=cam.position.y
                d.tx=0,d.ty=0;
        }*/
       if(d.id=="cameraPerson"){
           var near=0.01;
           d.znear=near;
           var pich=-Math.atan2(cam.position.y, Math.sqrt((cam.position.x-5.02355099923447)* (cam.position.x-5.02355099923447) + (cam.position.z+4.988736845513668) * (cam.position.z+4.988736845513668)))* 180 / Math.PI;
           d.pitch=pich
           d.x=cam.position.x;
           d.y=-cam.position.z;
           d.z=cam.position.y;
           d.hfov=80;
           d.tx=5.02355099923447,d.ty=4.988736845513668;
       }
    })
    content.design=api.getBase64.e(JSON.stringify(design));
    content=JSON.stringify(content);
    var room = roomObj;
    var option = JSON.stringify(options);
    var jobid = api.uuid();

    var designMeta = ui.getOpenedDesignMeta();
    var jobuserloginid = "";
    var designid = "";
    if (designMeta) {
        jobuserloginid = designMeta.userLoginId;
        designid = "";
    }
    api.getServiceJSONResponsePromise({
        type: 'post',
        url: url,
        cache: false,
        data: {design: content, room: room, option: option, jobid: jobid, jobuserloginid: jobuserloginid, designid: designid}
    }).then(function (res) {
        if (res.error == 0) {
            var jobid = res.jobid;
            renderview_jobid_time_interval_Map.put(jobid, createInternalTime().toString());
            renderview_jobid_time_interval_Array.push(jobid);
            log('send render request to server success, jobid=' + jobid);
            if (successCB)successCB({jobid: jobid, evaluateRenderTime: res.evaluateRenderTime});
        } else {
            alert('render server returns failed!! ' + jobid);
        }
    }).catch(function (e) {
        layer.alert('send render request to server failed!! ', {
            closeBtn: 0,
            skin: 'layui-layer-default'
        });
    });
};


//# sourceURL=ui\dialog/render/render.js