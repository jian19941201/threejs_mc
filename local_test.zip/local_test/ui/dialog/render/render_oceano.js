//# sourceURL=ui\dialog/render/render_oceano.js

var oceano_default_option = {
    engine: "CUDA",
    watermark: "oceano",
    lighting: "auto",
    light_multiplier: 1.0,
    camera: "cameraPerson"
};
/*渲染当前设计需要积分数*/
var render_design_current_points = 0;

/*设置积分制*/
function setCurrentPoints(points) {
    $("#renderPanel_oceano .current_points").text(points);
    render_design_current_points = points;
}

$(".renderPanel_oceano").dialog({
    width: 538,
    autoOpen: false,
    resizable: true,
    modal: false
})
    .on("dialogclose", function (event, ui) {
        render_fitPreview3d(true);
    }).on("dialogopen", function (event, ui) {
        var camera = api.documentGetActiveCamera();
        var fov = camera.hfov;
        $(".renderPanel_oceano .slider-camera-fov-move").slider("value", fov);
        $(".renderPanel_oceano .slider-camera-fov-text").val(fov);

        var z = camera.z;
        $(".renderPanel_oceano .slider-camera-height-move").slider("value", z);
        $(".renderPanel_oceano .slider-camera-height-text").val(z);

        var pitch = camera.pitch;
        if (pitch < 0) {
            pitch = -Math.ceil(Math.abs(pitch));
        } else {
            pitch = Math.ceil(pitch);
        }
        $(".renderPanel_oceano .slider-camera-pitch-move").slider("value", pitch);
        $(".renderPanel_oceano .slider-camera-pitch-text").val(pitch);

        // fit 3d:
        init_editor3d_size();

        // select which camera
        var camera_select = $("#renderPanel_oceano .camera_select").empty();
        var cameras = api.floorplanFilterEntity(function (e) {
            return e.type == "CAMERA";
        });
        for (var i = 0; i < cameras.length; ++i) {
            var camera = cameras[i];
            var cameraElement = $("<option>").attr({
                value: camera.id
            }).html(camera.name).appendTo(camera_select);
        }
        camera_select.val(api.documentGetActiveCamera().id);

        // fit:
        render_fitPreview3d();

        $(".renderPanel_oceano").tooltip();

        var $render_fee_info = $("#renderPanel_oceano .render_fee_info");
        if (appSettings.renderfee == 'true') {
            $render_fee_info.show();
            initUserTotalPoints();
            $("#renderPanel_oceano .recharge_points").on("click", function (e) {
                window.open(appSettings.designjavadomain + '/recharge');
            });
        } else {
            $render_fee_info.hide();
        }
    });

function init_editor3d_size() {
    // fit 3d:
    view2DActiveHandler();
    var domElement = document.getElementById("paper3d");
    var domClientRects = domElement.getClientRects();
    editor3d_size = domClientRects.length > 0 ? domClientRects[0] : {width: 300, height: 200};
}

/*初始化用户积分余额*/
function initUserTotalPoints() {
    $.ajax({
        type: 'post',
        url: appSettings.designjavadomain + '/control/getUserRechargeDetail',
        cache: false,
        data: {}
    }).done(function (data) {
        $("#renderPanel_oceano .total_points").text(data.points);
        if (data.points > 0) {
            $("#renderPanel_oceano .recharge_points").hide();
        } else {
            $("#renderPanel_oceano .recharge_points").show();
        }

    }).fail(function () {

    });
}

var editor3d_size;

/*渲染图像大小信息*/
var RENDER_IMAGE_SIZE_INFO = {
    /*宽，高，积分值*/
    low: [800, 600, 0],
    mid: [1280, 960, 3],
    high: [2048, 1536, 5],
    super_high: [4096, 3072, 10],
    super_high_add_01: [2000, 1000, 13],
    super_high_add_02: [6000, 3000, 15],
    custom: [0, 0, 8],
    panorama: [0, 0, 15],
    image: [0, 0, 0]
};

// 获取图像大小
function render_getRenderSize() {
    // size_txt为不同尺寸图像大小的value值。包括"low"、"mid"、"hign"、"super_high"、super_high_add_01、super_high_add_02、"custom"这7种情况
    var size_txt = $("#renderPanel_oceano .size_precision_select").attr("value");
    if (size_txt == "custom") {
        var width = $("#renderPanel_oceano .custom_size .widthInput").val();
        var ratio = $("#renderPanel_oceano .custom_size .ratioInput").val();
        return {
            width: parseInt(width),
            height: parseInt(width) / parseFloat(ratio)
        };
    }

    var quality = size_txt;
    var width = RENDER_IMAGE_SIZE_INFO[quality][0], height = RENDER_IMAGE_SIZE_INFO[quality][1];


    // 方向设置：默认情况下是横向，如果改成竖向的话则互换图像大小的长、宽值
    var direction = $("#renderPanel_oceano .direction_select input[name='orientation']:checked").val();
    if (direction == 'direction_x') {
        $(".image_size .size_precision_select div:eq(0) p:eq(1)").text("800x600");
        $(".image_size .size_precision_select div:eq(1) p:eq(1)").text("1280x960");
        $(".image_size .size_precision_select div:eq(2) p:eq(1)").text("2048x1536");
        $(".image_size .size_precision_select div:eq(3) p:eq(1)").text("4096x3072");
        return {width: width, height: height};
    }

    if (direction == 'direction_y') {
        $(".image_size .size_precision_select div:eq(0) p:eq(1)").text("600x800");
        $(".image_size .size_precision_select div:eq(1) p:eq(1)").text("960x1280");
        $(".image_size .size_precision_select div:eq(2) p:eq(1)").text("1536x2048");
        $(".image_size .size_precision_select div:eq(3) p:eq(1)").text("3072x4096");
        if(quality=="super_high_add_01"||quality=="super_high_add_02"){
            return {width: width, height: height};
        }else {
            return {width: height, height: width};
        }
    }
}

// 自定义图像大小之后，改变3D预览视图的大小（即右下角的“视图预览”窗口）
function render_fitPreview3d(isResume) {

    //改变大小比例时，按宽度不变自动计算出高度。--   gaoning 2017.2.28
    var ratioInputVal=$("#ratioInput").val()*1;  // ratioInputVal是宽高比
    var heightVal=$("#inputWidth").val()*1/ratioInputVal;
    $("#inputHeight").val( parseInt(heightVal) );

    var expectedSize;
    if (isResume == true) {
        expectedSize = {width: editor3d_size.width, height: editor3d_size.height};
    } else {
        var size = Math.max(editor3d_size.width, editor3d_size.height);
        expectedSize = {width: size, height: size};
        var realSize = render_getRenderSize();
        if (realSize.width > realSize.height) {
            expectedSize.height = Math.round(expectedSize.width * realSize.height / realSize.width);
        } else {
            expectedSize.width = Math.round(expectedSize.height * realSize.width / realSize.height);
        }
    }
    $("#paper3d").css(expectedSize);
    api.getViewById("3d").fit(expectedSize);
}

/*toolBar设置3D“视图预览”界面的高度*/
$(".renderPanel_oceano .slider-camera-height-move").
    slider({min: 0.2, max: 8, step: 0.02})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "m"})
    .on("slidestop", function (e, ui) {
        $(".renderPanel_oceano .slider-camera-height-text").val(ui.value);
    }).on("slide", function (e, ui) {
        var camera = api.documentGetActiveCamera();
        camera.z = parseFloat(ui.value);
    });

/*input框设置3D“视图预览”界面的高度*/
$(".renderPanel_oceano .slider-camera-height-text").bind("keypress", function (event) {
    /*回车键*/
    if (event.keyCode == 13) {
        /*正浮点数*/
        var positive_float = /^(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/;
        if (!positive_float.test($(this).val())) return false;
        var camera = api.documentGetActiveCamera();
        camera.z = parseFloat($(this).val());
        $(this).select();
        $(".renderPanel_oceano .slider-camera-height-move").slider("value", $(this).val());
        return false;
    }
});

/*toolBar设置3D“视图预览”界面的俯仰角度*/
$(".renderPanel_oceano .slider-camera-pitch-move").
    slider({min: -75, max: 75, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "度"})
    .on("slidestop", function (e, ui) {
        $(".renderPanel_oceano .slider-camera-pitch-text").val(ui.value);
    }).on("slide", function (e, ui) {
        var camera = api.documentGetActiveCamera();
        camera.pitch = parseFloat(ui.value);
    });

/*input框设置3D“视图预览”界面的俯仰角度*/
$(".renderPanel_oceano .slider-camera-pitch-text").bind("keypress", function (event) {
    /*回车键*/
    if (event.keyCode == 13) {
        /*整数*/
        var positive_int = /^-?\d+$/;
        if (!positive_int.test($(this).val())) return false;
        var camera = api.documentGetActiveCamera();
        camera.pitch = parseFloat($(this).val());
        $(this).select();
        $(".renderPanel_oceano .slider-camera-pitch-move").slider("value", $(this).val());
        return false;
    }
});

/*视野：toolBar设置3D“视图预览”界面的视野*/
$(".renderPanel_oceano .slider-camera-fov-move").
    slider({min: 15, max: 120, step: 1})
    .slider("pips", {
        first: false,
        last: false,
        rest: false
    }).slider("float", {suffix: "度"})
    .on("slidestop", function (e, ui) {
        $(".renderPanel_oceano .slider-camera-fov-text").val(ui.value);
    }).on("slide", function (e, ui) {
        var camera = api.documentGetActiveCamera();
        camera.hfov = parseFloat(ui.value);
    });

/*视野：文本框设置3D“视图预览”界面的视野*/
$(".renderPanel_oceano .slider-camera-fov-text").bind("keypress", function (event) {
    /*回车键*/
    if (event.keyCode == 13) {
        /*整数*/
        var positive_int = /^\d+$/;
        if (!positive_int.test($(this).val())) return false;
        var camera = api.documentGetActiveCamera();
        camera.hfov = parseFloat($(this).val());
        $(this).select();
        $(".renderPanel_oceano .slider-camera-fov-move").slider("value", $(this).val());
        return false;
    }
});

// 更换摄像机
$("#renderPanel_oceano .camera_select").on("change", function () {
    var selectCameraId = $(this).val();
    api.documentSetActiveCameras([selectCameraId]);

    // select another camera, update UI.
    var camera = api.documentGetActiveCamera();
    $(".renderPanel_oceano .slider-camera-fov-text").val(camera.hfov);
    $(".renderPanel_oceano .slider-camera-fov-move").slider("value", camera.hfov);
    $(".renderPanel_oceano .slider-camera-pitch-text").val(camera.pitch);
    $(".renderPanel_oceano .slider-camera-pitch-move").slider("value", camera.pitch);
    $(".renderPanel_oceano .slider-camera-height-text").val(camera.z);
    $(".renderPanel_oceano .slider-camera-height-move").slider("value", camera.z);

});

/*图像大小选择*/

//add by   gaoning 2016.12.9 start
/*输入宽度值，自动计算高度值*/
$("#inputWidth").on("keyup", function () {
    var ratioInputVal=$("#ratioInput").val()*1;
    var heightVal=$(this).val()*1/ratioInputVal;
    $("#inputHeight").val( parseInt(heightVal) );
});

/*输入高度值，自动计算宽度值*/
$("#inputHeight").on("keyup", function () {
    var ratioInputVal=$("#ratioInput").val()*1;
    var widthVal=$(this).val()*1*ratioInputVal;
    $("#inputWidth").val( parseInt(widthVal) );
});
//add by   gaoning 2016.12.9 end

/*类型：效果图|VR全景图*/
$("#renderPanel_oceano input[name='rendertype']").on("click", function () {
    //$(this).val()等于“panorama”或者“image”。panorama表示VR全景图，image表示普通效果图
    setCurrentPoints(RENDER_IMAGE_SIZE_INFO[$(this).val()][2]);

    //add by   gaoning 2016.8.17
    //选择VR全景图时，检查相机是否在房间内
    if($(this).val()=="panorama"){

        var cameraPos = new vector2();  // vector2()是声明坐标结构的
        var curCamera = api.floorplanFilterEntity(function(e)
        {
            return e.type=="CAMERA";
        });
        for(var i= 0;i < curCamera.length;i ++)
        {
            if(curCamera[i].active == true)
            {
                //得到相机的三维坐标
                cameraPos.x = curCamera[i].x;
                cameraPos.y = curCamera[i].y;
            }
        }
        var roomsPos = new Array();
        var index = 0;
        var isCameraInroom = false;
        var rooms = api.floorplanFilterEntity(function(e){return e.type=="FLOOR";});
        for(var i = 0; i < rooms.length;i ++)
        {
            index = 0;
            for(var r =0;r < rooms[i].getLoop().length; r ++)
            {
                var pos = new vector2();
                pos.x = rooms[i].getLoop()[r].x;
                pos.y = rooms[i].getLoop()[r].y;
                roomsPos[index] = pos;
                index ++;
            }
            var check = checkPointInPolygon(cameraPos,roomsPos);
            if(check == true)
                isCameraInroom = true;
        }
        if(isCameraInroom == false) {
            layer.alert("相机不在房间内，请调整好相机的位置！", {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        }
    };

    /*当类型选择是【VR全景图】时，图像下拉框设置成预览大小，勾选增强品质*/
    if ($(this).val() == 'panorama') {
        $("#renderPanel_oceano input[name='render_quality_advanced']").attr("checked", true);
    }
});
//声明坐标结构
function vector2() {
    this.x = 0;
    this.y = 0;
}


/*增强品质 勾选事件*/
$("#renderPanel_oceano input[name='render_quality_advanced']").on("click", function () {
    if ($(this).is(":checked")) {
        /*勾选【增强品质】后，按照图像对象对应的积分翻倍*/
        var size_txt = $("#renderPanel_oceano .size_precision_select").val();
        setCurrentPoints(RENDER_IMAGE_SIZE_INFO[size_txt][2] * 2); // 图像积分乘以2（翻倍）
    }
});

// 自定义大小的长宽比。用插件实现的
$("#renderPanel_oceano .custom_size .ratioInput").on("change", render_fitPreview3d);
// $("#renderPanel_oceano .custom_size .ratioInput").spinner({
//     step: 0.1,
//     min: 0.1,
//     max: 10
// }).on("spinstop", render_fitPreview3d);

// direction_select是一个div。为什么会有change事件？ 是否已经修改需求？
$("#renderPanel_oceano .direction_select").on("change", render_fitPreview3d);

// 布光规则（显示、隐藏）
$("#renderPanel_oceano .lighting_select").on("change", function () {
    if ($(this).val() == "auto") {
        $("#renderPanel_oceano .multiplier").hide();
    } else {
        $("#renderPanel_oceano .multiplier").show();
    }
});

// 关闭整个“渲染设置”对话框
$("#renderPanel_oceano .footer .cancel").on(click, function () {
    $("#renderPanel_oceano").dialog("close");
});

/*渲染按钮事件*/
$("#renderPanel_oceano .footer .ok").on(click, function () {
    if (appSettings.renderfee === 'true') {
        if (render_design_current_points == 0) {
            start_render();
            return;
        }
        $.ajax({
            type: 'post',
            url: appSettings.designjavadomain + '/control/ajaxUserRenderSpendPoints',
            cache: false,
            data: {"points": render_design_current_points}
        }).done(function (data) {
            var resultInfoMap = data.resultInfoMap;
            if (resultInfoMap) {
                if (resultInfoMap.status === 'spend_success') {
                    start_render();
                } else if (resultInfoMap.status === 'spend_error') {
                    error_info("网络异常，请稍后再试~");
                } else if (resultInfoMap.status === 'no_enough_money') {
                    error_info("账户余额不足，请充值后再试~");
                } else if (resultInfoMap.status === 'user_is_null') {
                    error_info("用户未登录，请登录后再试~");
                }
            } else {
                error_info("网络异常，请稍后再试~");
            }

        }).fail(function () {
            error_info("网络异常，请稍后再试~");
        });

        // 渲染异常弹出对话框
        function error_info(msg) {
            layer.alert(msg, {
                closeBtn: 0,
                skin: 'layui-layer-default'
            }, function (idx) {
                layer.close(idx);
            });
        }

    } else {
        start_render();
    }
});

// 重点关注“渲染函数”。里面执行了我们刚刚配置的诸多信息
function start_render() {
    // 第一步：设置渲染时间间隔限制[30秒]
    if (renderview_jobid_time_interval_Array.length > 0) {
        var lastjobid = renderview_jobid_time_interval_Array[renderview_jobid_time_interval_Array.length - 1];
        var jobjcreatetime = renderview_jobid_time_interval_Map.get(lastjobid);
        var nowtime = createInternalTime().toString();
        var _timeDiff = timeDiff(jobjcreatetime, nowtime);
        if (_timeDiff < 30) {
            layer.msg("渲染时间间隔需大于30秒~", {time: 1000});
            return;
        }
    }
    // 第二步：点击渲染的时候，会去执行render_getRenderSize()函数。然后获取“图像大小”
    var size = render_getRenderSize();
    var total=parseInt($("#inputWidth").val()*$("#inputHeight").val());
    var size_txt = $("#renderPanel_oceano .size_precision_select").attr("value");
    // 除了low、super_high_add_01和自定义(小于480000)之外之外，其他的像素都需要增强品质

    if(size_txt=='low'||size_txt=='super_high_add_01'||(size_txt=='custom')&&total<=480000){
        $("#renderPanel_oceano input[name='render_quality_advanced']").attr("checked", false);
    }else {
        $("#renderPanel_oceano input[name='render_quality_advanced']").attr("checked", true);
    }


    // 第三步：获取已被选中的外景图片
    var env = $("#select_ouside_view_pic .top .ouside_view_pic").filter(".hover").attr("name");

    // 第四步：获取选择了什么摄像机（例如是'默认摄像机'还是'鸟瞰摄像机'）
    var select_camera = $("#renderPanel_oceano .camera_select").val();

    // 第五步：获取'布光规则'
    var lighting = $("#renderPanel_oceano .lighting_select").val();
    // 自动布光还是手动布光
    var light_multiplier = (lighting == "auto" ? 1.0 : parseFloat($("#renderPanel_oceano .multiplier .multiplierInput").val()));

    // 第六步：可渲染图像的像素范围--add by gaoning 2017.3.28
    // var maxSize = 4096, minSize = 600;
    var maxHigh = 4096, minHigh = 99;
    var maxWidth = 6000, minWidth = 99;
    if (size.width > maxWidth || size.height > maxHigh) {
        layer.alert("当前渲染支持图像最大大小为6000x4096像素。", {
            closeBtn: 0,
            skin: 'layui-layer-default'
        }, function (idx) {
            layer.close(idx);
        });
        return;
    } else if (size.width < minWidth || size.height < minHigh) {
        layer.alert("当前渲染支持图像最小大小为100x100像素。", {
            closeBtn: 0,
            skin: 'layui-layer-default'
        }, function (idx) {
            layer.close(idx);
        });
        return;
    }

    // 第七步：
    /*是否是VR全景图*/
    var channel = "default";
    var outputtype = $("#renderPanel_oceano .outputtype input[name='rendertype']:checked").val();
    //var outputtype = $("#renderPanel_oceano .output_select").val();
    // if (outputtype == "panorama") {
    //     size.width = 2000, size.height = 1000;
    // }
    /*正常品质还是增强品质*/
    var quality_advanced = $("#renderPanel_oceano input[name='render_quality_advanced']").attr("checked");
    var quality = "high", engine = "CUDA";
    window.global_quality_advanced = quality_advanced;
    if (quality_advanced=="checked") { // 表示勾选了增强品质复选框
        quality = "super_high";
        engine = "CUDA2";
        channel = "hd";        
        // if (outputtype == "panorama") { // 勾选了“增强品质”复选框复选框之后，还选择了“VR全景图”
        //     size.width = 6000; // 设置“图像大小”的长度。size是刚刚定义的一个函数变量。用于获取“图像大小”的长度和宽度的
        //     size.height = 3000;
        //     renderview_retry_interval_time = 90;
        // }else{
        //     renderview_retry_interval_time = 45;
        // }
    }else{
    	  light_multiplier *= 1.3;
    }

    // 第八步：刚刚配置和获取的参数
    var options = {}, user_option = {
        image: {
            width: Math.floor(size.width),
            height: Math.floor(size.height),
            quality: quality
        },
        engine: engine,
        watermark: "none",
        outputtype: outputtype,
        hdri: env,
        lighting: lighting,
        camera: select_camera,
        light_multiplier: light_multiplier,
        channel: channel
    };
    $.extend(true, options, defaultMaxOption, oceano_default_option, user_option);

    // 第九步：关闭“渲染设置”对话框
    $("#renderPanel_oceano").dialog("close");

    // 第十步：
    if (renderDialog_onSuccessCB)renderDialog_onSuccessCB(options);
}


/****************************** UI *************************************/

$("#renderPanel_oceano .env-container .env").on(click, function () {
    $("#renderPanel_oceano .image_env .checkme").appendTo($(this));
    $("#renderPanel_oceano .image_env .env").removeClass("hover");
    $(this).addClass("hover");
});


$(".advanced .show_or_not .advanced_showup").on(click, function (e) {
    $(this).toggleClass("up").toggleClass("down");
    if ($(this).hasClass("up")) $(".advanced .options").hide();
    else $(".advanced .options").show();
});

/*收集要保存到设计的渲染参数*/
var collectRenderParamDataToSaved = function () {
    var result = {};
    var size_txt = $("#renderPanel_oceano .size_precision_select").val();
    result.precision = size_txt;


    result = $.extend(true, result, render_getRenderSize());

    /*方向*/
    var direction = $("#renderPanel_oceano .direction_select input[name='orientation']:checked").val();
    result.direction = direction;

    /*倍增*/
    var lighting = $("#renderPanel_oceano .lighting_select").val();
    var light_multiplier = (lighting == "auto" ? 1.0 : parseFloat($("#renderPanel_oceano .multiplier .multiplierInput").val()));
    result.light_multiplier = light_multiplier;

    return result;
}

/*读出设计中渲染参数信息*/
var readRenderParamDataFromSaved = function (content) {
    init_editor3d_size();

    var designjson = JSON.parse(content);
    var extra = designjson.extra || {};
    var precision = extra.precision || "low";
    var width = extra.width || 800;
    var height = extra.height || 600;
    var direction = extra.direction || "direction_x";
    var light_multiplier = extra.light_multiplier || 1;

    $("#renderPanel_oceano .size_precision_select").trigger("change", [precision]);

    $("#renderPanel_oceano .direction_select input[name='orientation']").each(function () {
        if ($(this).val() == direction) {
            $(this).attr("checked", true);
        } else {
            $(this).attr("checked", false);
        }
    });

    $("#renderPanel_oceano .multiplier .multiplierInput").val(light_multiplier);
    $("#renderPanel_oceano .custom_size .widthInput").val(width);
    $("#renderPanel_oceano .custom_size .ratioInput").val(width / height);
}


/*************************** API **********************************/
var renderDialog_onSuccessCB = undefined;

/*渲染设置*/
var renderDialogPrompt = function (onSuccessCB) {
    renderDialog_onSuccessCB = onSuccessCB;
    $("#renderPanel_oceano").dialog("open");
    $(".uploadMaterial_oceano").hide();
    $("#uploadMaterial_oceano").dialog("close");
    $("div[aria-describedby='renderPanel_oceano']").css("z-index", 1001);
};


//# sourceURL=ui\dialog/render/render_oceano.js

// 弹出层 -> 选择所需的外景图片
$("#renderPanel_oceano .outdoor_scene .btn_select").on(click, function () {
    var index=layer.open({
        type: 1,
        area: ['660px', '600px'],
        title: "请选择外景图片",
        shade: 0.8,
        anim: 1,
        move:false,
        content: $("#select_ouside_view_pic"),
        success: function () {
            $("#select_ouside_view_pic").parents(".layui-layer-page").draggable();
            // 渲染设置之图片列表点击事件
            $("#select_ouside_view_pic .top .ouside_view_pic").on(click, function () {
                $("#renderPanel_oceano .image_env .env-container .daylight").attr("click","true");
                $("#select_ouside_view_pic .top .checkme").appendTo($(this));
                $("#select_ouside_view_pic .top .ouside_view_pic").removeClass("hover");
                $(this).addClass("hover");

                // 获取this的点击图片的name属性
                var _name = ($(this).attr("name"));
                var _url = $("#renderPanel_oceano .image_env .env-container .daylight");

                // 确认按钮（选中图片之后点击确认按钮）
                $("#select_ouside_view_pic .bottom .confirm").on(click, function () {
                    // 获取图片的url
                    switch(_name){
                        case "11":
                            _url.addClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "2":
                            _url.addClass("env022");
                            _url.removeClass("env011");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "3":
                            _url.addClass("env033");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "4":
                            _url.addClass("env044");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "5":
                            _url.addClass("env055");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "6":
                            _url.addClass("env066");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "7":
                            _url.addClass("env077");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "8":
                            _url.addClass("env088");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env099");
                            _url.removeClass("env101");
                            break;
                        case "9":
                            _url.addClass("env099");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env101");
                            break;
                        case "10":
                            _url.addClass("env101");
                            _url.removeClass("env011");
                            _url.removeClass("env022");
                            _url.removeClass("env033");
                            _url.removeClass("env044");
                            _url.removeClass("env055");
                            _url.removeClass("env066");
                            _url.removeClass("env077");
                            _url.removeClass("env088");
                            _url.removeClass("env099");
                            break;
                    }
                    layer.close(index);
                });

            });
            // 取消按钮
            $("#select_ouside_view_pic .bottom .cancel").on(click, function () {
                var _url = $("#renderPanel_oceano .image_env .env-container .daylight");
                if(_url.attr("click")=="true"){

                }else {
                    _url.addClass("env011");
                    _url.removeClass("env022");
                    _url.removeClass("env033");
                    _url.removeClass("env044");
                    _url.removeClass("env055");
                    _url.removeClass("env066");
                    _url.removeClass("env077");
                    _url.removeClass("env088");
                    _url.removeClass("env099");
                    _url.removeClass("env101");
                }
                layer.close(index);
            });

            // 确认按钮（选中图片之后点击确认按钮）
            $("#select_ouside_view_pic .bottom .confirm").on(click, function () {
                layer.close(index);
            });
        }
    });
});

 // “图像大小”的选择
$("#renderPanel_oceano .size_precision_select .size").on("click", function (event, innervalue) {
    // 第一步：点击当前元素，添加背景颜色。以及将当前元素的value值赋给.size_precision_select的value值
    $("#renderPanel_oceano .size_precision_select .size").removeClass("add");
    $(this).addClass("add");
    if (typeof innervalue != "undefined") $(this).val(innervalue);
    var selectSize = $(this).attr("value");
    $("#renderPanel_oceano .size_precision_select").attr("value",selectSize);
    if(selectSize=="custom"){
        // 当点击“自定义”大小的选项时，激活input输入框
        $("#renderPanel_oceano .custom_size input").removeAttr("disabled");
        $("#renderPanel_oceano .custom_size input").removeAttr("readonly");
        $("#renderPanel_oceano .custom_size .title").removeClass("title_color");
        // 当点击“自定义”大小的选项时，隐藏方向
        $("#renderPanel_oceano .direction_select").addClass("hide");
    }else {
        $("#renderPanel_oceano .custom_size input").attr("disabled","true");
        $("#renderPanel_oceano .custom_size input").attr("readonly","true");
        $("#renderPanel_oceano .direction_select").removeClass("hide");
        $("#renderPanel_oceano .custom_size .title").addClass("title_color");
    }

    if($("#renderPanel_oceano .outputtype input[value='panorama']").is(":checked")){
        $("#renderPanel_oceano .direction_select").addClass("hide");
    }

    render_getRenderSize();
    render_fitPreview3d();
    setCurrentPoints(RENDER_IMAGE_SIZE_INFO[$(this).attr("value")][2]);
});

// VR模式的选择
$("#renderPanel_oceano .outputtype input[name='rendertype']").on("click", function () {
    var val=$(this).val();
    if (val == "panorama") {
        $("#renderPanel_oceano .direction_select").addClass("hide");
        $("#renderPanel_oceano .size_precision_select .size").removeClass("add");
        $("#renderPanel_oceano .size_precision_select .size[value='super_high_add_01']").addClass("add");
        $("#renderPanel_oceano .size_precision_select .size[value*='super_high_add']").siblings().addClass("hide");
        $("#renderPanel_oceano .size_precision_select .size[value*='super_high_add']").removeClass("hide");
        $("#renderPanel_oceano .image_size").addClass("image_size_set");
        //解决bug
        $("#renderPanel_oceano .size_precision_select").attr("value","super_high_add_01");

    }

    if(val == "image"){
        $("#renderPanel_oceano .direction_select").removeClass("hide");
        $("#renderPanel_oceano .size_precision_select .size").removeClass("add");
        $("#renderPanel_oceano .size_precision_select .size[value='low']").addClass("add");

        $("#renderPanel_oceano .size_precision_select .size:not([value*='super_high_add'])").siblings().removeClass("hide");
        $("#renderPanel_oceano .size_precision_select .size[value*='super_high_add']").addClass("hide");
        $("#renderPanel_oceano .image_size").removeClass("image_size_set");
        $("#renderPanel_oceano .custom_size input").attr("disabled","true");
        $("#renderPanel_oceano .custom_size input").attr("readonly","true");
        //解决bug
        $("#renderPanel_oceano .size_precision_select").attr("value","low");

        // 解决bug2
        var quality = $("#renderPanel_oceano .size_precision_select").attr("value");
        if(quality=='low'||quality=='custom'){
            $("#renderPanel_oceano input[name='render_quality_advanced']").removeAttr("checked");
        }else {
            $("#renderPanel_oceano input[name='render_quality_advanced']").attr("checked", "checked");
        }

    }
});













