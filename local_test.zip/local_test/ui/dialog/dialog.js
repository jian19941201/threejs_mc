function underlayInputDimensionPrompt(successCB) {
    var index = layer.open({
        type: 1,
        title: '比例设置',
        moveType: 1,
        moveOut: true,
        skin: 'layui-layer-default',
        fix: false,
        //closeBtn: false,
        shadeClose: true,
        maxmin: false,
        area: ['400px', '200px'],
        content: $('.underlayInputDimension')
    });

    function okclick() {
        $(".underlayInputOKButton").off(click);

        var length = $("#underlayInputText").val();

        if (isNaN(Number(length))) {
            layer.alert('输入数值不对！', {title: '提示', skin: 'layui-layer-default'}, function (index) {
                layer.close(index);
            });
        } else {
            layer.close(index);

            if (successCB)
                successCB(Number(length / 1000))

            //addwall action end--by gaoning 2017.4.24
            //api.actionEnd("AddWall");
        }
    }

    $("#underlayInputText").focus();
    $(".underlayInputOKButton").on(click, okclick);
}
function isSuperUser() {
    return false;
}

/*添加物品弹出层*/
var addProductPanelPrompt = (function () {
    var listDialogIndex = undefined;
    var successCB = undefined;
    var dataContainerArray = [];
    var choosedStyleId = undefined;
    var choosedSaturationId = undefined;

    function listDialog(onSuccessCB) {
        var dialogWidth = $(window).width() - 10;
        var dialogHeight = $(window).height() - 10;
        successCB = onSuccessCB;
        listDialogIndex = layer.open({
            type: 1,
            title: '添加物品列表',
            moveType: 1,
            moveOut: true,
            skin: 'layui-layer-default',
            fix: false,
            //closeBtn: false,
            shadeClose: false,
            maxmin: false,
            area: [dialogWidth + 'px', dialogHeight + 'px'],
            content: $('#addProductPanel')
        });
        initCatalog();
        initData();
        initProductStyle();
        initProductSaturation();
        initChoosedClassifie();
    }

    $(document).on('resize',window, function () {
        listDialogIndex && layer.full(listDialogIndex);
    });

    /*初始化风格区域*/
    function initProductStyle() {
        if ($('#addProductPanel #productStyleId ul li').length > 0) return;
        /*只初始化一次*/
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductStyleData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {}
        }).then(function (res) {
            //var res = JSON.parse(resp);
            var styleULObj = $('#addProductPanel #productStyleId ul');
            res.forEach(function (obj) {
                $("<li>").text(obj.title).appendTo(styleULObj).on('click', function (e) {
                    $(this).addClass("hover");
                    $(this).siblings().removeClass("hover");
                    initChoosedClassifie();
                    choosedStyleId = obj.sid;
                    var dataArray = [];
                    dataContainerArray.forEach(function (data) {
                        if (choosedSaturationId == undefined) {
                            if (choosedStyleId == data.style) {
                                dataArray.push(data);
                            }
                        } else {
                            if (choosedStyleId == data.style && choosedSaturationId == data.saturation) {
                                dataArray.push(data);
                            }
                        }
                    });
                    thirdCatalogLoadProducts(dataArray);
                });
            });
            calculateHeight();
        }).catch(function (e) {
            layer.alert('send getProductStyleData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }

    /*初始化色调区域*/
    function initProductSaturation() {
        if ($('#addProductPanel #productSaturationId ul li').length > 0) return;
        /*只初始化一次*/
        var servicePrefix = api.getServicePrefix("catalog");
        var url = servicePrefix + "/getProductSaturationData";
        api.getServiceJSONResponsePromise({
            type: 'get',
            url: url,
            cache: true,
            data: {}
        }).then(function (res) {
            //var res = JSON.parse(resp);
            var saturationULObj = $('#addProductPanel #productSaturationId ul');
            res.forEach(function (obj) {
                $("<li>").text(obj.title).appendTo(saturationULObj).on('click', function (e) {
                    $(this).addClass("hover");
                    $(this).siblings().removeClass("hover");
                    initChoosedClassifie();
                    choosedSaturationId = obj.satid;
                    var dataArray = [];
                    dataContainerArray.forEach(function (data) {
                        if (choosedStyleId == undefined) {
                            if (choosedSaturationId == data.saturation) {
                                dataArray.push(data);
                            }
                        } else {
                            if (choosedStyleId == data.style && choosedSaturationId == data.saturation) {
                                dataArray.push(data);
                            }
                        }

                    });
                    thirdCatalogLoadProducts(dataArray);
                });
            });
            calculateHeight();
        }).catch(function (e) {
            layer.alert('send getProductSaturationData request to server failed!! ', {
                closeBtn: 0,
                skin: 'layui-layer-default'
            });
        });
    }

    /*第一次打开页面初始化一些数据，TODO  */
    function initData(forcedLoad) {
        var dataContainerULOBJ = $('#addProductPanel .data_container ul');
        var dataContainerLIOBJS = $('#addProductPanel .data_container ul li');
        if (dataContainerLIOBJS.length == 0 || forcedLoad) {
            dataContainerULOBJ.html('');

            var servicePrefix = api.getServicePrefix("catalog");
            var url = servicePrefix + "/getProductBestListData";
            api.getServiceJSONResponsePromise({
                type: 'get',
                url: url,
                cache: false,
                data: {}
            }).then(function (res) {
                res.forEach(function (obj) {
                    $("<div>").attr("pid", obj.pid).addClass("product").appendTo($("<li>").appendTo(dataContainerULOBJ));
                });

                $("#addProductPanel .data_container ul .product").each(function () {
                    var pid = $(this).attr("pid");
                    $("<img>").attr({
                        src: api.catalogGetFileUrl("product", pid, "iso"),
                        width: '100%',
                        height: '100%',
                        class: 'prodimg ui-imglazy'
                    }).appendTo(this);

                }).on('click', productClick).on('click', function (e) {
                    layer.close(listDialogIndex);
                });

                // lazyLoad.init();
                // $('#addProductPanel .data_container').scroll(function () {
                //     lazyLoad.init();
                // });
            }).catch(function (e) {
                layer.alert('send getProductBestListData request to server failed!! ', {
                    closeBtn: 0,
                    skin: 'layui-layer-default'
                });
            });

        }

    }

    /*计算数据区域高度*/
    function calculateHeight() {
        var addProductPanelHeight = $('#addProductPanel').outerHeight(true);
        var queryAreaHeight = $('#addProductPanel .query_area').outerHeight(true);
        var dataAreaHeight = addProductPanelHeight - queryAreaHeight;
        /*内容体高度。减去border的上下框各1像素*/
        $('#addProductPanel .data_area').innerHeight(dataAreaHeight - 2);
    }

    /*收起事件*/
    $('#addProductPanel .open_close .close').on('click', function (e) {
        $('#addProductPanel .open_close .open').show();
        $('#addProductPanel .open_close .close').hide();
        $('#fristCatalogId').hide();
        $('#secondCatalogId').hide();
        $('#thirdCatalogId').hide();
        $('#productStyleId').hide();
        $('#productSaturationId').hide();
        calculateHeight();
    });

    /*展开事件*/
    $('#addProductPanel .open_close .open').on('click', function (e) {
        $('#addProductPanel .open_close .open').hide();
        $('#addProductPanel .open_close .close').show();
        $('#fristCatalogId').show();
        $('#secondCatalogId').show();
        $('#thirdCatalogId').show();
        $('#productStyleId').show();
        $('#productSaturationId').show();
        calculateHeight();
    });

    /*动态构造已选择项*/
    function initChoosedClassifie() {
        var choosedObj = $('#addProductPanel .query_area .classifief_title .choosed_classifie ul');
        choosedObj.html('');
        $('#addProductPanel .query_area .query_catalog ul .hover').each(function () {
            var liObj = $("<li>").text($(this).text()).appendTo(choosedObj);
            //$("<a>").attr({title:"删除"}).text("[X]").appendTo ( liObj ) ;
        });
    }

    /*清空已选择*/
    $('#addProductPanel .query_area .empty_choosed a').on('click', function (e) {
        $('#addProductPanel .query_area .classifief_title .choosed_classifie ul').html('');
        $('#addProductPanel .query_area .query_catalog ul .hover').each(function () {
            $(this).removeClass("hover");
        });
        initData(true);
    });

    /*在目录切换过程中，清空风格或色调的选择项*/
    function clearStyleAndSaturationChoosed() {
        choosedStyleId = undefined;
        choosedSaturationId = undefined;
        $('#addProductPanel #productStyleId ul .hover').removeClass("hover");
        $('#addProductPanel #productSaturationId ul .hover').removeClass("hover");
    }

    /*初始化目录数据*/
    function initCatalog() {
        if ($('#addProductPanel #fristCatalogId ul li').length > 0) return;
        /*只初始化一次*/

        var fristCatalogObj = $('#addProductPanel #fristCatalogId ul');
        var secondCatalogObj = $('#addProductPanel #secondCatalogId ul');
        var thirdCatalogObj = $('#addProductPanel #thirdCatalogId ul');
        api.catalogGetCatalogTreePromise().then(function (root) {
            fristCatalogObj.html('') , secondCatalogObj.html(''), thirdCatalogObj.html('');
            root.children.forEach(function (level1, index1) {
                /* 打开页面默认显示  开始 */
                /*一级目录全部显示；二级目录显示第一个一级目录的子目录，三级目录显示二级目录的第一个子目录*/
                level1.children.forEach(function (level2, index2) {
                    if (index1 == 0) {
                        $("<li>").text(level2.label).appendTo(secondCatalogObj).on('click', function (e) {
                            thirdCatalogObj.html('');
                            $(this).addClass("hover");
                            $(this).siblings().removeClass("hover");
                            clearStyleAndSaturationChoosed();
                            initChoosedClassifie();
                            level2.children.forEach(function (level3, index3) {
                                $("<li>").text(level3.label).appendTo(thirdCatalogObj).on('click', function (e) {
                                    $(this).addClass("hover");
                                    $(this).siblings().removeClass("hover");
                                    clearStyleAndSaturationChoosed();
                                    initChoosedClassifie();
                                    thirdCatalogLoadProducts(level3.children);
                                    dataContainerArray = level3.children;
                                });
                            });
                        });
                        level2.children.forEach(function (level3, index3) {
                            if (index2 == 0) {
                                $("<li>").text(level3.label).appendTo(thirdCatalogObj).on('click', function (e) {
                                    $(this).addClass("hover");
                                    $(this).siblings().removeClass("hover");
                                    clearStyleAndSaturationChoosed();
                                    initChoosedClassifie();
                                    thirdCatalogLoadProducts(level3.children);
                                    dataContainerArray = level3.children;
                                });
                            }
                        });
                    }
                });
                /* 打开页面默认显示  结束 */

                /*点击第一级目录，二，三级目录变化：二级目录全显示，三级目录显示第一个二级目录的子目录*/
                $("<li>").text(level1.label).appendTo(fristCatalogObj).on('click', function (e) {
                    secondCatalogObj.html('');
                    $(this).addClass("hover");
                    $(this).siblings().removeClass("hover");
                    clearStyleAndSaturationChoosed();
                    initChoosedClassifie();
                    level1.children.forEach(function (level2, index2) {
                        var level2LIObj = $("<li>").text(level2.label);
                        if (index2 == 0) {
                            level2LIObj.addClass("hover");
                            initChoosedClassifie();
                            thirdCatalogObj.html('');
                            level2.children.forEach(function (level3, index3) {
                                var level3LIObj = $("<li>").text(level3.label);
                                if (index3 == 0) {
                                    level3LIObj.addClass("hover");
                                    initChoosedClassifie();
                                }
                                level3LIObj.appendTo(thirdCatalogObj).on('click', function (e) {
                                    $(this).addClass("hover");
                                    $(this).siblings().removeClass("hover");
                                    clearStyleAndSaturationChoosed();
                                    initChoosedClassifie();
                                    thirdCatalogLoadProducts(level3.children);
                                    dataContainerArray = level3.children;
                                });
                            });
                        }

                        level2LIObj.appendTo(secondCatalogObj)
                            .on('click', function (e) {
                                thirdCatalogObj.html('');
                                $(this).addClass("hover");
                                $(this).siblings().removeClass("hover");
                                initChoosedClassifie();
                                level2.children.forEach(function (level3, index3) {
                                    $("<li>").text(level3.label).appendTo(thirdCatalogObj).on('click', function (e) {
                                        $(this).addClass("hover");
                                        $(this).siblings().removeClass("hover");
                                        clearStyleAndSaturationChoosed();
                                        initChoosedClassifie();
                                        thirdCatalogLoadProducts(level3.children);
                                        dataContainerArray = level3.children;
                                    });
                                });
                            });

                        /*点击一级目录 数据区显示 第一个二级目录，第一个三级目录下的数据  开始*/
                        if (index2 == 0) {
                            level2.children.forEach(function (level3, index3) {
                                if (index3 == 0) {
                                    thirdCatalogLoadProducts(level3.children);
                                    dataContainerArray = level3.children;
                                }
                            });
                        }
                        /*点击一级目录 数据区显示 第一个二级目录，第一个三级目录下的数据  结束*/

                    });
                });


            });

            /*目录数据加载完之后*/
            initChoosedClassifie();
            calculateHeight();
        });


    }

    /*单击第三级目录，加载改目录下的产品*/
    function thirdCatalogLoadProducts(dataArray) {
        var dataContainerULOBJ = $('#addProductPanel .data_container ul');
        dataContainerULOBJ.html('');
        dataArray.forEach(function (leaf) {
            $("<div>").attr({pid: leaf.pid})
                .addClass("product")
                .appendTo($("<li>").appendTo(dataContainerULOBJ))
                .on("click", productClick)
                .on("click", function (e) {
                    layer.close(listDialogIndex);
                }).each(function () {
                    var pid = $(this).attr("pid");
                    $("<img>").attr({
                        src: api.catalogGetFileUrl("product", pid, "iso"),
                        width: '100%',
                        height: '100%',
                        class: 'prodimg ui-imglazy'
                    }).appendTo(this);
                });
            // lazyLoad.init();
        });
    }


    return listDialog;
})();


/*显示隐藏物品弹出层*/
var showHideProductPanelPrompt = (function () {
    var listDialogIndex = undefined;
    var successCB = undefined;
    var dataContainerArray = [];

    function listDialog(onSuccessCB) {
        /* var dialogWidth = $(window).width()-10 ;
         var dialogHeight = $(window).height()-10 ;*/
        var dialogWidth = 550;
        var dialogHeight = 550;
        successCB = onSuccessCB;
        listDialogIndex = layer.open({
            type: 1,
            title: '隐藏与显示对象',
            moveType: 1,
            skin: 'layui-layer-default',
            //fix: false,
            //closeBtn: false,
            shade: false,
            shadeClose: false,
            maxmin: false,
            maxWidth:550,
            move: false,
            area: [dialogWidth + 'px', dialogHeight + 'px'],
            content: $('#showHideProductPanel'),
            success: function (layero, index) {
                $("#showHideProductPanel").parents(".layui-layer-default").draggable();
            }
        });
        loadData();
        loadShowData();
        productCount();
        // $('#showHideProductPanel .data_container').scroll(function () {
        //     lazyLoad.init();
        // });
        calculateHeight();
    }

    //使得弹出框会出现全屏显示现象
/*    $(window).bind('resize', function () {
        layer.full(listDialogIndex);
    });*/

    $("#showHideProductPanel .popup .tab").each(function (index) {
        $(this).on(click, function (e) {
            var tabcontainerobj = $(".showHideProductPanel .popup .tab_container .tab_" + index);
            tabcontainerobj.show();
            tabcontainerobj.siblings().hide();
            $(this).addClass("hover");
            $(this).siblings().removeClass("hover");
            // lazyLoad.init();
        });
    });

    /*所有使用的product类模型计数*/
    function productCount(){
        var ObjPidArrary = [];
        var ObjArrary = {};
        var productArray = api.floorplanFilterEntity(function (e) {
            return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR"|| e.type == 'BEAM' || e.type == 'BASEMENT');
        });
        for(var i=0;i<productArray.length;i++){
            ObjPidArrary.push(productArray[i].pid);
        }
        ObjPidArrary.forEach(function(item,i){
            ObjArrary[ObjPidArrary[i]] ? ObjArrary[ObjPidArrary[i]]++ : ObjArrary[ObjPidArrary[i]]=1;
        });
        console.warn(ObjArrary);
    }

    function loadData() {
        var dataContainerULOBJ = $('#showHideProductPanel .hide_tab_container .data_container ul');
        var furnitureContainerULOBJ = $('#showHideProductPanel .hide_tab_container .furniture_container ul');/*家居*/
        var lightContainerULOBJ = $('#showHideProductPanel .hide_tab_container .light_container ul');/*灯具*/
        var structureContainerULOBJ = $('#showHideProductPanel .hide_tab_container .structure_container ul');/*构造*/
        var dataContainerLIOBJS = $('#showHideProductPanel .hide_tab_container .data_container ul li');
        dataContainerULOBJ.html('');

        /*已经隐藏的对象数组*/
        var hiddenObjArray = api.floorplanFilterEntity(function (e) {
            return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR"|| e.type == 'BEAM' || e.type == 'BASEMENT') && ((e.flag & 4) != 0);
        });

        hiddenObjArray.forEach(function (obj) {
            var pid = obj.pid, id = obj.id, type = obj.type;
            var productContainer = $("<div>").attr({"pid": pid, "id": obj.id}).addClass("product");

            function getdivContain(obj){
                $("<img>").attr({
                    src: api.catalogGetFileUrl("product", pid, "iso"),
                    width: '100%',
                    height: '100%',
                    class: 'prodimg ui-imglazy'
                }).appendTo(productContainer);
                $("<span>"+obj.meta.title+obj.index+"</span>").appendTo(productContainer);
            }

            var dataImgUrl =getQueryString("brand")? "ui/catalog/" : "";
            if(obj.meta.subcategory=="pillar"||obj.meta.subcategory=="beam"||obj.meta.subcategory=="basement"){//写入柱子区域
                productContainer.appendTo($("<li>").appendTo(structureContainerULOBJ));
                $("<img>").attr({
                    src: dataImgUrl+"asset/imgCatalog/"+type+"/thumb.jpg",
                    width: '100%',
                    height: '100%',
                    class: 'prodimg ui-imglazy'
                }).appendTo(productContainer);
                $("<span>"+obj.meta.title+obj.index+"</span>").appendTo(productContainer);
            }
            else if(obj.meta.subcategory=="light"||obj.meta.subcategory=="ies"||obj.meta.subcategory=="filllight"){//写入灯具区域
                productContainer.appendTo($("<li>").appendTo(lightContainerULOBJ));
                getdivContain(obj);
            }
            else{//写入家具区域
                productContainer.appendTo($("<li>").appendTo(furnitureContainerULOBJ));
                getdivContain(obj);
            }
            var button_check = $("<input>").attr({"type": "checkbox", "value": id}).addClass("button_checkbox");
            var button_show = $("<div>").attr({"inline-svg-id": "svg-eye","title":"显示"})
                .addClass("button_show button_icon")
                .on("click", function (e) {
                    //$(this).parents("li").remove();
                    $(this).hide().siblings(".button_hide").show();
                    api.actionBegin("SetGeneralFlag", obj);
                    api.actionRun("set", 1 << 2, false);
                    api.actionEnd("SetGeneralFlag");
                });
            var button_hide = $("<div>").attr({"inline-svg-id": "svg-eye-blocked","style":"display:none","title":"隐藏"})
                .addClass("button_hide button_icon")
                .on("click", function (e) {
                    //$(this).parents("li").remove();
                    $(this).hide().siblings(".button_show").show();
                    api.actionBegin("SetGeneralFlag", obj);
                    api.actionRun("set", 1 << 2, true);
                    api.actionEnd("SetGeneralFlag");
                });
            var button_delete = $("<div>").attr({"inline-svg-id": "svg-trash","style":"display:none"})
                .addClass("button_delete button_icon")
                .on("click", function (e) {
                    var that = this;
                    layer.confirm('确定删除该对象？', {
                        btn: ['确定', '取消'], //按钮
                        shade: 0.3, //不显示遮罩
                        skin: 'layui-layer-default',
                        title: '提示'
                    }, function (index) {
                        api.actionBegin("DeleteProduct", obj);
                        api.actionEnd("DeleteProduct");
                        layer.close(index);
                        $(that).parents("li").remove();
                    }, function () {
                    });
                });
            var hover_div = $("<div class='hover_div'>").append(button_show).append(button_hide);
            $("<div>").addClass("button_area").append(button_check).append(button_delete).append(hover_div).appendTo(productContainer);
        });

        $("#showHideProductPanel .data_container ul .product")
            .on("mouseover", function (e) {
                $(this).addClass("hover");
            }).on("mouseout", function (e) {
                $(this).removeClass("hover");
            });
        initSVG();
        // lazyLoad.init();
        // $('#showHideProductPanel .data_container').scroll(function () {
        //     lazyLoad.init();
        // });
        $('#showHideProductPanel .button_area .checkboxset input').prop("checked", false);
    };

    function loadShowData() {
        var dataContainerULOBJ = $('#showHideProductPanel .show_tab_container .data_container ul');
        var furnitureContainerULOBJ = $('#showHideProductPanel .show_tab_container .furniture_container ul')/*家居*/
        var lightContainerULOBJ = $('#showHideProductPanel .show_tab_container .light_container ul');/*灯具*/
        var structureContainerULOBJ = $('#showHideProductPanel .show_tab_container .structure_container ul');/*构造*/
        var dataContainerLIOBJS = $('#showHideProductPanel .show_tab_container .data_container ul li');
        dataContainerULOBJ.html('');

        /*showObjArrary返回添加未隐藏的所有物体模型数组,其中((e.flag & 4) == 0)表示显示,((e.flag & 4) != 0)表示隐藏  -add by zk */
        /*添加的全部对象数组*/
        var showObjArrary = api.floorplanFilterEntity(function (e) {
            return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR" || e.type == 'BEAM' || e.type == 'BASEMENT') && ((e.flag & 4) == 0);
        });
        //console.warn(showObjArrary);

        showObjArrary.forEach(function (obj) {
            var pid = obj.pid, id = obj.id, type = obj.type;
            var productContainer = $("<div>").attr({"pid": pid, "id": obj.id}).addClass("product");

            function getdivContain(obj){
                $("<img>").attr({
                    src: api.catalogGetFileUrl("product", pid, "iso"),
                    width: '100%',
                    height: '100%',
                    class: 'prodimg ui-imglazy'
                }).appendTo(productContainer);
                $("<span>"+obj.meta.title+obj.index+"</span>").appendTo(productContainer);
            }
            var dataImgUrl =getQueryString("brand")? "ui/catalog/" : "";
            if(obj.meta.subcategory=="pillar"||obj.meta.subcategory=="beam"||obj.meta.subcategory=="basement"){//写入柱子区域
                productContainer.appendTo($("<li>").appendTo(structureContainerULOBJ));
                $("<img>").attr({
                    src: dataImgUrl+"asset/imgCatalog/"+type+"/thumb.jpg",
                    width: '100%',
                    height: '100%',
                    class: 'prodimg ui-imglazy'
                }).appendTo(productContainer);
                $("<span>"+obj.meta.title+obj.index+"</span>").appendTo(productContainer);
            }
            else if(obj.meta.subcategory=="light"||obj.meta.subcategory=="ies"||obj.meta.subcategory=="filllight"){//写入灯具区域
                productContainer.appendTo($("<li>").appendTo(lightContainerULOBJ));
                getdivContain(obj);
            }
            else{//写入家居区域
                productContainer.appendTo($("<li>").appendTo(furnitureContainerULOBJ));
                getdivContain(obj);
            }
            var button_check = $("<input>").attr({"type": "checkbox", "value": id}).addClass("button_checkbox");
            var button_show = $("<div>").attr({"inline-svg-id": "svg-eye","style":"display:none","title":"显示"})
                .addClass("button_show button_icon")
                .on("click", function (e) {
                    //$(this).parents("li").remove();
                    $(this).hide().siblings(".button_hide").show();
                    api.actionBegin("SetGeneralFlag", obj);
                    api.actionRun("set", 1 << 2, false);
                    api.actionEnd("SetGeneralFlag");
                });
            var button_hide = $("<div>").attr({"inline-svg-id": "svg-eye-blocked","title":"隐藏"})
                .addClass("button_hide button_icon")
                .on("click", function (e) {
                    //$(this).parents("li").remove();
                    $(this).hide().siblings(".button_show").show();
                    api.actionBegin("SetGeneralFlag", obj);
                    api.actionRun("set", 1 << 2, true);
                    api.actionEnd("SetGeneralFlag");
                });
            var button_delete = $("<div>").attr({"inline-svg-id": "svg-trash"})
                .addClass("button_delete button_icon")
                .on("click", function (e) {
                    var that = this;
                    layer.confirm('确定删除该对象？', {
                        btn: ['确定', '取消'], //按钮
                        shade: 0.3, //不显示遮罩
                        skin: 'layui-layer-default',
                        title: '提示'
                    }, function (index) {
                        api.actionBegin("DeleteProduct", obj);
                        api.actionEnd("DeleteProduct");
                        layer.close(index);
                        $(that).parents("li").remove();
                    }, function () {
                    });
                });
            var hover_div = $("<div class='hover_div'>").append(button_show).append(button_hide);
            $("<div>").addClass("button_area").append(button_check).append(button_delete).append(hover_div).appendTo(productContainer);
        });

        $("#showHideProductPanel .data_container ul .product")
            .on("mouseover", function (e) {
                $(this).addClass("hover");
            }).on("mouseout", function (e) {
                $(this).removeClass("hover");
            });
        initSVG();
        // lazyLoad.init();
        // $('#showHideProductPanel .data_container').scroll(function () {
        //     lazyLoad.init();
        // });
        $('#showHideProductPanel .button_area .checkboxset input').prop("checked", false);
    }

    /*一级选项卡切换*/
    $(".hide_tab ").click(function(){
        $(".hide_tab_container").show()
        $(".show_tab_container").hide();
        loadData();
    });
    $(".show_tab ").click(function(){
        $(".show_tab_container").show();
        $(".hide_tab_container").hide();
        loadShowData();
    });

    /*二级选项卡切换*/
    $(".furniture_tab ").click(function(){
        $(".furniture_container").show()
        $(".light_container").hide();
        $(".structure_container").hide();
        loadShowData();
        loadData();
    });
    $(".light_tab ").click(function(){
        $(".light_container").show();
        $(".furniture_container").hide();
        $(".structure_container").hide();
        loadShowData();
        loadData();
    });
    $(".structure_tab ").click(function(){
        $(".structure_container").show();
        $(".furniture_container").hide();
        $(".light_container").hide();
        loadShowData();
        loadData();
    });

    /*全选/取消*/
    $('#showHideProductPanel .button_area .checkboxset label').on("click", function (e) {
        if($("#showHideProductPanel .furniture_tab").hasClass("hover")){
            var allCheckboxs = $('#showHideProductPanel .furniture_container .button_checkbox');
        }else if($("#showHideProductPanel .light_tab").hasClass("hover")){
            var allCheckboxs = $('#showHideProductPanel .light_container .button_checkbox');
        }else if($("#showHideProductPanel .structure_tab").hasClass("hover")){
            var allCheckboxs = $('#showHideProductPanel .structure_container .button_checkbox');
        };
        var checkboxsetInput = $('#showHideProductPanel .button_area .checkboxset input');
        if (checkboxsetInput.is(":checked")) {
            allCheckboxs.each(function () {
                $(this).prop("checked", false);
            });
            checkboxsetInput.prop("checked", false);
        } else {
            allCheckboxs.each(function () {
                $(this).prop("checked", true);
            });
            checkboxsetInput.prop("checked", true);
        }
    });

    /*全选/取消*/
    $('#showHideProductPanel .button_area .checkboxset input').on("click", function (e) {
        if($("#showHideProductPanel .furniture_tab").hasClass("hover")){
            var allCheckboxs = $('#showHideProductPanel .furniture_container .button_checkbox');
        }else if($("#showHideProductPanel .light_tab").hasClass("hover")){
            var allCheckboxs = $('#showHideProductPanel .light_container .button_checkbox');
        }else if($("#showHideProductPanel .structure_tab").hasClass("hover")){
            var allCheckboxs = $('#showHideProductPanel .structure_container .button_checkbox');
        };
        if ($(this).is(":checked")) {
            allCheckboxs.each(function () {
                $(this).prop("checked", true);
            });
        } else {
            allCheckboxs.each(function () {
                $(this).prop("checked", false);
            });
        }
    });

    /*删除选中*/
    $('#showHideProductPanel .button_area .button_delete').on("click", function (e) {
        var $checkeds = $('#showHideProductPanel .data_container .button_checkbox:checked');
        if ($checkeds.length == 0)return;
        layer.confirm('确定删除选中的对象？', {
            btn: ['确定', '取消'], //按钮
            shade: 0.3, //不显示遮罩
            skin: 'layui-layer-default',
            title: '提示'
        }, function (index) {
            $checkeds.each(function () {
                var id = $(this).val();
                api.floorplanFilterEntity(function (e) {
                    return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR"|| e.type == 'BEAM' || e.type == 'BASEMENT');
                }).forEach(function (obj) {
                    if (id == obj.id) {
                        api.actionBegin("DeleteProduct", obj);
                        api.actionEnd("DeleteProduct");
                        return;
                    }
                });
                $(this).parents("li").remove();
            });
            layer.close(index);
        }, function () {
        });
    });

    /*显示选中*/
    $('#showHideProductPanel .button_area .button_show').on("click", function (e) {
        $('#showHideProductPanel .hide_tab_container .data_container .button_checkbox:checked').each(function () {
            var id = $(this).val();
            api.floorplanFilterEntity(function (e) {
                return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR"|| e.type == 'BEAM' || e.type == 'BASEMENT') && ((e.flag & 4) != 0);
            }).forEach(function (obj) {
                if (id == obj.id) {
                    api.actionBegin("SetGeneralFlag", obj);
                    api.actionRun("set", 1 << 2, false);
                    api.actionEnd("SetGeneralFlag");
                    return;
                }
            });
            $(this).parents("li").remove();
        });
    });

    /*隐藏选中*/
    $('#showHideProductPanel .button_area .button_hide').on("click", function (e) {
        $('#showHideProductPanel .show_tab_container .data_container .button_checkbox:checked').each(function () {
            var id = $(this).val();
            api.floorplanFilterEntity(function (e) {
                return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR"|| e.type == 'BEAM' || e.type == 'BASEMENT') && ((e.flag & 4) == 0);
            }).forEach(function (obj) {
                if (id == obj.id) {
                    api.actionBegin("SetGeneralFlag", obj);
                    api.actionRun("set", 1 << 2, true);
                    api.actionEnd("SetGeneralFlag");
                    return;
                }
            });
            $(this).parents("li").remove();
        });
    });

    /*计算数据区域高度*/
    function calculateHeight() {
        var showHideProductPanelHeight = $('#showHideProductPanel .popup').outerHeight(true);
        var tabHeadAreaHeight = $('#showHideProductPanel .popup .tab_head').outerHeight(true);
        var subTabHeadAreaHeight = $('#showHideProductPanel .popup .subtab_head').outerHeight(true);
        var buttonAreaHeight = $('#showHideProductPanel .popup .button_area').outerHeight(true);
        //var dataAreaHeight = showHideProductPanelHeight - tabHeadAreaHeight - buttonAreaHeight ;
        /*第二次打开buttonAreaHeight高度计算有误，暂时没找到原因*/
        var dataAreaHeight = showHideProductPanelHeight - tabHeadAreaHeight -subTabHeadAreaHeight - 132;
        /*内容体高度。减去border的上下框各1像素*/
        $('#showHideProductPanel .data_container').height(dataAreaHeight - 2);

        /* console.log(showHideProductPanelHeight);
         console.log(tabHeadAreaHeight);
         console.log(buttonAreaHeight);
         console.log(dataAreaHeight);*/
    }


    return listDialog;
})();
$("#hotkeyTable").dialog({
    width: 422, height: 280,
    autoOpen: false,
    resizable: true
});

$("#areaExpandPanel").dialog({
    width: 500,
    autoOpen: false,
    resized: false
}).on("dialogopen", function (event, ui) {
    $("#areaExpandPanel .expand_margin").focus().select()
});
$("#areaExpandPanel .expand_margin").bind("keydown", function (event) {
    if (event.keyCode == 13) {/*回车键*/
        $("#areaExpandPanel .expand").trigger(click);
    }
});
var expandAreaPanelPrompt_onSuccess;
var expandAreaPanelPrompt_onCancel;
var expandAreaPanelPrompt = function (onSuccess, onCancel) {
    $("#areaExpandPanel").dialog("open");
    $("div[aria-describedby='areaExpandPanel']").css("z-index", 5000);

    expandAreaPanelPrompt_onSuccess = onSuccess;
    expandAreaPanelPrompt_onCancel = onCancel;
};
$("#areaExpandPanel .expand").on(click, function () {
    var margin = parseFloat($("#areaExpandPanel .expand_margin").val()) / 1000;
    var area = api.pickGetPicked()[0].model;

    var action = (area.type == "FREEAREA" ? "AddFreeArea" : (area.type == "RECTAREA" ? "AddRectArea" : "AddRoundArea"));
    api.actionBegin(action, area.category);
    api.actionRun("expand", area, margin);
    api.actionEnd(action);

    $("#areaExpandPanel").dialog("close");
    if (expandAreaPanelPrompt_onSuccess)expandAreaPanelPrompt_onSuccess();
});
$("#areaExpandPanel .cancel").on(click, function () {
    $("#areaExpandPanel").dialog("close");
    if (expandAreaPanelPrompt_onCancel)expandAreaPanelPrompt_onCancel();
});


$("#color_pick_dialog").dialog({
    width: 400, height: 200,
    autoOpen: false,
    resizable: false
}).on("dialogopen", function (event, ui) {
    light_color_widget.spectrum("set", "#f0f0f0");
});
var light_color_widget = $("#color_pick_dialog .light_color_widget");
/*加载颜色选择控件*/
light_color_widget.spectrum({
    theme: "sp-light",
    color: "#f0f0f0", /*默认值*/
    preferredFormat: "hex",
    showInput: true,
    showPalette: true,
    palette: [["white", "#787878", "black"],
        ["#fff3d9", "#ffe59f", "#ffb573"],
        ["#d2e7ff", "#a8dbff", "#6ec3ff"]],
    cancelText: "取消",
    chooseText: "选择"
});
light_color_widget.on("change.spectrum", function (e, color) {
    $("#color_pick_dialog").dialog("close");
    var model = api.pickGetPicked()[0].model;
    if (!model || model.type === 'FLOOR') return;
    color_pick_dialog_onOK && color_pick_dialog_onOK(color.toRgb());
});

var color_pick_dialog_onOK;
var color_pick_dialog_onCancel;
$("#color_pick_dialog .ok").on(click, function () {
    $("#color_pick_dialog").dialog("close");
    var model = api.pickGetPicked()[0].model;
    if (!model || model.type === 'FLOOR') return;
    var color = light_color_widget.spectrum("get").toRgb();

    color_pick_dialog_onOK && color_pick_dialog_onOK(color);
});
$("#color_pick_dialog .cancel").on(click, function () {
    $("#color_pick_dialog").dialog("close");
    color_pick_dialog_onCancel && color_pick_dialog_onCancel();
});
function popup_color_picker_dialog(initColor, okCallback, cancelCallback) {
    color_pick_dialog_onOK = okCallback;
    color_pick_dialog_onCancel = cancelCallback;
    $("#color_pick_dialog").dialog("open");
}
//# sourceURL=ui\dialog/dialog.js