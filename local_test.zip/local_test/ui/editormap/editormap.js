$('#houseNavigationId').appendTo($('#viewcontent'));
$('#houseNavigationId').tooltip() ;
$('#houseNavigationId .open').click(function () {
    $(this).fadeOut();
    $('#houseNavigationId .close').fadeIn();
    $('#papermap').fadeOut();
    $(this).siblings(".lock_unlock_content").fadeOut();
});

$('#houseNavigationId .close').click(function () {
    $(this).fadeOut();
    $('#houseNavigationId .open').fadeIn();
    $('#papermap').fadeIn();
    $(this).siblings(".lock_unlock_content").fadeIn();
    api.getViewById("map").fit() ;
});

$('#houseNavigationId .lock_floorplan').click(function () {
    if (api.floorplanIsLocked()) return;
    api.floorplanLock(true);
    $(this).hide();
    $('#houseNavigationId .unlock_floorplan').show();
});

$('#houseNavigationId .unlock_floorplan').click(function () {
    if (!api.floorplanIsLocked()) return;
    var self = $(this);
    layer.confirm('解锁户型后可以修改户型。<br>是否继续解锁户型？', {
        btn: ['确定', '取消'], //按钮
        shade: 0.3, //不显示遮罩
        skin: 'layui-layer-default',
        title: '提示'
    }, function (index) {
        api.floorplanLock(false);
        layer.close(index);
        self.hide();
        $('#houseNavigationId .lock_floorplan').show();
    }, function () {
        //layer.msg('取消', {shift: 6});
    });
});



api.application_ready_event.add(function () {
    $('#houseNavigationId .lock_floorplan').show();
    $('#houseNavigationId .unlock_floorplan').hide();
    api.documentReadyEvent.add(function () {
        if (api.floorplanIsLocked()) {
            $('#houseNavigationId .lock_floorplan').hide();
            $('#houseNavigationId .unlock_floorplan').show();
        } else {
            $('#houseNavigationId .lock_floorplan').show();
            $('#houseNavigationId .unlock_floorplan').hide();
        }
    });

    api.documentLockChangedEvent.add(function (isLock) {
        if (isLock) {
            $('#houseNavigationId .lock_floorplan').hide();
            $('#houseNavigationId .unlock_floorplan').show();
        } else {
            $('#houseNavigationId .lock_floorplan').show();
            $('#houseNavigationId .unlock_floorplan').hide();
        }
    });

});


//# sourceURL=ui\editormap\editormap.js