api.application_ready_event.add(function () {
    //$('#houseNavigationId .open').trigger("click") ;
});
//# sourceURL=ui\editormap\editormap_oceano.js