;(function(window){
    var _this = {},
        imgTopJpgResult,imgFileType,scaleRatio=0.85,imgTopResultArray=[],
        urlPerfix="http://pic.oceano.com.cn/h5filesystem/help/",
        menuidArrayTemp=[],
        editTabItemUrl="/updateUiHelpTips",
        delTabItemUrl="/delUiHelpTips",
        setTabItemUrl="/setUiHelpTips",
        getTabItemUrl="/getUiHelpTipsByid",
        getUiHelpTipsUserBytelUrl="/getUiHelpTipsUserBytel";
    var layuiTabId="helpTips",
        wrap_tabCon="wrap_tabCon",
        wrap_layui_tab_content="#wrap_layui_tab_content",

        wrap_layui_tab_content_normal="#wrap_layui_tab_content_normal";


    _this.init=function (obj,cb) {

        _this.addTipsIconAction(obj,cb);

    }


    _this.userRole=function(user){

        if(user==globalHelpTipsUserObj.tel){
            return true
        }else{
            return false
        }
    }

    _this.getUserRole=function(user,cb){
        // if(!globalHelpTipsUserObj.tel){
            _this.ajaxTabItemAction(getUiHelpTipsUserBytelUrl,{tel:user},function(res){
                var v=res[0] && res[0].tel;
                globalHelpTipsUserObj.tel=v;
                cb&&cb()
            })
        // }else{
        //     cb&&cb();
        // }
    }

    //1.添加tips ui，添加按钮，编辑按钮，删除按钮
    _this.addTipsIconAction=function(obj,cb){
        //parent：事件委托父对象，son：事件委托对象，mask：触发事件的蒙板，不在原来菜单上加事件
        var objParent=obj.parent,objSon=obj.son,objMask=obj.mask;
        //每个菜单添加一个遮罩层，用来绑定事件
        var reg = new RegExp("[.#]","g");
        var tempObjMask=objMask.replace(reg,"");

        //编辑按钮
        var help_tips_edit=$('<div>', { "class": 'help_tips_bg help_tips_edit',
            on: {
                click: function( e ) {
                    var id=$(this).parents(objSon)[0].id;
                    _this.editTipsEvent($(this).parents(objMask),'menu_'+id);
                    return false
                }
            }
        });
        //添加按钮
        var help_tips_add= $('<div>', { "class": 'help_tips_bg help_tips_add',
                on: {
                    click: function( e ) {
                        //2.添加tips事件
                        var id=$(this).parents(objSon)[0].id;
                        _this.addTipsEvent($(this).parents(objMask),'menu_'+id)
                        return false
                    }
                }
            })

        //问号按钮
        var help_tips_quest= $('<div>', { "class": 'help_tips_bg help_tips_quest',
            on: {
                click: function( e ) {
                    //2.添加tips事件
                    var id=$(this).parents(objSon)[0].id;
                    _this.questTipsEvent($(this).parents(objMask),'menu_'+id)
                    return false
                }
            }
        })

        //操作按钮的wrap容器,根据权限生成对应的模版
        var wrap_help_tips;
        if( _this.userRole(globalUsrObj.globalPartyId) ){
            wrap_help_tips=$('<div>', {'class': 'wrap_help_tips'})
                .append(help_tips_add)
                .append(help_tips_edit);
        }else{
            //TODO 生成问号的时机 2018-04-04
            wrap_help_tips=$('<div>', {'class': 'wrap_help_tips'})
                .append(help_tips_quest);

        }

        //插入html到页面
        $(objParent).find(objSon).each(function(i,v){
            $("<div>",{"class":tempObjMask}).appendTo(this);
            $(v).find(objMask).append(wrap_help_tips.clone(true))
        });

        //移入移出事件
        $(objParent).find(objSon).on("mouseenter mouseleave",objMask,function(e){
            var $this=$(this),
                id=$this.parent()[0].id,
                iconsObj=$(this).find(".wrap_help_tips");
            if(e.type == "mouseenter"){
                //hover 显示
                iconsObj.show();

                if( !_this.hasStatusTag( $this.parent() ) ){
                    $this.find(".help_tips_edit").hide();

                    if( !_this.userRole(globalUsrObj.globalPartyId) ){
                        $this.remove();
                    }

                }else{
                    $this.find(".help_tips_add").hide();
                    $this.find(".help_tips_edit").show();
                }
                var height=$this.height(),
                    width=$this.width(),
                    //找出是否存在id
                    idExist = menuidArrayTemp.findIndex(function (value, index, arr) {
                        return value == id;
                    }) >= 0;
                //按钮位置只计算一次
                if( !idExist  ){
                    menuidArrayTemp.push(id);
                    iconsObj.css({"left":(width-10)+"px","top":(height/2-11)+"px"})
                }
            }else{
                //out 隐藏
                iconsObj.hide();
            }

        });
        cb &&cb();

    }

    //2.添加tips事件，增删改事件，parentObj：菜单对象，diglogId：菜单id作为对话框id，需要保存到数据库
    _this.addTipsEvent=function(parentObj,menuId){
        var offset=$(parentObj).offset(),
            width=$(parentObj).width(),
            queryId=menuId.split("_")[1];
        layer.open({
            type: 1 //Page层类型
            ,area: ['500px', '620px']
            ,title: false
            ,closeBtn:0
            // ,offset: [offset.top+'px', (offset.left*1+width*1)+'px']
            ,shade: 0.6 //遮罩透明度
            ,maxmin: false //允许全屏最小化
            ,anim: 0 //0-6的动画形式，-1不开启
            ,content: $("#wrap_layui_tab").text()
            ,id:menuId
            ,success:function(layerobj,index){
                layerobj.find(".layui-layer-content").addClass(wrap_tabCon);
                //3.选项卡操作事件
                _this.layuiTabClickEvt(layuiTabId,menuId,".layui-tab-btn");
            }
        });

    }

    _this.editTipsEvent=function(parentObj,menuId){
        var offset=$(parentObj).offset(),
            width=$(parentObj).width(),
            queryId=menuId.split("_")[1];
        layer.open({
            type: 1 //Page层类型
            ,area: ['500px', '620px']
            ,title: false
            ,closeBtn:0
            // ,offset: [offset.top+'px', (offset.left*1+width*1)+'px']
            ,shade: 0.6 //遮罩透明度
            ,maxmin: false //允许全屏最小化
            ,anim: 0 //0-6的动画形式，-1不开启
            ,content: $("#wrap_layui_tab").text()
            ,id:menuId
            ,success:function(layerobj,index){
                layerobj.find(".layui-layer-content").addClass(wrap_tabCon);
                //拿当前菜单id查询数据库，渲染已有的tab数据；
                _this.ajaxTabItemAction(getTabItemUrl,{id:queryId},function(res){
                    _this.layuiTabActions.tabLoad(layuiTabId,res,menuId)
                });
                //3.选项卡操作事件
                _this.layuiTabClickEvt(layuiTabId,menuId,".layui-tab-btn");
            }
        });
    }

    _this.questTipsEvent=function(parentObj,menuId){
        var offset=$(parentObj).offset(),
            width=$(parentObj).width(),
            offsetTop=offset.top,
            queryId=menuId.split("_")[1],
            winHeight=$(window).height();

        layer.open({
            type: 1 //Page层类型
            ,area: ['500px', '520px']
            ,title: false
            ,closeBtn:0
            ,offset: [offsetTop+'px', (offset.left*1+width*1)+'px']
            ,shade: 0.6 //遮罩透明度
            ,maxmin: false //允许全屏最小化
            ,anim: 0 //0-6的动画形式，-1不开启
            ,content: $("#wrap_layui_tab").text()
            ,id:menuId
            ,success:function(layerobj,index){
                if(offsetTop*1+layerobj.height()*1>winHeight){
                    offsetTop=offsetTop - (offsetTop*1+layerobj.height()*1-winHeight)-15+"px";
                    layerobj.css({"top":offsetTop})
                }

                //移除添加按钮
                layerobj.find(".layui-tab-addbtn").remove();

                layerobj.find(".layui-layer-content").addClass(wrap_tabCon);
                //拿当前菜单id查询数据库，渲染已有的tab数据；
                _this.ajaxTabItemAction(getTabItemUrl,{id:queryId},function(res){
                    _this.layuiTabActions.tabNormalLoad(layuiTabId,res,menuId)
                });
            }
        });
    }


    //tab的增删改事件以及tab内容模版
    _this.layuiTabActions = {
        tabItemContent:function(txtObj,handler){
            var tpl=$( $(txtObj).text() )
            tpl.attr("id","tab_"+handler);
            return tpl.prop("outerHTML");

        },
        tabCloseBtn:function(cb){
            return $('<div>', { "class": 'tabItem_closeBtn',
                on: {
                    click: function(e) {
                        cb && cb(e);
                        return false
                    }
                }
            });

        },
        tabNormalLoad:function(parentTabId,res,menuId){
            var parentObj=this;
            $(res).each(function(i,v){
                layui.element.tabAdd(parentTabId, {
                    title:v.itemtitle,
                    content:parentObj.tabItemContent(wrap_layui_tab_content_normal,v.infoid),
                    id: v.infoid});

                //todo 根据索引给各个 tab的按钮添加事件，这样的话id可以不用加上去
                //渲染已經存在的數據；
                var tabItem=$("#"+menuId).find(".layui-tab-item").eq(i);
                if(v.imgurl){
                    //选项卡Item，选项卡item index,数据库返回的数据
                    _this.tabItemImgAutoFix(tabItem,i,v);
                }

                var listsItemsArray=v.description.split("#");
                $(listsItemsArray).each(function(i,v){
                    var num=$('<span>', { "class": 'description_num',"text":i*1+1}),
                        li=$('<li>', {"text":v}).append(num);
                    tabItem.find(".txtArea_list").append(li);
                })

                if(i==0){
                    layui.element.tabChange(parentTabId, v.infoid);
                }
            });
        },
        //parentTabId：tab选项卡ui层id，res：服务器返回的tab数据
        tabLoad: function(parentTabId,res,menuId){
            var parentObj=this;
            $(res).each(function(i,v){
                layui.element.tabAdd(parentTabId, {
                    title:v.itemtitle,
                    content:parentObj.tabItemContent(wrap_layui_tab_content,v.infoid),
                    id: v.infoid});

                //todo 根据索引给各个 tab的按钮添加事件，这样的话id可以不用加上去
                //添加刪除選項卡按鈕事件
                $("#"+menuId).find(".layui-tab-title").find("li").eq(i).append(parentObj.tabCloseBtn(
                    function(e){
                        parentObj.tabDelete(parentTabId,menuId,e.target)
                        if( $("#"+menuId).find(".layui-tab-title").find("li").length<=1 ){
                            var menuid=menuId.split("_")[1];
                            _this.showAddBtn(menuid);
                        }

                    }
                ));
                //渲染已經存在的數據；
                var tabItem=$("#"+menuId).find(".layui-tab-item").eq(i);

                if(v.imgurl){
                    //选项卡Item，选项卡item index,数据库返回的数据
                    _this.tabItemImgAutoFix(tabItem,i,v);
                }


                if( v.description!=="undefined" && v.description!==""){
                    tabItem.find(".txtArea").val(v.description);
                }

                //菜單id ，tabItemid，索引，綁定上傳事件，保存事件
                _this.saveImgAndMsgUiEvent(menuId,v.infoid,i);

                if(i==0){
                    layui.element.tabChange(parentTabId, v.infoid);
                }

            });
        },

        //parentTabId：tab选项卡ui层id，obj：自定dom对象
        tabAdd: function(parentTabId,menuId,obj){
            var parentObj=_this.layuiTabActions;
            var tabItemId=api.uuid();
            //生成关闭按钮并绑定事件
            var tabItem_closeBtn=parentObj.tabCloseBtn(function(e){

                parentObj.tabDelete(parentTabId,menuId,e.target);
                //删除最后一个 修改 编辑图标
                if( $("#"+menuId).find(".layui-tab-title").find("li").length<=1 ){
                    var menuid=menuId.split("_")[1];
                    _this.showAddBtn(menuid);
                }
            });

            layer.prompt({title: '请输入标题', formType: 0}, function(text, index){
                layui.element.tabAdd(parentTabId, {title:text, content: parentObj.tabItemContent(wrap_layui_tab_content), id: tabItemId})
                layui.element.tabChange(parentTabId, tabItemId);
                //ajax 提交当前选项卡的基础数据到数据库
                var menuid=menuId.split("_")[1];
                var ajaxParam={title:text,id:tabItemId,menuid:menuid};
                //添加状态标记
                _this.addStatusTag("#"+menuid);
                window.loadingIndex = layer.load(1, {
                    shade: [0.1,'#fff'] //0.1透明度的白色背景
                });
                //添加基础tab内容到數據庫
                _this.ajaxTabItemAction(setTabItemUrl,ajaxParam,function(res){
                    if(res.error==0){
                        window.layer.close(loadingIndex)
                        $("#"+menuId).find("li").last().append(tabItem_closeBtn);
                        var tabItemIndex=$("#"+menuId).find("li").last().index();
                        //菜單id ，索引，綁定上傳事件，保存事件
                        _this.saveImgAndMsgUiEvent(menuId,tabItemId,tabItemIndex);
                    }
                });
                //强制显示按钮
                _this.forceShowEditBtn(menuid,".wrap_help_tips_mask")
                layer.close(index);

            });
        }
        ,tabDelete: function(parentTabId,menuId,obj){
            var tabItemid=$(obj).parent().attr("lay-id");
            layer.confirm('你是否要删除当前tab?', {
                btn: ['确定','取消'] //按钮
            }, function(){
                layer.close(layer.index);
                var loadingIndex = layer.load(1, {
                    shade: [0.1,'#fff'] //0.1透明度的白色背景
                });
                //添加基础tab内容
                var ajaxParam={id:tabItemid};
                $helpTips.ajaxTabItemAction(delTabItemUrl,ajaxParam,function(res){
                    if(res.error==0){
                        layui.element.tabDelete(parentTabId, tabItemid);
                        window.layer.close(loadingIndex)
                    }
                });

            }, function(){
                //关闭操作
            });

        }
    };
    //菜单id，选项卡item index,数据库返回的数据
    _this.tabItemImgAutoFix=function(tabItem,index,res){
        tabItem.find(".localImag").addClass("mask");
        //提取图片后缀
        var imgurlArray=res.imgurl.split("/"),
            imgurlId=imgurlArray[0],
            suffix=res.imgurl.split("/")[1];
        tabItem.find(".uploadMaterial_img_box").attr("src",urlPerfix+imgurlId+"/top."+suffix).on("load",function(){
            if( this.width < this.height ){
                $(this).parent().addClass("uploadMaterial_img_box_h")
            }
        });
    }

    //3.选项卡操作事件,绑定add和del按钮事件：parentTabId：tab选项卡的id，obj操作按钮(增删改查)
    _this.layuiTabClickEvt=function(parentTabId,menuid,obj){
        $(obj).on('click', function(){
            var $this = $(this), type = $this.data('type');
            _this.layuiTabActions[type] ? _this.layuiTabActions[type].call(this, parentTabId,menuid,$this) : '';
        });
    }

    //如果有帮助内容后-添加状态标记
    _this.addStatusTag=function(obj){
        if( !_this.hasStatusTag(obj) ){
            $(obj).attr("data-hasTabItem",true);
        }

    }

    //删除最后一条帮助内容后-删除状态标记
    _this.delStatusTag=function(obj){
        if( _this.hasStatusTag(obj) ){
            $(obj).removeAttr("data-hastabitem");
        }

    }

    _this.hasStatusTag=function(obj){
        return !!$(obj).attr("data-hasTabItem");
    }

    //强制一直显示编辑按钮，隐藏添加按钮
    _this.forceShowEditBtn=function(parentId,mask){
        var width=$("#"+parentId).find(mask).width();
        var height=$("#"+parentId).find(mask).height();
        $("#"+parentId).find(".help_tips_add").hide();
        $("#"+parentId).find(".help_tips_edit").show();
        $("#"+parentId).find(".wrap_help_tips").addClass("hasTabItem").css({"left":(width-10)+"px","top":(height/2-11)+"px"});
    }


    //删除最后一个tab后，隐藏编辑按钮，显示add按钮
    _this.showAddBtn=function(parentId){
        $("#"+parentId).find(".hasTabItem").removeClass("hasTabItem");
        $("#"+parentId).removeAttr("data-hasTabItem");
        $("#"+parentId).find(".help_tips_add").show();
        $("#"+parentId).find(".help_tips_edit").hide();
    }


    _this.ajaxGetAllTab=function(cb){
        var url = api.getServicePrefix("helptips") + "/getUiHelpTipsAllMenu";
        api.getServiceJSONResponsePromise({
            url: url,
            type: "POST",
            cache: false
            // data: ajaxParam
        }).then(function (resp) {
            var res = (resp);
            cb && cb( res ) ;
        });

    }

    //增删改查 tab
    _this.ajaxTabItemAction=function(apiUrl,ajaxParam,cb){
        var url = api.getServicePrefix("helptips") + apiUrl;
        api.getServiceJSONResponsePromise({
            url: url,
            type: "POST",
            cache: false,
            data: ajaxParam
        }).then(function (resp) {
            var res = (resp);
            cb && cb( res ) ;
        });
    }

    //获取含有tab的id
    _this.getExitstTabsIds=function(val){
        return val
    }

    _this.close=function(obj,cb) {
        menuidArrayTemp = [];
        $(".wrap_help_tips_mask").off("mouseenter mouseleave");
        $(".wrap_help_tips_mask").remove();
        cb && cb();
    }

    _this.resetUploadBox=function(){
        imgTopJpgResult=undefined;
        //$(".uploadMaterial_img_box").attr("src","");
        /*解决能上传两张同样的图片*/
        $(".custom_layui_tab_item_upload").find(".wrap_uploadMaterial_img_box").wrap("<form>").closest("form").get(0).reset();

    }

    //1.将图片转换为arraybuffer上传，gif不做base64转换
    _this.imgChangeToArrayBuffer= (function () {
            var objectURL = undefined;
            var img = new Image();
            var maxSize=4096;
            var minSize=256;
            var compRatio=0.5//压缩比
            var minImgSize={width:minSize,height:minSize}
            var bigImgSize={};
            return function (e,imgConObj) {
                var imgObj=e.target
                var file = imgObj.files[0];
                var reader = new FileReader();
                var reader2 = new FileReader();
                imgFileType=file.name.substr(file.name.lastIndexOf(".")+1);//imgFileType=file.name.substr(file.name.lastIndexOf(".")+1).match(/.([\s\S]*)/)[1];
                if (objectURL) {
                    /*释放ObjectURL对象资源*/
                    window.URL.revokeObjectURL(objectURL);
                    objectURL = undefined;
                }
                if(imgFileType=='jpg' || imgFileType=='gif'){
                    /*创建ObjectURL对象资源,同时创建小图*/
                    objectURL = window.URL.createObjectURL(file);
                    img.name = file.name, img.type = imgFileType, img.size = file.size;
                    img.src = objectURL;
                    var tempImgW,tempImgH;
                    img.onload = function () {
                        if(imgFileType=="gif"){//gif直接上传，不做base64转换
                            reader.readAsArrayBuffer(file);
                        }else{//压缩jpg
                            //1.图片转为base64，并压缩处理，然后转为blob
                            //获取图片宽高，超出指定宽高需要修剪 add by oxl 2017-04-17
                            var imgSize={width:(+img.naturalWidth),height:(+img.naturalHeight)}
                            /*小于2048*2的时候,使用原来的imgSize宽高即可，大于2048*2，计算一下最新的数值*/
                            bigImgSize=adjustImageWH(imgSize, maxSize, maxSize)
                            minImgSize=adjustImageWH(imgSize, minSize, minSize)
                            /*如果高度比宽度大，添加一个class*/
                            imgConObj.parent().removeClass("uploadMaterial_img_box_h").removeClass("mask");
                            imgConObj.parent().addClass("mask")
                            if( img.width < img.height ){
                                $(imgObj).parent().addClass("uploadMaterial_img_box_h")
                            }

                            /*输出大图Buffer,将用户的大图片调整大小为 小于等于2048的尺寸*/
                            var imgTopJpgResult1 = imageToBlob(imageToBase64(img, compRatio, bigImgSize));
                            var imgTopJpgResult2 = new File([imgTopJpgResult1], file.name, {
                                type: file.type,
                                lastModified: Date.now()
                            });

                            reader.readAsArrayBuffer(imgTopJpgResult2);
                        }



                        reader.onload = function (e) {
                            imgTopJpgResult = this.result;
                            imgTopJpgResult.type=imgFileType;
                            // imgTopResultArray.push(imgTopJpgResult);
                        };
                    }
                    imgConObj.attr("src", objectURL);


                }else{
                    $material.tips("不是jpg文件或gif文件");
                }


            }
        })(window);


    //菜單id，tabItem的ID,tabItem的索引
    _this.saveImgAndMsgUiEvent=function(menuId,tabItemId,index){
        var tabItem=$("#"+menuId).find(".layui-tab-item").eq(index);
        tabItem.find(".tabItemImgSelect").on("change",function(e){
            var $imgCon=$(this).parents(".wrap_uploadMaterial_img_box").find(".uploadMaterial_img_box")
            _this.imgChangeToArrayBuffer(e,$imgCon)
        });

        //點擊保存按鈕 上傳圖片，保存圖片id+描述
        tabItem.find(".save_tabItem_info_btn").on("click",function(){
            var $this=$(this);
            if(!tabItem.find(".txtArea").val()){
                alert("请输入描述")
                return
            }

            var saveBtn_mask=$('<div>', { "class": 'saveBtn_mask',"text":"保存"});
            $this.parent().append(saveBtn_mask);
            var index = layer.load(1, {
                shade: [0.4,'#000'] //0.1透明度的白色背景
            });
            _this.saveImgAndMsgAction(tabItem,tabItemId,imgTopJpgResult,function (ajaxParam) {
                //更新選項卡的數據到數據庫
                _this.ajaxTabItemAction(editTabItemUrl,ajaxParam,function(res){
                    if(res.error==0){
                        layer.close(index);
                        layer.msg('保存成功',{time:2000});
                        $this.parent().find(".saveBtn_mask").remove();
                        //清除狀態
                        _this.resetUploadBox();
                    }
                });

            })


        })

    }
    /*2.保存图片+文字描述 imgTopResultArg：提交的图片；imgFileType：图片后缀名*/
    _this.saveImgAndMsgAction=function(tabItem,tabItemId,imgTopResultArg,cb){

        if(!"existsUser"){//注册用户
            $material.tips("你没有权限");
            window.uploadActiveStatus = false;//重新定义上传状态
            return
        }

        var fileserver = api.getServicePrefix("file"),
            p=$(tabItem),
            description=p.find(".txtArea").val(),
            suffix={"jpg":"topjpg","gif":"topgif"};

        /*id:选项卡id,帮助描述*/
        var $objData={"id":tabItemId,"description":description}

        //如果有imgTopResultArg才能走整个流程，上传图片或者图片不改动，就只需要保存文字
        if(imgTopResultArg){
            var imgType=imgTopJpgResult.type.toLowerCase()
                ,imgId = api.uuid()
                ,commonUrl=fileserver + "/uploadFile" + "?id=" + imgId + "&category=help&"
                ,uploadTopJpgUrl = commonUrl+"type="+suffix[imgType];
            //imgurl：图片id+后缀
            $objData.imgurl=imgId+"/"+imgType;

            /*先上传大图*/
            api.getServiceJSONResponsePromise({
                url: uploadTopJpgUrl,
                type: "POST",
                cache: false,
                contentType: false,
                processData: false,
                data: imgTopResultArg//可以用buffer或者formData，这里是buffer
            }).catch(function (e) {
                layer.alert('上传失败,请重试!! ', {
                    closeBtn: 0,
                    skin: 'layui-layer-default'
                });
                window.uploadActiveStatus = false;//重新定义上传状态
                resetUploadDialog();

            }).then(function (resp) {
                /*成功保存图片后，再保存其他参数
                 * */
                console.log(imgId+"圖片上傳成功")
                if(resp){
                    cb && cb($objData)
                }
            });

        }else{
            //图片没改动，只传文字
            delete $objData.imgurl
            cb && cb($objData)
        }

    }

    window.$helpTips = _this;

})(window);


api.application_ready_event.add(function () {
    window.globalHelpTipsUserObj={};//保存帮助提示用户手机号的obj
    globalHelpTipsUserObj.tel=0;//初始化
    //初始化layui配置
    layui.config({
        dir: 'ui/lib/layerui/'
        ,version: false
        ,debug: false
        ,base: '' //设定扩展的Layui模块的所在目录，一般用于外部模块扩展
    });

    //引入layui tab模块
    layui.use(['element'], function () {
        var element = layui.element;
        element.init()//更新ui;

    });

    //2018-03-20-新手指引
    $("#helper_switch").click(function (e) {
        //左侧菜单
        var objMenuLeft={ parent:".catalogRoomLeft .roomLi",son:"li",mask:".wrap_help_tips_mask"}
        //右侧菜单
        var objMenuRight={ parent:"#productContent .items",son:".action_menu",mask:".wrap_help_tips_mask"}

        // var objMenuTop={ parent:"#toolbar_navigator",son:".left div",mask:".wrap_help_tips_mask"}
        if( $(this).prop("checked") ){

            //先确定是否有编辑权限
            $helpTips.getUserRole(globalUsrObj.globalPartyId,function(){

                $helpTips.ajaxGetAllTab( function(res){
                    var menuIdArray=[]
                    $(res).each(function(i,v){
                        menuIdArray.push(v.mid);
                    })

                    $helpTips.init(objMenuLeft,function () {
                        $(".catalogRoomContent").attr("style","visibility: hidden;");
                    });

                    $helpTips.init(objMenuRight);
                    // $helpTips.init(objMenuTop);



                    var set = new Set(menuIdArray);
                    var menuIdArray2 = Array.from(set);
                    $(menuIdArray2).each(function(i,v){
                        //隐藏添加按钮，强制显示编辑按钮
                        $("#"+v).attr("data-hasTabItem",true).find(".help_tips_add").hide();
                        $helpTips.forceShowEditBtn(v,objMenuLeft.mask)
                        //隐藏加号显示edit图标
                    })

                })

            })






        }else{
            //移除页面生成的各种帮助提示
            $helpTips.close(objMenuLeft,function () {
                $(".catalogRoomContent").attr("style","visibility: visible;");
            });
            $helpTips.close(objMenuRight);
            // $helpTips.close(objMenuTop);
        }

    })

})
