layer控件在本项目集成bug，特殊用法：

1、layer.open 打开窗口拖动，拖动一次之后就不能拖动了
   解决方案：设置move参数为false，然后open成功后的回调函数(success)中,使用jQuery的draggable方法，例如renderview.js中使用
   tips:只要定位到弹出框,并对弹出框进行draggable就可以了