function classInherit(childCtor, parentCtor) {
    function tempCtor() {
    }

    var type = childCtor.prototype.type;
    tempCtor.prototype = parentCtor.prototype, childCtor.superClass_ = parentCtor.prototype,
        childCtor.prototype = new tempCtor(), childCtor.prototype.constructor = childCtor,
    type && (TYPE[type] = childCtor, childCtor.prototype.type = type);
}

function classBase(me, opt_methodName, var_args) {
    var caller = arguments.callee.caller;
    if (caller.superClass_)
        return caller.superClass_.constructor.apply(me, Array.prototype.slice.call(arguments, 1));
    for (var args = Array.prototype.slice.call(arguments, 2), foundCaller = !1, ctor = me.constructor; ctor; ctor = ctor.superClass_ && ctor.superClass_.constructor) {
        if (ctor.prototype[opt_methodName] === caller) {
            foundCaller = !0;
        } else if (foundCaller) {
            return ctor.prototype[opt_methodName].apply(me, args);
        }
    }
    if (me[opt_methodName] === caller) {
        return me.constructor.prototype[opt_methodName].apply(me, args);
    }

    throw Error("class usage error.");
}

function Root(opt) {
    this.id = opt && opt.id || utilUUID();
    Root.prototype.database[this.id] = this;
    this.propertyChangedEvent = new Signal();
    this.userDefined = void 0;
}

function defaultPropertyChangedCallbackInternal(fieldName, oldValue, newValue) {
    0 != this.propertyChangedEvent.getNumListeners() && this.propertyChangedEvent.dispatch(fieldName, oldValue, newValue);
}


function utilRootDefineProperty(root, name, defaultValue, propertyChangedCallback, option) {
    var callback = propertyChangedCallback || defaultPropertyChangedCallbackInternal.bind(root);
    root["_p_" + name] = defaultValue;
    Object.defineProperty(root, name, {
        enumerable: !0,
        configurable: !0,
        get: function () {
            return this["_p_" + name];
        },
        set: function (value) {
            if (value !== this["_p_" + name]) {
                var old = this["_p_" + name];
                this["_p_" + name] = value;
                callback(name, old, value);
            }
        }
    });
}

function Entity(opt) {
    classBase(this, opt);
    this.lt = {};
    this.lf = {};
    this.linksChangedEvent = new Signal();
    this.linkPropertyChangedEvent = new Signal();
}

function utilEntityAddLink(from, to, ifSpreadSignal) {
    if(from && to && void 0 == from.lf[to.id]){
        if(to.type == "RECTAREA3D" || 
           to.type == "ROUNDAREA3D" ||
           to.type == "WALLBOARD" ||
           to.type == "BASEBOARD"){
           	
          if(!to.host){
          	return;
          }
        }
    
        from.lf[to.id] = to,
        from.linksChangedEvent.dispatch("lf", "add", to),
        to.lt[from.id] = from,
        to.linksChangedEvent.dispatch("lt", "add", from);
    };
}

function utilEntityRemoveLink(from, to, ifSpreadSignal) {
    from && to && void 0 != from.lf[to.id] && (
        delete from.lf[to.id],
            from.linksChangedEvent.dispatch("lf", "remove", to),
            delete to.lt[from.id],
            to.linksChangedEvent.dispatch("lt", "remove", from),
            to.dispose(),                                          //调用dispose 进行内部清理过程
            delete Root.prototype.database[to.id]                  //统一删除db对象
    );
}
function utilEntityRemoveLinkToGroup(from, to, ifSpreadSignal) {
    from && to && void 0 != from.lf[to.id] && (
        delete from.lf[to.id],
            from.linksChangedEvent.dispatch("lf", "remove", to),
            delete to.lt[from.id],
            to.linksChangedEvent.dispatch("lt", "remove", from)
    );
}
function linkPropertyChangedCalllback(propertyName, changedFrom, changedTo) {
    defaultPropertyChangedCallbackInternal.call(this, propertyName, changedFrom, changedTo);
    changedFrom && utilEntityRemoveLink(this, changedFrom);
    changedTo && utilEntityAddLink(this, changedTo);
}

function entityPropertyChangedCallback(propertyName, changedFrom, changedTo) {
    function spreadEvent(current) {
        for (var id in current.lt) {
            var linked = current.lt[id];
            linked.linkPropertyChangedEvent.dispatch(changedEntity, propertyName, changedFrom, changedTo);
            spreadEvent(linked);
        }
    }

    defaultPropertyChangedCallbackInternal.call(this, propertyName, changedFrom, changedTo);
    var changedEntity = this;
    spreadEvent(this);
}

function ModelObject(opt) {
    classBase(this, opt), utilRootDefineProperty(this, "flag", 0, entityPropertyChangedCallback.bind(this));
}

function utilIsFlagOn(flag, mask) {
    return 0 != (flag & mask);
}

function utilIsFlagOff(flag, mask) {
    return 0 == (flag & mask);
}

function utilModelIsFlagOn(m, mask) {
    return utilIsFlagOn(m.flag, mask);
}

function utilModelIsFlagOff(m, mask) {
    return utilIsFlagOff(m.flag, mask);
}

function utilModelSetFlagOn(m, mask) {
    utilModelIsFlagOff(m, mask) && (m.flag = m.flag | mask);
}

function utilModelSetFlagOff(m, mask) {
    utilModelIsFlagOn(m, mask) && (m.flag = m.flag & ~mask);
}

function Group(opt) {
    classBase(this, opt);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "group", void 0, propertyChanged), this.name = "",this.width=0,this.height=0,this.rot=0,this.x=0,this.y=0;
        this.children = [], this._center = void 0,this.boxCenter=void 0,this.itemAdded = new Signal(), this.itemRemoved = new Signal(),this.isdelete = 0;
}

function utilGroupUpdateCenter(fp, group) {
    var bound = new Bound();
    utilBoundReset(bound);
    var allLeafItems = utilGroupGetAllLeafChildren(group);
    0 == allLeafItems.length ? fp && utilGroupReset(fp, group) : (allLeafItems.forEach(function (child) {
        var loop = child.getLoop();
        utilBoundAddBound(bound, utilBoundFromLoop(loop));
    }), group._center = utilBoundIsValid(bound) ? bound.center() : {
        x: void 0,
        y: void 0
    }), utilModelChangeFlag(group, GROUPFLAG_VIEW_UPDATE);
    if(group.id==GROUP_TEMP.id)utilGroupUpdateBoxCenter(group)
}
function utilGroupUpdateBoxCenter(group) {
    group._center && (group.x=group._center.x,group.y=group._center.y);
    utilModelChangeFlag(group, GROUPFLAG_VIEW_UPDATE);
}

function utilGroupGetLoop(group, opt) {
    if (0 != group.children.length) {
        var nonRotBound = new Bound();
        utilBoundReset(nonRotBound);
        for (var i = 0, len = group.children.length; len > i; ++i) {
            var child = group.children[i], loop = child.getLoop();
            utilBoundAddBound(nonRotBound, utilBoundFromLoop(loop));
        }
        var nonRotBoundCenter = nonRotBound.center();
        var rot = 0;
        var loop = utilBoundToLoop(nonRotBound);
        loop && (loop.map(function (pt) {
            return utilMathRotatePointCW(nonRotBoundCenter, pt, rot);
        }));
        return loop;
    }
}

function utilGrouptRotateDelta(group, rotDelta) {
    /*var groupCenter = group._center,*/var groupCenter = {x:group.x,y:group.y},allLeafItems = utilGroupGetAllLeafChildren(group);
    group.rot += rotDelta;
    if(group.rot>360)group.rot=group.rot-360
    allLeafItems.forEach(function (child) {
        if (!(child instanceof Group)) {
            child.rot += rotDelta;
            var childPos = child.center || child, rotPosition = utilMathRotatePointCW(groupCenter, childPos, rotDelta);
            childPos.x = rotPosition.x, childPos.y = rotPosition.y;
        }
    });
}

function utilGroupAddItem(group, child) {
    return __assert(group instanceof Group, "first argument is not a group"), 0 == child.canGroup() ? (__assert(!1, "child can not be grouped:" + child.type),
        !1) : child.group == group ? !0 : (child.group && utilGroupRemoveItem(child.group, child),
        group.children.push(child), child.group = group, utilEntityAddLink(group, child),
        utilModelChangeFlag(group, GROUPFLAG_CHILDREN_ADDED_REMOVED), group.itemAdded.dispatch(child),
        utilGroupUpdateCenter(void 0, group), !0);
}

function utilGroupRemoveItem(group, child) {
    __assert(group instanceof Group, "first argument is not a group");
    var idx = group.children.indexOf(child);
    return -1 == idx ? !1 : (group.children.splice(idx, 1), child.group = void 0, utilEntityRemoveLinkToGroup(group, child),
        utilModelChangeFlag(group, GROUPFLAG_CHILDREN_ADDED_REMOVED), group.itemRemoved.dispatch(child),
        utilGroupUpdateCenter(void 0, group), !0);
}

function GetCameraFlyPosition() {

    var pos = THREE.Vector2(0, 0);

    return pos;
}

function utilGroupReset(floorplan, group) {
    __assert(floorplan, "Invalid Floorplan"), Object.keys(group.lt).forEach(function (parentId) {
        utilEntityRemoveLink(group.lt[parentId], group);
    });
    for (var i = group.children.length - 1; i >= 0; --i) {
        var child = group.children[i];
        utilGroupRemoveItem(group, child);
    }
    group.id == GROUP_TEMP.id && utilEntityAddLink(floorplan, group);
}

function utilFloorplanForEachType(fp, type, callback, thisArg) {
    __assert(void 0 != callback);
    for (var id in fp.lf) {
        var obj = fp.lf[id];
        obj instanceof type && callback.call(thisArg, obj);
    }
}

function utilFloorplanForEachArea(fp, callback, thisArg) {
    __assert(void 0 != callback);
    for (var aID in fp.lf) {
        var area = fp.lf[aID];
        area instanceof Area && callback.call(thisArg, area);
    }
}

function utilFloorplanForEachPoint(fp, callback, thisArg) {
    __assert(void 0 != callback);
    for (var wID in fp.lf) {
        var wall = fp.lf[wID];
        wall instanceof Curve && (
        wall.begin && callback.call(thisArg, wall.begin, wall),
        wall.end && callback.call(thisArg, wall.end, wall));
    }
}

//为自由画区域单独做的点吸咐。
function utilFloorplanForInnerPoint(fp,area,callback, thisArg) {
    __assert(void 0 != callback);

    //修改不只吸咐自身区域的点，房间内所有的区域的点都要可吸咐.
    for (var wID in fp.lf) {
        var area = fp.lf[wID];
        if(area instanceof FreeArea){
            area.profile.forEach(function (cruve){
                if(cruve){
                    cruve.begin && callback.call(thisArg, cruve.begin, cruve);
                    cruve.end && callback.call(thisArg, cruve.end, cruve);
                }
            });
        }
    }

    //if(area){
    //area.profile.forEach(function (curve) {
    //    if (curve) {
    //        //添加同一个区域内的点，其他区域的不添加
    //        curve.begin && callback.call(thisArg, curve.begin, curve);
    //        curve.end && callback.call(thisArg, curve.end, curve);
    //
    //        ////添加与最近墙的点列表
    //        //var rooms = utilAppFloorplanFilterEntity(application, function (e) {
    //        //    return e.type == "FLOOR";
    //        //});
    //        //for (var i = 0; i < rooms.length; i++) {
    //        //    var roomsPos = [];
    //        //    for (var r = 0; r < rooms[i].getLoop().length; r++) {
    //        //        var pos = new vector2();
    //        //        pos.x = rooms[i].getLoop()[r].x;
    //        //        pos.y = rooms[i].getLoop()[r].y;
    //        //        roomsPos.push(pos);
    //        //    }
    //        //    var check = checkPointInPolygon(curve.begin, roomsPos);
    //        //    //先判断此点是否在房间内,以房间为单位再添加墙的列表
    //        //    if (check == true) {
    //        //        var walls = rooms[i].profile;
    //        //        walls.forEach(function (wall) {
    //        //            // 判断点到线段的距离，取距离小的为房间内墙，吸咐时就吸咐到内墙。
    //        //            var p1 = wall._lines[1], p2 = wall._lines[2], p4 = wall._lines[4], p5 = wall._lines[5];
    //        //
    //        //            var d1 = getDistFromPointToLine(p1, p2, curve.begin);
    //        //            var d2 = getDistFromPointToLine(p4, p5, curve.begin);
    //        //
    //        //            if (d1 > d2) {
    //        //                callback.call(thisArg, p4, curve.begin);
    //        //                callback.call(thisArg, p5, curve.begin);
    //        //            } else {
    //        //                callback.call(thisArg, p1, curve.begin);
    //        //                callback.call(thisArg, p2, curve.begin);
    //        //            }
    //        //        });
    //        //    }
    //        //}
    //    }
    //});
    //}else{
    //    for (var wID in fp.lf) {
    //        var area = fp.lf[wID];
    //        if(area instanceof FreeArea){
    //            area.profile.forEach(function (cruve){
    //                if(cruve){
    //                    cruve.begin && callback.call(thisArg, cruve.begin, cruve);
    //                    cruve.end && callback.call(thisArg, cruve.end, cruve);
    //                }
    //            });
    //        }
    //    }
    //}
}

function utilFloorplanForEachBezierPoint(fp, callback, thisArg) {
    __assert(void 0 != callback);
    for (var wID in fp.lf) {
        var wall = fp.lf[wID];
        wall instanceof Curve && (
        wall.bezier && callback.call(thisArg, wall.bezier, wall));
    }
}

function utilFloorplanGetBound(fp) {
    var bound = new Bound();
    return utilBoundReset(bound), utilFloorplanForEachPoint(fp, function (p) {
        isNaN(p.x) || isNaN(p.y) || utilBoundAddPoint(this, p);
    }, bound), bound;
}

function utilFloorplanGetCamerasName(fp) {
    return utilAppFloorplanFilterEntity(application, function (entity) {
        return entity instanceof Camera;
    }, fp).map(function (camera) {
        return camera.id;
    });
}

function utilFloorplanSetActiveOrthographicCamera(fp, cameraIds) {//切换正交相机
    var allCameras = utilFloorplanGetCamerasName(fp);

    allCameras.forEach(function (name) {

        var isActive = -1 != cameraIds.indexOf(name);

        fp.lf[name].active = isActive;
    });
    //setOrthographicCamera();
}



function utilFloorplanSetActiveCamera(fp, cameraIds) {

    var allCameras = utilFloorplanGetCamerasName(fp);
   // console.log(allCameras+'gf')
    allCameras.forEach(function (name) {
        var isActive = -1 != cameraIds.indexOf(name);
        fp.lf[name].active = isActive;
    });
    //setOrthographicCamera();
}





function utilFloorplanGetActiveCamera(fp) {
    var rv, allCameras = utilFloorplanGetCamerasName(fp);
    return allCameras.forEach(function (name) {
        fp.lf[name].active && (rv = fp.lf[name]);
    }), rv;
}







function utilFloorplanBuildExtraLight(fp) {
    var lights = [], gap = .6, tol = .8;
    return utilFloorplanForEachFloor(fp, function (floor) {
        for (var loop = utilFloorGetLoopFromProfile(floor), bound = utilMathGetMinMaxFromPointArray(loop), bound_min = bound.min, bound_max = bound.max, i = bound_min.x + tol; i <= bound_max.x; i += gap) for (var j = bound_min.y + tol; j <= bound_max.y; j += gap) {
            var pt = {
                x: i,
                y: j
            };
            if (utilMathIsPointInPoly(loop, pt)) {
                var distance = 1 / 0;
                if (utilFloorplanForEachWall(fp, function (wall) {
                        if (wall && wall.begin && wall.end) {
                            var nearest = utilMathGetClosestSegmentPoint(pt, wall.begin, wall.end);
                            void 0 != nearest.x && (isNaN(nearest.x) || isNaN(nearest.y) || (distance = Math.min(distance, utilMathLineLength(pt, nearest))));
                        }
                    }), __log(i + "," + j + "," + distance), !(tol - .05 > distance)) {
                    var height = floor.height3d - .1 * distance, heightNoCollision = height;
                    utilFloorplanForEachProduct(fp, function (product) {
                        if (!(product.z < 1.2 || heightNoCollision - .1 > product.z + product.meta.zlen * product.sz)) {
                            var outline = utilGetProductOBBPoints(product);
                            utilMathIsPointInPoly(outline, pt) && (height = Math.min(height, product.z - .05));
                        }
                    });
                    var light = {
                        x: pt.x,
                        y: pt.y,
                        z: height,
                        distance: distance
                    };
                    lights.push(light);
                }
            }
        }
    }), lights;
}

function utilFloorplanSave(fp) {
    return {};
}

function utilFloorplanAddWall(fp, wall) {
    __assert(wall instanceof Wall);
}

function utilFloorplanRemoveWall(fp, wall) {
    __assert(wall instanceof Wall);
}

function utilFloorplanAddProduct(fp, product) {
    __assert(product instanceof Product);
}

function utilFloorplanRemoveProduct(fp, product) {
    __assert(product instanceof Product);
}

function utilFloorplanForEachFloor(fp, callback, thisArg) {
    __assert(void 0 != callback), Object.keys(fp.lf).forEach(function (fID) {
        var floor = fp.lf[fID];
        floor instanceof Floor && callback.call(thisArg, floor);
    });
}
//遍历application.doc.floorplan.lf 中包含的 floor RectArea RoundArea FreeArea oxl0927
//roomId 空间id -> floorMaterial[0].id 插入到svg的id
//api.getBomOneData(roomId).rooms[0].floorMaterial[0].id 当前选中的空间的 相关id
// 1.获取application.doc.floorplan.lf.xxxid 实例化于 rectarea
// 2.之后areaMaterial.id == api.getBomOneData(room[0].model.id).rooms[0].floorareas[0].materialid oxl0927
function utilFloorplanForEachItem(fp, callback, roomId, thisArg) {
    __assert(void 0 != callback), Object.keys(fp.lf).forEach(function (fID) {
        var item = fp.lf[fID];
        if (item instanceof Floor) {
            var floorId = item.floorMaterial.id;
            floorId == api.getBomOneData(roomId).rooms[0].floorMaterial.id && callback.call(thisArg, item)
        }
        //区域materialid需要遍历
        if (item instanceof RectArea || item instanceof RoundArea || item instanceof FreeArea) {
            var areaId = item.areaMaterial.id;
            api.getBomOneData(roomId).rooms[0].floorareas.forEach(function (v) {
                v.materialid == areaId && callback.call(thisArg, item);
            })
        }
    });
}


function utilFloorplanForEachProduct(fp, callback, thisArg) {
    __assert(void 0 != callback), Object.keys(fp.lf).forEach(function (pID) {
        var prod = fp.lf[pID];
        prod instanceof Product && callback.call(thisArg, prod);
    });
}

function utilFloorplanLockFlagChangedNotify(floorplan) {
    var isLockOn = utilModelIsFlagOn(floorplan, MODELFLAG_LOCKED);
    floorplan.underImage && (isLockOn ? utilModelSetFlagOn(floorplan.underImage, MODELFLAG_LOCKED) : utilModelSetFlagOff(floorplan.underImage, MODELFLAG_LOCKED));
    for (var id in floorplan.lf) {
        var child = floorplan.lf[id];
        (child.type == Floor.prototype.type || child instanceof Area || child.type == Wall.prototype.type) && (isLockOn ? utilModelSetFlagOn(child, MODELFLAG_LOCKED) : utilModelSetFlagOff(child, MODELFLAG_LOCKED));
    }
    utilFloorplanForEachPoint(floorplan, function (pt) {
        isLockOn ? utilModelSetFlagOn(pt, MODELFLAG_LOCKED) : utilModelSetFlagOff(pt, MODELFLAG_LOCKED);
    });
    utilFloorplanForEachBezierPoint(floorplan, function (pt) {
        isLockOn ? utilModelSetFlagOn(pt, MODELFLAG_LOCKED) : utilModelSetFlagOff(pt, MODELFLAG_LOCKED);
    });
}

function utilAppFloorplanIsLocked(app) {
    var fp = app.doc.floorplan;
    return utilModelIsFlagOn(fp, MODELFLAG_LOCKED);
}

function utilAppFloorplanLock(app, lockOrNot) {
    var fp = app.doc.floorplan;
    return 1 == lockOrNot ? utilModelSetFlagOn(fp, MODELFLAG_LOCKED) : utilModelSetFlagOff(fp, MODELFLAG_LOCKED),
        app.documentLockChangedEvent.dispatch(lockOrNot), lockOrNot;
}

function utilAppFloorplanGetUnderImageScale(app) {
    var fp = app.doc.floorplan;
    if (fp.underImage)
        return fp.underImage.sx;
}

function utilAppFloorplanSetUnderImageScale(app, scale) {
    var fp = app.doc.floorplan;
    fp.underImage && (fp.underImage.sx = fp.underImage.sy = scale, __log("set under image scale=" + scale));
}

function utilAppFloorplanGetAreasByHostId(app, floorplan, hostId, category) {
    for (var fp = floorplan || app.doc.floorplan, areas = [], keys = Object.keys(fp.lf), i = 0, len = keys.length; len > i; ++i) {
        var model = fp.lf[keys[i]];
        model instanceof Area && model.type != "WALLBOARD" && model.type != "BASEBOARD" && model && model.host && model.host.id == hostId && model.category == category && areas.push(model);
    }
    return areas.sort(function (a, b) {
        return a.level == b.level && __assert(!1, "Areas should not have the same level."),
        a.level - b.level;
    });
}

function utilAppFloorplanGetBoardsByWall(app, wall, category){	  
	  var fp = app.doc.floorplan;
	  var boards = [];
	  if(wall[category + "Boards"]){
	  	wall[category + "Boards"].forEach(function(id){
	  		var model = fp.lf[id];
	  		if(model){
	  			boards.push(model);
	  		}
	  	});
	  }
	  
	  return boards;
}

function utilAppFloorplanGetAreasAndBoundarysByHostId(app, floorplan, hostId, category) {
    for (var fp = floorplan || app.doc.floorplan, areas = [], keys = Object.keys(fp.lf), i = 0, len = keys.length; len > i; ++i) {
        var model = fp.lf[keys[i]];
        model instanceof Area && model && model.host && model.host.id == hostId && model.category == category && areas.push(model);
        model instanceof Boundary && model.category == category && areas.push(model);
    }
    return areas.sort(function (a, b) {
        return a.level == b.level && __assert(!1, "Areas should not have the same level."),
        a.level - b.level;
    });
}

function utilAppFloorplanUpdateAreasLevel(areas, updatedArea, isToTop) {
    var len = areas ? areas.length : -1;
    var oldLevel = areas.indexOf(updatedArea);
    -1 != oldLevel && areas.splice(oldLevel, 1);
    isToTop ? areas.push(updatedArea) : areas.unshift(updatedArea);
    for (var i = 0; len > i; ++i) {
      areas[i].level = i;
    }
}

function utilAppFloorplanGetBomData(app, opt) {
    var fp = app.doc.floorplan, rooms = [], openings = [], pids = [DEFAULT_TILE_MATERIAL_ID, DEFAULT_FLOOR_MATERIAL_ID], matLib = [];
    utilFloorplanForEachFloor(fp, function (floor) {
        var room = {
            furnitures: [],
            floor: {},
            walls: [],
            floorareas: [],
            wallareas: [],
            boundarys: [],
            areaboundarys:[],
            tiles: []
        };
        rooms.push(room);

        room.label = floor.label;
        room.labelX = floor.labelX;
        room.labelY = floor.labelY;
        room.measurement = floor.measurement;
        room.measurementLabel = floor.measurementLabel;
        room.measurementLabelX = room.labelX;
        room.measurementLabelY = room.labelY - 0.3;

        var floorLoop = utilFloorGetLoopFromProfile(floor);
        var roomInfo = utilFloorGetRoomInfo(app, floor);
        room.floor.id = floor.id;
        room.floor.measurement = roomInfo.measurement;
        room.floor.materialid = floor.floorMaterial.id;
        var loop = floor.getLoop();
        room.floor.loop = loop && loop.map(function (pt) {
                return {
                    x: pt.x,
                    y: pt.y
                };
            });
        pids.push(floor.floorMaterial.pid);
        matLib.push(floor.floorMaterial);
        roomInfo.areas.forEach(function (area) {
            var loop = area.getLoop();
            room.floorareas.push({
                id :area.id,
                floorRectOrigin :area.floorRectOrigin,
                gapwidth :area.gapwidth,
                singlepaveRot :area.singlepaveRot,
                isSquare : area.isSquare,
                materialid: area.areaMaterial.id,
                measurement: Math.abs(utilAreaGetMeasument(app, area)),
                type: area.type,
                loop: loop && loop.map(function (pt) {
                    return {
                        x: pt.x,
                        y: pt.y
                    };
                }),
                pid: area.areaMaterial.meta.pid,
                perimeterCount: area.perimeterCount,
                svgstr: area.svgstr,
                floorRectTiles: area.floorRectTiles,
                level: area.level,
            }), pids.push(area.areaMaterial.pid), matLib.push(area.areaMaterial);
        });
        floor.profile.forEach(function (wall) {
            //if (!utilModelIsFlagOn(wall, MODELFLAG_HIDDEN)) {
            var wallMiddle = Vec2.lerp(wall.begin, wall.end, .5);
            var middleTurnRight = utilMathRotatePointCW(wallMiddle, wall.begin, 90);
            var middleTurnRightSmall = utilMathGetScaledPoint(wallMiddle, middleTurnRight, wall.width);
            var side = utilMathIsPointInPoly(floorLoop, middleTurnRightSmall) ? "right" : "left", wallMaterial = wall[side + "Material"];
            var wallLoop = utilModelWallGetTessellates(wall, !1);//wall._lines || utilModelWallGetTessellates(wall, !1);
            void 0 == wallLoop || wallLoop.length < 3 || (wallLoop = [utilAdaptorClipperMakePath(wallLoop)]);
            room.walls.push({
                id: wall.id,
                length: utilMathLineLength(wall.begin, wall.end),
                height: wall.height3d,
                materialid: wallMaterial ? wallMaterial.id : "",
                width: wall.width,
                flag: wall.flag,
                begin: wall.begin && {
                    x: wall.begin.x,
                    y: wall.begin.y,
                    z: wall.begin.z
                },
                end: wall.end && {
                    x: wall.end.x,
                    y: wall.end.y,
                    z: wall.end.z
                },
                bezier: wall.bezier && {
                    x: wall.bezier.x,
                    y: wall.bezier.y,
                    z: wall.bezier.z
                },
                wallLoop: wallLoop
            }), wallMaterial && (pids.push(wallMaterial.pid), matLib.push(wallMaterial)), utilAppFloorplanGetAreasByHostId(app, fp, wall.id, side).forEach(function (wallArea) {
                var loop = wallArea.getLoop();
                room.wallareas.push({
                    host: wall.id,
                    materialid: wallArea.areaMaterial.id,
                    measurement: Math.abs(utilAreaGetMeasument(app, wallArea)),
                    type: wallArea.type,
                    flag: wallArea.flag,
                    loop: loop && loop.map(function (pt) {
                        return {
                            x: pt.x,
                            y: pt.y
                        };
                    }),
                    level: wallArea.level
                }), pids.push(wallArea.areaMaterial.pid), matLib.push(wallArea.areaMaterial);
            });
            //}
        });
        utilFloorplanForEachProduct(fp, function (prod) {
            prod.type == Product.prototype.type && (utilMathIsPointInPoly(floorLoop, prod) && room.furnitures.push({
                pid: prod.pid,
                sx: prod.sx,
                sy: prod.sy,
                sz: prod.sz,
                flag: prod.flag,
                type: prod.type
            }), pids.push(prod.pid));
        });

        //添加地砖信息
        var meta = floor.floorMaterial.meta;
        room.floorMaterial = floor.floorMaterial.save();
        room.floorMaterial.rot = parseInt(room.floorMaterial.rot);
        room.floorMaterial.meta = {
            xlen: meta.xlen,
            ylen: meta.ylen,
            zlen: meta.zlen
        };
        room.floorMaterial.origin = utilFloorMaterialOrigin(loop);

        //计算内墙线
        //var wallPaths = [];
        //room.walls.forEach(function (wall) {
        //    var paths = wall.wallLoop;
        //    wallPaths = wallPaths.concat(paths);
        //});
        //
        //var wallLines = utilAdaptorClipperExecute(wallPaths, void 0, ClipperLib.ClipType.ctUnion);
        var wallLines = utilFloorInsideLoopFromProfile(floor);
        room.wallLines = utilAdaptorClipperOffset(wallLines, utilFloorGetBoundaryOffset(floor));

        //添加房间
        utilFloorplanForEachBoundary(fp, function (boundary) {
            if (boundary.host.id == floor.id) {
                room.boundarys.push(boundary);
            } else {
                room.areaboundarys.push(boundary);
            }
            room.floorareas.forEach(function(area){
                if (boundary.host.id == area.id) {
                    room.boundarys.push(boundary);
                }
            });
        });

        floor.floorRectTiles.forEach(function (frTile) {
            if (frTile.tileProfile)
                room.tiles.push(frTile.tileProfile);
        });

    });

    utilFloorplanForEachProduct(fp, function (prod) {
        prod instanceof Opening && (openings.push({
            pid: prod.pid,
            host: prod.attached && prod.attached.id,
            sx: prod.sx,
            sy: prod.sy,
            sz: prod.sz
        }), pids.push(prod.pid));
    });

    var materials = matLib.map(function (mat) {
        return mat instanceof Material ? {
            id: mat.id,
            pid: mat.pid,
            sx: mat.sx,
            sy: mat.sy,
            showInBOM: utilModelIsFlagOff(mat, MATERIALFLAG_SHOW_IN_BOM),
            type: mat.type,
            rot: mat.rot,
            flag: mat.flag
        } : void 0;
    }).filter(function (mat) {
        return void 0 != mat;
    });

    return {
        rooms: rooms,
        pids: pids,
        openings: openings,
        materials: materials
    };
}

//function area
//function floor

function utilAppFloorplanGetBomOneData(app, floorId) {
    var fp = app.doc.floorplan, rooms = [], Rooms = [], openings = [], pids = [DEFAULT_TILE_MATERIAL_ID, DEFAULT_FLOOR_MATERIAL_ID], matLib = [], MatLib = [],wallMatLib=[];
    utilFloorplanForEachFloor(fp, function (floor) {
        var room = {
            furnitures: [],
            floor: {},
            walls: [],
            floorareas: [],
            wallareas: [],
            boundarys: [],
            areaboundarys: [],
            tiles: [],
            parquet: [],
            floorClipedTiles: [],
            areasClipedTiles: [],
            boundarysClipedTiles: []
            /*  parquet_meta:[]*/
        };
        if (floor.id != floorId)Rooms.push(room);
        if (floor.id == floorId)rooms.push(room);
        room.label = floor.label;
        room.labelX = floor.labelX;
        room.labelY = floor.labelY;
        room.measurement = floor.measurement;
        room.measurementLabel = floor.measurementLabel;
        room.measurementLabelX = room.labelX;
        room.measurementLabelY = room.labelY - 0.3;

        var floorLoop = utilFloorGetLoopFromProfile(floor);
        var roomInfo = utilFloorGetRoomInfo(app, floor);
        room.floor.id = floor.id;
        room.floor.measurement = roomInfo.measurement;
        room.floor.floorRectOrigin = floor.floorRectOrigin;
        room.floor.gapwidth = floor.gapwidth;
        room.floor.singlepaveRot = floor.singlepaveRot;
        room.floor.isSquare = floor.isSquare;
        room.floor.materialid = floor.floorMaterial.id;
        var loop = floor.getLoop();
        room.floor.loop = loop && loop.map(function (pt) {
                return {
                    x: pt.x,
                    y: pt.y
                };
            });
        pids.push(floor.floorMaterial.pid);
        /*matLib.push(floor.floorMaterial);*/
        if (floor.id != floorId)MatLib.push(floor.floorMaterial);
        if (floor.id == floorId)matLib.push(floor.floorMaterial);
        roomInfo.areas.forEach(function (area) {
            var loop = area.getLoop();
            room.floorareas.push({
                id :area.id,
                floorRectOrigin :area.floorRectOrigin,
                gapwidth :area.gapwidth,
                singlepaveRot :area.singlepaveRot,
                isSquare : area.isSquare,
                materialid: area.areaMaterial.id,
                measurement: Math.abs(utilAreaGetMeasument(app, area)),
                type: area.type,
                loop: loop && loop.map(function (pt) {
                    return {
                        x: pt.x,
                        y: pt.y
                    };
                }),
                pid: area.areaMaterial.meta.pid,
                perimeterCount: area.perimeterCount,
                svgstr: area.svgstr,
                floorRectTiles: area.floorRectTiles,
                level: area.level,
                //clipedTiles: [],
            }), pids.push(area.areaMaterial.pid), (floor.id != floorId) ? MatLib.push(area.areaMaterial) : matLib.push(area.areaMaterial);
        });

        //floor.profile.forEach(function (wall) {
        //修改为以墙面为计量单位
        var wallInnerPointArr = getWallInsideLoopFromProfile(floor);
        if (wallInnerPointArr) {
            wallInnerPointArr.forEach(function (wallArr) {
                var wall = wallArr[0];
                //return
                //if (!utilModelIsFlagOn(wall, MODELFLAG_HIDDEN)) {
                var wallMiddle = Vec2.lerp(wall.begin, wall.end, .5);
                var middleTurnRight = utilMathRotatePointCW(wallMiddle, wall.begin, 90);
                var middleTurnRightSmall = utilMathGetScaledPoint(wallMiddle, middleTurnRight, wall.width);
                var side = utilMathIsPointInPoly(floorLoop, middleTurnRightSmall) ? "right" : "left", wallMaterial = wall[side + "Material"];
                var wallLoop = utilModelWallGetTessellates(wall, !1);//wall._lines || utilModelWallGetTessellates(wall, !1);
                void 0 == wallLoop || wallLoop.length < 3 || (wallLoop = [utilAdaptorClipperMakePath(wallLoop)]);
                room.walls.push({
                    id: wall.id,
                    length: utilMathLineLength(wall.begin, wall.end),
                    height: wall.height3d,
                    materialid: wallMaterial ? wallMaterial.id : "",
                    width: wall.width,
                    flag: wall.flag,
                    begin: wall.begin && {
                        x: wall.begin.x,
                        y: wall.begin.y,
                        z: wall.begin.z
                    },
                    end: wall.end && {
                        x: wall.end.x,
                        y: wall.end.y,
                        z: wall.end.z
                    },
                    wallLoop: wallLoop,
                    //添加内墙数据信息--add by gaoning 2018.2.25
                    boards: getBoards(floor, wall),
                    rectArea3ds: getRectArea3ds(floor, wall),
                    roundArea3ds: getRoundArea3ds(floor, wall)
                    ////////////////////////////////////////////
                }),
                    //wallMaterial && (pids.push(wallMaterial.pid), matLib.push(wallMaterial)),
                    getBoards(floor, wall).length>0 &&(wallMatLib.push(getBoards(floor, wall)[0].areaMaterial))
                    utilAppFloorplanGetAreasByHostId(app, fp, wall.id, side).forEach(function (wallArea) {
                        var loop = wallArea.getLoop();
                        room.wallareas.push({
                            host: wall.id,
                            materialid: wallArea.areaMaterial.id,
                            measurement: Math.abs(utilAreaGetMeasument(app, wallArea)),
                            type: wallArea.type,
                            flag: wallArea.flag,
                            loop: loop && loop.map(function (pt) {
                                return {
                                    x: pt.x,
                                    y: pt.y
                                };
                            }),
                            level: wallArea.level
                        });
                        //pids.push(wallArea.areaMaterial.pid),
                        //matLib.push(wallArea.areaMaterial);
                        wallMatLib.push(wallArea.areaMaterial);
                    });
                //}
            });
        }
        utilFloorplanForEachProduct(fp, function (prod) {
            prod.type == Product.prototype.type && (utilMathIsPointInPoly(floorLoop, prod) && room.furnitures.push({
                pid: prod.pid,
                sx: prod.sx,
                sy: prod.sy,
                sz: prod.sz,
                flag: prod.flag,
                type: prod.type
            }), pids.push(prod.pid));
        });

        //添加地砖信息
        var meta = floor.floorMaterial.meta;
        room.floorMaterial = floor.floorMaterial.save();
        room.floor.pid=floor.floorMaterial.pid
        //周长，规格，数量等
        room.floor.perimeterCount = floor.perimeterCount;
        //svg相关数据
        room.floor.svgstr = floor.svgstr;
        room.floor.type="FLOOR"

        //切砖坐标集
        room.floor.floorRectTiles = floor.floorRectTiles;
        room.floorMaterial.rot = parseInt(room.floorMaterial.rot);
        room.floorMaterial.meta = {
            xlen: meta.xlen,
            ylen: meta.ylen,
            zlen: meta.zlen
        };
        room.floorMaterial.origin = utilFloorMaterialOrigin(loop);

        //计算内墙线
        //var wallPaths = [];
        //room.walls.forEach(function (wall) {
        //    var paths = wall.wallLoop;
        //    wallPaths = wallPaths.concat(paths);
        //});
        //
        //var wallLines = utilAdaptorClipperExecute(wallPaths, void 0, ClipperLib.ClipType.ctUnion);
        var wallLines = utilFloorInsideLoopFromProfile(floor);
        room.wallLines = utilAdaptorClipperOffset(wallLines, utilFloorGetBoundaryOffset(floor));

        //添加房间
        utilFloorplanForEachBoundary(fp, function (boundary) {
            if(floor.id==floorId){
                if (boundary.host.id == floor.id) {
                    room.boundarys.push(boundary);
                    matLib.push(boundary.baseMaterial);
                    if (boundary.corner == 'corner' || boundary.corner == 'cblr')matLib.push(boundary.cornerMaterial);
                    if (boundary.corner == 'cblr') {
                        matLib.push(boundary.leftMaterial)
                        matLib.push(boundary.rightMaterial)
                    };
                }else{
                    room.areaboundarys.push(boundary);
                    matLib.push(boundary.baseMaterial);
                    if (boundary.corner == 'corner' || boundary.corner == 'cblr')matLib.push(boundary.cornerMaterial);
                    if (boundary.corner == 'cblr') {
                        matLib.push(boundary.leftMaterial)
                        matLib.push(boundary.rightMaterial)
                    };
                }
                room.floorareas.forEach(function(area){
                    if (boundary.host.id == area.id) {
                        room.boundarys.push(boundary);
                        matLib.push(boundary.baseMaterial);
                        if (boundary.corner == 'corner' || boundary.corner == 'cblr')matLib.push(boundary.cornerMaterial);
                        if (boundary.corner == 'cblr') {
                            matLib.push(boundary.leftMaterial)
                            matLib.push(boundary.rightMaterial)
                        };
                    }
                });
            }
        });

        floor.floorRectTiles.forEach(function (frTile) {
            if (frTile.tileProfile)
            //room.tiles.push(frTile.tileProfile);
                room.tiles.push({pos: frTile.pos, tileProfile: frTile.tileProfile});
        });

        //floor裁剪后的砖列表--add by gaoning 2017.10.19

        room.areasClipedTiles = getAreasClipedTiles(room.floorareas, room);
        room.floorClipedTiles = getcFloorClipperTiles(floor.floorRectTiles, room.floorareas, room);
        room.boundarysClipedTiles = getBoundarysClipperTiles(room.boundarys);

        //console.log(room.boundarys);
        //console.log(room.boundarysClipedTiles);

        //floor.clipedTiles = room.floorClipedTiles
        //切砖后存入原floor的位置,area，boundarys计算用 oxl0927- oxl1025
        room.floor.clipedTiles = room.floorClipedTiles;
        room.floorareas.forEach(function (area,index) {
            area.clipedTiles=room.areasClipedTiles[index]
        });

        room.boundarys.forEach(function (area,index) {
            area.type="BOUNDARY"
            area.clipedTiles=room.boundarysClipedTiles[index]
        });

        delete room.floorClipedTiles,delete room.areasClipedTiles,delete room.boundarysClipedTiles

    });

    utilFloorplanForEachProduct(fp, function (prod) {
        prod instanceof Opening && (openings.push({
            pid: prod.pid,
            host: prod.attached && prod.attached.id,
            sx: prod.sx,
            sy: prod.sy,
            sz: prod.sz
        }), pids.push(prod.pid));
    });
    //var meterialsTemp=[],parquet=[],parquet_meta=[],otherMaterialsTemp=[];
    var materials = matLib.map(function (mat) {
        if (mat.pid == "p54261d5c918f41338f53cf27748659b2") { //蝴蝶拼花
            var count = 0;
            if (mat.userDefined) {
                for (var i in mat.userDefined.parquet.channels) {
                    if (count < 2) {
                        rooms[0].parquet.push(mat.userDefined.parquet.channels[i].pid)
                        rooms[0].parquet = removeDuplicatedItem(rooms[0].parquet)
                    }
                    count++;
                    //meterialsTemp.push({pid:extra[i].pid,type:mat.type});
                }
            } else {
                var extra = JSON.parse(mat.meta.extra).channels;
                for (var i in extra) {
                    if (count < 2) {
                        rooms[0].parquet.push(extra[i].pid)
                        rooms[0].parquet = removeDuplicatedItem(rooms[0].parquet)
                    }
                    count++;
                    //meterialsTemp.push({pid:extra[i].pid,type:mat.type});
                }
            }
            // rooms[0].parquet.push(mat.pid)
            //rooms[0].parquet=removeDuplicatedItem(rooms[0].parquet)
        }
        //materialid=mat.id
        return mat instanceof Material && mat.pid != 'color' ? {
            id: mat.id,
            productId: mat.meta.OCN_PRODUCT_ID,
            pid: mat.pid,
            type: mat.type,
            title: mat.meta.title,
            model: mat.meta.model,
            xlen:mat.meta.xlen,
            ylen:mat.meta.ylen,
            zlen:mat.meta.zlen,
            sque: mat.meta.xlen * 1000 + '×' + mat.meta.ylen * 1000 + (mat.meta.zlen == 0 ? "" : +'×' + mat.meta.zlen * 1000)
        } : void 0;
    }).filter(function (mat) {
        return void 0 != mat;
    });
    //if(meterialsTemp.length>0)materials=meterialsTemp.concat(materials)
    materials = removeDuplicatedItem2(materials);
    var otherMaterials = MatLib.map(function (mat) {
        return mat instanceof Material && mat.pid != 'color' ? {
            id: mat.id,
            productId: mat.meta.OCN_PRODUCT_ID,
            pid: mat.pid,
            sx: mat.sx,
            sy: mat.sy,
            title: mat.meta.title,
            showInBOM: utilModelIsFlagOff(mat, MATERIALFLAG_SHOW_IN_BOM),
            type: mat.type,
            rot: mat.rot,
            flag: mat.flag
        } : void 0;
    }).filter(function (mat) {
        return void 0 != mat;
    });
    wallMatLib=removeDuplicatedItem2(wallMatLib);
    var WallMaterials = wallMatLib.map(function (mat) {
        return mat instanceof Material && mat.pid != 'color' ? {
            id: mat.id,
            productId: mat.meta.OCN_PRODUCT_ID,
            pid: mat.pid,
            sx: mat.sx,
            sy: mat.sy,
            title: mat.meta.title,
            showInBOM: utilModelIsFlagOff(mat, MATERIALFLAG_SHOW_IN_BOM),
            type: mat.type,
            rot: mat.rot,
            flag: mat.flag
        } : void 0;
    }).filter(function (mat) {
        return void 0 != mat;
    });
    return {
        // pids: pids,
        //openings: openings,
        rooms: rooms,
        materials: materials,
        wallMaterials:WallMaterials,
        otherRooms: Rooms,
        ortherMaterials: otherMaterials
    };
    //数组去重复
    function removeDuplicatedItem(arr) {
        var tmp = {}, ret = [];
        for (var i = 0, j = arr.length; i < j; i++) {
            if (!tmp[arr[i]]) {
                tmp[arr[i]] = 1;
                ret.push(arr[i]);
            }
        }
        return ret;
    }

    function removeDuplicatedItem2(arr) {
        var tmp = {}, ret = [];
        for (var i = 0, j = arr.length; i < j; i++) {
            if (!tmp[arr[i].pid]) {
                tmp[arr[i].pid] = 1;
                ret.push(arr[i]);
            }
        }
        return ret;
    }
}

function getBoards(floor, wall) {

    var boards = [];
    var wallInnerPointArr = getWallInsideLoopFromProfile(floor);
    for (var i = 0; i < wallInnerPointArr.length; i++) {
        if (wallInnerPointArr[i][0].id == wall.id) {
            if (wallInnerPointArr[i][2] == "left") {
                boards = wall.leftBoards;
            } else if (wallInnerPointArr[i][2] == "right") {
                boards = wall.rightBoards;
            } else if (wallInnerPointArr[i][2] == "side0") {
                boards = wall.side0Boards;
            } else if (wallInnerPointArr[i][2] == "side1") {
                boards = wall.side1Boards;
            } else {
                boards = [];
            }
        }
    }
    var boardsList = [];
    if (boards && boards.length > 0) {
        for (var b = 0; b < boards.length; b++) {
            //获取区域，并画出区域的铺砖信息
            var board = fp.lf[boards[b]];
            if (board) {
                boardsList.push(board);
            }
        }
    }

    return boardsList;
}
function getRectArea3ds(floor,wall){

    var rectArea3ds = [];

    var wallboardCategory = "";
    var wallInnerPointArr = getWallInsideLoopFromProfile(floor);
    for (var i = 0; i < wallInnerPointArr.length; i++) {
        if (wallInnerPointArr[i][0].id == wall.id) {
            wallboardCategory = wallInnerPointArr[i][2];
        }
    }
    var roundArea3ds = [];
    var rectArea3dList = api.floorplanFilterEntity(function (e) {
        return e.type == "RECTAREA3D";
    });
    for (var r = 0; r < rectArea3dList.length; r++) {
        var category = rectArea3dList[r].category;
        if (rectArea3dList[r].host.id == wall.id && category == wallboardCategory) {
            rectArea3ds.push(rectArea3dList[r]);
        }
    }
    return rectArea3ds;
}
function getRoundArea3ds(floor,wall){

    var wallboardCategory = "";
    var wallInnerPointArr = getWallInsideLoopFromProfile(floor);
    for (var i = 0; i < wallInnerPointArr.length; i++) {
        if (wallInnerPointArr[i][0].id == wall.id) {
            wallboardCategory = wallInnerPointArr[i][2];
        }
    }
    var roundArea3ds = [];
    var roundArea3dList = api.floorplanFilterEntity(function (e) {
        return  e.type == "ROUNDAREA3D";
    });
    for (var r = 0; r < roundArea3dList.length; r++) {
        var category = roundArea3dList[r].category;
        if (roundArea3dList[r].host.id == wall.id && category == wallboardCategory) {
            roundArea3ds.push(roundArea3dList[r]);
        }
    }
    return roundArea3ds;
}

function getBoundarysClipperTiles(boundarys) {

    var allBoundarysData = [];
    boundarys.forEach(function (boundary) {
        var clipperTiles = [];
        boundary.floorRectTiles.forEach(function (floorRectTiles) {
            floorRectTiles.tiles.forEach(function (tiles) {

                if (tiles.tileProfile) {

                    var bounaryMaterialId = floorRectTiles.material.id;
                    var origin = tiles.origin;
                    var clipperProfile = [];
                    tiles.tileProfile.forEach(function (points) {
                        var line = [];
                        points.forEach(function (pos) {
                            line.push({
                                x: pos.x - origin.x,
                                y: pos.y - origin.y
                            });
                        });
                        if (line.length > 0)
                            clipperProfile.push(line);
                    });

                    if (clipperProfile.length > 0) {

                        var area = polygonArea(clipperProfile[0]);
                        //console.log(area);
                        if(area > 0.0001){  //过滤面积过小的砖
                            clipperTiles.push({
                                dir: tiles.dir,
                                elements: tiles.elements,
                                id: tiles.id,
                                floorRectOrigin :floorRectTiles.floorRectOrigin,
                                gapwidth :floorRectTiles.gapwidth,
                                singlepaveRot :floorRectTiles.singlepaveRot,
                                isSquare : floorRectTiles.isSquare,
                                origin: tiles.origin,
                                paveH: tiles.paveH,
                                paveW: tiles.paveW,
                                pavetileID: tiles.pavetileID,
                                pos: tiles.pos,
                                profile: tiles.profile,
                                rot: tiles.rot,
                                tileH: tiles.tileH,
                                tileIndex: tiles.tileIndex,
                                tileProfile: tiles.tileProfile,
                                tileW: tiles.paveW,
                                clipperProfile: clipperProfile,
                                bounaryMaterialId:bounaryMaterialId

                            });
                        }

                    }
                }
            });


        });
        allBoundarysData.push(clipperTiles);
    });

    return allBoundarysData;
}

function polygonArea(points){
    var i,j;
    var area = 0;
    for(i = 0; i < points.length; i++){
        j = (i + 1) % points.length;
        area += points[i].x * points[j].y;
        area -= points[i].y * points[j].x;
    }
    area /= 2;

    return Math.abs(area);
}

//add by gaoning 2017.10.19 start
function getAreasClipedTiles(areas, roomInfo) {

    var clipperNumber = 10000;
    var allAreasData = [];
    areas.forEach(function (area) {
        //区域内的铺砖线导出
        var clipperTiles = [];
        area.floorRectTiles.forEach(function (tiles) {
            if (tiles.tileProfile) {

                var highAreaPaths = [];
                var highArea = getAreasFromHighLevel(areas, area.level);
                if (highArea.length > 0) {
                    for (var a = 0; a < highArea.length; a++) {
                        var areaBoundarys = getBoundaryFromId(roomInfo, highArea[a].id);
                        if (areaBoundarys.length > 0) {
                            var areaPoly2 = [];
                            for (var i = 0; i < highArea[a].loop.length; ++i) {
                                areaPoly2.push({
                                    x: highArea[a].loop[i].x,
                                    y: highArea[a].loop[i].y
                                });
                            }
                            //计算所有外层波打线的宽度
                            var areaBoundarysLength = 0;
                            for (var b = 0; b < areaBoundarys.length; b++) {
                                areaBoundarysLength += areaBoundarys[b].size;
                            }
                            var newOffect = utilAdaptorClipperExtend(areaPoly2, areaBoundarysLength);

                            var areaPoly = [];
                            for (var i = 0; i < newOffect.length; ++i) {
                                areaPoly.push({
                                    X: Math.ceil(newOffect[i].x * clipperNumber),
                                    Y: Math.ceil(newOffect[i].y * clipperNumber)
                                });
                            }

                            highAreaPaths.push(areaPoly);

                        } else {
                            var areaPoly = [];
                            for (var i = 0; i < highArea[a].loop.length; ++i) {
                                areaPoly.push({
                                    X: Math.ceil(highArea[a].loop[i].x * clipperNumber),
                                    Y: Math.ceil(highArea[a].loop[i].y * clipperNumber)
                                });
                            }
                            highAreaPaths.push(areaPoly);
                        }
                    }

                    //添加区域内对上层区域的裁剪
                    var clipperProfile = [];
                    for (var i = 0; i < tiles.tileProfile.length; i++) {

                        var cpr = new ClipperLib.Clipper();
                        var solution = new ClipperLib.PolyTree();
                        var clipAreaPaths = [];
                        var areaLine = [];
                        for (var t = 0; t < tiles.tileProfile[i].length; t++) {
                            areaLine.push({
                                X: Math.ceil(tiles.tileProfile[i][t].x * clipperNumber),
                                Y: Math.ceil(tiles.tileProfile[i][t].y * clipperNumber)
                            });
                        }
                        clipAreaPaths.push(areaLine);

                        //接着裁剪上层区域
                        for (var p = 0; p < highAreaPaths.length; p++) {
                            if(p == 0) {  //先处理第一个
                                cpr.Clear();
                                cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                cpr.AddPath(highAreaPaths[p], ClipperLib.PolyType.ptClip, true);

                                solution = new ClipperLib.PolyTree();
                                cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                            }else if (solution && solution.m_AllPolys.length > 0) {
                                clipAreaPaths = [];
                                for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                    var polygon = [];
                                    for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                        polygon.push({
                                            X: solution.m_AllPolys[i].m_polygon[m].X,
                                            Y: solution.m_AllPolys[i].m_polygon[m].Y
                                        });
                                    }
                                    clipAreaPaths.push(polygon);
                                }
                                cpr.Clear();
                                cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                cpr.AddPath(highAreaPaths[p], ClipperLib.PolyType.ptClip, true);

                                solution = new ClipperLib.PolyTree();
                                cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                            }
                        }

                        //裁剪完清空
                        highAreaPaths = [];
                        var pos = tiles.origin;

                        //把柱子从区域剔除后开始画区域内的地面铺砖线
                        var areaLine = [];
                        for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                            for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                areaLine.push({
                                    x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber - pos.x,
                                    y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber - pos.y
                                });
                            }
                        }
                        if (areaLine.length > 0)
                            clipperProfile.push(areaLine);
                    }

                    if (clipperProfile.length > 0) {
                        clipperTiles.push({
                            dir: tiles.dir,
                            elements: tiles.elements,
                            id: tiles.id,
                            origin: tiles.origin,
                            paveH: tiles.paveH,
                            paveW: tiles.paveW,
                            pavetileID: tiles.pavetileID,
                            pos: tiles.pos,
                            profile: tiles.profile,
                            rot: tiles.rot,
                            tileH: tiles.tileH,
                            tileIndex: tiles.tileIndex,
                            tileProfile: tiles.tileProfile,
                            tileW: tiles.paveW,
                            clipperProfile: clipperProfile
                        });
                    }
                    //areasData.push(clipperTiles);

                } else {//没有上层区域时，只记录当前区域的铺砖

                    //var clipperTiles = [];
                    var clipperProfile = [];

                    var pos = tiles.origin;
                    for (var i = 0; i < tiles.tileProfile.length; i++) {
                        var areaLine = [];
                        for (var t = 0; t < tiles.tileProfile[i].length; t++) {
                            areaLine.push({
                                x: tiles.tileProfile[i][t].x - pos.x,
                                y: tiles.tileProfile[i][t].y - pos.y
                            });
                        }
                        if (areaLine.length > 0)
                            clipperProfile.push(areaLine);
                    }

                    if (clipperProfile.length > 0) {
                        clipperTiles.push({
                            dir: tiles.dir,
                            elements: tiles.elements,
                            id: tiles.id,
                            origin: tiles.origin,
                            paveH: tiles.paveH,
                            paveW: tiles.paveW,
                            pavetileID: tiles.pavetileID,
                            pos: tiles.pos,
                            profile: tiles.profile,
                            rot: tiles.rot,
                            tileH: tiles.tileH,
                            tileIndex: tiles.tileIndex,
                            tileProfile: tiles.tileProfile,
                            tileW: tiles.paveW,
                            clipperProfile: clipperProfile
                        });
                    }
                    //areasData.push(clipperTiles);
                }//没有上层区域时，只记录当前区域的铺砖
            }//tiles不存在时，不添加数据到列表
        });//区域内每个砖
        allAreasData.push(clipperTiles);
    });//房间内每个区域的数据

    //返回房间内所有区域的数据
    return allAreasData;
}
function getcFloorClipperTiles(floorRectTiles, areas, roomInfo) {

    var clipperNumber = 10000;
    if (areas && areas.length > 0) {

        var paths = [];
        areas.forEach(function (area) {
            //把区域添加到paths
            var areaBoundarys = getBoundaryFromId(roomInfo, area.id);
            if (areaBoundarys.length > 0) {
                var areaPoly2 = [];
                for (var i = 0; i < area.loop.length; ++i) {
                    areaPoly2.push({
                        x: area.loop[i].x,
                        y: area.loop[i].y
                    });
                }
                var areaBoundarysLength = 0;
                for (var b = 0; b < areaBoundarys.length; b++) {
                    areaBoundarysLength += areaBoundarys[b].size;
                }
                var newOffect = utilAdaptorClipperExtend(areaPoly2, areaBoundarysLength);

                var areaPoly = [];
                for (var i = 0; i < newOffect.length; ++i) {
                    areaPoly.push({
                        X: Math.ceil(newOffect[i].x * clipperNumber),
                        Y: Math.ceil(newOffect[i].y * clipperNumber)
                    });
                }

                paths.push(areaPoly);

            } else {
                var areaPoly = [];
                for (var i = 0; i < area.loop.length; ++i) {
                    areaPoly.push({
                        X: Math.ceil(area.loop[i].x * clipperNumber),
                        Y: Math.ceil(area.loop[i].y * clipperNumber)
                    });
                }
                paths.push(areaPoly);
            }
        });

        var clipperTiles = [];

        //对地面开始进行区域的剔除
        floorRectTiles.forEach(function (tiles) {

            if (tiles.tileProfile) {
                var cpr = new ClipperLib.Clipper();
                var solution = new ClipperLib.PolyTree();
                var pos = tiles.origin;
                var clipperProfile = [];

                var clipPaths = [];
                var path = [];
                for (var t = 0; t < tiles.tileProfile.length; t++) {
                    for (var i = 0; i < tiles.tileProfile[t].length; i++) {
                        path.push({
                            X: Math.ceil(tiles.tileProfile[t][i].x * clipperNumber),
                            Y: Math.ceil(tiles.tileProfile[t][i].y * clipperNumber)
                        });
                    }

                    clipPaths.push(path);
                    //开始剔除
                    for (var p = 0; p < paths.length; p++) {
                        if(p == 0) {  //没有solution值时先处理第一个
                            cpr.Clear();
                            cpr.AddPaths(clipPaths, ClipperLib.PolyType.ptSubject, true);
                            cpr.AddPath(paths[p], ClipperLib.PolyType.ptClip, true);

                            solution = new ClipperLib.PolyTree();
                            cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                        }else if (solution && solution.m_AllPolys.length > 0) {
                            clipPaths = [];
                            for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                var polygon = [];
                                for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                    polygon.push({
                                        X: solution.m_AllPolys[i].m_polygon[m].X,
                                        Y: solution.m_AllPolys[i].m_polygon[m].Y
                                    });
                                }
                                clipPaths.push(polygon);
                            }
                            cpr.Clear();
                            cpr.AddPaths(clipPaths, ClipperLib.PolyType.ptSubject, true);
                            cpr.AddPath(paths[p], ClipperLib.PolyType.ptClip, true);

                            solution = new ClipperLib.PolyTree();
                            cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                        }
                    }

                    //把区域和柱子都剔除后开始画地面铺砖线

                    var line = [];
                    for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                        for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                            line.push({
                                x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber - pos.x,
                                y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber - pos.y
                            });
                        }
                    }
                    if (line.length > 0)
                        clipperProfile.push(line);
                }

                if (clipperProfile.length > 0) {
                    clipperTiles.push({
                        dir: tiles.dir,
                        elements: tiles.elements,
                        id: tiles.id,
                        origin: tiles.origin,
                        paveH: tiles.paveH,
                        paveW: tiles.paveW,
                        pavetileID: tiles.pavetileID,
                        pos: tiles.pos,
                        profile: tiles.profile,
                        rot: tiles.rot,
                        tileH: tiles.tileH,
                        tileIndex: tiles.tileIndex,
                        tileProfile: tiles.tileProfile,
                        tileW: tiles.paveW,
                        clipperProfile: clipperProfile
                    });
                }

            }
        });

        return clipperTiles;

    } else {//没有剔除的情况下

        var clipperTiles = [];
        floorRectTiles.forEach(function (tiles) {

            if (tiles.tileProfile) {

                var pos = tiles.origin;
                var clipperProfile = [];
                tiles.tileProfile.forEach(function (profile) {
                    var points = [];
                    profile.forEach(function (flie) {
                        points.push({
                            x: flie.x - pos.x,
                            y: flie.y - pos.y
                        });
                    });
                    if (points.length > 0)
                        clipperProfile.push(points);
                });
                if (clipperProfile.length > 0) {
                    clipperTiles.push({
                        dir: tiles.dir,
                        elements: tiles.elements,
                        id: tiles.id,
                        origin: tiles.origin,
                        paveH: tiles.paveH,
                        paveW: tiles.paveW,
                        pavetileID: tiles.pavetileID,
                        pos: tiles.pos,
                        profile: tiles.profile,
                        rot: tiles.rot,
                        tileH: tiles.tileH,
                        tileIndex: tiles.tileIndex,
                        tileProfile: tiles.tileProfile,
                        tileW: tiles.paveW,
                        clipperProfile: clipperProfile
                    });
                }
            }

        });

        return clipperTiles;
    }
}

//获取上层的区域
var getAreasFromHighLevel = function (areas, level) {

    var newAreas = new Array();
    areas.forEach(function (area) {

        if (area.level > level) {
            newAreas.push(area);
        }
    });

    return newAreas;
}
//add by gaoning 2017.10.19  end


function utilModelChangeFlag(model, flag) {
    utilModelIsFlagOn(model, flag) ? utilModelSetFlagOff(model, flag) : utilModelSetFlagOn(model, flag);
}

function utilModelCheckRegularRotation(model, needFix) {
    if (!model || !model.hasOwnProperty("rot"))
        return !1;
    var rot = (model.rot + 360) % 360;
    return utilMathEquals(rot, 0, 3) ? (needFix === !0 && (model.rot = 0), !0) : utilMathEquals(rot, 90, 3) ? (needFix === !0 && (model.rot = 90),
        !0) : utilMathEquals(rot, 180, 3) ? (needFix === !0 && (model.rot = 180), !0) : utilMathEquals(rot, 270, 3) ? (needFix === !0 && (model.rot = 270),
        !0) : utilMathEquals(rot, 360, 3) ? (needFix === !0 && (model.rot = 0), !0) : !1;
}

function utilAppFloorplanGetCompassRotation(app) {
    var fp = app.doc.floorplan;
    return fp.compassRotation;
}

function utilAppFloorplanSetCompassRotation(app, rot) {
    var fp = app.doc.floorplan;
    fp.compassRotation = rot || 0;
}

function utilFloorplanAnalyzeNormalization(fp) {
    var noNormalizedWalls = [];
    var t = .01;
    utilFloorplanForEachFloor(fp, function (floor) {
        var walls = floor.profile;
        var wallCount = walls.length;
        var loop = utilFloorGetLoopFromProfile(floor);
        for (var i = 0; i < (loop && loop.length); ++i) {
            var pt = loop[i];
            var wall0 = walls[i % wallCount];
            var wall1 = walls[(i + 1) % wallCount];
            var lerp0 = utilMathGetLerpNumber(wall0.begin, wall0.end, pt);
            var lerp1 = utilMathGetLerpNumber(wall1.begin, wall1.end, pt);
            utilMathEquals(lerp0, 0, t) || utilMathEquals(lerp0, 1, t) || noNormalizedWalls.push({
                error: 1,
                wall: wall0,
                point: pt
            });
            utilMathEquals(lerp1, 0, t) || utilMathEquals(lerp1, 1, t) || noNormalizedWalls.push({
                error: 1,
                wall: wall1,
                point: pt
            });
        }
    });
    return noNormalizedWalls;
}

function utilAppFloorplanIsNormalized(app) {
    var fp = app.doc.floorplan;
    return 0 == utilFloorplanAnalyzeNormalization(fp).length;
}

function utilAppFloorplanMakeNormalized(app) {
    for (var analyze, fp = app.doc.floorplan, maxRetry = 20, count = 0; ;) {
        analyze = utilFloorplanAnalyzeNormalization(fp);
        var errorItem = analyze[0];
        if (!errorItem || ++count > maxRetry)
            break;
        if (1 == errorItem.error) {
            var wall = errorItem.wall;
            var point = errorItem.point;
            var lerpNumber = utilMathGetLerpNumber(wall.begin, wall.end, point);
            utilWallBreak(fp, wall, lerpNumber);
            utilFloorplanRebuildFloor(fp);
        }
    }
    utilFloorplanForEachWall(fp, function (w) {
        utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D);
        utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
    });
    __log("repair complete, retry=" + count);
    return analyze;
}

function utilAppFloorplanGetOrCreateAnimationByName(app, anim_name, animationType) {
    var rv, fp = app.doc.floorplan, name = anim_name || "DUMMY";
    return utilFloorplanForEachType(fp, Animation, function (w) {
        w.name == name && (rv = w);
    }), rv || (rv = new TYPE[animationType || "ANIMATION"](), utilEntityAddLink(fp, rv),
        rv.name = name), rv;
}

function utilAppFloorplanGetAnimationNames(app) {
    var fp = app.doc.floorplan, names = [];
    return utilFloorplanForEachType(fp, Animation, function (w) {
        names.push(w.name);
    }), names;
}

function utilAppFloorplanFilterEntity(app, filterFn, floorplan) {
    if (!app)
        return [];
    if (!filterFn || "function" != typeof filterFn)
        return [];
    var fp = floorplan || app.doc.floorplan;
    var rv = [];
    if (!fp)
        return rv;
    var lfArray = Object.keys(fp.lf);
    for (var i = 0, len = lfArray.length; len > i; ++i) {
        var entity = fp.lf[lfArray[i]];
        filterFn(entity) === !0 && rv.push(entity);
    }
    return rv;
}

//样板间套用执行方法--gaoning
function utilAppFloorplanApplyGhostRoomStyles(app, floorplan, room, ghostFloorplan, ghostRoom, option) {

    var fp = floorplan || app.doc.floorplan;
    var addFloorArea = (ghostFloorplan || app.doc.ghostFloorplan, !!option && option.floorarea === !0);
    var addWallArea = !!option && option.wallarea === !0;
    var addNewProduct = !!option && option.product_add_new === !0;
    var applyFloorMat = (!!option && option.product_remove_old === !0, !!option && option.floorMaterial === !0);
    var applyAreaMat = !!option && option.areaMaterial === !0;
    var applyWallMat = !!option && option.wallMaterial === !0;
    //start add by gaoning 2017.3.14
    //var product_model_material = !!option && option.product_model_material === !0;
    //var product_other_model_delete = !!option && option.product_other_model_delete === !0;
    var product_other_model = !!option && option.product_other_model === !0;
    //end add by gaoning 2017.3.14

    var removed = utilAppFloorplanResetRoom(app, floorplan, room, option);
    __log("APPLIED Room=" + room.id);
    var ghostFloorCenter = (utilFloorGetRoomInfo(app, room, fp), {
        x: ghostRoom._cx || 0,
        y: ghostRoom._cy || 0
    });
    var currentFloorLoop = room.getLoop();
    var currentFloorCenter = utilMathPolyMassCenter(currentFloorLoop);
    var added = [];
    var newAreas = [];
    if (addNewProduct && utilFloorplanLightFilterEntity(ghostFloorplan, function (entity) {
            return entity.type == Product.prototype.type || entity.type == ProductReplacement.prototype.type;
        }).forEach(function (prodMeta) {
            var entity = null;
            if (prodMeta.type == "PRODUCT") {
                var prod = new Product(prodMeta);
                prod.load(prodMeta);
                added.push(prod);
                utilEntityAddLink(fp, prod);
                prod.rot += 1;
                prod.rot -= 1;

                entity = prod;
            } else {
                var productReplacement = new ProductReplacement(prodMeta);
                productReplacement.load(prodMeta);
                //添加材质--gaoning
                productReplacement.replacementElements.forEach(function (element) {
                    var matName = element + "Material";
                    var mat = new TYPE[prodMeta[matName].type](prodMeta[matName]);
                    mat.load(prodMeta[matName]);
                    productReplacement[matName] = mat;
                });
                added.push(productReplacement);
                utilEntityAddLink(fp, productReplacement);
                productReplacement.load(prodMeta);
                productReplacement.rot += 1;
                productReplacement.rot -= 1;

                entity = productReplacement;
            }

            //记录新的entityId
            prodMeta.newId = entity.id;
        }),
            //start add by gaoning --2017.3.15
            //柱、地台、横梁
        product_other_model && utilFloorplanLightFilterEntity(ghostFloorplan, function (entity) {
            return entity.type == Pillar.prototype.type || entity.type == Beam.prototype.type || entity.type == Basement.prototype.type;
        }).forEach(function (othermodel) {

            //console.log(othermodel);
            var entity = null;
            if (othermodel.type == "PILLAR") {
                //Pillar
                var pillar = new Pillar(othermodel);
                pillar.load(othermodel);
                added.push(pillar);
                ChangeModelMaterial(pillar, othermodel);
                utilEntityAddLink(fp, pillar);
                pillar.rot += 1;
                pillar.rot -= 1;

                entity = pillar;
            } else if (othermodel.type == "BEAM") {
                //Beam
                var beam = new Beam(othermodel);
                beam.load(othermodel);
                added.push(beam);
                ChangeModelMaterial(beam, othermodel);
                utilEntityAddLink(fp, beam);
                beam.rot += 1;
                beam.rot -= 1;

                entity = beam;
            } else if (othermodel.type == "BASEMENT") {
                //Basement
                var basement = new Basement(othermodel);
                basement.load(othermodel);
                added.push(basement);
                ChangeModelMaterial(basement, othermodel);
                utilEntityAddLink(fp, basement);
                basement.rot += 1;
                basement.rot -= 1;

                entity = basement;
            }

            //记录新的entityId
            othermodel.newId = entity.id;
        }), //end add by gaoning --2017.3.15

            //对area进行排序
            function addFloorAreaHandel() {
                var areas = [];
                for (var key in ghostFloorplan) {
                    var entity = ghostFloorplan[key];
                    if ((entity.type == RectArea.prototype.type || entity.type == RoundArea.prototype.type || entity.type == FreeArea.prototype.type) && entity.category == AREA_INNER_CATEGORY_ID) {
                        areas.push(entity);
                    }
                }
                ;
                areas.sort(function (a, b) {
                    return a.level - b.level;
                });
                addFloorArea && areas.forEach(function (prodMeta) {
                    var area = new TYPE[prodMeta.type](prodMeta);
                    area.load(prodMeta);
                    area.host = fp;
                    utilEntityAddLink(fp, area);
                    added.push(area);
                    if (prodMeta.areaMaterial && applyAreaMat) {
                        var mat = new TYPE[prodMeta.areaMaterial.type](prodMeta.areaMaterial);
                        mat.load(prodMeta.areaMaterial);
                        area.areaMaterial = mat;
                    }
                    if (area instanceof RectArea || area instanceof RoundArea) {
                        var center = new Point();
                        center.load(prodMeta.center);
                        area.center = center;
                    } else if (area instanceof FreeArea) {
                        var srcProfile = prodMeta.profile;
                        if (srcProfile.length < 3) return;
                        for (var i = 0, len = srcProfile.length; len > i; ++i) {
                            var srcCurve = srcProfile[i];
                            var curve = new Curve();
                            utilEntityAddLink(fp, curve);
                            curve.begin = new Point();
                            curve.end = new Point();
                            curve.begin.x = srcCurve.begin.x;
                            curve.begin.y = srcCurve.begin.y;
                            curve.end.x = srcCurve.end.x;
                            curve.end.y = srcCurve.end.y;
                            var profile = area.profile = area.profile || [];
                            profile[i] = curve;
                        }
                        utilModelChangeFlag(area, AREAFLAG_CHANGED_FOR_REDRAWN);
                    }

                    prodMeta.newId = area.id;
                    newAreas.push(area);
                })
            }(),
            applyFloorMat) {
        if (ghostRoom.floorMaterial) {
            var mat = new TYPE[ghostRoom.floorMaterial.type](ghostRoom.floorMaterial);
            mat.load(ghostRoom.floorMaterial), room.floorMaterial = mat;
        }
        if (ghostRoom.ceilingMaterial) {
            var mat = new TYPE[ghostRoom.ceilingMaterial.type](ghostRoom.ceilingMaterial);
            mat.load(ghostRoom.ceilingMaterial);
            room.ceilingMaterial = mat;
        }
    }
    if (addWallArea || applyWallMat) {
        var ghostWallsOrientationInfo = utilRoomGetWallsOrientationByCenter(ghostFloorCenter, ghostRoom.profile);
        var currentWallsOrientationInfo = utilRoomGetWallsOrientationByCenter(currentFloorCenter, room.profile);
        applyWallMat && (currentWallsOrientationInfo.forEach(function (currentWallOrientationInfo) {
            currentWallOrientationInfo.wall[currentWallOrientationInfo.side + "Material"] = new Material({
                pid: DEFAULT_TILE_MATERIAL_ID
            });
        }), [1, 2, 4, 8].forEach(function (orientation) {
            var ghostWallOrientationInfo = ghostWallsOrientationInfo.filter(function (info) {
                return 0 != (info.orientation & orientation);
            })[0];
            ghostWallOrientationInfo && currentWallsOrientationInfo.filter(function (info) {
                return 0 != (info.orientation & orientation);
            }).forEach(function (info) {
                var ghostMat = ghostWallOrientationInfo.wall[ghostWallOrientationInfo.side + "Material"];
                if (ghostMat) {
                    var newMat = new TYPE[ghostMat.type](ghostMat);
                    newMat.load(ghostMat);
                    info.wall[info.side + "Material"] = newMat;
                }
            });
        })), addWallArea && utilFloorplanLightFilterEntity(ghostFloorplan, function (entity) {
            return entity.type == RectArea3d.prototype.type || entity.type == RoundArea3d.prototype.type;
        }).forEach(function (ghostWall3dArea) {
            var ghostInfo = ghostWallsOrientationInfo.filter(function (ghostWallOrientationInfo) {
                return ghostWall3dArea.host == ghostWallOrientationInfo.wall;
            })[0];
            if (ghostInfo) {
                var matchInfo = currentWallsOrientationInfo.filter(function (currentWallOrientationInfo) {
                    return 0 != (currentWallOrientationInfo.orientation & ghostInfo.orientation);
                })[0];
                if (matchInfo) {
                    var area3d = new TYPE[ghostWall3dArea.type](ghostWall3dArea);
                    area3d.load(ghostWall3dArea);
                    area3d.category = matchInfo.side;
                    area3d.center = new Point();
                    area3d.center.x = area3d.center.y = 0;
                    area3d.host = matchInfo.wall;
                    utilEntityAddLink(fp, area3d);
                    added.push(area3d);
                    area3d.center.x = ghostWall3dArea.center.x;
                    area3d.center.y = ghostWall3dArea.center.y;
                    var ghostAreaMat = ghostWall3dArea.areaMaterial;
                    if (ghostAreaMat) {
                        var mat = new TYPE[ghostAreaMat.type](ghostAreaMat);
                        mat.load(ghostAreaMat);
                        area3d.areaMaterial = mat;
                    } else area3d.areaMaterial = new Material({
                        pid: DEFAULT_AREA_MATERIAL[area3d.category]
                    });
                }
            }
        });

        //套用增加波打线--add by gaoning
        utilFloorplanLightFilterEntity(ghostFloorplan, function (entity) {
            return entity.type == Boundary.prototype.type;
        }).forEach(function (boundary) {

            if (boundary.host.type == "FLOOR") {
                var bounHost = room;
                var boundaryEntity = new Boundary({host: bounHost, type: boundary.corner});
                utilEntityAddLink(fp, boundaryEntity);
                added.push(boundaryEntity);
                if (boundary.baseMaterial) {
                    var mat = new TYPE[boundary.baseMaterial.type](boundary.baseMaterial);
                    mat.load(boundary.baseMaterial);
                    boundaryEntity.baseMaterial = mat;
                }
                if (boundary.cornerMaterial) {
                    var mat = new TYPE[boundary.cornerMaterial.type](boundary.cornerMaterial);
                    mat.load(boundary.cornerMaterial);
                    boundaryEntity.cornerMaterial = mat;
                }
                if (boundary.leftMaterial) {
                    var mat = new TYPE[boundary.leftMaterial.type](boundary.leftMaterial);
                    mat.load(boundary.leftMaterial);
                    boundaryEntity.leftMaterial = mat;
                }
                if (boundary.rightMaterial) {
                    var mat = new TYPE[boundary.rightMaterial.type](boundary.rightMaterial);
                    mat.load(boundary.rightMaterial);
                    boundaryEntity.rightMaterial = mat;
                }
                boundary.newId = boundaryEntity.id;
                
                boundaryEntity.size = boundary.size;
                boundaryEntity.baseRot = boundary.baseRot;
                boundaryEntity.cornerRot = boundary.cornerRot;
                boundaryEntity.leftRot = boundary.leftRot;
                boundaryEntity.rightRot = boundary.rightRot;
                boundaryEntity.level = bounHost.level;
                boundaryEntity.baseOffsetX = boundary.baseOffsetX || [];

            } else if (boundary.host.type == "RECTAREA" || boundary.host.type == "FREEAREA") {

                var areaHost = null;
                for (var a = 0; a < newAreas.length; a++) {
                    if (boundary.host.newId == newAreas[a].id) {
                        areaHost = newAreas[a];
                    }
                }
                if (areaHost != null) {
                    var boundaryEntity = new Boundary({host: areaHost, type: boundary.corner});
                    utilEntityAddLink(fp, boundaryEntity);
                    added.push(boundaryEntity);
                    if (boundary.baseMaterial) {
                    var mat = new TYPE[boundary.baseMaterial.type](boundary.baseMaterial);
		                    mat.load(boundary.baseMaterial);
		                    boundaryEntity.baseMaterial = mat;
		                }
		                if (boundary.cornerMaterial) {
		                    var mat = new TYPE[boundary.cornerMaterial.type](boundary.cornerMaterial);
		                    mat.load(boundary.cornerMaterial);
		                    boundaryEntity.cornerMaterial = mat;
		                }
		                if (boundary.leftMaterial) {
		                    var mat = new TYPE[boundary.leftMaterial.type](boundary.leftMaterial);
		                    mat.load(boundary.leftMaterial);
		                    boundaryEntity.leftMaterial = mat;
		                }
		                if (boundary.rightMaterial) {
		                    var mat = new TYPE[boundary.rightMaterial.type](boundary.rightMaterial);
		                    mat.load(boundary.rightMaterial);
		                    boundaryEntity.rightMaterial = mat;
		                }
                    
                    boundary.newId = boundaryEntity.id;
                    
                    boundaryEntity.size = boundary.size;
		                boundaryEntity.baseRot = boundary.baseRot;
		                boundaryEntity.cornerRot = boundary.cornerRot;
		                boundaryEntity.leftRot = boundary.leftRot;
		                boundaryEntity.rightRot = boundary.rightRot;
		                boundaryEntity.level = areaHost.level;
		                boundaryEntity.baseOffsetX = boundary.baseOffsetX || [];
                    
                }
            }

        });

    }
    //console.log("get this added###");
    //console.log(added);

    //重新生成group组成员
    utilFloorplanLightFilterEntity(ghostFloorplan, function (entity) {
        return entity.type == Group.prototype.type;
    }).forEach(function (groupmodel) {
        var groupCount = utilAppFloorplanFilterEntity(application, function (e) {
            return e.type == "GROUP";
        });

        if (groupmodel.flag != 0) {
            var group = new Group();
            group.name = "我的组合-" + (groupCount <= 10 ? "0" : "") + groupCount;

            groupmodel.children.forEach(function (child) {
                var model = Root.prototype.database[child.newId];
                if (model) {
                    //添加model到组
                    utilGroupAddItem(group, model);
                }
            });

            if (group.children.length > 0) {
                utilEntityAddLink(fp, group);
                //刷新组中心
                utilGroupUpdateCenter(fp, group);
            }
        }
    });


    room.applyModelRoomComplete.dispatch(room, ghostRoom, added, removed);
}
function ChangeModelMaterial(model, material) {
    //backmaterial
    var backMaterial = material.backMaterial;
    if (model && backMaterial) {
        var mat = new TYPE[backMaterial.type](backMaterial);
        mat.load(backMaterial);
        model.backMaterial = mat;
    } //else model.backMaterial = new Material({ pid: DEFAULT_AREA_MATERIAL[material.backMaterial]});
    //bottomMaterial
    var bottomMaterial = material.bottomMaterial;
    if (model && bottomMaterial) {
        var mat = new TYPE[bottomMaterial.type](bottomMaterial);
        mat.load(bottomMaterial);
        model.bottomMaterial = mat;
    }// else model.bottomMaterial = new Material({pid: DEFAULT_AREA_MATERIAL[material.bottomMaterial]});
    //frontMaterial
    var frontMaterial = material.frontMaterial;
    if (model && frontMaterial) {
        var mat = new TYPE[frontMaterial.type](frontMaterial);
        mat.load(frontMaterial);
        model.frontMaterial = mat;
    } //else model.frontMaterial = new Material({pid: DEFAULT_AREA_MATERIAL[material.frontMaterial]});
    //leftMaterial
    var leftMaterial = material.leftMaterial;
    if (model && leftMaterial) {
        var mat = new TYPE[leftMaterial.type](leftMaterial);
        mat.load(leftMaterial);
        model.leftMaterial = mat;
    }// else model.leftMaterial = new Material({pid: DEFAULT_AREA_MATERIAL[material.leftMaterial]});
    //rightMaterial
    var rightMaterial = material.rightMaterial;
    if (model && rightMaterial) {
        var mat = new TYPE[rightMaterial.type](rightMaterial);
        mat.load(rightMaterial);
        model.rightMaterial = mat;
    } //else model.rightMaterial = new Material({pid: DEFAULT_AREA_MATERIAL[material.rightMaterial]});
    //topMaterial
    var topMaterial = material.topMaterial;
    if (model && topMaterial) {
        var mat = new TYPE[topMaterial.type](topMaterial);
        mat.load(topMaterial);
        model.topMaterial = mat;
    } //else model.topMaterial = new Material({pid: DEFAULT_AREA_MATERIAL[material.topMaterial]});

}

//加载套用空间的内容-- gaoning
function utilAppFloorplanResetRoom(app, floorplan, room, option) {
    var fp = floorplan || app.doc.floorplan;
    var addFloorArea = !!option && option.floorarea === !0;
    var addWallArea = !!option && option.wallarea === !0;
    var removeOldProduct = (!!option && option.product_add_new === !0, !!option && option.product_remove_old === !0);
    var applyFloorMat = !!option && option.floorMaterial === !0;
    var applyWallMat = (!!option && option.areaMaterial === !0, !!option && option.wallMaterial === !0);
    //start add by gaoning 2017.3.14
    //var product_model_material = !!option && option.product_model_material === !0;
    //var product_other_model = !!option && option.product_other_model === !0;
    var product_other_model_delete = !!option && option.product_other_model_delete === !0;
    //end add by gaoning 2017.3.14

    var currentFloorInfo = utilFloorGetRoomInfo(app, room, fp);
    var currentFloorLoop = room.getLoop();
    var currentFloorCenter = utilMathPolyMassCenter(currentFloorLoop);
    var removed = [];
    removeOldProduct && (currentFloorInfo.products.forEach(function (prod) {
        utilEntityRemoveLink(fp, prod), removed.push(prod);
    }) || currentFloorInfo.productsReplacement.forEach(function (prod) {
        utilEntityRemoveLink(fp, prod), removed.push(prod);
    })),
        //add by gaoning 移除原有的构造体
    product_other_model_delete && currentFloorInfo.othermodels.forEach(function (prod) {
        utilEntityRemoveLink(fp, prod), removed.push(prod);
    }),

    addFloorArea && currentFloorInfo.areas.forEach(function (area) {
        area.profile && area.profile.forEach(function (curve) {
            curve && (curve.begin = void 0, curve.end = void 0, utilEntityRemoveLink(this.fp, curve));
        }, this), utilEntityRemoveLink(fp, area), removed.push(area);
    }), applyFloorMat &&  utilCatalogGetProductsMetaPromise(application.catalogMgr, [DEFAULT_FLOOR_MATERIAL_ID, DEFAULT_TILE_MATERIAL_ID]).then(function (meta) {
            room.floorMaterial = new Material(meta[DEFAULT_FLOOR_MATERIAL_ID]);
            room.ceilingMaterial = new Material(meta[DEFAULT_TILE_MATERIAL_ID]);
            room.paveType = "SINGLEPAVE_01";
        });


    var currentWallsOrientationInfo = utilRoomGetWallsOrientationByCenter(currentFloorCenter, room.profile);
    return applyWallMat && currentWallsOrientationInfo.forEach(function (currentWallOrientationInfo) {
        currentWallOrientationInfo.wall[currentWallOrientationInfo.side + "Material"] = new Material({
            pid: DEFAULT_TILE_MATERIAL_ID
        });
    }), addWallArea && currentWallsOrientationInfo.forEach(function (currentWallOrientationInfo) {
        var areas3d = utilAppFloorplanGetAreasByHostId(app, fp, currentWallOrientationInfo.wall.id, currentWallOrientationInfo.side);
        areas3d.forEach(function (area3d) {
            utilEntityRemoveLink(fp, area3d), removed.push(area3d);
        });
    }), removed;
}

function utilFloorplanLightFilterEntity(fp, filterFn) {
    return filterFn ? Object.keys(fp).map(function (id) {
        return fp[id];
    }).filter(filterFn) : [];
}

function utilFloorplanLightBuildFromObject(floorplanLight) {
    return Object.keys(floorplanLight).forEach(function (id) {
        var entity = floorplanLight[id];
        entity.lf = entity.lt = [], delete entity.id;
        for (var key in entity) {
            var val = entity[key];
            if ("string" == typeof val && 0 == val.indexOf("id")) {
                entity[key] = floorplanLight[val];
            } else if (Array.isArray(val)) {
                entity[key] = val.map(function (id) {
                    if ("string" == typeof id && 0 == id.indexOf("id")) {
                        //console.log("111111111111111111111111111");
                        //console.log(floorplanLight[id]);
                        return floorplanLight[id];
                    } else {
                        //console.log("222222222222222222222222");
                        //console.log(id);
                        return id;
                    }

                });
            }
        }
    }), floorplanLight;
}


function utilFloorGetMeasurement(floor, type) {
    var floor_loop = utilFloorGetLoopFromProfile(floor);
    if (!floor_loop)
        return 0;

    var centerMeasurment = Math.abs(utilMathPolyMeasurement(floor_loop));
    var wallsMeasurement = 0;
    for (var i = 0; i < floor.profile.length; ++i) {
        var wall = floor.profile[i];
        var startPt = floor_loop[i];
        var endPt = floor_loop[i + 1];
        wallsMeasurement += wall.width * utilMathLineLength(startPt, endPt);
    }

    if ("inner" == type) {
        //return centerMeasurment - wallsMeasurement / 2;
        var floor_insideloop = utilFloorInsideLoopFromProfile(floor);
        if (!floor_insideloop)
            return 0;
        floor_insideloop.push(floor_insideloop[0]);
        return Math.abs(utilMathPolyMeasurement(floor_insideloop));
    } else if ("outer" == type) {
        return centerMeasurment + wallsMeasurement / 2;
    } else {
        return centerMeasurment;
    }
}

function utilFloorSetFromProfile(floor, profile, sketches) {
    floor.profile = profile;
    utilModelChangeFlag(floor, FLOORFLAG_CHANGED_FOR_REDRAWN);
}

function utilIsProfileValid(profile) {
    var loop = utilGetLoopFromProfile(profile);
    if (!loop) return !1;
    if (loop.length < 3) return !1;
    for (var loopNormalized = [loop[0]], i = 0, len = loop.length; len > i; ++i) {
        var pt = loop[i];
        utilMathIsSamePoint(pt, loopNormalized[loopNormalized.length - 1], .01) || loopNormalized.push(pt);
    }
    loop = loopNormalized;
    for (var i = 1, len = loop.length; len > i; ++i) for (var pt = loop[i], j = i + 1; len > j; ++j) {
        var comparedPt = loop[j];
        if (utilMathIsSamePoint(pt, comparedPt, .05)) return !1;
    }
    return !0;
}

function utilFloorGetLoopFromProfile(floor, opt) {
    return utilGetLoopFromProfile(floor.profile, opt);
}

function utilGetLoopFromProfile(profile, opt) {
    var geom = [];
    var tol = .05;
    var removeDuplicated = opt && opt.removeDuplicated === !0;
    for (var i = 0, len = profile.length; len >= i; ++i) {
        var point;
        var wall1 = profile[i % len];
        var wall2 = profile[(i + 1) % len];
        if (!(wall1 && wall2 && wall1.begin && wall1.end && wall2.begin && wall2.end))
            return;
        if (utilMathIsLineParallel(wall1.begin, wall1.end, wall2.begin, wall2.end, tol)) {
            if (utilMathIsSamePoint(wall1.begin, wall2.begin, tol)) {
                point = wall1.begin;
            } else {
                if (utilMathIsSamePoint(wall1.end, wall2.begin, tol)) {
                    point = wall1.end;
                } else {
                    if (utilMathIsSamePoint(wall1.begin, wall2.end, tol)) {
                        point = wall1.begin;
                    } else {
                        utilMathIsSamePoint(wall1.end, wall2.end, tol) && (point = wall1.end);
                    }
                }
            }
        } else {
            point = utilMathLineLineIntersection(wall1.begin, wall1.end, wall2.begin, wall2.end);
        }

        if (!point || isNaN(point.x) || isNaN(point.y)) {
            return void __assert(!1, "build floor loop failed");
        }
        geom.push(point);
    }
    if (removeDuplicated === !0) for (var i = geom.length - 2; i >= 0; --i) {
        var thisPt = geom[i];
        var nextPt = geom[i + 1];
        utilMathIsSamePoint(thisPt, nextPt, .05) && geom.splice(i + 1, 1);
    }
    return geom.length < 3 ? void __assert(!1, "loop should have at least 3 points") : geom;
}

function utilFloorGetRoomInfo(app, floor, floorplan) {
    var fp = floorplan || app.doc.floorplan;
    var floor_loop = utilFloorGetLoopFromProfile(floor);
    var floor_insideLoop = utilFloorInsideLoopFromProfile(floor);
    var center = utilMathPolyMassCenter(floor_loop);
    var measurement = {
        center: floor.getMeasurement(),
        inner: floor.getMeasurement("inner"),
        outer: floor.getMeasurement("outer")
    };
    var areasInRoom = [];
    var areas = utilAppFloorplanGetAreasByHostId(app, fp, fp.id, AREA_INNER_CATEGORY_ID);

    for (var i = 0, len = areas.length; len > i; ++i) {
        var area = areas[i], area_in_floor = !0;
        if (area.isValid()) {
            for (var area_loop = area.getLoop(), j = 0, loopLen = area_loop && area_loop.length || 0; loopLen > j; ++j) {
                var pt = area_loop[j];
                area_in_floor && (area_in_floor = utilMathIsPointInPoly(floor_insideLoop, pt));
            }
            area_in_floor && areasInRoom.push(area);
            //areasInRoom.push(area);//修改为只要区域进入房间中，就认定属于该房间的区域
        }
    }

    var productsInRoom = [];
    var productsReplacementInRoom = [];
    var othermodelsInRoom = [];
    return utilFloorplanForEachProduct(fp, function (prod) {
        prod.type == Product.prototype.type && utilMathIsPointInPoly(floor_loop, prod) && productsInRoom.push(prod);
    }), utilFloorplanForEachProduct(fp, function (prod) {
        prod.type == ProductReplacement.prototype.type && utilMathIsPointInPoly(floor_loop, prod) && productsReplacementInRoom.push(prod);
    }), utilFloorplanForEachProduct(fp, function (prod) {
        (prod.type == Pillar.prototype.type || prod.type == Beam.prototype.type || prod.type == Basement.prototype.type) && utilMathIsPointInPoly(floor_loop, prod) && othermodelsInRoom.push(prod);
    }), {
        center: center,
        measurement: measurement,
        areas: areasInRoom,
        products: productsInRoom,
        productsReplacement: productsReplacementInRoom,
        othermodels: othermodelsInRoom
    };
}

function utilRoomGetWallsOrientationByCenter(roomCenter, walls) {
    var wallsInfo = [];
    return walls.forEach(function (wall) {
        var info = {
            wall: wall,
            orientation: 0,
            side: ""
        }, begin = wall.begin, end = wall.end;
        begin.x > roomCenter.x && end.x > roomCenter.x && (info.orientation |= 1), begin.y < roomCenter.y && end.y < roomCenter.y && (info.orientation |= 2),
        begin.x < roomCenter.x && end.x < roomCenter.x && (info.orientation |= 4), begin.y > roomCenter.y && end.y > roomCenter.y && (info.orientation |= 8);
        var angle = utilMathLinelineCCWAngle(begin, end, roomCenter);
        info.side = 180 > angle ? "left" : "right", wallsInfo.push(info);
    }), wallsInfo;
}

//gaoning 创建框选基类
function SclectionArea(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "center", void 0, linkChanged);
    utilRootDefineProperty(this, "width", 0, propertyChanged);
    utilRootDefineProperty(this, "height", 0, propertyChanged);
    utilRootDefineProperty(this, "rot", 0, propertyChanged);
}

function utilAreaGetMeasument(app, area) {
    var loop = area.getLoop();
    return loop ? utilMathPolyMeasurement(loop) : 0;
}

//判断区域是否在房间内-- gaoning
function utilAreaGetHostRoom(area) {
    var loop = area.getLoop();
    var center = (application.doc.floorplan, utilMathPolyMassCenter(loop));

    var rooms = utilAppFloorplanFilterEntity(application, function (e) {
        return e.type == Floor.prototype.type;
    }).filter(function (room) {
        return utilMathIsPointInPoly(room.getLoop(), center);
    });
    return rooms[0];
}

function utilRectAreaNormalize(area) {
    if (area) {
        var rot = (area.rot + 360) % 360, dir = rot / 45;
        if (!(dir >= 0 && 1 >= dir)) if (dir > 1 && 3 >= dir) {
            var w = area.width;
            area.width = area.height, area.height = w, area.rot = rot - 90;
        } else if (dir > 3 && 5 >= dir) area.rot = rot - 180; else if (dir > 5 && 7 >= dir) {
            var w = area.width;
            area.width = area.height, area.height = w, area.rot = rot - 270;
        } else dir > 7 && 8 > dir ? area.rot = rot - 360 : __assert(!1, "please check RectArea rotate angle");
    }
}

//计算两区域位置点--gaoning
function utilRectAreaGetSidePoints(area, side) {
    var center = area.center;
    var rot = area.rot;
    var width = area.width;
    var height = area.height;
    var points = RECT_SIDE_POINTS_OFFSET_FACTOR_MAP[side].map(function (info) {
        var beforeRot = {
            x: info.x * width / 2 + center.x,
            y: info.y * height / 2 + center.y
        };
        return utilMathRotatePointCW(center, beforeRot, rot);
    });
    return points;
}

//start add by gaoning --获取区域的四个顶点--
function utilRectAreaGetSidePoints4(area, side) {
    var center = area.center;
    var rot = area.rot;
    var width = area.width;
    var height = area.height;
    var points4 = [];
    //1
    RECT_SIDE_POINTS_OFFSET_FACTOR_MAP[side].map(function (info) {
        var beforeRot = {
            x: info.x * width / 2 + center.x,
            y: info.y * height / 2 + center.y
        };
        points4.push(utilMathRotatePointCW(center, beforeRot, rot));
    });
    //2
    RECT_SIDE_POINTS_OFFSET_FACTOR_MAP[side].map(function (info) {
        var beforeRot = {
            x: info.x * width / 2 - center.x,
            y: info.y * height / 2 - center.y
        };
        points4.push(utilMathRotatePointCW(center, beforeRot, rot));
    });
    //3
    RECT_SIDE_POINTS_OFFSET_FACTOR_MAP[side].map(function (info) {
        var beforeRot = {
            x: info.x * width / 2 + center.x,
            y: info.y * height / 2 - center.y
        };
        points4.push(utilMathRotatePointCW(center, beforeRot, rot));
    });
    //4
    RECT_SIDE_POINTS_OFFSET_FACTOR_MAP[side].map(function (info) {
        var beforeRot = {
            x: info.x * width / 2 - center.x,
            y: info.y * height / 2 + center.y
        };
        points4.push(utilMathRotatePointCW(center, beforeRot, rot));
    });

    return points4;
}
//end add by gaoning

function utilRectAreaGetSideMoveDir(area, side) {
    var sideVec = RECT_SIDE_VECTOR_MAP[side], rot = area.rot, moveDir = utilMathRotatePointCW({
        x: 0,
        y: 0
    }, sideVec, rot);
    return moveDir;
}

function utilRectAreaEdgeSnap(area, side) {
    var candidateSidePoints = utilRectAreaGetSnappedEdges(area, side);
    if (candidateSidePoints && 0 != candidateSidePoints.length) {
        var thisSideMoveDir = utilRectAreaGetSideMoveDir(area, side);
        var thisSidePoints = utilRectAreaGetSidePoints(area, side);
        var thisSideLine = new Line(thisSidePoints[0].x, thisSidePoints[0].y, thisSidePoints[1].x, thisSidePoints[1].y);
        var center = {
            x: area.center.x,
            y: area.center.y
        };
        var candidateSidePoint = candidateSidePoints[0].points[0];
        var perpedicular = thisSideLine.getClosestPoint(candidateSidePoint.x, candidateSidePoint.y);
        var sideVec = RECT_SIDE_VECTOR_MAP[side];
        var moveLength = Vec2.dot(thisSideMoveDir, {
            x: candidateSidePoint.x - perpedicular.x,
            y: candidateSidePoint.y - perpedicular.y
        });
        var centerBeforeRotate = {
            x: center.x,
            y: center.y
        };
        var width = area.width;
        var height = area.height;
        "left" == side || "right" == side ? (width = Math.abs(width + moveLength),
            centerBeforeRotate.x += moveLength * sideVec.x / 2) : "top" != side && "bottom" != side || (height = Math.abs(height + moveLength),
            centerBeforeRotate.y += moveLength * sideVec.y / 2);
        var centerRotated = utilMathRotatePointCW(center, centerBeforeRotate, area.rot);
        area.center.x = centerRotated.x;
        area.center.y = centerRotated.y;
        area.width = width;
        area.height = height;
    }
}

//3333333区域自动吸附--gaoning
function utilRectAreaGetSnappedEdges(area, side) {

    var snap_tolerance = AREA_SNAP_TOLERANCE;//无作用
    if (area && area.isValid()) {
        var fixRot = utilModelCheckRegularRotation(area, !0);
        if (fixRot) {
            var thisSidePoints = utilRectAreaGetSidePoints(area, side);
            var thisSideLine = new Line(thisSidePoints[0].x, thisSidePoints[0].y, thisSidePoints[1].x, thisSidePoints[1].y);
            var room = utilAreaGetHostRoom(area);
            var otherAreaInRoom = utilAppFloorplanFilterEntity(application, function (e) {
                return e.type == RectArea.prototype.type;
            }).filter(function (a) {
                //return a.id != area.id;//注释：修改区域的吸附功能，不应该只在同一房间内的区域才有吸附功能，所有的区域都要吸附功能，关闭对房间的判断。
                return room && a.id != area.id && utilMathIsPointInPoly(room.getLoop(), a.center);
            });
            var allCandidateSidesInfo = [];
            var other = otherAreaInRoom.forEach(function (other) {
                other && other.isValid() && utilModelCheckRegularRotation(other, !1) && Object.keys(RECT_SIDE_VECTOR_MAP).forEach(function (side) {
                    var sidePts = utilRectAreaGetSidePoints(other, side);
                    utilMathIsLineParallel(thisSidePoints[0], thisSidePoints[1], sidePts[0], sidePts[1]) && allCandidateSidesInfo.push({
                        area: other,
                        side: side,
                        points: sidePts
                    });
                });
            });
            var all = allCandidateSidesInfo.filter(function (candidateSidesInfo) {
                var candidateSidePoint = candidateSidesInfo.points[0];
                var perpedicular = thisSideLine.getClosestPoint(candidateSidePoint.x, candidateSidePoint.y);
                var twoLineDistance = utilMathLineLength(perpedicular, candidateSidePoint);
                return snap_tolerance > twoLineDistance;
            });

            return all;
        } else {
            return [];
        }
    }
}

//2222222222区域自动吸附
function utilRectAreaCenterSnap(area) {
    var snap_tolerance = AREA_SNAP_TOLERANCE;  //无作用
    if (area && area.isValid() && area && area.center && !isNaN(area.center.x)) {
        var room = (application.doc.floorplan, utilAreaGetHostRoom(area));
        var otherAreaInRoom = utilAppFloorplanFilterEntity(application, function (e) {
            return e.type == RectArea.prototype.type || e.type == RoundArea.prototype.type;
        }).filter(function (a) {
            //return a.id != area.id;//注释：修改区域的吸附功能，不应该只在同一房间内的区域才有吸附功能，所有的区域都要吸附功能，关闭对房间的判断。
            return room && a.id != area.id && utilMathIsPointInPoly(room.getLoop(), a.center);
        });
        var snap = {};
        for (var i = 0, len = otherAreaInRoom.length; len > i; ++i) {
            var staticArea = otherAreaInRoom[i];
            if (staticArea && staticArea.isValid() && staticArea.center && !isNaN(staticArea.center.y) && utilMathEquals(staticArea.center.y, area.center.y, snap_tolerance)) {
                area.center.y = staticArea.center.y;
                snap.horizental = staticArea.center;
                break;
            }
        }
        for (var i = 0, len = otherAreaInRoom.length; len > i; ++i) {
            var staticArea = otherAreaInRoom[i];
            if (staticArea && staticArea.isValid() && staticArea.center && !isNaN(staticArea.center.x) && utilMathEquals(staticArea.center.x, area.center.x, snap_tolerance)) {
                area.center.x = staticArea.center.x;
                snap.vertical = staticArea.center;
                break;
            }
        }
        return snap;
    }
}

//1111111111区域自动吸附--gaoning
function utilRectAreaBoundSnap(area) {

    var snap_tolerance = AREA_SNAP_TOLERANCE;//吸附生效的最小距离
    if (area && area.isValid() && area && area.center && !isNaN(area.center.x)) {
        var centerSnap = utilRectAreaCenterSnap(area);
        var sides = Object.keys(RECT_SIDE_VECTOR_MAP);
        //console.log(sides);
        var needHorizental = !centerSnap || !centerSnap.horizental;
        var needVertical = !centerSnap || !centerSnap.vertical;
        for (var i = 0; i < sides.length && (needHorizental || needVertical); ++i) {
            var side = sides[i];
            var thisSidePts = utilRectAreaGetSidePoints(area, side);
            var snappedEdges = utilRectAreaGetSnappedEdges(area, side);
            var snappedEdgesCount = snappedEdges.length;

            if (needHorizental && utilMathEquals(thisSidePts[0].y, thisSidePts[1].y)) {
                for (var j = 0; snappedEdgesCount > j; ++j) {
                    var snappedEdge = snappedEdges[j];
                    var snappedEdgePoints = snappedEdge.points;
                    if (utilMathEquals(snappedEdgePoints[0].y, snappedEdgePoints[1].y)) {
                        var offsetHorizental = thisSidePts[0].y - snappedEdgePoints[0].y;
                        if (Math.abs(offsetHorizental) < snap_tolerance) {
                            area.center.y = area.center.y - offsetHorizental;
                            needHorizental = !1;
                            break;
                        }
                    }
                }
            }
            if (needVertical && utilMathEquals(thisSidePts[0].x, thisSidePts[1].x)) {
                for (var j = 0; snappedEdgesCount > j; ++j) {
                    var snappedEdge = snappedEdges[j];
                    var snappedEdgePoints = snappedEdge.points;
                    if (utilMathEquals(snappedEdgePoints[0].x, snappedEdgePoints[1].x)) {
                        var offsetVertical = thisSidePts[0].x - snappedEdgePoints[0].x;
                        if (Math.abs(offsetVertical) < snap_tolerance) {
                            area.center.x = area.center.x - offsetVertical;
                            needVertical = !1;
                            break;
                        }
                    }
                }
            }
        }
    }
}

//33333天花吸附功能--add by gaoning 2017.12.8
function utilRectCeilingBoundSnap(ceiling) {

    return;//关闭天花吸咐功能。

    var snap_tolerance = AREA_SNAP_TOLERANCE;//吸附生效的最小距离
    if (ceiling && ceiling.isValid()) {
        var centerSnap = utilCeilingCenterSnap(ceiling);
        var sides = Object.keys(RECT_SIDE_VECTOR_MAP);
        //console.log(sides);
        var needHorizental = !centerSnap || !centerSnap.horizental;
        var needVertical = !centerSnap || !centerSnap.vertical;
        for (var i = 0; i < sides.length && (needHorizental || needVertical); ++i) {
            var side = sides[i];
            var thisSidePts = utilCeilingGetSidePoints(ceiling, side);
            var snappedEdges = utilCeilingGetSnappedEdges(ceiling, side);
            var snappedEdgesCount = snappedEdges.length;

            if (needHorizental && utilMathEquals(thisSidePts[0].y, thisSidePts[1].y)) {
                for (var j = 0; snappedEdgesCount > j; ++j) {
                    var snappedEdge = snappedEdges[j];
                    var snappedEdgePoints = snappedEdge.points;
                    if (utilMathEquals(snappedEdgePoints[0].y, snappedEdgePoints[1].y)) {
                        var offsetHorizental = thisSidePts[0].y - snappedEdgePoints[0].y;
                        if (Math.abs(offsetHorizental) < snap_tolerance) {
                            ceiling.y = ceiling.y - offsetHorizental;
                            needHorizental = !1;
                            break;
                        }
                    }
                }
            }
            if (needVertical && utilMathEquals(thisSidePts[0].x, thisSidePts[1].x)) {
                for (var j = 0; snappedEdgesCount > j; ++j) {
                    var snappedEdge = snappedEdges[j];
                    var snappedEdgePoints = snappedEdge.points;
                    if (utilMathEquals(snappedEdgePoints[0].x, snappedEdgePoints[1].x)) {
                        var offsetVertical = thisSidePts[0].x - snappedEdgePoints[0].x;
                        if (Math.abs(offsetVertical) < snap_tolerance) {
                            ceiling.x = ceiling.x - offsetVertical;
                            needVertical = !1;
                            break;
                        }
                    }
                }
            }
        }
    }
}
//444444天花吸附
function utilCeilingCenterSnap(ceiling) {
    var snap_tolerance = AREA_SNAP_TOLERANCE;  //无作用
    if (ceiling && ceiling.isValid()) {
        var room = (application.doc.floorplan, utilCeilingGetHostRoom(ceiling));

        console.log(room);

        var otherAreaInRoom = utilAppFloorplanFilterEntity(application, function (e) {
            return e.type == Product.prototype.type;
        }).filter(function (a) {
            //return a.id != area.id;//注释：所有的天花都要吸附功能，关闭对房间的判断。
            return room && a.id != ceiling.id && utilMathIsPointInPoly(room.getLoop(), {x: a.x,y: a.y});
        });
        var snap = {};
        for (var i = 0, len = otherAreaInRoom.length; len > i; ++i) {
            var staticArea = otherAreaInRoom[i];
            if (staticArea && staticArea.isValid() && utilMathEquals(staticArea.y, ceiling.y, snap_tolerance)) {
                ceiling.y = staticArea.y;
                snap.horizental = {x:staticArea.x,y:staticArea.y};
                break;
            }
        }
        for (var i = 0, len = otherAreaInRoom.length; len > i; ++i) {
            var staticArea = otherAreaInRoom[i];
            if (staticArea && staticArea.isValid() && utilMathEquals(staticArea.x, ceiling.x, snap_tolerance)) {
                ceiling.x = staticArea.x;
                snap.vertical = {x:staticArea.x,y:staticArea.y};
                break;
            }
        }
        return snap;
    }
}

//55555天花吸附--gaoning
function utilCeilingGetSnappedEdges(ceiling, side) {

    var snap_tolerance = AREA_SNAP_TOLERANCE;//无作用
    if (ceiling && ceiling.isValid()) {
        var fixRot = utilModelCheckRegularRotation(ceiling, !0);
        if (fixRot) {
            var thisSidePoints = utilCeilingGetSidePoints(ceiling, side);
            var thisSideLine = new Line(thisSidePoints[0].x, thisSidePoints[0].y, thisSidePoints[1].x, thisSidePoints[1].y);
            var room = utilCeilingGetHostRoom(ceiling);
            var otherAreaInRoom = utilAppFloorplanFilterEntity(application, function (e) {
                return e.type == Product.prototype.type;
            }).filter(function (a) {
                //return a.id != area.id;//注释：修改区域的吸附功能，不应该只在同一房间内的区域才有吸附功能，所有的区域都要吸附功能，关闭对房间的判断。
                return room && a.id != ceiling.id && utilMathIsPointInPoly(room.getLoop(), {x:a.x,y: a.y});
            });
            var allCandidateSidesInfo = [];
            var other = otherAreaInRoom.forEach(function (other) {
                other && other.isValid() && utilModelCheckRegularRotation(other, !1) && Object.keys(RECT_SIDE_VECTOR_MAP).forEach(function (side) {
                    var sidePts = utilCeilingGetSidePoints(other, side);
                    utilMathIsLineParallel(thisSidePoints[0], thisSidePoints[1], sidePts[0], sidePts[1]) && allCandidateSidesInfo.push({
                        area: other,
                        side: side,
                        points: sidePts
                    });
                });
            });
            var all = allCandidateSidesInfo.filter(function (candidateSidesInfo) {
                var candidateSidePoint = candidateSidesInfo.points[0];
                var perpedicular = thisSideLine.getClosestPoint(candidateSidePoint.x, candidateSidePoint.y);
                var twoLineDistance = utilMathLineLength(perpedicular, candidateSidePoint);
                return snap_tolerance > twoLineDistance;
            });

            return all;
        } else {
            return [];
        }
    }
}


//判断天花是否在房间内-- gaoning
function utilCeilingGetHostRoom(ceiling) {
    var loop = ceiling.getLoop();
    var center = (application.doc.floorplan, utilMathPolyMassCenter(loop));

    var rooms = utilAppFloorplanFilterEntity(application, function (e) {
        return e.type == Floor.prototype.type;
    }).filter(function (room) {
        return utilMathIsPointInPoly(room.getLoop(), center);
    });
    return rooms[0];
}
//计算两天花位置点--gaoning
function utilCeilingGetSidePoints(ceiling, side) {
    var center = {x:ceiling.x,y:ceiling.y};
    var rot = ceiling.rot;
    var width = ceiling.sx * ceiling.meta.xlen;
    var height = ceiling.sy * ceiling.meta.ylen;
    var points = RECT_SIDE_POINTS_OFFSET_FACTOR_MAP[side].map(function (info) {
        var beforeRot = {
            x: info.x * width / 2 + center.x,
            y: info.y * height / 2 + center.y
        };
        return utilMathRotatePointCW(center, beforeRot, rot);
    });
    return points;
}
///////////////////////////////////////////////////////////////////////////////////////

function utilRoundAreaCenterSanp(area) {
    return utilRectAreaCenterSnap(area);
}

function Camera(opt) {
    classBase(this, opt);
    var cb = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "x", 0, cb);
    utilRootDefineProperty(this, "y", 0, cb);
    utilRootDefineProperty(this, "z", 1.2, cb);
    utilRootDefineProperty(this, "tx", 1.5, cb);
    utilRootDefineProperty(this, "ty", 1.5, cb);
    utilRootDefineProperty(this, "hfov", 60, cb);
    utilRootDefineProperty(this, "pitch", 0, cb);
    utilRootDefineProperty(this, "znear", .3, cb);
    utilRootDefineProperty(this, "active", !1, cb);
    utilRootDefineProperty(this, "radian", 0, cb);
    utilRootDefineProperty(this, "tradian", 0, cb);
    utilRootDefineProperty(this, "lock", !1, cb);   //add by hcw 增加相机锁属性
    this.name = "";   //add by gaoning 2016.12.8  -- 增加两属性值。
}

function Material(meta) {
    classBase(this, meta);
    this.meta = meta;
    this.pid = meta && meta.pid;
    /*初始化时进来了这里 add by oxl 2017-03-30*/
    this.category = meta && meta.category || "product";
    this._url = void 0;
    __assert(void 0 != this.pid, "Material needs pid.");
    var propertyChanged = (linkPropertyChangedCalllback.bind(this), entityPropertyChangedCallback.bind(this));
    utilRootDefineProperty(this, "tx", 0, propertyChanged);
    utilRootDefineProperty(this, "ty", 0, propertyChanged);
    utilRootDefineProperty(this, "sx", 1, propertyChanged);
    utilRootDefineProperty(this, "sy", 1, propertyChanged);
    utilRootDefineProperty(this, "rot", 0, propertyChanged);
    this.reflection = materialGetExtraParameter(this.meta, "reflection") || DEFAULT_MATERIAL_REFLECTION;
    this.reflection_glossiness = materialGetExtraParameter(this.meta, "reflection_glossiness") || DEFAULT_MATERIAL_REFLECTION_GLOSSINESS;
}

/*添加自定义产品或者新产品时对应的url拼接，例如 custom_tile add by oxl 2017-03-30
 * 自定义拼花添加到画布第二步 "custom_tile" != cat;
 * */
function utilMaterialGetUrl(material, type) {
    if (material._url) 
        return material._url;
    var cat = material.category;
    "tile" != cat && "customparquet" != cat && "custom_tile" != cat && "color" != cat || (cat = "product");
    var url = utilCatalogGetFileUrl(application.catalogMgr, cat, material.pid, type || "top", "jpg");
    return material._url = url, url;
}

function materialGetRasterizedOffsetFromUV(material, uv) {
    if (material && material instanceof Material) {
        var meta = material.meta, scale = material.getScale(), result = new Vec2(uv.x, uv.y);
        result.subtract({
            x: material.tx,
            y: -material.ty
        });
        result.rotate(utilMathToRadius(material.rot));
        result.scale(1 / scale.x, 1 / scale.y);
        result.scale(1 / parseFloat(meta.xlen), 1 / parseFloat(meta.ylen));
        return result;
    }
}

function materialComputeRasterizedTranslationFromOffset(material, offset) {
    if (material && material instanceof Material) {
        var meta = material.meta, scale = material.getScale(), result = new Vec2(offset.x, offset.y);
        return result.scale(parseFloat(meta.xlen), parseFloat(meta.ylen)), result.scale(scale.x, scale.y),
            result.rotate(utilMathToRadius(-material.rot)), result;
    }
}

function materialGetExtraParameter(meta, field) {
    try {
        var extra = meta && meta.extra && JSON.parse(meta.extra), val = extra && extra[field];
        return val && parseFloat(val) || void 0;
    } catch (e) {
        return;
    }
}

function MaterialRawColor(meta) {
    var meta = meta || {};
    meta.pid = "color";
    meta.category = "color";
    classBase(this, meta);
    __assert(void 0 != this.pid, "Material needs pid.");
    var propertyChanged = (linkPropertyChangedCalllback.bind(this), entityPropertyChangedCallback.bind(this));
    utilRootDefineProperty(this, "diffuse_r", 255, propertyChanged);
    utilRootDefineProperty(this, "diffuse_g", 255, propertyChanged);
    utilRootDefineProperty(this, "diffuse_b", 255, propertyChanged);

    if (meta.color) {
        this.setColor(meta.color);
    }
}

//新建rawColor
function utilMaterialRawColorCreate(color) {
    return new MaterialRawColor({color:color});
}

function utilMaterialRawColorGetUrl(tile, usePrefix, map) {
    var urlPrefix = utilAppGetServicePrefix(application, "tileimg"), mapUrl = map && "" != map ? "diffuse" == map ? "/tileImgD" : "tileImgR" : "", url = mapUrl + "?pid=" + tile.pid + "&op=color&r=" + Math.round(tile.diffuse_r) + "&g=" + Math.round(tile.diffuse_g) + "&b=" + Math.round(tile.diffuse_b);
    return (usePrefix === !0 ? urlPrefix : "") + url;
}

function TileGroup(meta) {
    classBase(this, meta);
}

function Parquet(meta) {
    classBase(this, meta);
}

function utilParquetGetUrl(mat, imgWidth, override, usePrefix) {
    var urlPrefix = utilAppGetServicePrefix(application, "tileimg");
    var mapUrl = "/parquetD";
    var category = mat.category;
    var param = mat.meta.extra && JSON.parse(mat.meta.extra);
    if (!param) return __assert(!1, "CAN Not get material meta for pid=" + mat.meta.pid),
        "";
    mat.userDefined && mat.userDefined.parquet && (param = utilExtend(!0, param, mat.userDefined.parquet)),
    override && (param = utilExtend(!0, param, override));
    var size = imgWidth || 1024, data = {};
    for (var imgId in param.channels) {
        var channel = param.channels[imgId];
        "none" != channel.pid && (data[imgId] = {
            p: channel.pid,
            r: channel.rot || 0
        });
    }
    var url = "?pid=" + mat.pid + "&size=" + size + "&data=" + encodeURIComponent(JSON.stringify(data));
    category=="customparquet"?url+="&type=custom":'';
    return (usePrefix === !1 ? "" : urlPrefix + mapUrl) + url;
}

//底图
function Underlay(meta) {
    classBase(this, meta);
    this.category = "underlay";
    this.width = meta && meta.width || 0;
    this.height = meta && meta.height || 0;
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "x", 0, propertyChanged);
    utilRootDefineProperty(this, "y", 0, propertyChanged);
}

function Product(meta) {
    this.meta = meta, classBase(this, meta);
    var cb = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "x", -100, cb);
    utilRootDefineProperty(this, "y", -100, cb);
    utilRootDefineProperty(this, "z", meta && meta.attitude ? parseFloat(meta.attitude) : 0, cb);
    utilRootDefineProperty(this, "sx", 1, cb);
    utilRootDefineProperty(this, "sy", 1, cb);
    utilRootDefineProperty(this, "sz", 1, cb);
    utilRootDefineProperty(this, "rot", 0, cb);
    utilRootDefineProperty(this, "flip", 0, cb);
    utilRootDefineProperty(this, "index", globalModelIndex, cb);//添加index属性 add by zk
    utilRootDefineProperty(this, "usagecount", meta.usagecount, cb);//添加模型使用次数usagecount属性 add by zk

    //增加X轴的旋转  add by gaoning 2017.4.28
    utilRootDefineProperty(this, "rotx", 0, cb);
    //增加Y轴的旋转  add by gaoning 2017.4.29
    utilRootDefineProperty(this, "roty", 0, cb);
    //增加Y轴的旋转  add by gaoning 2017.4.29
    utilRootDefineProperty(this, "rotz", 0, cb);
    //增加Quaternion
    utilRootDefineProperty(this, "quaternion_x", 0, cb);
    utilRootDefineProperty(this, "quaternion_y", 0, cb);
    utilRootDefineProperty(this, "quaternion_z", 0, cb);
    utilRootDefineProperty(this, "quaternion_w", 0, cb);

    var linkChanged = linkPropertyChangedCalllback.bind(this);
    utilRootDefineProperty(this, "attached", void 0, cb);
    utilRootDefineProperty(this, "group", void 0, cb);

    //天花吸咐添加center值--add by gaoning 2017.12.8
    //var linkChanged = linkPropertyChangedCalllback.bind(this);
    //utilRootDefineProperty(this, "center", void 0, linkChanged);

    this.pid = meta && meta.pid;
    __assert(void 0 != this.pid, "Product needs a product ID.");
    this.userDefined = this.userDefined || {};
    meta.extra && utilExtend(this.userDefined, JSON.parse(meta.extra));
    void 0 == this.___b;
    this.propertyChangedEvent.add(function (propertyName) {
        "x" != propertyName && "y" != propertyName && "sx" != propertyName && "sy" != propertyName && "rot" != propertyName || (this.___b = void 0);
    });
}

function utilGetProductOBBPoints(product, opt) {
    var marginBound = opt && opt.margin || 0, rot = opt && opt.rot || product.rot, p = product, meta = p.meta, width = ({
        x: p.x,
        y: p.y
    }, meta.xlen * p.sx), height = meta.ylen * p.sy;
    return p instanceof Opening && (height = p.attached ? p.attached.width : DEFAULT_WALL_WIDTH),
        utilBoundOBBGetLoop({
            x: p.x,
            y: p.y,
            width: width,
            height: height,
            rot: rot
        }, marginBound);
}

function utilProductFindHostRoom(fp, product) {
    if (product instanceof Product) {
        var host = void 0;
        return utilFloorplanForEachFloor(fp, function (floor) {
            if (!host) {
                var profile = utilFloorGetLoopFromProfile(floor);
                utilMathIsPointInPoly(profile, product) && (host = floor);
            }
        }), host;
    }
}

function ProductReplacement(meta) {
    classBase(this, meta);
    var linkChanged = (entityPropertyChangedCallback.bind(this), linkPropertyChangedCalllback.bind(this));
    this.replacementElements = [];
    var replacement = this && this.meta && this.meta.extra && JSON.parse(this.meta.extra).replacement;
    if (replacement) {
        var replacementElements = this.replacementElements = Object.keys(replacement);
        var self = this;
        var pids = replacementElements.map(function (key) {
            var matName = key + "Material";
            return utilRootDefineProperty(self, matName, void 0, linkChanged), replacement[key].pid;
        });
        utilCatalogGetProductsMetaPromise(application.catalogMgr, pids).then(function (modelMetas) {
            replacementElements.forEach(function (key) {
                var matName = key + "Material";
                if (void 0 == self[matName]) {
                    var meta = modelMetas[replacement[key].pid];
                    var mat = new Material(meta);
                    self[matName] = mat;
                }
            });
        });
    }
}

function utilProductReplacementLoadMaterial(model, loadedData) {
    var db = Root.prototype.database, replacementMeta = model && model.meta && model.meta.extra && JSON.parse(model.meta.extra).replacement, userDefinedMeta = model && model.userDefined && model.userDefined.replacement, replaceMetas = utilExtend(!0, {}, replacementMeta, userDefinedMeta);
    if (0 == model.replacementElements.length) return void __assert(!1, "this product replacement product cannot find replaced elements");
    var pids = model.replacementElements.map(function (elementName) {
        return replaceMetas[elementName].pid;
    });
    utilCatalogGetProductsMetaPromise(application.catalogMgr, pids).then(function (modelMetas) {
        var replacementMeta = model && model.meta && model.meta.extra && JSON.parse(model.meta.extra).replacement, userDefinedMeta = model && model.userDefined && model.userDefined.replacement, replaceMetas = utilExtend(!0, {}, replacementMeta, userDefinedMeta);
        model.replacementElements.forEach(function (element) {
            var pid = replaceMetas[element].pid, elementMatName = element + "Material", replaceMeta = replaceMetas[element], modelMeta = modelMetas[pid], allMeta = utilExtend(!0, {}, modelMeta, replaceMeta), savedMeta = loadedData && loadedData.userDefined && loadedData.userDefined.replacement && loadedData.userDefined.replacement[element];
            if (!model[elementMatName] || model[elementMatName].pid != pid) {
                var type = Material;
                if (savedMeta) {
                    var savedMetaMat = db[savedMeta.id];
                    savedMetaMat && savedMetaMat.type && (type = TYPE[savedMetaMat.type]);
                }
                model[elementMatName] = new type(allMeta);
            }
            if (savedMeta && savedMeta.type && model[elementMatName].type != savedMeta.type) {
                var type = TYPE[savedMeta.type];
                model[elementMatName] = new type(allMeta);
            }
            var saved = model[elementMatName];
            saved.tx = allMeta.tx || saved.tx, saved.ty = allMeta.ty || saved.ty, saved.sx = allMeta.sx || saved.sx,
                saved.sy = allMeta.sy || saved.sy, saved.rot = allMeta.rot || saved.rot, saved.reflection = allMeta.reflection || saved.reflection,
                saved.reflection_glossiness = allMeta.reflection_glossiness || saved.reflection_glossiness,
                saved instanceof TileSingle && savedMeta ? (saved.gapwidth = savedMeta.gapwidth,
                    saved.gapcolor = savedMeta.gapcolor, saved.cuth = savedMeta.cuth, saved.cutv = savedMeta.cutv,
                    saved.pavetype = savedMeta.pavetype, saved.psx = savedMeta.psx, saved.psy = savedMeta.psy) : saved instanceof MaterialRawColor && (saved.diffuse_r = savedMeta.diffuse_r,
                    saved.diffuse_g = savedMeta.diffuse_g, saved.diffuse_b = savedMeta.diffuse_b);
        });
    });
}

//组合
function Assembly(meta) {
    classBase(this, meta);
    this.extra = meta.extra ? JSON.parse(meta.extra) : {};
    this.group = this.extra.group || {};
}

function Cube(meta) {
    var _meta = utilExtend({
        xlen: 1,
        ylen: 1,
        zlen: 1,
        pid: "cube",
        category: "furniture",
        subcategory: "surface",
        hasobj: 0,
        hasmax: 0
    }, meta);
    classBase(this, _meta);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "topMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "bottomMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "backMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "frontMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "leftMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "rightMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "faceHiddenFlag", 0, propertyChanged);

}

//add title by zk -20170504
//柱子
function Pillar(meta) {
    classBase(this, utilExtend(meta, {
        subcategory: "pillar",
        title: "柱子"
    }));
}

//地台
function Basement(meta) {
    classBase(this, utilExtend(meta, {
        subcategory: "basement",
        title: "地台"
    }));
}

//横梁
function Beam(meta) {
    classBase(this, utilExtend(meta, {
        subcategory: "beam",
        title: "横梁"
    }));
}

//热点？
function VRHotspot(meta) {
    classBase(this, meta);
    var cb = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "x", -100, cb);
    utilRootDefineProperty(this, "y", -100, cb);
    utilRootDefineProperty(this, "z", .2, cb);
    this.from = "";
    this.to = "";
    this.name = "";
    this.meta = this.meta || {
            subcategory: VRHotspot.prototype.type,
            xlen: .5,
            ylen: .5,
            zlen: .5
        };
}

function Annotation(opt, type) {
    //添加文本类型type参数 add by hcw
    classBase(this, opt);
    var propertyChanged = (linkPropertyChangedCalllback.bind(this), entityPropertyChangedCallback.bind(this));
    utilRootDefineProperty(this, "text", void 0, propertyChanged), utilRootDefineProperty(this, "fontsize", 20, propertyChanged),
        utilRootDefineProperty(this, "textcolor", "#696969", propertyChanged), utilRootDefineProperty(this, "x", -.5, propertyChanged),
        utilRootDefineProperty(this, "y", .5, propertyChanged), utilRootDefineProperty(this, "tx", 0, propertyChanged),
        utilRootDefineProperty(this, "ty", 0, propertyChanged);
    utilRootDefineProperty(this, "texttype", type, propertyChanged);
}

function InterpolateLinear(keys, frame) {
    __assert(keys.length > 1, "too few keys");
    for (var from = keys[0], to = keys[1], i = 0; i < keys.length - 1; ++i) {
        var currentFrom = keys[i], currentTo = keys[i + 1];
        if (frame > currentFrom.frame && frame < currentTo.frame) from = currentFrom, to = currentTo; else {
            if (frame == currentFrom.frame) return currentFrom.x;
            if (frame == currentTo.frame) return currentTo.x;
        }
    }
    var lerpNumber = (frame - from.frame) / (to.frame - from.frame), lerpX = from.x + lerpNumber * (to.x - from.x);
    return lerpX;
}

function InterpolateSoomthQuadraticBezier(keys, frame) {
    __assert(keys.length >= 2, "too few keys");
    for (var p0 = keys[0], p1 = keys[1], p2 = keys[2], i = 0; i < keys.length; ++i) if (keys[i].frame == frame) return keys[i];
    if (p0.frame < frame && frame < p1.frame) {
        var lerpNumber = (frame - p0.frame) / (p1.frame - p0.frame);
        return {
            x: p0.x + lerpNumber * (p1.x - p0.x),
            y: p0.y + lerpNumber * (p1.y - p0.y)
        };
    }
    if (p2 && !(keys[keys.length - 1].frame < frame)) for (var cp = utilMathGetScaledPoint(p0, p1, .5 * utilMathLineLength(p0, p1)), i = 1; i < keys.length - 1; ++i) if (p1 = keys[i],
            p2 = keys[i + 1], cp = utilMathGetScaledPoint(cp, p1, 2 * utilMathLineLength(cp, p1)),
        p1.frame < frame && frame < p2.frame) {
        var t = (frame - p1.frame) / (p2.frame - p1.frame), bezier = new Bezier(p1, cp, cp, p2), newPt = bezier.getPointQ(t);
        return newPt;
    }
}

function InterpolateCubeBezier(keys, frame) {
    for (var i = 0; i < keys.length; ++i) if (keys[i].frame == frame) return keys[i];
    __assert(keys.length >= 2, "too few keys");
    var pBegin = keys[0], pEnd = keys[keys.length - 1];
    if (!(frame < pBegin.frame || pEnd.frame < frame)) {
        for (var i = 0; i < keys.length - 1 && (pBegin = keys[i], pEnd = keys[i + 1], !(pBegin.frame < frame && frame < pEnd.frame)); ++i) ;
        var t = (frame - pBegin.frame) / (pEnd.frame - pBegin.frame), bezier = new Bezier(pBegin, pBegin.cp2, pEnd.cp1, pEnd), newPt = bezier.getPointC(t);
        return newPt;
    }
}

function AnimationKey(opt) {
    classBase(this, opt);
    var propertyChanged = (linkPropertyChangedCalllback.bind(this), entityPropertyChangedCallback.bind(this));
    utilRootDefineProperty(this, "name", "", propertyChanged), utilRootDefineProperty(this, "model", void 0, propertyChanged),
        utilRootDefineProperty(this, "frame", 0, propertyChanged), utilRootDefineProperty(this, "cp1x", void 0, propertyChanged),
        utilRootDefineProperty(this, "cp1y", void 0, propertyChanged), utilRootDefineProperty(this, "cp2x", void 0, propertyChanged),
        utilRootDefineProperty(this, "cp2y", void 0, propertyChanged);
}

function utilAnimationKeyBuildFromModel(key, model) {
    if (!key) return void __assert(!1);
    var aKey = "string" == typeof key ? new TYPE[key]() : key;
    return model && (aKey.model = model, aKey.fromModel()), aKey;
}

function utilAnimationKeyFlushToModel(key) {
    __assert(key && key instanceof AnimationKey, "key is not defined"), __assert(key.model, "Warning: Key model is not defined, Flush to model failed."),
    key.model && key.toModel();
}

function Animation(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this), propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "name", void 0, propertyChanged), utilRootDefineProperty(this, "frames", 100, propertyChanged),
        utilRootDefineProperty(this, "path", "linear", propertyChanged);
    for (var i = 0; ANIMATION_MAX_KEYS > i; i++) utilRootDefineProperty(this, i, void 0, linkChanged);
    this.length = ANIMATION_MAX_KEYS, this._sortedKeysInternal = void 0;
}

function utilAnimationGetLerpKeys(anim, frame) {
    return anim.lerp(frame);
}

function utilAnimationGetSortedKeysInternal(anim) {
    if (!anim._sortedKeysInternal) {
        var keys = Array.from(anim);
        keys.sort(function (a, b) {
            return a.frame - b.frame;
        }), anim._sortedKeysInternal = keys.filter(function (item) {
            return item;
        });
    }
    return anim._sortedKeysInternal;
}

function utilAnimationGetAllKeys(anim) {
    for (var keys = [], i = 0; ANIMATION_MAX_KEYS > i; i++) anim[i] || keys.push(anim[i]);
    return keys;
}

function utilAnimationAddKey(anim, key) {
    anim._sortedKeysInternal = void 0;
    for (var i = 0; ANIMATION_MAX_KEYS > i; i++) if (!anim[i]) return anim[i] = key,
        !0;
    return !1;
}

function utilAnimationDeleteKey(anim, key) {
    anim._sortedKeysInternal = void 0;
    for (var i = 0; ANIMATION_MAX_KEYS > i; i++) if (anim[i] && anim[i].id == key.id) return anim[i] = void 0,
        !0;
    return !1;
}

function WalkKey(opt) {
    classBase(this, opt);
    var propertyChanged = (linkPropertyChangedCalllback.bind(this), entityPropertyChangedCallback.bind(this));
    utilRootDefineProperty(this, "x", void 0, propertyChanged), utilRootDefineProperty(this, "y", void 0, propertyChanged),
        utilRootDefineProperty(this, "z", void 0, propertyChanged), utilRootDefineProperty(this, "tx", void 0, propertyChanged),
        utilRootDefineProperty(this, "ty", void 0, propertyChanged), utilRootDefineProperty(this, "pitch", void 0, propertyChanged),
        utilRootDefineProperty(this, "cp1tx", void 0, propertyChanged), utilRootDefineProperty(this, "cp1ty", void 0, propertyChanged),
        utilRootDefineProperty(this, "cp2tx", void 0, propertyChanged), utilRootDefineProperty(this, "cp2ty", void 0, propertyChanged);
}

function WalkThrough(opt) {
    classBase(this, opt);
    linkPropertyChangedCalllback.bind(this), entityPropertyChangedCallback.bind(this);
}

/*TYPE在classInherit执行时构造 add by oxl 2017-04-11*/
var TYPE = {};

Root.prototype.database = {}, Entity.prototype.type = "ENTITY", classInherit(Entity, Root),
    ModelObject.prototype.type = "MODELOBJECT", classInherit(ModelObject, Entity);

var MODELFLAG_PICKED = 2, MODELFLAG_HIDDEN = 4;

utilExtend(ModelObject.prototype, {
    load: function (data) {
        data.id && (this.id = data.id), this.flag = data.flag || 0, this.userDefined = data.userDefined;
        var db = Root.prototype.database;
        data.lf.forEach(function (linkId) {
            utilEntityAddLink(this, db[linkId]);
        }, this), data.lt.forEach(function (linkId) {
            utilEntityAddLink(db[linkId], this);
        }, this);
    },
    save: function () {
        return {
            id: this.id,
            flag: this.flag,
            type: this.type,
            lt: Object.keys(this.lt),
            lf: Object.keys(this.lf),
            userDefined: this.userDefined,
            category: this instanceof Product ? this.meta.category : '', //add by hcw
            subcategory: this instanceof Product ? this.meta.subcategory : ''
        };
    },
    destroy: function () {
    },
    canGroup: function () {
        return !1;
    },
    getBound: function (excludesType) {
        function appendLinkedBound(modelObject) {
            modelObject.lf.map(function (linkId) {
                return modelObject.lf[linkId];
            }).forEach(function (link) {
                if (-1 == excludesType.indexOf(link.type)) {
                    var linkedBound = link.getBound(excludesType);
                    linkedBound.isValid() && bound.addBound(linkedBound), appendLinkedBound(link);
                }
            });
        }

        var bound = new Bound(1 / 0, 1 / 0, 0, 0);
        return appendLinkedBound(this), bound;
    },
    dispose: function () {
    }
});

var MODEL_GROUP_ENABLED = !0, GROUPFLAG_OPENED = 512, GROUPFLAG_CHILDREN_ADDED_REMOVED = 1024, GROUPFLAG_VIEW_UPDATE = 2048, EDIT_GROUP_MODEL = false;

Group.prototype.type = "GROUP", classInherit(Group, ModelObject);

var GROUP_TEMP = new Group();

GROUP_TEMP.id = "TempGroup", GROUP_TEMP.name = "临时组合", utilExtend(Group.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.name = this.name, saved.children = this.children.map(function (child) {
            return child.id;
        }), this.group && (saved.group = this.group.id), saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        this.name = data.name, data.children.forEach(function (childId) {
            var child = db[childId];
            return child && utilGroupAddItem(this, child), db[childId];
        }, this), data.group && (this.group = db[data.group]);
    },
    canGroup: function () {
        return !0;
    },
    copy: function (source) {
        __assert(source instanceof Group, "Bad Copy From."), __assert(source.id != GROUP_TEMP.id, "Temp group could not be cloned.");
        var data = source;
        this.name = data.name;
    },
    getLoop: function (opt) {
        return utilGroupGetLoop(this, opt);
    },
    getBound: function () {
        return utilBoundFromLoop(this.getLoop());
    }
});

var utilGroupGetAllLeafChildren = function () {
    function fetchLeafChild(group, childFetched) {
        __assert(group instanceof Group, "need group type"), __assert(childFetched, "need a callback function"),
            group.children.forEach(function (child) {
                child instanceof Group ? fetchLeafChild(child, childFetched) : childFetched(child);
            });
    }

    return function (group) {
        var items = [];
        return fetchLeafChild(group, function (child) {
            items.push(child);
        }), items;
    };
}();

/* by mond 20170512
 wall.js
 floor.js
 area.js
 */


var CAMERA_PERSON_DEFAULT_NAME = "默认摄像机", CAMERA_FLY_DEFAULT_NAME = "鸟瞰摄像机";

Camera.prototype.type = "CAMERA", classInherit(Camera, ModelObject), utilExtend(Camera.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.x = this.x, saved.y = this.y, saved.z = this.z, saved.tx = this.tx,
            saved.ty = this.ty, saved.active = this.active, saved.hfov = this.hfov, saved.pitch = this.pitch,
            saved.znear = this.znear, saved.name = this.name, saved;
    },
    load: function (data) {
        classBase(this, "load", data), this.x = data.x, this.y = data.y, this.z = data.z,
            this.tx = data.tx, this.ty = data.ty, this.active = data.active || !1, this.hfov = data.hfov,
            this.pitch = data.pitch, data.znear && (this.znear = data.znear), data.name && (this.name = data.name);
    }
}), Material.prototype.type = "MATERIAL", classInherit(Material, ModelObject);

/*初始化Material，添加产品，暂时未知到这里的作用 add by oxl 2017-03-30*/
var DEFAULT_TILE_MATERIAL_ID = "tile001";
var DEFAULT_MATERIAL_REFLECTION = 0;
var DEFAULT_MATERIAL_REFLECTION_GLOSSINESS = 1;
var MATERIALFLAG_SHOW_IN_BOM = 512;
var DEFAULT_TILE_MATERIAL = new Material({
    pid: DEFAULT_TILE_MATERIAL_ID,
    xlen: 1,
    ylen: 1,
    zlen: 0,
    category: "tile"
});

application_ready_event.add(function () {
    utilCatalogGetProductsMetaPromise(application.catalogMgr, [DEFAULT_TILE_MATERIAL_ID]).then(function (metas) {
        DEFAULT_TILE_MATERIAL = new Material(metas[DEFAULT_TILE_MATERIAL_ID]);
    });
}), utilExtend(Material.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        saved.pid = this.pid;
        saved.category = this.category;
        saved.tx = this.tx || 0;
        saved.ty = this.ty || 0;
        saved.sx = this.sx || 1;
        saved.sy = this.sy || 1;
        saved.rot = this.rot || 0;
        saved.reflection = this.reflection || DEFAULT_MATERIAL_REFLECTION;
        saved.reflection_glossiness = this.reflection_glossiness || DEFAULT_MATERIAL_REFLECTION_GLOSSINESS;
        saved.ignoreUV = this.ignoreUV || false;
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        Root.prototype.database;
        this.pid = data.pid;
        data.category && (this.category = data.category);
        this.tx = data.tx;
        this.ty = data.ty;
        this.sx = data.sx;
        this.sy = data.sy;
        data.rot && (this.rot = data.rot);
        void 0 != data.reflection && (this.reflection = data.reflection);
        void 0 != data.reflection_glossiness && (this.reflection_glossiness = data.reflection_glossiness);
        data.ignoreUV && (this.ignoreUV = data.ignoreUV);
    },
    clone: function () {
        var rv = new TYPE[this.type]({
            pid: this.pid
        });
        rv.tx = this.tx;
        rv.ty = this.ty;
        rv.sx = this.sx;
        rv.sy = this.sy;
        rv.reflection = this.reflection;
        rv.reflection_glossiness = this.reflection_glossiness;
        this.rot && (rv.rot = this.rot);
        this.category && (rv.category = this.category);
        rv.meta = this.meta;
        rv.ignoreUV = this.ignoreUV||false;
        return rv;
    },
    getUrl: function (used) {
    	  if(used == "3d"){    	  	
			    var cat = this.category;
			    "tile" != cat && "customparquet" != cat &&"custom_tile" != cat && "color" != cat || (cat = "product");
			    if(cat == "product"){
			    	return "https://pic.oceano.com.cn/h5filesystem/products/" + this.pid + "/top.jpg@256h.jpg";
			    }
			  }
        return utilMaterialGetUrl(this);
    },
    getThreeUrl: function(){
    	  var cat = this.category;
		    "tile" != cat && "customparquet" != cat && "custom_tile" != cat && "color" != cat || (cat = "product");
		    if(cat == "product"){
		    	return "https://pic.oceano.com.cn/h5filesystem/products/" + this.pid + "/top.jpg@256h.jpg";
		    }else{
		    	utilMaterialGetUrl(this);
		    }
    },
    getScale: function () {
        return {
            x: this.sx,
            y: this.sy
        };
    },
    dispose: function () {
        //utilSnapClearPattern(this);
    }
}), MaterialRawColor.prototype.type = "MATERIALRAWCOLOR", classInherit(MaterialRawColor, Material),
    utilExtend(MaterialRawColor.prototype, {
        save: function () {
            var saved = classBase(this, "save");
            saved.diffuse_r = this.diffuse_r, saved.diffuse_g = this.diffuse_g, saved.diffuse_b = this.diffuse_b;
            var _url = saved._url = utilMaterialRawColorGetUrl(this, !1);
            return saved._md5 = utilMakeMD5(_url), saved;
        },
        load: function (data) {
            classBase(this, "load", data), this.diffuse_r = data.diffuse_r, this.diffuse_g = data.diffuse_g,
                this.diffuse_b = data.diffuse_b;
        },
        clone: function () {
            var rv = classBase(this, "clone");
            rv.diffuse_r = this.diffuse_r, rv.diffuse_g = this.diffuse_g, rv.diffuse_b = this.diffuse_b;
            var _url = rv._url = utilMaterialRawColorGetUrl(this, !1);
            return rv._md5 = utilMakeMD5(_url), rv;
        },
        getUrl: function () {
            return utilMaterialRawColorGetUrl(this, !0, "diffuse");
        },
        getThreeUrl: function () {
        	  return this.getUrl();
        },
        getColor: function () {
            var color = new THREE.Color(this.diffuse_r / 255.0, this.diffuse_g / 255.0, this.diffuse_b / 255.0);
            return color;
        },
        setColor: function (opt) {
            var c = new THREE.Color((opt & 0xff0000) >> 16, (opt & 0x00ff00) >> 8, opt & 0x0000ff);
            this.diffuse_r = c.r;
            this.diffuse_g = c.g;
            this.diffuse_b = c.b;
        },
        getColorHexString: function(){
        	  return utilColorHexString(this.diffuse_r,this.diffuse_g,this.diffuse_b);
        },
    }), TileGroup.prototype.type = "TILEGROUP", classInherit(TileGroup, Material), utilExtend(TileGroup.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        Root.prototype.database;
    },
    getUrl: function () {
        return "";
    }
}), Parquet.prototype.type = "PARQUET", classInherit(Parquet, Material);

var PAQUETFLAG_MATERIAL_CHANGED_FOR_REDRAW = 64;

utilExtend(Parquet.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        //return saved._url = utilParquetGetUrl(this, void 0, void 0, !1), saved;
        // 添加MD5,解决可替换材质贴上拼花后无法渲染的问题--add by gaoning 2017.4.12
        return saved._url = utilParquetGetUrl(this, void 0, void 0, !1), saved._md5 = utilMakeMD5(saved._url), saved;
    },
    load: function (data) {
        classBase(this, "load", data);
    },
    clone: function () {
        var rv = classBase(this, "clone");
        return this.userDefined && (rv.userDefined = rv.userDefined || {}, rv.userDefined = utilExtend(!0, rv.userDefined, this.userDefined)),
            rv;
    },
    getUrl: function (size, override, usePrefix) {
        return utilParquetGetUrl(this, size, override, usePrefix);
    },
    getThreeUrl: function() {
    	  return utilParquetGetUrl(this, 256);
    },
    update: function (override) {
        this.userDefined = this.userDefined || {};
        this.userDefined.parquet = this.userDefined.parquet || {};
        this.userDefined.parquet = utilExtend(!0, this.userDefined.parquet, override);
        this.rot += 2;
        this.rot -= 2;
        utilModelChangeFlag(this, PAQUETFLAG_MATERIAL_CHANGED_FOR_REDRAW);
    }
}), Underlay.prototype.type = "UNDERLAY", classInherit(Underlay, Material), utilExtend(Underlay.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.width = this.width, saved.height = this.height, saved.x = this.x, saved.y = this.y,
            saved;
    },
    load: function (data) {
        classBase(this, "load", data), this.width = data.width, this.height = data.height,
            this.x = data.x, this.y = data.y;
    }
}), Product.prototype.type = "PRODUCT", classInherit(Product, ModelObject), utilExtend(Product.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.x = utilIsNumber(this.x) ? this.x : 0, saved.y = this.y, saved.z = this.z,
            saved.pid = this.pid, saved.sx = this.sx, saved.sy = this.sy, saved.sz = this.sz,
            saved.rot = this.rot, this.attached && (saved.attached = this.attached.id), this.group && (saved.group = this.group.id),
            saved.flip = this.flip,
            //增加旋转参数--add by gaoning 2017.5.3
            saved.rotx = this.rotx, saved.roty = this.roty, saved.rotz = this.rotz,
            //增加序号参数--add by zk
            saved.index = this.index,
            saved.quaternion_x = this.quaternion_x, saved.quaternion_y = this.quaternion_y, saved.quaternion_z = this.quaternion_z, saved.quaternion_w = this.quaternion_w,
            saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        this.rot = data.rot || 0;
        this.x = Math.min(200, Math.max(-200, data.x));
        this.y = Math.min(200, Math.max(-200, data.y));
        this.z = Math.min(200, Math.max(-200, data.z));
        this.pid = data.pid;
        this.sx = data.sx || 1;
        this.sy = data.sy || 1;
        this.sz = data.sz || 1;
        this.index = data.index || globalModelIndex;//读取序号参数 add by zk
        globalModelIndex++;
        data.attached && (this.attached = db[data.attached]);
        this.flip = data.flip || false;
        data.group && utilGroupAddItem(db[data.group], this);
    },
    copy: function (source) {
        updateUsageCount(source);//产品模型复制热点计数
        __assert(source instanceof Product, "Bad Copy From.");
        var data = source;
        this.pid = data.pid, this.x = data.x, this.y = data.y, this.z = data.z, this.rot = data.rot,
            this.sx = data.sx, this.sy = data.sy, this.sz = data.sz, this.attached = data.attached,
            this.flip = data.flip,
            this.index = globalModelIndex,
        data.userDefined && (this.userDefined = this.userDefined || {}, this.userDefined = utilExtend(!0, this.userDefined, data.userDefined));
    },
    canGroup: function () {
        return !0;
    },
    getLoop: function (opt) {
        return utilGetProductOBBPoints(this, opt);
    },
    getBound: function () {
        return utilBoundFromLoop(this.getLoop());
    },

    isValid: function () {//--add by gaoning 2017.12.8
        return !isNaN(this.x) && !isNaN(this.y) && !isNaN(this.sx) && !isNaN(this.sy) && this.sx > .01 && this.sy > .01;
    },
    boundSnap: function () {  //添加天花吸咐功能2222 --add by gaoning 2017.12.8
        //console.log("2222222222");
        return utilRectCeilingBoundSnap(this);
    },

    getUrl: function (type) {
        return utilCatalogGetFileUrl(application.catalogMgr, "product", this.pid, type || "top", "png");
    }
}), ProductReplacement.prototype.type = "PRODUCTREPLACEMENT", classInherit(ProductReplacement, Product),
    utilExtend(ProductReplacement.prototype, {
        save: function () {
            var saved = classBase(this, "save");
            return this.replacementElements.forEach(function (element) {
                var matName = element + "Material", mat = this[matName];
                mat && (saved[matName] = mat.id);
            }, this), saved;
            var saved;
        },
        load: function (data) {
            classBase(this, "load", data);
            var db = Root.prototype.database;

            //console.log("@123456789@");

            this.replacementElements.forEach(function (element) {
                var matName = element + "Material", matId = data[matName];

                //console.log("## get matName");
                //console.log(this);
                //console.log(data);
                //console.log(matName);
                //console.log(matId);
                //console.log(db);
                //console.log(db[matId]);
                matId && db[matId] && (this[matName] = db[matId]);
            }, this);
        },
        copy: function (source) {
            __assert(source instanceof ProductReplacement, "Bad Copy From.");
            source.save();
            classBase(this, "copy", source), this.replacementElements.forEach(function (element) {
                var matName = element + "Material";
                this[matName] = source[matName].clone();
            }, this);
        }
    }), Assembly.prototype.type = "ASSEMBLY", classInherit(Assembly, Product), utilExtend(Assembly.prototype, {
    save: function () {
        classBase(this, "save");
    },
    load: function (data) {
    }
}), Cube.prototype.type = "CUBE", classInherit(Cube, Product), utilExtend(Cube.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
    }
});

var CUBE_MATERIAL_SIDE_META = {
    leftMaterial: [4, "y", "z"],
    rightMaterial: [8, "y", "z"],
    topMaterial: [16, "x", "y"],
    bottomMaterial: [32, "x", "y"],
    frontMaterial: [64, "x", "z"],
    backMaterial: [128, "x", "z"]
};

utilExtend(Cube.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return this.leftMaterial && (saved.leftMaterial = this.leftMaterial.id), this.rightMaterial && (saved.rightMaterial = this.rightMaterial.id),
        this.topMaterial && (saved.topMaterial = this.topMaterial.id), this.bottomMaterial && (saved.bottomMaterial = this.bottomMaterial.id),
        this.backMaterial && (saved.backMaterial = this.backMaterial.id), this.frontMaterial && (saved.frontMaterial = this.frontMaterial.id),
            saved.faceHiddenFlag = this.faceHiddenFlag,
            saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        data.leftMaterial && (this.leftMaterial = db[data.leftMaterial]), data.rightMaterial && (this.rightMaterial = db[data.rightMaterial]),
        data.topMaterial && (this.topMaterial = db[data.topMaterial]), data.bottomMaterial && (this.bottomMaterial = db[data.bottomMaterial]),
        data.backMaterial && (this.backMaterial = db[data.backMaterial]), data.frontMaterial && (this.frontMaterial = db[data.frontMaterial]),
        data.faceHiddenFlag && (this.faceHiddenFlag = data.faceHiddenFlag);

    },
    copy: function (source) {
        classBase(this, "copy", source);
        var data = source;
        data.leftMaterial && (this.leftMaterial = data.leftMaterial.clone()), data.rightMaterial && (this.rightMaterial = data.rightMaterial.clone()),
        data.topMaterial && (this.topMaterial = data.topMaterial.clone()), data.bottomMaterial && (this.bottomMaterial = data.bottomMaterial.clone()),
        data.backMaterial && (this.backMaterial = data.backMaterial.clone()), data.frontMaterial && (this.frontMaterial = data.frontMaterial.clone()),
        data.faceHiddenFlag && (this.faceHiddenFlag = data.faceHiddenFlag);
    },
    getUrl: function (type) {
        var mat = this[type || "topMaterial"], pid = mat ? mat.pid : DEFAULT_TILE_MATERIAL_ID;
        return utilCatalogGetFileUrl(application.catalogMgr, "product", pid, "top");
    }
}), Pillar.prototype.type = "PILLAR", classInherit(Pillar, Cube), Basement.prototype.type = "BASEMENT", classInherit(Basement, Cube), Beam.prototype.type = "BEAM", classInherit(Beam, Cube),
    VRHotspot.prototype.type = "VRHOTSPOT", classInherit(VRHotspot, ModelObject), utilExtend(VRHotspot.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.x = utilIsNumber(this.x) ? this.x : 0, saved.y = this.y, saved.z = this.z,
            saved.from = this.from, saved.to = this.to, saved.name = this.name,
            saved.index = this.index,
            saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        Root.prototype.database;
        this.x = data.x;
        this.y = data.y;
        this.z = data.z;
        this.from = data.from;
        this.to = data.to;
        this.name = data.name;
        this.index = data.index;//增加序号参数
    },
    getUrl: function () {
        return "";
    }
}), Annotation.prototype.type = "ANNOTATION", classInherit(Annotation, ModelObject),
    utilExtend(Annotation.prototype, {
        save: function () {
            var saved = classBase(this, "save");
            return saved.text = this.text ? encodeURIComponent(this.text.trim()) : void 0, saved.x = this.x,
                saved.y = this.y, saved.tx = this.tx, saved.ty = this.ty, saved.fontsize = this.fontsize,
                saved.textcolor = this.textcolor, saved;
        },
        load: function (data) {
            classBase(this, "load", data);
            Root.prototype.database;
            this.text = data.text ? decodeURIComponent(data.text.trim()) : void 0, this.x = data.x,
                this.y = data.y, this.tx = data.tx, this.ty = data.ty, data.fontsize && (this.fontsize = data.fontsize),
            data.textcolor && (this.textcolor = data.textcolor);
        }
    });

var AnimationInterpolator = {
    linear: InterpolateLinear.bind(void 0),
    bezierQ: InterpolateSoomthQuadraticBezier.bind(void 0),
    bezierC: InterpolateCubeBezier.bind(void 0)
};

AnimationKey.prototype.type = "ANIMATIONKEY", classInherit(AnimationKey, ModelObject),
    utilExtend(AnimationKey.prototype, {
        save: function () {
            var saved = classBase(this, "save");
            return this.model && (saved.model = this.model.id), saved.frame = this.frame, saved.cp1x = this.cp1x,
                saved.cp1y = this.cp1y, saved.cp2x = this.cp2x, saved.cp2y = this.cp2y, saved;
        },
        load: function (data) {
            classBase(this, "load", data);
            var db = Root.prototype.database;
            data.model && (this.model = db[data.model]), this.frame = data.frame, data.cp1x && (this.cp1x = data.cp1x),
            data.cp1y && (this.cp1y = data.cp1y), data.cp2x && (this.cp2x = data.cp2x), data.cp2y && (this.cp2y = data.cp2y);
        },
        fromModel: function () {
        },
        toModel: function () {
        },
        clone: function (another) {
            return another = another || new TYPE[this.type](), another.model = this.model, another.frame = this.frame,
                another.cp1x = this.cp1x, another.cp1y = this.cp1y, another.cp2x = this.cp2x, another.cp2y = this.cp2y,
                another;
        }
    });

var ANIMATION_MAX_KEYS = 10;

Animation.prototype.type = "ANIMATION", classInherit(Animation, ModelObject), utilExtend(Animation.prototype, {
    sortedKeys: function () {
        return utilAnimationGetSortedKeysInternal(this);
    },
    save: function () {
        var saved = classBase(this, "save");
        saved.name = this.name, saved.frames = this.frames, saved.path = this.path;
        for (var i = 0; ANIMATION_MAX_KEYS > i; i++) this[i] && (saved[i] = this[i].id);
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        this.name = data.name, this.frames = data.frames, this.path = data.path;
        for (var i = 0; ANIMATION_MAX_KEYS > i; i++) data[i] && (this[i] = db[data[i]]);
    },
    lerp: function (frame) {
        return [];
    }
}), WalkKey.prototype.type = "WALKKEY", classInherit(WalkKey, AnimationKey), utilExtend(WalkKey.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.x = this.x, saved.y = this.y, saved.z = this.z, saved.tx = this.tx,
            saved.ty = this.ty, saved.pitch = this.pitch, saved.cp1tx = this.cp1tx, saved.cp1ty = this.cp1ty,
            saved.cp2tx = this.cp2tx, saved.cp2ty = this.cp2ty, saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        Root.prototype.database;
        this.x = data.x, this.y = data.y, this.z = data.z || 1.2, this.tx = data.tx, this.ty = data.ty,
            this.pitch = data.pitch, data.cp1tx && (this.cp1tx = data.cp1tx), data.cp1ty && (this.cp1ty = data.cp1ty),
        data.cp2tx && (this.cp2tx = data.cp2tx), data.cp2ty && (this.cp2ty = data.cp2ty),
        void 0 === this.cp1x && this.resetCP();
    },
    fromModel: function () {
        classBase(this, "fromModel");
        var model = this.model;
        __assert(model && model.type == Camera.prototype.type), this.x = model.x, this.y = model.y,
            this.z = model.z, this.tx = model.tx, this.ty = model.ty, this.pitch = model.pitch,
        void 0 === this.cp1x && this.resetCP();
    },
    toModel: function () {
        classBase(this, "toModel");
        var model = this.model;
        __assert(model && model.type == Camera.prototype.type), model.x = this.x, model.y = this.y,
            model.z = this.z, model.tx = this.tx, model.ty = this.ty, model.pitch = this.pitch;
    },
    clone: function (another) {
        var cloned = classBase(this, "clone", another);
        return cloned.x = this.x, cloned.y = this.y, cloned.z = this.z, cloned.tx = this.tx,
            cloned.ty = this.ty, cloned.pitch = this.pitch, cloned.cp1tx = this.cp1tx, cloned.cp1ty = this.cp1ty,
            cloned.cp2tx = this.cp2tx, cloned.cp2ty = this.cp2ty, cloned;
    },
    resetCP: function () {
        var lenX = (this.tx - this.x) / 3, lenY = (this.ty - this.y) / 3;
        this.cp1x = this.x - lenX, this.cp1y = this.y - lenY, this.cp2x = this.x + lenX,
            this.cp2y = this.y + lenY, this.cp1tx = this.tx - lenX, this.cp1ty = this.ty - lenY,
            this.cp2tx = this.tx + lenX, this.cp2ty = this.ty + lenY;
    }
}), WalkThrough.prototype.type = "WALKTHROUGH", classInherit(WalkThrough, Animation),
    utilExtend(WalkThrough.prototype, {
        lerp: function (frame) {
            var sortKeys = this.sortedKeys(), firstKey = sortKeys[0], lastKey = sortKeys[sortKeys.length - 1], newKeys = [];
            if (firstKey && lastKey && frame >= firstKey.frame && frame <= lastKey.frame) {
                var newKey = new WalkKey();
                firstKey.clone(newKey), newKey.frame = frame;
                var linearinterpolator = AnimationInterpolator.linear;
                newKey.z = linearinterpolator(sortKeys.map(function (item) {
                    return {
                        frame: item.frame,
                        x: item.z
                    };
                }), frame), newKey.pitch = linearinterpolator(sortKeys.map(function (item) {
                    return {
                        frame: item.frame,
                        x: item.pitch
                    };
                }), frame);
                var interpolate = AnimationInterpolator[this.path];
                if ("linear" == this.path) newKey.x = interpolate(sortKeys.map(function (item) {
                    return {
                        frame: item.frame,
                        x: item.x
                    };
                }), frame), newKey.y = interpolate(sortKeys.map(function (item) {
                    return {
                        frame: item.frame,
                        x: item.y
                    };
                }), frame), newKey.tx = interpolate(sortKeys.map(function (item) {
                    return {
                        frame: item.frame,
                        x: item.tx
                    };
                }), frame), newKey.ty = interpolate(sortKeys.map(function (item) {
                    return {
                        frame: item.frame,
                        x: item.ty
                    };
                }), frame); else if ("bezierQ" == this.path) {
                    var pos = interpolate(sortKeys.map(function (item) {
                        return {
                            frame: item.frame,
                            x: item.x,
                            y: item.y
                        };
                    }), frame);
                    newKey.x = pos.x, newKey.y = pos.y;
                    var tar = interpolate(sortKeys.map(function (item) {
                        return {
                            frame: item.frame,
                            x: item.tx,
                            y: item.ty
                        };
                    }), frame);
                    newKey.tx = tar.x, newKey.ty = tar.y;
                } else if ("bezierC" == this.path) {
                    var pos = interpolate(sortKeys.map(function (item) {
                        return {
                            frame: item.frame,
                            x: item.x,
                            y: item.y,
                            cp1: {
                                x: item.cp1x,
                                y: item.cp1y
                            },
                            cp2: {
                                x: item.cp2x,
                                y: item.cp2y
                            }
                        };
                    }), frame);
                    newKey.x = pos.x, newKey.y = pos.y;
                    var tar = interpolate(sortKeys.map(function (item) {
                        return {
                            frame: item.frame,
                            x: item.tx,
                            y: item.ty,
                            cp1: {
                                x: item.cp1tx,
                                y: item.cp1ty
                            },
                            cp2: {
                                x: item.cp2tx,
                                y: item.cp2ty
                            }
                        };
                    }), frame);
                    newKey.tx = tar.x, newKey.ty = tar.y;
                }
                newKeys.push(newKey);
            }
            return newKeys;
        }
    });