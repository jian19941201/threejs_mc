var application = void 0, application_ready_event = new signals.Signal();

global.bootstrap_complete_event = new signals.Signal();

var api = {
    application_ready_event: application_ready_event,
    bootstrap_complete_event: global.bootstrap_complete_event
};

global.api = api;

var Signal = signals.Signal;