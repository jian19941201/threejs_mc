function BaseView(app, domElement, opt) {
    classBase(this, app, opt), this.domElement = domElement, this.context = this.context || this.createContextInternal(), 
    this.viewport = this.viewport || new Bound(1 / 0, 1 / 0, 0, 0), this.dl = this.dl || {}, 
    this.adl = this.adl || {}, this.dF = 0, this.domElement && (this.domElement.oncontextmenu = function(e) {
        return !1;
    });
}

/*TODO 是这个才是事件源，初始化后，每次改变dom触发；
 *执行完createDO后，再执行displayGizmo.create()，最终输出到页面
* add by oxl 2017-02-28*/
function utilViewActionGizmoBeginHandler(view, actionObj) {
    var displayGizmo = view.createDO(actionObj);
    displayGizmo && (displayGizmo.create(), view.adl[actionObj.type] = displayGizmo);
}

function utilViewActionGizmoEndHandler(view, actionObj) {
    var actionDisplay = view.adl[actionObj.type];
    actionDisplay && (actionDisplay.destroy(), delete view.adl[actionObj.type]);
}

/*执行完createDO后，再执行dispObj.create()，最终输出到页面*/
function utilViewLinksChangedEventCallback(propertyName, changedOperation, oldValue, newValue) {
    var linksChangedHappened = utilViewLinksChangedEventCallback.bind(this);
    if ("add" == changedOperation) {
        __assert(void 0 != oldValue && oldValue instanceof ModelObject);
        
        if(oldValue instanceof Curve){
        	oldValue.linksChangedEvent.add(linksChangedHappened);
        }
        
        var dispObj = this.dl[oldValue.id] || this.createDO(oldValue);
        dispObj && (dispObj.create(), this.dl[dispObj.id] = dispObj);
    } else if ("remove" == changedOperation) {
        __assert(void 0 != oldValue && oldValue instanceof ModelObject);
        
        if(oldValue instanceof Curve){
        	oldValue.begin = void 0;
          oldValue.end = void 0;
          oldValue.bezier = void 0;
          oldValue.linksChangedEvent.remove(linksChangedHappened);
        }
                
        var dispObj = this.dl[oldValue.id];
        dispObj && dispObj.destroy();
        delete this.dl[oldValue.id];  //删除显示对象
    } else {
    	__assert(!1, "unknown change operation : " + changedOperation);
    }
}

function DisplayObject(modelObject, view) {
    this.model = modelObject;
    this.id = modelObject.id;
    this.view = view;
    this.dF = 0;
    this.de = void 0;
}

function DisplayWall(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(BaseView, AView), utilExtend(BaseView.prototype, {
    fit: function() {},
    clear: function() {
        classBase(this, "clear");
        Object.keys(this.dl).forEach(function(id) {
            var displayObject = this.dl[id];
            displayObject.destroy(), delete this.dl[id];
        }, this);
    },
    createContextInternal: function() {},
    onDocumentChanged: function() {
        classBase(this, "onDocumentChanged");
    },
    init: function() {
        classBase(this, "init");
    },
    getBoundingClientRect: function() {
        return this.domElement && this.domElement.getBoundingClientRect ? this.domElement.getBoundingClientRect() : {
            width: 10,
            height: 10
        };
    },
    onUpdate: function() {
    	  if(0 == this.dF){
    	  	return !1;
    	  }else{
    	  	Object.keys(this.dl).forEach(function(displayObjectKey) {
	            var displayObject = this.dl[displayObjectKey];
	            if(0 != displayObject.dF){
	            	try{
		            	displayObject.update();
		            }catch(e){
		            	log("**update**"+e);
		            }
	            	displayObject.dF = 0;
	            }
	        }, this);
	        this.dF = 0;
	        return !0;    	  	
    	  }
    },
    createDO: function(modelObject) {},
    /*1.初始化时绑定一次onDocumentChanged；
    * 2.this.app.actionMgr.actionBeginEvent.add 发布事件，
    * 3.每次dom操作时触发,在action.comp.js  function utilActionBegin(mgr, actionType)  订阅事件mgr.actionBeginEvent.dispatch(actionObj, actionObj.type, args)
    * 4.function utilViewActionGizmoBeginHandler(view, actionObj) { 主要dom操作在这个方法
    * 5.所有流程结束
    * add by -oxl 2017-03-01
    * */
    onDocumentChanged: function() {
        var doc = this.doc;
        classBase(this, "onDocumentChanged");
        doc.floorplanCreatedEvent.add(function(floorplan) {
            var fp = this.doc.floorplan;
            someChangesHappened = function(a, b, c, d, e) {
                this.dF = 1;
            }.bind(this);
            fp.propertyChangedEvent.add(someChangesHappened);
            fp.linksChangedEvent.add(someChangesHappened);
            fp.linkPropertyChangedEvent.add(someChangesHappened);
            var linksChangedHappened = utilViewLinksChangedEventCallback.bind(this);
            fp.linksChangedEvent.add(linksChangedHappened);
        }.bind(this));
        this._actionGizmoBeginHandler = this._actionGizmoBeginHandler || utilViewActionGizmoBeginHandler.bind(void 0, this), 
        this._actionGizmoEndHandler = this._actionGizmoEndHandler || utilViewActionGizmoEndHandler.bind(void 0, this), 
        this.app.actionMgr.actionBeginEvent.has(this._actionGizmoBeginHandler) || this.app.actionMgr.actionBeginEvent.add(this._actionGizmoBeginHandler), 
        this.app.actionMgr.actionEndEvent.has(this._actionGizmoEndHandler) || this.app.actionMgr.actionEndEvent.add(this._actionGizmoEndHandler);
    }
}), utilExtend(DisplayObject.prototype, {
    create: function() {},
    update: function() {},
    destroy: function() {}
}), classInherit(DisplayWall, DisplayObject), utilExtend(DisplayWall.prototype, {
    create: function() {
        classBase(this, "create");
    }
});