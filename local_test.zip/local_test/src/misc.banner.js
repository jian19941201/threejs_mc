"undefined" == typeof global && (global = this), global.version = "BUILD_VERSION";

var __assert = function() {}, __log = function() {}, __assert = function(s, msg) {
    s || console.warn(msg);
}, __log = function(msg) {
    console.log(msg);
};