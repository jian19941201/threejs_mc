function MapView(app, domElement, opt) {
    classBase(this, app, domElement, opt), this.layerOrder = [ Floor.prototype.type, "Temp" ];
}

function DisplayMapFloor(modelObject, view) {
    classBase(this, modelObject, view);
    this.offset = -.1;
    this.ignoreOffset = true;  //忽略offset计算
}

MapView.prototype.type = "MapView";
classInherit(MapView, SnapView);
utilExtend(MapView.prototype, {
    init: function() {
        classBase(this, "init");
    },
    createDO: function(modelObject) {
        var model = modelObject;
        return model.type == Floor.prototype.type ? new DisplayMapFloor(model, this) : void 0;
    },
    onUpdate: function() {
        var needUpdate = classBase(this, "onUpdate");
        return this.context ? (needUpdate && this.fit(), !0) : !1;
    },
    zoom: function() {}
})

classInherit(DisplayMapFloor, DisplayObject);
var MAP_VIEW_FLOOR_COLOR = {
    normal: "darkgray",
    select: "darkorange"
};

utilExtend(DisplayMapFloor.prototype, {
    create: function() {
      classBase(this, "create");
      
      var context = this.view.context;
      var layer = this.view.layers[this.model.type];
      var labelLayer = this.view.layers[SNAP_LAYER_ROOMLABEL];
      var fp = this.view.doc.floorplan;
      var view = (this.model, this.view);
      
      var model = this.model;
      var view = this.view;
      var paths = utilSnapFloorCreatePathString(this.model, this.ignoreOffset?0:utilFloorGetBoundaryOffset(this.model));
      var style = context.path(paths[1]).attr({
          "fill-opacity": 1.0,
          "stroke-width": 0,
          fill: MAP_VIEW_FLOOR_COLOR.normal
      }).click(function(e) {
          __log("map view, floor clicks.");
          var floorLoop = utilFloorGetLoopFromProfile(model);
          var floorBound = utilBoundFromLoop(floorLoop);
          var massCenter = utilMathPolyMassCenter(floorLoop);
          var app = view.app, doc = view.doc;
          utilViewFit(app, "2d", floorBound);
          var activeCamera = utilFloorplanGetActiveCamera(doc.floorplan);
          activeCamera.x = massCenter.x, activeCamera.y = massCenter.y, activeCamera.tx = activeCamera.x + 1.5, 
          activeCamera.ty = activeCamera.y + 1.5;
      });
      this.de = [style];
      layer.add(this.de);
      
      var updateFun = function (propertyName, oldValue, newValue) {
		      if (propertyName instanceof Material) {
		          "rot" != oldValue && "tx" != oldValue && "ty" != oldValue && "sx" != oldValue && "sy" != oldValue || (this.dF |= 2);
		      } else if ("flag" == propertyName) {
		          ((oldValue & FLOORFLAG_CHANGED_FOR_REDRAWN) != (newValue & FLOORFLAG_CHANGED_FOR_REDRAWN) && (this.dF |= 1));
		          ((oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 2));
		      }else {
		          this.dF |= 1;
		      }
		  }.bind(this);
		
		  this.model.propertyChangedEvent.add(updateFun);
		  this.model.linksChangedEvent.add(updateFun);
		  this.model.linkPropertyChangedEvent.add(updateFun);
    },
    update: function() {
        classBase(this, "update");
        var style = this.de[0]; 
               
        if (0 != (1 & this.dF)) {
        	var paths = utilSnapFloorCreatePathString(this.model, this.ignoreOffset?0:utilFloorGetBoundaryOffset(this.model));
        	style.attr({
              path: paths[1]
          }); 
        }
        
        if(0 != (2 & this.dF)) {
            var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            style.attr({
                fill: picked ? MAP_VIEW_FLOOR_COLOR.select:MAP_VIEW_FLOOR_COLOR.normal                
            });
        }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.remove();
        });
    }    
});