﻿/*Document继承于Root
 *classInherit(Document, Root)
 * */
function Document(opt) {
    classBase(this, opt);
    this.floorplan = void 0;
    this.floorplanGhost = void 0;
    this.floorplanCreatedEvent = new Signal();
    this.floorplanLoadCompleteEvent = new Signal();
    this.floorplanGhostLoadCompleteEvent = new Signal();
    this.floorplanLoadCompleteEvent.add(function (doc) {
        function _forceUpdateWall() {
            utilFloorplanForEachWall(fp, function (w) {
                utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
            });
        }

        if (doc && doc.floorplan) {
            var fp = doc.floorplan;
            _forceUpdateWall(), setTimeout(_forceUpdateWall, 800);
        }
    });
}

function utilSaveFilterModelInRoom(container, current) {
    if (!container || !current) return !0;
    if (__assert(container instanceof Floor, "save filter error"), current instanceof Wall)
        return -1 != container.profile.indexOf(current);
    if (current instanceof Opening)
        return current.attached && -1 != container.profile.indexOf(current.attached);
    if (current instanceof Product) {
        var loop = utilFloorGetLoopFromProfile(container);
        return utilMathIsPointInPoly(loop, current);
    }
    if (current instanceof Floor) return container.id == current.id;
    if (current instanceof Area) {
        if (current.type == RectArea3d.prototype.type || current.type == RoundArea3d.prototype.type) {
            var wall = current.host;
            return -1 != container.profile.indexOf(wall);
        }
        var loop = utilFloorGetLoopFromProfile(container), areaLoop = current.getLoop(), center = utilMathPolyMassCenter(areaLoop);
        if (center) return utilMathIsPointInPoly(loop, center);
    }
    return !0;
}

function utilAppDocumentSave(app, opt, extra) {
    //保存户型添加墙宽度，高度  add by hcw
    var extra=extra || {};
    extra.wallWidth=DEFAULT_WALL_WIDTH;
    extra.wallHeight=DEFAULT_WALL_HEIGHT3D;
    var designContent = JSON.stringify(app.doc.save(opt));
    var encryped = utilEncryptString(designContent);
    var obj = utilExtend({
        created: utilCreateInternalTime(),
        extra: extra
    }, DocumentMeta, {
        design: encryped
    });
    return JSON.stringify(obj);
}

function utilAppDocumentLoadGhost(app, designStr) {
    var documentJson = JSON.parse(designStr), designJson = documentJson.debug === !0 ? JSON.parse(documentJson.design) : JSON.parse(utilDecryptString(documentJson.design));
    return app.doc.openGhost(designJson), app.doc;
}

//gaoning
function utilAppDocumentLoad(app, designStr) {
    //start add by gaoning 2017.3.8
    var picked = api.pickGetPicked();
    if (picked.length > 0 && picked[0].model.type == "FLOOR") {
        var pickMgr = app.pickMgr;
        utilPickMgrUnpickAll(pickMgr);
    }
    //end add by gaoning 2017.3.8

    //清理所有pattern by mond
    //utilSnapClearAllPattern();

    var doc = new Document();
    if (app.doc = doc, !designStr) {
        doc.open();
        return doc;
    }

    var documentJson = JSON.parse(designStr);
    var designVersion = parseFloat(documentJson.version);
    if (parseFloat(DocumentSupportedVersion_MAX) < designVersion || parseFloat(DocumentSupportedVersion_MIN) > designVersion) {
        doc.open();
        var msg = "UNSUPPORTED FILE VERSION, file version=" + documentJson.version + ", supported version=[" + DocumentSupportedVersion_MIN + ", " + DocumentSupportedVersion_MAX + "].";
        throw new Error(msg);
    }
    //读取墙宽度，高度  add by hcw
    DEFAULT_WALL_WIDTH=documentJson.extra ? documentJson.extra.wallWidth || DEFAULT_WALL_WIDTH :DEFAULT_WALL_WIDTH;
    DEFAULT_WALL_HEIGHT3D=documentJson.extra ? documentJson.extra.wallHeight || DEFAULT_WALL_HEIGHT3D :DEFAULT_WALL_HEIGHT3D;

    var designJson = documentJson.debug === !0 ? documentJson : JSON.parse(utilDecryptString(documentJson.design));
    doc.open(designJson);
    return doc;
}


function utilAppDocumentSetActiveCameras(app, cameraNames) {

    if (!Array.isArray(cameraNames)) throw new Error("argument is array of cameraName.");
    var fp = app.doc.floorplan;
    utilFloorplanSetActiveCamera(fp, cameraNames);

}

function utilAppDocumentGetCameras(app) {
    var fp = app.doc.floorplan;
    return utilFloorplanGetCamerasName(fp);
}

function utilAppDocumentGetActiveCamera(app) {
    var fp = app.doc.floorplan;
    return utilFloorplanGetActiveCamera(fp);
}

function AView(app, opt) {
    classBase(this, opt), this.app = app, this.opt = opt, this.actionMgr = this.app.actionMgr,
        this.settings = {}, utilRootDefineProperty(this, "doc", void 0, this._documentChangedCallback.bind(this));
    /*utilRootDefineProperty 在这里传进来的 是回调函数，没有触发 set方法。在这个方法里已经执行了回调*/
}

function utilViewSetFPS(app, viewId, fpsNumber) {
    var fps = Math.max(Math.min(50, fpsNumber), 5), view = app.views[viewId];
    return view ? (view.opt.fps = fps, view) : void 0;
}

function utilViewFit(app, viewId, opt1, opt2) {
    var view = app.views[viewId];
    if (view)
    {
        //点击户型居中显示。
        view.fit(opt1, opt2);
        return view;
    }
}

function utilAppGetViewById(app, viewId) {
    return app.views[viewId];
}

function AppBase(opt, settings) {
    classBase(this, opt), this.settings = settings, this.views = {}, this.actionMgr = new ActionManager(this),
        this.catalogMgr = new CatalogManager(this), this.documentReadyEvent = new Signal(),
        this.structureChangedEvent = new Signal(), utilRootDefineProperty(this, "doc", void 0, this._documentChangedCallback.bind(this));
    /*utilRootDefineProperty 在这里传进来的 是回调函数，没有触发 set方法。在这个方法里已经执行了回调*/
}

function utilAppGetServicePrefix(app, serviceName) {
    var appSettings = app.settings, servers = appSettings.servers[serviceName];
    if (servers && 0 != servers.length) {
        var server = servers[Math.ceil(10 * Math.random()) % servers.length];
        return "http://" + server.host + ":" + server.port;
    }
}

function utilAppGetServiceJSONResponsePromise(app, requestObject) {
    return requestObject.encodeFields && requestObject.encodeFields.forEach(function (field) {
        var val = requestObject[field];
        "string" != typeof val && (val = JSON.stringify(val)), requestObject[field] = utilEncryptString(val);
    }), new Promise(function (resolve, reject) {
        httpclient.ajax(requestObject).done(function (response) {
            var data;
            try {
                data = JSON.parse(utilDecryptString(response));
            } catch (e) {
                data = response;
            }
            resolve(data);
        }).fail(function (err) {
            __assert(!1), reject(err);
        });
    });
}
//自定义模型上进度条 add by hcw
function utilAppGetServiceJSONResponsePromiseUpload(app, requestObject) {
    return requestObject.encodeFields && requestObject.encodeFields.forEach(function (field) {
        var val = requestObject[field];
        "string" != typeof val && (val = JSON.stringify(val)), requestObject[field] = utilEncryptString(val);
    }), new Promise(function (resolve, reject) {
        requestObject.xhr=function(){
            var xhr=$.ajaxSettings.xhr();
            if(application.CustomModelProgress && xhr.upload){
                xhr.addEventListener('progress',application.CustomModelProgress,false);
            }
            return xhr;
        }
        httpclient.ajax(requestObject).done(function (response) {
            var data;
            try {
                data = JSON.parse(utilDecryptString(response));
            } catch (e) {
                data = response;
            }
            resolve(data);
        }).fail(function (err) {
            __assert(!1), reject(err);
        });
    });
}
function CatalogManager(app) {
    this.app = app, this.productsMeta = {}, this.productsDetail = {}, this.file = {},
        this.catalogServers = utilCatalogGetServers(app.settings, "catalog"), this.customCatalogServers = utilCatalogGetServers(app.settings, "customcatalog"), this.fileServers = utilCatalogGetServers(app.settings, "file");
}

function utilCatalogGetServers(setting, serviceName) {
    var servers = [];
    if (setting && setting.servers && setting.servers[serviceName]) {
        var svrs = setting.servers[serviceName];
        svrs.forEach(function (srv) {
            servers.push("http://" + srv.host + ":" + srv.port + "/");
        });
    }
    return servers;
}

/*获取分类目录树*/
function utilCatalogGetCatalogTreePromise(catalogMgr, _brand) {
    var brand = _brand || "full", hosts = catalogMgr.catalogServers, host = hosts[Math.ceil(1e4 * Math.random()) % hosts.length], url = host + "getCatalogTree?brand=" + brand + "&d";
    return new Promise(function (resolve, reject) {
        httpclient.ajax({
            url: url,
            type: "GET",
            success: function (response) {
                var data;
                data = utilDecryptString(response), data = response;
                var rv = JSON.parse(data);
                resolve(rv);
            },
            error: function (err) {
                __assert(!1), reject(err);
            }
        });
    });
}


/* 第一次访问时帮用户建立一个自定义拼花根目录，如果已存在不用再创建
 * 暂时硬编码写死host  host ="http://120.27.236.252:5554/" ，在api项目build后直接修改api.js
 * add by oxl 2017-03-14
 * 修改参数可变目录oxl-2017-08-23
 * */
function utilSetUserRootCustomCatalogPromise(catalogMgr,apiurl, _brand) {
    var hosts = catalogMgr.customCatalogServers, host = hosts[Math.ceil(1e4 * Math.random()) % hosts.length], url = host + apiurl;
    return new Promise(function (resolve, reject) {
        httpclient.ajax({
            url: url,
            data: {
                globalUserLoginId: globalUsrObj.globalUserLoginId,
                globalPartyId: globalUsrObj.globalPartyId,
                globalAccessTokenValue: globalUsrObj.globalAccessTokenValue
            },
            type: "POST",
            success: function (response) {
                resolve(response);
            },
            error: function (err) {
                __assert(!1), reject(err);
            }
        });
    });
}

/* TODO 获取 自定义拼花分类数据后，继续插入页面
 * 获取自定义拼花分类目录树，通过partyId来查询用户的目录
 * 暂时硬编码写死host  host ="http://120.27.236.252:5554/"，在api项目build后直接修改api.js
 * add by oxl 2017-03-01
 * */
function utilGetCustomTileCatalogTreePromise(catalogMgr, _brand) {
    var brand = _brand || "full", hosts = catalogMgr.customCatalogServers, host = hosts[Math.ceil(1e4 * Math.random()) % hosts.length], url = host + "getCustomTileCatalogTree?brand=" + brand + "&d";
    return new Promise(function (resolve, reject) {
        httpclient.ajax({
            url: url,
            type: "GET",
            data: {
                globalPartyId: globalUsrObj.globalPartyId
            },
            success: function (response) {
                var data;
                data = utilDecryptString(response), data = response;
                var rv = JSON.parse(data);
                resolve(rv);
            },
            error: function (err) {
                __assert(!1), reject(err);
            }
        });
    });
}

function utilCatalogGetProductsDetailPromise(catalogMgr, pIds) {
}

function utilCatalogGetProductsMetaPromise(catalogMgr, pIds) {
    __assert(Array.isArray(pIds));
    var hosts = catalogMgr.catalogServers;
    var productIds = pIds.filter(function (productId) {
        return void 0 == catalogMgr.productsMeta[productId];
    });
    if (0 == productIds.length) {
        var rv = {};
        return pIds.forEach(function (pId) {
            rv[pId] = catalogMgr.productsMeta[pId];
        }), Promise.resolve(rv);
    }
    var host = hosts[Math.ceil(1e4 * Math.random()) % hosts.length];
    var url = host + "getProductsMeta?d";
    return new Promise(function (resolve, reject) {
        httpclient.ajax({
            url: url,
            data: {
                ids: productIds.join(",")
            },
            type: "POST",
            success: function (response) {
                var data;
                data = utilDecryptString(response), data = response, JSON.parse(data).forEach(function (item) {
                    catalogMgr.productsMeta[item.pid] = item;
                });
                var rv = {};
                pIds.forEach(function (pId) {
                    rv[pId] = catalogMgr.productsMeta[pId];
                }), resolve(rv);
            },
            error: function (err) {
                __assert(!1), reject(err);
            }
        });
    });
}
/*编辑套装模式下，保存套装后，清除productsMeta里面的对应产品缓存数据 add by hcw*/
function clearProductMetaCache(catalogMgr, pId){
    delete catalogMgr.productsMeta[pId]
}

/*获取自定义拼花元数据promise add by oxl 2017-03-24
 * 硬编码写死做测试 host ="http://120.27.236.252:5554/"
 * */
function utilCatalogGetCustomProductsMetaPromise(catalogMgr, pIds) {
    __assert(Array.isArray(pIds));
    var hosts = catalogMgr.customCatalogServers, productIds = pIds.filter(function (productId) {
        return void 0 == catalogMgr.productsMeta[productId];
    });
    if (0 == productIds.length) {
        var rv = {};
        return pIds.forEach(function (pId) {
            rv[pId] = catalogMgr.productsMeta[pId];
        }), Promise.resolve(rv);
    }
    var host = hosts[Math.ceil(1e4 * Math.random()) % hosts.length], url = host + "getCustomProductsMeta?d";
    return new Promise(function (resolve, reject) {
        httpclient.ajax({
            url: url,
            data: {
                ids: productIds.join(",")
            },
            type: "POST",
            success: function (response) {
                var data;
                data = utilDecryptString(response), data = response, JSON.parse(data).forEach(function (item) {
                    catalogMgr.productsMeta[item.pid] = item;
                });
                var rv = {};
                pIds.forEach(function (pId) {
                    rv[pId] = catalogMgr.productsMeta[pId];
                }), resolve(rv);
            },
            error: function (err) {
                __assert(!1), reject(err);
            }
        });
    });
}

/*获取自定模型数据promise add by hcw 2017-09-07
 * 添加 clearCache参数 为true时清除缓存 add by hcw
 * */
function utilCatalogGetCustomModelProductsMetaPromise(catalogMgr, pIds,clearCahce) {
    __assert(Array.isArray(pIds));
    var hosts = catalogMgr.customCatalogServers, productIds = pIds.filter(function (productId) {
        return void 0 == catalogMgr.productsMeta[productId];
    });
    if (0 == productIds.length) {
        var rv = {};
        return pIds.forEach(function (pId) {
            clearCahce? delete  catalogMgr.productsMeta[pId]:rv[pId] = catalogMgr.productsMeta[pId];
        }), Promise.resolve(rv);
    }
    var host = hosts[Math.ceil(1e4 * Math.random()) % hosts.length], url = host + "getCustomProductsMeta?d";
    return new Promise(function (resolve, reject) {
        httpclient.ajax({
            url: url,
            data: {
                ids: productIds.join(",")
            },
            type: "POST",
            success: function (response) {
                var data;
                data = utilDecryptString(response), data = response, JSON.parse(data).forEach(function (item) {
                    catalogMgr.productsMeta[item.pid] = item;
                });
                var rv = {};
                pIds.forEach(function (pId) {
                    rv[pId] = catalogMgr.productsMeta[pId];
                }), resolve(rv);
            },
            error: function (err) {
                __assert(!1), reject(err);
            }
        });
    });
}

function utilCatalogGetFileUrl(catalogMgr, category, productId, type, format) {
    var hosts = catalogMgr.fileServers, getKey = productId + type;
    if (getKey) {
        for (var keyNumber = 0, i = 0, len = getKey.length; len > i; ++i) keyNumber += getKey.charCodeAt(i);
        var host = hosts[keyNumber % hosts.length];
        
        if(category == "product"){
        	if(type == "obj"){
        		return "https://pic.oceano.com.cn/h5filesystem/products/" + productId + "/product.obj";
        	}else if(type == "top"){
        		return "https://pic.oceano.com.cn/h5filesystem/products/" + productId + "/top." + (format || "jpg");        		
        	}
        }
      	var url = host + "getFile?category=" + category + "&id=" + productId + "&type=" + type + "&d";
      	return url;
    }
}
/*作用待定 需要跟踪一下 add by oxl 2017-03-27*/
function utilCatalogGetFileContentPromise(catalogMgr, category, productId, type) {
    if (void 0 != catalogMgr.file[productId + type]) return Promise.resolve(catalogMgr.file[productId + type]);
    var url = utilCatalogGetFileUrl(catalogMgr, category, productId, type);
    return new Promise(function (resolve, reject) {
        httpclient.ajax({
            url: url,
            cache: !0,
            success: function (resp) {
                var data = "obj" == type ? utilDecryptString(resp) : resp;
                data = resp, catalogMgr.file[productId + type] = data, resolve(data);
            },
            error: function (err) {
                reject(err);
            }
        });
    });
}
function getTmallOrderinfoPromise() {
    var room=api.pickGetPicked();
    var roomName=''
    var date=new Date()
    var jsonData = {
        "Project": "",
        "Title": "",
        "Client": "",
        "Manager": "",
        "Designer": "",
        "ClientTel": "",
        "OfficeTel": "",
        "DrawingNo": "",
        "Scale": "",
        "Address": "",
        "Date": date.toLocaleDateString()
    };
    if(room.length>0 && room[0].model.type=="FLOOR"){
        roomName=room[0].model.label;
    }
    return new Promise(function (resolve, reject) {
        if(!designId)resolve(false);
        if(globalLeadId && globalLeadId && globalOppId){
                httpclient.ajax({
                    url: '/control/getOpportunity',
                    type:"post",
                    cache: !0,
                    data: {'folId': globalFolId, 'leadId': globalLeadId, 'oppId': globalOppId},
                    success: function (resp) {
                        if(resp.returnValue.resp_msg == 'Success') {
                            var address = resp.returnValue.opp;
                            if (!address) {
                                resolve(jsonData)
                            }else{
                                jsonData.Project=roomName;
                                jsonData.Client=address.customerName
                                jsonData.ClientTel=address.mobile
                            }
                        }
                        resolve(jsonData)
                    },
                    error: function (err) {
                        resolve(jsonData)
                    }
                });
        }else{
            var loginParam = "?userLoginId=" + globalUsrObj.globalUserLoginId + "&password=" + globalUserLoginPassword;
            httpclient.ajax({
                url: '/control/rpccommonrequest' + loginParam,
                type: 'post',
                data: {'method': 'ipadCrmListCustomerAddress', 'customerId': globalCustomerId,userLoginId:globalUsrObj.globalUserLoginId},
                success: function (resp) {
                    if(resp.returnValue.status=='30000'){
                        var customerInfo = resp.returnValue.data[0];
                        jsonData.Client=customerInfo.name
                        jsonData.ClientTel=customerInfo.contactPhone;
                        jsonData.Project=customerInfo.provinceName+customerInfo.cityName+customerInfo.areaName+customerInfo.address;
                        httpclient.ajax({
                            url: '/control/ajaxGetTableDesign',
                            type: 'post',
                            data: {designId:designId},
                            success: function (data) {
                                if(data.designEntity){
                                    jsonData.Title=data.designEntity.designName;
                                }
                                resolve(jsonData)
                            },
                            error:function (resp) {
                                resolve(jsonData)
                            }
                        })
                    }else{
                        resolve(jsonData)
                    }
                },
                error: function (err) {
                    resolve(jsonData)
                }
            });
        }
    });
}
/*add by oxl
 *使用classBase前先使用继承，EditorApp就可以使用父函数AppBase的方法
 *classInherit(EditorApp, AppBase), utilExtend(EditorApp.prototype, {});
 *
 * */

function EditorApp(opt, settings) {
    classBase(this, opt, settings), this.keyboardMgr = new KeyboardMgr(this), this.pickMgr = new PickMgr(this),
        this.rulerMeasurementChanged = new Signal(), this.documentLockChangedEvent = new Signal();
}

function utilAppGetVersion(app) {
    return "MVT ; BUILD_VERSION";
}

function KeyboardMgr(app) {
    this.app = app, $ && ($(document).on("keydown", null, "f4", utilF4KeyDown.bind(this)),
        $(document).on("keydown", null, "esc", utilESCDown.bind(this)),
        $(document).on("keydown", null, "del", utilDeleteDown.bind(this)),
        $(document).on("keydown", null, "backspace", utilDeleteDown.bind(this)),
        $(document).on("keydown", null, "space", utilWhitespaceDown.bind(this)),
        $(document).on("keydown", null, "w", utilThreedKeyDown.bind(this, "translate")),
        $(document).on("keydown", null, "e", utilThreedKeyDown.bind(this, "rotate")),
        $(document).on("keydown", null, "r", utilThreedKeyDown.bind(this, "scale")),
        $(document).on("keydown", null, "z", utilThreedFitKeyDown.bind(this)),
        $(document).on("keydown", null, "m", utilMaterialDropperKeyDown.bind(this)),
        $(document).on("keydown", null, "n", utilWallDropperKeyDown.bind(this)),
        $(document).on("keydown", null, "up", utilCameraMovement.bind(this, "up")),
        $(document).on("keydown", null, "down", utilCameraMovement.bind(this, "down")),
        $(document).on("keydown", null, "left", utilCameraMovement.bind(this, "left")),
        $(document).on("keydown", null, "right", utilCameraMovement.bind(this, "right")),
        $(document).on("keydown", null, "pageup", utilCameraMovement.bind(this, "pageup")),
        $(document).on("keydown", null, "pagedown", utilCameraMovement.bind(this, "pagedown")),
        $(document).on("keydown", null, "ctrl+z", utilKeyboardAction.bind(this, "undo")),
        $(document).on("keydown", null, "ctrl+y", utilKeyboardAction.bind(this, "redo"))),
        //add by gaoning 2016.12.2
        $(document).on("keydown", null, "f", utilWhiteFDown.bind(this)),
        //add by gaoning 2016.12.2
        //add by gaoning 2017.2.9
        $(document).on("keydown", null, "ctrl+c", utilKeyboardCopyAction.bind(this, "copy")),
        $(document).on("keydown", null, "ctrl+v", utilKeyboardCopyAction.bind(this, "pause"));
    //add by gaoning 2017.2.9
}

//start add by gaoning 2017.2.9
function utilKeyboardCopyAction(cmd) {
    "copy" == cmd ? utilActionCopy(this.app.actionMgr) : "pause" == cmd && utilActionPause(this.app.actionMgr);
}
//end add by gaoning 2017.2.9

function utilKeyboardAction(cmd) {
    "undo" == cmd ? utilActionUndo(this.app.actionMgr) : "redo" == cmd && utilActionRedo(this.app.actionMgr);
}

function utilF4KeyDown(e) {
    SNAP_ADDWALL_SNAP_ENABLE = !SNAP_ADDWALL_SNAP_ENABLE;
}

function utilMaterialDropperKeyDown(e) {
    utilActionBegin(this.app.actionMgr, "MaterialDropper");
}

function utilWallDropperKeyDown(e) {
	  utilActionBegin(this.app.actionMgr, "WallDropper");
}

function utilThreedKeyDown(mode, e) {
    var view3d = this.app.views["3d"];
    view3d && utilThreeViewSetTransformMode(view3d, mode);
}

//add by gaoning - 2016.12.2--start
function utilWhiteFDown(t) {
    var pickObj = api.pickGetPicked(function (e) {
        return e;
    })[0].model;
    //console.log("pickObj.type = " + pickObj.type);
    if (pickObj.type == "PRODUCT" || pickObj.type == "PRODUCTREPLACEMENT") {
        var curCamera;
        var curCameraList = api.floorplanFilterEntity(function (e) {
            return e.type == "CAMERA";
        });
        for (var i = 0; i < curCameraList.length; i++) {
            if (curCameraList[i].active == true) {
                curCamera = curCameraList[i];
            }
        }
        curCamera.tx = pickObj.x;
        curCamera.ty = pickObj.y;
        var obj_r = 3;
        //console.log("pickObj.rot = "+pickObj.rot);
        curCamera.x = pickObj.x + Math.sin(pickObj.rot * 2 * Math.PI / 360) * obj_r;
        curCamera.y = pickObj.y - Math.cos(pickObj.rot * 2 * Math.PI / 360) * obj_r;

    } else if (pickObj.type == "WALL") {
    } else {
    }

}
//add by gaoning - 2016.12.2--end


function utilThreedFitKeyDown(e) {
    var fp = this.app.doc.floorplan, view3d = this.app.views["3d"];
    if (view3d) {
        var camera = utilFloorplanGetActiveCamera(fp);
        if ("cameraFly" == camera.id) utilThreeCameraFlyFitView(view3d); else {
            var picked = utilPickMgrGetPickResults(this.app.pickMgr);
            if (0 == picked.length) return;
            var model = picked[0].model;
            if (!(model instanceof Product)) return;
            camera.tx = model.x, camera.ty = model.y;
        }
    }
}

function utilESCDown(e) {
    var rv = utilActionRun(this.app.actionMgr, "keydown", e, "ESC");
    rv !== !0 && utilActionEnd(this.app.actionMgr);

    RemoveMouseToWallLine();
}

function utilDeleteDown(e) {
    var picked = this.app.pickMgr.pickResults;
    Object.keys(picked).forEach(function (pick) {
        var model = picked[pick].model;
        if(model.group){ ///在编辑组合时，删除最后一个物体同时删除该组合  add by hcw
            if(model.group.children.length==1){
                model=model.group;
            }
        }
        if(model){
        	if(model.type == Annotation.prototype.type || model.type == Product.prototype.type || model.type == Door.prototype.type || model.type == Windows.prototype.type || model.type == ProductReplacement.prototype.type || model instanceof Cube){
        		utilActionBegin(this.app.actionMgr, ActionDeleteProduct.prototype.type, model);
          }else if(model.type == Wall.prototype.type){
          	utilActionBegin(this.app.actionMgr, ActionDeleteWall.prototype.type, model);
          }else if(model instanceof Area){
          	utilActionBegin(this.app.actionMgr, ActionDeleteArea.prototype.type, model);
          }else if(model instanceof Group){
          	utilActionBegin(this.app.actionMgr, ActionDeleteGroup.prototype.type, model);
          }else if(model instanceof Boundary){
          	utilActionBegin(this.app.actionMgr, ActionDeleteBoundary.prototype.type, model);
          }
          utilActionEnd(this.app.actionMgr);
        }
    }, this);
    utilPickMgrUnpickAll(this.app.pickMgr);
}

function utilWhitespaceDown(e) {
    function callRotAction(type, model) {
        utilActionBegin(actionMgr, type, model), utilActionRun(actionMgr, "whitespace"),
            utilActionEnd(actionMgr, type);
    }

    var actionMgr = this.app.actionMgr, pickMgr = this.app.pickMgr;
    if (actionMgr.current) return void utilActionRun(actionMgr, "whitespace");
    var picked = pickMgr.pickResults;
    Object.keys(picked).forEach(function (pick) {
        var model = picked[pick].model;
        model && (model.type == Product.prototype.type || model.type == ProductReplacement.prototype.type || model instanceof Cube ? (callRotAction(ActionRotateProduct.prototype.type, model),
            utilPickMgrRepick(pickMgr, model)) : model instanceof Opening ? callRotAction(ActionChangeDoorSwing.prototype.type, model) : model instanceof Group && callRotAction(ActionRotateGroup.prototype.type, model));
    }, this);
}

function utilCameraMovement(key, e) {
    var app = this.app, fp = app.doc.floorplan, cam = utilFloorplanGetActiveCamera(fp), dir = Vec2.difference({
        x: cam.tx,
        y: cam.ty
    }, {
        x: cam.x,
        y: cam.y
    }).normalize().scale(.05);
    switch (key) {
        case "up":
            cam.x += dir.x, cam.y += dir.y, cam.tx += dir.x, cam.ty += dir.y;
            break;

        case "down":
            cam.x -= dir.x, cam.y -= dir.y, cam.tx -= dir.x, cam.ty -= dir.y;
            break;

        case "left":
            cam.x -= dir.y, cam.y += dir.x, cam.tx -= dir.y, cam.ty += dir.x;
            break;

        case "right":
            cam.x += dir.y, cam.y -= dir.x, cam.tx += dir.y, cam.ty -= dir.x;
            break;

        case "pageup":
            cam.z += .05;
            break;

        case "pagedown":
            cam.z = Math.max(cam.z - .05, .1);
    }
}

function PickMgr(app) {
    this.app = app, this.pickResults = {}, this.pickChangedEvent = new Signal();
}

function PickResult(model, opt) {
    this.model = model, this.modelPos = void 0, this.screenPos = void 0, this.opt = opt,
    opt && opt.modelPos && (this.modelPos = opt.modelPos), opt && opt.screenPos && (this.screenPos = opt.screenPos);
}

function utilPickMgrGetPickResults(mgr) {
    var results = [];
    return Object.keys(mgr.pickResults).forEach(function (rId) {
        results.push(mgr.pickResults[rId]);
    }), results;
}
/*获取当前选中的套装组合 add by hcw*/
function utilPickMgrGetPickGroupResults(mgr) {
    var results;
    return Object.keys(mgr.pickResults).forEach(function (rId) {
        var isProduct=true;
        if(mgr.pickResults[rId].model instanceof Group && mgr.pickResults[rId].model.id!='TempGroup'){
            mgr.pickResults[rId].model.children.forEach(function (p) {
                if(!( p instanceof Product))isProduct=false
            })
            isProduct && (results=mgr.pickResults[rId].model.children);
        }
    }), results;
}

function utilPickMgrIsPicked(mgr, model) {
    return mgr.pickResults[model.id];
}

function utilPickMgrPick(mgr, model, opt) {
    utilModelSetFlagOn(model, MODELFLAG_PICKED);
    var result = new PickResult(model, opt);
    mgr.pickResults[model.id] = result, mgr.pickChangedEvent.dispatch("select", result);
}

function utilPickMgrRepick(mgr, model) {
    utilModelSetFlagOff(model, MODELFLAG_PICKED), utilModelSetFlagOn(model, MODELFLAG_PICKED);
}

function utilPickMgrUnpick(mgr, model) {
    utilModelSetFlagOff(model, MODELFLAG_PICKED);
    var result = mgr.pickResults[model.id];
    delete mgr.pickResults[model.id], mgr.pickChangedEvent.dispatch("unselect", result);
}

function utilPickMgrUnpickAll(mgr) {
    Object.keys(mgr.pickResults).forEach(function (modelID) {
        var model = mgr.pickResults[modelID].model;
        utilPickMgrUnpick(mgr, model);
    });
}

var DocumentMeta = {
    version: "1.0"
}, DocumentSupportedVersion_MIN = "1.0", DocumentSupportedVersion_MAX = DocumentMeta.version;

Document.prototype.type = "DOCUMENT", classInherit(Document, Root), utilExtend(Document.prototype, {
    openGhost: function (designJson) {
        var design = designJson.design;
        var doc = this;
        __assert(Array.isArray(design), "bad design format");
        var productsId = (Root.prototype.database, []);
        var floorplan = null;
        design.forEach(function (modelJson) {
            modelJson.pid && productsId.push(modelJson.pid);
            (modelJson.type == "FLOORPLAN") && (floorplan = modelJson);
        });

        //清理非floorplan所属对象
        for(var i = 0;i<design.length;){
        	  var modelJson = design[i];
        	  var remove = true;
            modelJson.lt.forEach(function(lt){
            	(lt == floorplan.id) && (remove = false);
            });

            if((modelJson.type == "RECTAREA" || modelJson.type == "PRODUCT") && remove){
            	design.splice(i,1);
            }else{
            	++i;
            }
        };

        var cMgr = application.catalogMgr;
        utilCatalogGetProductsMetaPromise(cMgr, productsId).then(function (meta) {
            var floorplanLight = {};
            design.forEach(function (modelJson) {
                var pMeta = cMgr.productsMeta[modelJson.pid];
                pMeta && (modelJson = utilExtend({}, pMeta, modelJson));
                floorplanLight[modelJson.id] = modelJson;
            }, this);
            doc.floorplanGhost = utilFloorplanLightBuildFromObject(floorplanLight);
            doc.floorplanGhostLoadCompleteEvent.dispatch(doc.floorplanGhost);
        });
    },
    open: function (designJson) {
        if (this.close(), __assert(void 0 == this.floorplan, "the document already opened!"),
                !designJson) return this.floorplan = new Floorplan(), this.floorplanCreatedEvent.dispatch(),
            this.floorplan.init(), void (application && application.documentReadyEvent.dispatch(doc));
        var design = designJson.design;
        __assert(Array.isArray(design), "bad design format");
        var db = Root.prototype.database, doc = this, productsId = [];
        design.forEach(function (modelJson) {
            modelJson.pid && productsId.push(modelJson.pid);
        });
        var cMgr = application.catalogMgr;
        utilCatalogGetProductsMetaPromise(cMgr, productsId).then(function (meta) {

            //添加自定义拼花meta初始化过程
            utilCatalogGetCustomProductsMetaPromise(cMgr, productsId).then(function(meta){
            	  design.forEach(function (modelJson) {
		                var pMeta = cMgr.productsMeta[modelJson.pid];
		                pMeta && (modelJson = utilExtend({}, pMeta, modelJson));
		                var type = TYPE[modelJson.type], m = type && void 0 == db[modelJson.id] ? new type(modelJson) : db[modelJson.id];
		                modelJson.type == Floorplan.prototype.type && (doc.floorplan = m);
                        if(modelJson.type=="GROUP" && modelJson.id!="TempGroup"){
                          setTimeout(function () {
                              utilGroupUpdateBoxCenter(m);
                              utilModelIsFlagOn(m, MODELFLAG_PICKED)?utilModelChangeFlag(m, MODELFLAG_PICKED):utilModelChangeFlag(m, MODELFLAG_HIDDEN);
                              utilPickMgrUnpickAll(application.pickMgr);
                              application.laberFrame();
                          },100)
                        }
		            }, this);

		            doc.floorplanCreatedEvent.dispatch();
		            doc.floorplan.init();
		            utilDocumentRecursiveLoadModelObjectAndRelationship(design, doc.floorplan);
		            doc.floorplanLoadCompleteEvent.dispatch(doc);
		            utilAppFloorplanLock(application, !0);
		            application.documentReadyEvent.dispatch(doc);

		            //start add by gaoning 检测有鸟瞰相机重新设置属性值。
		            var curCameraList = api.floorplanFilterEntity(function (e) {
		                return e.type == "CAMERA";
		            });
		            for (var i = 0; i < curCameraList.length; i++) {
		                if (curCameraList[i].id == "cameraFly")
		                {
		                    curCameraList[i].name = CAMERA_FLY_DEFAULT_NAME;
		                    curCameraList[i].z = 10;
		                    curCameraList[i].x = 0;
		                    curCameraList[i].y = -10;
		                    curCameraList[i].tx = 0;
		                    curCameraList[i].ty = 0;
		                    curCameraList[i].pitch = -45;
		                    curCameraList[i].hfov = 60;
		                }
		            }
		            //end add by gaoning
            });
        });
    },
    close: function () {
        var db = Root.prototype.database;
        Object.keys(db).forEach(function (id) {
            var model = this[id];
            model instanceof ModelObject && (model.destroy(), delete this[id]);
        }, db), this.floorplan = void 0;
    },
    save: function (opt) {  //保存方案--gaoning
    	  var floorplanID = this.floorplan.id;

    	  function infloorplan(model){
    	  	return model.lt[floorplanID] != null;
    	  }

        function saveModelObject(model) {
            if (!(saveUnderImage === !1 && model instanceof Underlay)) {
                //utilSaveFilterModelInRoom(pickedRoom, model) === !0 && (models[model.id] = model.save());
                //if (utilSaveFilterModelInRoom(pickedRoom, model) === !0) {
                    try {
                    	  if(model.type == "PRODUCT"){
                    	  	if(!infloorplan(model)){
                    	  		return;
                    	  	}
                    	  }

                        models[model.id] = model.save();
                        __log("Save success! the model id is : " + model.id);
                    } catch (err) {

                        api.getServiceJSONResponsePromise({
                            type: "POST", url: api.getServicePrefix("notify") + "/log", data: {
                                to: "erroralert_desos@oceano.com.cn", subject: "test",
                                text: "Save Document info:" + err
                            }
                        }).then(function (res) {
                        });
                    }

                //}
                for (var linksId in model.lf)
                    saveModelObject(model.lf[linksId]);
            }
        }

        var models = {}, pickedRoom = opt && opt.pickedRoom, saveUnderImage = opt && opt.saveUnderImage;
        saveModelObject(this.floorplan);
        var rv = {
            design: Object.keys(models).map(function (modelId) {
                return models[modelId];
            })
        };
        return opt && opt.extralight === !0 && (rv.extralight = utilFloorplanBuildExtraLight(this.floorplan)),
            rv;
    }
});

var utilDocumentRecursiveLoadModelObjectAndRelationship = function (design, modelObject) {
    if (modelObject) {
        var modelJson = design.filter(function (modelMeta) {
            return modelObject.id == modelMeta.id;
        })[0];
        __log("LOAD:" + modelObject.type), modelJson && modelObject.load(modelJson);
        for (var db = Root.prototype.database, i = 0, len = modelJson.lf.length; len > i; ++i) {
            var linksId = modelJson.lf[i];
            utilDocumentRecursiveLoadModelObjectAndRelationship(design, db[linksId]);
        }
    }
};
/* TODO AView.prototype 的 _documentChangedCallback 方法 ，里面的 this.onDocumentChanged()，实际执行的代码在
 * BaseView.prototype,第70行代码 的 onDocumentChanged 方法 --在文件canvas.base.comp.js
 * AView 继承 Root
 * add by oxl -2017-2-27*/
classInherit(AView, Root), utilExtend(AView.prototype, {
    _documentChangedCallback: function (propertyName, oldDoc, newDoc) {
        __assert(newDoc instanceof Root), this.onDocumentChanged();
    },
    changeSettings: function (settingKey, settingValue) {
        this.settings[settingKey] = settingValue;
    },
    onDocumentChanged: function () {
        this.clear();
    },
    init: function () {
    },
    clear: function () {
    },
    update: function (force, option, callback) {
        var doc = this.doc;
        doc && (__assert(doc instanceof Root), this.onUpdate && this.onUpdate(force, option),
        callback && callback.call(this));
    },
    onUpdate: function (force, option) {
        __log("update this view: id=" + this.id);
    }
}), AppBase.prototype.type = "APPBASE", classInherit(AppBase, Root), utilExtend(AppBase.prototype, {
    _documentChangedCallback: function (propertyName, oldDoc, newDoc) {
        __assert(oldDoc != newDoc), __assert(newDoc instanceof Root), oldDoc && oldDoc.close();
        for (var name in this.views) {
            var view = this.views[name];
            view.doc = newDoc;
        }
        this.updateViews(!0);
    },
    addView: function (v) {
        return v instanceof AView || __assert(!1, "bad view!"), v.init(), this.views[v.id] = v,
            v;
    },
    updateViews: function (force, option) {
        for (var id in this.views) {
            var view = this.views[id];
            view.update(force || !0, option);
        }
    },
    run: function (option) {
        function animateUpdate(view) {
            var delay = (view.update(), view.opt && view.opt.fps ? 1e3 / view.opt.fps : 100);
            setTimeout(animateUpdate, delay, view);
        }

        for (var id in this.views) {
            var view = this.views[id];
            !function (view) {
                animateUpdate(view);
            }(view);
        }
        __log("----------application RUNS!!-------");
    }
});

/*TODO 自定义拼花用到了这个方法 需要跟踪一下 add by oxl 2017-03-27*/
var utilCatalogGetFileContentPromise = function () {
    var getPromiseCache = {};
    return function (catalogMgr, category, productId, type) {
        var getKey = productId + type;
        if (void 0 != catalogMgr.file[getKey]) return Promise.resolve(catalogMgr.file[getKey]);
        var url = utilCatalogGetFileUrl(catalogMgr, category, productId, type), promise = new Promise(function (resolve, reject) {
            var allPromises = getPromiseCache[getKey];
            allPromises ? (allPromises.resolves.push(resolve), allPromises.rejects.push(reject)) : (allPromises = getPromiseCache[getKey] = {
                resolves: [resolve],
                rejects: [reject]
            }, httpclient.ajax({
                url: url,
                success: function (resp) {
                    var data = "obj" == type ? utilDecryptString(resp) : resp;
                    data = resp, catalogMgr.file[getKey] = data, allPromises.resolves.forEach(function (resolve) {
                        resolve(data);
                    }), delete getPromiseCache[getKey];
                },
                error: function (err) {
                    allPromises.rejects.forEach(function (reject) {
                        reject(err);
                    }), delete getPromiseCache[getKey];
                }
            }));
        });
        return promise;
    };
}();

/*TODO 自定义拼花用到了这个方法 需要跟踪一下 add by oxl 2017-03-27  自定义模型读取 add by hcw 去掉缓存*/
var utilCustomModelGetFileContentPromise = function () {
    var getPromiseCache = {};
    return function (catalogMgr, category, productId, type) {
        getPromiseCache={};
        var getKey = productId + type;
        var url =utilCatalogGetFileUrl(catalogMgr, category, productId, type), promise = new Promise(function (resolve, reject) {
            var allPromises = getPromiseCache[getKey];
            allPromises ? (allPromises.resolves.push(resolve), allPromises.rejects.push(reject)) : (allPromises = getPromiseCache[getKey] = {
                resolves: [resolve],
                rejects: [reject]
            }, httpclient.ajax({
                url: url,
                cache: false,
                success: function (resp) {
                    var data = "obj" == type ? utilDecryptString(resp) : resp;
                    data = resp, allPromises.resolves.forEach(function (resolve) {
                        resolve(data);
                    }), delete getPromiseCache[getKey];
                },
                error: function (err) {
                    allPromises.rejects.forEach(function (reject) {
                        reject(err);
                    }), delete getPromiseCache[getKey];
                }
            }));
        });
        return promise;
    };
}();

//读取，设置墙宽度，高度 add by hcw
function setWallInfo(valueObj) {
    if(valueObj){
        if(valueObj.hasOwnProperty('width')){
            DEFAULT_WALL_WIDTH=valueObj.width;
        }
        if(valueObj.hasOwnProperty('height')){
            DEFAULT_WALL_HEIGHT3D=valueObj.height;
        }
    }else{
        return {width:DEFAULT_WALL_WIDTH,height:DEFAULT_WALL_HEIGHT3D}
    }
}

/*add by oxl
 *AppBase继承根ROOT函数
 * AppBase.prototype.type = "APPBASE", classInherit(AppBase, Root)
 * */
EditorApp.prototype.type = "EDITORAPP", classInherit(EditorApp, AppBase), utilExtend(EditorApp.prototype, {});
