function SnapView(app, domElement, opt) {
    classBase(this, app, domElement, opt);
    this.layerOrder = [
        Underlay.prototype.type,
        "Grid",
        AREA_OUTER_CATEGORY_ID,
        Floor.prototype.type,
        Boundary.prototype.type,
        AREA_INNER_CATEGORY_ID,
        Wall.prototype.type,
        Point.prototype.type,                
        "SLIDINGDOOR",
        "CASEMENTDOOR",
        "BATHTUB",
        "BAYWINDOW",
        "CASEMENTWINDOW",
        "SLIDINGWINDOW",
        "TOILET",

        "ROOM",
        "CARPET",
        "BASEMENT",
        "SEAT",
        "SURFACE",
        "SURFACE_SEAT",
        "DECORATION",
        "PILLAR",
        "BACKGROUNDWALL",
        "BACKGROUNDWALL_LIGHT",
        "LIGHT",
        Group.prototype.type,
        "IES",
        "FILLLIGHT",
        "CEILING",
        "BEAM",
        Opening.prototype.type,
        Windows.prototype.type,
        Door.prototype.type,
        SNAP_LAYER_IN_DIMENSION,
        SNAP_LAYER_IN_DIMENSION_INNER,//add by gaoning 2017.8.10增加内墙标尺
        SNAP_LAYER_OUT_DIMENSION,
        SNAP_LAYER_ROOMLABEL,
        BezierPoint.prototype.type,
        VRHotspot.prototype.type,
        Annotation.prototype.type,
        Camera.prototype.type,
        WalkThrough.prototype.type,
        "AUXILLARY_ARROW",//物体辅助箭头层上
        "PRODUCT_MARK",//物体标距线层 
        "Temp",
        "PRODUCT_MARK_TEXT",//物体标距线层  文字 矩形  
        "LOCKCAMERA",
    ];
    this.layers = {};
    this.zoomChangedEvent = new Signal();
    var view = this;
    this.zoomChangedEvent.add(function (viewport) {
        var viewIsSmall = Math.min(viewport.width, viewport.height) > 3e3;
        view.layers[SNAP_LAYER_ROOMLABEL].attr("display", view.settings.showRoomLabel !== !0 || viewIsSmall ? "none" : "block");
        view.layers[SNAP_LAYER_IN_DIMENSION].attr("display", view.settings.showDimensionLayer !== !0 || viewIsSmall ? "none" : "block");
        view.layers[SNAP_LAYER_IN_DIMENSION_INNER].attr("display", view.settings.showInnerDimensionLayer !== !0 || viewIsSmall ? "none" : "block");//add by gaoning 2017.8.10增加内墙标尺
    });
}

function utilSvgVectorScreenSpaceToModelSpace(view, screen_offset_x, screen_offset_y) {
    var mPos = utilSvgScreenSpaceToModelSpace(view, screen_offset_x, screen_offset_y), mZeroPos = utilSvgScreenSpaceToModelSpace(view, 0, 0);
    return {
        x: mPos.x - mZeroPos.x,
        y: mPos.y - mZeroPos.y
    };
}

function utilSvgScreenSpaceToModelSpace(view, screen_x, screen_y) {
    var viewElementBound = view.getBoundingClientRect();
    var viewportBound = view.viewport;
    var scale_x = viewportBound.width / viewElementBound.width;
    var scale_y = viewportBound.height / viewElementBound.height;
    var x = (screen_x - viewElementBound.left) * scale_x + viewportBound.left;
    var y = (screen_y - viewElementBound.top) * scale_y + viewportBound.top;
    return {
        x: x / 100,
        y: -y / 100
    };
}

function utilSvgModelSpaceToScreenSpace(view, model_x, model_y) {
    var screen_x = 100 * model_x;
    var screen_y = 100 * -model_y;
    var viewElementBound = view.getBoundingClientRect();
    var viewportBound = view.viewport;
    var scale_x = viewportBound.width / viewElementBound.width;
    var scale_y = viewportBound.height / viewElementBound.height;
    var x = (screen_x - viewportBound.left) / scale_x;
    var y = (screen_y - viewportBound.top) / scale_y;
    return {
        x: x + viewElementBound.left,
        y: y + viewElementBound.top
    };
}

function utilSvgCreateDimension(view, model, layer) {
    if (void 0 != layer && !view.dl[model.id]) {
        var displayDim = new DisplaySnapOuterDimension(model, view);
        displayDim.create(), view.dl[displayDim.id] = displayDim;
    }
}

function utilSvgCreateGrid(view, model, layer) {
    if (void 0 != layer) {
        var displayGrid = new DisplaySnapGrid(model, view);
        displayGrid.create(), view.dl[displayGrid.id] = displayGrid;
    }
}

function utilSvgCreateLayers(view, layerOrder) {
    function createOneLayer(type) {
        var g = context.g();
        g.attr("type", type), this.layers[type] = g;
    }

    var context = view.context;
    layerOrder.forEach(function (layerName) {
        createOneLayer.call(this, layerName);
    }, view);
}

function utilSvgBindTouchEvent(view) {
    function onEv(ev) {
        //__log(ev.type);
    }

    function utilSnapHammerOnTap(view, evt, a, b, c) {
        if ("touch" == evt.pointerType) {
            var srcEvent = evt.srcEvent;
            ({
                x: srcEvent.pageX,
                y: srcEvent.pageY
            });
            utilSvgHit(view, evt);
        }
    }

    function utilSnapHammerOnDoubleTap(view, evt, a, b, c) {
    }

    var mc = view.hammer;
    if (mc) {
        var utilSnapHammerOnPan = function () {
            var origPt, center;
            return function (view, evt, a, b, c) {
            	  //__log(evt.type);
                if ("touch" == evt.pointerType) switch (evt.type) {
                    case "panstart":
                        origPt = evt.pointers.map(function (pt) {
                            return {
                                x: pt.pageX,
                                y: pt.pageY
                            };
                        }), evt.pointers.length > 1 && (center = Vec2.lerp(origPt[0], origPt[1], .5));
                        break;

                    case "panmove":
                        if (!origPt) return;
                        if (1 == evt.pointers.length) {
                            var deltaX = evt.pointers[0].pageX - origPt[0].x, deltaY = evt.pointers[0].pageY - origPt[0].y;
                            view.pan(deltaX, deltaY), origPt[0].x = evt.pointers[0].pageX, origPt[0].y = evt.pointers[0].pageY;
                        } else if (evt.pointers.length > 1) {
                            var pts = evt.pointers.map(function (pt) {
                                return {
                                    x: pt.pageX,
                                    y: pt.pageY
                                };
                            }), origSquareLength = Vec2.difference(origPt[0], origPt[1]).squaredMagnitude(), currentSquareLength = Vec2.difference(pts[0], pts[1]).squaredMagnitude();
                            view.zoomWithFactor(origSquareLength / currentSquareLength, center.x, center.y),
                                origPt = pts;
                        }
                        break;

                    case "panend":
                        origPt = void 0;
                }
            };
        }();
        mc.add(new Hammer.Pan({
            threshold: 0,
            pointers: 0
        })), mc.add(new Hammer.Swipe()).recognizeWith(mc.get("pan")), mc.add(new Hammer.Rotate({
            threshold: 0
        })).recognizeWith(mc.get("pan")), mc.add(new Hammer.Pinch({
            threshold: 0
        })).recognizeWith([mc.get("pan"), mc.get("rotate")]), mc.add(new Hammer.Tap({
            event: "doubletap",
            taps: 2
        })), mc.add(new Hammer.Tap()), mc.on("panstart panmove panend", utilSnapHammerOnPan.bind(void 0, view)),
            mc.on("rotatestart rotatemove rotateend", onEv), mc.on("pinchstart pinchmove pinchend", onEv),
            mc.on("swipe", onEv), mc.on("tap", utilSnapHammerOnTap.bind(void 0, view)), mc.on("doubletap", utilSnapHammerOnDoubleTap.bind(void 0, view)),
            mc.on("hammer.input", function (ev) {
                ev.isFinal;
            });
    }
}

var utilView;
var evtAll;
//点击选择物体。鼠标抬起时执行事件--gaoning 2017.2.8
function utilSvgHit(view, evt) {
    evtAll = evt;
    var mPos = utilSvgScreenSpaceToModelSpace(view, evt.pageX, evt.pageY);
    var hitPt = {
        x: 100 * mPos.x,
        y: 100 * -mPos.y
    };
    var actionMgr = view.actionMgr;
    if (actionMgr) {

        var selected = utilSnapDisplaySelectAndName(view, hitPt,
            [Wall.prototype.type,
                AREA_OUTER_CATEGORY_ID,
                Floor.prototype.type,
                Boundary.prototype.type,
                AREA_INNER_CATEGORY_ID,
                "SLIDINGDOOR",
                "CASEMENTDOOR",
                "BATHTUB",
                "BAYWINDOW",
                "CASEMENTWINDOW",
                "SLIDINGWINDOW",
                "TOILET",

                "CARPET",
                "SEAT",
                "SURFACE",
                "SURFACE_SEAT",
                "DECORATION",
                "LIGHT",
                "CEILING",
                Camera.prototype.type]
        )

        selected[0] = selected[0].map(function (display) {
            return display ? display.model : void 0;
        });

        utilActionRun(actionMgr, "view2d_" + evt.type, evt, mPos, selected[0], selected[1]);

        var selected = utilSnapDisplaySelectAndName(view, hitPt);
        var picked = selected[0];
        var names = selected[1];
        var pickMgr = view.app.pickMgr;
        var hitScreenPt = {
            x: evt.pageX,
            y: evt.pageY
        };
        var model = picked.length > 0 ? picked[0].model : void 0;
        var fp = view.app.doc.floorplan;
        var alreadyPicked = utilPickMgrGetPickResults(pickMgr);
        var currentAction = view.actionMgr ? view.actionMgr.current : void 0;
        var isMaterial=currentAction && (currentAction.product ? currentAction.product instanceof Material ?true:false:false);
        if (MODEL_GROUP_ENABLED === !0 && 0 == evt.button && 1 == evt.ctrlKey) {  //ctrl键 --gaoning
            if (!model) return;
            if (model.canGroup() !== !0)
                return;
            var models = utilSnapSelectDisplayToPickResult(pickMgr, picked, names, mPos, hitScreenPt);
            if (alreadyPicked.forEach(function (pickResult) {
                    pickResult.model.id != GROUP_TEMP.id && utilGroupAddItem(GROUP_TEMP, pickResult.model);
                }), 0 == GROUP_TEMP.children.length) models[0].id != GROUP_TEMP.id && utilGroupAddItem(GROUP_TEMP, models[0]);
            else {
                var checkedModel = models[0].id == GROUP_TEMP.id ? models[1] : models[0];
                -1 != GROUP_TEMP.children.indexOf(checkedModel) ? utilGroupRemoveItem(GROUP_TEMP, checkedModel) : utilGroupAddItem(GROUP_TEMP, checkedModel);
                //utilPickMgrUnpickAll(pickMgr);  //多选时选中物体时呈现高亮--change by gaoning 2017.2.7
                utilPickMgrPick(pickMgr, GROUP_TEMP, {  //显示虚线框
                    modelPos: mPos,
                    screenPos: hitScreenPt,
                    src: "2d"
                });
            }
        } else if (0 == evt.button && 0 == evt.ctrlKey && !(isMoveAction>1)) {
            //单击选择物体--gaoning
            utilGroupReset(fp, GROUP_TEMP);
            utilPickMgrUnpickAll(pickMgr);
            var models = utilSnapSelectDisplayToPickResult(pickMgr, picked, names, mPos, hitScreenPt);
            var model = models[models.length - 1];
            model && model.group && utilModelSetFlagOn(model.group, MODELFLAG_PICKED);
        } else if (2 == evt.button) {  //2D右键弹出菜单
            utilPickMgrUnpickAll(pickMgr);
            var models = utilSnapSelectDisplayToPickResult(pickMgr, picked, names, mPos, hitScreenPt);
            var model = models[models.length - 1];
            model && model.group && utilModelSetFlagOn(model.group, MODELFLAG_PICKED);
        } else if(0 == evt.button && 0 == evt.ctrlKey && !isMaterial){
            ///更换砖执行，防止不能换砖  add by hcw 2018 04.02
            alreadyPicked.forEach(function (pickResult) {
                pickResult.model.id == GROUP_TEMP.id && utilPickMgrUnpickAll(pickMgr);
            })
            utilGroupReset(fp, GROUP_TEMP);
            isMoveAction=0;
        }
    }
}
var isDown = false;
var isSelection = false;
var isMoveAction=0;//物体移动标识 add by hcw
function utilSvgBindMouseEvent(view) {
    function onMouseWheel(e) {
        var delta = e.wheelDelta ? e.wheelDelta / 120 : -e.detail / 3;
        var mouseX = e.pageX;
        var mouseY = e.pageY;
        this.zoom(delta, mouseX, mouseY);
    }

    function onMouseEvent(evt) {
        evtAll = evt;

        if (evt.buttons) {
            if (evt.buttons == 4) {
                return void this.pan(evt.movementX, evt.movementY);
            }
        } else {
            if (1 == evt.button)
                return void this.pan(evt.movementX, evt.movementY);
        }

        var currentAction = this.actionMgr ? this.actionMgr.current : void 0;

        if(void 0 != currentAction && ("mousemove" == evt.type)){
            (currentAction.type!='MaterialDropper' && currentAction.type!='WallDropper') && (isMoveAction++);
        }

        if (void 0 != currentAction && ("mousemove" == evt.type || "mousedown" == evt.type) && currentAction.needViewportMouseMove() === !0 ) {

            var mousePtX = evt.pageX;
            var mousePtY = evt.pageY;
            var modelPt = (this.viewport, this.getBoundingClientRect().width, this.getBoundingClientRect().height, utilSvgScreenSpaceToModelSpace(this, mousePtX, mousePtY));
            var mPos = modelPt;
            var hitPt = {
                x: 100 * mPos.x,
                y: 100 * -mPos.y
            };
            var mouseHitTypes = currentAction.viewportMouseHitTypes();

            var picked = void 0 != mouseHitTypes ? utilSnapDisplaySelect(this, hitPt, mouseHitTypes) : [];
            currentAction.run("view2d_" + evt.type, evt, mPos, picked.map(function (display) {
                return display ? display.model : void 0;
            }));
            isMoveAction++;
        }//add by gaoning 2017.2.6  --没有选中任何Action时，默认为框选。
        else if ("mousemove" == evt.type && void 0 == currentAction) {
            //防止多选时不能移动
            var pickObjs = api.pickGetPicked(function (e) {
                return e;
            });
            if (pickObjs.length < 1) {
                selectionView = this;
                //api.actionBegin("ActionProductSelection", "inner");
            }
            isMoveAction=0;
        }

        utilView = this;
        return void ("mouseup" == evt.type && (utilSvgHit(this, evt), 2 == evt.button));
    }

    var context = view.context;
    var svg = context.defs.ownerSVGElement;
    var mouseEvt = onMouseEvent.bind(view);
    svg.addEventListener("mousewheel", onMouseWheel.bind(view));
    svg.addEventListener("DOMMouseScroll", onMouseWheel.bind(view));
    svg.addEventListener("mousedown", mouseEvt);
    svg.addEventListener("mousemove", mouseEvt);
    svg.addEventListener("mouseup", mouseEvt);
    svg.addEventListener("touchmove", mouseEvt);

}

function utilSnapViewExport(view, format, callback) {
    return "JSON" == format ? utilSnapViewExportJSON(view, callback) : (format = "DXF") ? utilSnapViewExportDXF(view, callback) : void 0;
}

function utilSnapViewExportJSON(view, callback) {
    var scene = {
        wallrods: [],
        wallLines: [],
        openings: [],
        products: [],
        dimensions: [],
        annotations: [],
        areas: [],
        others: []
    }, fp = view.app.doc.floorplan, wallsClipperPaths = {}, pids = [];

    utilFloorplanForEachWall(fp, function (wall) {
        var wallLoop = /*wall._lines ||*/ utilModelWallGetTessellates(wall, !1);
        
        //添加对bezier曲面墙的支持
        if(wall.bezier && wallLoop.length == 9){
        	var bezierLoop = [];
		    	bezierLoop.push(wallLoop[0]);bezierLoop.push(wallLoop[1]);    	
		    	for(var i=0;i<wallLoop[7].length;++i){
		    		bezierLoop.push(wallLoop[7][i]);
		    	}
		    	bezierLoop.push(wallLoop[2]);bezierLoop.push(wallLoop[3]);bezierLoop.push(wallLoop[4]);
		    	for(var i=0;i<wallLoop[8].length;++i){
		    		bezierLoop.push(wallLoop[8][i]);
		    	}
		    	bezierLoop.push(wallLoop[5]);
		    	bezierLoop.push(wallLoop[6]);
		    	wallLoop = bezierLoop;
        }
        
        void 0 == wallLoop || wallLoop.length < 3 || (wallsClipperPaths[wall.id] = [utilAdaptorClipperMakePath(wallLoop)]);
    });

    utilFloorplanForEachProduct(fp, function (product) {
        if (product.type == Windows.prototype.type || product.type == Door.prototype.type) {
            //门窗
            var openingLoop = utilGetProductOBBPoints(product, {
                margin: .005
            });
            var openingLoopNoMargin = utilGetProductOBBPoints(product);
            var openingSaved = product.save();
            openingSaved.subcategory = product.meta.subcategory;
            openingSaved.loop = openingLoopNoMargin;
            scene.openings.push(openingSaved);
            var openingClipperPath = utilAdaptorClipperMakePath(openingLoop);
            var attachWall = product.attached;
            //if (attachWall.type != Wall.prototype.type){ 
            //	return;
            //}
            //门窗对墙壁的切割处理，暂时屏蔽
            //var executeSolution = utilAdaptorClipperExecute(wallsClipperPaths[attachWall.id], [ openingClipperPath ], ClipperLib.ClipType.ctDifference);
            //wallsClipperPaths[attachWall.id] = executeSolution, __log("use wall-opening clipper.");

        } else if (product.type == Product.prototype.type || product.type == ProductReplacement.prototype.type) {
            //家具
            var productSaved = product.save();
            productSaved.loop = utilGetProductOBBPoints(product, {
                margin: .005
            });
            scene.products.push(productSaved), product.pid && pids.push(product.pid);
        } else if (product.type == Pillar.prototype.type || product.type == Basement.prototype.type || product.type == Beam.prototype.type) {
            //柱子 地台 横梁
            var otherSaved = product.save();
            otherSaved.loop = utilGetProductOBBPoints(product, {
                margin: .005
            });
            scene.others.push(otherSaved), product.pid && pids.push(product.pid);
        }
    });

    //获取所有文本注释
    utilFloorplanForEachType(fp, Annotation, function (annotation) {
        var annotaionSaved = annotation.save();
        annotaionSaved.text = annotation.text;
        scene.annotations.push(annotaionSaved);
    });

    //获取所有RectArea
    utilFloorplanForEachType(fp, RectArea, function (rectarea) {
        if (rectarea.type == "RECTAREA" && rectarea.areaMaterial) {
            var areaSave = {};
            areaSave.areadata = rectarea;
            areaSave.pid = rectarea.areaMaterial.pid;
            areaSave.loop = rectarea.getLoop();
            areaSave.level = rectarea.level;
            
            if (areaSave.loop) {
                scene.areas.push(areaSave);
            }
        }
    });
    //获取所有FreeArea
    utilFloorplanForEachType(fp, FreeArea, function (freearea) {
        var areaSave = {};
        areaSave.areadata = freearea;
        areaSave.pid = freearea.areaMaterial.pid;
        areaSave.level = freearea.level;
        areaSave.loop = [];
        var loop = freearea.getLoop();
        if (loop) {
            loop.forEach(function (point) {
                var pointSave = {};
                pointSave.x = point.x;
                pointSave.y = point.y;
                areaSave.loop.push(pointSave);
            });
            scene.areas.push(areaSave);
        }
    });
    //获取所有RoundArea
    utilFloorplanForEachType(fp, RoundArea, function (roundarea) {
        if (roundarea.type == "ROUNDAREA") {
            var areaSave = {};
            areaSave.areadata = roundarea;
            areaSave.pid = roundarea.areaMaterial.pid;
            areaSave.loop = roundarea.getLoop();
            areaSave.level = roundarea.level;
            if (areaSave.loop) {
                scene.areas.push(areaSave);
            }
        }
    });

    var wallPaths = [];
    for (var wid in wallsClipperPaths) {
        var paths = wallsClipperPaths[wid];
        wallPaths = wallPaths.concat(paths);
    }

    //标准化相近的交接点解决有时出现无法形成地面的问题--add by gaoning  2017.8.8
    wallPaths = utilMathIsSamePointForPath(wallPaths);

    var wallLines = utilAdaptorClipperExecute(wallPaths, void 0, ClipperLib.ClipType.ctXor);
    scene.wallLines = wallLines;

    //添加墙体标尺 scene.wallrods
    wallPaths.forEach(function (wall) {
        //标注点距离0.2
        var rodInfo = {};
        rodInfo.lines = [];	//绘制线段
        rodInfo.labels = []; //文字信息

        var p6 = wall[5], p5 = wall[4], p1 = wall[0], p4 = wall[3];
        var angle = 0;	//注意:垂直斜率
        if (p6.X == p5.X) {
            angle = p6.Y > p5.Y ? 0 * Math.PI / 180 : 180 * Math.PI / 180;
        } else if (p6.Y == p5.Y) {
            angle = p6.X > p5.X ? -90 * Math.PI / 180 : 90 * Math.PI / 180;
        } else {
            angle = Math.atan((p6.Y - p5.Y) / (p6.X - p5.X));
            if (angle > 0) {
                angle = p6.Y > p5.Y ? (angle - 90 * Math.PI / 180) : (angle + 90 * Math.PI / 180);
            } else {
                angle = p6.Y > p5.Y ? (angle + 90 * Math.PI / 180) : (angle - 90 * Math.PI / 180);
            }
        }

        var start = {x: p1.X + Math.cos(angle) * 350, y: p1.Y + Math.sin(angle) * 350};
        var end = {x: p4.X + Math.cos(angle) * 350, y: p4.Y + Math.sin(angle) * 350};

        var label = Math.round(utilMathLineLength(start, end));
        start.x *= 0.001;
        start.y *= 0.001;
        end.x *= 0.001;
        end.y *= 0.001;
        rodInfo.labels.push({label: label, x: (start.x + end.x) / 2, y: (start.y + end.y) / 2});

        rodInfo.lines.push([start, end]);
        //两根竖线
        rodInfo.lines.push([{x: (p1.X + Math.cos(angle) * 200) * 0.001, y: (p1.Y + Math.sin(angle) * 200) * 0.001},
            {x: (p1.X + Math.cos(angle) * 450) * 0.001, y: (p1.Y + Math.sin(angle) * 450) * 0.001}]);
        rodInfo.lines.push([{x: (p4.X + Math.cos(angle) * 200) * 0.001, y: (p4.Y + Math.sin(angle) * 200) * 0.001},
            {x: (p4.X + Math.cos(angle) * 450) * 0.001, y: (p4.Y + Math.sin(angle) * 450) * 0.001}]);

        scene.wallrods.push(rodInfo);
    });

    utilCatalogGetProductsMetaPromise(application.catalogMgr, pids).then(function (metas) {
        scene.metas = metas, callback && callback(scene);
    });
}

function utilSnapViewExportDXF(view, callback) {
    utilSnapViewExportJSON(view, function (scene) {
        callback && callback(utilEncryptString(JSON.stringify(scene)));
    });
}

function DisplaySnapGrid(modelObject, view) {
    classBase(this, modelObject, view);
}

function utilSnapGridBuildSvgLine(lineStrip) {
    var lines = lineStrip, factor = 100;
    __assert(Array.isArray(lines) && 0 != lines.length);
    for (var svgPath = "", i = 0, len = lines.length; len > i; i += 4) svgPath += "M" + Math.round(lines[i] * factor) + "," + Math.round(-lines[i + 1] * factor) + "L" + Math.round(lines[i + 2] * factor) + "," + Math.round(-lines[i + 3] * factor);
    return svgPath += "Z";
}

function utilSnapGridCreateGeometry(width, height, space) {
    for (var halfWidth = width / 2, halfHeight = height / 2, MajorSpace = 5, axis = [], major = [], minor = [], i = 0, total = halfWidth / space; total >= i; i++) {
        var bucket = 0 == i ? axis : i % MajorSpace == 0 ? major : minor, gap = i * space;
        bucket.push(-halfWidth, gap, halfWidth, gap, -halfWidth, -gap, halfWidth, -gap);
    }
    for (var i = 0, total = halfHeight / space; total >= i; i++) {
        var bucket = 0 == i ? axis : i % MajorSpace == 0 ? major : minor, gap = i * space;
        bucket.push(gap, -halfHeight, gap, halfHeight, -gap, -halfHeight, -gap, halfHeight);
    }
    return {
        ax: axis,
        ma: major,
        mi: minor
    };
}

function DisplaySnapOuterDimension(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

function DisplaySnapCamera(modelObject, view) {
    classBase(this, modelObject, view);
}

function utilDisplaySnapCameraBuildPath(pos, target, fov, zNear) {
    var svgLerpDirectionPt = Vec2.lerp(target, pos, Math.tan(.5 * fov * Math.PI / 180));
    var svgTargetPlaneLeftPt = Vec2.rotateAroundPoint(svgLerpDirectionPt, target, Math.PI / 2);
    var svgTargetPlaneRightPt = Vec2.rotateAroundPoint(svgLerpDirectionPt, target, -Math.PI / 2);
    var radius = utilMathLineLength(svgTargetPlaneLeftPt, svgTargetPlaneRightPt);
    var svgGizmoLine = "M" + pos.x + "," + pos.y + "L" + svgTargetPlaneLeftPt.x + "," + svgTargetPlaneLeftPt.y + "A" + radius + "," + radius + ",0,0,1," + svgTargetPlaneRightPt.x + "," + svgTargetPlaneRightPt.y + "Z";
    var targetLength = utilMathLineLength(pos, target);
    var lerpNumber = Math.min(1, zNear / targetLength);
    var svgClipNearLeftPt = Vec2.lerp(pos, svgTargetPlaneLeftPt, lerpNumber);
    var svgClipNearRightPt = Vec2.lerp(pos, svgTargetPlaneRightPt, lerpNumber);
    var zNearClip = "M" + svgClipNearLeftPt.x + "," + svgClipNearLeftPt.y + "L" + svgClipNearRightPt.x + "," + svgClipNearRightPt.y;
    return {
        area: svgGizmoLine,
        znear: zNearClip,
        znearPos: Vec2.lerp(svgClipNearLeftPt, svgClipNearRightPt, .5)
    };
}

function DisplaySnapCurve(modelObject, view) {
    classBase(this, modelObject, view);
}



function DisplaySnapProduct(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

function utilDisplaySnapProductBuildBound(productModelObject, offset) {
    offset = offset || {
            x: 0,
            y: 0
        };
    var p = productModelObject, meta = p.meta || p, width = meta.xlen * (p.sx || 1) * 100, height = meta.ylen * (p.sy || 1) * 100;
    return {
        left: 100 * (p.x + offset.x) - width / 2,
        top: 100 * -(p.y + offset.y) - height / 2,
        width: width,
        height: height
    };
}

function utilDisplaySnapOpeningBound(opening) {
    var p = opening;
    var meta = p.meta;
    var factor = 100;
    var width = meta.xlen * p.sx * factor;
    var height = (opening.attached ? opening.attached.width : DEFAULT_WALL_WIDTH) * factor;
    return {
        left: p.x * factor - width / 2,
        top: -p.y * factor - height / 2,
        width: width,
        height: height
    };
}

function DisplaySnapCube(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

function DisplaySnapVRHotspot(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

function DisplaySnapAnnotation(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

function DisplaySnapWalkThrough(modelObject, view) {
    classBase(this, modelObject, view);
}

function utilSnapWalkThroughBuildPath(walkThrough, isPos) {
    var linear = "linear" == walkThrough.path, bezierC = "bezierC" == walkThrough.path, keys = walkThrough.sortedKeys();
    if (keys.length < 2) return "";
    var p0 = isPos ? {
        x: keys[0].x,
        y: keys[0].y
    } : {
        x: keys[0].tx,
        y: keys[0].ty
    }, p1 = isPos ? {
        x: keys[1].x,
        y: keys[1].y
    } : {
        x: keys[1].tx,
        y: keys[1].ty
    }, path = "";
    if (bezierC) {
        path = "M" + 100 * p0.x + "," + -100 * p0.y;
        for (var i = 0, len = keys.length - 1; len > i; ++i) {
            var k0 = keys[i], k1 = keys[i + 1], p0 = {
                x: isPos ? k0.x : k0.tx,
                y: isPos ? k0.y : k0.ty
            }, p1 = {
                x: isPos ? k1.x : k1.tx,
                y: isPos ? k1.y : k1.ty
            }, cp1 = {
                x: isPos ? k0.cp2x : k0.cp2tx,
                y: isPos ? k0.cp2y : k0.cp2ty
            }, cp2 = {
                x: isPos ? k1.cp1x : k1.cp1tx,
                y: isPos ? k1.cp1y : k1.cp1ty
            };
            path += "C" + 100 * cp1.x + "," + -100 * cp1.y + "," + 100 * cp2.x + "," + -100 * cp2.y + "," + 100 * p1.x + "," + -100 * p1.y;
        }
    } else {
        var cp = utilMathGetScaledPoint(p0, p1, .5 * utilMathLineLength(p0, p1));
        path = "M" + 100 * p0.x + "," + -100 * p0.y + "Q" + 100 * cp.x + "," + -100 * cp.y + "," + 100 * p1.x + "," + -100 * p1.y;
        for (var i = 2; i < keys.length; ++i) {
            var p1 = keys[i];
            path += linear ? "L" + 100 * (isPos ? p1.x : p1.tx) + "," + -100 * (isPos ? p1.y : p1.ty) : "T" + 100 * (isPos ? p1.x : p1.tx) + "," + -100 * (isPos ? p1.y : p1.ty);
        }
    }
    return path;
}

function DisplaySnapGroup(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

function DisplaySnapArea(modelObject, view) {
    classBase(this, modelObject, view);
}

function utilSnapAreaCreatePathString(areaModel, offset) {
    var geom, svgString = "", profile = areaModel.profile, factor = 100;
    if (profile.length < 3) return "";
    if (geom = utilAreaGetLoopFromProfile(areaModel), utilMathEquals(offset, 0, .01) || (geom = utilAdaptorClipperOffset(geom, offset)),
            !geom) return "";
    for (var i = 0, len = geom.length; len > i; ++i) {
        var pt = geom[i];
        __assert(!isNaN(pt.x) && !isNaN(pt.y)), svgString += (0 == i ? "M" : "L") + Math.round(pt.x * factor) + "," + Math.round(-pt.y * factor);
    }
    return svgString += "Z";
}

function utilSnapAreaGetAreaMaterial(displayArea) {
    var area = displayArea.model;
    var view = displayArea.view;
    if (!area.areaMaterial)
        return "#c0c0c0";
    var pid = area.areaMaterial.pid;
    var patternId = area.id + pid;
    var mat = area.areaMaterial;
    var rot = mat.rot;
    utilSnapViewCreatePattern(view, pid, patternId, function (pattern) {
        pattern.transform("r" + Math.round(-rot) + "T" + 100 * mat.tx + "," + -100 * mat.ty);
    });
    return "url(#" + patternId + ")";
}

/*
 DisplaySnapFloor
 */

function utilSnapFloorCreatePathFromLoop(loop, opt) {
    for (var geom = loop, factor = 100.0, svgString = "", offset = opt && opt.offset || {
            x: 0,
            y: 0
        }, i = 0, len = geom.length; len > i; ++i) {
        var pt = geom[i];
        if (!pt || isNaN(pt.x) || isNaN(pt.y)) return __assert(!1, "FloorProfile has invalid data."),
            "";
        svgString += (0 == i ? "M" : "L") + ((pt.x + offset.x) * factor) + "," + (-(pt.y + offset.y) * factor);
    }
    return svgString += "Z";
}

function DisplaySnapTemp(modelObject, view) {
    this.layer = void 0, this.paper = void 0, classBase(this, modelObject, view);
}
/*插入户型图接口，实现在下面
 * TODO 查找在哪里调用 【DisplaySnapUnderlay】
 * add by oxl 2017-02-27*/
function DisplaySnapUnderlay(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

function utilDisplaySnapUnderlayBuildBound(productModelObject) {
    var p = productModelObject, meta = p.meta, DEFAULT_WIDTH = 10, width = DEFAULT_WIDTH * p.sx * 100, height = meta.height / meta.width * DEFAULT_WIDTH * p.sy * 100;
    return {
        left: 100 * p.x - width / 2,
        top: 100 * -p.y - height / 2,
        width: width,
        height: height
    };
}

function utilSnapDisplaySelectAndName(view, hitPoint, acceptableLayers) {
	var hitPointModel = {x:hitPoint.x/100.0, y:-hitPoint.y/100.0};
    var layers = acceptableLayers || view.layerOrder;
    __assert(Array.isArray(layers));
    var rv = [];
    layers = layers.slice(0).reverse();
    layers.forEach(function (layer) {
        var activelayer = view.layers[layer];
        if (activelayer && "none" !== window.getComputedStyle(activelayer.node).display) for (var elements = activelayer.children(), i = elements.length - 1; i >= 0; --i) {
            var element = elements[i];
            if (element) {
                var displayId = element.attr("did");
                if (void 0 != displayId && "none" !== window.getComputedStyle(element.node).display) {
                    var bb = element.getBBox();
                    if (Snap.path.isPointInsideBBox(bb, hitPoint.x, hitPoint.y)) {
                        var model = view.dl[displayId].model;
                        if (model instanceof Product){// || model instanceof RectArea) {
                            var bbNoTransform = element.getBBox(!0);
                            //点是否在盒子内部
                            var inside = utilIsPointInsideOBB(new Bound(bbNoTransform.x, bbNoTransform.y, bbNoTransform.width, bbNoTransform.height), model.rot, hitPoint);
                            if (!inside) 
                                continue;
                        } else if(model instanceof Area || model instanceof Floor){                        	  
                        	  if(model.floorRectTiles.length == 0){
                        	  	//未进行铺贴
                        	  	var profile = model.getLoop();
                        	  	if(!utilMathIsPointInPoly(profile, hitPointModel)){                      	  			
                      	  			continue;
                      	  		}
                        	  }else{
                        	  	var hited = false;
                        	  	for(var fI = 0;fI<model.floorRectTiles.length;++fI){
	                        	  	var tiles = model.floorRectTiles[fI];	  
	                        	  	if(tiles.tileProfile){                      	  	
		                        	  	for(var pI = 0;pI<tiles.tileProfile.length;++pI){
		                        	  		var profile = tiles.tileProfile[pI];
		                        	  		if(tiles.elements && tiles.elements[pI] && utilMathIsPointInPoly(profile, hitPointModel)){
		                        	  			rv.push(tiles.elements[pI]);
		                        	  			hited = true;
		                        	  			break;
		                        	  		}
		                        	  	};
		                        	  	if(hited){
		                        	  		break;
		                        	  	}      		                        	  	
		                        	  }	  	
	                        	  };
	                        	  continue;
                        	  }
                        }else {
                        	  if(element.type == "g"){
                        	  	for(var n=0; n<element.node.childElementCount;++n){
                        	  		  var pathFun = Snap.path.get[element[n].type];
			                            if (!pathFun) 
			                                continue;
			                                
			                            //通过matrix对path进行变换
			                            var path = pathFun(element[n]);			          			                                              
			                            //path = Snap.path.map(path, element[n].matrix);
			                            
			                            //点是否在闭合内部
			                            var notInside = !Snap.path.isPointInside(path, hitPoint.x, hitPoint.y);
			                            if (notInside) 
			                                continue;
			                                
			                            rv.push(element[n]);
                        	  	}
                        	  	continue;
                        	  }else{
                        	  	var pathFun = Snap.path.get[element.type];
	                            if (!pathFun) continue;
	                            var path = pathFun(element);
	                            //点是否在闭合内部
	                            var notInside = !Snap.path.isPointInside(path, hitPoint.x, hitPoint.y);
	                            if (notInside)
	                                continue;
                        	  }
                        }
                        rv.push(element);
                    }
                }
            }
        }
    });

    var rvName = [];
    for (var i = 0; i < rv.length; i++) {
        rvName.push(rv[i].name || "");
    }

    rv = rv.map(function (ele) {
        return view.dl[ele.attr("did")];
    });

    return [rv, rvName];
}

function utilSnapDisplaySelect(view, hitPoint, acceptableLayers) {
    var layers = acceptableLayers || view.layerOrder;
    __assert(Array.isArray(layers));
    var rv = [];
    layers = layers.slice(0).reverse();
    layers.forEach(function (layer) {
        var activelayer = view.layers[layer];
        if (activelayer && "none" !== window.getComputedStyle(activelayer.node).display) for (var elements = activelayer.children(), i = elements.length - 1; i >= 0; --i) {
            var element = elements[i];
            if (element) {
                var displayId = element.attr("did");
                if (void 0 != displayId && "none" !== window.getComputedStyle(element.node).display) {
                    var bb = element.getBBox();
                    if (Snap.path.isPointInsideBBox(bb, hitPoint.x, hitPoint.y)) {
                        var model = view.dl[displayId].model;
                        if (model instanceof Product || model instanceof RectArea) {
                            var bbNoTransform = element.getBBox(!0);
                            //点是否在盒子内部
                            var inside = utilIsPointInsideOBB(new Bound(bbNoTransform.x, bbNoTransform.y, bbNoTransform.width, bbNoTransform.height), model.rot, hitPoint);
                            if (!inside) continue;
                        } else {
                            var pathFun = Snap.path.get[element.type];
                            if (!pathFun) continue;
                            var path = pathFun(element);
                            //点是否在闭合内部
                            var notInside = !Snap.path.isPointInside(path, hitPoint.x, hitPoint.y);
                            if (notInside) continue;
                        }
                        rv.push(element);
                    }
                }
            }
        }
    });
    rv = rv.map(function (ele) {
        return view.dl[ele.attr("did")];
    });

    return rv;
}

//框选add by gaoning 2017.2.17
var selectionView;
function utilSnapDisplaySelection(rectPoints) {

    var modelList = new Array();
    var modelSrc = "";
    var areaPos = rectPoints;
    var layers = selectionView.layerOrder;
    return layers = layers.slice(0).reverse(), layers.forEach(function (layer) {
            var activelayer = selectionView.layers[layer];
            if (activelayer && "none" !== window.getComputedStyle(activelayer.node).display) {
                for (var elements = activelayer.children(), i = elements.length - 1; i >= 0; --i) {
                    var element = elements[i];
                    if (element) {
                        var displayId = element.attr("did");

                        if (void 0 != displayId && "none" !== window.getComputedStyle(element.node).display) {
                            var model = selectionView.dl[displayId].model;
                            if (model instanceof Product) {
                                //if (model instanceof Product || model instanceof RectArea) {
                                var bbNoTransform = element.getBBox(!0);
                                if (bbNoTransform.width > 0) {

                                    var modelPos = new Array();
                                    modelPos[0] = new Vec2(model.x - bbNoTransform.width / 200, model.y + bbNoTransform.height / 200);
                                    modelPos[1] = new Vec2(model.x - bbNoTransform.width / 200, model.y - bbNoTransform.height / 200);
                                    modelPos[2] = new Vec2(model.x + bbNoTransform.width / 200, model.y + bbNoTransform.height / 200);
                                    modelPos[3] = new Vec2(model.x + bbNoTransform.width / 200, model.y + bbNoTransform.height / 200);
                                    modelPos[4] = new Vec2(model.x, model.y);

                                    for (var m = 0; m < modelPos.length; m++) {
                                        var check = api.checkPointInPolygon(modelPos[m], areaPos);
                                        if (check == true) {
                                            if (modelList.pushIfNotHas(model)) {
                                                //modelList.push(model);
                                                modelSrc += model.id;
                                                utilGroupAddItem(GROUP_TEMP, model);
                                                utilPickMgrPick(selectionView.app.pickMgr, GROUP_TEMP, {  //显示虚线框
                                                    modelPos: new Vec2(model.x, model.y),
                                                    screenPos: new Vec2(model.x, model.y),
                                                    src: "2d"
                                                });
                                            }
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                            /*var mPos = utilSvgScreenSpaceToModelSpace(selectionView, model.x, model.y);
                                             var hitPt = {
                                             x: 100 * mPos.x,
                                             y: 100 * -mPos.y
                                             };
                                             var actionMgr = selectionView.actionMgr;
                                             if (actionMgr) {

                                             utilActionRun(actionMgr, "view2d_" + evtAll.type, evtAll, new Vec2(model.x, model.y), utilSnapDisplaySelect(selectionView, hitPt,
                                             [Wall.prototype.type,
                                             AREA_OUTER_CATEGORY_ID,
                                             Floor.prototype.type,
                                             AREA_INNER_CATEGORY_ID,
                                             "CARPET", "SEAT", "SURFACE", "DECORATION", "LIGHT", "CEILING",
                                             Camera.prototype.type]
                                             ).map(function (display) {
                                             return display ? display.model : void 0;
                                             }));

                                             var picked = model;//utilSnapDisplaySelect(selectionView, hitPt);
                                             var pickMgr = selectionView.app.pickMgr;
                                             var alreadyPicked = modelList;//utilPickMgrGetPickResults(pickMgr);

                                             var hitScreenPt = {
                                             x: model.x,
                                             y: model.y
                                             };
                                             if (!model) return;
                                             if (model.canGroup() !== !0)
                                             return;
                                             var models = utilSnapSelectDisplayToPickResult(pickMgr, picked, mPos, hitScreenPt);
                                             if (alreadyPicked.forEach(function (pickResult) {
                                             pickResult.model.id != GROUP_TEMP.id && utilGroupAddItem(GROUP_TEMP, pickResult.model);
                                             }), 0 == GROUP_TEMP.children.length) models[0].id != GROUP_TEMP.id && utilGroupAddItem(GROUP_TEMP, models[0]);
                                             else {
                                             var checkedModel = models[0].id == GROUP_TEMP.id ? models[1] : models[0];
                                             -1 != GROUP_TEMP.children.indexOf(checkedModel) ? utilGroupRemoveItem(GROUP_TEMP, checkedModel) : utilGroupAddItem(GROUP_TEMP, checkedModel);
                                             // utilPickMgrUnpickAll(pickMgr);  //多选时选中物体时呈现高亮--change by gaoning 2017.2.7
                                             utilPickMgrPick(pickMgr, GROUP_TEMP, {  //显示虚线框
                                             modelPos: mPos,
                                             screenPos: hitScreenPt,
                                             src: "2d"
                                             });
                                             }
                                             }*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                                        }
                                    }

                                } else {

                                }
                            }
                        }
                    }
                }

            }
        }
    )
        ;
}

function utilSnapSelectDisplayToPickResult(pickMgr, selectedDisplays, selectedNames, hitModelPt, hitScreenPt) {
    var isSingleSelection = !0;
    var hasSelected = !1;
    var pickedModel = void 0;
    var path = [];
    selectedDisplays.forEach(function (display, index) {
        void 0 != display && void 0 != display.model && (1 == isSingleSelection && 1 == hasSelected || (pickedModel = display.model,
        MODEL_GROUP_ENABLED === !0 && display.model.group && (utilModelIsFlagOn(display.model.group, GROUPFLAG_OPENED) ? (pickedModel = display.model,
            path.push(display.model.group)) : display.model.group.group ? (pickedModel = display.model.group.group,
            path.push(display.model.group.group, display.model.group)) : (pickedModel = display.model.group,
            path.push(display.model.group))), path.push(display.model), utilPickMgrPick(pickMgr, pickedModel, {
            modelPos: hitModelPt,
            screenPos: hitScreenPt,
            src: "2d",
            side: selectedNames[index]
        }), hasSelected = !0));
    });
    return path;
}

function utilSnapWallDimensionCreate(context, wall) {
    var dimensions = [];
    return dimensions.push(context.path().attr({
        "stroke-width": 2
    })), dimensions.push(context.text().attr({
        "font-size": api.getViewById("2d").getAreaLabelSize(10, 25),
        "font-weight": "bold",
        "font-family": "Calibri,Arial,Helvetica,sans-serif",
        fill: "#202020"
        })), allDimensions = dimensions, dimensions;
}
var allDimensions = [];

//刷新自由画区域 两点之间的距离的字体
function refreshDimensions() {
    allDimensions.forEach(function  (dimension) {
        dimension.attr({
            "font-size": api.getViewById("2d").getAreaLabelSize(10, 25)
        });
    });
}

function utilSnapWallDimensionUpdate(context, wall, dimensions) {
    return utilSnapPointsDimensionUpdate(context, wall.begin, wall.end, dimensions);
}

function utilSnapPointsDimensionUpdate(context, begin, end, dimensions) {
    var text = (dimensions[0], dimensions[1]), wallAngle = 0, wallLength = 0, wallMiddle = {
        x: 0,
        y: 0
    };
    begin && end && !isNaN(begin.x) && !isNaN(end.x) && (wallAngle = utilMathGetAngleHorizontaleCCW(begin, end),
    Vec2.dot({
        x: end.x - begin.x,
        y: end.y - begin.y
    }, {
        x: 1,
        y: 0
    }) < -.1 && (wallAngle -= 180), wallLength = utilMathLineLength(begin, end), wallMiddle = {
        x: (begin.x + end.x) / 2,
        y: (begin.y + end.y) / 2
    });
    var textShow = wallLength > .5 ? Math.round(1e3 * wallLength) + "" : "";
    text.attr({
        x: isNaN(wallMiddle.x) ? 0 : 100 * wallMiddle.x,
        y: isNaN(wallMiddle.y) ? 0 : 100 * -wallMiddle.y,
        text: textShow
    }).transform("r" + -wallAngle);
}

function DisplaySnapActionAddWall(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionAddArea(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionAddRectArea(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionAddRoundArea(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionMovePoint(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionMoveBezierPoint(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionAnalyzeNormalized(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionRulerMeasure(action, view) {
    classBase(this, action, view), this.action = this.model;
}

function DisplaySnapActionApplyModelroom(action, view) {
    classBase(this, action, view);
    this.action = this.model;
    this.ghostMove = this.action.ghostMove;
    this.ghostLoop = void 0;
}
//判断产品是否在房间内，是则返回该房间的所有墙体, add by hcw
function GetCurrentFloor(posArray) {
    var index = 0;
    var wall = [];
    var rooms = api.floorplanFilterEntity(function (e) {
        return e.type == "FLOOR";
    });
    for (var i = 0; i < rooms.length; i++) {
        index = 0;
        var roomsPos = new Array();
        for (var r = 0; r < rooms[i].getLoop().length; r++) {
            var pos = new THREE.Vector2();
            pos.x = rooms[i].getLoop()[r].x;
            pos.y = rooms[i].getLoop()[r].y;
            roomsPos[index] = pos;
            index++;
        }
        var check = false;
        for (var c = 0; c < posArray.length; c++) {
            check = checkPointInPolygon(posArray[c], roomsPos);
            if (check == true) {
                wall = rooms[i].profile;
                break;
            }
        }
        if(check)break;
    }
    return wall;
}
//计算物体标注线 add by hcw
function createProductLabel(allWall, left, right, top, buttom, rot) {
    var allwallpoint = [];//包围所有墙体的最大，最小坐标
    var linepoint = [];//所有标注线的坐标
    var floorwidthl = 0, floorwidthr = 0, floorheightt = 0, floorheightb = 0, wallwidth = 150;
    if (allWall.length > 0) {
        allWall.forEach(function (wall, i) {
            var wallpointbegin = {x: wall.begin.x, y: wall.begin.y};//墙边开始坐标点
            var wallpointend = {x: wall.end.x, y: wall.end.y};//墙边结束坐标点
            wallwidth = wall.width / 2;
            allwallpoint[i] = [wallpointbegin, wallpointend]
        })
        //计算包围墙体最大最小的四个顶点
        var xmin = allWall[0].begin.x, xmax = allWall[0].end.x, ymin = allWall[0].begin.y, ymax = allWall[0].end.y
        var p1, p2;
        allWall.forEach(function (wall, i) {
            if (ymax < allWall[i].end.y) {
                ymax = allWall[i].end.y
            }
            if (allWall[i].begin.y < ymin) {
                ymin = allWall[i].begin.y
            }
            if (xmax < allWall[i].end.x) {
                xmax = allWall[i].end.x
            }
            if (allWall[i].begin.x < xmin) {
                xmin = allWall[i].begin.x
            }
        })
        p1 = {x: xmin, y: ymax}//左上角顶点
        p2 = {x: xmax, y: ymin}//右下角顶点
        var dismax = utilMathLineLength(p1, p2)//Math.sqrt(Math.pow(p1.x-p2.x,2)+Math.pow(p1.y-p2.y,2))四个点最长距离
        if (rot == 0 || rot == 90 || rot == 180 || rot == 270 || rot == 360) {
            var alllinepoint = [top, left, right, buttom];
            var left1 = left, right1 = right, top1 = top, buttom1 = buttom
            alllinepoint.forEach(function (point) {
                if (left1.x > point.x) {
                    left1 = point;
                }
                if (right1.x < point.x) {
                    right1 = point;
                }
                if (top1.y < point.y) {
                    top1 = point;
                }
                if (buttom1.y > point.y) {
                    buttom1 = point;
                }
            })
            var left2 = {x: left1.x - dismax, y: left1.y}, right2 = {x: right1.x + dismax, y: right1.y},
                top2 = {x: top1.x, y: top1.y + dismax}, buttom2 = {x: buttom1.x, y: buttom1.y - dismax}
            var maxcrosspointl = productCrossWall(left1, left2, 'l');
            var maxcrosspointt = productCrossWall(top1, top2, 't');
            var maxcrosspointb = productCrossWall(buttom1, buttom2, 'b');
            var maxcrosspointr = productCrossWall(right1, right2, 'r');
        } else {
            //物体旋转时获取四个顶点
            var left = left, right = right, top = top, buttom = buttom, left1, right1, top1, buttom1;
            left1 = (left.x > right.x) ? right : left;
            left1 = (left1.x > top.x) ? top : left1;
            left1 = (left1.x > buttom.x) ? buttom : left1;
            right1 = (right.x < left.x) ? left : right;
            right1 = (right1.x < top.x) ? top : right1;
            right1 = (right1.x < buttom.x) ? buttom : right1;
            top1 = (top.y < right.y) ? right : top;
            top1 = (top1.y < left.y) ? left : top1;
            top1 = (top1.y < buttom.y) ? buttom : top1;
            buttom1 = (buttom.y > right.y) ? right : buttom;
            buttom1 = (buttom1.y > top.y) ? top : buttom1;
            buttom1 = (buttom1.y > left.y) ? left : buttom1;
            var leftend = {x: left1.x - dismax, y: left1.y}, rightend = {x: right1.x + dismax, y: right1.y},
                topend = {x: top1.x, y: top1.y + dismax}, buttomend = {x: buttom1.x, y: buttom1.y - dismax}
            var maxcrosspointl = productCrossWall(left1, leftend, 'l');
            var maxcrosspointt = productCrossWall(top1, topend, 't');
            var maxcrosspointb = productCrossWall(buttom1, buttomend, 'b');
            var maxcrosspointr = productCrossWall(right1, rightend, 'r');
        }
        var othersize = []
        if (maxcrosspointl) {
            othersize = productCrossWall(left1, {x: left1.x + dismax, y: left1.y})
            if (typeof (othersize) != 'undefined') {
                othersize.x = othersize.x - othersize.dis
                floorwidthl = Math.round((othersize.x - maxcrosspointl.x) * 1e3);
            }
        }
        if (maxcrosspointr) {
            othersize = productCrossWall(right1, {x: right1.x - dismax, y: right1.y})
            if (typeof (othersize) != 'undefined') {
                othersize.x = othersize.x + othersize.dis
                floorwidthr = Math.round((maxcrosspointr.x - othersize.x) * 1e3);
            }
        }
        if (maxcrosspointt) {
            othersize = productCrossWall(top1, {x: top1.x, y: top1.y - dismax})
            if (typeof (othersize) != 'undefined') {
                othersize.y = othersize.y + othersize.dis
                floorheightt = Math.round((maxcrosspointt.y - (othersize.y)) * 1e3);
            }
        }
        if (maxcrosspointb) {
            othersize = productCrossWall(buttom1, {x: buttom1.x, y: buttom1.y + dismax})
            if (typeof (othersize) != 'undefined') {
                othersize.y = othersize.y - othersize.dis
                floorheightb = Math.round((othersize.y - maxcrosspointb.y) * 1e3); //区域内高度
            }
        }
    }
    function matchDis(p1,p2,pos) {
        var diff_x =p1.x-p2.x,
            diff_y =p1.y-p2.y;
        //返回角度,不是弧度
        var rot=360*Math.atan(diff_y/diff_x)/(2*Math.PI);
        var dis=0;
        if (pos == 'l' || pos == 'r'){
            if(rot>=0){
                dis=wallwidth/Math.sin((rot)*Math.PI/180);
            }else{
                dis=wallwidth/Math.sin((-rot)*Math.PI/180);
            }
        }else{
            if(rot>=0){
                dis=wallwidth/Math.sin((90-rot)*Math.PI/180);
            }else{
                dis=wallwidth/Math.sin((90+rot)*Math.PI/180);
            }
        }
        return dis;
    }
    function productCrossWall(p0, p1, pos) {//判断产品四个延长线段与各个墙体是否有交点
        for (var i = 0; i < allwallpoint.length; i++) {
            if (checkCross(p0, p1, allwallpoint[i][0], allwallpoint[i][1])) {
                var dis=matchDis(allwallpoint[i][0], allwallpoint[i][1],pos)
                var crosspoint = utilMathLineLineIntersection(p0, p1, allwallpoint[i][0], allwallpoint[i][1]);
                if (pos == 'l') crosspoint.x = crosspoint.x + dis
                if (pos == 'r') crosspoint.x = crosspoint.x - dis
                if (pos == 't') crosspoint.y = crosspoint.y - dis
                if (pos == 'b') crosspoint.y = crosspoint.y + dis
                if (typeof (pos) != 'undefined') {
                    linepoint.push({
                        dis2: utilMathLineLength(p0, crosspoint),
                        dis: Math.round(1e3 * utilMathLineLength(p0, crosspoint)),
                        wallpoint: {x: crosspoint.x, y: crosspoint.y},
                        linepoint: {x: p0.x, y: p0.y},
                        p: pos
                    })
                }
                crosspoint.dis=dis;
                return crosspoint;
                break;
            }
        }
    }

    return {
        point: linepoint,
        widthmaxl: floorwidthl,
        widthmaxr: floorwidthr,
        heighttmax: floorheightt,
        heightbmax: floorheightb
    }
}

//////////////////////////////////////////////////////////////////////////////////////
//创建鼠标距离墙标线-- add by gaoning 2018.3.15
var allContextArr = [];
var textRectArr = [];
var wallLineResult;
//function createMouseToWallLine(obj,pos) {
function createMouseToWallLine(pos) {
    var view = utilAppGetViewById(application, "2d");
    var context = view.context;
    var layer = view.layers['PRODUCT_MARK'];//物体标注信息层
    var layer2 = view.layers['PRODUCT_MARK_TEXT'];//解决高光线遮住框和字体  物体字体和框的层
    var lineleft = {
        x: pos.x - 0.00,
        y: pos.y
    }, lineright = {
        x: pos.x + 0.00,
        y: pos.y
    }, lineTop = {
        x: pos.x,
        y: pos.y + 0.00
    }, linebuttom = {
        x: pos.x,
        y: pos.y - 0.00
    }
    var allWall = GetCurrentFloor([lineleft, lineright, lineTop, linebuttom]);//获取物体所在房间的所有墙体
    var result = createProductLabel(allWall, lineleft, lineright, lineTop, linebuttom, 0);
    wallLineResult = result;

    if (allContextArr.length > 0) {
        showMouseLabelLine(view, result);
        return;
    }
    var Line0 = context.line();
    var Line1 = context.line();
    var Line2 = context.line();
    var Line3 = context.line();
    var rect0 = context.rect();
    var rect1 = context.rect();
    var rect2 = context.rect();
    var rect3 = context.rect();

    var text0 = context.text();
    var text1 = context.text();
    var text2 = context.text();
    var text3 = context.text();

    allContextArr = [Line0, Line1, Line2, Line3];
    textRectArr = [rect0, rect1, rect2, rect3, text0, text1, text2, text3];
    layer.add(allContextArr);
    layer2.add(textRectArr)
    showMouseLabelLine(view, result);
}

function reFreshMouseToWallLine(){

    if (allContextArr.length > 0 || textRectArr.length > 0){
        var view = utilAppGetViewById(application, "2d");
        showMouseLabelLine(view, wallLineResult);
    }
    
}

//2d视图下显示物体标注线
function showMouseLabelLine(view,result) {  //function showMouseLabelLine(view,obj,result) {
    if (result.point.length > 3) {
        result.point.forEach(function (point, i) {
            var line;
            var text;
            var rect;
            if (i == 0)line = allContextArr[0]
            if (i == 1)line = allContextArr[1]
            if (i == 2)line = allContextArr[2]
            if (i == 3)line = allContextArr[3]
            
            if (i == 0) rect = textRectArr[0]
            if (i == 1) rect = textRectArr[1]
            if (i == 2) rect = textRectArr[2]
            if (i == 3) rect = textRectArr[3]

            if (i == 0) text = textRectArr[4]
            if (i == 1) text = textRectArr[5]
            if (i == 2) text = textRectArr[6]
            if (i == 3) text = textRectArr[7]
            if (!isNaN(point.dis) && !isNaN(point.linepoint.x) && !isNaN(point.linepoint.y)) {
                line.attr({
                    display: "block",
                    x1: point.linepoint.x * 100,
                    y1: -point.linepoint.y * 100,
                    x2: point.wallpoint.x * 100,
                    y2: -point.wallpoint.y * 100,
                    stroke: "#4affff",
                    "stroke-width": 0.5,
                    "stroke-dasharray": "5,5"
                });
                rect.attr({
                    display: "block",
                    fill: "#ffffff",
                    stroke: "#6e6e6e",
                    "stroke-width": api.getViewById("2d").getAreaLabelSize(1,1),
                    cursor: "move",
                    width: api.getViewById("2d").getAreaLabelSize(10,50),
                    height: api.getViewById("2d").getAreaLabelSize(10,30),
                    opacity: 1
                });
                text.attr({
                    stroke: "none",
                    "font-size": api.getViewById("2d").getAreaLabelSize(10,20),
                    fill: "#5f5f5f",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "text-anchor": "middle",
                    display: "block",
                    text: point.dis,
                });
                //提出公共部分 单独就上下左右四个框和文字分别做定位
                if (point.p == 'l') {
                    if(text.node.innerHTML <500){
                        rect.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2 - api.getViewById("2d").getAreaLabelSize(10, 50),
                            y: -point.linepoint.y * 100 - api.getViewById("2d").getAreaLabelSize(10, 30) / 2,
                        });
                        text.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 50),
                            y: -point.linepoint.y * 100 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4,
                        });
                    }else{
                        rect.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2,
                            y: -point.linepoint.y * 100 - api.getViewById("2d").getAreaLabelSize(10, 30) / 2,
                        });
                        text.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2,
                            y: -point.linepoint.y * 100 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4,
                        });       
                    }    
                };
                if (point.p == 'r') {
                    if (text.node.innerHTML < 500){
                        rect.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2 + api.getViewById("2d").getAreaLabelSize(10, 50),
                            y: -point.linepoint.y * 100 - api.getViewById("2d").getAreaLabelSize(10, 30) / 2,
                        });
                        text.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2 + api.getViewById("2d").getAreaLabelSize(10, 50),
                            y: -point.linepoint.y * 100 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4,
                        });
                    }else{
                        rect.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2,
                            y: -point.linepoint.y * 100 - api.getViewById("2d").getAreaLabelSize(10, 30) / 2,
                        });
                        text.attr({
                            x: (point.linepoint.x + point.wallpoint.x) * 100 / 2,
                            y: -point.linepoint.y * 100 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4,
                        });       
                    }
                    
                };
                if (point.p == 't') {
                    if (text.node.innerHTML < 270){
                        rect.attr({
                            x: point.linepoint.x * 100 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 30) / 2 - api.getViewById("2d").getAreaLabelSize(10, 30),
                        });
                        text.attr({
                            x: point.linepoint.x * 100,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4 - api.getViewById("2d").getAreaLabelSize(10, 30),
                        });
                    }else{
                        rect.attr({
                            x: point.linepoint.x * 100 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 30) / 2,
                        });
                        text.attr({
                            x: point.linepoint.x * 100,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4,
                        });
                    }
                    
                };
                if (point.p == 'b') {
                    if (text.node.innerHTML < 270) {
                        rect.attr({
                            x: point.linepoint.x * 100 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 30) / 2 + api.getViewById("2d").getAreaLabelSize(10, 30),
                        });
                        text.attr({
                            x: point.linepoint.x * 100,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4 + api.getViewById("2d").getAreaLabelSize(10, 30),
                        });
                    } else {
                        rect.attr({
                            x: point.linepoint.x * 100 - api.getViewById("2d").getAreaLabelSize(10, 50) / 2,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 - api.getViewById("2d").getAreaLabelSize(10, 30) /2,
                        });
                        text.attr({
                            x: point.linepoint.x * 100,
                            y: -(point.linepoint.y + point.wallpoint.y) * 100 / 2 + api.getViewById("2d").getAreaLabelSize(10, 30) / 4,
                        });
                    }
                    
                }
            }
        })
    }else{
        allContextArr.forEach(function (arrow) {
            arrow.remove();
        });
        allContextArr = [];
        textRectArr.forEach(function (arrow) {
            arrow.remove();
        });
        textRectArr = [];
    }
}

function RemoveMouseToWallLine(){
    allContextArr.forEach(function (arrow) {
        arrow.remove();
    });
    allContextArr = [];
    textRectArr.forEach(function (arrow) {
        arrow.remove();
    });
    textRectArr = [];
}

//显示矩形区域可拖拉标识
function createRectAreaArrow(obj){

    var context = obj.view.context;
    var model = obj.model.hasOwnProperty("center") ? obj.model.center : obj.model;
    var layer = obj.view.layers['PRODUCT_MARK'];

    var loop = obj.model.getLoop();
    var cneterPos = new Vec2(obj.model.center.x, obj.model.center.y);
    var left, right, top, bottom,pos0,pos1,pos2,pos3;
    if (obj.model instanceof RoundArea) {//radius
        var radius = obj.model.radius;
        if(radius){
            pos0 = new Vec2(cneterPos.x - radius, cneterPos.y);
            pos1 = new Vec2(cneterPos.x, cneterPos.y + radius);
            pos2 = new Vec2(cneterPos.x + radius, cneterPos.y);
            pos3 = new Vec2(cneterPos.x, cneterPos.y - radius);
        }
    }else{
        if (loop.length > 0) {
            pos0 = new Vec2((loop[0].x + loop[1].x ) / 2, (loop[0].y + loop[1].y ) / 2);
            pos1 = new Vec2((loop[1].x + loop[2].x ) / 2, (loop[1].y + loop[2].y ) / 2);
            pos2 = new Vec2((loop[2].x + loop[3].x ) / 2, (loop[2].y + loop[3].y ) / 2);
            pos3 = new Vec2((loop[3].x + loop[4].x ) / 2, (loop[3].y + loop[4].y ) / 2);
        }
    }

    if (obj.showDe.moveArrow.length > 0) {  //已经创建过
        createTopBottomArrow(obj, pos1, 0);
        createTopBottomArrow(obj, pos3, 10);
        createLeftRightArrow(obj, pos0, 20);
        createLeftRightArrow(obj, pos2, 30);
    } else {
        for (var i = 0; i < 60; i++) {
            var line = context.path().attr({
                stroke: "#000000",
                "stroke-width": 1,
                display: "none"
            });
            obj.showDe.moveArrow.push(line);
        }
        createTopBottomArrow(obj, pos1, 0);
        createTopBottomArrow(obj, pos3, 10);
        createLeftRightArrow(obj, pos0, 20);
        createLeftRightArrow(obj, pos2, 30);
    }
}

//没有选中时清除画线
function clearRectAreaArrow(obj){
    if(obj.showDe.moveArrow){
        obj.showDe.moveArrow.forEach(function (arrow){
            arrow.remove();
        });
        obj.showDe.moveArrow = [];
    }
}

//创建上下方向箭头
function createTopBottomArrow(obj,pos0,index){  //1-16

    //上
    var arrowT = obj.showDe.moveArrow[index + 1];
    arrowT.attr({
        display: "block",
        path: "M" + pos0.x * 100 + "," + (-(pos0.y + 0.1) * 100) + 
              "L" + ((pos0.x + 0.05) * 100) + "," + (-(pos0.y + 0.05) * 100) + 
              " L" + ((pos0.x - 0.05) * 100) + "," + (-(pos0.y + 0.05) * 100) + 
              "Z"
    });
    
    //下
    var arrowB = obj.showDe.moveArrow[index + 5];
    arrowB.attr({
        display: "block",
        path: "M" + pos0.x * 100 + "," + (-(pos0.y - 0.1) * 100) + 
              "L" + ((pos0.x + 0.05) * 100) + "," + (-(pos0.y - 0.05) * 100) + 
              " L" + ((pos0.x - 0.05) * 100) + "," + (-(pos0.y - 0.05) * 100) + 
              "Z"
    });
}
//创建左右方向箭头
function createLeftRightArrow(obj,pos0,index){ //17-32
    //右
    var arrowL = obj.showDe.moveArrow[index + 1];
    arrowL.attr({
        display: "block",
        path: "M" + (pos0.x+ 0.1) * 100 + "," + (-(pos0.y) * 100) + 
              "L" + ((pos0.x + 0.05) * 100) + "," + (-(pos0.y + 0.05) * 100) + 
              " L" + ((pos0.x + 0.05) * 100) + "," + (-(pos0.y - 0.05) * 100) + 
              "Z"
    });
    
    //左
    var arrowR = obj.showDe.moveArrow[index + 5];
    arrowR.attr({
        display: "block",
        path: "M" + (pos0.x - 0.1) * 100 + "," + (-(pos0.y) * 100) + 
              "L" + ((pos0.x - 0.05) * 100) + "," + (-(pos0.y + 0.05) * 100) + 
              " L" + ((pos0.x - 0.05) * 100) + "," + (-(pos0.y - 0.05) * 100) + 
              "Z"
    });
   
}

//add by gaoning 2018.3.15
////////////////////////////////////////////////////////////////

//创建标距线 add by hcw
function createLabelLine(obj) {
    var context = obj.view.context, model = obj.model.hasOwnProperty("center") ? obj.model.center : obj.model;
    var layer = obj.view.layers['PRODUCT_MARK'];//物体标注信息层
    if(obj.model.group)return;
    if (obj.model instanceof Product) {
        var meta = model.meta, height = (meta.xlen * model.sx, meta.ylen * model.sy), width = meta.xlen * model.sx
    }else if(obj.model instanceof Group){
        var height = obj.model.height/100, width = obj.model.width/100
    } else {
        var height = obj.model.height, width = obj.model.width
    }
    if (obj.model instanceof RoundArea) {
        var lineleft = {
            x: model.x - obj.model.radius,
            y: model.y
        }, lineright = {
            x: model.x + obj.model.radius,
            y: model.y
        }, lineTop = {
            x: model.x,
            y: model.y + obj.model.radius
        }, linebuttom = {
            x: model.x,
            y: model.y - obj.model.radius
        }
        var allWall = GetCurrentFloor([lineleft, lineright, lineTop, linebuttom]);//获取物体所在房间的所有墙体
        var result = createProductLabel(allWall, lineleft, lineright, lineTop, linebuttom, obj.model.rot)
    } else {
        var lineTopleft = utilMathRotatePointCW(model, {
            x: model.x - width / 2,
            y: model.y + height / 2
        }, obj.model.rot), lineTopright = utilMathRotatePointCW(model, {
            x: model.x + width / 2,
            y: model.y + height / 2
        }, obj.model.rot), linebuttomleft = utilMathRotatePointCW(model, {
            x: model.x - width / 2,
            y: model.y - height / 2
        }, obj.model.rot), linebuttomright = utilMathRotatePointCW(model, {
            x: model.x + width / 2,
            y: model.y - height / 2
        }, obj.model.rot), lineleft = utilMathRotatePointCW(model, {
            x: model.x - width / 2,
            y: model.y
        }, obj.model.rot), lineright = utilMathRotatePointCW(model, {
            x: model.x + width / 2,
            y: model.y
        }, obj.model.rot), lineTop = utilMathRotatePointCW(model, {
            x: model.x,
            y: model.y + height / 2
        }, obj.model.rot), linebuttom = utilMathRotatePointCW(model, {
            x: model.x,
            y: model.y - height / 2
        }, obj.model.rot)
        var allWall = GetCurrentFloor([lineTopleft, lineTopright, linebuttomleft, linebuttomright]);//获取物体所在房间的所有墙体
        if (obj.model.rot == 0 || obj.model.rot == 90 || obj.model.rot == 180 || obj.model.rot == 270 || obj.model.rot == 360) {
            var result = createProductLabel(allWall, lineleft, lineright, lineTop, linebuttom, obj.model.rot)
        } else {
            var result = createProductLabel(allWall, linebuttomleft, linebuttomright, lineTopleft, lineTopright, obj.model.rot)
        }
    }
    if (obj.showDe.label.length > 0) {
        if (obj.model instanceof Product) {
            showLabelLine(obj, result, 1);
        } else {
            showLabelLine(obj, result);
        }
        return;
    }
    var Line0 = context.line().attr({
        stroke: "#6E6E6E",
        "stroke-width": 1.5,
        "stroke-dasharray":"5,5",
        display: "none"
    });
    var Line1 = context.line().attr({
        stroke: "#6E6E6E",
        "stroke-width": 1.5,
        "stroke-dasharray":"5,5",
        display: "none"
    });
    var Line2 = context.line().attr({
        stroke: "#6E6E6E",
        "stroke-width": 1.5,
        "stroke-dasharray":"5,5",
        display: "none"
    });
    var Line3 = context.line().attr({
        stroke: "#6E6E6E",
        "stroke-width": 1.5,
        "stroke-dasharray":"5,5",
        display: "none"
    });
    obj.showDe.label = [Line0, Line1, Line2, Line3]
    layer.add(obj.showDe.label);
    if (obj.model.hasOwnProperty("meta")) {
        showLabelLine(obj, result, 1);
    } else {
        showLabelLine(obj, result);
    }

}

//2d视图下显示物体标注线 add by hcw
function showLabelLine(obj, result, type) {
    if (result.point.length > 0) {
        result.point.forEach(function (point, i) {
            var line, textx = point.linepoint.x, texty = point.linepoint.y
            if (i == 0)line = obj.showDe.label[0]
            if (i == 1)line = obj.showDe.label[1]
            if (i == 2)line = obj.showDe.label[2]
            if (i == 3)line = obj.showDe.label[3]
            if (!isNaN(point.dis) || !isNaN(point.linepoint.x) || !isNaN(point.linepoint.y)) {
                line.attr({
                    display: "block",
                    x1: point.linepoint.x * 100,
                    y1: -point.linepoint.y * 100,
                    x2: point.wallpoint.x * 100,
                    y2: -point.wallpoint.y * 100
                })
                var pointwalldis = Math.sqrt(Math.pow(point.linepoint.x - point.wallpoint.x, 2) + Math.pow(point.linepoint.y - point.wallpoint.y, 2))
                if (point.p == 'l')textx = textx - pointwalldis / 2
                if (point.p == 'r')textx = textx + pointwalldis / 2
                if (point.p == 't')texty = texty + pointwalldis / 2
                if (point.p == 'b')texty = texty - pointwalldis / 2
                obj.model.textpos[i] = {
                    type: point.p,
                    text: point.dis,
                    x: textx * 100,
                    y: -texty * 100,
                    widthl: result.widthmaxl,
                    widthr: result.widthmaxr,
                    heightt: result.heighttmax,
                    heightb: result.heightbmax,
                    dis2: point.dis2 * 100
                };
                //物体旋转手柄不与标距线输入框重叠 add by hcw
                if (type != void 0) {
                    var view = obj.view;
                    var meta = obj.model.meta, height = (meta.xlen * obj.model.sx, meta.ylen * obj.model.sy), lineBeginModelPt = utilMathRotatePointCW(obj.model, {
                        x: obj.model.x,
                        y: obj.model.y - height / 2
                    }, obj.model.rot), lineScreenLength = 100, lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, lineScreenLength * Math.sin(utilMathToRadius(obj.model.rot)), lineScreenLength * Math.cos(utilMathToRadius(obj.model.rot))), lineEndModelPt = {
                        x: lineEndModelPtDelta.x + lineBeginModelPt.x,
                        y: lineEndModelPtDelta.y + lineBeginModelPt.y
                    };
                    var handLehgth = utilMathLineLength(lineEndModelPt, lineBeginModelPt);
                    if (((obj.model.rot == 0 || obj.model.rot == 360) && point.p == 'b') || (obj.model.rot == 90 && point.p == 'r') || (obj.model.rot == 180 && point.p == 't') || (obj.model.rot == 270 && point.p == 'l')) {
                        handLehgth = handLehgth + handLehgth / 4;
                        if (handLehgth > pointwalldis / 2) {
                            var lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, 155 * Math.sin(utilMathToRadius(obj.model.rot)), 155 * Math.cos(utilMathToRadius(obj.model.rot)));
                            lineEndModelPt = {
                                x: lineEndModelPtDelta.x + lineBeginModelPt.x,
                                y: lineEndModelPtDelta.y + lineBeginModelPt.y
                            };
                            obj.de[2].attr({
                                x1: lineBeginModelPt.x * 100,
                                y1: -lineBeginModelPt.y * 100,
                                x2: lineEndModelPt.x * 100,
                                y2: -lineEndModelPt.y * 100
                            });
                            obj.de[4].attr({
                                x: lineEndModelPt.x * 100 - obj.de[4].attr('width')/2,
                                y: -lineEndModelPt.y * 100 - obj.de[4].attr('width')/2,
                            })
                        }
                    }
                }
            }
        })
        application.laberFrame(obj.model)//添加物体标注线输入框显示
    }
}

//创建辅助线 add by hcw
function destroyArrowLine(obj) {
    if (obj._zoomEventAL) {
        obj.view.zoomChangedEvent.remove(obj._zoomEventAL);
        obj._zoomEventAL = null;
    }
}
function createArrowLine(obj) {
    var pickMgr = obj.view.app.pickMgr;
    var context = obj.view.context;
    var model = obj.model, view = obj.view;
    var actionMgr = obj.view.app.actionMgr, app = application;
    if(model.group)return;
    if (obj.showDe.arrow.length > 0) {
        !utilAppFloorplanIsLocked(app)?  setArrow(obj):!(obj.model instanceof FreeArea || obj.model instanceof RectArea || obj.model instanceof RoundArea)? setArrow(obj):"";
        return;
    }
    var Liney = context.line().attr({
        stroke: "blue",
        "stroke-width": 1,
        display: "none",
        cursor: "move"
    });
    var arrowy = context.path().attr({
        fill: "blue",
        display: "none",
        "stroke-width": 1,
    });

    var movey = context.rect().attr({
        "stroke-width": 0,
        "fill-opacity": .01,
        did: obj.id,
        stroke: "red",
        display: "none",
        cursor: "move",
    }).click(function (e, screen_x, screen_y) {
        utilPickMgrPick(pickMgr, model);
    }).mouseover(function (e) {
        Liney.attr({stroke: "yellow"}), arrowy.attr({fill: "yellow"})
    }).mouseout(function (e) {
        Liney.attr({stroke: "blue"}), arrowy.attr({fill: "blue"})
    }).drag(function (dx, dy, x, y, e) {
        if (e.stopPropagation(), 1 != e.button && (!utilAppFloorplanIsLocked(app)?  true:!(obj.model instanceof FreeArea || obj.model instanceof RectArea || obj.model instanceof RoundArea)? true:false)) {
        	  if(e.buttons && e.buttons == 1){
	            var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
	            if (obj.model instanceof FreeArea) {
	                for (var id in this._modelPos) {
	                    var pos = this._modelPos[id];
	                    pos.m.x = pos.x, pos.m.y = pos.y + modelOffset.y;
	                }
	                utilModelChangeFlag(this.model, AREAFLAG_CHANGED_FOR_REDRAWN);
	            } else if (obj.model instanceof Product) {
	                if (obj.model.meta.category == 'furniture') {
	                    utilActionRun(actionMgr, e.type + "2d", e, {
	                        x: obj.ox,
	                        y: obj.oy + modelOffset.y
	                    }, modelOffset);
	                } else {
	                    var mPos = {
	                        x: obj.ox,
	                        y: obj.oy + modelOffset.y
	                    }, hitPt = {
	                        x: 100 * mPos.x,
	                        y: 100 * -mPos.y
	                    }, picked = utilSnapDisplaySelect(view, hitPt, [Wall.prototype.type]), attachedWall = picked.length > 0 ? picked[0].model : void 0;
	                    attachedWall && __log("attach to wall [" + mPos.x + ", " + mPos.y), utilActionRun(actionMgr, e.type + "2d", e, mPos, attachedWall);
	                }
	            } else if(obj.model instanceof Group){
	                actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, {
	                    x: 0,
	                    y: modelOffset.y
	                }, {
                        x: 0,
                        y: modelOffset.y
                    }));
	            }else{
                    actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, {
                        x: 0,
                        y: modelOffset.y
                    }, modelOffset));
                }
	          }
        }
    }, function (x, y, e) {
        if (e.stopPropagation(), 1 != e.button) {
            if (obj.model instanceof FreeArea) {
                var profile = obj.model.profile, pos = obj._modelPos = {};
                profile.forEach(function (curve) {
                    var begin = curve.begin, end = curve.end;
                    pos[begin.id] = {
                        m: begin,
                        x: begin.x,
                        y: begin.y
                    }, pos[end.id] = {
                        m: end,
                        x: end.x,
                        y: end.y
                    };
                });
            } else if (obj.model instanceof Product) {
                if (obj.ox = model.x, obj.oy = model.y, !actionMgr.current) {
                    if (obj.model.meta.category == 'furniture') {
                        var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveProduct.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                        utilActionBegin(actionMgr, actionType, actionModel, {
                            shiftKey: e.shiftKey
                        });
                    } else {
                        obj.ox = this.model.x, obj.oy = obj.model.y, actionMgr.current || utilActionBegin(actionMgr, ActionMoveProduct.prototype.type, obj.model);
                    }
                }
            } else if(obj.model instanceof Group){
                    utilActionBegin(actionMgr, ActionMoveGroup.prototype.type, obj.model)
            }else {
                obj._modelCenter = {
                    x: model.center.x,
                    y: model.center.y
                };
                if (!actionMgr.current) {
                    var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveArea.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                    utilActionBegin(actionMgr, actionType, actionModel, {
                        shiftKey: e.shiftKey
                    });
                }
            }
        }
    }, function (e) {
        if (obj.model instanceof FreeArea) {
            e.stopPropagation(), 1 != e.button && delete this._modelPos;
        } else if (obj.model instanceof Product) {
            if (obj.model.meta.category == 'furniture') {
                e.stopPropagation(), 1 != e.button && utilActionEnd(actionMgr);
            } else {
                utilActionEnd(actionMgr, ActionMoveProduct.prototype.type);
            }
        } else {
            e.stopPropagation(), 1 != e.button && (delete obj._modelCenter, actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionEnd(actionMgr)
            ));
        }
    }, obj, obj, obj);
    var Linex = context.line().attr({
        stroke: "red",
        "stroke-width": 1,
        display: "none",
        cursor: "move"
    });
    var arrowx = context.path().attr({
        fill: "red",
        display: "none",
        "stroke-width": 1,
    })
    var movex = context.rect().attr({
        "stroke-width": 0,
        "fill-opacity": .01,
        did: obj.id,
        stroke: "red",
        display: "none",
        cursor: "move",
    }).click(function (e, screen_x, screen_y) {
        utilPickMgrPick(pickMgr, model);
    }).mouseover(function (e) {
        Linex.attr({stroke: "yellow"}), arrowx.attr({fill: "yellow"})
    }).mouseout(function (e) {
        Linex.attr({stroke: "red"}), arrowx.attr({fill: "red"})
    }).drag(function (dx, dy, x, y, e) {
        if (e.stopPropagation(), 1 != e.button &&  (!utilAppFloorplanIsLocked(app)?  true:!(obj.model instanceof FreeArea || obj.model instanceof RectArea || obj.model instanceof RoundArea)? true:false)) {
        	  if(e.buttons && e.buttons == 1){
	            var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
	            if (obj.model instanceof FreeArea) {
	                for (var id in this._modelPos) {
	                    var pos = this._modelPos[id];
	                    pos.m.x = pos.x + modelOffset.x, pos.m.y = pos.y;
	                }
	                utilModelChangeFlag(this.model, AREAFLAG_CHANGED_FOR_REDRAWN);
	            } else if (obj.model instanceof Product) {
	                if (obj.model.meta.category == 'furniture') {
	                    utilActionRun(actionMgr, e.type + "2d", e, {
	                        x: obj.ox + modelOffset.x,
	                        y: obj.oy
	                    }, modelOffset);
	                } else {
	                    var mPos = {
	                        x: obj.ox + modelOffset.x,
	                        y: obj.oy
	                    }, hitPt = {
	                        x: 100 * mPos.x,
	                        y: 100 * -mPos.y
	                    }, picked = utilSnapDisplaySelect(view, hitPt, [Wall.prototype.type]), attachedWall = picked.length > 0 ? picked[0].model : void 0;
	                    attachedWall && __log("attach to wall [" + mPos.x + ", " + mPos.y), utilActionRun(actionMgr, e.type + "2d", e, mPos, attachedWall);
	                }
	            }else if(obj.model instanceof Group){
                    actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, {
                        x: modelOffset.x,
                        y: 0
                    }, {
                        x: modelOffset.x,
                        y: 0
                    }));
                } else {
	                actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, {
	                    x: modelOffset.x,
	                    y: 0
	                }, modelOffset));
	            }
	          }
        }
    }, function (x, y, e) {
        if (e.stopPropagation(), 1 != e.button) {
            if (obj.model instanceof FreeArea) {
                var profile = obj.model.profile, pos = obj._modelPos = {};
                profile.forEach(function (curve) {
                    var begin = curve.begin, end = curve.end;
                    pos[begin.id] = {
                        m: begin,
                        x: begin.x,
                        y: begin.y
                    }, pos[end.id] = {
                        m: end,
                        x: end.x,
                        y: end.y
                    };
                });
            } else if (obj.model instanceof Product) {
                if (this.ox = model.x, this.oy = model.y, !actionMgr.current) {
                    if (obj.model.meta.category == 'furniture') {
                        var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveProduct.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                        utilActionBegin(actionMgr, actionType, actionModel, {
                            shiftKey: e.shiftKey
                        });
                    } else {
                        obj.ox = this.model.x, obj.oy = obj.model.y, actionMgr.current || utilActionBegin(actionMgr, ActionMoveProduct.prototype.type, obj.model);
                    }
                }
            }else if(obj.model instanceof Group){
                utilActionBegin(actionMgr, ActionMoveGroup.prototype.type, obj.model)
            } else {
                obj._modelCenter = {
                    x: model.center.x,
                    y: model.center.y
                };
                if (!actionMgr.current) {
                    var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveArea.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                    utilActionBegin(actionMgr, actionType, actionModel, {
                        shiftKey: e.shiftKey
                    });
                }
            }
        }
    }, function (e) {
        if (obj.model instanceof FreeArea) {
            e.stopPropagation(), 1 != e.button && delete this._modelPos;
        } else if (obj.model instanceof Product) {
            if (obj.model.meta.category == 'furniture') {
                e.stopPropagation(), 1 != e.button && utilActionEnd(actionMgr);
            } else {
                utilActionEnd(actionMgr, ActionMoveProduct.prototype.type);
            }
        } else {
            e.stopPropagation(), 1 != e.button && (delete obj._modelCenter, actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionEnd(actionMgr)
            ));
        }
    }, obj, obj, obj);
    var centerBox =  context.rect().attr({
        display: "none",
        cursor: "move",
        fill: "yellow",
        "fill-opacity": .6,
    }).click(function (e, screen_x, screen_y) {
        utilPickMgrPick(pickMgr, model);
    }).mouseover(function (e) {
        centerBox.attr({"fill-opacity": 1})
    }).mouseout(function (e) {
        centerBox.attr({"fill-opacity": .6})
    }).drag(function (dx, dy, x, y, e) {
        if (e.stopPropagation(), 1 != e.button &&  (!utilAppFloorplanIsLocked(app)?  true:!(obj.model instanceof FreeArea || obj.model instanceof RectArea || obj.model instanceof RoundArea)? true:false)) {
            if(e.buttons && e.buttons == 1){
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
                if (obj.model instanceof FreeArea) {
                    for (var id in this._modelPos) {
                        var pos = this._modelPos[id];
                        pos.m.x = pos.x + modelOffset.x, pos.m.y = pos.y + modelOffset.y;
                    }
                    utilModelChangeFlag(this.model, AREAFLAG_CHANGED_FOR_REDRAWN);
                } else if (obj.model instanceof Product) {
                    if (obj.model.meta.category == 'furniture') {
                        utilActionRun(actionMgr, e.type + "2d", e, {
                            x: obj.ox + modelOffset.x,
                            y: obj.oy + modelOffset.y
                        }, modelOffset);
                    } else {
                        var mPos = {
                            x: obj.ox + modelOffset.x,
                            y: obj.oy + modelOffset.y
                        }, hitPt = {
                            x: 100 * mPos.x,
                            y: 100 * -mPos.y
                        }, picked = utilSnapDisplaySelect(view, hitPt, [Wall.prototype.type]), attachedWall = picked.length > 0 ? picked[0].model : void 0;
                        attachedWall && __log("attach to wall [" + mPos.x + ", " + mPos.y), utilActionRun(actionMgr, e.type + "2d", e, mPos, attachedWall);
                    }
                } else {
                    actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, {
                        x: modelOffset.x,
                        y: modelOffset.y
                    }, modelOffset));
                }
            }
        }
    }, function (x, y, e) {
        if (e.stopPropagation(), 1 != e.button) {
            if (obj.model instanceof FreeArea) {
                var profile = obj.model.profile, pos = obj._modelPos = {};
                profile.forEach(function (curve) {
                    var begin = curve.begin, end = curve.end;
                    pos[begin.id] = {
                        m: begin,
                        x: begin.x,
                        y: begin.y
                    }, pos[end.id] = {
                        m: end,
                        x: end.x,
                        y: end.y
                    };
                });
            } else if (obj.model instanceof Product) {
                if (this.ox = model.x, this.oy = model.y, !actionMgr.current) {
                    if (obj.model.meta.category == 'furniture') {
                        var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveProduct.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                        utilActionBegin(actionMgr, actionType, actionModel, {
                            shiftKey: e.shiftKey
                        });
                    } else {
                        obj.ox = this.model.x, obj.oy = obj.model.y, actionMgr.current || utilActionBegin(actionMgr, ActionMoveProduct.prototype.type, obj.model);
                    }
                }
            }else if(obj.model instanceof Group){
                utilActionBegin(actionMgr, ActionMoveGroup.prototype.type, obj.model)
            } else {
                obj._modelCenter = {
                    x: model.center.x,
                    y: model.center.y
                };
                if (!actionMgr.current) {
                    var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveArea.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                    utilActionBegin(actionMgr, actionType, actionModel, {
                        shiftKey: e.shiftKey
                    });
                }
            }
        }
    }, function (e) {
        if (obj.model instanceof FreeArea) {
            e.stopPropagation(), 1 != e.button && delete this._modelPos;
        } else if (obj.model instanceof Product) {
            if (obj.model.meta.category == 'furniture') {
                e.stopPropagation(), 1 != e.button && utilActionEnd(actionMgr);
            } else {
                utilActionEnd(actionMgr, ActionMoveProduct.prototype.type);
            }
        } else {
            e.stopPropagation(), 1 != e.button && (delete obj._modelCenter, actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionEnd(actionMgr)
            ));
        }
    }, obj, obj, obj);
    obj.showDe.arrow = [Liney, arrowy, movey, Linex, arrowx, movex,centerBox];
    !utilAppFloorplanIsLocked(app)?  setArrow(obj):!(obj.model instanceof FreeArea || obj.model instanceof RectArea || obj.model instanceof RoundArea)? setArrow(obj):"";
    //!utilAppFloorplanIsLocked(app) ? setArrow(obj) : "";
    obj._zoomEventAL = function () {
        //缩放时改变辅助箭头长度  add by hcw
        if (this instanceof Product) {
            this.dF |= 3;
        } else {
            this.dF |= 2;
        }
        this.update()
    }.bind(obj);
    obj.view.zoomChangedEvent.add(obj._zoomEventAL);
}
//2d视图下箭头辅助线  add by hcw
function setArrow(obj) {
    var arrowWidth = 20, layer = obj.view.layers['AUXILLARY_ARROW'], factor = 100, view = obj.view, lineScreenLength = 100;
    var model = obj.model.hasOwnProperty("center") ? obj.model.center : obj.model;
    var sizeMultiple=1,centerBoxWidth=25;
    if (obj.model instanceof RoundArea) {
        var height = obj.model.radius / 2, lineBeginModelPt = utilMathRotatePointCW(model, {
            x: model.x,
            y: model.y - height
        }, obj.model.rot), lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, lineScreenLength * Math.sin(utilMathToRadius(obj.model.rot)), lineScreenLength * Math.cos(utilMathToRadius(obj.model.rot))), lineEndModelPt = {
            x: lineEndModelPtDelta.x + lineBeginModelPt.x,
            y: lineEndModelPtDelta.y + lineBeginModelPt.y
        };
        sizeMultiple= (utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7;
        var moveLength=utilMathLineLength(lineEndModelPt, lineBeginModelPt);
    } else if (obj.model instanceof FreeArea) {
        var start = obj.model.profile[0].begin;
        model = start;
        var allpoint = [], x = 0, y = 0;
        obj.model.profile.forEach(function (p) {
            allpoint.push({x: p.begin.x, y: p.begin.y})
            allpoint.push({x: p.end.x, y: p.end.y})
        })
        allpoint.forEach(function (point) {
            x += point.x;
            y += point.y;
        })
        x = x / allpoint.length, y = y / allpoint.length
        var lineBeginModelPt = utilMathRotatePointCW(start, {
            x: x,
            y: y
        }, 0), lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, lineScreenLength * Math.sin(utilMathToRadius(0)), lineScreenLength * Math.cos(utilMathToRadius(0))), lineEndModelPt = {
            x: lineEndModelPtDelta.x + lineBeginModelPt.x,
            y: lineEndModelPtDelta.y + lineBeginModelPt.y
        };
        var moveLength = utilMathLineLength(lineEndModelPt, lineBeginModelPt);
        sizeMultiple= (utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7;
    } else if (obj.model instanceof Product) {
        var meta = model.meta, height = (meta.xlen * model.sx, meta.ylen * model.sy), width = meta.xlen * obj.model.sx, lineBeginModelPt = utilMathRotatePointCW(model, {
            x: model.x,
            y: model.y - height / 2
        }, model.rot), lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, lineScreenLength * Math.sin(utilMathToRadius(model.rot)), lineScreenLength * Math.cos(utilMathToRadius(model.rot))), lineEndModelPt = {
            x: lineEndModelPtDelta.x + lineBeginModelPt.x,
            y: lineEndModelPtDelta.y + lineBeginModelPt.y
        };
        var moveLength = utilMathLineLength(lineEndModelPt, lineBeginModelPt);
        sizeMultiple= (utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7;
    } else {
        var height = obj.model.height / 2, width = obj.model.width, lineBeginModelPt = utilMathRotatePointCW(model, {
            x: model.x,
            y: model.y - height
        }, obj.model.rot), lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, lineScreenLength * Math.sin(utilMathToRadius(obj.model.rot)), lineScreenLength * Math.cos(utilMathToRadius(obj.model.rot))), lineEndModelPt = {
            x: lineEndModelPtDelta.x + lineBeginModelPt.x,
            y: lineEndModelPtDelta.y + lineBeginModelPt.y
        };
        var moveLength = utilMathLineLength(lineEndModelPt, lineBeginModelPt);
        sizeMultiple= (utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7;
    }
    var moveEndY = -(model.y + moveLength) * factor, moveStartY = model.x * factor-5*sizeMultiple,
        moveStartX = model.x * factor + moveLength * factor, moveEndX = -model.y * factor;
        arrowWidth=arrowWidth*sizeMultiple;
    if (obj.model instanceof FreeArea) {
        moveEndY = -(y + moveLength) * factor, moveStartY = x * factor - 5*sizeMultiple,
            moveStartX = x * factor + moveLength * factor, moveEndX = -y * factor;
        obj.showDe.arrow[2].attr({
            display: "block",
            x: x * factor - arrowWidth / 2,
            y: -(y + moveLength) * factor - centerBoxWidth*sizeMultiple,
            width: arrowWidth,
            height: moveLength * factor
        });
        obj.showDe.arrow[5].attr({
            display: "block",
            x: x * factor + centerBoxWidth*sizeMultiple,
            y: -y * factor - arrowWidth / 2,
            width: moveLength * factor,
            height: arrowWidth
        })

        obj.showDe.arrow[0].attr({
            "stroke-width":sizeMultiple,
            display: "block",
            x1: x * factor ,
            y1: -y * factor - centerBoxWidth*sizeMultiple + sizeMultiple,
            x2: x * factor,
            y2: -(y + moveLength) * factor
        })
        obj.showDe.arrow[3].attr({
            "stroke-width":sizeMultiple,
            display: "block",
            x1: x * factor + centerBoxWidth*sizeMultiple,
            y1: -y * factor,
            x2: (x + moveLength) * factor,
            y2: -y * factor
        })
        obj.showDe.arrow[6].attr({
            display: "block",
            x: x * factor - sizeMultiple,
            y: - y * factor - centerBoxWidth*sizeMultiple + sizeMultiple,
            width: centerBoxWidth*sizeMultiple,
            height:centerBoxWidth*sizeMultiple
        })
    } else {
        obj.showDe.arrow[2].attr({
            display: "block",
            x: model.x * factor - arrowWidth / 2,
            y: -(model.y + moveLength) * factor - centerBoxWidth*sizeMultiple,
            width: arrowWidth,
            height: moveLength * factor
        });
        obj.showDe.arrow[5].attr({
            display: "block",
            x: model.x * factor +centerBoxWidth*sizeMultiple,
            y: -model.y * factor - arrowWidth / 2,
            width: moveLength * factor,
            height: arrowWidth
        })

        obj.showDe.arrow[0].attr({
            "stroke-width":sizeMultiple,
            display: "block",
            x1: model.x * factor,
            y1: -model.y * factor - centerBoxWidth*sizeMultiple + sizeMultiple,
            x2: model.x * factor,
            y2: -(model.y + moveLength) * factor
        })
        obj.showDe.arrow[3].attr({
            "stroke-width":sizeMultiple,
            display: "block",
            x1: model.x * factor + centerBoxWidth*sizeMultiple,
            y1: -model.y * factor,
            x2: (model.x + moveLength) * factor,
            y2: -model.y * factor
        })
        obj.showDe.arrow[6].attr({
            display: "block",
            x: model.x * factor - sizeMultiple,
            y: -model.y * factor - centerBoxWidth*sizeMultiple + sizeMultiple,
            width:centerBoxWidth*sizeMultiple,
            height:centerBoxWidth*sizeMultiple
        })
    }
    obj.showDe.arrow[1].attr({
        path: "M" + moveStartY + "," + (moveEndY + 15*sizeMultiple) + " L" + (moveStartY + 5*sizeMultiple) + "," + (moveEndY) + " L" + (moveStartY + 10*sizeMultiple) + "," + (moveEndY + 15*sizeMultiple) + " L" + moveStartY + "," + (moveEndY + 15*sizeMultiple),
        display: "block"
    })
    obj.showDe.arrow[4].attr({
        path: "M" + (moveStartX - 15*sizeMultiple) + "," + (moveEndX + 5*sizeMultiple) + " L" + (moveStartX - 15*sizeMultiple) + "," + (moveEndX - 5*sizeMultiple) + " L" + moveStartX + "," + moveEndX + " L" + (moveStartX - 15*sizeMultiple) + "," + (moveEndX + 5*sizeMultiple),
        display: "block"
    })

    layer.add(obj.showDe.arrow)
}


/*插入产品到画布*/
var utilSnapViewUpdateMaterial = function (displayObject, material, patternCallback) {
    var model = displayObject.model, view = displayObject.view;
    if (!material)
        return "";
    var patternId = material.id;
    utilSnapViewCreatePattern(view, material, patternId, function (pattern) {
        if (pattern && pattern.transform) {
            var mat = material;
            //左下角坐标            
            var loop = model.type == Floor.prototype.type ? model.getInsideLoop() : model.getLoop();// 改成使用内框
            if (loop) {
                var modelBottomLeft = {
                    x: 1000,
                    y: 1000
                };
                for (var i = 0; i < loop.length; ++i) {
                    var pt = loop[i];
                    modelBottomLeft.x = Math.min(modelBottomLeft.x, pt.x), modelBottomLeft.y = Math.min(modelBottomLeft.y, pt.y);
                }
                model instanceof RectArea && (modelBottomLeft = model.getLoop({
                    rot: 0
                })[0]);
                var scale = mat ? mat.getScale() : {
                    x: 1,
                    y: 1
                };
                var translate = {
                    x: mat ? mat.tx : 0,
                    y: mat ? mat.ty : 0
                };
                var rot = mat ? mat.rot : 0;
                pattern.transform("T" + toFixedNumber(100 * modelBottomLeft.x, 3) + "," + toFixedNumber(-100 * modelBottomLeft.y, 3) + "r" + Math.round(-rot) + "S" + toFixedNumber(scale.x, 3) + "," + toFixedNumber(scale.y, 3) + "T" + toFixedNumber(100 * translate.x, 3) + "," + toFixedNumber(-100 * translate.y, 3));
                patternCallback && patternCallback.call(displayObject, pattern);
            }
        }
    });
    return "url(#" + patternId + ")";
};

classInherit(DisplaySnapGrid, DisplayObject), utilExtend(DisplaySnapGrid.prototype, {
    create: function () {
        var layer = this.view.layers[this.model.id];
        var context = this.view.context;
        var defaultWidth = 100;
        var geometry = utilSnapGridCreateGeometry(defaultWidth, defaultWidth, 1);
        
        this.de = [];
        var path = utilSnapGridBuildSvgLine(geometry.ax);
        this.de.push(context.path(path).attr({
            "stroke-width": 4,
            stroke: "black",
            opacity: .1
        }));        
        path = utilSnapGridBuildSvgLine(geometry.ma);
        this.de.push(context.path(path).attr({
            "stroke-width": 2,
            stroke: "black",
            opacity: .1
        }));
        path = utilSnapGridBuildSvgLine(geometry.mi);
        this.de.push(context.path(path).attr({
            "stroke-width": 1,
            stroke: "black",
            opacity: .1
        }));
        layer.add(this.de);
    }
}), classInherit(DisplaySnapOuterDimension, DisplayObject), utilExtend(DisplaySnapOuterDimension.prototype, {
    create: function () {
        this.view.layers[this.model.id], this.view.context;
    },
    update: function () {
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.remove();
        });
    }
}), classInherit(DisplaySnapCamera, DisplayObject);

var SNAP_CAMERA_IMG = {
    url: "asset/imgSnap/camera.png",
    width: 30,
    height: 50
}, SNAP_CAMERA_TARGET_IMG = {
    url: "asset/imgSnap/camera_target.png",
    width: 30,
    height: 100
}, SNAP_CAMERA_CLIP_IMG = {
    url: "asset/imgSnap/camera_clip.png",
    width: 26,
    height: 12
}, SNAP_CAMERA_REGION = {
    color: "#333",
    "stroke-width": 3
}, SNAP_CAMERA_LOCK_IMAGE = {
    url: "asset/imgSnap/camera_lock.png",
    width: 20,
    height: 20,
},SNAP_Product_Rotate_IMG = {
    url: "asset/imgSnap/model_rotate.png",
    width: 38,
    height: 38
},SNAP_Group_Rotate_IMG = {
    url: "asset/imgSnap/group_rotate.png",
    width: 38,
    height: 38
};

utilExtend(DisplaySnapCamera.prototype, {
    create: function () {
        this.model.layerOrer_ = this.view.layerOrder;
        var context = (this.de = this.de || [], this.view.context);
        if (context && !(this.de.length > 0)) {
            var layer = this.view.layers[this.model.type], svgPos = {
                x: 100 * this.model.x,
                y: 100 * -this.model.y,
                did: this.model.id
            }, svgTarget = {
                x: 100 * this.model.tx,
                y: 100 * -this.model.ty,
                did: this.model.id
            }, fov = this.model.hfov, isActive = this.model.active, actionMgr = this.view.app.actionMgr, cameraPosImg = context.image(SNAP_CAMERA_IMG.url, -SNAP_CAMERA_IMG.width / 2, -SNAP_CAMERA_IMG.height / 2, SNAP_CAMERA_IMG.width, SNAP_CAMERA_IMG.height).attr({
                stroke: "#909090",
                "stroke-width": 0,
                "fill-opacity": 1,
                cursor: "move",
                did: this.model.id
            }), cameraTargetImg = context.image(SNAP_CAMERA_TARGET_IMG.url, -SNAP_CAMERA_TARGET_IMG.width / 2, -SNAP_CAMERA_TARGET_IMG.height / 2, SNAP_CAMERA_TARGET_IMG.width, SNAP_CAMERA_TARGET_IMG.height).attr({
                stroke: "#909090",
                "stroke-width": 0,
                "fill-opacity": 1,
                cursor: "move",
                did: this.model.id
            }), cameraLockImg = context.image(SNAP_CAMERA_LOCK_IMAGE.url, -SNAP_CAMERA_LOCK_IMAGE.width / 2, -SNAP_CAMERA_LOCK_IMAGE.height / 2, SNAP_CAMERA_LOCK_IMAGE.width, SNAP_CAMERA_LOCK_IMAGE.height).attr({
                stroke: "red",
                "stroke-width": 10,
                "fill-opacity": 1,
                "alt": "image-block",
                cid: this.model.id // 根据此ID判断当前的摄像机
            }), cameraClipPlaneImg = context.image(SNAP_CAMERA_CLIP_IMG.url, -SNAP_CAMERA_CLIP_IMG.width / 2, -SNAP_CAMERA_CLIP_IMG.height / 2, SNAP_CAMERA_CLIP_IMG.width, SNAP_CAMERA_CLIP_IMG.height).attr({
                stroke: "#909090",
                "stroke-width": 0,
                "fill-opacity": 1,
                cursor: "move",
                did: this.model.id
            }), cameraP = context.circle(svgPos.x, svgPos.y, 10).attr({
                stroke: "#909090",
                "stroke-width": 1,
                "fill-opacity": .7,
                fill: "#c0c0c0",
                cursor: "move",
                did: this.model.id
            }), target = context.circle(svgTarget.x, svgTarget.y, 10).attr({
                stroke: "#909090",
                "stroke-width": 1,
                "fill-opacity": .7,
                fill: "#c0c0c0",
                cursor: "move",
                did: this.model.id
            }), paths = utilDisplaySnapCameraBuildPath(svgPos, svgTarget, fov, 100 * this.model.znear), areaPath = paths.area, area = context.path(areaPath).attr({
                stroke: "#4c749c",
                "stroke-width": SNAP_CAMERA_REGION["stroke-width"],
                "fill-opacity": .1,
                fill: SNAP_CAMERA_REGION.color,
                opacity: 1,
                did: this.id
            }), znear = context.path(paths.znear).attr({
                stroke: SNAP_CAMERA_REGION.color,
                "stroke-width": 2,
                cursor: "move",
                did: this.model.id
            });
            this.de = [area, cameraP, target, znear, cameraPosImg, cameraTargetImg, cameraClipPlaneImg, cameraLockImg],
                layer.add(this.de), 0 == isActive && this.de.forEach(function (e) {
                e.attr("display", "none");
            }), this.model.propertyChangedEvent.add(function (propertyName) {
                this.dF = 1;
            }.bind(this));

            if (this.model.camerahasadd == "true") {
                var dis = layer.attr("display");
                if (dis && dis == "none") {
                    layer.attr("display", "block");
                }
            }

            var touchHandler = function () {
                var pos = void 0;
                return function (which, e) {
                    if (e.stopPropagation(), !(e.touches && (__log("camera touch count=" + e.touches.length),
                        e.touches.length > 1))) {
                        var touch = e.touches[0];
                        if (touch) if ("touchstart" == e.type) pos = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY); else if ("touchmove" == e.type) {
                            if (!pos) return;
                            var modelPt = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY);
                            if ("pos" == which) this.model.x = modelPt.x, this.model.y = modelPt.y; else if ("tar" == which) this.model.tx = modelPt.x,
                                this.model.ty = modelPt.y; else if ("both" == which) this.model.x += modelPt.x - pos.x,
                                this.model.y += modelPt.y - pos.y, this.model.tx += modelPt.x - pos.x, this.model.ty += modelPt.y - pos.y,
                                pos = modelPt; else if ("znear" == which) {
                                var expectLen = utilMathLineLength(this.model, modelPt);
                                this.model.znear = Math.max(.2, Math.min(this._maxLength, expectLen));
                            }
                        } else "touchend" == e.type && (pos = void 0);
                    }
                };
            }(), touchBothHandler = touchHandler.bind(this, "both"), touchPositionHandler = touchHandler.bind(this, "pos"), touchTargetHandler = touchHandler.bind(this, "tar"), touchZNearHandler = touchHandler.bind(this, "znear");
            area.drag(function (dx, dy, x, y, e) {
                if (e instanceof Event && !this.model.lock) {
                    e.stopPropagation(), __log("camera drag move.");
                    var modelPt = utilSvgScreenSpaceToModelSpace(this.view, x, y), x = this._modelX + (modelPt.x - this._dragX), y = this._modelY + (modelPt.y - this._dragY), tx = this._modelTX + (modelPt.x - this._dragX), ty = this._modelTY + (modelPt.y - this._dragY);
                    utilActionRun(actionMgr, "setbatch", {
                        x: x,
                        y: y,
                        tx: tx,
                        ty: ty
                    });
                }
            }, function (x, y, e) {
                var modelPt = utilSvgScreenSpaceToModelSpace(this.view, x, y);
                this._dragX = modelPt.x, this._dragY = modelPt.y, this._modelX = this.model.x, this._modelY = this.model.y,
                    this._modelTX = this.model.tx, this._modelTY = this.model.ty, utilActionBegin(actionMgr, "SetGeneralProp", this.model);
            }, function (e) {
                utilActionEnd(actionMgr, "SetGeneralProp");
            }, this, this, this).touchstart(touchBothHandler).touchmove(touchBothHandler).touchend(touchBothHandler),
                cameraPosImg.drag(function (dx, dy, x, y, e) {
                    if (e.stopPropagation(), e instanceof Event && !this.model.lock) {
                        var modelPt = utilSvgScreenSpaceToModelSpace(this.view, x, y);
                        utilActionRun(actionMgr, "setbatch", {
                            x: modelPt.x,
                            y: modelPt.y
                        });
                    }
                }, function (x, y, e) {
                    utilActionBegin(actionMgr, "SetGeneralProp", this.model);
                }, function (e) {
                    utilActionEnd(actionMgr, "SetGeneralProp");
                }, this, this, this).touchstart(touchPositionHandler).touchmove(touchPositionHandler).touchend(touchPositionHandler),
                cameraTargetImg.drag(function (dx, dy, x, y, e) {
                    if (e.stopPropagation(), e instanceof Event && !this.model.lock) {
                        var modelPt = utilSvgScreenSpaceToModelSpace(this.view, x, y);
                        utilActionRun(actionMgr, "setbatch", {
                            tx: modelPt.x,
                            ty: modelPt.y
                        });
                    }
                }, function (x, y, e) {
                    utilActionBegin(actionMgr, "SetGeneralProp", this.model);
                }, function (e) {
                    utilActionEnd(actionMgr, "SetGeneralProp");
                }, this, this, this).touchstart(touchTargetHandler).touchmove(touchTargetHandler).touchend(touchTargetHandler);
            var zNearDragMove = function (dx, dy, x, y, e) {
                if (e.stopPropagation(), e instanceof Event && !this.model.lock) {
                    var modelPt = utilSvgScreenSpaceToModelSpace(this.view, x, y), expectLen = utilMathLineLength(this.model, modelPt);
                    this.model.znear = Math.max(.2, Math.min(this._maxLength, expectLen));
                }
            }.bind(this), zNearDragDown = function (x, y, e) {
                this._maxLength = utilMathLineLength(this.model, {
                    x: this.model.tx,
                    y: this.model.ty
                });
            }.bind(this), zNearDragUp = function (e) {
                delete this._maxLength;
            }.bind(this);
            znear.drag(zNearDragMove, zNearDragDown, zNearDragUp, this, this, this).touchstart(touchZNearHandler).touchmove(touchZNearHandler).touchend(touchZNearHandler),
                cameraClipPlaneImg.drag(zNearDragMove, zNearDragDown, zNearDragUp, this, this, this).touchstart(touchZNearHandler).touchmove(touchZNearHandler).touchend(touchZNearHandler);
        }
    },
    update: function () {
        var layer = this.view.layers[this.model.type]
        layer.add(this.de);
         //The camera was locked while the property's value is true
        if (this.model.lock) {
            if (this.model.active == 0) {
                this.de.forEach(function (e) {
                    e.attr("display", "none");
                });
            } else {
                this.de.forEach(function (e) {
                    e.attr("display", "block");
                });
            }
            var layer = this.view.layers['LOCKCAMERA'];
            layer.add(this.de);
            return;
        }
        var area = this.de[0], cameraP = this.de[1], target = this.de[2], znear = this.de[3], cameraPosImg = this.de[4], cameraTargetImg = this.de[5], cameraClipPlaneImg = this.de[6], cameraLockImg = this.de[7], isActive = this.model.active;
        if (0 == isActive) return void this.de.forEach(function (e) {
            e.attr("display", "none");
        });
        this.de.forEach(function (e) {
            e.attr("display", "block");
            // Hide the lock image in initial time
            cameraLockImg.attr("display", "none");
        });


        var svgP = {
            x: 100 * this.model.x,
            y: 100 * -this.model.y
        }, svgT = {
            x: 100 * this.model.tx,
            y: 100 * -this.model.ty
        };
        cameraP.attr("cx") == svgP.x && cameraP.attr("cy") == svgP.y || cameraP.attr({
            cx: svgP.x,
            cy: svgP.y
        }), target.attr("cx") == svgT.x && target.attr("cy") == svgT.y || target.attr({
            cx: svgT.x,
            cy: svgT.y
        });
        var paths = utilDisplaySnapCameraBuildPath(svgP, svgT, this.model.hfov, 100 * this.model.znear);
        area.attr("path") != paths.area && area.attr({
            path: paths.area
        });
        var rot = utilMathGetAngleHorizontaleCCW(svgP, svgT), width = cameraPosImg.attr("width"), height = cameraPosImg.attr("height");
        cameraPosImg.attr({
            x: svgP.x - width / 2,
            y: svgP.y - height / 2
        }).transform("r" + rot), width = cameraTargetImg.attr("width"), height = cameraTargetImg.attr("height"),
            cameraTargetImg.attr({
                x: svgT.x - width / 2,
                y: svgT.y - height / 2
            }).transform("r" + rot), znear.attr("path") != paths.znear && znear.attr({
            path: paths.znear
        }), width = cameraLockImg.attr("width"), height = cameraLockImg.attr("height"),
            cameraLockImg.attr({
                x: svgP.x - width / 2,
                y: svgP.y - height / 2
            }),
            width = cameraClipPlaneImg.attr("width"), height = cameraClipPlaneImg.attr("height"),
            cameraClipPlaneImg.attr({
                x: paths.znearPos.x - width / 2,
                y: paths.znearPos.y - height / 2
            }).transform("r" + rot);
    },
    destroy: function () {
        this.de.forEach(function (item) {
            item.remove();
        });
    }
});

classInherit(DisplaySnapCurve, DisplayObject), utilExtend(DisplaySnapCurve.prototype, {
    create: function () {
        classBase(this, "create");
        this.view.context, this.view.layers[this.model.type], this.view.app.actionMgr;
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.remove();
        });
    }
}), classInherit(DisplaySnapProduct, DisplayObject), utilExtend(DisplaySnapProduct.prototype, {
    createDisplayInternal: function () {
        var context = this.view.context, url = this.model.getUrl("top"), bound = utilDisplaySnapProductBuildBound(this.model);
        return context.image(url, bound.left, bound.top, bound.width, bound.height).attr({
            stroke: "#909090",
            "stroke-width": 0,
            "fill-opacity": 1,
            cursor: "move"
        });
    },
    create: function () {
        classBase(this, "create");
        var actionMgr = this.view.app.actionMgr;
        var pickMgr = this.view.app.pickMgr;
        var model = this.model;
        var factor = 100;
        this.showDe = {arrow: [], label: []};
        var bound = utilDisplaySnapProductBuildBound(model);
        var subCategory = model.meta.subcategory ? model.meta.subcategory.toUpperCase() : "SEAT";
        var context = this.view.context;
        model.isdelete = 0;
        if (context) {
            var layer = this.view.layers[subCategory];
            var layer2 = this.view.layers['PRODUCT_MARK'];//物体标注信息层
            if (!layer) {
                var error = "Some error happen when creating this product:<" + model.pid + ">, this product is in layer <" + subCategory + ">,  but 2d does not have thislayer:";
                return void __assert(!1, error);
            }
            this.model.textpos = [];//标注线输入框坐标
            0 == this.de.length;
            var bounds = this.de[0] || context.rect(bound.left, bound.top, bound.width, bound.height).attr({
                    stroke: "#49fffe",
                    "stroke-width": 0,
                    "fill-opacity": .01,
                    did: this.id
                })
            var img = this.de[1] || this.createDisplayInternal();
            var rotLine = context.line().attr({
                stroke: "#49fffe",
                "stroke-width": 2,
                display: "none"
            });
            var rotHandle = context.circle().attr({
                stroke: "#49fffe",
                fill: "#49fffe",
                "stroke-width": 0,
                "fill-opacity": .8,
                display: "none",
                cursor: "move"
            });
            var productRotateImg = context.image(SNAP_Product_Rotate_IMG.url, -SNAP_Product_Rotate_IMG.width / 2, -SNAP_Product_Rotate_IMG.height / 2, SNAP_Product_Rotate_IMG.width, SNAP_Product_Rotate_IMG.height).attr({
                stroke: "#909090",
                "stroke-width": 0,
                "fill-opacity": 1,
                cursor: "move",
                display: "none",
                did: this.model.id
            })
            0 == this.de.length && this.de.push(bounds, img, rotLine, rotHandle,productRotateImg), layer.add([this.de[0], this.de[1]]),
                layer2.add([this.de[2], this.de[3],this.de[4]]),
                model.propertyChangedEvent.add(function (propertyName) {
                    "x" == propertyName || "y" == propertyName || "sx" == propertyName || "sy" == propertyName || "flip" == propertyName ? this.dF |= 3 : "flag" == propertyName ? this.dF |= 2 : "rot" == propertyName && (this.dF |= 3);
                }.bind(this));
            this._zoomChangeRot = function () {
                rotLine.attr("display", "none");
                rotHandle.attr("display", "none");
                productRotateImg.attr("display", "none")
            }.bind(this);
            this.view.zoomChangedEvent.add(this._zoomChangeRot);
            var touchHandler = function (e, a0, a1, a2) {
                if (e.stopPropagation(), "touchstart" == e.type) this.ox = this.model.x, this.oy = this.model.y; else if ("touchmove" == e.type) {
                    var touch = e.touches[0];
                    if (!touch || 1 != e.touches.length) return;
                    var modelPt = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY);
                    this.model.x = modelPt.x, this.model.y = modelPt.y;
                } else "touchend" == e.type;
            }.bind(this);
            img.click(function (e, screen_x, screen_y) {
                //utilPickMgrPick(pickMgr, model);
            }).mouseover(function (e) {
            }).mouseout(function (e) {
            }).drag(function (dx, dy, x, y, e) {
                if (e.stopPropagation(), e instanceof Event && 1 != e.button) {
                    var modelOffset = utilSvgVectorScreenSpaceToModelSpace(this.view, dx, dy);
                    utilActionRun(actionMgr, e.type + "2d", e, {
                        x: this.ox + modelOffset.x,
                        y: this.oy + modelOffset.y
                    }, modelOffset);
                }
            }, function (x, y, e) {
                if (e.stopPropagation(), 1 != e.button) {
                    var model = this.model;
                    if (this.ox = model.x, this.oy = model.y, !actionMgr.current) {
                        var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveProduct.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                        utilActionBegin(actionMgr, actionType, actionModel, {
                            shiftKey: e.shiftKey
                        });
                    }
                }
            }, function (e) {
                e.stopPropagation(), 1 != e.button && utilActionEnd(actionMgr);
            }, this, this, this).touchstart(touchHandler).touchmove(touchHandler).touchend(touchHandler);

            var touchRotHandler = function (e) {
                e.stopPropagation();
                var touch = e.touches[0];
                "touchstart" == e.type ? dragDown.bind(this)(touch.pageX, touch.pageY, e) : "touchmove" == e.type ? dragMove.bind(this)(0, 0, touch.pageX, touch.pageY, e) : "touchend" == e.type && dragUp.bind(this)(e);
            }.bind(this), dragMove = function (dx, dy, x, y, e) {
                if (e.stopPropagation(), 1 != e.button) {
                    var angleDelta = utilMathLinelineCCWAngle(this.orig, this.handlePos, {
                        x: x,
                        y: y
                    }), angle = (this.origRot - angleDelta + 360) % 360, rot = utilMathRotationSnap(angle);
                    __log("angle  = " + angle), utilActionRun(actionMgr, "setbatch", {
                        rot: rot
                    });
                    var meta = model.meta, height = (meta.xlen * model.sx, meta.ylen * model.sy), lineBeginModelPt = utilMathRotatePointCW(model, {
                        x: model.x,
                        y: model.y - height / 2
                    }, model.rot), lineEndModelPt = utilSvgScreenSpaceToModelSpace(this.view, x, y);
                    rotLine.attr({
                        x1: lineBeginModelPt.x * factor,
                        y1: -lineBeginModelPt.y * factor,
                        x2: lineEndModelPt.x * factor,
                        y2: -lineEndModelPt.y * factor
                    }), rotHandle.attr({
                        cx: lineEndModelPt.x * factor,
                        cy: -lineEndModelPt.y * factor
                    }),productRotateImg.attr({
                        x: lineEndModelPt.x * factor - productRotateImg.attr('width')/2,
                        y: -lineEndModelPt.y * factor - productRotateImg.attr('width')/2
                    });
                }
            }, dragDown = function (x, y, e) {
                e.stopPropagation(), this.orig = utilSvgModelSpaceToScreenSpace(this.view, this.model.x, this.model.y),
                    this.origRot = this.model.rot, this.handlePos = {
                    x: x,
                    y: y
                }, utilActionBegin(actionMgr, "SetGeneralProp", this.model);
            }, dragUp = function (e) {
                e.stopPropagation(), utilActionEnd(actionMgr, "SetGeneralProp", this.model);
            };
            //rotHandle.drag(dragMove, dragDown, dragUp, this, this, this).touchstart(touchRotHandler).touchmove(touchRotHandler).touchend(touchRotHandler);
            productRotateImg.drag(dragMove, dragDown, dragUp, this, this, this).touchstart(touchRotHandler).touchmove(touchRotHandler).touchend(touchRotHandler);
        }
    },
    update: function () {
        if (!(this.de.length < 3)) {
            var bounds = this.de[0], img = this.de[1], rotLine = this.de[2], rotHandle = this.de[3],productRotateImg=this.de[4], model = this.model, view = this.view, factor = 100;
            (this.showDe.label && this.showDe.label.length > 0) ? (this.showDe.label[0].attr("display", "none"), this.showDe.label[1].attr("display", "none"), this.showDe.label[2].attr("display", "none"), this.showDe.label[3].attr("display", "none")) : "";
            (this.showDe.arrow && this.showDe.arrow.length > 0) ? (
                this.showDe.arrow.forEach(function (a) {
                    a.attr("display", "none")
                })) : "";
            this.de.forEach(function (e) {
                e.attr("display", "none")
            })
            var isGroup=model.group?utilModelIsFlagOff(model.group, GROUPFLAG_OPENED):false;
            this.model.textpos = []
            if (0 != (2 & this.dF)) {
                var picked = utilPickMgrIsPicked(this.view.app.pickMgr, model);
                var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
                    return e;
                });
                if (void 0 != picked) {
                    bounds.attr({
                        "stroke-width": isGroup?.1:3
                    });
                    var meta = model.meta, height = (meta.xlen * model.sx, meta.ylen * model.sy), width = meta.xlen * model.sx, lineBeginModelPt = utilMathRotatePointCW(model, {
                        x: model.x,
                        y: model.y - height / 2
                    }, model.rot), lineScreenLength = 100, lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, lineScreenLength * Math.sin(utilMathToRadius(model.rot)), lineScreenLength * Math.cos(utilMathToRadius(model.rot))), lineEndModelPt = {
                        x: lineEndModelPtDelta.x + lineBeginModelPt.x,
                        y: lineEndModelPtDelta.y + lineBeginModelPt.y
                    };
                    var productRotateImgWidth=SNAP_Product_Rotate_IMG.width*(utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7,
                        productRotateImgHeight=SNAP_Product_Rotate_IMG.width*(utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7
                    rotLine.attr({
                        display:isGroup?"none":"block",
                        x1: lineBeginModelPt.x * factor,
                        y1: -lineBeginModelPt.y * factor,
                        x2: lineEndModelPt.x * factor,
                        y2: -lineEndModelPt.y * factor
                    }), rotHandle.attr({
                        display:isGroup?"none":"none",
                        cx: lineEndModelPt.x * factor,
                        cy: -lineEndModelPt.y * factor,
                        r: utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor
                    }),productRotateImg.attr({
                        display:isGroup?"none":"block",
                        x: lineEndModelPt.x * factor - productRotateImgWidth/2,
                        y: -lineEndModelPt.y * factor - productRotateImgHeight/2,
                        width:productRotateImgWidth,
                        height:productRotateImgHeight
                    })
                    // 物体标距线,添加物体箭头辅助线 add by hcw
                    utilModelIsFlagOn(model, MODELFLAG_HIDDEN) ?"":(createLabelLine(this),createArrowLine(this));

                } else bounds.attr({
                    "stroke-width": 0
                }), rotLine.attr("display", "none"), rotHandle.attr("display", "none"),productRotateImg.attr("display","none");
                utilModelIsFlagOn(model, MODELFLAG_HIDDEN) && (utilPickMgrUnpick(this.view.app.pickMgr, model),
                    rotLine.attr("display", "none"), rotHandle.attr("display", "none"), productRotateImg.attr("display","none"),application.laberFrame()), bounds.attr("display", utilModelIsFlagOn(model, MODELFLAG_HIDDEN) ? "none" : "block"),
                    img.attr("display",utilModelIsFlagOn(model, MODELFLAG_HIDDEN) ? "none" : "block") , !pickObjs_product[0] && (application.laberFrame());
            }
            if (0 != (1 & this.dF)) {
                var bound = utilDisplaySnapProductBuildBound(this.model);
                bounds.attr({
                    x: bound.left,
                    y: bound.top,
                    width: bound.width,
                    height: bound.height
                }).transform("r" + -this.model.rot);
                img.attr({
                    x: bound.left,
                    y: bound.top,
                    width: bound.width,
                    height: bound.height
                });

                if (this.model.flip) {
                    var m = new Snap.Matrix();
                    m.scale(-1, 1, bound.left + bound.width / 2, bound.top + bound.height / 2);
                    m.rotate(this.model.rot, bound.left + bound.width / 2, bound.top + bound.height / 2);
                    img.transform(m);
                } else {
                    img.transform("r" + -this.model.rot);
                }
            }
        }
    },
    destroy: function () {
        this.model.isdelete = 1;
        this.de.forEach(function (ele) {
            ele.remove();
        });
        if (this.showDe.arrow) {
            this.showDe.arrow.forEach(function (ele) {
                ele.remove();
            });
        }
        this.showDe.label.forEach(function (ele) {
            ele.remove();
        });
        application.laberFrame()//添加物体标注线输入框显示

        if (this._zoomChangedRot) {
            this.view.zoomChangedEvent.remove(this._zoomChangedRot);
            this._zoomChangedRot = null;
        }
        destroyArrowLine(this);
    }
});

classInherit(DisplaySnapCube, DisplaySnapProduct);

var SNAP_CUBE_DISPLAY_COLOR = {};

SNAP_CUBE_DISPLAY_COLOR[Pillar.prototype.type] = ["#333333", 1], SNAP_CUBE_DISPLAY_COLOR[Beam.prototype.type] = ["#fafafa", .7],
    SNAP_CUBE_DISPLAY_COLOR[Basement.prototype.type] = ["#cccccc", 1], utilExtend(DisplaySnapCube.prototype, {
    createDisplayInternal: function () {
        var context = this.view.context, model = this.model, bound = utilDisplaySnapProductBuildBound(this.model);
        return context.rect(bound.left, bound.top, bound.width, bound.height).attr({
            fill: SNAP_CUBE_DISPLAY_COLOR[model.type][0],
            "fill-opacity": SNAP_CUBE_DISPLAY_COLOR[model.type][1],
            stroke: "#202020",
            "stroke-width": 1,
            "stroke-opacity": 1
        });
    },
    create: function () {
        classBase(this, "create");
        this.view.app.actionMgr, this.view.app.pickMgr, this.model;
    },
    update: function () {
        classBase(this, "update");
        this.de[0], this.de[1], this.de[2], this.de[3], this.model, this.view;
    },
    destroy: function () {
        classBase(this, "destroy");
    }
}), classInherit(DisplaySnapVRHotspot, DisplaySnapProduct);

var SNAP_VRHOTSPOT_IMG_2D = {
    url: "asset/imgSnap/hotspot_2d.png",
    width: 99,
    height: 99
};

utilExtend(DisplaySnapVRHotspot.prototype, {
    createDisplayInternal: function () {
        var context = this.view.context, model = this.model, bound = utilDisplaySnapProductBuildBound(model);
        return context.image(SNAP_VRHOTSPOT_IMG_2D.url, bound.left, bound.top, bound.width, bound.height).attr({
            stroke: "#909090",
            "stroke-width": 0,
            "fill-opacity": 1,
            cursor: "move"
        });
    },
    create: function () {
        classBase(this, "create");
    },
    update: function () {
        classBase(this, "update");
    },
    destroy: function () {
        classBase(this, "destroy");
    }
}), classInherit(DisplaySnapAnnotation, DisplayObject);

var SNAP_ANNOTATION_EMPTY_TEXT = "右击添加文字";

utilExtend(DisplaySnapAnnotation.prototype, {
    create: function () {
        classBase(this, "create");
        var view = this.view, context = (this.view.app.actionMgr, this.view.app.pickMgr,
            this.view.context), model = this.model, factor = 100, pos = context.circle(100 * this.model.x, -100 * this.model.y, 10).attr({
            fill: "white",
            stroke: "deepskyblue",
            "stroke-width": 2,
            "stroke-opacity": 1,
            "stroke-linejoin": "round",
            opacity: 1,
            cursor: "move",
            "display": model.texttype == 2 ? "none" : "block",
        }).drag(function (dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button) {
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
                this.model.x = this._modelCenter.x + modelOffset.x, this.model.y = this._modelCenter.y + modelOffset.y;
            }
        }, function (x, y, e) {
            e.stopPropagation(), 1 != e.button && (this._modelCenter = {
                x: this.model.x,
                y: this.model.y
            });
        }, function (e) {
            e.stopPropagation(), 1 != e.button && delete this._modelCenter;
        }, this, this, this), line = context.line(100 * this.model.x, -100 * this.model.y, this.model.tx * factor, -100 * this.model.ty).attr({
            stroke: "deepskyblue",
            "stroke-width": 2,
            "display": model.texttype == 2 ? "none" : "block"
        }), text = context.text(this.model.tx * factor, -100 * this.model.ty, SNAP_ANNOTATION_EMPTY_TEXT).attr({
            "font-size": model.fontsize,
            fill: model.textcolor,
            "font-family": "Calibri,Arial,Helvetica,sans-serif",
            cursor: "move"
        }).drag(function (dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button) {
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
                this.model.tx = this._modelCenter.x + modelOffset.x, this.model.ty = this._modelCenter.y + modelOffset.y;
            }
        }, function (x, y, e) {
            e.stopPropagation(), 1 != e.button && (this._modelCenter = {
                x: this.model.tx,
                y: this.model.ty
            });
        }, function (e) {
            e.stopPropagation(), 1 != e.button && delete this._modelCenter;
        }, this, this, this), textBB = text.getBBox(), textBound = context.rect(textBB.x, textBB.y, textBB.width, textBB.height).attr({
            stroke: "deepskyblue",
            "stroke-width": model.texttype == 2 ? 0 : 2,
            "fill-opacity": model.texttype == 2 ? .01 : 1,
            fill: "white",
            did: this.id
        });
        this.de = [line, pos, textBound, text];
        var layer = this.view.layers[this.model.type];
        layer.add(this.de), this.model.propertyChangedEvent.add(function (propertyName) {
            "flag" == propertyName ? this.dF |= 1 : "x" == propertyName || "y" == propertyName ? this.dF |= 2 : "tx" == propertyName || "ty" == propertyName ? this.dF |= 4 : this.dF |= 8;
        }.bind(this));
    },
    update: function () {
        var line = this.de[0], pos = this.de[1], textBound = this.de[2], text = this.de[3], model = this.model;
        this.view;
        var textattr = {"stroke": utilModelIsFlagOn(model, MODELFLAG_PICKED) ? "darkorange" : "deepskyblue"}
        if (model.texttype == 2)textattr = {
            "stroke": utilModelIsFlagOn(model, MODELFLAG_PICKED) ? "darkorange" : "deepskyblue",
            "stroke-width": utilModelIsFlagOn(model, MODELFLAG_PICKED) ? 1 : 0
        }
        if (0 != (1 & this.dF) && textBound.attr(textattr),
            0 != (2 & this.dF) && (pos.attr({
                cx: 100 * model.x,
                cy: -100 * model.y
            }), line.attr({
                x1: 100 * model.x,
                y1: -100 * model.y
            })), 0 != (4 & this.dF)) {
            if (line) {
                line.attr({
                    x2: 100 * model.tx,
                    y2: -100 * model.ty
                }),
                    text.attr({
                        x: 100 * model.tx,
                        y: -100 * model.ty
                    });
            } else {
                text.attr({
                    x: 100 * (model.tx - 0.5),
                    y: -100 * (model.ty + 0.5)
                });
            }
            var textBB = text.getBBox();
            textBound.attr({
                x: textBB.x,
                y: textBB.y
            });
        }
        if (0 != (8 & this.dF)) {
            var textall = [], textshow = model.text;
            if (textshow) {
                textall = model.text.split('\n');
                textshow = textall.length > 1 ? textall : model.text;
            }
            text.attr({
                text: textshow || SNAP_ANNOTATION_EMPTY_TEXT,
                "font-size": model.fontsize,
                fill: model.textcolor
            });
            if (textall.length > 1) {
                var widthlen = 0;
                text.node.childNodes.forEach(function (node, i) {
                    if (node.textContent == '') {
                        node.innerHTML = '&nbsp;';
                    } else {
                        node.innerHTML = node.textContent.replace(/\s/g, '&nbsp;')
                    }
                    if (i > 0) {
                        widthlen = text.node.childNodes[i - 1].getComputedTextLength()
                        text.node.childNodes[i].setAttribute('dx', -widthlen)
                        text.node.childNodes[i].setAttribute('dy', model.fontsize)
                    }
                })
            } else {
                text.node.innerHTML = text.node.textContent.replace(/\s/g, '&nbsp;')
            }
            var textBB = text.getBBox();
            textBound.attr({
                width: textBB.width,
                height: textBB.height
            });
        }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.remove();
        });
    }
}), classInherit(DisplaySnapWalkThrough, DisplayObject), utilExtend(DisplaySnapWalkThrough.prototype, {
    create: function () {
        function getModelPoint(type, model) {
            switch (type) {
                case "pos":
                    return {
                        x: model.x,
                        y: model.y
                    };

                case "tar":
                    return {
                        x: model.tx,
                        y: model.ty
                    };

                case "cp1pos":
                    return {
                        x: model.cp1x,
                        y: model.cp1y
                    };

                case "cp1tar":
                    return {
                        x: model.cp1tx,
                        y: model.cp1ty
                    };

                case "cp2pos":
                    return {
                        x: model.cp2x,
                        y: model.cp2y
                    };

                case "cp2tar":
                    return {
                        x: model.cp2tx,
                        y: model.cp2ty
                    };
            }
        }

        function setModelPoint(type, model, pt) {
            "pos" == type ? (model.x = pt.x, model.y = pt.y) : "tar" == type ? (model.tx = pt.x,
                model.ty = pt.y) : "cp1pos" == type ? (model.cp1x = pt.x, model.cp1y = pt.y) : "cp1tar" == type ? (model.cp1tx = pt.x,
                model.cp1ty = pt.y) : "cp2pos" == type ? (model.cp2x = pt.x, model.cp2y = pt.y) : "cp2tar" == type && (model.cp2tx = pt.x,
                model.cp2ty = pt.y);
        }

        classBase(this, "create");
        var view = this.view, context = (this.view.doc.floorplan, this.view.app.actionMgr,
            this.view.app.pickMgr, this.view.context), layer = (this.model, this.view.layers[this.model.type]), self = this, posPath = context.path().attr({
            fill: "none",
            stroke: "royalblue",
            "stroke-width": 3
        }), tarPath = context.path().attr({
            fill: "none",
            stroke: "orange",
            "stroke-width": 3
        });
        this.de = [posPath, tarPath];
        for (var dragMove = function (dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button) {
                var model = this.model[this.index];
                if (model) {
                    var modelPt = utilSvgScreenSpaceToModelSpace(view, x, y);
                    setModelPoint(this.type, model, modelPt), model.toModel();
                }
            }
        }, dragDown = function (x, y, e) {
            var model = this.model[this.index];
            if (e.stopPropagation(), model) {
                var modelPt = getModelPoint(this.type, model);
                this.orig = utilSvgModelSpaceToScreenSpace(view, modelPt.x, modelPt.y);
            } else self.dF |= 1 << this.index + 1;
        }, dragUp = function (e) {
            e.stopPropagation(), delete this.orig;
        }, i = 0; i < ANIMATION_MAX_KEYS; i++) {
            var posThis = {
                model: this.model,
                index: i,
                type: "pos"
            }, tarThis = {
                model: this.model,
                index: i,
                type: "tar"
            }, cp1posThis = {
                model: this.model,
                index: i,
                type: "cp1pos"
            }, cp1tarThis = {
                model: this.model,
                index: i,
                type: "cp1tar"
            }, cp2posThis = {
                model: this.model,
                index: i,
                type: "cp2pos"
            }, cp2tarThis = {
                model: this.model,
                index: i,
                type: "cp2tar"
            }, cp1posline = context.line().attr({
                stroke: "green",
                "stroke-width": 2
            }), cp1pos = context.rect().attr({
                fill: "green",
                stroke: "darkgray",
                "stroke-width": 1,
                cursor: "move"
            }).drag(dragMove.bind(cp1posThis), dragDown.bind(cp1posThis), dragUp.bind(cp1posThis)), cp1tarline = context.line().attr({
                stroke: "green",
                "stroke-width": 2
            }), cp1tar = context.rect().attr({
                fill: "green",
                stroke: "darkgray",
                "stroke-width": 1,
                cursor: "move"
            }).drag(dragMove.bind(cp1tarThis), dragDown.bind(cp1tarThis), dragUp.bind(cp1tarThis)), cp2posline = context.line().attr({
                stroke: "darkgreen",
                "stroke-width": 2
            }), cp2pos = context.rect().attr({
                fill: "darkgreen",
                stroke: "darkgray",
                "stroke-width": 1,
                cursor: "move"
            }).drag(dragMove.bind(cp2posThis), dragDown.bind(cp2posThis), dragUp.bind(cp2posThis)), cp2tarline = context.line().attr({
                stroke: "darkgreen",
                "stroke-width": 2
            }), cp2tar = context.rect().attr({
                fill: "darkgreen",
                stroke: "darkgray",
                "stroke-width": 1,
                cursor: "move"
            }).drag(dragMove.bind(cp2tarThis), dragDown.bind(cp2tarThis), dragUp.bind(cp2tarThis)), pos = context.rect().attr({
                fill: "blue",
                stroke: "darkgray",
                "stroke-width": 1,
                cursor: "move"
            }).drag(dragMove.bind(posThis), dragDown.bind(posThis), dragUp.bind(posThis)), tar = context.rect().attr({
                fill: "darkorange",
                stroke: "darkgray",
                "stroke-width": 1,
                cursor: "move"
            }).drag(dragMove.bind(tarThis), dragDown.bind(tarThis), dragUp.bind(tarThis));
            this.de.push(cp1posline, cp1tarline, cp2posline, cp2tarline, cp1pos, cp1tar, cp2pos, cp2tar, pos, tar);
        }
        layer.add(this.de), this.model.linksChangedEvent.add(function (propertyName) {
            __log("pName=" + propertyName);
        }.bind(this)), this.model.propertyChangedEvent.add(function (propertyName) {
            if ("flag" == propertyName) this.dF |= 1; else if ("path" == propertyName) this.dF |= 1048575; else {
                var keyIndex = parseInt(propertyName);
                isNaN(keyIndex) ? __log("WalkThrough: changed property:" + propertyName) : (this.dF |= 1 << keyIndex + 1,
                    utilModelChangeFlag(this.model, 1 << 24));
            }
        }.bind(this)), this.model.linkPropertyChangedEvent.add(function (property, name, oldValue, newValue) {
            if (property instanceof WalkKey) for (var i = 0; i < ANIMATION_MAX_KEYS; i++) {
                var key = this.model[i];
                key && key.id == property.id && (this.dF |= 1 << i + 1);
            }
        }.bind(this));
    },
    update: function () {
        var size = (this.model, this.view, .2), posPath = this.de[0], tarPath = this.de[1];
        if (0 != (1 & this.dF)) for (var i = 0, len = this.de.length; len > i; ++i) this.de[i].attr({
            display: utilModelIsFlagOn(MODELFLAG_HIDDEN) ? "none" : "block"
        });
        for (var keyChanged = !1, isBezierC = "bezierC" == this.model.path, noneDisplay = {
            display: "none"
        }, i = 0; i < ANIMATION_MAX_KEYS; i++) if (0 != (this.dF & 1 << i + 1)) {
            var key = this.model[i], beginIdx = 2 + 10 * i, cp1posline = this.de[beginIdx], cp1tarline = this.de[beginIdx + 1], cp2posline = this.de[beginIdx + 2], cp2tarline = this.de[beginIdx + 3], cp1pos = this.de[beginIdx + 4], cp1tar = this.de[beginIdx + 5], cp2pos = this.de[beginIdx + 6], cp2tar = this.de[beginIdx + 7], pos = this.de[beginIdx + 8], tar = this.de[beginIdx + 9];
            key && !isNaN(key.x) ? (isBezierC ? (cp1posline.attr({
                x1: 100 * key.cp1x,
                y1: -100 * key.cp1y,
                x2: 100 * key.x,
                y2: -100 * key.y,
                display: "block"
            }), cp1pos.attr({
                x: 100 * (key.cp1x - size / 4),
                y: -100 * (key.cp1y + size / 4),
                width: 50 * size,
                height: 50 * size,
                display: "block"
            }), cp2posline.attr({
                x1: 100 * key.cp2x,
                y1: -100 * key.cp2y,
                x2: 100 * key.x,
                y2: -100 * key.y,
                display: "block"
            }), cp2pos.attr({
                x: 100 * (key.cp2x - size / 4),
                y: -100 * (key.cp2y + size / 4),
                width: 50 * size,
                height: 50 * size,
                display: "block"
            }), cp1tarline.attr({
                x1: 100 * key.cp1tx,
                y1: -100 * key.cp1ty,
                x2: 100 * key.tx,
                y2: -100 * key.ty,
                display: "block"
            }), cp1tar.attr({
                x: 100 * (key.cp1tx - size / 4),
                y: -100 * (key.cp1ty + size / 4),
                width: 50 * size,
                height: 50 * size,
                display: "block"
            }), cp2tarline.attr({
                x1: 100 * key.cp2tx,
                y1: -100 * key.cp2ty,
                x2: 100 * key.tx,
                y2: -100 * key.ty,
                display: "block"
            }), cp2tar.attr({
                x: 100 * (key.cp2tx - size / 4),
                y: -100 * (key.cp2ty + size / 4),
                width: 50 * size,
                height: 50 * size,
                display: "block"
            })) : (cp1posline.attr(noneDisplay), cp1tarline.attr(noneDisplay), cp2posline.attr(noneDisplay),
                cp2tarline.attr(noneDisplay), cp1pos.attr(noneDisplay), cp1tar.attr(noneDisplay),
                cp2pos.attr(noneDisplay), cp2tar.attr(noneDisplay)), pos.attr({
                x: 100 * (key.x - size / 2),
                y: -100 * (key.y + size / 2),
                width: 100 * size,
                height: 100 * size,
                display: "block"
            }), tar.attr({
                x: 100 * (key.tx - size / 2),
                y: -100 * (key.ty + size / 2),
                width: 100 * size,
                height: 100 * size,
                display: "block"
            })) : (pos.attr(noneDisplay), tar.attr(noneDisplay), cp1posline.attr(noneDisplay),
                cp1tarline.attr(noneDisplay), cp2posline.attr(noneDisplay), cp2tarline.attr(noneDisplay),
                cp1pos.attr(noneDisplay), cp1tar.attr(noneDisplay), cp2pos.attr(noneDisplay), cp2tar.attr(noneDisplay)),
                keyChanged = !0;
        }
        if (keyChanged || 0 != (32768 & this.dF)) {
            var posPathStr = utilSnapWalkThroughBuildPath(this.model, !0);
            posPath.attr({
                path: posPathStr,
                display: "block"
            });
            var tarPathStr = utilSnapWalkThroughBuildPath(this.model, !1);
            tarPath.attr({
                path: tarPathStr,
                display: "block"
            });
        }
    },
    destroy: function () {
        classBase(this, "destroy"), this.de.forEach(function (ele) {
            ele.remove();
        });
    }
}), classInherit(DisplaySnapGroup, DisplayObject), utilExtend(DisplaySnapGroup.prototype, {
    create: function () {
        classBase(this, "create");
        var layer = this.view.layers[Group.prototype.type];
        this.layer = layer;
        var actionMgr = this.view.app.actionMgr,factor=100;
        this.showDe = {arrow: [], label: []};
        this.model.textpos = [];//标注线输入框坐标
        var context = this.view.context, model = this.model, svgbound = context.path().attr({
            fill: "none",
            stroke: utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "orange" : "hotpink",
            opacity: 1,
            fid:model.id,
            "stroke-width": 3,
            "stroke-opacity": 1,
            "stroke-linejoin": "round",
            "stroke-dasharray": model.id == GROUP_TEMP.id ? "8,6" : void 0
        }), svgCenter = context.circle(null, null, 5).attr({
            display: "none",
            fill: utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "orange" : "hotpink",
            opacity: 1,
        });
        var box=context.rect().attr({
            stroke:"#ffa500",
            "stroke-width": 3,
            fill: "none",
            opacity: 1
        })
        var rotLine = context.line().attr({
            stroke: "#ffa500",
            "stroke-width": 2,
            display: "none"
        });
        var productRotateImg = context.image(SNAP_Group_Rotate_IMG.url, -SNAP_Group_Rotate_IMG.width / 2, -SNAP_Group_Rotate_IMG.height / 2, SNAP_Group_Rotate_IMG.width, SNAP_Group_Rotate_IMG.height).attr({
            stroke: "#909090",
            "stroke-width": 0,
            "fill-opacity": 1,
            cursor: "move",
            display: "none",
        });
        this._GroupZoomChangeRot = function () {
            this.dF |= 1
            this.update()
        }.bind(this);
        this.view.zoomChangedEvent.add(this._GroupZoomChangeRot);
        var touchRotHandler = function (e) {
            e.stopPropagation();
            var touch = e.touches[0];
            "touchstart" == e.type ? dragDown.bind(this)(touch.pageX, touch.pageY, e) : "touchmove" == e.type ? dragMove.bind(this)(0, 0, touch.pageX, touch.pageY, e) : "touchend" == e.type && dragUp.bind(this)(e);
        }.bind(this), dragMove = function (dx, dy, x, y, e) {
            var actionMgr = this.view.app.actionMgr,factor=100;
            if (e.stopPropagation(), 1 != e.button) {
                var angleDelta = utilMathLinelineCCWAngle(this.orig, this.handlePos, {
                    x: x,
                    y: y
                }), angle = (this.origRot - angleDelta + 360) % 360, rot = utilMathRotationSnap(angle);
                var newRot=rot-model.rot;
                utilActionRun(actionMgr,"contextmenu",e,newRot,rot);
                var  height =model.height/factor, lineBeginModelPt = utilMathRotatePointCW(model, {
                    x: model.x,
                    y: model.y - height / 2
                }, model.rot), lineEndModelPt = utilSvgScreenSpaceToModelSpace(this.view, x, y);
                rotLine.attr({
                    x1: lineBeginModelPt.x * factor,
                    y1: -lineBeginModelPt.y * factor,
                    x2: lineEndModelPt.x * factor,
                    y2: -lineEndModelPt.y * factor
                }),productRotateImg.attr({
                    x: lineEndModelPt.x * factor - productRotateImg.attr('width')/2,
                    y: -lineEndModelPt.y * factor - productRotateImg.attr('width')/2
                });
            }
        }, dragDown = function (x, y, e) {
            e.stopPropagation(), this.orig = utilSvgModelSpaceToScreenSpace(this.view, this.model.x, this.model.y),
                this.origRot = this.model.rot, this.handlePos = {
                x: x,
                y: y
            }, utilActionBegin(actionMgr, "RotateGroup", this.model);
        }, dragUp = function (e) {
            e.stopPropagation(), utilActionEnd(actionMgr, "RotateGroup", this.model);
        };
        productRotateImg.drag(dragMove, dragDown, dragUp, this, this, this).touchstart(touchRotHandler).touchmove(touchRotHandler).touchend(touchRotHandler);

        this.de.push(svgbound, svgCenter,box,rotLine,productRotateImg), layer.add(this.de), model.propertyChangedEvent.add(function (propertyName, oldValue, newValue) {
            "rot" == propertyName ? this.dF |= 4 : "flag" == propertyName && ((oldValue & GROUPFLAG_CHILDREN_ADDED_REMOVED) != (newValue & GROUPFLAG_CHILDREN_ADDED_REMOVED) ? this.dF |= 1 : (oldValue & GROUPFLAG_VIEW_UPDATE) != (newValue & GROUPFLAG_VIEW_UPDATE) ? this.dF |= 1 : (oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) ? this.dF |= 2 : (oldValue & GROUPFLAG_OPENED) != (newValue & GROUPFLAG_OPENED) && (this.dF |= 2));
        }.bind(this)), model.itemAdded.add(function () {
            this.dF |= 1;
        }.bind(this)), model.itemRemoved.add(function () {
            this.dF |= 1;
        }.bind(this));
    },
    update: function () {
        var svgbound = this.de[0], svgCenter = this.de[1],box=this.de[2],rotLine=this.de[3], productRotateImg=this.de[4],model = this.model, factor = (this.view,
            100);
        (this.showDe.label && this.showDe.label.length > 0) ? (this.showDe.label[0].attr("display", "none"), this.showDe.label[1].attr("display", "none"), this.showDe.label[2].attr("display", "none"), this.showDe.label[3].attr("display", "none")) : "";
        (this.showDe.arrow && this.showDe.arrow.length > 0) ? (
            this.showDe.arrow.forEach(function (a) {
                a.attr("display", "none")
            })) : "";
        this.de.forEach(function (e) {
            e.attr("display", "none")
        });
        this.model.textpos = []
        var modelBound=model.getLoop();
        if(model.width == 0 && modelBound){
            var width=Math.abs(modelBound[1].x-modelBound[0].x)*factor,height=Math.abs(modelBound[1].y-modelBound[2].y)*factor
            model.width=width;
            model.height=height;
        }
        if (0 != (4 & this.dF) && svgbound.transform("r" + -model.rot), 0 != (2 & this.dF)) {
            if(model._center.x=='Infinity'){
                model.width=0,model.rot=0,utilGroupUpdateCenter(application.doc.floorplan,model),utilGroupUpdateBoxCenter(model)
                this.update();
                return
            }
            !utilModelIsFlagOff(model, GROUPFLAG_OPENED) && (model.width=0,model.rot=0,utilGroupUpdateCenter(application.doc.floorplan,model),utilGroupUpdateBoxCenter(model));
            var attr = {
                "stroke-width": utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? .1:3,
                stroke: utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "#49fffe" : "hotpink",
                display: utilModelIsFlagOn(model, MODELFLAG_PICKED) ? "block" : "none"
            };
            svgbound.attr(attr), svgCenter.attr(attr);
            var boxAttr={
                display: utilModelIsFlagOn(model, MODELFLAG_PICKED) ? (utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "block ": "none" ):"none"
            }
            box.attr(boxAttr),productRotateImg.attr(boxAttr),rotLine.attr(boxAttr);
            box.attr({
                x:model.x * factor - model.width/2,
                y:-model.y * factor - model.height/2,
                width:model.width,
                height:model.height
            })
        }
        if (0 != (1 & this.dF)) {
            var modelCenter = model._center,view=this.view;
            if (modelBound && 5 == modelBound.length) {
                if(!modelCenter.x || modelCenter.x=='Infinity')return
                var  height = model.height/factor, width = model.width, lineBeginModelPt = utilMathRotatePointCW(model, {
                    x: model.x,
                    y: model.y - height / 2
                }, model.rot), lineScreenLength = 100, lineEndModelPtDelta = utilSvgVectorScreenSpaceToModelSpace(view, lineScreenLength * Math.sin(utilMathToRadius(model.rot)), lineScreenLength * Math.cos(utilMathToRadius(model.rot))), lineEndModelPt = {
                    x: lineEndModelPtDelta.x + lineBeginModelPt.x,
                    y: lineEndModelPtDelta.y + lineBeginModelPt.y
                };

                var svgPath = "M" + modelBound[0].x * factor + "," + modelBound[0].y * -factor + "L" + modelBound[1].x * factor + "," + modelBound[1].y * -factor + "L" + modelBound[2].x * factor + "," + modelBound[2].y * -factor + "L" + modelBound[3].x * factor + "," + modelBound[3].y * -factor + "L" + modelBound[4].x * factor + "," + modelBound[4].y * -factor + "Z";
                var productRotateImgWidth=SNAP_Group_Rotate_IMG.width*(utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7,
                    productRotateImgHeight=SNAP_Group_Rotate_IMG.width*(utilMathLineLength(lineBeginModelPt, lineEndModelPt) / 8 * factor)/18.7
                svgbound.attr({
                    "stroke-width":model.id == GROUP_TEMP.id ? 3:(utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? .1:3),
                    path: svgPath,
                    stroke: utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "#49fffe" : "hotpink",
                    display: utilModelIsFlagOn(model, MODELFLAG_PICKED) ? "block" : "none"
                }), svgCenter.attr({
                    cx: modelCenter.x * factor,
                    cy: -factor * modelCenter.y,
                    fill: utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "#49fffe" : "hotpink",
                    display: utilModelIsFlagOn(model, MODELFLAG_PICKED) ? "block" : "none"
                });
                box.attr({
                    x:model.x * factor - model.width/2,
                    y:-model.y * factor - model.height/2,
                    width:model.width,
                    height:model.height,
                    display: model.id == GROUP_TEMP.id ?"none":(utilModelIsFlagOn(model, MODELFLAG_PICKED) ? (utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "block ": "none" ):"none")
                }).transform("r" + -model.rot);
                rotLine.attr({
                    display: model.id == GROUP_TEMP.id ?"none":(utilModelIsFlagOn(model, MODELFLAG_PICKED) ? (utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "block ": "none" ):"none"),
                    x1: lineBeginModelPt.x * factor,
                    y1: -lineBeginModelPt.y * factor,
                    x2: lineEndModelPt.x * factor,
                    y2: -lineEndModelPt.y * factor
                }), productRotateImg.attr({
                    display: model.id == GROUP_TEMP.id ?"none":(utilModelIsFlagOn(model, MODELFLAG_PICKED) ? (utilModelIsFlagOff(model, GROUPFLAG_OPENED) ? "block ": "none" ):"none"),
                    x: lineEndModelPt.x * factor - productRotateImgWidth/2,
                    y: -lineEndModelPt.y * factor - productRotateImgHeight/2,
                    width:productRotateImgWidth,
                    height:productRotateImgHeight
                })
                    // 物体标距线,添加物体箭头辅助线 add by hcw
                utilModelIsFlagOff(model, GROUPFLAG_OPENED) && (model.id != GROUP_TEMP.id && (!utilModelIsFlagOn(model, MODELFLAG_PICKED) ?"":(createLabelLine(this),createArrowLine(this))));
                !utilModelIsFlagOff(model, GROUPFLAG_OPENED) && (model.width=0,model.rot=0,utilGroupUpdateCenter(application.doc.floorplan,model),utilGroupUpdateBoxCenter(model));
            }
        }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.remove();
        });
        if (this._GroupZoomChangeRot) {
            this.view.zoomChangedEvent.remove(this._GroupZoomChangeRot);
            this._GroupZoomChangeRot = null;
        }
        if (this.showDe.arrow) {
            this.showDe.arrow.forEach(function (ele) {
                ele.remove();
            });
        }
        if (this.showDe.label) {
            application.laberFrame();
            this.showDe.label.forEach(function (ele) {
                ele.remove();
            });
        }
    }
}),

    classInherit(DisplaySnapTemp, DisplayObject), utilExtend(DisplaySnapTemp.prototype, {
    create: function () {
        classBase(this, "create");
        var layer = this.view.layers.Temp;
        this.layer = layer;
        var context = this.view.context, factor = 100, defaultWidth = 100;
        this.paper = context.rect(-defaultWidth * factor / 2, -defaultWidth * factor / 2, defaultWidth * factor, defaultWidth * factor).attr({
            fill: "#FFFF00",
            stroke: "#ECECEC",
            cursor: "crosshair",
            opacity: 0
        }), layer.add(this.paper);
    },
    update: function () {
    },
    destroy: function () {
        this.layer.clear();
    }
}), classInherit(DisplaySnapUnderlay, DisplayObject), utilExtend(DisplaySnapUnderlay.prototype, {
    create: function () {
        classBase(this, "create");
        /*上传户型图在此处执行snap.js插件，context.image(),插入文档 add by oxl*/
        var fp = (this.view.app.actionMgr, this.view.doc.floorplan);
        var locked = utilModelIsFlagOn(fp, MODELFLAG_LOCKED);
        var bound = utilDisplaySnapUnderlayBuildBound(this.model);
        var layer = this.view.layers[this.model.type];
        var url = utilMaterialGetUrl(this.model, "thumb");
        var context = this.view.context;
        var bounds = context.rect(bound.left, bound.top, bound.width, bound.height).attr({
            stroke: "#909000",
            "stroke-width": 0,
            "fill-opacity": .01,
            did: this.id
        })
        var img = context.image(url, bound.left, bound.top, bound.width, bound.height).attr({
            stroke: "#902020",
            "stroke-width": 2,
            opacity: locked ? .2 : 1
        });
        this.de.push(bounds, img), layer.add(this.de);
        var updateFun = function (propertyName) {
            this.dF |= 1, "flag" == propertyName && (this.dF |= 2);
        }.bind(this);
        this.model.propertyChangedEvent.add(updateFun);
    },
    update: function () {
        var fp = (this.view.app.actionMgr, this.view.doc.floorplan), img = this.de[1];
        if (0 != (1 & this.dF)) {
            var bound = utilDisplaySnapUnderlayBuildBound(this.model);
            img.attr({
                x: bound.left,
                y: bound.top,
                width: bound.width,
                height: bound.height
            });
        }
        if (0 != (2 & this.dF)) {
            var locked = utilModelIsFlagOn(fp, MODELFLAG_LOCKED);
            img.attr({
                opacity: locked ? .2 : 1
            });
        }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.attr("display", "none");
        });
    }
}), classInherit(DisplaySnapActionAddWall, DisplaySnapTemp);

var SNAP_ADDWALL_SNAP_ENABLE = !0;

utilExtend(DisplaySnapActionAddWall.prototype, {
    create: function () {
        classBase(this, "create");
        var context = this.view.context;
        var cursorPoint = context.circle(0, 0, 5).attr({
            fill: "#f09090",
            stroke: "#f09090",
            "fill-opacity": .5,
            "stroke-opacity": .7,
            "stroke-width": 1
        });
        var alignH = context.path().attr({
            "stroke-width": 2,
            stroke: "#60fefe"
        });
        var alignV = context.path().attr({
            "stroke-width": 2,
            stroke: "#60fefe"
        });
        var dimensions = utilSnapWallDimensionCreate(context, this.action.model);
        this.de = [cursorPoint, alignH, alignV, this.paper];
        this.de.unshift.apply(this.de, dimensions);
        this.layer.add(this.de);
        var fp = this.action.fp;
        var allPoints = [];
        utilFloorplanForEachPoint(fp, function (pt) {
            this.begin && pt.id == this.begin.id || this.end && pt.id == this.end.id || allPoints.push(pt);
        }, this.action.model);
        var onmouseevt = function (e, screen_x, screen_y) {
            function _MakeSvgLine(pt1, pt2, isInfinit) {
                if (1 == isInfinit) {
                    var _pt2 = utilMathGetScaledPoint(pt1, pt2, 50);
                    var _pt1 = utilMathGetScaledPoint(pt2, pt1, 50);
                    pt1 = _pt1;
                    pt2 = _pt2;
                }
                return "M" + 100 * pt1.x + "," + -100 * pt1.y + "L" + 100 * pt2.x + "," + -100 * pt2.y;
            }

            if (1 != e.button) {
               // e.stopPropagation();
                var alignHPt;
                var alignVPt;
                var factor = 100;
                var tol = .15;
                var modelPos = utilSvgScreenSpaceToModelSpace(this.view, e.pageX, e.pageY);
                var snap = SNAP_ADDWALL_SNAP_ENABLE && utilWallGetSnapPt(fp, modelPos, [this.action.model]);
                if (0 == SNAP_ADDWALL_SNAP_ENABLE)
                    ;
                else if (snap && snap.snapTo.type == Point.prototype.type)
                    modelPos = snap.point;
                else if (snap && snap.snapTo.type == Wall.prototype.type) {
                    var snapPt = snap.point;
                    var wall = snap.snapTo;
                    var currentWall = this.action.model;
                    var modelPos = snapPt;
                    var beginPt = currentWall.begin;
                    beginPt && utilMathEquals(beginPt.y, snapPt.y, tol) ? (alignHPt = beginPt, modelPos = utilMathLineLineIntersection(alignHPt, {
                        x: alignHPt.x + 10,
                        y: alignHPt.y
                    }, wall.begin, wall.end)) : beginPt && utilMathEquals(beginPt.x, snapPt.x, tol) && (alignVPt = beginPt,
                        modelPos = utilMathLineLineIntersection(alignVPt, {
                            x: alignVPt.x,
                            y: alignVPt.y + 10
                        }, wall.begin, wall.end));
                } else {
                    var currentWall = this.action.model;
                    var beginPt = currentWall.begin;
                    beginPt && utilMathEquals(modelPos.y, beginPt.y, tol) ? (alignHPt = beginPt, modelPos.y = beginPt.y) : beginPt && utilMathEquals(modelPos.x, beginPt.x, tol) && (alignVPt = beginPt,
                        modelPos.x = beginPt.x);
                    for (var i = 0, len = allPoints.length; len > i; ++i) {
                        var p = allPoints[i];
                        if (!alignHPt && utilMathEquals(p.y, modelPos.y, tol)) {
                            alignHPt = p, modelPos.y = p.y;
                            break;
                        }
                        if (!alignVPt && utilMathEquals(p.x, modelPos.x, tol)) {
                            alignVPt = p, modelPos.x = p.x;
                            break;
                        }
                    }
                }
                utilActionRun(this.action.mgr, e.type, e, modelPos), cursorPoint.attr({
                    cx: modelPos.x * factor,
                    cy: -modelPos.y * factor
                }), alignH.attr({
                    path: alignHPt ? _MakeSvgLine(alignHPt, modelPos, !0) : ""
                }), alignV.attr({
                    path: alignVPt ? _MakeSvgLine(alignVPt, modelPos, !0) : ""
                });
            }
        }.bind(this);
        this.paper.mousemove(onmouseevt).click(onmouseevt).mouseup(onmouseevt);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionAddArea, DisplaySnapTemp), utilExtend(DisplaySnapActionAddArea.prototype, {
    create: function () {
        classBase(this, "create");
        //console.log(this)
        var context = this.view.context, firstPoint = context.circle(-1e4, -1e4, 5).attr({
            fill: "#c03030",
            stroke: "#c03030",
            "fill-opacity": .15,
            "stroke-opacity": .1,
            "stroke-width": 1
        }), cursorPoint = context.circle(0, 0,5).attr({
            fill: "blue",
            stroke: "#909090",
            "fill-opacity": .15,
            "stroke-opacity": .1,
            "stroke-width": 1
        }), alignH = context.path().attr({
            "stroke-width": 2,
            stroke: "#60fefe"
        }), alignV = context.path().attr({
            "stroke-width": 2,
            stroke: "#60fefe"
        }), dimensions = utilSnapWallDimensionCreate(context, this.action.model);
        this.de = [firstPoint, cursorPoint, alignH, alignV, this.paper], this.de.unshift.apply(this.de, dimensions);
        //this.layer.add( [firstPoint, cursorPoint, this.paper]);
        //this.view.layers['PRODUCT_MARK'].add([alignH,alignV]);
        this.layer.add(this.de);

        var fp = this.action.fp, allPoints = [];
        //utilFloorplanForEachPoint(fp, function (pt) {
        //    this.begin && pt.id == this.begin.id || this.end && pt.id == this.end.id || allPoints.push(pt);
        //}, this.action.model);
        //区域的点只与区域之中的点吸咐。
        utilFloorplanForInnerPoint(fp, undefined, function (pt) {
            this.begin && pt.id == this.begin.id || this.end && pt.id == this.end.id || allPoints.push(pt);
            //allPoints.push(pt);
        });

        var onmouseevt = function (e, screen_x, screen_y) {
            function _MakeSvgLine(pt1, pt2, isInfinit) {
                if (1 == isInfinit) {
                    var _pt2 = utilMathGetScaledPoint(pt1, pt2, 50), _pt1 = utilMathGetScaledPoint(pt2, pt1, 50);
                    pt1 = _pt1, pt2 = _pt2;
                }
                return "M" + 100 * pt1.x + "," + -100 * pt1.y + "L" + 100 * pt2.x + "," + -100 * pt2.y;
            }

            if (1 != e.button) {
                e.stopPropagation();
                var alignHPt, alignVPt, factor = 100, tol = .05;
                var modelPos = utilSvgScreenSpaceToModelSpace(this.view, e.pageX, e.pageY);

                //修改自由画区域时的吸咐功能
                var snap = SNAP_ADDWALL_SNAP_ENABLE && utilWallGetSnapPtForArea(fp, modelPos, []); //  utilWallGetSnapPt
                if (0 == SNAP_ADDWALL_SNAP_ENABLE){
                    //do nothing
                }else if (snap && snap.snapTo.type == Point.prototype.type ){
                    modelPos = snap.point;
                }
                else if (snap && snap.snapTo.type == Wall.prototype.type) {
                    modelPos = snap.point;
                    //var snapPt = snap.point, wall = snap.snapTo, currentWall = this.action.model, modelPos = snapPt, beginPt = currentWall.begin;
                    //beginPt && utilMathEquals(beginPt.y, snapPt.y, tol) ? (alignHPt = beginPt, modelPos = utilMathLineLineIntersection(alignHPt, {
                    //    x: alignHPt.x + 10,
                    //    y: alignHPt.y
                    //}, wall.begin, wall.end)) : beginPt && utilMathEquals(beginPt.x, snapPt.x, tol) && (alignVPt = beginPt,
                    //    modelPos = utilMathLineLineIntersection(alignVPt, {
                    //        x: alignVPt.x,
                    //        y: alignVPt.y + 10
                    //    }, wall.begin, wall.end));
                } //不处理对墙的上下吸咐
                else {
                    var currentWall = this.action.model;
                    var beginPt = currentWall.begin;
                    beginPt && utilMathEquals(modelPos.y, beginPt.y, tol) ? (alignHPt = beginPt, modelPos.y = beginPt.y) : beginPt && utilMathEquals(modelPos.x, beginPt.x, tol) && (alignVPt = beginPt,
                        modelPos.x = beginPt.x);

                    //beginPt && utilMathEquals(modelPos.y, beginPt.y, tol) && (alignHPt = beginPt, modelPos.y = beginPt.y);
                    //beginPt && utilMathEquals(modelPos.x, beginPt.x, tol) && (alignVPt = beginPt, modelPos.x = beginPt.x);

                    for (var i = 0, len = allPoints.length; len > i; ++i) {
                        var p = allPoints[i];
                        if (!alignHPt && utilMathEquals(p.y, modelPos.y, tol)) {
                            alignHPt = p, modelPos.y = p.y;
                            break;
                        }
                        //if (!alignVPt && utilMathEquals(p.x, modelPos.x, tol)) {
                        //    alignVPt = p, modelPos.x = p.x;
                        //    break;
                        //}
                    }

                    for (var i = 0, len = allPoints.length; len > i; ++i) {
                        var p = allPoints[i];
                        //if (!alignHPt && utilMathEquals(p.y, modelPos.y, tol)) {
                        //    alignHPt = p, modelPos.y = p.y;
                        //    break;
                        //}
                        if (!alignVPt && utilMathEquals(p.x, modelPos.x, tol)) {
                            alignVPt = p, modelPos.x = p.x;
                            break;
                        }
                    }

                }

                utilActionRun(this.action.mgr, e.type, e, modelPos), "click" == e.type && -1 == allPoints.indexOf(this.action.model.begin) && allPoints.push(this.action.model.begin);
                var actionFirstPt = this.action.firstPoint;
                actionFirstPt && firstPoint.attr({
                    cx: actionFirstPt.x * factor,
                    cy: -actionFirstPt.y * factor
                });
                cursorPoint.attr({
                    cx: modelPos.x * factor,
                    cy: -modelPos.y * factor
                });

                utilSnapWallDimensionUpdate(context, this.action.model, dimensions), alignH.attr({
                    path: alignHPt ? _MakeSvgLine(alignHPt, modelPos, !0) : ""
                }), alignV.attr({
                    path: alignVPt ? _MakeSvgLine(alignVPt, modelPos, !0) : ""
                });
            }
        }.bind(this);
        this.paper.mousemove(onmouseevt).click(onmouseevt).mouseup(onmouseevt);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionAddRectArea, DisplaySnapTemp), utilExtend(DisplaySnapActionAddRectArea.prototype, {
    create: function () {
        classBase(this, "create");
        var context = this.view.context, firstPoint = context.circle(-1e4, -1e4, 5).attr({
            fill: "#c03030",
            stroke: "#c03030",
            "fill-opacity": .15,
            "stroke-opacity": .1,
            "stroke-width": 1
        }), cursorPoint = context.circle(0, 0, 5).attr({
            fill: "#909090",
            stroke: "#909090",
            "fill-opacity": .15,
            "stroke-opacity": .1,
            "stroke-width": 1
        }), h_dimensions = utilSnapWallDimensionCreate(context), v_dimensions = utilSnapWallDimensionCreate(context);
        console.log(utilSnapWallDimensionCreate(context))
        this.de = [firstPoint, cursorPoint, this.paper], this.de.unshift.apply(this.de, h_dimensions),
            this.de.unshift.apply(this.de, v_dimensions), this.layer.add(this.de);
        var onmouseevt = (this.action.fp, function (e, screen_x, screen_y) {
            if (1 != e.button) {
                e.stopPropagation();
                var factor = 100, modelPos = utilSvgScreenSpaceToModelSpace(this.view, e.pageX, e.pageY), mouseType = "view2d_" + e.type;
                utilActionRun(this.action.mgr, mouseType, e, modelPos), cursorPoint.attr({
                    cx: modelPos.x * factor,
                    cy: -modelPos.y * factor
                });
                var actionFirstPt = this.action.firstPoint;
                actionFirstPt && (firstPoint.attr({
                    cx: actionFirstPt.x * factor,
                    cy: -actionFirstPt.y * factor
                }), utilSnapPointsDimensionUpdate(context, actionFirstPt, {
                    x: modelPos.x,
                    y: actionFirstPt.y
                }, h_dimensions), utilSnapPointsDimensionUpdate(context, {
                    x: modelPos.x,
                    y: actionFirstPt.y
                }, modelPos, v_dimensions));
            }
        }.bind(this));
        this.paper.mousemove(onmouseevt).click(onmouseevt).mouseup(onmouseevt);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionAddRoundArea, DisplaySnapTemp), utilExtend(DisplaySnapActionAddRoundArea.prototype, {
    create: function () {
        classBase(this, "create");
        var context = this.view.context, firstPoint = context.circle(-1e4, -1e4, 5).attr({
            fill: "#c03030",
            stroke: "#c03030",
            "fill-opacity": .15,
            "stroke-opacity": .1,
            "stroke-width": 1
        }), cursorPoint = context.circle(0, 0, 5).attr({
            fill: "#909090",
            stroke: "#909090",
            "fill-opacity": .15,
            "stroke-opacity": .1,
            "stroke-width": 1
        }), dimensions = utilSnapWallDimensionCreate(context);
        this.de = [firstPoint, cursorPoint, this.paper], this.de.unshift.apply(this.de, dimensions),
            this.layer.add(this.de);
        var onmouseevt = (this.action.fp, function (e, screen_x, screen_y) {
            if (1 != e.button) {
                e.stopPropagation();
                var factor = 100, modelPos = utilSvgScreenSpaceToModelSpace(this.view, e.pageX, e.pageY), mouseType = "view2d_" + e.type;
                utilActionRun(this.action.mgr, mouseType, e, modelPos), cursorPoint.attr({
                    cx: modelPos.x * factor,
                    cy: -modelPos.y * factor
                });
                var actionFirstPt = this.action.center;
                actionFirstPt && (firstPoint.attr({
                    cx: actionFirstPt.x * factor,
                    cy: -actionFirstPt.y * factor
                }), utilSnapPointsDimensionUpdate(context, actionFirstPt, {
                    x: modelPos.x,
                    y: actionFirstPt.y
                }, dimensions));
            }
        }.bind(this));
        this.paper.mousemove(onmouseevt).click(onmouseevt).mouseup(onmouseevt);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionMovePoint, DisplaySnapTemp), utilExtend(DisplaySnapActionMovePoint.prototype, {
    create: function () {
        classBase(this, "create");
        var context = this.view.context;
        var dimensions = [];
        this.de = [];
        this.action.walls.forEach(function (wall) {
            var dimension = utilSnapWallDimensionCreate(context, wall);
            dimensions.push(dimension);
            this.de.push.apply(this.de, dimension);
        }, this);
        var alignH = context.path().attr({
            "stroke-width": 2,
            stroke: "#60fefe"
        }), alignV = context.path().attr({
            "stroke-width": 2,
            stroke: "#60fefe"
        });
        this.de.push(alignH, alignV, this.paper);
        this.layer.add(this.de);
        //this.view.layers['PRODUCT_MARK'].add(this.de);
        var fp = this.action.fp;
        var excludedPoints = this.action.points;
        var firstPriorityPoints = [];
        var secondPriorityPoints = [];
        var area = this.model.areas[0];//当前操作的自由画区域
        var wallCruve = this.model.walls[0];//当前操作的自由画区域

        //移动墙的点时执行
        this.action.walls.forEach(function (wall) {
            wall.begin && -1 == excludedPoints.indexOf(wall.begin) && firstPriorityPoints.push(wall.begin),
            wall.end && -1 == excludedPoints.indexOf(wall.end) && firstPriorityPoints.push(wall.end);
        });

        if(wallCruve){
            utilFloorplanForEachPoint(fp, function (pt) { //utilFloorplanForEachPoint
                if(-1 == excludedPoints.indexOf(pt) && -1 == firstPriorityPoints.indexOf(pt))
                {
                    //firstPriorityPoints.push(pt);//添加第一个点，使得同时有上下左右吸咐对位。
                    secondPriorityPoints.push(pt);
                }
            });
        }

        if (area) {
            utilFloorplanForInnerPoint(fp, area, function (pt) { //utilFloorplanForEachPoint
                if (-1 == excludedPoints.indexOf(pt)) //&& -1 == firstPriorityPoints.indexOf(pt))
                {
                    firstPriorityPoints.push(pt);//添加第一个点，使得同时有上下左右吸咐对位。
                    secondPriorityPoints.push(pt);
                }
            });
        }


        var onmouseevt = function (e, screen_x, screen_y) {
            function _MakeSvgLine(pt1, pt2, isInfinit) {
                if (1 == isInfinit) {
                    var _pt2 = utilMathGetScaledPoint(pt1, pt2, 50), _pt1 = utilMathGetScaledPoint(pt2, pt1, 50);
                    pt1 = _pt1, pt2 = _pt2;
                }
                return "M" + 100 * pt1.x + "," + -100 * pt1.y + "L" + 100 * pt2.x + "," + -100 * pt2.y;
            }
            e.stopPropagation();
            var alignHPt, alignVPt, tol = .15, modelPos = utilSvgScreenSpaceToModelSpace(this.view, e.pageX, e.pageY);
            var snap = undefined;

            //移动点时取消对墙的吸咐：不获取snap的值.
            if (wallCruve) {
                if (SNAP_ADDWALL_SNAP_ENABLE) {
                    snap = utilWallGetSnapPt(fp, modelPos, this.action.walls);
                }
            }
            if (area) {
                if (SNAP_ADDWALL_SNAP_ENABLE) {
                    //修改移动区域的点与墙的吸咐
                    snap = utilWallGetSnapPtForArea(fp, modelPos, this.action.walls);
                }
            }


            if (0 == SNAP_ADDWALL_SNAP_ENABLE){
                //按F4关闭吸咐功能时do nothing  SNAP_ADDWALL_SNAP_ENABLE==false
            } else if (snap && (snap.snapTo.type == Point.prototype.type || snap.snapTo.type == Wall.prototype.type))
            {
                modelPos = snap.point;
            }

            //把自动对位的功能也受F4键控制
            if (SNAP_ADDWALL_SNAP_ENABLE) {
                for (var i = 0, len = firstPriorityPoints.length; len > i; ++i) {
                    var p = firstPriorityPoints[i];
                    if (!alignHPt && utilMathEquals(p.y, modelPos.y, tol)) {
                        alignHPt = p;
                        modelPos.y = p.y;
                        break;
                    }
                    if (!alignVPt && utilMathEquals(p.x, modelPos.x, tol)) {
                        alignVPt = p;
                        modelPos.x = p.x;
                        break;
                    }
                }
                for (var i = 0, len = secondPriorityPoints.length; len > i; ++i) {
                    var p = secondPriorityPoints[i];
                    if (!alignHPt && utilMathEquals(p.y, modelPos.y, tol)) {
                        alignHPt = p;
                        modelPos.y = p.y;
                        break;
                    }
                    if (!alignVPt && utilMathEquals(p.x, modelPos.x, tol)) {
                        alignVPt = p;
                        modelPos.x = p.x;
                        break;
                    }
                }
            }

            utilActionRun(this.view.app.actionMgr, e.type, e, modelPos);
            //移动墙的点时执行
            this.action.walls.forEach(function (wall, i) {
                var dimension = dimensions[i];
                utilSnapWallDimensionUpdate(context, wall, dimension);
            });
            alignH.attr({
                path: alignHPt ? _MakeSvgLine(alignHPt, modelPos, !0) : ""
            });
            alignV.attr({
                path: alignVPt ? _MakeSvgLine(alignVPt, modelPos, !0) : ""
            });

            //buttons 1左键  4中键   2右键
            //移动自动画区域的点的时候增加坐标校准。--add by gaoning 2018.4.8
            if (area) {
                if (e.type == "mousemove" && e.buttons == 1) {
                    createMouseToWallLine(modelPos);
                    area.profile.forEach(function (curve) {
                        var line = new Line(curve.begin.x, curve.begin.y, curve.end.x, curve.end.y);
                        var length = line.length();

                        var text;
                        if(area.lineLengthTextDic.Exists(curve.id)){
                            text = area.lineLengthTextDic.getItem(curve.id);
                        }else{
                            text = context.text();
                            area.lineLengthTextDic.add(curve.id,text);
                        }
                        text.attr({
                            stroke: "none",
                            "font-size": api.getViewById("2d").getAreaLabelSize(10,20),
                            fill: "#6e6e6e",
                            "font-family": "Calibri,Arial,Helvetica,sans-serif",
                            "text-anchor": "middle",
                            text: Math.round(length * 1000),
                            x: (curve.begin.x + curve.end.x) / 2 * 100,
                            y: -(curve.begin.y + curve.end.y) / 2 * 100
                        });
                    });
                } else if (e.type == "mouseup") {
                    area.showMouseLabel.forEach(function (label) {
                        if (label)
                            label.remove();
                    });
                    area.showMouseLabel = [];

                    RemoveMouseToWallLine();

                    var texts = area.lineLengthTextDic.values();
                    for (var t = 0; t < texts.length; t++) {
                        if (texts[t])
                            texts[t].remove();
                    }
                    area.lineLengthTextDic.removeAll();
                }
            }else{
                //移动墙上的点时走正常流程
            }

        }.bind(this);

        this.paper.mousemove(onmouseevt).click(onmouseevt).mouseup(onmouseevt);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionMoveBezierPoint, DisplaySnapTemp), utilExtend(DisplaySnapActionMoveBezierPoint.prototype, {
    create: function () {
        classBase(this, "create");
        var context = this.view.context;        
        var fp = this.action.fp;        

        var onmouseevt = function (e, screen_x, screen_y) {
            e.stopPropagation();
            var modelPos = utilSvgScreenSpaceToModelSpace(this.view, e.pageX, e.pageY);
            utilActionRun(this.view.app.actionMgr, e.type, e, modelPos);
            //更新墙体
        }.bind(this);
        this.paper.mousemove(onmouseevt).click(onmouseevt).mouseup(onmouseevt);
        
        //激活选中host墙体
        var pickMgr = this.view.app.pickMgr;
        utilPickMgrUnpickAll(pickMgr);
        utilPickMgrPick(pickMgr, this.model.wall);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionAnalyzeNormalized, DisplaySnapTemp), utilExtend(DisplaySnapActionAnalyzeNormalized.prototype, {
    create: function () {
        var actionMgr = this.view.app.actionMgr;
        classBase(this, "create");
        var context = this.view.context;
        this.de = [];
        for (var analyzed = this.action.analyzed, i = 0; i < analyzed.length; ++i) {
            var error = analyzed[i];
            if (error.floor, error.wall) {
                var wallPath = utilSnapWallCreateLoopString(error.wall, !0), wallSvg = context.path(wallPath).attr({
                    fill: "blue",
                    stroke: "darkgray"
                });
                this.de.push(wallSvg);
            }
            if (error.point) {
                var ptSvg = context.circle(100 * error.point.x, -100 * error.point.y, 20).attr({
                    fill: "red",
                    stroke: "darkgray"
                });
                this.de.push(ptSvg);
            }
        }
        this.layer.add(this.de);
        var onmouseevt = function (e, screen_x, screen_y) {
            e.stopPropagation(), 1 != e.button && utilActionEnd(actionMgr);
        }.bind(this);
        this.paper.click(onmouseevt);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionRulerMeasure, DisplaySnapTemp), utilExtend(DisplaySnapActionRulerMeasure.prototype, {
    create: function () {
        function snapModelPoint(pt) {
            return pt;
        }

        classBase(this, "create");
        var view = this.view, actionMgr = this.view.app.actionMgr, context = this.view.context, points = this.action.points, layer = this.layer, svgPts = [], svgLines = [], svgRemindLine = void 0, onmouseup = function (e, screen_x, screen_y) {
            if (e.stopPropagation(), 1 != e.button) {
                if (2 == e.button && "mouseup" == e.type) return void utilActionEnd(actionMgr);
                var currentPos = snapModelPoint(utilSvgScreenSpaceToModelSpace(view, screen_x, screen_y)), lastPos = points.length > 0 ? points[points.length - 1] : void 0;
                utilActionRun(actionMgr, e.type, e, currentPos);
                var svgPt = context.circle(100 * currentPos.x, -100 * currentPos.y, 5).attr({
                    stroke: "#3eb3de",
                    fill: "#3eb3de",
                    "stroke-width": 1,
                    "fill-opacity": .8,
                    cursor: "crosshair"
                }).mouseup(onmouseup), svgLine = lastPos ? context.line(100 * currentPos.x, -100 * currentPos.y, 100 * lastPos.x, -100 * lastPos.y).attr({
                    stroke: "#3eb3de",
                    "stroke-width": 2
                }) : void 0;
                svgPt && svgPts.push(svgPt), svgLine && svgLines.push(svgLine), layer.add(svgLines),
                    layer.add(svgPts);
            }
        }.bind(this), ondbclick = function (e) {
            e.stopPropagation(), utilActionEnd(actionMgr);
        }.bind(this), onmousemove = function (e, screen_x, screen_y) {
            var currentPos = snapModelPoint(utilSvgScreenSpaceToModelSpace(view, screen_x, screen_y)), lastPos = points.length > 0 ? points[points.length - 1] : void 0;
            svgRemindLine ? svgRemindLine.attr({
                x1: 100 * currentPos.x,
                y1: -100 * currentPos.y,
                x2: 100 * lastPos.x,
                y2: -100 * lastPos.y
            }) : svgRemindLine = lastPos ? context.line(100 * currentPos.x, -100 * currentPos.y, 100 * lastPos.x, -100 * lastPos.y).attr({
                stroke: "#3eb3de",
                "stroke-width": 2,
                cursor: "crosshair"
            }).mouseup(onmouseup) : void 0, svgRemindLine && layer.add(svgRemindLine);
        }.bind(this);
        this.paper.mouseup(onmouseup).dblclick(ondbclick).mousemove(onmousemove);
    },
    update: function () {
    }
}), classInherit(DisplaySnapActionApplyModelroom, DisplaySnapTemp), utilExtend(DisplaySnapActionApplyModelroom.prototype, {
    create: function () {
        var actionMgr = this.view.app.actionMgr;
        classBase(this, "create");
        var view = this.view, context = view.context;
        this.de = [];
        var ghostFloor = this.action.ghostRoom;
        if (ghostFloor) {
            this.ghostLoop = utilFloorGetLoopFromProfile(ghostFloor);
            var ghostCenter = utilMathPolyMassCenter(this.ghostLoop), roomCenter = utilMathPolyMassCenter(this.action.thisRoom.getLoop()), roomPath = context.path().attr({
                fill: "black",
                opacity: .2,
                cursor: "-webkit-grab"
            });

            roomPath.drag(function (dx, dy, x, y, e) {
                if (e.stopPropagation(), 1 != e.button) {
                    var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, x - this._mouseLast.x, y - this._mouseLast.y);
                    this._mouseLast.x = x, this._mouseLast.y = y, utilActionRun(actionMgr, "move", modelOffset);
                }
            }, function (x, y, e) {
                e.stopPropagation(), 1 != e.button && (this._mouseLast = {
                    x: x,
                    y: y
                });
            }, function (e) {
                e.stopPropagation(), 1 != e.button && delete this._mouseLast;
            }, this, this, this);
            for (var ghostFp = this.model.ghostFp, contentDisplay = [], areaDisplay = [], roomDisplay = {
                model: ghostFloor,
                element: roomPath
            }, ids = Object.keys(ghostFp), contentElementAttr = {
                stroke: "#909090",
                "stroke-width": 0,
                opacity: .5
            }, areaElementAttr = {
                fill: "red",
                opacity: .3
            }, i = 0, len = ids.length; len > i; ++i) {
                var modelObject = ghostFp[ids[i]];
                switch (modelObject.type) {
                    case Product.prototype.type:
                        var url = utilCatalogGetFileUrl(application.catalogMgr, "product", modelObject.pid, "top");
                        var contentImg = context.image(url, 0, 0, 0, 0).attr(contentElementAttr);
                        contentDisplay.push({
                            model: modelObject,
                            element: contentImg
                        });
                        break;

                    //start add by gaoning --2017.3.17
                    //套用空间时增加其他构造的加载
                    case Pillar.prototype.type:
                        //Addmodel(context, application, modelObject, contentDisplay, contentElementAttr);
                        var url = utilCatalogGetFileUrl(application.catalogMgr, "product", modelObject.pid, "top");
                        var contentImg = context.image(url, 0, 0, 0, 0).attr(contentElementAttr);
                        contentDisplay.push({
                            model: modelObject,
                            element: contentImg
                        });
                        break;
                    case Beam.prototype.type:
                        //Addmodel(context, application, modelObject, contentDisplay, contentElementAttr);
                        var url = utilCatalogGetFileUrl(application.catalogMgr, "product", modelObject.pid, "top");
                        var contentImg = context.image(url, 0, 0, 0, 0).attr(contentElementAttr);
                        contentDisplay.push({
                            model: modelObject,
                            element: contentImg
                        });
                        break;
                    case Basement.prototype.type:
                        //Addmodel(context, application, modelObject, contentDisplay, contentElementAttr);
                        var url = utilCatalogGetFileUrl(application.catalogMgr, "product", modelObject.pid, "top");
                        var contentImg = context.image(url, 0, 0, 0, 0).attr(contentElementAttr);
                        contentDisplay.push({
                            model: modelObject,
                            element: contentImg
                        });
                        break;

                    case ProductReplacement.prototype.type:
                        var url = utilCatalogGetFileUrl(application.catalogMgr, "product", modelObject.pid, "top");
                        var contentImg = context.image(url, 0, 0, 0, 0).attr(contentElementAttr);
                        contentDisplay.push({
                            model: modelObject,
                            element: contentImg
                        });
                        break;
                    //end add by gaoning -- 2017.3.17

                    case RectArea.prototype.type:
                        areaDisplay.push({
                            model: modelObject,
                            element: context.rect().attr(areaElementAttr)
                        });
                        break;

                    case RoundArea.prototype.type:
                        areaDisplay.push({
                            model: modelObject,
                            element: context.circle().attr(areaElementAttr)
                        });
                        break;

                    case FreeArea.prototype.type:
                        areaDisplay.push({
                            model: modelObject,
                            element: context.path().attr(areaElementAttr)
                        });
                }
            }
            areaDisplay.forEach(function (area) {
                area.element && this.de.push(area.element);
            }, this), contentDisplay.forEach(function (content) {
                content.element && this.de.push(content.element);
            }, this);
            this.de.push(roomDisplay.element);
            this.layer.add(this.de);
            var initOffset = {
                x: roomCenter.x - ghostCenter.x,
                y: roomCenter.y - ghostCenter.y
            }, ghostDisplayUpdate = function (which) {
                function ProfileUpdate(profile) {
                    if (!(profile.length < 3)){
                        for (var i = 0, len = profile.length; len > i; ++i) {
                            var curve = profile[i];
                            PointUpdate(curve.begin);
                            PointUpdate(curve.end);
                        }
                    }
                }

                function PointUpdate(point) {
                    var rectMoves = move;
                    switch (which) {
                        case "init":
                            rectMoves = initOffset;

                        case "move":
                            point.x += rectMoves.x, point.y += rectMoves.y;
                            break;

                        case "rot":
                            var rectRot = utilMathRotatePointCW(newGhostCenterPos, point, rot);
                            point.x = rectRot.x, point.y = rectRot.y;
                    }
                }

                var ghostLoop = utilFloorGetLoopFromProfile(ghostFloor);
                var ghostCenter = utilMathPolyMassCenter(ghostLoop);
                var factor = 100;
                var rot = this.action.ghostRot;
                var move = this.action.ghostMove;
                var newGhostCenterPos = {
                    x: ghostCenter.x + move.x,
                    y: ghostCenter.y + move.y
                };
                var floorProfile = roomDisplay.model.profile;
                ProfileUpdate(floorProfile);
                roomDisplay.element.attr({
                    path: utilSnapFloorCreatePathStringForModelRoom(roomDisplay.model, 0)[0]
                });
                contentDisplay.forEach(function (content) {
                    var modelContent = content.model;
                    PointUpdate(modelContent), "rot" == which && (modelContent.rot += rot);
                    var bound = utilDisplaySnapProductBuildBound(modelContent);
                    content.element.attr({
                        x: bound.left,
                        y: bound.top,
                        width: bound.width,
                        height: bound.height
                    }).transform("r" + -modelContent.rot);
                }), areaDisplay.forEach(function (area) {
                    var modelArea = area.model;
                    modelArea.type == RectArea.prototype.type || modelArea.type == RoundArea.prototype.type ? (PointUpdate(modelArea.center),
                    "rot" == which && (modelArea.rot += rot), modelArea.type == RectArea.prototype.type ? area.element && area.element.attr({
                        x: (modelArea.center.x - modelArea.width / 2) * factor,
                        y: -(modelArea.center.y + modelArea.height / 2) * factor,
                        width: modelArea.width * factor,
                        height: modelArea.height * factor
                    }).transform("r" + -modelArea.rot) : area.element && area.element.attr({
                        cx: modelArea.center.x * factor,
                        cy: -modelArea.center.y * factor,
                        r: modelArea.radius * factor
                    })) : modelArea.type == FreeArea.prototype.type && (ProfileUpdate(modelArea.profile),
                    area.element && area.element.attr({
                        path: utilSnapFloorCreatePathString(modelArea, 0)[0]
                    }));
                });
            }.bind(this);
            this.action.ghostUpdate.has(ghostDisplayUpdate) || this.action.ghostUpdate.add(ghostDisplayUpdate);
        }
    },
    update: function () {
    }


});

function Addmodel(context, application, modelObject, contentDisplay, contentElementAttr) {
    var pid;
    if (modelObject.topMaterial) {
        pid = modelObject.topMaterial.pid;
        AddmodelToContentDisplay(context, application, modelObject, contentDisplay, contentElementAttr, pid);
    }
    if (modelObject.bottomMaterial) {
        pid = modelObject.bottomMaterial.pid;
        AddmodelToContentDisplay(context, application, modelObject, contentDisplay, contentElementAttr, pid);
    }
    if (modelObject.backMaterial) {
        pid = modelObject.backMaterial.pid;
        AddmodelToContentDisplay(context, application, modelObject, contentDisplay, contentElementAttr, pid);
    }
    if (modelObject.frontMaterial) {
        pid = modelObject.frontMaterial.pid;
        AddmodelToContentDisplay(context, application, modelObject, contentDisplay, contentElementAttr, pid);
    }
    if (modelObject.leftMaterial) {
        pid = modelObject.leftMaterial.pid;
        AddmodelToContentDisplay(context, application, modelObject, contentDisplay, contentElementAttr, pid);
    }
    if (modelObject.rightMaterial) {
        pid = modelObject.rightMaterial.pid;
        AddmodelToContentDisplay(context, application, modelObject, contentDisplay, contentElementAttr, pid);
    }
}
function AddmodelToContentDisplay(context, application, modelObject, contentDisplay, contentElementAttr, pid) {
    var url = utilCatalogGetFileUrl(application.catalogMgr, "product", pid, "top");
    var contentImg = context.image(url, 0, 0, 0, 0).attr(contentElementAttr);
    contentDisplay.push({
        model: modelObject,
        element: contentImg
    });
}