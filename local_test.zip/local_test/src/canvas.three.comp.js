function utilThreeXYZ2UVW(xyzPos, uvwOrig, uDir) {
    var intersectPt2d = utilMathGetPerpendicularIntersect(xyzPos, uvwOrig, {
        x: uvwOrig.x + uDir.x,
        y: uvwOrig.y + uDir.y
    }), distance2d = utilMathLineLength(intersectPt2d, xyzPos), w = distance2d, u = utilMathLineLength(uvwOrig, intersectPt2d), v = xyzPos.z;
    return {
        x: u,
        y: v,
        z: w
    };
}

function utilThreeUVW2XYZ(uvwPos, xyzOrig, uDir) {
    var u = uvwPos.x, v = uvwPos.y, w = uvwPos.z || 0, pt = utilMathGetScaledPoint(xyzOrig, {
        x: xyzOrig.x + uDir.x,
        y: xyzOrig.y + uDir.y
    }, u);
    if (0 != w) {
        var wDir = new THREE.Vector2(-uDir.y, uDir.x);
        wDir.normalize().setLength(w), pt.x += wDir.x, pt.y += wDir.y;
    }
    var x, y, z;
    return x = pt.x, y = pt.y, z = v, {
        x: x,
        y: y,
        z: z
    };
}

function _utilThreeGetHoleProfileUVW(hole) {
    var profile = hole.profile || [{
            x: 0,
            y: 0
        }, {
            x: 1,
            y: 0
        }, {
            x: 1,
            y: 1
        }, {
            x: 0,
            y: 1
        }, {
            x: 0,
            y: 0
        }];
    return profile.map(function (pt) {
        return {
            x: (pt.x - .5) * this.xlen,
            y: pt.y * this.zlen
        };
    }, hole.meta);
}

function utilThreeExtrude2dline(line2d, wallHeight3d, holesmodel, ignoreUV) {
	  
	  var buildDatas = [];
	  var vtX = 0; //累计的vtX长度
	  //根据传进来的line2d数量进行创建(多段)
	  for(var lineIndex=0;lineIndex<line2d.length-1;++lineIndex){
	  	var ignoreUV = ignoreUV === !0;
	    var holesModel = holesmodel;
	    var v = [];
	    var f = [];
	    var fn = []; //faceVertexNormals
	    var vt = [];
	    var holesPos = [];
	    var holeProfiles = [];
	    var lineDir = new THREE.Vector2(line2d[lineIndex+1].x, line2d[lineIndex+1].y);
	    lineDir.sub(line2d[lineIndex+0]);
	    var vn = new THREE.Vector3(lineDir.y, -lineDir.x, 0);
	    var boundProfile = [new THREE.Vector3(line2d[lineIndex+0].x, line2d[lineIndex+0].y, 0),
	                        new THREE.Vector3(line2d[lineIndex+1].x, line2d[lineIndex+1].y, 0),
	                        new THREE.Vector3(line2d[lineIndex+1].x, line2d[lineIndex+1].y, wallHeight3d), 
	                        new THREE.Vector3(line2d[lineIndex+0].x, line2d[lineIndex+0].y, wallHeight3d), 
	                        new THREE.Vector3(line2d[lineIndex+0].x, line2d[lineIndex+0].y, 0)];
	    var xyzOrig = boundProfile[0];
	    var boundUVWProfile = boundProfile.map(function (p) {
	        return utilThreeXYZ2UVW(p, xyzOrig, lineDir);
	    });
	    
	    //获取对应朝向(包括夸2线段)
	    var getLineDir = function(index1, index2){	    	
	    	var lDir = new THREE.Vector2(line2d[index2].x, line2d[index2].y);
		    lDir.sub(line2d[index1]);
		    return new THREE.Vector3(lDir.y, -lDir.x, 0);
	    }    
	    
	    if (void 0 == holesModel || 0 == holesModel.length) {
	    	  //没有门洞
	        Array.prototype.push.apply(v, boundProfile);
	        f.push(0, 1, 2, 2, 3, 4);	        	        
	    }else {
	    	  //需要去掉门洞
	        var shape = new THREE.Shape(boundUVWProfile);
	        holesModel.forEach(function (hole) {
	            var uvwHolePos = utilThreeXYZ2UVW(hole, xyzOrig, lineDir);
	            var holeProfile = _utilThreeGetHoleProfileUVW(hole).map(function (pt) {
	                return {
	                    x: pt.x * hole.sx + uvwHolePos.x,
	                    y: pt.y * hole.sz + uvwHolePos.y,
	                    z: 0
	                };
	            });
	            holeProfiles.push(holeProfile);
	            holesPos.push(holeProfile.map(function (p) {
	                return utilThreeUVW2XYZ(p, xyzOrig, lineDir);
	            }));
	            shape.holes.push(new THREE.Shape(holeProfile));
	        });
	        var shapeGeom = shape.makeGeometry();
	        v = shapeGeom.vertices.map(function (vertex) {
	            return utilThreeUVW2XYZ(vertex, xyzOrig, lineDir);
	        }), shapeGeom.faces.forEach(function (face) {
	            f.push(face.a, face.b, face.c);
	        });
	    }
	    if (!ignoreUV) {
	    	for (var uvwOrig = xyzOrig, i = 0; i < v.length; i++) {
	        var vi = v[i];
	        var uvw = utilThreeXYZ2UVW(vi, uvwOrig, lineDir);
	        vt.push(new THREE.Vector2(uvw.x + vtX, uvw.y));
	      }
	    }
	    
	    buildDatas.push({
	        f: f,
	        fn: fn,
	        v: v,
	        vn: vn,
	        vt: vt,
	        b3d: boundProfile,
	        h3d: holesPos,
	        h2d: holeProfiles,
	        b2d: boundUVWProfile,
	        hmodel: holesModel,
	        o: xyzOrig
	    });
	    
	    vtX += utilMathLineLength(line2d[lineIndex], line2d[lineIndex+1]);
	  }
    
    return buildDatas;
}

function utilThreeTurn2DWallBuiltDataToSideWall(builtDatas, name, highlightMat, MeshMat) {
    var root = new THREE.Object3D();
    var faceGeom = new THREE.Geometry();
    faceGeom.vertices = [];
    
    var vectorNum = 0;
    builtDatas.forEach(function(builtData){
    	//v
    	faceGeom.vertices = faceGeom.vertices.concat(builtData.v);
    	
	    var uvs = faceGeom.faceVertexUvs[0];    
	    for (var i = 0; i < builtData.f.length / 3; i++){
	    	//f+normal
	    	faceGeom.faces.push(new THREE.Face3(builtData.f[3 * i] + vectorNum, builtData.f[3 * i + 1] + vectorNum, builtData.f[3 * i + 2] + vectorNum, builtData.fn[i]));
	    	//uv
	      uvs.push([builtData.vt[builtData.f[3 * i]], builtData.vt[builtData.f[3 * i + 1]], builtData.vt[builtData.f[3 * i + 2]]]);
	    }
	    
	    vectorNum = faceGeom.vertices.length;
    })  
    
    //融合顶点
    faceGeom.mergeVertices();
    faceGeom.computeFaceNormals();
    faceGeom.computeVertexNormals();    
    
    var mesh = new THREE.Mesh(faceGeom, MeshMat);
    mesh.name = name;
    mesh._rawData = builtDatas[0];//调整为第一个墙面(曲面有多个)
    mesh._rawDatas= builtDatas;
    root.add(mesh);
    if (highlightMat) {
        var outline = new THREE.Mesh(faceGeom, highlightMat);
        outline.name = name + "highlight";
        outline.visible = !1;
        outline.raycastable = !1;
        root.add(outline);
    }
    return root;
}

function utilThreeExtrude2dStoneLoop(line2d, wallWidth, holemodel) {
    var lineDir = new THREE.Vector2(line2d[1].x, line2d[1].y);
    lineDir.sub(line2d[0]);
    var xyzOrig = new THREE.Vector3(line2d[0].x, line2d[0].y, 0);
    var uvwHolePos = utilThreeXYZ2UVW(holemodel, xyzOrig, lineDir);
    var beginX = uvwHolePos.x - holemodel.meta.xlen*holemodel.sx/2;
    var endX = uvwHolePos.x + holemodel.meta.xlen*holemodel.sx/2;
    
    var beginPos1 = utilMathGetScaledPoint(line2d[0], line2d[1], beginX);
    var beginPos2 = utilMathGetScaledPoint(line2d[0], line2d[1], beginX + wallWidth/2);
    
    var endPos1 = utilMathGetScaledPoint(line2d[0], line2d[1], endX);
    var endPos2 = utilMathGetScaledPoint(line2d[0], line2d[1], endX + wallWidth/2);
    
    var rot = utilMathGetAngleHorizontaleCCW(line2d[1], line2d[0]);


    var stoneLoop = [];    
    stoneLoop.push(utilMathRotatePointCW(beginPos1, beginPos2, 90));
    stoneLoop.push(utilMathRotatePointCW(beginPos1, beginPos2, -90));
    stoneLoop.push(utilMathRotatePointCW(endPos1, endPos2, -90));
    stoneLoop.push(utilMathRotatePointCW(endPos1, endPos2, 90));
    
    return stoneLoop;
}
//通过墙体信息创建门槛石
function utilThreeCreateWallStone(view, profile, highlightMat, mat) {
	  var root = new THREE.Object3D(), faceGeom = new THREE.Geometry();
	  
    var p1 = profile[0]; //center
    var p2 = profile[3];

    var rot = utilMathGetAngleHorizontaleCCW(p1, p2);
    var loop = [];
    for (var pl = 0; pl < profile.length; ++pl) {
        var rotatedPoint = utilMathRotatePointCW(p1, profile[pl], -rot);
        loop.push(rotatedPoint);
    }

    var offset = 0;//2e-5 * (boundaryModel.level + 1) + zBias; 
    var meshMat = utilThreeViewCreateTileMaterial(view, mat, {});

    var areaShape = new THREE.Shape(loop);
    var areaGeom = areaShape.makeGeometry();

    var vertexMin = {
        x: 1e3,
        y: 1e3
    };
    for (var i = 0, len = areaGeom.vertices.length; len > i; ++i) {
        var vertex = areaGeom.vertices[i];
        var rotatedPoint = utilMathRotatePointCW(p1, vertex, rot);
        vertexMin.x = Math.min(vertexMin.x, vertex.x);
        vertexMin.y = Math.min(vertexMin.y, vertex.y);
        rotatedPoint && (vertex.x = rotatedPoint.x, vertex.y = rotatedPoint.y);
        vertex.z = offset;
    }

    areaGeom.faceVertexUvs[0].forEach(function (uvs) {
        Array.isArray(uvs) && uvs.forEach(function (uv) {
            uv.x -= vertexMin.x;
            uv.y -= vertexMin.y;
        });
    });
    var areaMesh = new THREE.Mesh(areaGeom, meshMat);
    areaMesh.name = "stone";    
    root.add(areaMesh);
    
    //highlight
    var highlightMesh = new THREE.Mesh(areaGeom, highlightMat);
    highlightMesh.name = "stonehighlight";    
    highlightMesh.position.z = 4e-5;
    highlightMesh.raycastable = !1;
    root.add(highlightMesh);    
    
    return root;
}
function utilThreeTurn2DWallBuiltDataToSideWallStone(builtData, name, highlightMat, MeshMat) {
    var root = new THREE.Object3D(), faceGeom = new THREE.Geometry();
    faceGeom.vertices = builtData.v;
    for (var uvs = faceGeom.faceVertexUvs[0], i = 0; i < builtData.f.length / 3; i++) faceGeom.faces.push(new THREE.Face3(builtData.f[3 * i], builtData.f[3 * i + 1], builtData.f[3 * i + 2], builtData.vn)),
        uvs.push([builtData.vt[builtData.f[3 * i]], builtData.vt[builtData.f[3 * i + 1]], builtData.vt[builtData.f[3 * i + 2]]]);
    var mesh = new THREE.Mesh(faceGeom, MeshMat);
    if (mesh.name = name, mesh._rawData = builtData, root.add(mesh), highlightMat) {
        var outline = new THREE.Mesh(faceGeom, highlightMat);
        outline.name = "highlight", outline.visible = !1, outline.raycastable = !1, root.add(outline);
    }
    return root;
}

function utilThreeGetPickRay(view, screenPt) {
    var raycaster = new THREE.Raycaster();
    view.getBoundingClientRect();
    return raycaster;
}

function utilThreePick(pickRay, root) {
}

function utilThreeSelectDisplayToPickResult(view, pickMgr, selectedDisplay, hitModelPt, hitScreenPt) {
    var model_info = utilThreeGetModelByMesh(view, selectedDisplay);
    model_info.model && utilPickMgrPick(pickMgr, model_info.model, {
        modelPos: hitModelPt,
        screenPos: hitScreenPt,
        src: "3d",
        elementName: model_info.sideName,
        side: model_info.side
    });
}

function utilThreeGetModelByMesh(view, mesh) {
    __assert(mesh instanceof THREE.Object3D);
    var model = void 0, sideName = mesh.name, side = mesh.side || "";
    return mesh.traverseAncestors(function (parent) {
        if (parent.did) {
            var display = view.dl[parent.did];
            display && (model = display.model);
        }
    }), {
        model: model,
        sideName: sideName,
        side: side
    };
}

var a,b,c;

function ThreeView(app, domElement, opt) {//透视摄像机
    this.layers = {};
    this.hammer = void 0;
    this.scene = void 0;
    this.sceneHelper = void 0;
    this.camera = new THREE.PerspectiveCamera(45, 1, .01, 20);

    this.Orcamera =new THREE.OrthographicCamera(window.innerWidth / -200., window.innerWidth / 200,
        window.innerHeight /200, window.innerHeight / -200, -10000, 10000);

    this.cameraOffset = {
        x: 0,
        y: 0
    };
    this.transformHelper = void 0;
    classBase(this, app, domElement, opt);
    this.mode = "default";
    a=app;
    b=domElement;
    c=opt;

}


function utilThreeViewSetTransformMode(view, mode) {
    view.transformHelper && (view.transformHelper.setMode(mode), view.dF = 1);
    console.log('14');
}


function utilThreeCreateLayers(rootLayers, whichScene, layers) {
    layers.forEach(function (layer) {
        var s = new THREE.Scene();
        s.name = layer, rootLayers[layer] = s, whichScene.add(rootLayers[layer]);
    });
}

function utilThreeBrowserSupportWebgl() {
    for (var contextName = ["webgl", "webkit-3d", "experimental-webgl", "moz-webgl"], gl = void 0, canvas = document.createElement("canvas"), i = 0, len = contextName.length; len > i; ++i) {
        try {
            gl = canvas.getContext(contextName[i]);
        } catch (e) {
        }
        if (void 0 != gl) return !0;
    }
    return !1;
}

function utilThreeBindHammerEvent(view) {
    function onEv(ev) {
        __log(ev.type);
    }

    function utilThreeHammerOnPan(view, evt, a, b, c) {
        switch (__log(evt.type), evt.type) {
            case "panstart":
                break;

            case "panmove":
                break;

            case "panend":
        }
    }

    function utilThreeHammerOnTap(view, evt, a, b, c) {
        var srcEvent = evt.srcEvent, screenPos = {
            x: srcEvent.pageX,
            y: srcEvent.pageY
        };
        utilThreeGetPickRay(view, screenPos);
    }

    function utilThreeHammerOnDoubleTap(view, evt, a, b, c) {
    }

    var mc = view.hammer;
    mc && (mc.add(new Hammer.Pan({
        threshold: 0,
        pointers: 0
    })), mc.add(new Hammer.Swipe()).recognizeWith(mc.get("pan")), mc.add(new Hammer.Rotate({
        threshold: 0
    })).recognizeWith(mc.get("pan")), mc.add(new Hammer.Pinch({
        threshold: 0
    })).recognizeWith([mc.get("pan"), mc.get("rotate")]), mc.add(new Hammer.Tap({
        event: "doubletap",
        taps: 2
    })), mc.add(new Hammer.Tap()), mc.on("panstart panmove panend", utilThreeHammerOnPan.bind(void 0, view)),
        mc.on("rotatestart rotatemove rotateend", onEv), mc.on("pinchstart pinchmove pinchend", onEv),
        mc.on("swipe", onEv), mc.on("tap", utilThreeHammerOnTap.bind(void 0, view)), mc.on("doubletap", utilThreeHammerOnDoubleTap.bind(void 0, view)),
        mc.on("hammer.input", function (ev) {
            ev.isFinal;
        }));
}

//3D视图下鼠标点击选中物体事件响应--gaoning
function utilThreeBindEvent(view, root) {
    var container = {
        dom: view.domElement,
        view: view
    };
    var objects = root;
    var pickMgr = view.app.pickMgr;
    var actionMgr = view.app.actionMgr;
    var raycaster = new THREE.Raycaster();
    var mouse = new THREE.Vector2();
    var getIntersects = function (point, object) {
        var camera = container.view.camera;
        return mouse.set(2 * point.x - 1, -(2 * point.y) + 1), raycaster.setFromCamera(mouse, camera),
            object instanceof Array ? raycaster.intersectObjects(object) : raycaster.intersectObject(object, !0);
    };
    var onDownPosition = new THREE.Vector2();
    var onUpPosition = new THREE.Vector2();
    var onDoubleClickPosition = (new THREE.Vector2(), new THREE.Vector2());
    var getMousePosition = function (dom, x, y) {
        var rect = dom.getBoundingClientRect();
        return [(x - rect.left) / rect.width, (y - rect.top) / rect.height];
    };
    pickMgr.pickChangedEvent.add(function (type) {
        "unselect" == type && view.transformHelper && view.transformHelper.detach();
    });
    //3D视图下鼠标点击选中物体事件响应--gaoning
    var handleClick = function (event) {
        //if (0 == onDownPosition.distanceTo(onUpPosition))
        if (0.003 >= onDownPosition.distanceTo(onUpPosition)) {  //允许鼠标点击时轻微移动 2017.3.21
            var intersects = getIntersects(onUpPosition, objects);
            if (utilPickMgrUnpickAll(pickMgr), intersects.length > 0) {
                for (var nearZ = view.camera.near, intersect = void 0, i = 0; i < intersects.length && !intersect; ++i) if (!(intersects[i].distance < nearZ)) {
                    for (var mesh = intersects[i].object, visible = mesh.visible, parent = mesh.parent; parent;)
                        visible = visible && parent.visible,
                            parent = parent.parent;
                    visible && (intersect = intersects[i]);
                }
                var object = intersect.object;
                //console.log(event);
                utilThreeSelectDisplayToPickResult(view, pickMgr, object, intersect.point, {
                    x: event.pageX,
                    y: event.pageY
                });
                var pickResult = utilPickMgrGetPickResults(application.pickMgr)[0];

                //console.log(pickResult.model.group);
                (pickResult.model instanceof Product || pickResult.model.type == VRHotspot.prototype.type) && view.transformHelper && view.transformHelper.attach(object);
                utilActionRun(actionMgr, "click3d", event, pickResult);
            }
        } else {
            //console.log(".............................");
            //console.log(event.type);
            utilActionRun(actionMgr, event.type + "3d", event);
        }
    }
    //3D视图下鼠标点击事件响应-gaoning
    var onMouseDown = function (event) {
        //test
        //console.log("MouseDown@@@@@");
        var pickObj = api.pickGetPicked(function (e) {
            return e;
        });
        if (pickObj.length > 0) {
            //console.log(pickObj[0].model);
            if (pickObj[0].model.group) {
                //console.log("++++++++++");
                //pickObj[0].model.group.x += 0.3;
                //pickObj[0].model.group.y += 0.3;
            }
        }

        event.preventDefault();
        var array = getMousePosition(container.dom, event.clientX, event.clientY);
        onDownPosition.fromArray(array), document.addEventListener("mouseup", onMouseUp, !1);
    };
    var onMouseMove = function (event) {
        return;
    };
    var onMouseUp = function (event) {
        var array = getMousePosition(container.dom, event.clientX, event.clientY);
        onUpPosition.fromArray(array);
        handleClick(event);
        //console.log(event);
        document.removeEventListener("mouseup", onMouseUp, !1);
    };
    var onTouchStart = function (event) {
        var touch = event.changedTouches[0], array = getMousePosition(container.dom, touch.clientX, touch.clientY);
        onDownPosition.fromArray(array), document.addEventListener("touchend", onTouchEnd, !1);
    };
    var onTouchEnd = function (event) {
        var touch = event.changedTouches[0], array = getMousePosition(container.dom, touch.clientX, touch.clientY);
        onUpPosition.fromArray(array), handleClick(event), document.removeEventListener("touchend", onTouchEnd, !1);
    };
    var onDoubleClick = function (event) {
        var array = getMousePosition(container.dom, event.clientX, event.clientY);
        onDoubleClickPosition.fromArray(array);
        var intersects = getIntersects(onDoubleClickPosition, objects);
        if (intersects.length > 0) {
            intersects[0];
        }
    };
    container && container.dom && (container.dom.addEventListener("mousedown", onMouseDown, !1),
        container.dom.addEventListener("mousemove", onMouseMove, !1), container.dom.addEventListener("touchstart", onTouchStart, !1),
        container.dom.addEventListener("dblclick", onDoubleClick, !1));
}

function utilThreeViewExport(view, format, option) {
    return "OBJ" == format ? utilThreeViewExportOBJ(view, option) : "JPG" == format || "JPEG" == format ? utilThreeViewExportJPG(view, option) : "ROOM3D" == format ? utilThreeViewExportRoom3D(view, option) : void 0;
}

function utilThreeViewExportRoom3D(view, option) {
    var room = option.model;
    if (!room) return __assert(room, "room should not be null"), [];
    var checkedInfos = [{
        model: room
    }], room3d = [], floorLoop = utilFloorGetLoopFromProfile(room), wallInfos = (utilFloorGetRoomInfo(application, room),
        room.profile.map(function (wall) {
            var wallMiddle = Vec2.lerp(wall.begin, wall.end, .5), middleTurnRight = utilMathRotatePointCW(wallMiddle, wall.begin, 90), middleTurnRightSmall = utilMathGetScaledPoint(wallMiddle, middleTurnRight, wall.width), side = utilMathIsPointInPoly(floorLoop, middleTurnRightSmall) ? "right" : "left";
            return {
                model: wall,
                sideName: side
            };
        }));
    return checkedInfos = checkedInfos.concat(wallInfos), checkedInfos.forEach(function (checkInfo) {
        utilThreeViewExportOBJ(view, {
            needEncode: !1,
            mesh_filter_fn: function (mesh, meshModelInfo) {
                if (meshModelInfo.model.id != checkInfo.model.id) return !1;
                if (checkInfo.sideName && checkInfo.sideName != meshModelInfo.sideName) return !1;
                var model = meshModelInfo.model, geom = mesh.geometry, faces = geom.faces.map(function (face) {
                    return [face.a, face.b, face.c];
                }), info = {
                    id: model.id,
                    type: model.type,
                    sideName: meshModelInfo.sideName,
                    v: geom.vertices,
                    f: faces
                };
                if (model.type == Wall.prototype.type) {
                    var rawData = mesh._rawData;
                    if (rawData) {
                        var edgeLoop = [rawData.b3d];
                        rawData.h3d.length > 0 && (edgeLoop = edgeLoop.concat(rawData.h3d));
                    }
                    info.e = edgeLoop;
                }
                return room3d.push(info), !1;
            }
        });
    }), room3d;
}

function utilThreeViewExportOBJ(view, option) {
    var lines = ["# Created by MVT exporter, on " + new Date().toUTCString(), "\n"];
    var vertexIndex = 0;
    var normalIndex = 0;
    var uvIndex = 0;
    var defaultGroupCount = 0;
    var tmpVec3 = new THREE.Vector3();
    var needEncode = option && option.encode;
    var keepGroup = option && 1 == option.keep_group;
    var mesh_filter_fn = option && option.mesh_filter_fn;
    [Wall.prototype.type, Floor.prototype.type, Area.prototype.type, Cube.prototype.type, Boundary.prototype.type].forEach(function (layerId) {
        if (view) {
            var layer = view.layers[layerId];
            layer.traverseVisible(function (child) {
                if ("Mesh" == child.type && -1 == child.name.indexOf("highlight")) {
                    var modelInfo = utilThreeGetModelByMesh(view, child);
                    var model = modelInfo.model;
                    if (!mesh_filter_fn || mesh_filter_fn(child, modelInfo) !== !1) {
                        var material = model[modelInfo.sideName + "Material"];
                        var defaultMat = model.type == Area.prototype.type ? DEFAULT_AREA_MATERIAL[model.category] : DEFAULT_TILE_MATERIAL_ID, tileSingleId = "";
                        
                        if(material && material.type == TileSingle.prototype.type && !material.ignoreUV){                        	
                        	tileSingleId = utilMakeMD5(utilTileSingleGetUrl(material, !1));
                        }else if(material && material.type == Parquet.prototype.type){
                        	tileSingleId = utilMakeMD5(material.getUrl(void 0, void 0, !1));
                        }else if(material && material.type == MaterialRawColor.prototype.type){
                        	tileSingleId = utilMakeMD5(utilMaterialRawColorGetUrl(material, !1));
                        }
                        
                        var groupName = model.id + "_" + (material ? material.id : "") + "_" + (material ? material.pid : defaultMat) + "_" + modelInfo.sideName + "_" + tileSingleId + "_" + defaultGroupCount++, vertexCount = 0, normalCount = 0, uvCount = 0, mesh = child;
                        lines.push("\ng " + (keepGroup ? groupName : "group_" + defaultGroupCount));
                        var geometry = mesh.geometry;
                        if (__log("export obj: " + modelInfo.sideName + " - " + geometry.type), geometry && geometry instanceof THREE.Geometry) {
                            for (var i = 0, l = geometry.vertices.length; l > i; i++) {
                                var vertex = geometry.vertices[i];
                                vertex = tmpVec3.copy(vertex).applyMatrix4(mesh.matrixWorld), lines.push("v " + vertex.x + " " + vertex.y + " " + vertex.z),
                                    vertexCount++;
                            }
                            for (var i = 0, l = geometry.faceVertexUvs[0].length; l > i; i++) for (var vertexUvs = geometry.faceVertexUvs[0][i], j = 0; j < vertexUvs.length; j++) {
                                var uv = vertexUvs[j];
                                lines.push("vt " + uv.x + " " + uv.y), uvCount++;
                            }                            
                            
                          	for (var i = 0, l = geometry.faces.length; l > i; i++) {                          		
                          		if(geometry.faces[i].vertexNormals.length > 0){
                          			//添加独立法线支持
                          			geometry.faces[i].vertexNormals.forEach(function(normal){
                          				lines.push("vn " + normal.x + " " + normal.y + " " + normal.z);
                          				normalCount++;
                          			});
                          		}else{
                          			var normal = geometry.faces[i].normal;
                                lines.push("vn " + normal.x + " " + normal.y + " " + normal.z);
                                normalCount++;
                          		}                                                              
                            }
                            
                            for (var i = 0, j = 1, l = geometry.faces.length; l > i; i++, j += 3) {
                                var face = geometry.faces[i], _face = "f ";
                                if(geometry.faces[i].vertexNormals.length > 0){
                                	_face += vertexIndex + face.a + 1 + "/" + (uvIndex + j) + "/" + (normalIndex + 1 + 3 * i) + " ";
                                  _face += vertexIndex + face.b + 1 + "/" + (uvIndex + j + 1) + "/" + (normalIndex + 2 + 3 * i) + " ";
                                  _face += vertexIndex + face.c + 1 + "/" + (uvIndex + j + 2) + "/" + (normalIndex + 3 + 3 * i) + " ";
                                }else{
                                	_face += vertexIndex + face.a + 1 + "/" + (uvIndex + j) + "/" + (normalIndex + 1 + i) + " ";
                                  _face += vertexIndex + face.b + 1 + "/" + (uvIndex + j + 1) + "/" + (normalIndex + 1 + i) + " ";
                                  _face += vertexIndex + face.c + 1 + "/" + (uvIndex + j + 2) + "/" + (normalIndex + 1 + i) + " ";
                                }                                
                                lines.push(_face);
                            }
                        } else if (geometry && "BufferGeometry" == geometry.type) {
                            var v = geometry.getAttribute("position"), vn = geometry.getAttribute("normal"), vt = geometry.getAttribute("uv");
                            if (!v || !vn || !vt) return;
                            for (var vBuffer = v.array, vnBuffer = vn.array, vtBuffer = vt.array, i = 0, len = v.length, itemSize = v.itemSize; len / itemSize > i; ++i) {
                                var vx = vBuffer[3 * i], vy = vBuffer[3 * i + 1], vz = vBuffer[3 * i + 2], vnx = vnBuffer[3 * i], vny = vnBuffer[3 * i + 1], vnz = vnBuffer[3 * i + 2], vtu = vtBuffer[2 * i], vtv = vtBuffer[2 * i + 1], vertex = new THREE.Vector3(vx, vy, vz), normal = new THREE.Vector3(vnx, vny, vnz), uv = new THREE.Vector2(vtu, vtv), worldMatrix = mesh.matrixWorld, normalMatrix = new THREE.Matrix3().getNormalMatrix(worldMatrix), uvScale = mesh.material.scUniform3||[1,1];
                                vertex.applyMatrix4(worldMatrix), normal.applyMatrix3(normalMatrix), uv.x *= uvScale[0],
                                    uv.y *= uvScale[1], lines.push("v " + vertex.x + " " + vertex.y + " " + vertex.z),
                                    vertexCount++, lines.push("vn " + normal.x + " " + normal.y + " " + normal.z), normalCount++,
                                    lines.push("vt " + uv.x + " " + uv.y), uvCount++;
                            }
                            for (var i = 0; i < v.length / 9; ++i) {
                                var _face = "f ";
                                _face += vertexIndex + 3 * i + 1 + "/" + (uvIndex + 3 * i + 1) + "/" + (normalIndex + 1 + 3 * i) + " ",
                                    _face += vertexIndex + 3 * i + 2 + "/" + (uvIndex + 3 * i + 2) + "/" + (normalIndex + 2 + 3 * i) + " ",
                                    _face += vertexIndex + 3 * i + 3 + "/" + (uvIndex + 3 * i + 3) + "/" + (normalIndex + 3 + 3 * i) + " ",
                                    lines.push(_face);
                            }
                        }
                        vertexIndex += vertexCount, uvIndex += uvCount, normalIndex += normalCount;
                    }
                }
            });
        }
    });
    var content = lines.join("\n");
    return 1 == needEncode ? Base64.e(content) : content;
}

function utilThreeViewExportJPG(view, option) {
    var imageDataUri = view.domElement.toDataURL("image/jpeg", option && option.quality || .8);
    return option && utilImageResize(imageDataUri, option.width, option.height, option.quality || .8, option.keepRatio || !0, option.onSuccess, option.onError),
        imageDataUri;
}

function DisplayThreeCamera(modelObject, view) {
    this.threeCamera = view.camera, this.cameraController = void 0, this.transformHelper = void 0,
        classBase(this, modelObject, view);
}

function utilThreeCameraFlyFitView(view) {
    console.log(view);
    var fp = view.doc.floorplan, camera = utilFloorplanGetActiveCamera(fp);
    if ("cameraFly" == camera.id) {
       // console.log(camera);
        var cameraDir = {
            x: camera.tx - camera.x,
            y: camera.ty - camera.y
        }, fpBound = utilFloorplanGetBound(fp);
        if (utilBoundIsValid(fpBound)) {
            var center = fpBound.center(), radius = fpBound.radius();
            camera.tx = center.x, camera.ty = center.y;
            var cameraPos = Vec2.difference(center, utilMathGetScaledPoint({
                x: 0,
                y: 0
            }, cameraDir, 2 * radius));
            camera.x = cameraPos.x, camera.y = cameraPos.y, camera.pitch = -30;
        }
    }
}




function _utilThreeDisplayElementGetMesh(threeObject) {
    var meshes = [];
    return threeObject.traverse(function (child) {
        "Mesh" != child.type && "Line" != child.type || meshes.push(child);
    }), meshes;
}

function _utilDisposeResource(threeObject) {
    _utilThreeDisplayElementGetMesh(threeObject).forEach(function (mesh) {
        mesh.parent.remove(mesh), mesh.geometry.dispose();
    });
}

/*
 function DisplayThreeFloor
 */

function DisplayThreeProduct(modelObject, view) {
    this.boundDisplay = void 0;
    classBase(this, modelObject, view);
    this.layer = this.model.type;
}

function DisplayThreeProductReplacement(modelObject, view) {
    classBase(this, modelObject, view);
    this.layer = Product.prototype.type;
}

function utilCreateReplaceMaterialWithLightMap(view, mat, opt, completeCallback) {
}

function DisplayThreeCube(modelObject, view) {
    this.boundDisplay = void 0;
    classBase(this, modelObject, view);
    this.layerName = Cube.prototype.type;
    /*if ("PILLAR" == modelObject.meta.type)
     this.layerName = Pillar.prototype.type;
     else if ("BEAM" == modelObject.meta.type)
     this.layerName = Beam.prototype.type;
     else if ("BASEMENT" == modelObject.meta.type)
     this.layerName = Basement.prototype.type;
     else
     this.layerName = Cube.prototype.type;
     */
    this.objRoot = void 0;
}

function utilThreeCreateCube(displayCube) {
    var view = displayCube.view, model = displayCube.model, cube3d = (view.doc.floorplan,
        new THREE.Object3D());
    cube3d.position.set(model.x, model.y, model.z), cube3d.setRotationFromAxisAngle(new THREE.Vector3(0, 0, 1), model.rot * Math.PI / 180),
        cube3d.scale.set(model.sx, model.sy, model.sz), cube3d.updateMatrix();
    var boundMatrix = new THREE.Matrix4(), boxGeom = new THREE.BoxGeometry(1, 1, 1), boundMesh = new THREE.Mesh(boxGeom);
    boundMesh.applyMatrix(boundMatrix);
    var boundDisplay = displayCube.boundDisplay = new THREE.BoxHelper(boundMesh);
    boundDisplay.material.color = new THREE.Color(15707904), boundDisplay.name = "highlight",
        boundDisplay.visible = !0, boundDisplay.raycastable = !1, boundDisplay.updateMatrix(),
        cube3d.add(boundDisplay);
    var mat = new THREE.MeshBasicMaterial({
        color: 15790144,
        transparent: !0,
        opacity: .5
    });
    new THREE.Mesh(boxGeom, mat);
    return cube3d;
}

function DisplayThreeVRHotspot(modelObject, view) {
    this.boundDisplay = void 0, classBase(this, modelObject, view), this.layer = this.model.type;
}

var utilThreeBuildExtrudeMesh = function () {
    var tmp = new THREE.Vector3(), v0 = new THREE.Vector3(), v1 = new THREE.Vector3(), v2 = new THREE.Vector3();
    return function (rightProfile, extrudeDepth, name, meshMat, opt) {
        var root = new THREE.Object3D();
        __assert(rightProfile.length >= 3);
        var faceGeom = new THREE.Geometry();
        v0.copy(rightProfile[0]), v1.copy(rightProfile[1]), v2.copy(rightProfile[2]);
        for (var dir = v2.sub(v1).cross(v1.sub(v0)).normalize().setLength(extrudeDepth), uv = faceGeom.faceVertexUvs[0], i = 0; i < rightProfile.length - 1; ++i) {
            var start = rightProfile[i], end = rightProfile[i + 1], rightstart = new THREE.Vector3(start.x, start.y, start.z), rightend = new THREE.Vector3(end.x, end.y, end.z), extrudestart = rightstart.clone().add(dir), extrudeend = rightend.clone().add(dir), len = tmp.copy(start).sub(end).length(), rightstartUV = new THREE.Vector2(0, 0), rightendUV = new THREE.Vector2(0, len), extrudestartUV = new THREE.Vector2(extrudeDepth, 0), extrudeendUV = new THREE.Vector2(extrudeDepth, len);
            faceGeom.vertices.push(rightstart, rightend, extrudeend, extrudestart), faceGeom.faces.push(new THREE.Face3(4 * i, 4 * i + 1, 4 * i + 2)),
                faceGeom.faces.push(new THREE.Face3(4 * i + 2, 4 * i + 3, 4 * i)), uv.push([rightstartUV, rightendUV, extrudeendUV], [extrudeendUV, extrudestartUV, rightstartUV]);
        }
        faceGeom.computeFaceNormals();
        var mesh = new THREE.Mesh(faceGeom, meshMat);
        return mesh.name = name, root.add(mesh), root;
    };
}();

ThreeView.prototype.type = "ThreeView", classInherit(ThreeView, BaseView);

var DEFAULT_3D_VIEW_SETTINGS = {
    showIESProductLayer: !0
}, VIEW_VR_EYE_DISTANCE = .08;

utilExtend(ThreeView.prototype, {
    clear: function () {
        classBase(this, "clear"), utilExtend(this.settings, DEFAULT_3D_VIEW_SETTINGS);
    },
    changeSettings: function (settingKey, settingValue) {
        classBase(this, "changeSettings", settingKey, settingValue), this.layers.IES.visible = this.settings.showIESProductLayer === !0,
            this.layers.FILLLIGHT.visible = this.settings.showIESProductLayer === !0, this.dF = 1;
    },
    createContextInternal: function () {
        var option = {
            canvas: this.domElement,
            antialias: !0,
            preserveDrawingBuffer: !0
        }, supportWebgl = utilThreeBrowserSupportWebgl();
        if (__assert(1 == supportWebgl, "webgl not support."), supportWebgl) {
            var renderer = this.domElement ? new THREE.WebGLRenderer(option) : void 0;
            if (renderer) {
                renderer.setClearColor(0x808080), renderer.autoClear = !1;
                var bounds = this.getBoundingClientRect();
                renderer.setSize(bounds.width, bounds.height, !1);
            }
            return renderer;
        }
    },
    _updateAllCameras: function () {
        var allCameras = utilFloorplanGetCamerasName(this.doc.floorplan);
        allCameras.forEach(function (cameraName) {
            this.dl[cameraName] && this.dl[cameraName].update();
        }, this);
    },
    fit: function (opt) {
        classBase(this, "fit"), opt && void 0 !== opt.mode && (this.mode = opt.mode);
        var bounds = opt && opt.width && opt.height ? {
            width: opt.width,
            height: opt.height
        } : this.getBoundingClientRect();
        this.context && (this.context.setSize(bounds.width, bounds.height, !1), this.update(!0));
    },
    init: function () {
        classBase(this, "init"), this.hammer = "undefined" != typeof Hammer && this.domElement ? new Hammer.Manager(this.domElement) : void 0;
        this.scene = new THREE.Scene();
        /*setting DirectionalLight of making distinction between wall
        * added by mdx 2017/7/24
        * */
        var defaultLight = new THREE.DirectionalLight(16777215, .2);
        defaultLight.position.set(-5, -10, 8);
        var defaultLight2 = new THREE.DirectionalLight(16777215, .2);
        defaultLight2.position.set(5, 10, 8);
        this.scene.add(new THREE.HemisphereLight(16777215, 16777215, .8));
        this.scene.add(defaultLight);
        this.scene.add(defaultLight2);
        this.sceneHelper = new THREE.Scene();
        this.opt.helpers === !0 && (this.transformHelper = new THREE.TransformControls(this.camera, this.domElement), this.sceneHelper.add(this.transformHelper));
        utilThreeCreateLayers(this.layers, this.scene,
            ["Background",
                //add by gaoning
                Pillar.prototype.type,
                Beam.prototype.type,
                Basement.prototype.type,
                
                Floor.prototype.type,       //地面
                Boundary.prototype.type,    //波打线
                Area.prototype.type,        //自定义区域
                Wall.prototype.type,
                Product.prototype.type,
                Cube.prototype.type,
                "IES",
                "FILLLIGHT",
                Opening.prototype.type,
                Windows.prototype.type,
                Door.prototype.type,
                VRHotspot.prototype.type,
                "Temp"]);

        utilThreeBindHammerEvent(this);
        utilThreeBindEvent(this, this.scene);
    },
    createDO: function (modelObject) {
        //console.log("!@@@@sdssfsfs");
        return modelObject.type == Camera.prototype.type ? new DisplayThreeCamera(modelObject, this) : 
        modelObject.type == Product.prototype.type ? new DisplayThreeProduct(modelObject, this) : 
        modelObject.type == ProductReplacement.prototype.type ? new DisplayThreeProductReplacement(modelObject, this) : 
        modelObject.type == Wall.prototype.type ? new DisplayThreeWall(modelObject, this) : 
        modelObject.type == Floor.prototype.type ? new DisplayThreeFloor(modelObject, this) : 
        modelObject.type == Opening.prototype.type ? new DisplayThreeOpening(modelObject, this) : 
        modelObject.type == Door.prototype.type ? new DisplayThreeDoor(modelObject, this) : 
        modelObject.type == Windows.prototype.type ? new DisplayThreeWindow(modelObject, this) : 
        modelObject.type == FreeArea.prototype.type || modelObject.type == RoundArea.prototype.type || modelObject.type == RectArea.prototype.type ? new DisplayThreeFloorArea(modelObject, this) : 
        modelObject.type == RoundArea3d.prototype.type || 
        modelObject.type == RectArea3d.prototype.type || 
        modelObject.type == Baseboard.prototype.type || 
        modelObject.type == Wallboard.prototype.type ? new DisplayThreeWallArea(modelObject, this) : modelObject instanceof Cube ? new DisplayThreeCube(modelObject, this) : 
        modelObject.type == VRHotspot.prototype.type ? new DisplayThreeVRHotspot(modelObject, this) : 
        modelObject.type == Boundary.prototype.type ? new DisplayThreeBoundary(modelObject, this) :
        //add by gaoning--2017.3.21
        //== Pillar.prototype.type ? new DisplayThreeCube(modelObject, this) : modelObject.type
        //== Beam.prototype.type ? new DisplayThreeCube(modelObject, this) : modelObject.type
        //== Basement.prototype.type ? new DisplayThreeCube(modelObject, this) : modelObject.type
        //== Cube.prototype.type ? new DisplayThreeCube(modelObject, this) : modelObject.type
        void 0;
    },
    onUpdate: function (isForce, opt) {
        var needUpdate = classBase(this, "onUpdate");
        if (!this.context) return !1;
        var renderer = this.context;
        if ("vr" === this.mode) {
            var size = this.domElement.getClientRects()[0], halfWidth = size.width / 2;
            renderer.clear(), renderer.enableScissorTest(!0), this.cameraOffset.x = -.5 * VIEW_VR_EYE_DISTANCE,
                this._updateAllCameras(), renderer.setViewport(0, 0, halfWidth, size.height), renderer.setScissor(0, 0, halfWidth, size.height),
            this.scene && renderer.render(this.scene, this.camera), this.cameraOffset.x = .5 * VIEW_VR_EYE_DISTANCE,
                this._updateAllCameras(), renderer.setViewport(halfWidth, 0, halfWidth, size.height),
                renderer.setScissor(halfWidth, 0, halfWidth, size.height), this.scene && renderer.render(this.scene, this.camera),
                renderer.enableScissorTest(!1);
        } else (isForce === !0 || this.context && 1 == needUpdate) && (this.cameraOffset.x = 0,
            this._updateAllCameras(),
            renderer.clear(),
            //__log("-----  update 3d view.");
            this.scene && renderer.render(this.scene, this.camera),
            renderer.clear(!1, !0, !1),
            this.sceneHelper && renderer.render(this.sceneHelper, this.camera));
    },
    resetFontSize: function(){
    	//...
    }
});
/*3d 读取图片到场景
 *TODO 产品，拼花读取图片跟踪，这里返回了产品的图片路径 mat.getUrl-2017-03-27
 *http://localhost:63342/3dyun/editorui/src/index.html?brand=oceano
 * 如果brand为oceano时，执行mat.getUrl()后(实际方法是->return utilMaterialGetUrl(this);在model.comp.js)
 * 方法会被重置为--> utilCatalogGetFileUrl = oceanoUtilCatalogGetFileUrl --> 主体在misc.footer.js，读取了 阿里云oss 的资源 域名是pic.oceano.com.cn 那个；
 * 否则使用原来的 utilCatalogGetFileUrl 获取服务器本地文件；在 app.comp.js
 * 2017-04-07
 * add by oxl
 * */
 //砖图
var utilThreeViewCreateTileMaterial = function () {
    var texturesCache = {};
    var tileCache = {};
    var default_material_count = 0;
    return THREE.ImageUtils.crossOrigin = "anonymous", function (view, mat, opt, completeCallback) {
        var cMgr = application.catalogMgr;
        var fp = view.doc.floorplan;
        var pid = mat ? mat.pid : DEFAULT_TILE_MATERIAL_ID;
        var cache_tile_key = view.id + (mat ? mat.id : "DEFAULT_MATERIAL");// + default_material_count++); 
               
        var textureUrl = mat && mat.getThreeUrl ? mat.getThreeUrl() : utilCatalogGetFileUrl(cMgr, "product", pid, "top");
        var textureMat = tileCache[cache_tile_key];
        if(textureMat){
        	textureMat = textureMat.clone();        	
        }else{
        	textureMat = new THREE.MeshPhongMaterial({
            transparent: !1
          });
          textureMat.side = THREE.DoubleSide;
          tileCache[cache_tile_key] = textureMat;
        }
        __log("load texture:" + textureUrl);
        /*加载了2次，两次，在canvas.three.comp.js -> 关键代码 0 != (1 & this.dF) */
        utilCatalogGetProductsMetaPromise(cMgr, [pid]).then(function (data) {
            return new Promise(function (resolve, reject) {
                var proId = Object.keys(data)[0];
                var meta = data[proId] || {
                        xlen: 1,
                        ylen: 1
                    };
                var cache_texture = texturesCache[textureUrl];
                if (cache_texture) {
                    textureMat.map = cache_texture;
                    fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN); 
                    resolve({
                        meta: meta,
                        texture: cache_texture
                    });
                } else {
                    var loader = new THREE.TextureLoader();
				            loader.crossOrigin = "anonymous";
				            var texture = loader.load(textureUrl, function (t) {
				                t.wrapS = t.wrapT = THREE.RepeatWrapping;
                        t.repeat.set(1 / parseFloat(meta.xlen), 1 / parseFloat(meta.ylen));
                        t.needsUpdate = !0;
                        fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);                        
                        resolve({
                            meta: meta,
                            texture: t
                        });
				            }, void 0, function (err) {
				                log(err);
				            });
				            texturesCache[textureUrl] = texture;
				            textureMat.map = texture;
                }
            });
        }).then(function (o) {
            var sx = mat && mat.sx || 1;
            var sy = mat && mat.sy || 1;
            var matScale = mat && mat.getScale ? mat.getScale() : {
                x: sx,
                y: sy
            };
            textureMat.scUniform1 = [utilMathToRadius(mat && -mat.rot || 0), mat && mat.tx || 0, mat && mat.ty || 0, 0];
            textureMat.scUniform2 = [matScale.x, matScale.y, 0, 0];
            textureMat.needsUpdate = !0;
            completeCallback && completeCallback(o.meta, textureMat, o.texture);
            fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
        });
        return textureMat;
    };
}();
//paveTile屏蔽了正常的纹理缩放和旋转，偏移等等处理
var utilThreeViewCreatePaveTileMaterial = function () {
    var texturesCache = {};
    var tileCache = {};
    var default_material_count = 0;
    return THREE.ImageUtils.crossOrigin = "anonymous", function (view, mat, opt, completeCallback) {
        var cMgr = application.catalogMgr;
        var fp = view.doc.floorplan;
        var pid = mat ? mat.pid : DEFAULT_TILE_MATERIAL_ID;
        var cache_tile_key = view.id + (mat ? mat.id : "DEFAULT_MATERIAL");// + default_material_count++);
        var textureUrl = "";
        if(mat && mat.getUrl){
        	if(mat.type == Parquet.prototype.type || mat.type == TileSingle.prototype.type){
        		textureUrl = mat.getUrl(256);
        	}else{
        		textureUrl = mat.getUrl("3d");
        	}
        }else{
        	textureUrl = utilCatalogGetFileUrl(cMgr, "product", pid, "top");
        	//textureUrl+= "@128h.jpg";
        }
        
        var textureMat = tileCache[cache_tile_key];
        textureMat ? textureMat = textureMat.clone() : (textureMat = new THREE.MeshPhongMaterial({
            transparent: !1
        }), textureMat.side = THREE.DoubleSide, tileCache[cache_tile_key] = textureMat)
        __log("load texture:" + textureUrl);
        /*加载了2次，两次，在canvas.three.comp.js -> 关键代码 0 != (1 & this.dF) */
        utilCatalogGetProductsMetaPromise(cMgr, [pid]).then(function (data) {
            return new Promise(function (resolve, reject) {
                var proId = Object.keys(data)[0];
                var meta = data[proId] || {
                        xlen: 1,
                        ylen: 1
                    };
                var cache_texture = texturesCache[textureUrl];
                if (cache_texture) {
                    textureMat.map = cache_texture;
                    fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
                    resolve({
                        meta: meta,
                        texture: cache_texture
                    });
                } else {                    
                    var loader = new THREE.TextureLoader();
				            loader.crossOrigin = "anonymous";
				            var texture = loader.load(textureUrl, function (t) {
				                t.wrapS = t.wrapT = THREE.RepeatWrapping;
                        t.repeat.set(1 / parseFloat(meta.xlen), 1 / parseFloat(meta.ylen));
                        t.needsUpdate = !0;
                        fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);                        
                        resolve({
                            meta: meta,
                            texture: t
                        });
				            }, void 0, function (err) {
				                log(err);
				            });
				            texturesCache[textureUrl] = texture;
				            textureMat.map = texture;
                }
            });
        }).then(function (o) {
            var sx = mat && mat.sx || 1;
            var sy = mat && mat.sy || 1;
            var matScale = mat && mat.getScale ? mat.getScale() : {
                x: sx,
                y: sy
            };
            textureMat.scUniform1 = [utilMathToRadius(0), 0, 0, 0];
            textureMat.scUniform2 = [1, 1, 0, 0];
            textureMat.needsUpdate = !0;
            completeCallback && completeCallback(o.meta, textureMat, o.texture);
            fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
        });
        return textureMat;
    };
}();
//加载obj模型纹理
utilThreeViewLoadTexturePromise = function () {
	  var texturesCache = {};
    return function (view, pid) {
        var cache_pid = view.id + pid;
        var catalogMgr = view.app.catalogMgr;
        var fp = view.doc.floorplan;
        if(texturesCache[cache_pid]){
        	fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
        	return Promise.resolve(texturesCache[cache_pid]);
        }else{
	        	return new Promise(function (resolve, reject) {
	            //var url = utilCatalogGetFileUrl(catalogMgr, "product", pid, "texture");
	            //var postfix = url.substring(url.lastIndexOf("."));
	            //url += "@128h"+postfix;
	            var url = "https://pic.oceano.com.cn/h5filesystem/products/" + pid + "/product.png@256h.png";
	            var loader = new THREE.TextureLoader();
	            loader.crossOrigin = "anonymous";
	            var texture = loader.load(url, function (t) {
	                t.wrapS = t.wrapT = THREE.RepeatWrapping;
	                t.needsUpdate = !0;
	                t.url = url;
	                fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
	                resolve(t);
	            }, void 0, function (err) {
	                resolve();
	            });
	            texturesCache[cache_pid] = texture; 
	        });
	      }
    };
}();

utilThreeViewLoadObjPromise = function () {/*3d obj LoadObjPromise add by oxl 2017-04-07，要跟踪一下*/
    var modelCache = {};
    return function (view, pid) {
        var cache_pid = view.id + pid;
        var catalogMgr = view.app.catalogMgr;
        var fp = view.doc.floorplan;
        if (modelCache[cache_pid]) {
            return Promise.resolve(modelCache[cache_pid]);
        } else {
            return utilCatalogGetFileContentPromise(catalogMgr, "product", pid, "obj").then(function (data) {
                var loader = new THREE.OBJLoader({});
                var node = loader.parse(data);
                modelCache[cache_pid] = node;
                fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
                return Promise.resolve(modelCache[cache_pid]);
            });
        }
    };
}();
utilThreeViewLoadFlipObjPromise = function () {
    //加载镜像模型
    var modelFlipCache = {};
    return function (view, pid) {
        var cache_pid = view.id + pid;
        var catalogMgr = view.app.catalogMgr;
        var fp = view.doc.floorplan;
        if (modelFlipCache[cache_pid]) {
            return Promise.resolve(modelFlipCache[cache_pid]);
        } else {
            return utilCatalogGetFileContentPromise(catalogMgr, "product", pid, "obj").then(function (data) {
                var loader = new THREE.OBJLoader({});
                var node = loader.parse(data);
                modelFlipCache[cache_pid] = node;

                node.traverse(function (child) {
                    if (child instanceof THREE.Mesh) {
                        child.geometry.applyMatrix(new THREE.Matrix4().makeScale(-1, 1, 1));
                    }
                });


                fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
                return Promise.resolve(modelFlipCache[cache_pid]);
            });
        }
    };
}();

classInherit(DisplayThreeCamera, DisplayObject), utilExtend(DisplayThreeCamera.prototype, {
    create: function () {
        if (this.model.propertyChangedEvent.add(function (propertyName) {
                this.dF = 1;
            }.bind(this)), this.view.opt.helpers === !0) {
            var dom = this.view.domElement;
            if (!dom) return;
            this.cameraController = new THREE.EditorControls(this.threeCamera, dom, this), this.transformHelper = this.view.transformHelper,
                this.transformHelper.setDisplayView(this.view), this.transformHelper.setCameraController(this.cameraController);
        }
        this.update();
    },
    update: function () {
        if(this.model.lock){
            return;
        }
        if (0 != this.model.active) {
            this.transformHelper && this.transformHelper.setCameraController(this.cameraController);
            var cameraModel = this.model, clientBound = this.view.getBoundingClientRect(), aspectRatio = clientBound.width / clientBound.height;
            "vr" == this.view.mode && (aspectRatio /= 2), this.threeCamera.aspect = aspectRatio;
            var hfov = cameraModel.hfov, vfov = THREE.Math.radToDeg(2 * Math.atan(Math.tan(.5 * THREE.Math.degToRad(hfov)) / aspectRatio));
            this.threeCamera.fov = vfov, this.threeCamera.near = cameraModel.znear, "cameraFly" == cameraModel.id && (this.threeCamera.far = 50),
                this.threeCamera.updateProjectionMatrix(), this.threeCamera.up.set(0, 0, 1);
            var pos = {
                x: this.model.x,
                y: this.model.y,
                z: this.model.z
            }, dir = new THREE.Vector2();
            dir.subVectors({
                x: this.model.tx,
                y: this.model.ty
            }, {
                x: this.model.x,
                y: this.model.y
            });
            var zOffset = Math.tan(THREE.Math.degToRad(this.model.pitch)) * dir.length(), target = {
                x: this.model.tx,
                y: this.model.ty,
                z: this.model.z + zOffset
            }, offsetDir = dir.clone().setLength(this.view.cameraOffset.x);
            pos.x += offsetDir.x, pos.y += offsetDir.y, target.x += offsetDir.x, target.y += offsetDir.y,
                this.threeCamera.position.set(pos.x, pos.y, pos.z), this.threeCamera.lookAt(target),
                this.threeCamera.updateMatrixWorld(!0), this.cameraController && this.cameraController.center.copy(target);
            application.allCameraInit()
        }
    },
    destroy: function () {
    }
}), classInherit(DisplayThreeProduct, DisplayObject);

var displayThreeProductOBJLoadingCompleteFlag = 65536, displayThreeProductTextureLoadingCompleteFlag = 1 << 17;

utilExtend(DisplayThreeProduct.prototype, {
    create: function () {
        classBase(this, "create");
        var model = (application.catalogMgr, this.model);
        var subCategory = model.meta && model.meta.subcategory ? model.meta.subcategory.toUpperCase() : void 0;
        if ("IES" == subCategory ? this.layer = "IES" : "FILLLIGHT" == subCategory && (this.layer = "FILLLIGHT"),
            void 0 == this.de) {
            this.de = new THREE.Object3D();
            this.de.did = this.id;
            var boundMatrix = new THREE.Matrix4();
            boundMatrix.setPosition({
                x: 0,
                y: 0,
                z: this.model.meta.zlen / 2
            });
            var boundMesh = new THREE.Mesh(new THREE.BoxGeometry(this.model.meta.xlen, this.model.meta.ylen, this.model.meta.zlen));
            boundMesh.applyMatrix(boundMatrix);
            this.boundDisplay = new THREE.BoxHelper(boundMesh);
            /*TODO 遮罩的颜色 -2017-03-27*/
            this.boundDisplay.material.color = new THREE.Color(15707904);
            this.boundDisplay.name = "highlight";
            this.boundDisplay.visible = !0;
            this.boundDisplay.raycastable = !1;
            this.de.add(this.boundDisplay);
        }
        this.view.layers[this.layer].add(this.de);
        this.model.propertyChangedEvent.add(function (propertyName, oldValue, newValue) {
            this.dF |= 1, "flag" == propertyName && (this.dF |= 2);
        }.bind(this));
        this.loadModelInternal();
    },
    loadModelInternal: function () {
        var view = this.view;
        var pid = this.model.pid;
        var displayElement = this.de;
        var model = this.model;
        var boundDisplay = this.boundDisplay;
        utilModelSetFlagOff(model, displayThreeProductOBJLoadingCompleteFlag);
        utilModelSetFlagOff(model, displayThreeProductTextureLoadingCompleteFlag);

        var loadObjFunction = utilThreeViewLoadObjPromise;
        displayElement.flip = false;

        if (model.flip) {
            loadObjFunction = utilThreeViewLoadFlipObjPromise;
            displayElement.flip = true;
        }

        loadObjFunction(view, pid).then(function (threeMesh) {
            if (displayElement.mainMesh) {
                displayElement.remove(displayElement.mainMesh);
            }
            displayElement.mainMesh = threeMesh.clone();
            displayElement.add(displayElement.mainMesh);
            displayElement.position.set(model.x, model.y, model.z + .004);
            displayElement.updateMatrix();
            boundDisplay.visible = !1;
            utilModelSetFlagOn(model, displayThreeProductOBJLoadingCompleteFlag);
            return utilThreeViewLoadTexturePromise(view, pid);
        }).then(function (threeTexture) {
            displayElement.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                    if (child.material instanceof THREE.MeshBasicMaterial)
                        return;
                    child.material = new THREE.MeshBasicMaterial();
                    child.material.map = threeTexture;
                    child.material.scUniform2 = [1, 1, 0, 0];
                    if (this.model.flip) {
                        child.material.side = THREE.BackSide;
                    }
                    child.material.needsUpdate = !0;
                    -1 == child.name.toLowerCase().indexOf("shadow") && -1 == child.name.toLowerCase().indexOf("glass") && -1 == child.name.toLowerCase().indexOf("transparent") && -1 == child.name.toLowerCase().indexOf("environment") || (child.material.transparent = !0);
                }
            }.bind(this));
            utilModelSetFlagOn(model, displayThreeProductTextureLoadingCompleteFlag);
        }.bind(this));
    },
    setFlip: function () {
        this.loadModelInternal();
    },
    update: function () {
        var displayElement = this.de;
        var model = (application.catalogMgr, this.model);
        this.view;
        model.pid;

        var flipElement = function (displayElement, model) {
            if (model.flip) {
                if (displayElement.flip != true) {
                    this.setFlip();
                }
            } else {
                if (displayElement.flip == true) {
                    this.setFlip();
                }
            }
        }.bind(this);   //初始化Product的Transform--gaoning

        0 != (1 & this.dF) && (displayElement.position.set(this.model.x, this.model.y, this.model.z + .004),
            displayElement.setRotationFromAxisAngle(new THREE.Vector3(0, 0, 1), this.model.rot * Math.PI / 180),

            //设置物体的初始值 add by gaoning 2017.4.29
            displayElement.rotateX(this.model.rotx * Math.PI / 180),
            displayElement.rotateY(this.model.roty * Math.PI / 180),
            //displayElement.rotateZ(this.model.rotz * Math.PI / 360),
            this.model.rotz = this.model.rot,
            this.model.quaternion_x = parseFloat(displayElement.getWorldQuaternion().x),
            this.model.quaternion_y = parseFloat(displayElement.getWorldQuaternion().y),
            this.model.quaternion_z = parseFloat(displayElement.getWorldQuaternion().z),
            this.model.quaternion_w = parseFloat(displayElement.getWorldQuaternion().w),
            //console.log(displayElement.getWorldQuaternion()),
            //console.log(displayElement.getWorldRotation()),
            displayElement.scale.set(this.model.sx, this.model.sy, this.model.sz),
            displayElement.updateMatrix(),
            flipElement(displayElement, this.model));
        0 != (2 & this.dF) && (this.boundDisplay && (this.boundDisplay.visible = utilModelIsFlagOn(this.model, MODELFLAG_PICKED)),
            this.de.visible = utilModelIsFlagOff(this.model, MODELFLAG_HIDDEN));
    },
    destroy: function () {
        this.view.layers[this.layer].remove(this.de);
    }
}), classInherit(DisplayThreeProductReplacement, DisplayThreeProduct), utilExtend(DisplayThreeProductReplacement.prototype, {
    create: function () {
        classBase(this, "create");
        var updateFun = function (propertyName, oldValue, newValue) {
            -1 != propertyName.indexOf("Material") && (this.dF |= 4);
        }.bind(this), linkPropertyChangedFun = function (property, linksOp, changeFrom, changeTo) {
            this.model;
            property instanceof MaterialRawColor ? this.dF |= 4 : property instanceof Material && (this.dF |= 8);
        }.bind(this);
        this.model.propertyChangedEvent.add(updateFun);
        this.model.linksChangedEvent.add(updateFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    loadModelInternal: function () {
        var view = this.view,
            pid = this.model.pid,
            displayElement = this.de,
            model = this.model,
            boundDisplay = this.boundDisplay,
            catalogMgr = this.view.app.catalogMgr;
        utilModelSetFlagOff(model, displayThreeProductOBJLoadingCompleteFlag),
            utilModelSetFlagOff(model, displayThreeProductTextureLoadingCompleteFlag);
        var realworldUVNode = {};
        utilCatalogGetFileContentPromise(catalogMgr, "product", pid, "product_re.obj").then(function (data) {
            if (data) {
                var loader = new THREE.OBJLoader({}),
                    node = loader.parse(data);
                realworldUVNode = node;
            }
            return utilCatalogGetFileContentPromise(catalogMgr, "product", pid, "obj");
        }).then(function (data) {
            var loader = new THREE.OBJLoader({});
            var threeMesh = loader.parse(data);
            displayElement.add(threeMesh.clone());
            displayElement.position.set(model.x, model.y, model.z + .004);
            displayElement.updateMatrix();
            displayElement.flip = this.model.flip;
            boundDisplay.visible = !1;
            if (displayElement.flip)
                this.setFlip();
            utilModelSetFlagOn(model, displayThreeProductOBJLoadingCompleteFlag)
            utilThreeViewLoadTexturePromise(view, pid);
        }.bind(this)).then(function (threeTexture) {
            displayElement.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                    var elementName = child.name;
                    var mat = model[elementName + "Material"];
                    if (mat) {
                        var realUV = realworldUVNode.getObjectByName(elementName).geometry.getAttribute("uv"), bakedUV = child.geometry.getAttribute("uv");
                        realUV && (child.geometry.addAttribute("uv", realUV), child.geometry.addAttribute("uv2", bakedUV)),
                            child.material = utilThreeViewCreateTileMaterial(view, mat, void 0, function (meta, mat, texture) {
                                utilModelSetFlagOn(model, displayThreeProductTextureLoadingCompleteFlag);
                            }), child.material.aoMap = threeTexture, child.material.aoMapIntensity = 1, child.material.needsUpdate = !0;
                    } else {
                        child.material = new THREE.MeshBasicMaterial(), child.material.map = threeTexture;
                        if (this.model.flip)
                            child.material.side = THREE.BackSide;
                    }
                }
            }.bind(this));
        }.bind(this));
    },
    setFlip: function () {
        var displayElement = this.de;
        displayElement.flip = this.model.flip;
        if (this.model.flip) {
            displayElement.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                    child.geometry.applyMatrix(new THREE.Matrix4().makeScale(-1, 1, 1));
                    if (child.material)
                        child.material.side = THREE.BackSide;
                }
            });
        } else {
            displayElement.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                    child.geometry.applyMatrix(new THREE.Matrix4().makeScale(-1, 1, 1));
                    if (child.material)
                        child.material.side = THREE.FrontSide;
                }
            });
        }
    },
    update: function () {
        classBase(this, "update");
        var displayElement = this.de, model = (application.catalogMgr, this.model), view = this.view, fp = (model.pid,
        model.meta && model.meta.extra && JSON.parse(model.meta.extra), view.doc.floorplan);
        0 != (4 & this.dF) && displayElement.traverse(function (child) {
            if (child instanceof THREE.Mesh) {
                var elementName = child.name, mat = model[elementName + "Material"];
                if (mat) {
                    var savedLightMap = child.material.aoMap;
                    child.material = utilThreeViewCreateTileMaterial(view, mat, void 0, function () {
                        child.material.aoMap = savedLightMap, child.material.aoMapIntensity = 1, child.material.needsUpdate = !0;
                    });
                }
            }
        }), 0 != (8 & this.dF) && displayElement.traverse(function (child) {
            if (child instanceof THREE.Mesh) {
                var elementName = child.name, mat = model[elementName + "Material"];
                if (mat) {
                    var textureMat = child.material, sx = mat && mat.sx || 1, sy = mat && mat.sy || 1, matScale = mat && mat.getScale ? mat.getScale() : {
                        x: sx,
                        y: sy
                    };
                    textureMat.scUniform1 = [utilMathToRadius(mat && -mat.rot || 0), mat && mat.tx || 0, mat && mat.ty || 0, 0];
                    textureMat.scUniform2 = [matScale.x, matScale.y, 0, 0]; 
                    textureMat.needsUpdate = !0;
                    if (mat.type == Parquet.prototype.type) {
		                    if (textureMat.map) {
		                        var textureUrl = mat.getThreeUrl();
		                        textureMat.map.image.src = textureUrl;
		                    }
		                }
                    //fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
                }
            }
        });
    }
}), classInherit(DisplayThreeCube, DisplayObject), utilExtend(DisplayThreeCube.prototype, {
    create: function () {
        classBase(this, "create");
        var model = this.model;
        if (void 0 == this.de) {
            this.de = new THREE.Object3D();
            this.de.did = this.id;
            var boundMatrix = new THREE.Matrix4();
            boundMatrix.setPosition({
                x: 0,
                y: 0,
                z: this.model.meta.zlen / 2
            });
            var boundMesh = new THREE.Mesh(new THREE.BoxGeometry(this.model.meta.xlen, this.model.meta.ylen, this.model.meta.zlen));
            boundMesh.applyMatrix(boundMatrix);
            this.boundDisplay = new THREE.BoxHelper(boundMesh);
            this.boundDisplay.material.color = new THREE.Color(15707904);
            this.boundDisplay.name = "highlight";
            this.boundDisplay.visible = !0;
            this.boundDisplay.raycastable = !1;
            this.de.add(this.boundDisplay);
        }
        this.view.layers[this.layerName].add(this.de);
        var propChangedFun = function (propertyName, oldValue, newValue) {
            "flag" == propertyName ? (oldValue & MODELFLAG_HIDDEN)
            != (newValue & MODELFLAG_HIDDEN) ? this.dF
                |= 256 : this.dF |= 256 : "sx"
            == propertyName || "sy"
            == propertyName || "sz"
            == propertyName ? (this.dF |= 2, this.dF |= 1024) : -1
            != propertyName.indexOf("Material") ? this.dF
                |= CUBE_MATERIAL_SIDE_META[propertyName][0] : "faceHiddenFlag"
            == propertyName ? this.dF |= 256 : this.dF |= 2;
        }.bind(this), linkPropertyChangedFun = function (property, linksOp, changeFrom, changeTo) {
            var model = this.model;
            if (property instanceof Material)
                for (var mid in CUBE_MATERIAL_SIDE_META)
                    model[mid] && property.id == model[mid].id && (this.dF |= CUBE_MATERIAL_SIDE_META[mid][0]);
        }.bind(this);
        this.model.propertyChangedEvent.add(propChangedFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
        var view = this.view;
        var pid = this.model.pid;
        var self = this;
        var displayElement = this.de;
        var model = this.model;
        var boundDisplay = this.boundDisplay;        
        utilThreeViewLoadObjPromise(view, pid).then(function (threeMesh) {
            var root = self.objRoot = threeMesh.clone();
            displayElement.add(root);
            displayElement.position.set(model.x, model.y, model.z - .004);
            displayElement.updateMatrix();
            boundDisplay.visible = !1;
            return root;
        }).then(function (root) {
            return root.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                    var matSide = child.name + "Material";
                    child.material = utilThreeViewCreateTileMaterial(view, model[matSide], {}, function (meta, mat, texture) {
                        child.material.needsUpdate = !0;
                    });
                }
            }), self.dF |= 1024, root;
        }).then(function (root) {
        });
    },
    update: function () {
        var displayElement = this.de, pickMgr = this.view.app.pickMgr, model = this.model;
        if (0 != (256 & this.dF)) {
            this.boundDisplay && (this.boundDisplay.visible = utilModelIsFlagOn(this.model, MODELFLAG_PICKED));
            var pick = utilPickMgrGetPickResults(pickMgr)[0], isPick = pick && pick.model.id == this.model.id, pickSide = pick && pick.opt && pick.opt.elementName;
            displayElement.visible = utilModelIsFlagOff(this.model, MODELFLAG_HIDDEN), this.objRoot && this.objRoot.traverse(function (child) {
                if (child instanceof THREE.Mesh) {
                    if (CUBE_MATERIAL_SIDE_META[child.name + "Material"]) {
                        var isHiddenFace = 0 != (model.faceHiddenFlag & CUBE_MATERIAL_SIDE_META[child.name + "Material"][0]);
                        child.visible = !isHiddenFace;
                    }
                    var c = isPick && child.name == pickSide ? .15 : 0;
                    child.material.color.setRGB(c + 1, c + 1, 1), child.material.needsUpdate = !0;
                }
            });
        }
        0 != (1024 & this.dF) && this.objRoot && this.objRoot.traverse(function (child) {
            if (child instanceof THREE.Mesh) {
                var matSide = child.name + "Material", mat3d = child.material, meta = CUBE_MATERIAL_SIDE_META[matSide], uScale = meta ? model["s" + meta[1]] : 1, vScale = meta ? model["s" + meta[2]] : 1;
                mat3d.scUniform3 = [uScale, vScale, 0, 0];
            }
        }), 0 != (2 & this.dF) && (displayElement.position.set(this.model.x, this.model.y, this.model.z - .004),
            displayElement.setRotationFromAxisAngle(new THREE.Vector3(0, 0, 1), this.model.rot * Math.PI / 180),
            displayElement.scale.set(this.model.sx, this.model.sy, this.model.sz), displayElement.updateMatrix());
        for (var mid in CUBE_MATERIAL_SIDE_META) if (0 != (this.dF & CUBE_MATERIAL_SIDE_META[mid][0])) {
            var root = this.objRoot;
            if (root) {
                __log("Three Cube: update or recreate " + mid);
                var mat = this.model[mid], view = this.view, model = this.model;
                root.traverse(function (child) {
                    if (child instanceof THREE.Mesh) {
                        var matSide = child.name + "Material";
                        matSide == mid && (child.material = utilThreeViewCreateTileMaterial(view, mat, {}, function (tileMeta, mat, tex) {
                            var mat3d = child.material, meta = CUBE_MATERIAL_SIDE_META[matSide], uScale = meta ? model["s" + meta[1]] : 1, vScale = meta ? model["s" + meta[2]] : 1;
                            mat3d.scUniform3 = [uScale, vScale, 0, 0], mat3d.needsUpdate = !0;
                        }));
                    }
                });
            }
        }
    },
    destroy: function () {
        this.view.layers[this.layerName].remove(this.de);
    }
}), classInherit(DisplayThreeVRHotspot, DisplayObject);

var SNAP_VRHOTSPOT_IMG_3D = {
    url: "asset/imgSnap/hotspot_3d.png",
    width: 99,
    height: 150
};

utilExtend(DisplayThreeVRHotspot.prototype, {
    create: function () {
        classBase(this, "create");
        var model = this.model;
        model.meta && model.meta.subcategory ? model.meta.subcategory.toUpperCase() : void 0;
        if (this.model.propertyChangedEvent.add(function (propertyName) {
                this.dF |= 1, "flag" == propertyName && (this.dF |= 2);
            }.bind(this)), void 0 == this.de) {
            this.de = new THREE.Object3D(), this.de.did = this.id;
            var geometry = new THREE.Geometry(), vertex = new THREE.Vector3(0, 0, 0);
            geometry.vertices.push(vertex);
            var sprite = THREE.ImageUtils.loadTexture(SNAP_VRHOTSPOT_IMG_3D.url), material = new THREE.PointCloudMaterial({
                size: 1,
                map: sprite,
                alphaTest: .5,
                transparent: !0,
                wireframe: !0
            });
            material.color.setHSL(1, .2, .7);
            var hotspot = new THREE.PointCloud(geometry, material);
            this.de.add(hotspot), this.de.position.set(this.model.x, this.model.y, this.model.z);
        }
        this.view.layers[this.layer].add(this.de);
        var model = (this.view, this.model.pid, this.de, this.model);
        this.boundDisplay;
    },
    update: function () {
        var displayElement = this.de;
        0 != (1 & this.dF) && (displayElement.position.set(this.model.x, this.model.y, this.model.z),
            displayElement.updateMatrix()), 0 != (2 & this.dF) && this.boundDisplay;
    },
    destroy: function () {
        this.view.layers[this.layer].remove(this.de);
    }
});