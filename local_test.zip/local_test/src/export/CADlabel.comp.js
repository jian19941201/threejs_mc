/**
 * Created by gn on 2017/7/12.
 */
(function (root) {
    var lineContext;
    var centerPoint;
    var leftTop;
    var leftBottom;
    var rightTop;
    var rightBottom;
    var horizontalMin, horizontalMax;
    var verticalMin, verticalMax;


    //尺寸显示
    var showDimensionLayer = true;
    root.setDimensionLayer = function (active) {
        showDimensionLayer = active;
    }
    root.getDimensionLayer = function () {
        return showDimensionLayer;
    }

    // 显示房间信息
    var showRoomLabel = true;
    root.setRoomLabel = function (active) {
        showRoomLabel = active;
    }
    root.getRoomLabel = function () {
        return showRoomLabel;
    }

    //显示文字标注
    var showTextAnnotation = true;
    root.setTextAnnotation = function (active) {
        showTextAnnotation = active;
    }
    root.getTextAnnotation = function () {
        return showTextAnnotation;
    }

    //显示房间信息外标识
    var showOutRoomLabel = true;
    root.setOutRoomLabel = function (active) {
        showOutRoomLabel = active;
    }
    root.getOutRoomLabel = function () {
        return showOutRoomLabel;
    }

    //显示外墙尺寸标识
    var showOutLabel = true;
    root.setOutLabel = function (active) {
        showOutLabel = active;
    }
    root.getOutLabel = function () {
        return showOutLabel;
    }

    var wallLinesArr = new Array();
    root.getCADWallLines = function () {
        return wallLinesArr;
    }

    //自定义墙的类型
    function WallLabel(begin, end, points) {
        this.begin = begin;
        this.end = end;
        this.points = points;
    }

    var topRoomInfoArr = new Array();
    root.getTopRoomInfoArr = function () {
        return topRoomInfoArr;
    }
    var bottomRoomInfoArr = new Array();
    root.getBottomRoomInfoArr = function () {
        return bottomRoomInfoArr;
    }

    //清理队列
    function ClearArr(arr) {
        arr.splice(0, arr.length);
    }

    root.InitCADData = function () {

        //初始化数据
        ClearArr(topRoomInfoArr);
        ClearArr(bottomRoomInfoArr);
        ClearArr(wallLinesArr);
        //清理房间名称
        pidNameDic.clear();
        pidNumberDic.clear();

        lineContext = utilAppGetViewById(application, "2d").context;
        //初始化房间产品数据
        InitPidName();
        var hWallArr = new Array();//记录所有墙的数据，包括begin\end
        var vWallArr = new Array();//记录所有墙的数据，包括begin\end
        var pointArr = new Array();//记录所有墙的坐标点，用于求户型中心点。
        var hPointArr = new Array();//记录横向的墙的坐标点
        var vPointArr = new Array();//记录竖向的墙的坐标点
        var wallLineArr = new Array();//记录所有墙，起点和终点，用于做房间标识
        var pointArr2 = new Array();//记录所有墙，起点和终点，用于做房间标识
        var hWallLineArr = new Array();//记录横向的外墙
        var vWallLineArr = new Array();//记录竖向的外墙
        var bomData = api.getBomData();
        api.catalogGetProductsMetaPromise(bomData.pids).then(function (meta) {
            api.snapExport("JSON", function (content) {
                bomData.rooms.forEach(function (roomInfo) {

                    roomInfo.walls.forEach(function (walls) {
                        //记录所有房间的墙的起点和终点
                        //var lineTwo = new Array();
                        var p1 = new Vec2(walls.begin.x, walls.begin.y);
                        var p2 = new Vec2(walls.end.x, walls.end.y);
                        pointArr2.push(p1);
                        pointArr2.push(p2);
                        //var wallLine = new Line(walls.begin.x * 1000, walls.begin.y * 1000, walls.end.x * 1000, walls.end.y * 1000);
                        var wallLine = new Line(walls.begin.x, walls.begin.y, walls.end.x, walls.end.y);
                        wallLineArr.push(wallLine);

                        var wallPointArr = new Array();
                        walls.wallLoop.forEach(function (posList) {
                            posList.forEach(function (line) {
                                //记录所有墙的顶点，每个墙有四个点,先去除中间两点没用的点。
                                var v = new Vec2(line.X, line.Y);
                                wallPointArr.push(v);
                            });
                        });
                        //删除墙的无用坐标数据
                        //分别记录横向和墙和竖向的墙
                        var point = new Vec2(walls.end.x - walls.begin.x, walls.end.y - walls.begin.y);
                        var angle = Math.atan2(point.y, point.x) / Math.PI * 180;
                        if ((angle > 45 && angle < 135) || (angle > -135 && angle < -45)) {//竖向
                            var w = new WallLabel();
                            w.begin = walls.begin;
                            w.end = walls.end;
                            var points = new Array();
                            for (var i = 0; i < wallPointArr.length; i++) {
                                if (i != 0 && i != 3) { //删除墙的无用坐标数据
                                    vPointArr.push(wallPointArr[i]);
                                    //pointArr.push(wallPointArr[i]);
                                    points.push(wallPointArr[i]);
                                    var wallLine = new Line(walls.begin.x, walls.begin.y, walls.end.x, walls.end.y);
                                    if (!CheckLineArray(wallLine, vWallLineArr)) {
                                        vWallLineArr.push(wallLine);
                                        //console.log("左右墙");
                                    }
                                }
                            }
                            w.points = points;
                            //保存到列表
                            vWallArr.push(w);

                        } else {//横向
                            var w = new WallLabel();
                            w.begin = walls.begin;
                            w.end = walls.end;
                            var points = new Array();
                            for (var i = 0; i < wallPointArr.length; i++) {
                                if (i != 0 && i != 3) { //删除墙的无用坐标数据
                                    hPointArr.push(wallPointArr[i]);
                                    //pointArr.push(wallPointArr[i]);
                                    points.push(wallPointArr[i]);
                                    var wallLine = new Line(walls.begin.x, walls.begin.y, walls.end.x, walls.end.y);
                                    if (!CheckLineArray(wallLine, hWallLineArr)) {
                                        hWallLineArr.push(wallLine);
                                        //console.log("上下墙");
                                    }
                                }
                            }
                            w.points = points;
                            //保存到列表
                            hWallArr.push(w);
                        }
                    });
                });
            });
        });

        //房间信息标注
        //var pointArr2 = new Array();//记录所有墙的坐标点，用于求户型中心点。
        var hPointArr2 = new Array();//记录横向的墙的坐标点
        var vPointArr2 = new Array();//记录竖向的墙的坐标点

        var topPointArr2 = new Array();//记录横向的墙的坐标点
        var bottomPointArr2 = new Array();//记录竖向的墙的坐标点
        var leftPointArr2 = new Array();//记录横向的墙的坐标点
        var rightPointArr2 = new Array();//记录竖向的墙的坐标点

        //保存数据，用来做标注间距离的判断,做错位显示功能--add by 2017.7.22
        var topLabelArr = new Array();
        var topLabelDic = new Dictionary();
        var bottomLabelArr = new Array();
        var bottomLabelDic = new Dictionary();

        //选择房间中最长的墙用来显示标签add by gaoning 2017.8.9
        var roomIndex = 0;
        var roomIndexArr = new Array();
        var roomIndexDic = new Dictionary();

        api.catalogGetProductsMetaPromise(bomData.pids).then(function (meta) {
            api.snapExport("JSON", function (content) {
                bomData.rooms.forEach(function (roomInfo) {
                    var roomName = roomInfo.label;
                    var measurement = roomInfo.measurementLabel;
                    var pid = roomInfo.floorMaterial.pid;
                    var productName = GetNameFromPid(pid);
                    var productNumber = GetNumberFromPid(pid);

                    roomIndex++;

                    var isReadWall = false;  //确保只画一次
                    var roomPos2 = new Array();
                    roomInfo.walls.forEach(function (walls) {

                        //添加曲线墙
                        if(walls.bezier){
                            var bezi = new Vec2(walls.bezier.x, walls.bezier.y);
                            var begin = new Vec2(walls.begin.x, walls.begin.y);
                            var end = new Vec2(walls.end.x, walls.end.y);
                            for (var p = 0; p < 20; ++p) {
                                var ps = utilMathBerzier(begin, bezi, end, p/19);
                                var vec = new Vec2(ps.x * 1000, ps.y * 1000);
                                pointArr.push(vec);
                            }
                        }

                        var begin = new Vec2(walls.begin.x, walls.begin.y);
                        roomPos2.push(begin);
                        var end = new Vec2(walls.end.x, walls.end.y);
                        roomPos2.push(end);

                        walls.wallLoop.forEach(function (posList) {
                            posList.forEach(function (line) {
                                //记录当前房间墙的顶点，每个墙有四个点,先去除中间两点没用的点。
                                //var v = new Vec2(line.X, line.Y);
                            });
                        });
                        var point = new Vec2(walls.end.x - walls.begin.x, walls.end.y - walls.begin.y);
                        var angle = Math.atan2(point.y, point.x) / Math.PI * 180;
                        //当前墙的中心坐标
                        var centerPoint2 = new Vec2((walls.end.x + walls.begin.x) / 2, (walls.end.y + walls.begin.y) / 2);
                        if ((angle > 45 && angle < 135) || (angle > -135 && angle < -45)) {//竖向

                            //##222
                            //判断是否为外墙
                            // 判断从中心坐标起上下两边有没有其他墙，如果有则不是外墙
                            //足够长的线段
                            //1.查看向上是否有其他墙
                            var checkCross = false;
                            var checkCrossIndex = 0;
                            var p1 = new Vec2(centerPoint2.x - 0.1, centerPoint2.y);
                            var p2 = new Vec2(centerPoint2.x + 50, centerPoint2.y);
                            //#11上下比较，同时被引用于做房间标识
                            for (var i = 0; i < vWallLineArr.length; i++) {
                                var p3 = new Vec2(vWallLineArr[i].x0, vWallLineArr[i].y0);
                                var p4 = new Vec2(vWallLineArr[i].x1, vWallLineArr[i].y1);

                                checkCross = LineCrossCheck(p1, p2, p3, p4);
                                if (checkCross) {
                                    checkCrossIndex++;
                                }
                            }
                            if (checkCrossIndex < 2) {
                                //console.log("右方没有墙");
                                for (var i = 0; i < 6; i++) {
                                    if (i != 1 && i != 3) {
                                        var vec = new Vec2(walls.wallLoop[0][i].X, walls.wallLoop[0][i].Y);
                                        if (!CheckArray(vec, vPointArr2)) {
                                            vPointArr2.push(vec);
                                            pointArr.push(vec);
                                        }
                                    }
                                }
                                // 此墙为右外墙，开始查找与这个墙相交的墙的的坐标点。并且是向右的坐标点
                                for (var i = 0; i < hWallArr.length; i++) {
                                    var p1 = new Vec2(walls.begin.x, AddLength(walls.begin.y, 0.1, walls.end.y));
                                    var p2 = new Vec2(walls.end.x, AddLength(walls.end.y, 0.1, walls.begin.y));
                                    var p3 = new Vec2(AddLength(hWallArr[i].begin.x, 0.1, hWallArr[i].end.x), hWallArr[i].begin.y);
                                    var p4 = new Vec2(AddLength(hWallArr[i].end.x, 0.1, hWallArr[i].begin.x), hWallArr[i].end.y);
                                    var check = LineCrossCheck(p1, p2, p3, p4);
                                    if (check) {
                                        var vecs = GetLeftRight(hWallArr[i].points);
                                        if (getSamePointY(rightPointArr2, vecs[2]) && getSamePointY(rightPointArr2, vecs[3])) {
                                            rightPointArr2.push(vecs[2]);
                                            rightPointArr2.push(vecs[3]);
                                        }
                                    }
                                }

                            } else { //2.查看向下是否有其他墙
                                checkCrossIndex = 0;
                                checkCross = false;
                                p1 = new Vec2(centerPoint2.x + 0.1, centerPoint2.y);
                                p2 = new Vec2(centerPoint2.x - 50, centerPoint2.y);
                                for (var i = 0; i < vWallLineArr.length; i++) {
                                    var p3 = new Vec2(vWallLineArr[i].x0, vWallLineArr[i].y0);
                                    var p4 = new Vec2(vWallLineArr[i].x1, vWallLineArr[i].y1);
                                    checkCross = LineCrossCheck(p1, p2, p3, p4);
                                    if (checkCross) {
                                        checkCrossIndex++;
                                    }
                                }
                                if (checkCrossIndex < 2) {
                                    //console.log("左方没有墙");
                                    for (var i = 0; i < 6; i++) {
                                        if (i != 1 && i != 3) {
                                            var vec = new Vec2(walls.wallLoop[0][i].X, walls.wallLoop[0][i].Y);
                                            if (!CheckArray(vec, vPointArr2)) {
                                                vPointArr2.push(vec);
                                                pointArr.push(vec);
                                            }
                                        }
                                    }

                                    // 此墙为左外墙，开始查找与这个墙相交的墙的的坐标点。并且是向右的坐标点
                                    for (var i = 0; i < hWallArr.length; i++) {
                                        //处理：墙的长度加长才能保证顺利对接碰撞
                                        var p1 = new Vec2(walls.begin.x, AddLength(walls.begin.y, 0.1, walls.end.y));
                                        var p2 = new Vec2(walls.end.x, AddLength(walls.end.y, 0.1, walls.begin.y));
                                        var p3 = new Vec2(AddLength(hWallArr[i].begin.x, 0.1, hWallArr[i].end.x), hWallArr[i].begin.y);
                                        var p4 = new Vec2(AddLength(hWallArr[i].end.x, 0.1, hWallArr[i].begin.x), hWallArr[i].end.y);
                                        var check = LineCrossCheck(p1, p2, p3, p4);
                                        if (check) {
                                            var vecs = GetLeftRight(hWallArr[i].points);
                                            if (getSamePointY(leftPointArr2, vecs[0]) && getSamePointY(leftPointArr2, vecs[1])) {
                                                leftPointArr2.push(vecs[0]);
                                                leftPointArr2.push(vecs[1]);
                                            }
                                        }
                                    }
                                }
                            }
                            //##222
                        } else {//横向

                            //##000
                            //判断是否为外墙
                            // 判断从中心坐标起上下两边有没有其他墙，如果有则不是外墙
                            //足够长的线段
                            //1.查看向上是否有其他墙
                            var checkCross = false;
                            var checkCrossIndex = 0;
                            var p1 = new Vec2(centerPoint2.x, centerPoint2.y - 0.1);
                            var p2 = new Vec2(centerPoint2.x, centerPoint2.y + 50);
                            //#11上下比较，同时被引用于做房间标识
                            for (var i = 0; i < hWallLineArr.length; i++) {
                                var p3 = new Vec2(hWallLineArr[i].x0, hWallLineArr[i].y0);
                                var p4 = new Vec2(hWallLineArr[i].x1, hWallLineArr[i].y1);

                                checkCross = LineCrossCheck(p1, p2, p3, p4);
                                if (checkCross) {
                                    checkCrossIndex++;
                                }
                            }
                            if (checkCrossIndex < 2) {
                                //console.log("上方没有墙");
                                for (var i = 0; i < 6; i++) {
                                    if (i != 1 && i != 3) {
                                        var vec = new Vec2(walls.wallLoop[0][i].X, walls.wallLoop[0][i].Y);
                                        if (!CheckArray(vec, hPointArr2)) {
                                            hPointArr2.push(vec);
                                            pointArr.push(vec);
                                        }
                                    }
                                }

                                // 此墙为上外墙，开始查找与这个墙相交的墙的的坐标点。并且是向右的坐标点
                                for (var i = 0; i < vWallArr.length; i++) {
                                    //处理：墙的长度加长才能保证顺利对接碰撞
                                    var p1 = new Vec2(AddLength(walls.begin.x, 0.1, walls.end.x), walls.begin.y);
                                    var p2 = new Vec2(AddLength(walls.end.x, 0.1, walls.begin.x), walls.end.y);
                                    var p3 = new Vec2(vWallArr[i].begin.x, AddLength(vWallArr[i].begin.y, 0.1, vWallArr[i].end.y));
                                    var p4 = new Vec2(vWallArr[i].end.x, AddLength(vWallArr[i].end.y, 0.1, vWallArr[i].begin.y));
                                    var check = LineCrossCheck(p1, p2, p3, p4);
                                    if (check) {
                                        var vecs = GetTopBottom(vWallArr[i].points);
                                        if (getSamePointX(topPointArr2, vecs[2]) && getSamePointX(topPointArr2, vecs[3])) {
                                            topPointArr2.push(vecs[2]);
                                            topPointArr2.push(vecs[3]);
                                        }
                                    }
                                }

                            } else { //2.查看向下是否有其他墙
                                checkCrossIndex = 0;
                                checkCross = false;
                                p1 = new Vec2(centerPoint2.x, centerPoint2.y + 0.1);
                                p2 = new Vec2(centerPoint2.x, centerPoint2.y - 50);
                                for (var i = 0; i < hWallLineArr.length; i++) {
                                    var p3 = new Vec2(hWallLineArr[i].x0, hWallLineArr[i].y0);
                                    var p4 = new Vec2(hWallLineArr[i].x1, hWallLineArr[i].y1);
                                    checkCross = LineCrossCheck(p1, p2, p3, p4);

                                    if (checkCross) {
                                        checkCrossIndex++;
                                    }
                                }
                                if (checkCrossIndex < 2) {
                                    //console.log("下方没有墙");
                                    for (var i = 0; i < 6; i++) {
                                        if (i != 1 && i != 3) {
                                            var vec = new Vec2(walls.wallLoop[0][i].X, walls.wallLoop[0][i].Y);
                                            if (!CheckArray(vec, hPointArr2)) {
                                                hPointArr2.push(vec);
                                                pointArr.push(vec);
                                            }

                                        }
                                    }

                                    // 此墙为下外墙，开始查找与这个墙相交的墙的的坐标点。并且是向右的坐标点
                                    for (var i = 0; i < vWallArr.length; i++) {
                                        //处理：墙的长度加长才能保证顺利对接碰撞
                                        var p1 = new Vec2(AddLength(walls.begin.x, 0.1, walls.end.x), walls.begin.y);
                                        var p2 = new Vec2(AddLength(walls.end.x, 0.1, walls.begin.x), walls.end.y);
                                        var p3 = new Vec2(vWallArr[i].begin.x, AddLength(vWallArr[i].begin.y, 0.1, vWallArr[i].end.y));
                                        var p4 = new Vec2(vWallArr[i].end.x, AddLength(vWallArr[i].end.y, 0.1, vWallArr[i].begin.y));
                                        var check = LineCrossCheck(p1, p2, p3, p4);
                                        if (check) {
                                            var vecs = GetTopBottom(vWallArr[i].points);
                                            if (getSamePointX(bottomPointArr2, vecs[0]) && getSamePointX(bottomPointArr2, vecs[1])) {
                                                bottomPointArr2.push(vecs[0]);
                                                bottomPointArr2.push(vecs[1]);
                                            }
                                        }
                                    }
                                }
                            }
                            //##000

                            //获取房间上下两边的墙，用来做信息引线
                            //标注房间信息。
                            //判断每面墙来标房间信息。
                            //获取房间的中心坐标
                            //if (!isReadWall) { //确保只画一次
                            // 判断从中心坐标起上下两边有没有其他墙，如果有则不能标注房间信息
                            //足够长的线段
                            //1.查看向上是否有其他墙
                            var checkCross = false;
                            var checkCrossIndex = 0;
                            var p1 = new Vec2(centerPoint2.x, centerPoint2.y - 0.2);
                            var p2 = new Vec2(centerPoint2.x, centerPoint2.y + 50);
                            //#11上下比较，同时被引用于做房间标识
                            for (var i = 0; i < hWallLineArr.length; i++) {
                                var p3 = new Vec2(hWallLineArr[i].x0, hWallLineArr[i].y0);
                                var p4 = new Vec2(hWallLineArr[i].x1, hWallLineArr[i].y1);

                                checkCross = LineCrossCheck(p1, p2, p3, p4);
                                if (checkCross) {
                                    checkCrossIndex++;
                                }
                            }
                            if (checkCrossIndex < 2) {
                                //console.log("上方可以做标注");
                                if (showOutRoomLabel) {
                                    p1 = new Vec2(centerPoint2.x, centerPoint2.y - 1);
                                    p2 = new Vec2(centerPoint2.x, centerPoint2.y + 1);
                                    //已经标注的坐标记录起来
                                    var roomInfoLabel = new RoomInfoLabel();
                                    roomInfoLabel.p1 = p1;
                                    roomInfoLabel.p2 = p2;
                                    roomInfoLabel.begin = walls.begin;
                                    roomInfoLabel.end = walls.end;
                                    roomInfoLabel.roomName = roomName;
                                    roomInfoLabel.measurement = measurement;
                                    roomInfoLabel.productName = productName;
                                    roomInfoLabel.productNumber = productNumber;
                                    roomInfoLabel.layer = 0; //0：下层，1：上层
                                    var p1_x = parseFloat(centerPoint2.x.toFixed(2));

                                    roomInfoLabel.key = p1_x;
                                    roomInfoLabel.isTop = true;

                                    //选择长度最长的墙来显示房间标记信息
                                    var roomIndexInfo = roomIndexDic.get(roomIndex);
                                    if (roomIndexInfo) {
                                        var line_1 = new Line(walls.begin.x, walls.begin.y, walls.end.x, walls.end.y);
                                        var line_2 = new Line(roomIndexInfo.begin.x, roomIndexInfo.begin.y, roomIndexInfo.end.x, roomIndexInfo.end.y);
                                        if (line_1.length() > line_2.length()) {
                                            roomIndexDic.set(roomIndex, roomInfoLabel);
                                            if (!CheckValue(roomIndex, roomIndexArr)) {
                                                roomIndexArr.push(roomIndex);
                                            }
                                        }
                                    } else {
                                        if (!CheckValue(roomIndex, roomIndexArr)) {
                                            roomIndexArr.push(roomIndex);
                                        }
                                        roomIndexDic.set(roomIndex, roomInfoLabel);
                                    }

                                }
                                isReadWall = true;

                            }
                            //else {
                            //2.查看向下是否有其他墙
                            checkCrossIndex = 0;
                            checkCross = false;
                            p1 = new Vec2(centerPoint2.x, centerPoint2.y + 0.2);
                            p2 = new Vec2(centerPoint2.x, centerPoint2.y - 50);
                            for (var i = 0; i < hWallLineArr.length; i++) {
                                var p3 = new Vec2(hWallLineArr[i].x0, hWallLineArr[i].y0);
                                var p4 = new Vec2(hWallLineArr[i].x1, hWallLineArr[i].y1);
                                checkCross = LineCrossCheck(p1, p2, p3, p4);
                                if (checkCross) {
                                    checkCrossIndex++;
                                }
                            }
                            if (checkCrossIndex < 2) {
                                //console.log("下方可以做标注");
                                if (showOutRoomLabel) {

                                    p1 = new Vec2(centerPoint2.x, centerPoint2.y + 1);
                                    p2 = new Vec2(centerPoint2.x, centerPoint2.y - 1);
                                    //已经标注的坐标记录起来
                                    var roomInfoLabel = new RoomInfoLabel();
                                    roomInfoLabel.p1 = p1;
                                    roomInfoLabel.p2 = p2;
                                    roomInfoLabel.begin = walls.begin;
                                    roomInfoLabel.end = walls.end;
                                    roomInfoLabel.roomName = roomName;
                                    roomInfoLabel.measurement = measurement;
                                    roomInfoLabel.productName = productName;
                                    roomInfoLabel.productNumber = productNumber;
                                    roomInfoLabel.layer = 0; //0：下层，1：上层
                                    var p1_x = parseFloat(centerPoint2.x.toFixed(2));

                                    roomInfoLabel.key = p1_x;
                                    roomInfoLabel.isTop = false;

                                    //选择长度最长的墙来显示房间标记信息
                                    var roomIndexInfo = roomIndexDic.get(roomIndex);
                                    if (roomIndexInfo) {
                                        var line_1 = new Line(walls.begin.x, walls.begin.y, walls.end.x, walls.end.y);
                                        var line_2 = new Line(roomIndexInfo.begin.x, roomIndexInfo.begin.y, roomIndexInfo.end.x, roomIndexInfo.end.y);
                                        if (line_1.length() > line_2.length()) {
                                            roomIndexDic.set(roomIndex, roomInfoLabel);
                                            if (!CheckValue(roomIndex, roomIndexArr)) {
                                                roomIndexArr.push(roomIndex);
                                            }
                                        }
                                    } else {
                                        if (!CheckValue(roomIndex, roomIndexArr)) {
                                            roomIndexArr.push(roomIndex);
                                        }
                                        roomIndexDic.set(roomIndex, roomInfoLabel);
                                    }
                                }
                                isReadWall = true;
                            }
                            //}
                            //#11
                            //}//确保只画一次
                        }
                    });
                    //todo 每个房间

                });

                if (showOutRoomLabel) {

                    //从roomIndexDic获取值得给topLabelArr和bottomLabelArr
                    for (var r = 0; r < roomIndexArr.length; r++) {

                        if (roomIndexDic.get(roomIndexArr[r]).isTop == true) {
                            topLabelArr.push(roomIndexDic.get(roomIndexArr[r]).key);
                            topLabelDic.set(roomIndexDic.get(roomIndexArr[r]).key, roomIndexDic.get(roomIndexArr[r]));
                        } else {
                            bottomLabelArr.push(roomIndexDic.get(roomIndexArr[r]).key);
                            bottomLabelDic.set(roomIndexDic.get(roomIndexArr[r]).key, roomIndexDic.get(roomIndexArr[r]));
                        }
                    }

                    GetRectangle(pointArr, 0);
                    var newTopY = leftTop.y > rightTop.y ? leftTop.y : rightTop.y;
                    var newBottomY = leftBottom.y < rightBottom.y ? leftBottom.y : rightBottom.y;
                    //导出房间信息
                    //判断与其他已画标注的位置距离
                    // 上方标
                    if (topLabelArr.length > 0) {
                        topLabelArr.sort(sortNumber);
                        var info = topLabelDic.get(topLabelArr[0]);
                        info.p2.y = newBottomY * 0.001 + 1;
                        topRoomInfoArr.push(info);
                        for (var t = 1; t <= (topLabelArr.length - 1); t++) {
                            //如果当前标与其他标相距不足2时，就要将左移或者右移
                            info = topLabelDic.get(topLabelArr[t]);
                            info.p2.y = newBottomY * 0.001 + 1;
                            var info_0 = topLabelDic.get(topLabelArr[t - 1]);
                            //topLabelArr记录的是p1.x
                            if ((info.key - info_0.key) < 4) {

                                var end_x = info.begin.x < info.end.x ? info.end.x : info.begin.x;
                                var newP2_y = info.p2.y;
                                if (((end_x - 0.2) - info_0.key) < 4) { //标无法放在合适的位置，需要调整高度来错位

                                    info.key = end_x - 0.2;
                                    if (CheckValue(info.key, topLabelArr)) {
                                        info.key = end_x - 0.21;
                                    }
                                    //判断前一个标签是上层还是下层
                                    if (info_0 && info_0.layer == 0) {//0：下层，1：上层
                                        newP2_y = newP2_y + 1;
                                        info.p2.y = newP2_y;
                                        info.layer = 1;
                                    }
                                } else {//可以放下标注信息
                                    info.key = info_0.key + 4;
                                    if (CheckValue(info.key, topLabelArr)) {
                                        info.key = info_0.key + 3.9;
                                    }
                                }

                                var info2 = info;
                                info2.p1 = new Vec2(info.key, info.p1.y);
                                info2.p2 = new Vec2(info.key, newP2_y);
                                topRoomInfoArr.push(info2);
                            } else {
                                var info3 = info;
                                info3.p1 = new Vec2(info.p1.x, info.p1.y);
                                info3.p2 = new Vec2(info.p2.x, info.p2.y);
                                topRoomInfoArr.push(info3);
                            }
                        }
                    }
                    //下方标注
                    if (bottomLabelArr.length > 0) {
                        bottomLabelArr.sort(sortNumber);
                        var info = bottomLabelDic.get(bottomLabelArr[0]);
                        info.p2.y = newTopY * 0.001 - 1;
                        bottomRoomInfoArr.push(info);
                        for (var t = 1; t <= (bottomLabelArr.length - 1); t++) {
                            //如果当前标与其他标相距不足2时，就要将左移或者右移
                            info = bottomLabelDic.get(bottomLabelArr[t]);
                            info.p2.y = newTopY * 0.001 - 1;
                            var info_0 = bottomLabelDic.get(bottomLabelArr[t - 1]);
                            //topLabelArr记录的是p1.x
                            if ((info.key - info_0.key) < 4) {

                                var end_x = info.begin.x < info.end.x ? info.end.x : info.begin.x;
                                var newP2_y = info.p2.y;
                                if (((end_x - 0.2) - info_0.key) < 4) { //标无法放在合适的位置，需要调整高度来错位

                                    info.key = end_x - 0.2;
                                    if (CheckValue(info.key, bottomLabelArr)) {
                                        info.key = end_x - 0.21;
                                    }

                                    //判断前一个标签是上层还是下层
                                    if (info_0 && info_0.layer == 0) {//0：下层，1：上层
                                        newP2_y = newP2_y - 1;
                                        info.p2.y = newP2_y;
                                        info.layer = 1;
                                    }
                                } else {//可以放下标注信息
                                    info.key = info_0.key + 4;
                                    if (CheckValue(info.key, bottomLabelArr)) {
                                        info.key = info_0.key + 3.9;
                                    }
                                }
                                var info2 = info;
                                info2.p1 = new Vec2(info.key, info.p1.y);
                                info2.p2 = new Vec2(info.key, newP2_y);
                                bottomRoomInfoArr.push(info2);
                            } else {
                                var info3 = info;
                                bottomRoomInfoArr.push(info3);
                            }
                        }
                    }
                }
                //每套户型
                //测试导出数据。
                if (showOutLabel) {
                    GetPointFromRectangle(pointArr, leftPointArr2, rightPointArr2, bottomPointArr2, topPointArr2);
                }
            });
        });
    }

    function sortNumber(a, b) {
        return a - b;
    }

    function getSamePointX(arr, pos) {
        for (var i = 0; i < arr.length; i++) {
            if (getLengthX(arr[i].x, pos.x) < 200) {
                return false;
            }
        }
        return true;
    }

    function getSamePointY(arr, pos) {
        for (var i = 0; i < arr.length; i++) {
            if (getLengthX(arr[i].y, pos.y) < 200) {
                return false;
            }
        }
        return true;
    }

    //获取两点的长度
    function getLengthX(p1_x, p2_x) {
        var line = new Line(p1_x, 0, p2_x, 0);
        return line.length();
    }

    //获取两点的长度
    function getLengthY(p1_y, p2_y) {
        var line = new Line(0, p1_y, 0, p2_y);
        return line.length();
    }


    //获取房间主产品名称
    var pidNameDic = new Dictionary();
    var pidNumberDic = new Dictionary();

    function InitPidName() {
        var rooms = api.floorplanFilterEntity(function (e) {
            return e.type == "FLOOR";
        }).forEach(function (room) {
            var meta = room.floorMaterial.meta;
            if (!pidNameDic.hasKey(meta.pid)) {
                //添加产品系列和规格
                var info = meta.title;
                //var info = meta.title + " " + meta.model + " " + (meta.xlen * 1000) + "X" + (meta.ylen * 1000);
                pidNameDic.set(meta.pid, info);
            }
            if (!pidNumberDic.hasKey(meta.pid)) {
                //添加产品系列和规格
                //var info = meta.title + " " + meta.model + " " + (meta.xlen * 1000) + "X" + (meta.ylen * 1000);
                var info = meta.model + " " + (meta.xlen * 1000) + "X" + (meta.ylen * 1000);
                pidNumberDic.set(meta.pid, info);
            }
        });
    }

    //方便于添加唯一值到列表里
    function CheckValue(value, arr) {

        for (var i = 0; i < arr.length; i++) {
            if (value == arr[i])
                return true;
        }
        return false;
    }

    //通过pid获取产品名称
    function GetNameFromPid(pid) {
        if (pidNameDic.hasKey(pid)) {
            return pidNameDic.get(pid);
        } else {
            return "未添加产品";
        }
    }

    //通过pid获取产品编号
    function GetNumberFromPid(pid) {
        if (pidNumberDic.hasKey(pid)) {
            return pidNumberDic.get(pid);
        } else {
            return "";
        }
    }

    //给墙添加偏移量，保证有误差的线段能相交。
    function AddLength(value, ex, value2) {

        if ((value < 0 && value2 < 0 ) || (value >= 0 && value2 >= 0)) {//处理两个点都小于0时
            if (value < value2) {
                value -= ex;
                return value;
            } else {
                value += ex;
                return value;
            }
        } else {  //一个大于0另外一个小于0
            if (value >= 0) {
                value += ex;
            } else {
                value -= ex;
            }
            return value;
        }
    }

    //区分左右墙的交点坐标
    function GetLeftRight(arr) {
        var newArr = new Array();
        if (arr[0].x > arr[1].x) {
            newArr.push(arr[1]);
            newArr.push(arr[2]);
            newArr.push(arr[3]);
            newArr.push(arr[0]);
        } else {
            newArr.push(arr[0]);
            newArr.push(arr[3]);
            newArr.push(arr[2]);
            newArr.push(arr[1]);
        }

        return newArr;
    }


    //区分上下墙的交点坐标
    function GetTopBottom(arr) {
        var newArr = new Array();
        if (arr[0].y > arr[1].y) {
            newArr.push(arr[1]);
            newArr.push(arr[2]);
            newArr.push(arr[3]);
            newArr.push(arr[0]);
        } else {
            newArr.push(arr[0]);
            newArr.push(arr[3]);
            newArr.push(arr[2]);
            newArr.push(arr[1]);
        }

        return newArr;
    }

    function AddLine(line, showLine, showText) {
        if (lineContext) {
            if (showLine) {
                var line1 = lineContext.paper.line(line.x0, -line.y0, line.x1, -line.y1).attr({
                    fill: "none",
                    stroke: "#5f5f5f",
                    "stroke-width": 1
                });

                labelArr.push(line1);
            }
            if (showText) {
                var distance = line.length();
                distance = parseInt(distance * 10);
                var angle = 0;
                var deviation = 0;
                if (line.x0 == line.x1) {

                    if (line.x0 > 0) {
                        angle = 90;
                        deviation = -10;
                    } else {
                        angle = 270;
                        deviation = -10;
                    }
                }
                if (line.y0 == line.y1) {
                    if (line.y0 > 0) {
                        deviation = -10;
                    } else {
                        deviation = 20;
                    }
                }
                var text1 = lineContext.paper.text((line.x0 + line.x1) / 2, -(line.y0 + line.y1) / 2 + deviation, distance.toString()).attr({
                    stroke: "none",
                    "font-size": 20,
                    fill: "#5f5f5f",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "text-anchor": "middle"
                });
                text1.transform(new Snap.Matrix().rotate(angle, (line.x0 + line.x1) / 2, -(line.y0 + line.y1) / 2) + deviation);
                labelArr.push(text1);
            } else {
                var text1 = lineContext.paper.text((line.x0 + line.x1) / 2, -(line.y0 + line.y1) / 2, "").attr({
                    stroke: "none",
                    "font-size": 20,
                    fill: "#5f5f5f",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "text-anchor": "middle"
                });
                labelArr.push(text1);
            }
        }
    }

    //add by gaoning 2017.5.19 start
    //求多边形的中点坐标
    function GetCenterPoint(arr) {
        var xArr = new Array();
        var yArr = new Array();

        for (var i = 0; i < arr.length; i++) {
            xArr.push(arr[i].x);
            yArr.push(arr[i].y);
        }

        xArr = quickSort(xArr);
        yArr = quickSort(yArr);

        centerPoint = new Vec2((xArr[0] + xArr[xArr.length - 1]) / 2, (yArr[0] + yArr[yArr.length - 1]) / 2)

        return centerPoint;
    }

    //获取外框矩形的坐标
    function GetRectangle(arr, ext) {
        var xArr = new Array();
        var yArr = new Array();

        for (var i = 0; i < arr.length; i++) {
            xArr.push(arr[i].x);
            yArr.push(arr[i].y);
        }
        xArr = quickSort(xArr);
        yArr = quickSort(yArr);
        var centerPoint = new Vec2((xArr[0] + xArr[xArr.length - 1]) / 2, (yArr[0] + yArr[yArr.length - 1]) / 2);
        var width = xArr[xArr.length - 1] - xArr[0];
        var height = yArr[yArr.length - 1] - yArr[0];
        //离外部矩形的距离
        //ext = 2000;
        leftTop = new Vec2((centerPoint.x - width / 2 - ext), (centerPoint.y - height / 2 - ext));
        rightTop = new Vec2((centerPoint.x + width / 2 + ext), (centerPoint.y - height / 2 - ext));
        leftBottom = new Vec2((centerPoint.x - width / 2 - ext), (centerPoint.y + height / 2 + ext));
        rightBottom = new Vec2((centerPoint.x + width / 2 + ext), (centerPoint.y + height / 2 + ext));

        //leftTop = new Vec2((centerPoint.x - width / 2 - ext), (centerPoint.y + height / 2 + ext));
        //rightTop = new Vec2((centerPoint.x + width / 2 + ext), (centerPoint.y + height / 2 + ext));
        //leftBottom = new Vec2((centerPoint.x - width / 2 - ext), (centerPoint.y - height / 2 - ext));
        //rightBottom = new Vec2((centerPoint.x + width / 2 + ext), (centerPoint.y - height / 2 - ext));

        //leftTop = new Vec2((xArr[xArr.length - 1] - ext), (yArr[yArr.length - 1] - ext));
        //rightTop = new Vec2((xArr[0] + ext), (yArr[yArr.length - 1] - ext));
        //leftBottom = new Vec2((xArr[xArr.length - 1] - ext), (yArr[0] + ext));
        //rightBottom = new Vec2((xArr[0] + ext), (yArr[0] + ext));
    }

    //获取外框线上的坐标点
    function GetPointFromRectangle(arr, leftPointArr2, rightPointArr2, topPointArr2, bottomPointArr2) {

        if (arr.length == 0)
            return;

        //计算数据--第一步
        GetRectangle(arr, 500);  //设置外围的距离2000
        var leftPoints = new Array();
        var rightPoints = new Array();
        var topPoints = new Array();
        var bottomPoints = new Array();
        for (var i = 0; i < leftPointArr2.length; i++) {
            var pos = new Vec2(leftTop.x, leftPointArr2[i].y);
            if (!CheckArray(pos, leftPoints)) {
                leftPoints.push(pos);
            }
        }
        for (var i = 0; i < rightPointArr2.length; i++) {
            var pos = new Vec2(rightTop.x, rightPointArr2[i].y);
            if (!CheckArray(pos, rightPoints)) {
                rightPoints.push(pos);
            }
        }
        for (var i = 0; i < topPointArr2.length; i++) {
            var pos = new Vec2(topPointArr2[i].x, leftTop.y);
            if (!CheckArray(pos, topPoints)) {
                topPoints.push(pos);
            }
        }
        for (var i = 0; i < bottomPointArr2.length; i++) {
            var pos = new Vec2(bottomPointArr2[i].x, leftBottom.y);
            if (!CheckArray(pos, bottomPoints)) {
                bottomPoints.push(pos);
            }
        }
        //生成给CAD直接调用的数据
        //left
        if (leftPoints.length > 0) {
            var lefts = OuterPointToLineExcept(leftPoints);
            for (var i = 0; i < (lefts.length - 1); i++) {

                var left2 = new Vec2(lefts[i + 1].x * 0.001 - 0.2, lefts[i + 1].y * 0.001);
                var left1 = new Vec2(lefts[i + 1].x * 0.001 + 0.2, lefts[i + 1].y * 0.001);

                var center1 = new Vec2(lefts[i].x * 0.001, lefts[i].y * 0.001);
                var center2 = new Vec2(lefts[i + 1].x * 0.001, lefts[i + 1].y * 0.001);

                var right2 = new Vec2(lefts[i].x * 0.001 - 0.2, lefts[i].y * 0.001);
                var right1 = new Vec2(lefts[i].x * 0.001 + 0.2, lefts[i].y * 0.001);


                var distance = -0.25;
                if (getLength(center1, center2) < 0.3) {
                    //distance = -0.01;
                    var labelPos = new Vec2((lefts[i].x * 0.001 + lefts[i + 1].x * 0.001) / 2 + distance, (lefts[i].y * 0.001 + lefts[i + 1].y * 0.001) / 2);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);

                } else {
                    distance = -0.01;
                    var labelPos = new Vec2((lefts[i].x * 0.001 + lefts[i + 1].x * 0.001) / 2 + distance, (lefts[i].y * 0.001 + lefts[i + 1].y * 0.001) / 2);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);
                }
            }
        }
        //right
        if (rightPoints.length > 0) {
            var rights = OuterPointToLineExcept(rightPoints);
            for (var i = 0; i < (rights.length - 1); i++) {

                var left1 = new Vec2(rights[i].x * 0.001 - 0.2, rights[i].y * 0.001);
                var left2 = new Vec2(rights[i].x * 0.001 + 0.2, rights[i].y * 0.001);

                var center1 = new Vec2(rights[i].x * 0.001, rights[i].y * 0.001);
                var center2 = new Vec2(rights[i + 1].x * 0.001, rights[i + 1].y * 0.001);

                var right1 = new Vec2(rights[i + 1].x * 0.001 - 0.2, rights[i + 1].y * 0.001);
                var right2 = new Vec2(rights[i + 1].x * 0.001 + 0.2, rights[i + 1].y * 0.001);

                var distance = +0.6;
                if (getLength(center1, center2) < 0.3) {
                    //distance = +0.3;
                    var labelPos = new Vec2((rights[i].x * 0.001 + rights[i + 1].x * 0.001) / 2 + distance, (rights[i].y * 0.001 + rights[i + 1].y * 0.001) / 2);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);
                } else {
                    distance = +0.3;
                    var labelPos = new Vec2((rights[i].x * 0.001 + rights[i + 1].x * 0.001) / 2 + distance, (rights[i].y * 0.001 + rights[i + 1].y * 0.001) / 2);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);
                }
            }
        }
        //top
        if (topPoints.length > 0) {
            var tops = OuterPointToLineExcept(topPoints);
            for (var i = 0; i < (tops.length - 1); i++) {

                var left2 = new Vec2(tops[i].x * 0.001, tops[i].y * 0.001 - 0.2);
                var left1 = new Vec2(tops[i].x * 0.001, tops[i].y * 0.001 + 0.2);

                var center1 = new Vec2(tops[i].x * 0.001, tops[i].y * 0.001);
                var center2 = new Vec2(tops[i + 1].x * 0.001, tops[i + 1].y * 0.001);

                var right2 = new Vec2(tops[i + 1].x * 0.001, tops[i + 1].y * 0.001 - 0.2);
                var right1 = new Vec2(tops[i + 1].x * 0.001, tops[i + 1].y * 0.001 + 0.2);

                var distance = -0.6;
                if (getLength(center1, center2) < 0.3) {
                    //distance = -0.3;
                    var labelPos = new Vec2((tops[i].x * 0.001 + tops[i + 1].x * 0.001) / 2, (tops[i].y * 0.001 + tops[i + 1].y * 0.001) / 2 + distance);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);
                } else {
                    distance = -0.3;
                    var labelPos = new Vec2((tops[i].x * 0.001 + tops[i + 1].x * 0.001) / 2, (tops[i].y * 0.001 + tops[i + 1].y * 0.001) / 2 + distance);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);
                }
            }
        }
        //bottom
        if (bottomPoints.length > 0) {
            var bottoms = OuterPointToLineExcept(bottomPoints);
            for (var i = 0; i < (bottoms.length - 1); i++) {
                var left1 = new Vec2(bottoms[i].x * 0.001, bottoms[i].y * 0.001 - 0.2);
                var left2 = new Vec2(bottoms[i].x * 0.001, bottoms[i].y * 0.001 + 0.2);

                var center1 = new Vec2(bottoms[i].x * 0.001, bottoms[i].y * 0.001);
                var center2 = new Vec2(bottoms[i + 1].x * 0.001, bottoms[i + 1].y * 0.001);

                var right1 = new Vec2(bottoms[i + 1].x * 0.001, bottoms[i + 1].y * 0.001 - 0.2);
                var right2 = new Vec2(bottoms[i + 1].x * 0.001, bottoms[i + 1].y * 0.001 + 0.2);

                var distance = 0.35;
                if (getLength(center1, center2) < 0.3) {
                    //distance = 0.02;
                    var labelPos = new Vec2((bottoms[i].x * 0.001 + bottoms[i + 1].x * 0.001) / 2, (bottoms[i].y * 0.001 + bottoms[i + 1].y * 0.001) / 2 + distance);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);
                } else {
                    distance = 0.02;
                    var labelPos = new Vec2((bottoms[i].x * 0.001 + bottoms[i + 1].x * 0.001) / 2, (bottoms[i].y * 0.001 + bottoms[i + 1].y * 0.001) / 2 + distance);
                    var wallLine = new WallLines(left1, left2, center1, center2, right1, right2, labelPos);
                    wallLinesArr.push(wallLine);
                }
            }
        }
    }

    //获取两点的长度
    function getLength(p1, p2) {
        var line = new Line(p1.x, p1.y, p2.x, p2.y);
        return line.length();
    }

    //除外框线外的点集合
    function OuterPointToLineExcept(arr) {

        var xarr = new Array();
        var yarr = new Array();
        var outArr = new Array();
        if (arr[0].x == arr[arr.length - 1].x) {
            var _x;
            for (var i = 0; i < arr.length; i++) {
                _x = arr[0].x;
                yarr.push(arr[i].y);
            }

            //去除头尾四个点坐标
            yarr = quickSort(yarr);
            for (var i = 0; i < yarr.length; i++) {
                var xVec2 = new Vec2(_x, yarr[i]);
                outArr.push(xVec2);
            }
        } else if (arr[0].y == arr[arr.length - 1].y) {
            var _y;
            for (var i = 0; i < arr.length; i++) {
                _y = arr[0].y;
                xarr.push(arr[i].x);
            }
            //去除头尾四个点坐标
            xarr = quickSort(xarr);
            for (var i = 0; i < xarr.length; i++) {
                var yVec2 = new Vec2(xarr[i], _y);
                outArr.push(yVec2);
            }
        }

        return outArr;
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    //方便于添加唯一坐标点到列表里
    function CheckArray(value, arr) {

        for (var i = 0; i < arr.length; i++) {
            if (value.x == arr[i].x && value.y == arr[i].y)
                return true;
        }
        return false;
    }

    //方便于添加唯一坐标点到列表里
    function CheckLineArray(value, arr) {

        for (var i = 0; i < arr.length; i++) {
            if (value.x0 == arr[i].x0 && value.y0 == arr[i].y0 && value.x1 == arr[i].x1 && value.y1 == arr[i].y1)
                return true;
        }
        return false;
    }

    // 快速排序
    function quickSort(array) {
        //var array = [8,4,6,2,7,9,3,5,74,5];
        //var array = [0,1,2,44,4,324,5,65,6,6,34,4,5,6,2,43,5,6,62,43,5,1,4,51,56,76,7,7,2,1,45,4,6,7];

        if (array.length == 0) {
            return array;
        } else {
            return array.sort(sortNumber);
        }

        var i = 0;
        var j = array.length - 1;
        var Sort = function (i, j) {
            // 结束条件
            if (i == j)
                return;
            var key = array[i];
            var stepi = i; // 记录开始位置
            var stepj = j; // 记录结束位置
            while (j > i) {
                // j <<-------------- 向前查找
                if (array[j] >= key) {
                    j--;
                } else {
                    array[i] = array[j]
                    //i++ ------------>>向后查找
                    while (j > ++i) {
                        if (array[i] > key) {
                            array[j] = array[i];
                            break;
                        }
                    }
                }
            }
            // 如果第一个取出的 key 是最小的数
            if (stepi == i) {
                Sort(++i, stepj);
                return;
            }
            // 最后一个空位留给 key
            array[i] = key;
            // 递归
            Sort(stepi, i);
            Sort(j, stepj);
        }
        Sort(i, j);
        return array;
    }

    //求线段的垂直平分线
    function GetCenterLine(line) {
        var length = 100;
        var centerPos = new Vec2((line.x0 + line.x1) / 2, (line.y0 + line.y1) / 2);
        var k = -(line.x1 - line.x0) / (line.y1 - line.y0);
        var x0 = 100; //给定足够长的线
        var y0 = k * x0 + (line.y0 + line.y1) / 2 + (line.x0 - line.x1) * (line.x0 + line.x1) / (2 * (line.y1 - line.y0));
        var x1 = -100; //给定足够长的线
        var y1 = k * x0 + (line.y0 + line.y1) / 2 + (line.x0 - line.x1) * (line.x0 + line.x1) / (2 * (line.y1 - line.y0));

        var centerLine = new Line(x0, y0, x1, y1);

        return centerLine;
    }

    //判断线段相交方法77777
    function LineCrossCheck(a, b, c, d) {
        var abc = (a.x - c.x) * (b.y - c.y) - (a.y - c.y) * (b.x - c.x);
        var abd = (a.x - d.x) * (b.y - d.y) - (a.y - d.y) * (b.x - d.x);
        if (abc * abd >= 0) {
            return false;
        }
        var cda = (c.x - a.x) * (d.y - a.y) - (c.y - a.y) * (d.x - a.x);
        var cdb = cda + abc - abd;
        if (cda * cdb >= 0) {
            return false;
        }
        return true;
    }
})(this);
//add by gaoning end 2017.7.12
















