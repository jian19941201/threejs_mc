/**
 * Created by gn on 2017/9/21.
 */
//对需要导出的数据进行整理(去业务化)
function utilExportJSONData2(callback) {

    //初始化数据
    api.InitCADData();
    //导出顺序：
    //1.柱子、地台等其他类型
    //2.墙
    //3.波打线
    //4.区域
    //5.地面
    var bomData = api.getBomData();
    api.catalogGetProductsMetaPromise(bomData.pids).then(function (meta) {
        bomData.metas = meta;

        //console.log(bomData);

        api.snapExport("JSON", function (content) {
            var cad = {};
            cad.export = [];

            var clipperNumber = 1000; //设置裁剪参数
            var idsList = [], idsDic = new Dictionary();

            //导出房间内的信息
            bomData.rooms.forEach(function (roomInfo) {
                var bomRoom = roomInfo;
                var room = {floor: {}, walls: []};

                var cadFloor = room.floor;
                var cadWalls = room.walls;

                //导出其他类型-柱子-地台-横梁-用于波打线裁剪
                var pathsForBoundarys = [];
                var bomOthers = content.others;
                if (bomOthers) {
                    bomOthers.forEach(function (bomOther) {
                        if (bomOther.type == "PILLAR") {
                            var pillarPoly = [];
                            for (var i = 0; i < bomOther.loop.length; ++i) {
                                pillarPoly.push({
                                    X: Math.ceil(bomOther.loop[i].x * clipperNumber),
                                    Y: Math.ceil(bomOther.loop[i].y * clipperNumber)
                                });
                            }
                            pathsForBoundarys.push(pillarPoly);
                        }
                    })
                }
                var content_str_ext = JSON.stringify(content.wallLines);
                var content_str_ext = JSON.parse(content_str_ext);
                content_str_ext.forEach(function (wallLine) {

                    var wallPoly = [];
                    wallLine.forEach(function (line) {
                        wallPoly.push({
                            X: Math.ceil(line.X * 0.001 * clipperNumber),
                            Y: Math.ceil(line.Y * 0.001 * clipperNumber)
                        });

                    });
                    pathsForBoundarys.push(wallPoly);
                });


                if (roomInfo.boundarys && roomInfo.boundarys.length > 0) {
                    var boundaryX = (roomInfo.boundarys[0].baseMaterial.meta.xlen);
                    //var boundaryY = (roomInfo.boundarys[0].baseMaterial.meta.ylen);
                    roomInfo.boundarys.forEach(function (boundary) {
                        boundary.floorRectTiles.forEach(function (floorRectTiles) {

                            floorRectTiles.tiles.forEach(function (tiles) {

                                if (tiles.tileProfile) {

                                    tiles.tileProfile.forEach(function (points) {
                                        var line = {polyline: []};
                                        points.forEach(function (pos) {
                                            line.polyline.push({
                                                x: pos.x,
                                                y: pos.y
                                            });
                                        });
                                        cad.export.push(genCADPolylines(line, {
                                            layer: LAYER.FLOOR,
                                            color: COLOR.FLOOR,
                                            width: 0
                                        }));
                                    });
                                }
                            });
                        });

                    });
                }

                //地面铺砖信息
                //var bomFloor = bomRoom && bomRoom.floor;
                var bomFloor = bomRoom && bomRoom.tiles;
                if (bomFloor) {

                    var clipperNumber = 10000;
                    var areas = content.areas;

                    //console.log(areas);

                    var bomOthers = content.others;
                    var hasBomOrhers = false;
                    bomOthers.forEach(function (bomOther) {
                        if (bomOther.type == "PILLAR") {
                            //判断是否有在面裁剪
                            hasBomOrhers = true;
                        }
                    });
                    if ((areas && areas.length > 0) || hasBomOrhers) {

                        var paths = [];
                        var bomOthersPaths = []; //用来做区域内柱子的剔除

                        //地面铺砖对柱子进行剔除- 2017.9.3
                        //导出其他类型
                        bomOthers.forEach(function (bomOther) {
                            if (bomOther.type == "PILLAR") {
                                //剔除操作
                                var pillarPoly = [];
                                for (var i = 0; i < bomOther.loop.length; ++i) {
                                    pillarPoly.push({
                                        X: Math.ceil(bomOther.loop[i].x * clipperNumber),
                                        Y: Math.ceil(bomOther.loop[i].y * clipperNumber)
                                    });
                                }
                                paths.push(pillarPoly);
                                bomOthersPaths.push(pillarPoly);
                            }
                        });

                        areas.forEach(function (area) {

                            //把区域添加到paths
                            var areaBoundarys = getBoundaryFromId(roomInfo, area.areadata.id);
                            if (areaBoundarys.length > 0) {
                                var areaPoly2 = [];
                                for (var i = 0; i < area.loop.length; ++i) {
                                    areaPoly2.push({
                                        x: area.loop[i].x,
                                        y: area.loop[i].y
                                    });
                                }
                                var areaBoundarysLength = 0;
                                for (var b = 0; b < areaBoundarys.length; b++) {
                                    areaBoundarysLength += areaBoundarys[b].size;
                                }
                                var newOffect = utilAdaptorClipperExtend(areaPoly2, areaBoundarysLength);

                                var areaPoly = [];
                                for (var i = 0; i < newOffect.length; ++i) {
                                    areaPoly.push({
                                        X: Math.ceil(newOffect[i].x * clipperNumber),
                                        Y: Math.ceil(newOffect[i].y * clipperNumber)
                                    });
                                }
                                //areaPoly.push({
                                //    X: Math.ceil(newOffect[0].x * clipperNumber),
                                //    Y: Math.ceil(newOffect[0].y * clipperNumber)
                                //});

                                paths.push(areaPoly);

                            } else {
                                var areaPoly = [];
                                for (var i = 0; i < area.loop.length; ++i) {
                                    areaPoly.push({
                                        X: Math.ceil(area.loop[i].x * clipperNumber),
                                        Y: Math.ceil(area.loop[i].y * clipperNumber)
                                    });
                                }
                                paths.push(areaPoly);
                            }

                            //区域内的铺砖线导出
                            area.areadata.floorRectTiles.forEach(function (floorRectTiles) {

                                //console.log(floorRectTiles);

                                if (floorRectTiles.tileProfile) {

                                    var highAreaPaths = [];
                                    var highArea = getAreasFromLevel(areas, area.areadata.level);
                                    for (var a = 0; a < highArea.length; a++) {
                                        var areaBoundarys = getBoundaryFromId(roomInfo, highArea[a].areadata.id);
                                        if (areaBoundarys.length > 0) {
                                            var areaPoly2 = [];
                                            for (var i = 0; i < highArea[a].loop.length; ++i) {
                                                areaPoly2.push({
                                                    x: highArea[a].loop[i].x,
                                                    y: highArea[a].loop[i].y
                                                });
                                            }
                                            //计算所有外层波打线的宽度
                                            var areaBoundarysLength = 0;
                                            for (var b = 0; b < areaBoundarys.length; b++) {
                                                areaBoundarysLength += areaBoundarys[b].size;
                                            }
                                            var newOffect = utilAdaptorClipperExtend(areaPoly2, areaBoundarysLength);

                                            var areaPoly = [];
                                            for (var i = 0; i < newOffect.length; ++i) {
                                                areaPoly.push({
                                                    X: Math.ceil(newOffect[i].x * clipperNumber),
                                                    Y: Math.ceil(newOffect[i].y * clipperNumber)
                                                });
                                            }

                                            highAreaPaths.push(areaPoly);

                                        } else {
                                            var areaPoly = [];
                                            for (var i = 0; i < highArea[a].loop.length; ++i) {
                                                areaPoly.push({
                                                    X: Math.ceil(highArea[a].loop[i].x * clipperNumber),
                                                    Y: Math.ceil(highArea[a].loop[i].y * clipperNumber)
                                                });
                                            }
                                            highAreaPaths.push(areaPoly);
                                        }
                                    }

                                    //console.log(area.areadata.singlepaveRot);
                                    var singlepaveRot = area.areadata.singlepaveRot;
                                    //var areaLists = api.floorplanFilterEntity(function(e)
                                    //{
                                    //    return e.type=="RECTAREA" || e.type=="ROUNDAREA" ||e.type=="FREEAREA" ;
                                    //});
                                    //areaLists.forEach(function (arealist){
                                    //    if(arealist.id == area.areadata.id){
                                    //        console.log(arealist.singlepaveRot);
                                    //    }
                                    //});
                                    //弧度= 角度 * Math.PI / 180;
                                    //角度 = 弧度 * 180 / Math.PI;

                                    //判断此区域上层有没有区域，要做区域内的区域裁剪。
                                    //没有柱子里，就不用考虑对柱子剔除
                                    if (bomOthersPaths.length == 0 && highAreaPaths.length == 0) {

                                        for (var i = 0; i < floorRectTiles.tileProfile.length; i++) {
                                            var areaData = floorRectTiles.material.category == "customparquet" ? {
                                                polyline: [],
                                                ids: {id: "", ox: 0, oy: 0, sx: 1, sy: 1, rot: 0, color: 0}
                                            } : {polyline: []};
                                            for (var t = 0; t < floorRectTiles.tileProfile[i].length; t++) {
                                                areaData.polyline.push({
                                                    x: floorRectTiles.tileProfile[i][t].x,
                                                    y: floorRectTiles.tileProfile[i][t].y
                                                });
                                            }

                                            if (areaData.polyline.length > 0) {
                                                areaData.polyline.push({
                                                    x: areaData.polyline[0].x,
                                                    y: areaData.polyline[0].y
                                                });

                                                if (areaData.ids) {
                                                    areaData.ids.id = floorRectTiles.material.pid;
                                                    areaData.ids.ox = floorRectTiles.pos.x;
                                                    areaData.ids.oy = floorRectTiles.pos.y;
                                                    areaData.ids.sx = floorRectTiles.material.sx * floorRectTiles.material.meta.xlen;
                                                    areaData.ids.sy = floorRectTiles.material.sy * floorRectTiles.material.meta.ylen;
                                                    areaData.ids.rot = singlepaveRot * Math.PI / 180;
                                                    areaData.ids.color = COLOR.PARQUET;

                                                    if (!idsDic.hasKey(areaData.ids.id)) {
                                                        idsDic.set(areaData.ids.id, areaData.ids);
                                                        idsList.push(areaData.ids.id);
                                                    }

                                                }


                                                cad.export.push(genCADPolylines(areaData, {
                                                    layer: LAYER.FLOOR,
                                                    color: COLOR.FLOOR,
                                                    width: 0
                                                }));
                                            }
                                        }


                                    } else {  //先进行区域内对柱子剔除再画区域内铺砖信息
                                        //添加区域内对上层区域的裁剪
                                        var cpr = new ClipperLib.Clipper();
                                        var solution = new ClipperLib.PolyTree();
                                        var clipAreaPaths = [];
                                        var areaLine = [];
                                        for (var i = 0; i < floorRectTiles.tileProfile.length; i++) {
                                            for (var t = 0; t < floorRectTiles.tileProfile[i].length; t++) {
                                                areaLine.push({
                                                    X: Math.ceil(floorRectTiles.tileProfile[i][t].x * clipperNumber),
                                                    Y: Math.ceil(floorRectTiles.tileProfile[i][t].y * clipperNumber)
                                                });
                                            }

                                            clipAreaPaths.push(areaLine);

                                            //开始剔除柱子
                                            for (var p = 0; p < bomOthersPaths.length; p++) {
                                                if (solution && solution.m_AllPolys.length > 0) {
                                                    clipAreaPaths = [];
                                                    for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                        var polygon = [];
                                                        for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                            polygon.push({
                                                                X: solution.m_AllPolys[i].m_polygon[m].X,
                                                                Y: solution.m_AllPolys[i].m_polygon[m].Y
                                                            });
                                                        }
                                                        clipAreaPaths.push(polygon);
                                                    }
                                                    cpr.Clear();
                                                    cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                    cpr.AddPath(bomOthersPaths[p], ClipperLib.PolyType.ptClip, true);

                                                    solution = new ClipperLib.PolyTree();
                                                    cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                                }
                                                else if (p == 0) {  //没有solution值时先处理第一个
                                                    cpr.Clear();
                                                    cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                    cpr.AddPath(bomOthersPaths[p], ClipperLib.PolyType.ptClip, true);

                                                    solution = new ClipperLib.PolyTree();
                                                    cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                                }
                                            }

                                            //接着裁剪上层区域
                                            for (var p = 0; p < highAreaPaths.length; p++) {
                                                if (solution && solution.m_AllPolys.length > 0) {
                                                    clipAreaPaths = [];
                                                    for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                        var polygon = [];
                                                        for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                            polygon.push({
                                                                X: solution.m_AllPolys[i].m_polygon[m].X,
                                                                Y: solution.m_AllPolys[i].m_polygon[m].Y
                                                            });
                                                        }
                                                        clipAreaPaths.push(polygon);
                                                    }
                                                    cpr.Clear();
                                                    cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                    cpr.AddPath(highAreaPaths[p], ClipperLib.PolyType.ptClip, true);

                                                    solution = new ClipperLib.PolyTree();
                                                    cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                                                }

                                                else if (p == 0) {  //没有solution值时先处理第一个
                                                    cpr.Clear();
                                                    cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                    cpr.AddPath(highAreaPaths[p], ClipperLib.PolyType.ptClip, true);

                                                    solution = new ClipperLib.PolyTree();
                                                    cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                                                }
                                            }

                                            //裁剪完清空
                                            highAreaPaths = [];

                                            //把柱子从区域剔除后开始画区域内的地面铺砖线
                                            for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                //var areaData = {polyline: []};
                                                var areaData = floorRectTiles.material.category == "customparquet" ? {
                                                    polyline: [],
                                                    ids: {id: "", ox: 0, oy: 0, sx: 1, sy: 1, rot: 0, color: 0}
                                                } : {polyline: []};
                                                for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                    areaData.polyline.push({
                                                        x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                                        y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                                    });
                                                }
                                                if (areaData.polyline.length > 0) {

                                                    if (areaData.ids) {
                                                        areaData.ids.id = floorRectTiles.material.pid;
                                                        areaData.ids.ox = floorRectTiles.pos.x;
                                                        areaData.ids.oy = floorRectTiles.pos.y;
                                                        areaData.ids.sx = floorRectTiles.material.sx * floorRectTiles.material.meta.xlen;
                                                        areaData.ids.sy = floorRectTiles.material.sy * floorRectTiles.material.meta.ylen;
                                                        areaData.ids.rot = singlepaveRot * Math.PI / 180;
                                                        areaData.ids.color = COLOR.PARQUET;

                                                        if (!idsDic.hasKey(areaData.ids.id)) {
                                                            idsDic.set(areaData.ids.id, areaData.ids);
                                                            idsList.push(areaData.ids.id);
                                                        }
                                                    }

                                                    areaData.polyline.push({
                                                        x: areaData.polyline[0].x,
                                                        y: areaData.polyline[0].y
                                                    });
                                                    cad.export.push(genCADPolylines(areaData, {
                                                        layer: LAYER.FLOOR,
                                                        color: COLOR.FLOOR,
                                                        width: 0
                                                    }));
                                                }

                                            }
                                        }


                                    }
                                }
                            });
                        });


                        //对地面开始进行区域和柱子的剔除
                        bomFloor.forEach(function (tiles) {

                            var cpr = new ClipperLib.Clipper();
                            var solution = new ClipperLib.PolyTree();
                            var clipPaths = [];
                            var line = [];
                            for (var i = 0; i < tiles.length; i++) {
                                for (var t = 0; t < tiles[i].length; t++) {
                                    line.push({
                                        X: Math.ceil(tiles[i][t].x * clipperNumber),
                                        Y: Math.ceil(tiles[i][t].y * clipperNumber)
                                    });
                                }
                            }
                            clipPaths.push(line);

                            //开始剔除
                            for (var p = 0; p < paths.length; p++) {
                                if (solution && solution.m_AllPolys.length > 0) {
                                    clipPaths = [];
                                    for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                        var polygon = [];
                                        for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                            polygon.push({
                                                X: solution.m_AllPolys[i].m_polygon[m].X,
                                                Y: solution.m_AllPolys[i].m_polygon[m].Y
                                            });
                                        }
                                        clipPaths.push(polygon);
                                    }
                                    cpr.Clear();
                                    cpr.AddPaths(clipPaths, ClipperLib.PolyType.ptSubject, true);
                                    cpr.AddPath(paths[p], ClipperLib.PolyType.ptClip, true);

                                    solution = new ClipperLib.PolyTree();
                                    cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                }
                                else if (p == 0) {  //先处理第一个
                                    cpr.Clear();
                                    cpr.AddPaths(clipPaths, ClipperLib.PolyType.ptSubject, true);
                                    cpr.AddPath(paths[p], ClipperLib.PolyType.ptClip, true);

                                    solution = new ClipperLib.PolyTree();
                                    cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                }
                            }

                            //把区域和柱子都剔除后开始画地面铺砖线

                            for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                var floorData = {polyline: []};
                                for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                    floorData.polyline.push({
                                        x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                        y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                    });
                                }
                                if (floorData.polyline.length > 0) {
                                    floorData.polyline.push({x: floorData.polyline[0].x, y: floorData.polyline[0].y});
                                    cad.export.push(genCADPolylines(floorData, {
                                        layer: LAYER.FLOOR,
                                        color: COLOR.FLOOR,
                                        width: 0
                                    }));
                                }
                            }


                        });
                    } else {//没有剔除的情况下
                        bomFloor.forEach(function (tiles) {

                            for (var i = 0; i < tiles.length; i++) {
                                var floorData = {polyline: []};
                                for (var t = 0; t < tiles[i].length; t++) {
                                    floorData.polyline.push({x: tiles[i][t].x, y: tiles[i][t].y});
                                }
                                if (floorData.polyline.length > 0) {
                                    floorData.polyline.push({x: floorData.polyline[0].x, y: floorData.polyline[0].y});
                                    cad.export.push(genCADPolylines(floorData, {
                                        layer: LAYER.FLOOR,
                                        color: COLOR.FLOOR,
                                        width: 0
                                    }));
                                }
                            }

                        });
                    }
                }


                //1.导出其他类型-柱子-地台-横梁
                var pillarPaths = [];
                var bomOthers = content.others;

                //console.log("@AAAAAAAAAAAAAAA");
                //console.log(content);

                if (bomOthers) {
                    bomOthers.forEach(function (bomOther) {

                        var cadOther = {};
                        //cadOther.id = bomOther.id;
                        //cadOther.attached = bomOther.attached;
                        cadOther.pid = bomOther.pid;
                        cadOther.insert = {x: bomOther.x, y: bomOther.y, z: bomOther.z};
                        cadOther.scale = {sx: bomOther.sx, sy: bomOther.sy, sz: bomOther.sz};
                        cadOther.rotate = {rot: bomOther.rot};
                        cadOther.polyline = bomOther.loop;

                        if (bomOther.type == "PILLAR") {
                            cad.export.push(genCADPolylines(cadOther, {
                                layer: LAYER.PILLAR,
                                color: COLOR.PILLAR,
                                width: 0
                            }));

                            //剔除操作
                            var pillarPoly = [];
                            for (var i = 0; i < bomOther.loop.length; ++i) {
                                pillarPoly.push({
                                    X: Math.ceil(bomOther.loop[i].x * clipperNumber),
                                    Y: Math.ceil(bomOther.loop[i].y * clipperNumber)
                                });
                            }
                            pillarPaths.push(pillarPoly);

                        } else if (bomOther.type == "BASEMENT") {
                            //cad.export.push(genCADPolylines(cadOther, {
                            //    layer: LAYER.BASEMENT,
                            //    color: COLOR.BASEMENT,
                            //    width: 0
                            //}));
                        } else if (bomOther.type == "BEAM") {
                            //cad.export.push(genCADPolylines(cadOther, {
                            //    layer: LAYER.BEAM,
                            //    color: COLOR.BEAM,
                            //    width: 0
                            //}));
                        }
                    })
                }

                //墙体标尺
                content.wallrods.forEach(function (wallrod) {

                    //增加导出选择--add by gaoning 2017.7.13
                    var dimensionLayer = false;//api.getDimensionLayer();
                    if (dimensionLayer) {
                        var labelData = wallrod.labels[0];
                        //新增dim数据
                        var dimData = [];
                        //左侧
                        dimData.push(wallrod.lines[1][0]);
                        dimData.push(wallrod.lines[1][1]);
                        //右侧
                        dimData.push(wallrod.lines[2][0]);
                        dimData.push(wallrod.lines[2][1]);
                        //中间
                        dimData.push(wallrod.lines[0][0]);
                        dimData.push(wallrod.lines[0][1]);
                        //文字坐标
                        dimData.push({x: labelData.x, y: labelData.y});
                        cad.export.push(genCADDim(dimData), {layer: LAYER.WALLROD, color: COLOR.WALLROD, width: 0.5});
                    }
                });

                //2.房间墙体
                var wallLines_json = content.wallLines.concat();
                wallLines_json.forEach(function (wallLine) {

                    var wallPaths = [];
                    var wallData = {polyline: []};
                    var wallPoly = [];
                    wallLine.forEach(function (line) {

                        wallData.polyline.push({x: line.X * 0.001, y: line.Y * 0.001});

                        //var wallPoly = [];
                        wallPoly.push({
                            X: Math.ceil(line.X * 0.001 * clipperNumber),
                            Y: Math.ceil(line.Y * 0.001 * clipperNumber)
                        });

                    });
                    wallPaths.push(wallPoly);
                    if (pillarPaths.length == 0) {  //没有柱子里，直接画墙，不用考虑裁剪问题。
                        if (wallData.polyline.length > 0) {
                            wallData.polyline.push({x: wallData.polyline[0].x, y: wallData.polyline[0].y});
                            cad.export.push(genCADPolylines(wallData, {
                                layer: LAYER.WALL,
                                color: COLOR.WALL,
                                width: 0
                            }));
                        }
                    } else {
                        var cpr = new ClipperLib.Clipper();
                        var solution = new ClipperLib.PolyTree();
                        //开始剔除
                        for (var p = 0; p < pillarPaths.length; p++) {
                            if (solution && solution.m_AllPolys.length > 0) {
                                wallPaths = [];
                                for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                    var polygon = [];
                                    for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                        polygon.push({
                                            X: solution.m_AllPolys[i].m_polygon[m].X,
                                            Y: solution.m_AllPolys[i].m_polygon[m].Y
                                        });
                                    }
                                    wallPaths.push(polygon);
                                }
                                cpr.Clear();
                                cpr.AddPaths(wallPaths, ClipperLib.PolyType.ptSubject, true);
                                cpr.AddPath(pillarPaths[p], ClipperLib.PolyType.ptClip, true);

                                solution = new ClipperLib.PolyTree();
                                cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                            }
                            else if (p == 0) {  //没有solution值时先处理第一个
                                cpr.Clear();
                                cpr.AddPaths(wallPaths, ClipperLib.PolyType.ptSubject, true);
                                cpr.AddPath(pillarPaths[p], ClipperLib.PolyType.ptClip, true);

                                solution = new ClipperLib.PolyTree();
                                cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
                            }
                        }

                        //把柱子从墙体剔除后开始画墙线

                        for (var i = 0; i < solution.m_AllPolys.length; ++i) {

                            var wallDatas = {polyline: []};
                            for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                wallDatas.polyline.push({
                                    x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                    y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                });
                            }
                            if (wallDatas.polyline.length > 0) {
                                wallDatas.polyline.push({x: wallDatas.polyline[0].x, y: wallDatas.polyline[0].y});
                                cad.export.push(genCADPolylines(wallDatas, {
                                    layer: LAYER.WALL,
                                    color: COLOR.WALL,
                                    width: 0
                                }));
                            }
                        }

                    }


                });

                // 导出设置-- add by gaoning 2017.7.13
                var roomLabel = api.getRoomLabel();
                if (roomLabel) {
                    //计算地板铺砖数量
                    var measurement = roomInfo.measurement;
                    var num = bomFloor.length;//Math.ceil(measurement / (floorW * floorH));
                    //cad.export.push(genCADLabel({
                    //    label: "铺砖数" + num,
                    //    x: roomInfo.labelX,
                    //    y: roomInfo.labelY + 0.28,
                    //    size: 12,
                    //    align: 0
                    //}, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));


                    //房间命名和平方米
                    cad.export.push(genCADLabel({
                        label: roomInfo.label == "" ? "未命名" : roomInfo.label,
                        x: roomInfo.labelX,
                        y: roomInfo.labelY,
                        size: 12,
                        align: 0
                    }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                    cad.export.push(genCADLabel({
                        label: roomInfo.measurementLabel == "" ? "空" : roomInfo.measurementLabel,
                        x: roomInfo.measurementLabelX,
                        y: roomInfo.measurementLabelY + 0.08,
                        size: 12,
                        align: 0
                    }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                }
            });


            //导出门窗
            var bomOpenings = content.openings;
            if (bomOpenings) {
                bomOpenings.forEach(function (bomOpening) {
                    var attrib = {width: 0};
                    var cadOpening = {};

                    cadOpening.id = bomOpening.id;
                    //cadOpening.attached = bomOpening.attached;
                    cadOpening.pid = bomOpening.pid;
                    cadOpening.insert = {x: bomOpening.x, y: bomOpening.y, z: bomOpening.z};
                    cadOpening.scale = {sx: bomOpening.sx, sy: bomOpening.sy, sz: bomOpening.sz};
                    cadOpening.rotate = {rot: bomOpening.rot, swing: bomOpening.swing};
                    cadOpening.polyline = bomOpening.loop;

                    //确定门窗子类型
                    switch (bomOpening.subcategory) {
                        case "casementdoor"://平开门
                            cadOpening.subcategory = 0;
                            break;
                        case "doublecasementdoor"://双开门
                            cadOpening.subcategory = 1;
                            break;
                        case "slidingdoor"://推拉门
                            cadOpening.subcategory = 2;
                            break;
                        case "casementwindow"://平开窗
                            cadOpening.subcategory = 0;
                            break;
                        case "slidingwindow"://推拉窗
                            cadOpening.subcategory = 1;
                            break;
                        case "baywindow"://飘窗
                            cadOpening.subcategory = 2;
                            break;
                        case "hungwindow"://装饰窗
                            cadOpening.subcategory = 3;
                            break;
                    }

                    if (bomOpening.type == "WINDOW") {
                        attrib.color = COLOR.WINDOW;
                        attrib.layer = LAYER.WINDOW;

                        //windows输出中心线
                        cadOpening.centerline = [];
                        cadOpening.centerline.push({
                            x: (bomOpening.loop[0].x + bomOpening.loop[3].x) / 2,
                            y: (bomOpening.loop[0].y + bomOpening.loop[3].y) / 2
                        });
                        cadOpening.centerline.push({
                            x: (bomOpening.loop[1].x + bomOpening.loop[2].x) / 2,
                            y: (bomOpening.loop[1].y + bomOpening.loop[2].y) / 2
                        });

                        cad.export.push(genCADWindow(cadOpening, attrib));
                    } else if (bomOpening.type == "DOOR") {
                        attrib.color = COLOR.DOOR;
                        attrib.layer = LAYER.DOOR;

                        //door输出基线
                        cadOpening.baseline = [];

                        switch (bomOpening.swing) {
                            case 0:
                                cadOpening.baseline.push({x: bomOpening.loop[0].x, y: bomOpening.loop[0].y});
                                cadOpening.baseline.push({x: bomOpening.loop[1].x, y: bomOpening.loop[1].y});
                                break;
                            case 1:
                                cadOpening.baseline.push({x: bomOpening.loop[3].x, y: bomOpening.loop[3].y});
                                cadOpening.baseline.push({x: bomOpening.loop[2].x, y: bomOpening.loop[2].y});
                                break;
                            case 2:
                                cadOpening.baseline.push({x: bomOpening.loop[2].x, y: bomOpening.loop[2].y});
                                cadOpening.baseline.push({x: bomOpening.loop[3].x, y: bomOpening.loop[3].y});
                                break;
                            case 3:
                                cadOpening.baseline.push({x: bomOpening.loop[1].x, y: bomOpening.loop[1].y});
                                cadOpening.baseline.push({x: bomOpening.loop[0].x, y: bomOpening.loop[0].y});
                                break;
                        }

                        cad.export.push(genCADDoor(cadOpening, attrib));
                    }


                })
            }

            //导出家具
            var bomProducts = content.products;
            if (bomProducts) {
                bomProducts.forEach(function (bomProduct) {
                    var cadProduct = {};
                    cadProduct.pid = bomProduct.pid;
                    cadProduct.insert = {x: bomProduct.x, y: bomProduct.y, z: bomProduct.z};
                    cadProduct.scale = {sx: bomProduct.sx, sy: bomProduct.sy, sz: bomProduct.sz};
                    cadProduct.rotate = {rot: bomProduct.rot};
                    //cadProduct.id = bomProduct.id;
                    //cadProduct.attached = bomProduct.attached;

                    cadProduct.polyline = bomProduct.loop;
                    if (bomProduct.type == "PRODUCT" || bomProduct.type == "PRODUCTREPLACEMENT") {
                        //cad.export.push(genCADPolylines(cadProduct,{layer:LAYER.PRODUCT,color:COLOR.PRODUCT,width:0}));
                    }
                })
            }


            //导出注释
            //导出设置-- add by gaoning 2017.7.13
            var textAnnotation = api.getTextAnnotation();
            if (textAnnotation) {
                var bomAnnotations = content.annotations;
                if (bomAnnotations) {
                    bomAnnotations.forEach(function (bomAnnotation) {
                        //注释线段
                        var lines = [];
                        lines.push({x: bomAnnotation.x, y: bomAnnotation.y});
                        lines.push({x: bomAnnotation.tx, y: bomAnnotation.ty});
                        cad.export.push(genCADLines([lines], {
                            layer: LAYER.ANNOTATION,
                            color: COLOR.ANNOTATION,
                            width: 0
                        }));

                        //注释文字
                        cad.export.push(genCADLabel({
                            label: "" + bomAnnotation.text,
                            x: bomAnnotation.tx,
                            y: bomAnnotation.ty,
                            size: bomAnnotation.fontsize,
                            align: 1
                        }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                    })
                }
            }

            //*************************************************************************************
            //add by gaoning  添加户型标注信息
            var outRoomLabel = api.getOutRoomLabel();
            outRoomLabel = false; //关闭显示主砖信息
            if (outRoomLabel) {

                var topRoomInfo = getTopRoomInfoArr();
                var bottomRoomInfo = getBottomRoomInfoArr();

                if (topRoomInfo) {
                    for (var i = 0; i < topRoomInfo.length; i++) {

                        var info = topRoomInfo[i];
                        var p1 = info.p1;
                        var p2 = info.p2;
                        var roomName = info.roomName;
                        if (roomName == "") {
                            roomName = "未命名";
                        }
                        var measurement = info.measurement;
                        var productName = info.productName;
                        var productNumber = info.productNumber;
                        //线段
                        var lines = [];
                        lines.push({x: p1.x, y: p1.y});
                        lines.push({x: p2.x, y: p2.y + 0.25});
                        cad.export.push(genCADLines([lines], {
                            layer: LAYER.ANNOTATION,
                            color: COLOR.ANNOTATION,
                            width: 0
                        }));

                        var lines = [];
                        lines.push({x: p1.x - 1.1, y: p2.y + 0.25});
                        lines.push({x: p2.x + 1.1, y: p2.y + 0.25});
                        cad.export.push(genCADLines([lines], {
                            layer: LAYER.ANNOTATION,
                            color: COLOR.ANNOTATION,
                            width: 0
                        }));

                        //房间名称
                        cad.export.push(genCADLabel({
                            label: "" + roomName + " " + measurement,
                            x: p2.x - 1,
                            y: p2.y + 0.8,
                            size: 10,
                            align: 1,
                            alignmode: 0
                        }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));

                        //主砖信息
                        cad.export.push(genCADLabel({
                            label: "" + productName,
                            x: p2.x - 1,
                            y: p2.y + 0.55,
                            size: 10,
                            align: 1,
                            alignmode: 0
                        }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                        //主砖信息
                        cad.export.push(genCADLabel({
                            label: "" + productNumber,
                            x: p2.x - 1,
                            y: p2.y + 0.3,
                            size: 10,
                            align: 1,
                            alignmode: 0
                        }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                    }
                }

                if (bottomRoomInfo) {
                    for (var i = 0; i < bottomRoomInfo.length; i++) {

                        var info = bottomRoomInfo[i];
                        var p1 = info.p1;
                        var p2 = info.p2;
                        var roomName = info.roomName;
                        if (roomName == "") {
                            roomName = "未命名";
                        }
                        var measurement = info.measurement;
                        var productName = info.productName;
                        var productNumber = info.productNumber;
                        //线段
                        var lines = [];
                        lines.push({x: p1.x, y: p1.y});
                        lines.push({x: p2.x, y: p2.y - 0.25});
                        cad.export.push(genCADLines([lines], {
                            layer: LAYER.ANNOTATION,
                            color: COLOR.ANNOTATION,
                            width: 0
                        }));

                        var lines = [];
                        lines.push({x: p1.x - 1.1, y: p2.y - 0.25});
                        lines.push({x: p2.x + 1.1, y: p2.y - 0.25});
                        cad.export.push(genCADLines([lines], {
                            layer: LAYER.ANNOTATION,
                            color: COLOR.ANNOTATION,
                            width: 0
                        }));

                        //房间名称
                        cad.export.push(genCADLabel({
                            label: "" + roomName + " " + measurement,
                            x: p2.x - 1,
                            y: p2.y - 0.45,
                            size: 10,
                            align: 1,
                            alignmode: 0
                        }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));

                        //主砖信息
                        cad.export.push(genCADLabel({
                            label: "" + productName,
                            x: p2.x - 1,
                            y: p2.y - 0.7,
                            size: 10,
                            align: 1,
                            alignmode: 0
                        }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                        //主砖信息
                        cad.export.push(genCADLabel({
                            label: "" + productNumber,
                            x: p2.x - 1,
                            y: p2.y - 0.95,
                            size: 10,
                            align: 1,
                            alignmode: 0
                        }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                    }
                }
            }

            //导出墙外标尺--add by gaoning 2017.7.15
            var outLabel = api.getOutLabel();
            if (outLabel) {
                var wallLinesArr = api.getCADWallLines();
                if (wallLinesArr) {
                    for (var i = 0; i < wallLinesArr.length; i++) {
                        var wallLine = wallLinesArr[i];
                        var dimData3 = [];

                        //左侧
                        dimData3.push(wallLine.leftPoint1);
                        dimData3.push(wallLine.leftPoint2);

                        //右侧
                        dimData3.push(wallLine.rightPoint1);
                        dimData3.push(wallLine.rightPoint2);

                        //中间
                        dimData3.push(wallLine.centerPoint1);
                        dimData3.push(wallLine.centerPoint2);
                        //文字坐标
                        dimData3.push({x: wallLine.labelPoint.x, y: wallLine.labelPoint.y});
                        cad.export.push(genCADDim(dimData3), {
                            layer: LAYER.ANNOTATION,
                            color: COLOR.ANNOTATION,
                            width: 0
                        });
                    }
                }
            }
            //*************************************************************************************

            if (callback) {


                var frame = {
                    "Project": "Project2017",
                    "Title": "Title01",
                    "Client": "Client01",
                    "Manager": "Manager001",
                    "Designer": "Designer002",
                    //"Drawer": "Drawer01",
                    "ClientTel": "075766880000",
                    "OfficeTel": "075766880000",
                    "DrawingNo": "00001",
                    //"JobNo": "00002",
                    "Scale": "1",
                    //"Size": "A3",
                    "Address": "创意产业园",
                    "Date": "2017.11.15"
                }
                api.getTmallOrderinfo().then(function (data) {
                    var frame = data;

                    //customerNameTxt
                    //customerPhone
                    //daogou
                    //daogouPhone
                    //date
                    //designerName
                    //designerPhone
                    //markTxt
                    //projectNameTxt
                    //ratio
                    //renderingNameTxt
                    //renderingNumber
                    //storeAddress

                    //frame = {
                    //    "Project": data.designerName,
                    //    "Title": data.designerName,
                    //    "Client": data.designerName,
                    //    "Manager": data.designerName,
                    //    "Designer": data.designerName,
                    //    //"Drawer": data.designerName,
                    //    "ClientTel": data.customerPhone,
                    //    "OfficeTel": data.designerName,
                    //    "DrawingNo": data.designerName,
                    //    //"JobNo": "00002",
                    //    "Scale": data.designerName,
                    //    //"Size": data.designerName,
                    //    "Address": data.storeAddress,
                    //    "Date": data.designerName
                    //}

                    //输出多个方案
                    var ret = {};
                    ret.schemes = [];
                    //方案
                    var scheme1 = {};
                    scheme1.name = "户型平面图";
                    scheme1.local = {x: 0, y: 0};
                    scheme1.export = cad.export;
                    scheme1.idsList = idsList; //添加 ids列表

                    //test
                    scheme1.frame = frame;
                    ret.schemes.push(scheme1);
                    callback(ret);
                });

            }
        });
    });
}

//获取对应区域的波打线--add by gaoning 2017.9.6
var getBoundaryFromId = function (roomInfo, id) {
    var boundarys = new Array();
    if (roomInfo.areaboundarys && roomInfo.areaboundarys.length > 0) {
        for (var i = 0; i < roomInfo.areaboundarys.length; i++) {
            if (roomInfo.areaboundarys[i].host.id == id) {
                boundarys.push(roomInfo.areaboundarys[i]);
            }
        }
    }
    return boundarys;
}

//获取上层的区域
var getAreasFromLevel = function (areas, level) {

    var newAreas = new Array();
    areas.forEach(function (area) {

        if (area.areadata.level > level) {
            newAreas.push(area);
        }
    });

    return newAreas;
}

//自定义墙标尺数据类型-- add by gaoning 2017.7.15
function WallLines(leftPoint1, leftPoint2, centerPoint1, centerPoint2, rightPoint1, rightPoint2, labelPoint) {
    this.leftPoint1 = leftPoint1;
    this.centerPoint1 = centerPoint1;
    this.rightPoint1 = rightPoint1;

    this.labelPoint = labelPoint;

    this.leftPoint2 = leftPoint2;
    this.centerPoint2 = centerPoint2;
    this.rightPoint2 = rightPoint2;

    //this.showText = showText;
}

//自定义房间信息标尺数据类型
function RoomInfoLabel(p1, p2, begin, end, roomName, measurement, productName, productNumber, layer, key, isTop) {
    this.key = key;
    this.layer = layer; //0：下层，1：上层
    this.p1 = p1;
    this.p2 = p2;
    this.begin = begin;
    this.end = end;
    this.roomName = roomName;
    this.measurement = measurement;
    this.productName = productName;
    this.productNumber = productNumber;

    this.isTop = isTop;
}

/////////////////////////////////////////////////////////////////////////////
//导出CAD JSON格式数据

//层定义
var LAYER = {
    DEFAULT: "OSN_DEFAULT",				//默认
    WINDOW: "OSN_WINDOW",				//窗
    DOOR: "OSN_DOOR",					//门
    FLOOR: "OSN_FLOOR",					//地面
    WALL: "OSN_WALL",          //墙体
    WALLROD: "OSN_WALLROD",  	    //墙体标尺
    PRODUCT: "OSN_PRODUCT",       //家具
    PILLAR: "OSN_PILLAR",				//柱子
    BASEMENT: "OSN_BASEMENT",      //地台
    BEAM: "OSN_BEAM",          //横梁
    ANNOTATION: "OSN_ANNOTATION",    //注释
};
var CADCOLOR = {
    NONE: 0,
    RED: 1,
    YELLOW: 2,
    GREEN: 3,
    CYAN: 4,
    BLUE: 5,
    PURPLE: 6,
    WHITE: 7,
    GRAY: 8,
    GRAY2: 9,
    GRAY3: 251,
};
var COLOR = {
    DEFAULT: CADCOLOR.NONE,
    WINDOW: CADCOLOR.YELLOW,
    PILLAR: CADCOLOR.CYAN,
    BASEMENT: CADCOLOR.GRAY2,
    BEAM: CADCOLOR.GREEN,
    PRODUCT: CADCOLOR.GREEN,
    DOOR: CADCOLOR.RED,
    WALL: CADCOLOR.CYAN,
    FLOOR: CADCOLOR.GRAY,
    OTHER: CADCOLOR.GREEN,
    WALLROD: CADCOLOR.GRAY2,
    ANNOTATION: CADCOLOR.GRAY2,
    WALLLINE: CADCOLOR.WHITE,
    ROOMTEXT: CADCOLOR.WHITE,
    PARQUET: CADCOLOR.GRAY3,
};


var RATIO = 1;	//单位大小 1000毫米
function genDefaultAttrib() {
    return {layer: LAYER.DEFAULT, color: COLOR.DEFAULT, width: 0};
}
function genCADPolylines(data, attrib) {
    var ret = {};
    ret.type = "POLYLINE";
    ret.attrib = attrib;

    var dataRet = {polyline: []};

    if (data.ids != null) {
        dataRet = {polyline: [], ids: {id: "", ox: 0, oy: 0, sx: 1, sy: 1, rot: 0, color: 0}};
        dataRet.ids.id = data.ids.id;
        dataRet.ids.ox = data.ids.ox * RATIO;
        dataRet.ids.oy = data.ids.oy * RATIO;
        dataRet.ids.sx = data.ids.sx;
        dataRet.ids.sy = data.ids.sy;
        dataRet.ids.rot = data.ids.rot;
        dataRet.ids.color = data.ids.color;
    }

    data.polyline.forEach(function (object) {
        dataRet.polyline.push({x: object.x * RATIO, y: object.y * RATIO});
    });
    ret.data = dataRet;
    return ret;
}
function genCADLines(data, attrib) {
    var ret = {};
    ret.type = "LINE";
    ret.attrib = attrib;

    var dataRet = [];
    data.forEach(function (object) {
        dataRet.push([{x: object[0].x * RATIO, y: object[0].y * RATIO}, {
            x: object[1].x * RATIO,
            y: object[1].y * RATIO
        }]);
    });
    ret.data = dataRet;
    return ret;
}
function genCADDoor(data, attrib) {
    var ret = {};
    ret.type = "DOOR";
    ret.attrib = attrib;

    var dataRet = {};
    dataRet.id = data.id;
    dataRet.pid = data.pid;
    dataRet.rotate = data.rotate;
    dataRet.subcategory = data.subcategory;

    dataRet.baseline = [];
    data.baseline.forEach(function (object) {
        dataRet.baseline.push({x: object.x * RATIO, y: object.y * RATIO});
    });

    dataRet.polyline = [];
    data.polyline.forEach(function (object) {
        dataRet.polyline.push({x: object.x * RATIO, y: object.y * RATIO});
    });

    ret.data = dataRet;
    return ret;
}
function genCADWindow(data, attrib) {
    var ret = {};
    ret.type = "WINDOW";
    ret.attrib = attrib;

    var dataRet = {};
    dataRet.id = data.id;
    dataRet.pid = data.pid;
    dataRet.rotate = data.rotate;
    dataRet.subcategory = data.subcategory;

    dataRet.centerline = [];
    data.centerline.forEach(function (object) {
        dataRet.centerline.push({x: object.x * RATIO, y: object.y * RATIO});
    });

    dataRet.polyline = [];
    data.polyline.forEach(function (object) {
        dataRet.polyline.push({x: object.x * RATIO, y: object.y * RATIO});
    });

    ret.data = dataRet;
    return ret;
}
function genCADLabel(data, attrib) {
    //align 0中间对齐 1左边对齐 2右边对其
    //{label:,x:,y:,size:}
    var ret = {};
    ret.type = "LABEL";
    ret.attrib = attrib;

    var dataRet = {};
    dataRet.label = data.label;
    dataRet.size = data.size * RATIO;
    dataRet.x = data.x * RATIO;
    dataRet.y = data.y * RATIO;
    dataRet.align = data.align || 0;
    dataRet.alignmode = data.alignmode || 0;
    ret.data = dataRet;
    return ret;
}
function genCADFloor(data, attrib) {
    var ret = {};
    ret.type = "FLOOR";
    ret.attrib = attrib;

    var dataRet = {lines: [], polyline: []};
    data.lines.forEach(function (object) {
        dataRet.lines.push([{x: object[0].x * RATIO, y: object[0].y * RATIO}, {
            x: object[1].x * RATIO,
            y: object[1].y * RATIO
        }]);
    });
    data.polyline.forEach(function (object) {
        dataRet.polyline.push({x: object.x * RATIO, y: object.y * RATIO});
    });
    ret.data = dataRet;
    return ret;
}
function genCADDim(data, attrib) {
    var ret = {};
    ret.type = "DIM";
    ret.attrib = attrib;

    var dataRet = [];
    data.forEach(function (object) {
        dataRet.push({x: object.x * RATIO, y: object.y * RATIO});
    });
    ret.data = dataRet;
    return ret;
}
//导出CAD JSON格式数据 end by mond 2016-2017
/////////////////////////////////////////////////////////////////////////////