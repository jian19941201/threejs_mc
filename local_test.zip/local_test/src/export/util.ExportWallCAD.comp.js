/**
 * Created by gn on 2018/1/21.
 */
(function (root) {
//对需要导出的数据进行整理(去业务化)
    root.utilExportJSONData3 = function (room, callback) {

        var idsList = [],idsDic = new Dictionary();

        var roomModel = room.model;
        //console.log(roomModel);
        getWallInsideLoopFromProfile(roomModel);
        var innerPos = geom;
        var maxWallLength = getMaxWallLength(innerPos);
        var fp = application.doc.floorplan;

        var roomName = roomModel.label == "" ? "未命名" : roomModel.label;
        var cad = {};
        cad.export = [];
        var wallLabel = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
        var wallPoints = [];
        var clipperNumber = 10000;
        //1.房间命名和平方米
        //cad.export.push(genCADLabel({
        //    label: roomModel.label == "" ? "未命名" : roomModel.label,
        //    x: roomModel.labelX,
        //    y: roomModel.labelY,
        //    size: 12,
        //    align: 0
        //}, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
        //cad.export.push(genCADLabel({
        //    label: roomModel.measurementLabel == "" ? "空" : roomModel.measurementLabel,
        //    x: roomModel.labelX,
        //    y: roomModel.labelY - 0.4,
        //    size: 12,
        //    align: 0
        //}, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));

        //记录房间的内墙坐标点wallPaths
        var wallPaths = [];
        var wallsPoly = [];
        for (var i = 0; i < innerPos.length; ++i) {
            wallPaths.push({
                X: Math.ceil(innerPos[i].x * clipperNumber),
                Y: Math.ceil(innerPos[i].y * clipperNumber)
            });
        }
        //wallPaths.push(wallsPoly);
        //console.log(wallPaths);

        //导出房间内的信息
        var bomData = api.getBomData();
        utilCatalogGetProductsMetaPromise(application.catalogMgr, bomData.pids).then(function (meta) {
            bomData.metas = meta;
            bomData.rooms.forEach(function (roomInfo) {

                //console.log(roomInfo);

                if (roomInfo.floor.id == roomModel.id) {//只导出选中房间的信息
                    var bomRoom = roomInfo;

                    //房间的波打线
                    if (roomInfo.boundarys && roomInfo.boundarys.length > 0) {
                        roomInfo.boundarys.forEach(function (boundary) {
                            if (boundary.host.id == roomInfo.floor.id) {
                                boundary.floorRectTiles.forEach(function (floorRectTiles) {
                                    floorRectTiles.tiles.forEach(function (tiles) {
                                        if (tiles.tileProfile) {
                                            tiles.tileProfile.forEach(function (points) {
                                                var line = {polyline: []};
                                                points.forEach(function (pos) {
                                                    line.polyline.push({
                                                        x: pos.x,
                                                        y: pos.y
                                                    });
                                                });
                                                cad.export.push(genCADPolylines(line, {
                                                    layer: LAYER.FLOOR,
                                                    color: COLOR.FLOOR,
                                                    width: 0
                                                }));
                                            });
                                        }
                                    });
                                });
                            }//if(boundary.host.id == roomInfo.floor.id)
                        });
                    }//if (roomInfo.boundarys && roomInfo.boundarys.length > 0)

                    // 区域的波打线
                    if (roomInfo.areaboundarys && roomInfo.areaboundarys.length > 0) {
                        roomInfo.areaboundarys.forEach(function (boundary) {
                            boundary.floorRectTiles.forEach(function (floorRectTiles) {

                                floorRectTiles.tiles.forEach(function (tiles) {
                                    if (tiles.tileProfile) {
                                        tiles.tileProfile.forEach(function (points) {
                                            var linePaths = [];
                                            var line = [];
                                            points.forEach(function (pos) {
                                                line.push({
                                                    X: Math.ceil(pos.x * clipperNumber),
                                                    Y: Math.ceil(pos.y * clipperNumber)
                                                });
                                            });
                                            linePaths.push(line);

                                            ////////////////////////////////////////////////////////////
                                            //波打线内铺砖对房间的裁剪
                                            var cpr = new ClipperLib.Clipper();
                                            var solution = new ClipperLib.PolyTree();
                                            cpr.Clear();
                                            cpr.AddPaths(linePaths, ClipperLib.PolyType.ptSubject, true);
                                            cpr.AddPath(wallPaths, ClipperLib.PolyType.ptClip, true);
                                            cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);

                                            //把房间外的波打线裁剪后画线
                                            for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                var boundaryaData = {polyline: []};
                                                for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                    boundaryaData.polyline.push({
                                                        x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                                        y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                                    });
                                                }
                                                if (boundaryaData.polyline.length > 0) {
                                                    boundaryaData.polyline.push({
                                                        x: boundaryaData.polyline[0].x,
                                                        y: boundaryaData.polyline[0].y
                                                    });
                                                    cad.export.push(genCADPolylines(boundaryaData, {
                                                        layer: LAYER.FLOOR,
                                                        color: COLOR.FLOOR,
                                                        width: 0
                                                    }));
                                                }
                                            }
                                            //////////////////////////////////////////////////////////////////
                                        });
                                    }
                                });
                            });
                        });
                    }

                    //地面铺砖信息
                    //var bomFloor = bomRoom && bomRoom.floor;
                    var bomFloor = bomRoom && bomRoom.tiles;
                    if (bomFloor) {

                        var areas = roomInfo.floorareas;//content.areas;//
                        //var areas = api.floorplanFilterEntity(function (e) {
                        //    //console.log(e.type);//BOUNDARY
                        //    return e.type == "RECTAREA" || e.type == "ROUNDAREA";
                        //});
                        if ((areas && areas.length > 0)) {
                            var paths = [];
                            var bomOthersPaths = []; //用来做区域内柱子的剔除
                            areas.forEach(function (area) {

                                //把区域添加到paths
                                //var areaBoundarys = getBoundarysFromAreaId(area.materialid); // area.areadata.id
                                var areaBoundarys = getBoundaryFromId(roomInfo, area.id);
                                if (areaBoundarys.length > 0) {
                                    var areaPoly2 = [];
                                    for (var i = 0; i < area.loop.length; ++i) {
                                        areaPoly2.push({
                                            x: area.loop[i].x,
                                            y: area.loop[i].y
                                        });
                                    }
                                    var areaBoundarysLength = 0;
                                    for (var b = 0; b < areaBoundarys.length; b++) {
                                        areaBoundarysLength += areaBoundarys[b].size;
                                    }
                                    var newOffect = utilAdaptorClipperExtend(areaPoly2, areaBoundarysLength);

                                    var areaPoly = [];
                                    for (var i = 0; i < newOffect.length; ++i) {
                                        areaPoly.push({
                                            X: Math.ceil(newOffect[i].x * clipperNumber),
                                            Y: Math.ceil(newOffect[i].y * clipperNumber)
                                        });
                                    }
                                    paths.push(areaPoly);

                                } else {
                                    var areaPoly = [];
                                    for (var i = 0; i < area.loop.length; ++i) {
                                        areaPoly.push({
                                            X: Math.ceil(area.loop[i].x * clipperNumber),
                                            Y: Math.ceil(area.loop[i].y * clipperNumber)
                                        });
                                    }
                                    paths.push(areaPoly);
                                }

                                //区域的外框线与房间内墙线做裁剪
                                ////////////////////////////////////////////////////////////
                                if (paths.length > 0) {

                                    var newPaths = [];

                                    var cpr = new ClipperLib.Clipper();
                                    var solution = new ClipperLib.PolyTree();
                                    cpr.Clear();
                                    cpr.AddPaths(paths, ClipperLib.PolyType.ptSubject, true);
                                    cpr.AddPath(wallPaths, ClipperLib.PolyType.ptClip, true);
                                    cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);

                                    //把房间外的波打线裁剪后画线
                                    for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                        var pathData = [];
                                        //var areasData = {polyline: []};
                                        for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {

                                            pathData.push({
                                                X: Math.ceil(solution.m_AllPolys[i].m_polygon[m].X),
                                                Y: Math.ceil(solution.m_AllPolys[i].m_polygon[m].Y)
                                            });
                                            //areasData.polyline.push({
                                            //    x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                            //    y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                            //});
                                        }
                                        newPaths.push(pathData);
                                        //if (areasData.polyline.length > 0) {
                                        //    areasData.polyline.push({
                                        //        x: areasData.polyline[0].x,
                                        //        y: areasData.polyline[0].y
                                        //    });
                                        //    cad.export.push(genCADPolylines(areasData, {
                                        //        layer: LAYER.FLOOR,
                                        //        color: COLOR.FLOOR,
                                        //        width: 0
                                        //    }));
                                        //}
                                    }
                                    paths = newPaths;
                                }
                                //////////////////////////////////////////////////////////////////

                                //区域内的铺砖线导出
                                area.floorRectTiles.forEach(function (floorRectTiles) {

                                    if (floorRectTiles.tileProfile) {

                                        var highAreaPaths = [];
                                        var highArea = getAreasFromLevel2(areas, area.level);
                                        for (var a = 0; a < highArea.length; a++) {
                                            //var areaBoundarys = getBoundarysFromAreaId(highArea[a].materialid);
                                            var areaBoundarys = getBoundaryFromId(roomInfo, highArea[a].id);
                                            if (areaBoundarys.length > 0) {
                                                var areaPoly2 = [];
                                                for (var i = 0; i < highArea[a].loop.length; ++i) {
                                                    areaPoly2.push({
                                                        x: highArea[a].loop[i].x,
                                                        y: highArea[a].loop[i].y
                                                    });
                                                }
                                                //计算所有外层波打线的宽度
                                                var areaBoundarysLength = 0;
                                                for (var b = 0; b < areaBoundarys.length; b++) {
                                                    areaBoundarysLength += areaBoundarys[b].size;
                                                }
                                                var newOffect = utilAdaptorClipperExtend(areaPoly2, areaBoundarysLength);

                                                var areaPoly = [];
                                                for (var i = 0; i < newOffect.length; ++i) {
                                                    areaPoly.push({
                                                        X: Math.ceil(newOffect[i].x * clipperNumber),
                                                        Y: Math.ceil(newOffect[i].y * clipperNumber)
                                                    });
                                                }

                                                highAreaPaths.push(areaPoly);

                                            } else {
                                                var areaPoly = [];
                                                for (var i = 0; i < highArea[a].loop.length; ++i) {
                                                    areaPoly.push({
                                                        X: Math.ceil(highArea[a].loop[i].x * clipperNumber),
                                                        Y: Math.ceil(highArea[a].loop[i].y * clipperNumber)
                                                    });
                                                }
                                                highAreaPaths.push(areaPoly);
                                            }
                                        }

                                        //判断此区域上层有没有区域，要做区域内的区域裁剪。
                                        //没有柱子里，就不用考虑对柱子剔除
                                        if (bomOthersPaths.length == 0 && highAreaPaths.length == 0) {

                                            var areaPaths = [];
                                            for (var i = 0; i < floorRectTiles.tileProfile.length; i++) {
                                                //var areaData = {
                                                //    polyline: [],
                                                //    ids: {id: "", ox: 0, oy: 0, sx: 1, sy: 1, rot: 0}
                                                //};
                                                //for (var t = 0; t < floorRectTiles.tileProfile[i].length; t++) {
                                                //    areaData.polyline.push({
                                                //        x: floorRectTiles.tileProfile[i][t].x,
                                                //        y: floorRectTiles.tileProfile[i][t].y
                                                //    });
                                                //}
                                                //if (areaData.polyline.length > 0) {
                                                //    areaData.polyline.push({
                                                //        x: areaData.polyline[0].x,
                                                //        y: areaData.polyline[0].y
                                                //    });
                                                //
                                                //    areaData.ids.id = floorRectTiles.material.pid;
                                                //    areaData.ids.ox = floorRectTiles.origin.x;
                                                //    areaData.ids.oy = floorRectTiles.origin.y;
                                                //    areaData.ids.sx = floorRectTiles.material.sx;
                                                //    areaData.ids.sy = floorRectTiles.material.sy;
                                                //    areaData.ids.rot = floorRectTiles.rot == undefined ? 0 : floorRectTiles.rot;
                                                //
                                                //    cad.export.push(genCADPolylines(areaData, {
                                                //        layer: LAYER.FLOOR,
                                                //        color: COLOR.FLOOR,
                                                //        width: 0
                                                //    }));
                                                //}
                                                var data = [];
                                                for (var t = 0; t < floorRectTiles.tileProfile[i].length; t++) {
                                                    data.push({
                                                        X: Math.ceil(floorRectTiles.tileProfile[i][t].x * clipperNumber),
                                                        Y: Math.ceil(floorRectTiles.tileProfile[i][t].y * clipperNumber)
                                                    });
                                                }
                                                areaPaths.push(data);
                                            }
                                            //区域内的铺砖线与房间内墙线做裁剪
                                            ////////////////////////////////////////////////////////////
                                            var cpr = new ClipperLib.Clipper();
                                            var solution = new ClipperLib.PolyTree();
                                            cpr.Clear();
                                            cpr.AddPaths(areaPaths, ClipperLib.PolyType.ptSubject, true);
                                            cpr.AddPath(wallPaths, ClipperLib.PolyType.ptClip, true);
                                            cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);

                                            //把房间外的波打线裁剪后画线
                                            for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                var areasData = {polyline: []};
                                                for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                    areasData.polyline.push({
                                                        x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                                        y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                                    });
                                                }
                                                if (areasData.polyline.length > 0) {
                                                    areasData.polyline.push({
                                                        x: areasData.polyline[0].x,
                                                        y: areasData.polyline[0].y
                                                    });
                                                    cad.export.push(genCADPolylines(areasData, {
                                                        layer: LAYER.FLOOR,
                                                        color: COLOR.FLOOR,
                                                        width: 0
                                                    }));
                                                }
                                            }
                                            //////////////////////////////////////////////////////////////////

                                        } else {  //先进行区域内对柱子剔除再画区域内铺砖信息
                                            //添加区域内对上层区域的裁剪
                                            var cpr = new ClipperLib.Clipper();
                                            var solution = new ClipperLib.PolyTree();
                                            var clipAreaPaths = [];
                                            var areaLine = [];
                                            for (var i = 0; i < floorRectTiles.tileProfile.length; i++) {
                                                for (var t = 0; t < floorRectTiles.tileProfile[i].length; t++) {
                                                    areaLine.push({
                                                        X: Math.ceil(floorRectTiles.tileProfile[i][t].x * clipperNumber),
                                                        Y: Math.ceil(floorRectTiles.tileProfile[i][t].y * clipperNumber)
                                                    });
                                                }

                                                clipAreaPaths.push(areaLine);

                                                //开始剔除柱子
                                                for (var p = 0; p < bomOthersPaths.length; p++) {
                                                    if (solution && solution.m_AllPolys.length > 0) {
                                                        clipAreaPaths = [];
                                                        for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                            var polygon = [];
                                                            for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                                polygon.push({
                                                                    X: solution.m_AllPolys[i].m_polygon[m].X,
                                                                    Y: solution.m_AllPolys[i].m_polygon[m].Y
                                                                });
                                                            }
                                                            clipAreaPaths.push(polygon);
                                                        }
                                                        cpr.Clear();
                                                        cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                        cpr.AddPath(bomOthersPaths[p], ClipperLib.PolyType.ptClip, true);

                                                        solution = new ClipperLib.PolyTree();
                                                        cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                                    }
                                                    else if (p == 0) {  //没有solution值时先处理第一个
                                                        cpr.Clear();
                                                        cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                        cpr.AddPath(bomOthersPaths[p], ClipperLib.PolyType.ptClip, true);

                                                        solution = new ClipperLib.PolyTree();
                                                        cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                                    }
                                                }

                                                //接着裁剪上层区域
                                                for (var p = 0; p < highAreaPaths.length; p++) {
                                                    if (solution && solution.m_AllPolys.length > 0) {
                                                        clipAreaPaths = [];
                                                        for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                            var polygon = [];
                                                            for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                                polygon.push({
                                                                    X: solution.m_AllPolys[i].m_polygon[m].X,
                                                                    Y: solution.m_AllPolys[i].m_polygon[m].Y
                                                                });
                                                            }
                                                            clipAreaPaths.push(polygon);
                                                        }
                                                        cpr.Clear();
                                                        cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                        cpr.AddPath(highAreaPaths[p], ClipperLib.PolyType.ptClip, true);

                                                        solution = new ClipperLib.PolyTree();
                                                        cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                                    } else if (p == 0) {  //没有solution值时先处理第一个
                                                        cpr.Clear();
                                                        cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                        cpr.AddPath(highAreaPaths[p], ClipperLib.PolyType.ptClip, true);

                                                        solution = new ClipperLib.PolyTree();
                                                        cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                                    }
                                                }

                                                //接着房间内墙线再裁剪外面的区域铺砖
                                                cpr.Clear();
                                                cpr.AddPaths(clipAreaPaths, ClipperLib.PolyType.ptSubject, true);
                                                cpr.AddPath(wallPaths, ClipperLib.PolyType.ptClip, true);

                                                solution = new ClipperLib.PolyTree();
                                                cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);

                                                //裁剪完清空
                                                highAreaPaths = [];

                                                //把柱子从区域剔除后开始画区域内的地面铺砖线
                                                for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                                    var areaData = {polyline: []};
                                                    for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                        areaData.polyline.push({
                                                            x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                                            y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                                        });
                                                    }
                                                    if (areaData.polyline.length > 0) {
                                                        areaData.polyline.push({
                                                            x: areaData.polyline[0].x,
                                                            y: areaData.polyline[0].y
                                                        });
                                                        cad.export.push(genCADPolylines(areaData, {
                                                            layer: LAYER.FLOOR,
                                                            color: COLOR.FLOOR,
                                                            width: 0
                                                        }));
                                                    }

                                                }
                                            }

                                        }
                                    }
                                });
                            });


                            //对地面开始进行区域和柱子的剔除
                            bomFloor.forEach(function (tiles) {

                                var cpr = new ClipperLib.Clipper();
                                var solution = new ClipperLib.PolyTree();
                                var clipPaths = [];
                                var line = [];
                                for (var i = 0; i < tiles.length; i++) {
                                    for (var t = 0; t < tiles[i].length; t++) {
                                        line.push({
                                            X: Math.ceil(tiles[i][t].x * clipperNumber),
                                            Y: Math.ceil(tiles[i][t].y * clipperNumber)
                                        });
                                    }
                                }
                                clipPaths.push(line);

                                //开始剔除
                                for (var p = 0; p < paths.length; p++) {
                                    if (solution && solution.m_AllPolys.length > 0) {
                                        clipPaths = [];
                                        for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                            var polygon = [];
                                            for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                                polygon.push({
                                                    X: solution.m_AllPolys[i].m_polygon[m].X,
                                                    Y: solution.m_AllPolys[i].m_polygon[m].Y
                                                });
                                            }
                                            clipPaths.push(polygon);
                                        }
                                        cpr.Clear();
                                        cpr.AddPaths(clipPaths, ClipperLib.PolyType.ptSubject, true);
                                        cpr.AddPath(paths[p], ClipperLib.PolyType.ptClip, true);

                                        solution = new ClipperLib.PolyTree();
                                        cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                    }
                                    else if (p == 0) {  //先处理第一个
                                        cpr.Clear();
                                        cpr.AddPaths(clipPaths, ClipperLib.PolyType.ptSubject, true);
                                        cpr.AddPath(paths[p], ClipperLib.PolyType.ptClip, true);

                                        solution = new ClipperLib.PolyTree();
                                        cpr.Execute(ClipperLib.ClipType.ctUnion, solution);
                                    }
                                }

                                //把区域和柱子都剔除后开始画地面铺砖线

                                for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                                    var floorData = {polyline: []};
                                    for (var m = 0; m < solution.m_AllPolys[i].m_polygon.length; ++m) {
                                        floorData.polyline.push({
                                            x: solution.m_AllPolys[i].m_polygon[m].X / clipperNumber,
                                            y: solution.m_AllPolys[i].m_polygon[m].Y / clipperNumber
                                        });
                                    }
                                    if (floorData.polyline.length > 0) {
                                        floorData.polyline.push({
                                            x: floorData.polyline[0].x,
                                            y: floorData.polyline[0].y
                                        });
                                        cad.export.push(genCADPolylines(floorData, {
                                            layer: LAYER.FLOOR,
                                            color: COLOR.FLOOR,
                                            width: 0
                                        }));
                                    }
                                }


                            });
                        } else {//没有剔除的情况下
                            bomFloor.forEach(function (tiles) {

                                for (var i = 0; i < tiles.length; i++) {
                                    var floorData = {polyline: []};
                                    for (var t = 0; t < tiles[i].length; t++) {
                                        floorData.polyline.push({x: tiles[i][t].x, y: tiles[i][t].y});
                                    }
                                    if (floorData.polyline.length > 0) {
                                        floorData.polyline.push({
                                            x: floorData.polyline[0].x,
                                            y: floorData.polyline[0].y
                                        });
                                        cad.export.push(genCADPolylines(floorData, {
                                            layer: LAYER.FLOOR,
                                            color: COLOR.FLOOR,
                                            width: 0
                                        }));
                                    }
                                }

                            });
                        }
                    }
                    //=========================================================================================

                    //画内墙线
                    for (var i = 0; i < innerPos.length - 1; i++) {

                        wallPoints.push(innerPos[i]);

                        var wallData1 = {polyline: []};
                        wallData1.polyline.push({x: innerPos[i].x, y: innerPos[i].y});
                        wallData1.polyline.push({x: innerPos[i + 1].x, y: innerPos[i + 1].y});
                        if (wallData1.polyline.length > 0) {
                            cad.export.push(genCADPolylines(wallData1, {
                                layer: LAYER.WALL,
                                color: COLOR.WALL,
                                width: 0
                            }));
                        }
                    }

                    //内墙尺寸标线
                    //墙标志ABCD......
                    //获取户型右下角的坐标
                    var rightBottomPoint = GetLightBottomPoint(wallPoints);
                    var wallLabelIndex = 0;
                    //wallProfile.forEach(function (wall) {
                    for (var i = 0; i < wallInnerPointArr.length; i++) {
                        var wall = wallInnerPointArr[i][0];//fp.lf[wallInnerPointArr[i][0]];

                        //定义标尺和ABCD显示在房间外层
                        var innerDirection = 1,outDirection = -1;
                        var wallBegin = getPreviousPoint(i);//getNextPointFromGeom(innerPos, wallInnerPointArr[i][1]);//wall.begin;
                        var wallEnd = wallInnerPointArr[i][1];//wall.end;

                        //计算是否显示墙信息
                        var widthSide = utilModelWallGetSideLength(wall, wallInnerPointArr[i][2]);
                        var sideWidths = utilModelWallGetSmoothRawDatas(wall, wallInnerPointArr[i][2]);
                        //获取墙标尺的坐标点
                        if (sideWidths && sideWidths.length > 0) {
                            var startWallSide = sideWidths[0].side;
                            if (startWallSide == "left") {
                                wallBegin = sideWidths[0].wall._lines[1];
                                wallEnd = sideWidths[0].wall._lines[2];
                                innerDirection = -2,outDirection = 1.5;
                            } else if (startWallSide == "right") {
                                wallBegin = sideWidths[0].wall._lines[5];
                                wallEnd = sideWidths[0].wall._lines[4];
                                innerDirection = 2,outDirection = -1;
                            }
                        }

                        //开始画墙标线
                        var defaultDimensionPositionComparedCallback = function (begin, end) {
                            return 1;
                        };
                        var dimPosCompared = defaultDimensionPositionComparedCallback;
                        //计算用于画墙标尺
                        var perpendicularOffset = DEFAULT_WALL_WIDTH_INNER * outDirection + wall.width;
                        var dimBeginInWall = wallBegin;
                        var dimEndInWall = wallEnd;
                        var dimBegin = utilMathGetScaledPoint(dimBeginInWall, utilMathRotatePointCW(dimBeginInWall, dimEndInWall,
                            90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
                        var dimEnd = utilMathGetScaledPoint(dimEndInWall, utilMathRotatePointCW(dimEndInWall,
                            dimBeginInWall, -90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
                        var dimMiddle = {
                            x: (dimBegin.x + dimEnd.x) / 2,
                            y: (dimBegin.y + dimEnd.y) / 2
                        };
                        var dimBeginPerpendicularLineBegin = utilMathGetScaledPoint(dimBegin, utilMathRotatePointCW(dimBegin, dimEnd, -90), DEFAULT_WALL_WIDTH / 2);
                        var dimBeginPerpendicularLineEnd = utilMathGetScaledPoint(dimBeginPerpendicularLineBegin, dimBegin, DEFAULT_WALL_WIDTH);
                        var dimEndPerpendicularLineBegin = utilMathGetScaledPoint(dimEnd, utilMathRotatePointCW(dimEnd, dimBegin, 90), DEFAULT_WALL_WIDTH / 2);
                        var dimEndPerpendicularLineEnd = utilMathGetScaledPoint(dimEndPerpendicularLineBegin, dimEnd, DEFAULT_WALL_WIDTH);

                        //房间墙的长度标尺
                        var dimData = [];
                        //左侧
                        dimData.push(dimBeginPerpendicularLineBegin);
                        dimData.push(dimBeginPerpendicularLineEnd);
                        //右侧
                        dimData.push(dimEndPerpendicularLineBegin);
                        dimData.push(dimEndPerpendicularLineEnd);
                        //中间
                        dimData.push(dimBegin);
                        dimData.push(dimEnd);
                        //数字坐标
                        dimData.push({x: dimMiddle.x, y: dimMiddle.y});
                        cad.export.push(genCADDim(dimData), {
                            layer: LAYER.ANNOTATION,
                            color: COLOR.ANNOTATION,
                            width: 0
                        });
                        /////////////////////////////////////////////////////墙标尺
                        /////////////////////////////////////////////////////////////////////////////

                        if (wall && widthSide != 0) {

                            //utilModelWallIsSmoothStart
                            //utilModelWallGetSmoothRawDatas
                            var isStart = utilModelWallIsSmoothStart(wall, wallInnerPointArr[i][2]);
                            var width = sideWidths[0].width;
                            if (isStart) {
                                width = 0;
                                for (var l = 0; l < sideWidths.length; l++) {
                                    width += sideWidths[l].width;
                                }
                                if (sideWidths && sideWidths.length > 0) {
                                    //start
                                    var startWallSide = sideWidths[0].side;
                                    if (startWallSide == "left") {
                                        wallBegin = sideWidths[0].wall._lines[1];
                                        innerDirection = -2;
                                    } else if (startWallSide == "right") {
                                        wallBegin = sideWidths[0].wall._lines[5];
                                        innerDirection = 2;
                                    }
                                    //end
                                    var endWallSide = sideWidths[sideWidths.length - 1].side;
                                    if (endWallSide == "left") {
                                        wallEnd = sideWidths[sideWidths.length - 1].wall._lines[2];
                                    } else if (endWallSide == "right") {
                                        wallEnd = sideWidths[sideWidths.length - 1].wall._lines[4];
                                    }
                                }
                            }

                            if (wallBegin && wallEnd && !isNaN(wallBegin.x) && !isNaN(wallEnd.x)) {
                                //计算用于画墙标记ABCD
                                var perpendicularOffset2 = DEFAULT_WALL_WIDTH_INNER * 2 * innerDirection + wall.width;
                                var dimBeginInWall2 = wallBegin;
                                var dimEndInWall2 = wallEnd;
                                var dimBegin2 = utilMathGetScaledPoint(dimBeginInWall2, utilMathRotatePointCW(dimBeginInWall2, dimEndInWall2,
                                    90 * (dimPosCompared(dimBeginInWall2, dimEndInWall2) ? 1 : -1)), perpendicularOffset2);
                                var dimEnd2 = utilMathGetScaledPoint(dimEndInWall2, utilMathRotatePointCW(dimEndInWall2,
                                    dimBeginInWall2, -90 * (dimPosCompared(dimBeginInWall2, dimEndInWall2) ? 1 : -1)), perpendicularOffset2);
                                var dimMiddle2 = {
                                    x: (dimBegin2.x + dimEnd2.x) / 2,
                                    y: (dimBegin2.y + dimEnd2.y) / 2
                                };
                                var dimBeginPerpendicularLineBegin2 = utilMathGetScaledPoint(dimBegin2, utilMathRotatePointCW(dimBegin2, dimEnd2, -90), DEFAULT_WALL_WIDTH / 2);
                                var dimBeginPerpendicularLineEnd2 = utilMathGetScaledPoint(dimBeginPerpendicularLineBegin2, dimBegin2, DEFAULT_WALL_WIDTH);
                                var dimEndPerpendicularLineBegin2 = utilMathGetScaledPoint(dimEnd2, utilMathRotatePointCW(dimEnd2, dimBegin2, 90), DEFAULT_WALL_WIDTH / 2);
                                var dimEndPerpendicularLineEnd2 = utilMathGetScaledPoint(dimEndPerpendicularLineBegin2, dimEnd2, DEFAULT_WALL_WIDTH);
                                ///////////////////////////////////////////////////////////////////////////

                                //房间内标记墙ABCD
                                cad.export.push(genCADLabel({
                                    label: String.fromCharCode(65 + Number(wallLabelIndex)),//wallLabel[wallLabelIndex],
                                    x: dimMiddle2.x - 0.2,
                                    y: dimMiddle2.y,
                                    size: 28,
                                    align: 0
                                }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));
                                ///////////////////////////////////////////////////////////////////////////
                                ///////////////////////////////////////////////////////////////////////////

                                //画墙长宽
                                //var width = getLength(wallBegin, wallEnd);
                                if (wall.bezier) {
                                    width = getBezierWallLength(wall, wallInnerPointArr[i][2]);
                                }
                                var height = wall.height3d;

                                var firstPoint = new Vec2(rightBottomPoint.x + 2, rightBottomPoint.y);

                                var distance = height + 1.5;//每墙之前的间距1.5

                                //墙左下角标记ABCD......
                                cad.export.push(genCADLabel({
                                    label: String.fromCharCode(65 + Number(wallLabelIndex)),//wallLabel[wallLabelIndex],
                                    x: firstPoint.x + 0.1 + maxWallLength * (Math.floor(wallLabelIndex / 4)) + width,
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) + height / 2,//超过4个就排到第二排
                                    size: 28,
                                    align: 0
                                }, {layer: LAYER.ANNOTATION, color: COLOR.ANNOTATION, width: 0}));

                                //画墙的铺砖信息--先画墙内砖线再画墙
                                //var planeIndex = wallInnerPlaneDic.get(wall.id);  //0:right  1:left
                                var wallboardCategory = wallInnerPointArr[i][2];//planeIndex == 1 ? "left" : "right";
                                var boards = [];//planeIndex == 1 ? wall.leftBoards : wall.rightBoards;
                                if (wallInnerPointArr[i][2] == "left") {
                                    boards = wall.leftBoards;
                                } else if (wallInnerPointArr[i][2] == "right") {
                                    boards = wall.rightBoards;
                                } else if (wallInnerPointArr[i][2] == "side0") {
                                    boards = wall.side0Boards;
                                } else if (wallInnerPointArr[i][2] == "side1") {
                                    boards = wall.side1Boards;
                                } else {
                                    boards = [];
                                }

                                if (boards && boards.length > 0) {
                                    for (var b = 0; b < boards.length; b++) {
                                        //获取区域，并画出区域的铺砖信息
                                        var board = fp.lf[boards[b]];
                                        if (board) {
                                            //console.log(board);
                                            var floorRectOrigin = board.floorRectOrigin;
                                            var floorRectTiles = board.floorRectTiles;
                                            floorRectTiles.forEach(function (tiles) {

                                                var tileProfile = tiles.tileProfile;
                                                if (tileProfile) {
                                                    tileProfile.forEach(function (profile) {
                                                        var floorData = {polyline: []};
                                                        for (var p = 0; p < profile.length; p++) {
                                                            floorData.polyline.push({
                                                                x: profile[p].x + firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                                                y: profile[p].y + firstPoint.y + distance * (wallLabelIndex % 4)
                                                            });
                                                        }
                                                        if (floorData.polyline.length > 0) {
                                                            //闭合矩形
                                                            floorData.polyline.push({
                                                                x: floorData.polyline[0].x,
                                                                y: floorData.polyline[0].y
                                                            });
                                                            cad.export.push(genCADPolylines(floorData, {
                                                                layer: LAYER.FLOOR,
                                                                color: COLOR.FLOOR,
                                                                width: 0
                                                            }));
                                                        }
                                                    });
                                                }

                                            });
                                        }
                                    }
                                }
                                ///////////////////////////////////////////////////////////////////////

                                //墙上区域铺砖信息 category  right left
                                var rectArea3dList = api.floorplanFilterEntity(function (e) {
                                    return e.type == "RECTAREA3D" || e.type == "ROUNDAREA3D" || e.type == "WALLBOARD";
                                });
                                if (rectArea3dList.length > 0) {
                                    for (var r = 0; r < rectArea3dList.length; r++) {
                                        var category = rectArea3dList[r].category;
                                        if (rectArea3dList[r].host.id == wall.id && category == wallboardCategory) {

                                            var floorRectOrigin = rectArea3dList[r].floorRectOrigin;
                                            var floorRectTiles = rectArea3dList[r].floorRectTiles;
                                            floorRectTiles.forEach(function (tiles) {
                                                if (tiles.tileProfile) {
                                                    tiles.tileProfile.forEach(function (profile) {

                                                        var floorData = {polyline: []};
                                                        for (var p = 0; p < profile.length; p++) {
                                                            floorData.polyline.push({
                                                                x: profile[p].x + firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                                                y: profile[p].y + firstPoint.y + distance * (wallLabelIndex % 4)
                                                            });
                                                        }
                                                        if (floorData.polyline.length > 0) {
                                                            //闭合矩形
                                                            floorData.polyline.push({
                                                                x: floorData.polyline[0].x,
                                                                y: floorData.polyline[0].y
                                                            });
                                                            cad.export.push(genCADPolylines(floorData, {
                                                                layer: LAYER.FLOOR,
                                                                color: COLOR.FLOOR,
                                                                width: 0
                                                            }));
                                                        }

                                                    });
                                                }

                                            });
                                        }
                                    }
                                }
                                ///////////////////////////////////////////////////////////////

                                //["UNDERLAY", "Grid", "outer", "FLOOR", "BOUNDARY", "inner", "WALL", "POINT", "SLIDINGDOOR", "CASEMENTDOOR", "BATHTUB",
                                // "BAYWINDOW", "CASEMENTWINDOW", "SLIDINGWINDOW", "TOILET", "ROOM", "CARPET", "BASEMENT", "SEAT", "SURFACE", "SURFACE_SEAT",
                                // "DECORATION", "PILLAR", "BACKGROUNDWALL", "BACKGROUNDWALL_LIGHT", "LIGHT", "GROUP", "IES", "FILLLIGHT", "CEILING", "BEAM",
                                // "OPENING", "WINDOW", "DOOR", "INDIMENSION", "INDIMENSION_INNER", "OUTDIMENSION", "ROOMLABEL", "BEZIERPOINT", "VRHOTSPOT",
                                // "ANNOTATION", "CAMERA", "WALKTHROUGH", "Temp", "PRODUCT_MARK", "AUXILLARY_ARROW", "LOCKCAMERA"]
                                //////////////////////////////////////////////////////////////////////////////////

                                //墙上的门窗信息"OPENING", "WINDOW", "DOOR",
                                var wall3dData = undefined;
                                var view3d = api.getViewById("3d");
                                var wall3d = view3d.dl[wall.id].de;
                                var wallSideMesh = undefined;

                                wall3d.traverse(function (child) {
                                    if (child.name == wallboardCategory && (child.type == "Mesh")) {
                                        wallSideMesh = child;
                                    }
                                });
                                if (wallSideMesh)
                                    wall3dData = wallSideMesh._rawData;
                                var holeProfiles = wall3dData.h2d;
                                holeProfiles.forEach(function (holeProfile) {
                                    var openingData = {polyline: []};
                                    for (var i = 0, len = holeProfile.length; i < len; ++i) {
                                        //var pt = holeProfile[i];
                                        openingData.polyline.push({
                                            x: holeProfile[i].x + firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                            y: holeProfile[i].y + firstPoint.y + distance * (wallLabelIndex % 4)
                                        });
                                    }
                                    if (openingData.polyline.length > 0) {
                                        //闭合矩形
                                        openingData.polyline.push({
                                            x: openingData.polyline[0].x,
                                            y: openingData.polyline[0].y
                                        });
                                        cad.export.push(genCADPolylines(openingData, {
                                            layer: LAYER.WALL,
                                            color: COLOR.WALL,
                                            width: 0
                                        }));
                                    }
                                });
                                //////////////////////////////////////////////////////////////////


                                //画墙
                                //第1边 下
                                var wallData1 = {polyline: []};
                                wallData1.polyline.push({
                                    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                });
                                wallData1.polyline.push({
                                    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                });
                                if (wallData1.polyline.length > 0) {
                                    cad.export.push(genCADPolylines(wallData1, {
                                        layer: LAYER.WALL,
                                        color: COLOR.WALL,
                                        width: 0
                                    }));
                                }
                                var dimData1 = [];
                                //左侧
                                dimData1.push({
                                    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) - 0.15
                                });
                                dimData1.push({
                                    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) - 0.35
                                });
                                //右侧
                                dimData1.push({
                                    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) - 0.15
                                });
                                dimData1.push({
                                    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) - 0.35
                                });
                                //中间
                                dimData1.push({
                                    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) - 0.25
                                });
                                dimData1.push({
                                    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) - 0.25
                                });
                                //数字坐标
                                dimData1.push({
                                    x: firstPoint.x + width / 2 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4) - 0.7
                                });
                                cad.export.push(genCADDim(dimData1), {
                                    layer: LAYER.ANNOTATION,
                                    color: COLOR.ANNOTATION,
                                    width: 0
                                });

                                //第2边 左
                                var wallData2 = {polyline: []};
                                wallData2.polyline.push({
                                    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                });
                                wallData2.polyline.push({
                                    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                });
                                if (wallData2.polyline.length > 0) {
                                    cad.export.push(genCADPolylines(wallData2, {
                                        layer: LAYER.WALL,
                                        color: COLOR.WALL,
                                        width: 0
                                    }));
                                }
                                var dimData2 = [];
                                //左侧
                                dimData2.push({
                                    x: firstPoint.x - 0.15 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                });
                                dimData2.push({
                                    x: firstPoint.x - 0.35 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                });
                                //右侧
                                dimData2.push({
                                    x: firstPoint.x - 0.15 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                });
                                dimData2.push({
                                    x: firstPoint.x - 0.35 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                });
                                //中间
                                dimData2.push({
                                    x: firstPoint.x - 0.25 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                });
                                dimData2.push({
                                    x: firstPoint.x - 0.25 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                });
                                //数字坐标
                                dimData2.push({
                                    x: firstPoint.x - 0.5 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height / 2 + distance * (wallLabelIndex % 4)
                                });
                                cad.export.push(genCADDim(dimData2), {
                                    layer: LAYER.ANNOTATION,
                                    color: COLOR.ANNOTATION,
                                    width: 0
                                });

                                //第3边 右
                                var wallData3 = {polyline: []};
                                wallData3.polyline.push({
                                    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                });
                                wallData3.polyline.push({
                                    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                });
                                if (wallData3.polyline.length > 0) {
                                    cad.export.push(genCADPolylines(wallData3, {
                                        layer: LAYER.WALL,
                                        color: COLOR.WALL,
                                        width: 0
                                    }));
                                }

                                //var dimData3 = [];
                                ////左侧
                                //dimData3.push({
                                //    x: firstPoint.x + width + 0.15 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                //});
                                //dimData3.push({
                                //    x: firstPoint.x + width + 0.35 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                //});
                                ////右侧
                                //dimData3.push({
                                //    x: firstPoint.x + width + 0.15 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                //});
                                //dimData3.push({
                                //    x: firstPoint.x + width + 0.35 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                //});
                                ////中间
                                //dimData3.push({
                                //    x: firstPoint.x + width + 0.25 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + distance * (wallLabelIndex % 4)
                                //});
                                //dimData3.push({
                                //    x: firstPoint.x + width + 0.25 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                //});
                                ////数字坐标
                                //dimData3.push({
                                //    x: firstPoint.x + width + 0.7 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height / 2 + distance * (wallLabelIndex % 4)
                                //});
                                //cad.export.push(genCADDim(dimData3), {
                                //    layer: LAYER.ANNOTATION,
                                //    color: COLOR.ANNOTATION,
                                //    width: 0
                                //});

                                //第4边  上
                                var wallData4 = {polyline: []};
                                wallData4.polyline.push({
                                    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                });
                                wallData4.polyline.push({
                                    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                    y: firstPoint.y + height + distance * (wallLabelIndex % 4)
                                });
                                if (wallData4.polyline.length > 0) {
                                    cad.export.push(genCADPolylines(wallData4, {
                                        layer: LAYER.WALL,
                                        color: COLOR.WALL,
                                        width: 0
                                    }));
                                }

                                //var dimData4 = [];
                                ////左侧
                                //dimData4.push({
                                //    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4) + 0.15
                                //});
                                //dimData4.push({
                                //    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4) + 0.35
                                //});
                                ////右侧
                                //dimData4.push({
                                //    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4) + 0.15
                                //});
                                //dimData4.push({
                                //    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4) + 0.35
                                //});
                                ////中间
                                //dimData4.push({
                                //    x: firstPoint.x + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4) + 0.25
                                //});
                                //dimData4.push({
                                //    x: firstPoint.x + width + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4) + 0.25
                                //});
                                ////数字坐标
                                //dimData4.push({
                                //    x: firstPoint.x + width / 2 + maxWallLength * (Math.floor(wallLabelIndex / 4)),
                                //    y: firstPoint.y + height + distance * (wallLabelIndex % 4) + 0.4
                                //});
                                //cad.export.push(genCADDim(dimData4), {
                                //    layer: LAYER.ANNOTATION,
                                //    color: COLOR.ANNOTATION,
                                //    width: 0
                                //});


                                wallLabelIndex++;
                            }
                            // }
                            //}
                        }
                    }
                    //=========================================================================================
                    if (callback) {
                        var frame = {
                            "Project": "Project2017",
                            "Title": "Title01",
                            "Client": "Client01",
                            "Manager": "Manager001",
                            "Designer": "Designer002",
                            //"Drawer": "Drawer01",
                            "ClientTel": "075766880000",
                            "OfficeTel": "075766880000",
                            "DrawingNo": "00001",
                            //"JobNo": "00002",
                            "Scale": "1",
                            //"Size": "A3",
                            "Address": "创意产业园",
                            "Date": "2017.11.15"
                        }
                        api.getTmallOrderinfo().then(function (data) {
                            var frame = data;

                            //输出多个方案
                            var ret = {};
                            ret.schemes = [];
                            //方案
                            var scheme1 = {};
                            scheme1.name = roomName + "立面图";
                            scheme1.local = {x: 0, y: 0};
                            scheme1.export = cad.export;
                            scheme1.idsList = idsList; //添加 ids列表
                            //test
                            scheme1.frame = frame;
                            ret.schemes.push(scheme1);
                            callback(ret);
                        });
                    }

                }//if (roomInfo.floor.id == roomModel.id)
            });//bomData.rooms.forEach(function (roomInfo)
        });
        ///////////////////////////////////////////////////////////////////////////////////


    }//root.utilExportJSONData3 = function (room, callback) {

    //方法类
    ////////////////////////////////////////////////////////////////////////////////////////////////
    var geom = [];  //内墙一圈的坐标点
    var wallInnerPointArr = new Array();  //墙对应的坐标集合
    root.getWallInsideLoopFromProfile = function (floor) {

        if (!floor)
            return [];

        wallInnerPointArr = new Array();
        geom = [];

        var floorLoop = utilFloorGetLoopFromProfile(floor);
        //if(floorLoop)
        //    floorLoop = utilAdaptorClipperOffset(floorLoop, -0.010); //10毫米内部,解决其他墙体嵌入问题

        //检查所有转角的wall是否在房间内部，如果属于房间内部，加入队列中
        var profile = floor.profile;//==wall的信息
        var allProfile = {};
        profile.forEach(function (wall) {
            allProfile[wall.id] = wall;
        });

        //var geom = [];
        if (profile.length >= 3) {
            var fp = application.doc.floorplan;
            //确定中心点位于墙的左侧还是右侧，展开获得内墙线

            var wallStart = profile[0];
            var wall = wallStart;
            var wallCenter = {x: (wall.begin.x + wall.end.x) * 0.5, y: (wall.begin.y + wall.end.y) * 0.5};
            var wallDir = new Vec2(wall.end.x - wall.begin.x, wall.end.y - wall.begin.y);
            var wallDirOffset = wallDir.normalize().scale(0.01);
            var v12 = Vec2.rotateAroundPoint(wallDirOffset.clone().add(wallCenter), wallCenter, -Math.PI / 2);

            var wallLoop = utilModelWallGetTessellates(wall, !1);
            var concatBezierLoop = function (loop, index, backward) {
                var len = loop[index].length;
                if (backward) {
                    //逆向
                    for (var i = 0; i < len; ++i) {
                        geom.push(loop[index][len - i - 1]);
                        wallInnerPointArr.push([wall, loop[index][len - i - 1], "left", "bezier"]);
                    }
                    return "left";
                } else {
                    for (var i = 0; i < len; ++i) {
                        geom.push(loop[index][i]);
                        wallInnerPointArr.push([wall, loop[index][i], "right", "bezier"]);
                    }
                    return "right";
                }
            }

            if (utilMathIsPointInPoly(floorLoop, v12)) {
                //右转
                if (wall.bezier) {
                    geom.push(wallLoop[1]);
                    wallInnerPointArr.push([wall, wallLoop[1], "right", "bezier"]);
                    concatBezierLoop(wallLoop, 7, false);
                    geom.push(wallLoop[2]);
                    wallInnerPointArr.push([wall, wallLoop[2], "right", "bezier"]);
                } else {
                    geom.push(wallLoop[1], wallLoop[2]);
                    wallInnerPointArr.push([wall, wallLoop[1], "right"]);
                    wallInnerPointArr.push([wall, wallLoop[2], "right"]);
                }
                var turnType = 0;//0 endRight 1:beginRight
                var loopNum = 0;
                while (1) {
                    loopNum++;
                    if (loopNum > 100) {
                        return [];
                    }
                    if (turnType == 0) {
                        var turnRight = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !0);
                        if (turnRight) {
                            wall = turnRight.road;
                            if (wall == wallStart) {
                                //结束
                                break;
                            }
                            wallLoop = utilModelWallGetTessellates(wall, !1);
                            if (turnRight.sameRoadDir) {
                                turnType = 0;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 7, false);
                                    wallInnerPointArr.push([wall, wallLoop[2], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[2], "right"]);
                                }
                                geom.push(wallLoop[2]);
                            } else {
                                turnType = 1;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 8, false);
                                    wallInnerPointArr.push([wall, wallLoop[5], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[5], "left"]);
                                }
                                geom.push(wallLoop[5]);

                            }
                        } else {
                            //断头(end)
                            turnType = 1;
                            geom.push(wallLoop[4]);
                            wallInnerPointArr.push([wall, wallLoop[4], "side1"]);
                            if (wall.bezier) {
                                var side = concatBezierLoop(wallLoop, 8, false);
                                wallInnerPointArr.push([wall, wallLoop[5], side, "bezier"]);
                            } else {
                                wallInnerPointArr.push([wall, wallLoop[5], "left"]);
                            }
                            geom.push(wallLoop[5]);

                        }
                    } else {
                        var turnRight = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !0);
                        if (turnRight) {
                            wall = turnRight.road;
                            if (wall == wallStart) {
                                break;
                            }
                            wallLoop = utilModelWallGetTessellates(wall, !1);
                            if (turnRight.sameRoadDir) {
                                turnType = 0;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 7, false);
                                    wallInnerPointArr.push([wall, wallLoop[2], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[2], "right"]);
                                }
                                geom.push(wallLoop[2]);

                            } else {
                                turnType = 1;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 8, false);
                                    wallInnerPointArr.push([wall, wallLoop[5], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[5], "left"]);
                                }
                                geom.push(wallLoop[5]);

                            }
                        } else {
                            //断头(begin)
                            turnType = 0;
                            geom.push(wallLoop[1]);
                            wallInnerPointArr.push([wall, wallLoop[1], "side0"]);
                            if (wall.bezier) {
                                var side = concatBezierLoop(wallLoop, 7, false);
                                wallInnerPointArr.push([wall, wallLoop[2], side, "bezier"]);
                            } else {
                                wallInnerPointArr.push([wall, wallLoop[2], "right"]);
                            }
                            geom.push(wallLoop[2]);

                        }
                    }
                }
            } else {
                //左转
                if (wall.bezier) {
                    geom.push(wallLoop[5]);
                    wallInnerPointArr.push([wall, wallLoop[5], "left", "bezier"]);
                    concatBezierLoop(wallLoop, 8, true);
                    geom.push(wallLoop[4]);
                    wallInnerPointArr.push([wall, wallLoop[4], "left", "bezier"]);
                } else {
                    geom.push(wallLoop[5], wallLoop[4]);
                    wallInnerPointArr.push([wall, wallLoop[5], "left"]);
                    wallInnerPointArr.push([wall, wallLoop[4], "left"]);
                }
                var turnType = 0;//0 endLeft 1:beginLeft
                var loopNum = 0;
                while (1) {
                    loopNum++;
                    if (loopNum > 100) {
                        return [];
                    }
                    if (turnType == 0) {
                        var turnLeft = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !1);
                        if (turnLeft) {
                            wall = turnLeft.road;
                            if (wall == wallStart) {
                                //结束
                                break;
                            }
                            wallLoop = utilModelWallGetTessellates(wall, !1);
                            if (turnLeft.sameRoadDir) {
                                turnType = 0;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 8, true);
                                    wallInnerPointArr.push([wall, wallLoop[4], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[4], "left"]);  //right
                                }
                                geom.push(wallLoop[4]);

                            } else {
                                turnType = 1;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 7, true);
                                    wallInnerPointArr.push([wall, wallLoop[1], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[1], "right"]);
                                }
                                geom.push(wallLoop[1]);

                            }
                        } else {
                            //断头(end)
                            turnType = 1;
                            geom.push(wallLoop[2]);
                            wallInnerPointArr.push([wall, wallLoop[2], "side1"]);
                            if (wall.bezier) {
                                var side = concatBezierLoop(wallLoop, 7, true);
                                wallInnerPointArr.push([wall, wallLoop[1], side, "bezier"]);
                            } else {
                                wallInnerPointArr.push([wall, wallLoop[1], "left"]);
                            }
                            geom.push(wallLoop[1]);

                        }
                    } else {
                        var turnLeft = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !1);
                        if (turnLeft) {
                            wall = turnLeft.road;
                            if (wall == wallStart) {
                                break;
                            }
                            wallLoop = utilModelWallGetTessellates(wall, !1);
                            if (turnLeft.sameRoadDir) {
                                turnType = 0;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 8, true);
                                    wallInnerPointArr.push([wall, wallLoop[4], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[4], "left"]);
                                }
                                geom.push(wallLoop[4]);

                            } else {
                                turnType = 1;
                                if (wall.bezier) {
                                    var side = concatBezierLoop(wallLoop, 7, true);
                                    wallInnerPointArr.push([wall, wallLoop[1], side, "bezier"]);
                                } else {
                                    wallInnerPointArr.push([wall, wallLoop[1], "right"]);
                                }
                                geom.push(wallLoop[1]);

                            }
                        } else {
                            //断头(begin)
                            turnType = 0;
                            geom.push(wallLoop[4]);
                            wallInnerPointArr.push([wall, wallLoop[4], "Y"]);
                            if (wall.bezier) {
                                var side = concatBezierLoop(wallLoop, 7, true);
                                wallInnerPointArr.push([wall, wallLoop[1], side, "bezier"]);
                            } else {
                                wallInnerPointArr.push([wall, wallLoop[1], "Z"]);
                            }
                            geom.push(wallLoop[1]);

                        }
                    }
                }
            }
        }
        //去掉第1个数据，是重复的。
        //console.log(geom);
        if (!wallInnerPointArr[0][3]) {  //开始第一道墙为曲面墙里不需要去掉第1个数据
            wallInnerPointArr.splice(0, 1);
        }
        //对曲面墙数据的处理，wall.id、side、都相同时整理中一个数组中保存数据。
        //console.log(wallInnerPointArr);
        var newWallInnerPointArr = new Array();
        for (var w = 0; w < wallInnerPointArr.length; w++) {
            if (wallInnerPointArr[w][3] && wallInnerPointArr[w][3] == "bezier") { //当些数据为曲面墙数据时
                //查找新的数组里有没有这样的数据，如果没有，就添加到新数组的新数据里
                if (newWallInnerPointArr.length > 0) {
                    var nIndex = 0;
                    var wIndex = 0;
                    var hasValue = false;
                    for (var n = 0; n < newWallInnerPointArr.length; n++) {
                        //先检测新数组中是否存在wall.id和side都相同的墙数据，如果没有就创建一个，如果有就直接在原墙数据添加一个坐标记录。
                        if (newWallInnerPointArr[n][0].id == wallInnerPointArr[w][0].id && newWallInnerPointArr[n][2] == wallInnerPointArr[w][2]) {

                            hasValue = true;
                            nIndex = n;
                            wIndex = w;

                        } else {
                            hasValue = false;
                        }
                    }

                    if (hasValue) {
                        //通过遍历，设置坐标为最后一位
                        newWallInnerPointArr[nIndex][1] = wallInnerPointArr[wIndex][1];
                        newWallInnerPointArr[nIndex][4].push(wallInnerPointArr[wIndex][1]);
                    } else {//新的一条曲面墙数据
                        // 直接添加为新数据
                        newWallInnerPointArr.push([wallInnerPointArr[w][0], wallInnerPointArr[w][1], wallInnerPointArr[w][2], wallInnerPointArr[w][3], [wallInnerPointArr[w][1]]]);
                    }

                } else {
                    //直接添加到新的数组里
                    newWallInnerPointArr.push([wallInnerPointArr[w][0], wallInnerPointArr[w][1], wallInnerPointArr[w][2], wallInnerPointArr[w][3], [wallInnerPointArr[w][1]]]);

                }
            } else {
                //直接添加到新的数组里
                newWallInnerPointArr.push(wallInnerPointArr[w]);
            }

        }

        //console.log(newWallInnerPointArr);

        wallInnerPointArr = newWallInnerPointArr;

        return wallInnerPointArr;//geom;
    }

    //获取对应区域的波打线
    var getBoundarysFromAreaId = function (id) {
        var boundarys = new Array();
        var boundaryLists = api.floorplanFilterEntity(function (e) {
            return e.type == "BOUNDARY";
        });
        if (boundaryLists.length > 0) {
            for (var i = 0; i < boundaryLists.length; i++) {
                if (boundaryLists[i].host.id == id) {
                    boundarys.push(boundaryLists[i]);
                }
            }
        }
        return boundarys;
    }

    //获取曲面墙的长度
    function getBezierWallLength(wall, category) {
        var width = 0;
        var geom = utilModelWallGetTessellates(wall, 0);
        switch (category) {
            case "right":
                if (wall.bezier) {
                    width = utilMathLineLength(geom[1], geom[7][0]);
                    for (var i = 1; i < geom[7].length; ++i) {
                        width += utilMathLineLength(geom[7][i - 1], geom[7][i]);
                    }
                    width += utilMathLineLength(geom[7][geom[7].length - 1], geom[2]);
                } else {
                    width = utilMathLineLength(geom[1], geom[2]);
                }
                break;
            case "left":
                if (wall.bezier) {
                    width = utilMathLineLength(geom[4], geom[8][0]);
                    for (var i = 1; i < geom[8].length; ++i) {
                        width += utilMathLineLength(geom[8][i - 1], geom[8][i]);
                    }
                    width += utilMathLineLength(geom[8][geom[8].length - 1], geom[5]);
                } else {
                    width = utilMathLineLength(geom[4], geom[5]);
                }
                break;
            case "side0":
                width = utilMathLineLength(geom[5], geom[1]);
                break;
            case "side1":
                width = utilMathLineLength(geom[2], geom[4]);
                break;
        }

        return width;
    }

    //////////////////////////////////////////////////////////////////

    function utilFloorGetLoopFromProfile(floor, opt) {
        if (!floor)
            return null;
        return utilGetLoopFromProfile(floor.profile, opt);
    }

    function utilGetLoopFromProfile(profile, opt) {
        var geom = [];
        var tol = .05;
        var removeDuplicated = opt && opt.removeDuplicated === !0;
        for (var i = 0, len = profile.length; len >= i; ++i) {
            var point;
            var wall1 = profile[i % len];
            var wall2 = profile[(i + 1) % len];
            if (!(wall1 && wall2 && wall1.begin && wall1.end && wall2.begin && wall2.end))
                return;
            if (utilMathIsLineParallel(wall1.begin, wall1.end, wall2.begin, wall2.end, tol)) {
                if (utilMathIsSamePoint(wall1.begin, wall2.begin, tol)) {
                    point = wall1.begin;
                } else {
                    if (utilMathIsSamePoint(wall1.end, wall2.begin, tol)) {
                        point = wall1.end;
                    } else {
                        if (utilMathIsSamePoint(wall1.begin, wall2.end, tol)) {
                            point = wall1.begin;
                        } else {
                            utilMathIsSamePoint(wall1.end, wall2.end, tol) && (point = wall1.end);
                        }
                    }
                }
            } else {
                point = utilMathLineLineIntersection(wall1.begin, wall1.end, wall2.begin, wall2.end);
            }

            if (!point || isNaN(point.x) || isNaN(point.y)) {
                return void __assert(!1, "build floor loop failed");
            }
            geom.push(point);
        }
        if (removeDuplicated === !0) for (var i = geom.length - 2; i >= 0; --i) {
            var thisPt = geom[i];
            var nextPt = geom[i + 1];
            utilMathIsSamePoint(thisPt, nextPt, .05) && geom.splice(i + 1, 1);
        }
        return geom.length < 3 ? void __assert(!1, "loop should have at least 3 points") : geom;
    }

    //获取上层的区域
    var getAreasFromLevel2 = function (areas, level) {

        var newAreas = new Array();
        areas.forEach(function (area) {

            if (area.level > level) {
                newAreas.push(area);
            }
        });

        return newAreas;
    }

//获取geom数组里上一个数组的内容
    function getNextPointFromGeom(arr, p) {

        var vec2 = new Vec2(0, 0);
        if (arr.length != 0) {
            for (var i = 0; i < arr.length; i++) {

                if (p.x == arr[i].x && p.y == arr[i].y) {
                    vec2 = (i == 0) ? arr[arr.length - 2] : arr[i - 1];
                    return vec2;
                }
            }
        } else {
            return vec2
        }

        return vec2;
    }

    //获取wallInnerPointArr上一个坐标数据
    function getPreviousPoint(i) {
        if (wallInnerPointArr[i]) {
            return i == 0 ? wallInnerPointArr[wallInnerPointArr.length - 1][1] : wallInnerPointArr[i - 1][1];
        } else {
            return new Vec2(0, 0);
        }
    }

//获取房间最右下角的坐标点
    function GetLightBottomPoint(wallPoints) {

        if (wallPoints.length > 0) {
            var xArr = [];
            var yArr = [];
            for (var i = 0; i < wallPoints.length; i++) {
                xArr.push(wallPoints[i].x);
                yArr.push(wallPoints[i].y);
            }
            xArr = quickSort(xArr);
            yArr = quickSort(yArr);

            return new Vec2(xArr[xArr.length - 1], yArr[0]);
        } else {
            return null;
        }
    }

//获取房间最长的墙的长度
    function getMaxWallLength(innerPos) {

        var wallPoints = [];
        wallPoints.push(getLength(innerPos[0], innerPos[innerPos.length - 1]));
        for (var i = 0; i < innerPos.length - 2; i++) {
            wallPoints.push(getLength(innerPos[i], innerPos[i + 1]));
        }
        wallPoints = quickSort(wallPoints);

        return wallPoints[wallPoints.length - 1] + 2;
    }

//获取两点的长度
    function getLength(p1, p2) {
        var line = new Line(p1.x, p1.y, p2.x, p2.y);
        return line.length();
    }

// 快速排序
    function quickSort(array) {
        //var array = [8,4,6,2,7,9,3,5,74,5];
        //var array = [0,1,2,44,4,324,5,65,6,6,34,4,5,6,2,43,5,6,62,43,5,1,4,51,56,76,7,7,2,1,45,4,6,7];
        if (array.length == 0) {
            return array;
        } else {
            return array.sort(sortNumber);
        }
        var i = 0;
        var j = array.length - 1;
        var Sort = function (i, j) {
            // 结束条件
            if (i == j)
                return;
            var key = array[i];
            var stepi = i; // 记录开始位置
            var stepj = j; // 记录结束位置
            while (j > i) {
                // j <<-------------- 向前查找
                if (array[j] >= key) {
                    j--;
                } else {
                    array[i] = array[j]
                    //i++ ------------>>向后查找
                    while (j > ++i) {
                        if (array[i] > key) {
                            array[j] = array[i];
                            break;
                        }
                    }
                }
            }
            // 如果第一个取出的 key 是最小的数
            if (stepi == i) {
                Sort(++i, stepj);
                return;
            }
            // 最后一个空位留给 key
            array[i] = key;
            // 递归
            Sort(stepi, i);
            Sort(j, stepj);
        }
        Sort(i, j);
        return array;
    }
})
(this);