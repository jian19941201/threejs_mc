﻿function ActionManager(app) {
    this.app = app, this.current = void 0, this.undos = [], this.redos = [], this.actionBeginEvent = new Signal(),
        this.actionEndEvent = new Signal(), this.actionUndoRedoChangedEvent = new Signal();
}

//添加临时组合接口 提供给ui层保存编辑套件使用 add by hcw
function addTempGroup(alreadyPicked, models) {
    if (alreadyPicked.forEach(function (pickResult) {
            pickResult.id != GROUP_TEMP.id && utilGroupAddItem(GROUP_TEMP, pickResult);
        }), 0 == GROUP_TEMP.children.length) models.id != GROUP_TEMP.id && utilGroupAddItem(GROUP_TEMP, models);
    else {
        var checkedModel = models;
        -1 != GROUP_TEMP.children.indexOf(checkedModel) ? utilGroupRemoveItem(GROUP_TEMP, checkedModel) : utilGroupAddItem(GROUP_TEMP, checkedModel);
    }
}
//移除所有临时组合接口  add by hcw
function removeTempGroup() {
    var view = api.getViewById('2d');
    var fp = view.app.doc.floorplan;
    var pickMgr = view.app.pickMgr;
    utilGroupReset(fp, GROUP_TEMP);
    utilPickMgrUnpickAll(pickMgr);
}
function checkEditGroupModel() {
    return EDIT_GROUP_MODEL;
}

/*TYPE 是一个对象集合，包含了*/
function utilActionBegin(mgr, actionType) {
	try{
    //console.log(mgr);
    //console.log(actionType);
    /*TYPE在classInherit执行时构造,在model.comp.js add by oxl 2017-04-11*/
    var action = TYPE[actionType];
    __assert(void 0 != action, "undefined action: " + actionType),
    void 0 != mgr.current && (__assert(!1, "Another action is running: " + mgr.current.type),
        utilActionEnd(mgr));
    var actionObj = new action(mgr);
    if (0 != actionObj.isEnable()) {
        actionObj.canUndoRedo() && (mgr.undos.push(actionObj),
            mgr.actionUndoRedoChangedEvent.dispatch(mgr)),
            mgr.current = actionObj;
        var args = [];
        args.push.apply(args, arguments), args.shift(), args.shift();
        /*删除arguments类数组前面的2个参数
         * 给actionObj.begin 方法绑定 修改后的参数 args，并马上执行等价于：AddUnderImage.begin(meta,url)
         * add by oxl*/
        var rv = actionObj.begin.apply(actionObj, args);
        /*mgr.actionBeginEvent的引用在 misc.footer.js定义
         * add by oxl 2017-03-01
         * */
        return mgr.actionBeginEvent.dispatch(actionObj, actionObj.type, args), rv;
    }
  }catch(e){
  	log("**ActionBegin**" + e);
  }
}

function utilActionRun(mgr) {
	try{
    if (void 0 != mgr.current) {
        var args = [];
        args.push.apply(args, arguments);
        args.shift();
        return mgr.current.run.apply(mgr.current, args);
    }
  }catch(e){
  	log("**ActionRun**"+e);
  }
}

function utilActionEnd(mgr, actionType) {
	try{
    var active = mgr.current;
    if (!active) return !0;
    void 0 != actionType && __assert(actionType == active.type);
    var args = [];
    args.push.apply(args, arguments), args.shift();
    var rv = active.end.apply(active, args);
    active.canUndoRedo() && (mgr.redos = [], mgr.actionUndoRedoChangedEvent.dispatch(mgr));
    mgr.actionEndEvent.dispatch(active, active.type);
    mgr.current = void 0;
    return rv;
  }catch(e){
  	log("**ActionEnd**"+e);
  }
}

function utilActionGetCurrentAction(mgr) {
    return mgr.current;
}

function utilActionUndo(mgr) {
    var action = mgr.undos.pop();
    if(action){
    	try{
    	  action.undo();
    	}catch(e){
    		log("**ActionUndo**"+e);
    	}
    	mgr.redos.push(action);
    	mgr.actionUndoRedoChangedEvent.dispatch(mgr);
    }
}

//start add by gaoning 2017.2.9
function utilActionCopy(mgr) {

    //console.log("copy**");
    //获取当前选中的物体
    var pickObjs = api.pickGetPicked(function (e) {
        return e;
    });//[0].model;
    if (pickObjs.length == 1) {
        if (pickObjs[0].model.type == "PRODUCT" || pickObjs[0].model.type == "PRODUCTREPLACEMENT") {
            api.actionBegin("CopyProduct", pickObjs[0].model);
        } else if (pickObjs[0].model.type == "RECTAREA") {
            api.actionBegin("CopyArea", pickObjs[0].model);
        }
    } else if (pickObjs.length > 1) {
        for (var i = 0; i < pickObjs.length; i++) {
            //console.log(pickObjs[i].model.type);//GROUP   WALL RECTAREA
            if (pickObjs[i].model.type == "GROUP") {
                api.actionBegin("CopyGroup", pickObjs[i].model);
            }
        }
    }

    //解决区域复制后无法移动的Bug，因为没有结束复制Action--add by gaoning 2017.6.19
    api.actionEnd("CopyGroup");

}
function utilActionPause(mgr) {
    //console.log("pause**");
}
//end add by gaoning 2017.2.9

function utilActionRedo(mgr) {
    var action = mgr.redos.pop();
    if(action){
    	try{
    	  action.redo();
    	}catch(e){
    		log("**ActionRedo**"+e);
    	}
    	mgr.undos.push(action);
    	mgr.actionUndoRedoChangedEvent.dispatch(mgr);
    }
}

function ActionBase(mgr) {
    /*提供mgr方法给儿子继承使用*/
    this.mgr = mgr, this.fp = this.mgr.app.doc.floorplan;
}

function ActionAddAutoLight(mgr) {
    classBase(this, mgr), this.product = void 0;
}
/*AddUnderImage.prototype.type = "AddUnderImage", classInherit(AddUnderImage, ActionBase), */
function AddUnderImage(mgr) {
    /*继承了ActionBase 后 调用父ActionBase的 mgr 方法*/
    classBase(this, mgr), this.mat = void 0;
}

//创建框选类--gaoning
function ActionProductSelection(mgr, opt) {
    classBase(this, mgr);
    this.firstPoint = void 0;
    this.area = void 0;

}



function ActionAddFreeArea(mgr, opt) {
    classBase(this, mgr), this.firstPoint = void 0, this.model = void 0, this.area = void 0,
        this.mouseMoveEvt = new Signal();
}

function ActionAddRectArea(mgr, opt) {
    classBase(this, mgr), this.firstPoint = void 0, this.area = void 0;
}

function ActionAddRoundArea(mgr, opt) {
    classBase(this, mgr), this.center = void 0, this.area = void 0;
}

function ActionAddCube(mgr) {
    classBase(this, mgr), this.product = void 0;
}

function ActionAddAnnotation(mgr) {
    classBase(this, mgr), this.annotation = void 0, this.delta = {};
}

function ActionAddSimpleAnnotation(mgr) {
    classBase(this, mgr), this.annotation = void 0, this.delta = {};
}

function ActionAddCamera(mgr) {
    classBase(this, mgr), this.camera = void 0, this.lastCamera = void 0;
}

function ActionMakeGroup(mgr) {
    classBase(this, mgr), this.group = void 0;
}
/*添加拖拽可移动组合  add by hcw*/
function ActionAddGroup(mgr) {
    classBase(this, mgr), this.group = void 0;
}
function ActionExplodeGroup(mgr) {
    classBase(this, mgr), this.group = void 0, this.childrenIds = void 0;
}

function ActionDeleteProduct(mgr) {
    classBase(this, mgr), this.product = void 0;
}

function ActionDeleteArea(mgr) {
    classBase(this, mgr), this.area = void 0;
}

function ActionDeleteGroup(mgr) {
    classBase(this, mgr), this.group = void 0;
}

function ActionDeleteAutoLight(mgr) {
    classBase(this, mgr), this.product = void 0;
}



function ActionMoveMaterial(mgr) {
    classBase(this, mgr), this.material = void 0, this.tx = 0, this.ty = 0;
}

function ActionMoveArea(mgr) {
    classBase(this, mgr), this.copiedArea = void 0, this.area = void 0, this.orig = void 0;
}

function ActionMoveGroup(mgr) {
    classBase(this, mgr), this.group = void 0, this.childPos = {};
}

function ActionRotateProduct(mgr) {
    classBase(this, mgr), this.product = void 0, this.srcRot = void 0;
}

function ActionChangeDoorSwing(mgr) {
    classBase(this, mgr), this.product = void 0;
}

function ActionRotateMaterial(mgr) {
    classBase(this, mgr), this.material = void 0, this.srcRot = void 0;
}

function ActionScaleProduct(mgr) {
    classBase(this, mgr), this.product = void 0;
}

function ActionScaleMaterial(mgr) {
    classBase(this, mgr), this.material = void 0;
}

function ActionRotateGroup(mgr) {
    classBase(this, mgr), this.group = void 0;
}

function ActionCopyProduct(mgr) {
    classBase(this, mgr), this.product = void 0;
}

function ActionCopyArea(mgr) {
    classBase(this, mgr), this.area = void 0;
}

function ActionCopyGroup(mgr) {
    classBase(this, mgr), this.group = void 0, this.copiedGroup = void 0;
}
/*TYPE对象集合看到以上这部分*/
function utilActionCopyGroup(fp, group, offset) {
    var copiedGroup = new Group();
    return copiedGroup.name = "Group_" + Math.round(1e3 * Math.random()), utilEntityAddLink(fp, copiedGroup),
        group.children.forEach(function (child) {
            if (child instanceof Product) {
                utilActionCopyProduct(fp, child, copiedGroup, offset);
            } else if (child instanceof Area) {
                utilActionCopyArea(fp, child, copiedGroup, offset);
            }
        }), copiedGroup;
}

function utilActionCopyProduct(fp, source, group, offset) {
    var productMeta = application.catalogMgr.productsMeta[source.pid], product = new TYPE[source.type](productMeta);
    return product.copy(source), utilEntityAddLink(fp, product), offset && (product.x += offset.x,
        product.y += offset.y), group && utilGroupAddItem(group, product), product;
}

function utilActionCopyArea(fp, source, group, offset) {
    var area = new TYPE[source.type]();
    return area.copy(source), utilEntityAddLink(fp, area), offset && (area.center.x += offset.x,
        area.center.y += offset.y), group && utilGroupAddItem(group, area), area;
}

function ActionSplitWall(mgr) {
    classBase(this, mgr), this.current = void 0, this.added = void 0;
}

function ActionAnalyzeNormalized(mgr) {
    classBase(this, mgr), this.analyzed = void 0;
}

function ActionRulerMeasure(mgr) {
    classBase(this, mgr), this.points = void 0;
}

function ActionMaterialDropper(mgr) {
    classBase(this, mgr), this.pickMat = void 0, this.droppedInfos = [];
}

function ActionWallDropper(mgr) {
    classBase(this, mgr), this.pickMat = void 0, this.droppedInfos = [];
}

function ActionApplyModelroom(mgr) {
    classBase(this, mgr);
    this.thisRoom = void 0;
    this.ghostRoom = void 0;
    this.ghostFp = void 0;
    this.applyConfig = void 0;
    this.ghostMove = {
        x: 0,
        y: 0
    };
    this.ghostRot = 0;
    this.ghostUpdate = new Signal();
}
function ActionSetFloorDirection(mgr){
    classBase(this, mgr), this.model = void 0
}
function ActionSetHeight3d(mgr) {
    classBase(this, mgr), this.model = void 0, this.height3dBefore = void 0, this.walls = [];
}

function ActionSetWallLength(mgr) {
    classBase(this, mgr), this.wall = void 0, this.wallLengthBefore = void 0, this.movedInfo = {};
}

function ActionSetMaterial(mgr) {
    classBase(this, mgr), this.old_material = void 0, this.model = void 0;
}

function ActionSetAreaLevel(mgr) {
    classBase(this, mgr), this.oldLevel = NaN, this.area = void 0;
}

function ActionSetGeneralProperty(mgr) {
    classBase(this, mgr), this.oldValue = void 0, this.propName = void 0, this.batchOldValue = void 0,
        this.model = void 0, this.modelsSetBatch = void 0;
}

function ActionSetgeneralFlag(mgr) {
    classBase(this, mgr), this.oldValue = void 0, this.flag = void 0, this.model = void 0,
        this.cmd = void 0;
}

var globalModelIndex = 1;//增加模型计数
function getAllObjArraryLength(indexNum) {
    var allObjArrary = api.floorplanFilterEntity(function (e) {
        return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR" || e.type == 'BEAM' || e.type == 'BASEMENT');
    });
    //console.warn(allObjArrary)
    if (allObjArrary[0] && allObjArrary[0].index == undefined) {
        allObjArrary[0].index = 1;
    } else {
        var index2 = indexNum || allObjArrary[allObjArrary.length - 1] && allObjArrary[allObjArrary.length - 1].index;
        console.warn(index2)
    }
    return index2;
};

var Flag = 1;//为让模型拖进画板只执行一次的变量
var usagecount = 0;//模型使用次数变量

utilExtend(ActionManager, {
    canUndo: function () {
        return this.undos.length > 0;
    },
    canRedo: function () {
        return this.redos.length > 0;
    }
}), utilExtend(ActionBase.prototype, {
    needViewportMouseMove: function () {
        return !1;
    },
    viewportMouseHitTypes: function () {
    },
    isEnable: function () {
        return !0;
    },
    canUndoRedo: function () {
        return !1;
    },
    begin: function () {
        return !0;
    },
    end: function () {
        return !0;
    },
    run: function () {
        return !0;
    },
    undo: function () {
        __assert(this.canUndoRedo());
    },
    redo: function () {
        __assert(this.canUndoRedo());
    }
}), ActionAddAutoLight.prototype.type = "AddAutoLight", classInherit(ActionAddAutoLight, ActionBase),
    utilExtend(ActionAddAutoLight.prototype, {
        canUndoRedo: function () {
            return !1;
        },
        begin: function (productId, productMeta, size, userDefined) {
            //__log("run this action: " + this.type + ", param=[]");
            var productMeta = this.mgr.app.catalogMgr.productsMeta[productId] || productMeta, Class = (productMeta && productMeta.category,
                Product), product = this.product = new Class(productMeta);
            return product.userDefined = product.userDefined || {}, Object.assign(product.userDefined, userDefined),
            void 0 != size.x && (product.x = size.x), void 0 != size.y && (product.y = size.y),
            void 0 != size.z && (product.z = size.z), void 0 != size.sx && (product.sx = size.sx),
            void 0 != size.sy && (product.sy = size.sy), void 0 != size.sz && (product.sz = size.sz),
                utilEntityAddLink(this.fp, product), this.product;
        },
        end: function () {
        }
    }), AddUnderImage.prototype.type = "AddUnderImage", classInherit(AddUnderImage, ActionBase),
    utilExtend(AddUnderImage.prototype, {
        begin: function (meta, url) {
            //__log("run this action: " + this.type + ",url=" + url);
            this.mat = new Underlay(meta);
            //this.mat._url = url;
            this.fp.underImage = this.mat;
            utilActionEnd(this.mgr, this.type);
        }
    }), ActionAddFreeArea.prototype.type = "AddFreeArea", classInherit(ActionAddFreeArea, ActionBase),
    utilExtend(ActionAddFreeArea.prototype, {
        _updateAreaAndCurve: function () {
            utilModelChangeFlag(this.area, AREAFLAG_CHANGED_FOR_REDRAWN);
        },
        isEnable: function () {
            return !0;
        },
        end: function (opt) {
            this.area.showMouseLabel.forEach(function(label){
                label.remove();
            });
            this.area.showMouseLabel = [];
            //只有一个点或者两个点 就结束action 不能形成自由区域的情况  删除点线
            if(this.firstPoint && (this.model.end.x = this.firstPoint.x, this.model.end.y = this.firstPoint.y,
                    this._updateAreaAndCurve()), this.area && 0 == this.area.isValid()){
                utilEntityRemoveLink(this.fp, this.area), this.area.profile.forEach(function (cure){
                    if(cure){
                        utilEntityRemoveLink(this.fp, cure)
                    }
                });
            }

            RemoveMouseToWallLine();
        },
        begin: function (category, host, opt) {
           
            var cat = category || AREA_OUTER_CATEGORY_ID, host = host || this.fp;

            this.area = new FreeArea({
                category: cat,
                host: host
            }), utilEntityAddLink(this.fp, this.area), this.area.areaMaterial = new Material({
                pid: DEFAULT_AREA_MATERIAL[this.area.category]
            }), this.area.level = utilAppFloorplanGetAreasByHostId(application, void 0, host.id, cat).length;
            var curve = new Curve();
            this.area.showMouseLabel = [];
            this.area.lineLengthTextDic = new uDictionary();
            return utilEntityAddLink(this.fp, curve), this.model = curve, this.area.profile.push(curve),
                this.area;

        },
        run: function (cmd, evt, modelPos) {
            if (__log(cmd), "mousemove" == cmd) {

                //绘制区域时鼠标中键可移动屏幕 --add by gaoning 2018.4.4
                if (evt.buttons) {
                    if (evt.buttons == 4) {
                        var view = api.getViewById("2d");
                        return void view.pan(evt.movementX, evt.movementY);
                    }
                } else {
                    if (1 == evt.button)
                        return void this.pan(evt.movementX, evt.movementY);
                }

                //显示鼠标与内墙的距离--add by gaoning 2018.3.15
                createMouseToWallLine(modelPos);

                if (!this.model.begin) return;
                var end = this.model.end;
                end.x = modelPos.x, end.y = modelPos.y, this._updateAreaAndCurve(), this.mouseMoveEvt.dispatch(cmd, evt);
            } else if ("click" == cmd || "setLength" == cmd) {
                if ("setLength" == cmd) {
                    var length = modelPos;
                    if (this.model.end) {
                        var newEndPt = utilMathGetScaledPoint(this.model.begin, this.model.end, length);
                        this.model.end.x = newEndPt.x, this.model.end.y = newEndPt.y;
                    }
                }
                if (1 == evt.button) return;
                if (void 0 == this.firstPoint) return this.firstPoint = this.model.begin = new Point(),
                    this.firstPoint.x = modelPos.x, this.firstPoint.y = modelPos.y, void (this.model.end = new Point());
                if (utilMathIsSamePoint(this.firstPoint, modelPos, .1)) return void utilActionEnd(this.mgr);
                var curve = this.model = new Curve();
                utilEntityAddLink(this.fp, curve), curve.begin = new Point(), curve.begin.x = modelPos.x,
                    curve.begin.y = modelPos.y, curve.end = new Point(), this.area.profile.push(curve),
                    this._updateAreaAndCurve();
            } else {
                if ("ESC" == cmd || "keydown" == cmd && 27 == evt.keyCode || "mouseup" == cmd && 2 == evt.button) return utilActionEnd(this.mgr),
                    this._updateAreaAndCurve(), !0;
                if ("keydown" == cmd && 115 == evt.keyCode) utilF4KeyDown(evt); else if ("exit" == cmd) utilActionEnd(this.mgr); else if ("expand" == cmd) {
                    var src = evt, margin = modelPos, srcLoop = src.getLoop(), areaLoop = utilAdaptorClipperOffset(srcLoop, margin);
                    areaLoop.push(areaLoop[0]), this.area.profile = [];
                    for (var i = 0; i < areaLoop.length - 1; ++i) {
                        var begin = areaLoop[i], end = areaLoop[i + 1], curve = new Curve();
                        utilEntityAddLink(this.fp, curve), curve.begin = new Point(), curve.begin.x = begin.x,
                            curve.begin.y = begin.y, curve.end = new Point(), curve.end.x = end.x, curve.end.y = end.y,
                            this.area.profile.push(curve);
                    }
                    this._updateAreaAndCurve();
                }
            }
        }
    }), ActionAddRectArea.prototype.type = "AddRectArea", classInherit(ActionAddRectArea, ActionBase),
    utilExtend(ActionAddRectArea.prototype, {
        _updateAreaAndCurve: function () {
            utilModelChangeFlag(this.area, AREAFLAG_CHANGED_FOR_REDRAWN);
        },
        needViewportMouseMove: function () {
            return !0;
        },
        isEnable: function () {
            return !0;
        },
        end: function (opt) {
            this.firstPoint && (delete Root.prototype.database[this.firstPoint.id], this.firstPoint = null);
            this.area.showMouseLabel.forEach(function(label){
                label.remove();
            });
            this.area.showMouseLabel = [];

            this._updateAreaAndCurve();

            RemoveMouseToWallLine();
        },
        begin: function (category, host) {
            var cat = category || AREA_OUTER_CATEGORY_ID;
            var host = host || this.fp;
            var cls = RectArea;
            if(host.type == "WALL"){
            	cls = RectArea3d;
            }else if(host.type == "RECTAREA" ||
            	       host.type == "ROUNDAREA" ||
            	       host.type == "FREEAREA"){
            	cls = RectArea3d;
            }
            
            this.area = new cls({
                category: cat,
                host: host
            });
            utilEntityAddLink(this.fp, this.area);
            this.area.areaMaterial = new Material({
                pid: DEFAULT_AREA_MATERIAL[this.area.category]
            });
            this.area.level = utilAppFloorplanGetAreasByHostId(application, void 0, host.id, cat).length;
            this.area.center = new Point();
            this.area.showMouseLabel = [];
            return this.area;
        },
        run: function (cmd, evt, modelPos) {
            __log(cmd);

            //绘制区域时鼠标中键可移动屏幕 --add by gaoning 2017.12.22
            if (evt.buttons) {
                if (evt.buttons == 4) {
                    var view = api.getViewById("2d");
                    return void view.pan(evt.movementX, evt.movementY);
                }
            } else {
                if (1 == evt.button)
                    return void this.pan(evt.movementX, evt.movementY);
            }

            var _moveSencondPoint = function (pos) {
                this.area.width = Math.abs(pos.x - this.firstPoint.x);
                this.area.height = Math.abs(pos.y - this.firstPoint.y);
                this.area.center.x = (pos.x + this.firstPoint.x) / 2;
                this.area.center.y = (pos.y + this.firstPoint.y) / 2;
            }.bind(this);
            if ("view2d_mousemove" == cmd) {  //鼠标移动

                //显示鼠标与内墙的距离--add by gaoning 2018.3.15
                createMouseToWallLine(modelPos);

                if (!this.firstPoint) {
                    return;
                }
                _moveSencondPoint(modelPos);
                this._updateAreaAndCurve();
            } else if ("view2d_mouseup" == cmd) { //鼠标抬起
                if (1 == evt.button) {
                    return;
                }
                void 0 == this.firstPoint ? (this.firstPoint = new Point(),
                    this.firstPoint.x = this.area.center.x = modelPos.x,
                    this.firstPoint.y = this.area.center.y = modelPos.y) : (_moveSencondPoint(modelPos),
                    utilActionEnd(this.mgr));
            } else if ("expand" == cmd) {
                var src = evt, margin = modelPos;
                this.area.center.x = src.center.x;
                this.area.center.y = src.center.y;
                this.area.width = src.width + 2 * margin;
                this.area.height = src.height + 2 * margin;
                this.area.rot = src.rot;
            }
        }
    }),

    ActionAddRoundArea.prototype.type = "AddRoundArea", classInherit(ActionAddRoundArea, ActionBase),
    utilExtend(ActionAddRoundArea.prototype, {
        _updateAreaAndCurve: function () {
            utilModelChangeFlag(this.area, AREAFLAG_CHANGED_FOR_REDRAWN);
        },
        needViewportMouseMove: function () {
            return !0;
        },
        isEnable: function () {
            return !0;
        },
        end: function (opt) {
            this.center && (delete Root.prototype.database[this.center.id], this.center = null);
            this.area.showMouseLabel.forEach(function(label){
                label.remove();
            });
            this.area.showMouseLabel = [];

            this._updateAreaAndCurve();

            RemoveMouseToWallLine();
        },
        begin: function (category, host, opt) {
            var cat = category || AREA_OUTER_CATEGORY_ID, host = host || this.fp;
            var cls = RoundArea;
            if(host.type == "WALL"){
            	cls = RoundArea3d;
            }else if(host.type == "RECTAREA" ||
            	       host.type == "ROUNDAREA" ||
            	       host.type == "FREEAREA"){
            	cls = RoundArea3d;
            }

            return this.area = new cls({
                category: cat,
                host: host
            }), utilEntityAddLink(this.fp, this.area), this.area.areaMaterial = new Material({
                pid: DEFAULT_AREA_MATERIAL[this.area.category]
            }), this.area.level = utilAppFloorplanGetAreasByHostId(application, void 0, host.id, cat).length,
                this.area.center = new Point(), this.area.showMouseLabel = [],this.area;
        },
        run: function (cmd, evt, modelPos) {
            __log(cmd);

            //绘制区域时鼠标中键可移动屏幕 --add by gaoning 2018.4.4
            if (evt.buttons) {
                if (evt.buttons == 4) {
                    var view = api.getViewById("2d");
                    return void view.pan(evt.movementX, evt.movementY);
                }
            } else {
                if (1 == evt.button)
                    return void this.pan(evt.movementX, evt.movementY);
            }

            var _moveSencondPoint = function (pos) {
                this.area.radius = Vec2.difference(this.center, pos).magnitude();
            }.bind(this);
            if ("view2d_mousemove" == cmd) {

                //显示鼠标与内墙的距离--add by gaoning 2018.3.15
                createMouseToWallLine(modelPos);

                if (!this.center) return;
                _moveSencondPoint(modelPos), this._updateAreaAndCurve();
            } else if ("view2d_mouseup" == cmd) {
                if (1 == evt.button) return;
                void 0 == this.center ? (this.center = new Point(), this.center.x = this.area.center.x = modelPos.x,
                    this.center.y = this.area.center.y = modelPos.y) : (_moveSencondPoint(modelPos),
                    utilActionEnd(this.mgr));
            } else if ("expand" == cmd) {
                var src = evt, margin = modelPos;
                this.area.center.x = src.center.x, this.area.center.y = src.center.y, this.area.radius = src.radius + margin;
            }
        }
    }), ActionAddCube.prototype.type = "AddCube", classInherit(ActionAddCube, ActionBase),
    utilExtend(ActionAddCube.prototype, {
        canUndoRedo: function () {
            return !0;
        },
        _materialUndoRedo: function () {
            var before = this.materialEntity[this.materialSide];
            this.materialEntity[this.materialSide] = this.materialBefore, this.materialBefore = before,
                this.materialEntity instanceof Floor ? utilModelChangeFlag(this.materialEntity, FLOORFLAG_CHANGED_FOR_REDRAWN) : this.materialEntity instanceof Area && utilModelChangeFlag(this.materialEntity, AREAFLAG_CHANGED_FOR_REDRAWN);
        },
        undo: function () {
            if (this.product instanceof Material) this._materialUndoRedo(); else if (utilEntityRemoveLink(this.fp, this.product),
                this.product instanceof Opening) {
                var attached = this.product.attached;
                attached && attached.type == Wall.prototype.type && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
            }
        },
        redo: function () {
            if (this.product instanceof Material) this._materialUndoRedo(); else if (utilEntityAddLink(this.fp, this.product),
                this.product instanceof Opening) {
                var attached = this.product.attached;
                attached && attached.type == Wall.prototype.type && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
            }
        },
        needViewportMouseMove: function () {
            return !0;
        },
        begin: function (category, opt) {
            var allObjArrary = api.floorplanFilterEntity(function (e) {
                return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR" || e.type == 'BEAM' || e.type == 'BASEMENT');
            });
            if (allObjArrary[0] == undefined) {
                globalModelIndex = 1;
            } else {
                globalModelIndex = getAllObjArraryLength() + 1;
            }
            __log("run this action: " + this.type + ", param=" + opt ? JSON.stringify(opt) : "");
            var Class = Cube;
            "beam" == category ? Class = Beam
                : "pillar" == category ? Class = Pillar
                : "basement" == category ? Class = Basement
                : __assert(!1, "Unknown category:" + category);
            var product = this.product = new Class(opt);
            return opt && opt.x && (product.x = opt.x), opt && opt.y && (product.y = opt.y),
                utilEntityAddLink(this.fp, product), product;
        },
        end: function () {
            Flag = 1;
            if (this.product.x < -99 && this.product.y < -99) return void utilEntityRemoveLink(this.fp, this.product);
            if (this.product instanceof Opening) {
                var attached = this.product.attached;
                attached && attached.type == Wall.prototype.type && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
            }
        },
        run: function (cmd, evt, position, attachments) {
            if (1 == Flag) {
                globalModelIndex++;
                Flag = 0;
            }
            __log(cmd);
            "view2d_mousemove" == cmd ? (this.product.x = position.x, this.product.y = position.y) : "view2d_mouseup" == cmd ? utilActionEnd(this.mgr) : "click3d" == cmd ? utilActionEnd(this.mgr)

                : ("mouseup3d" == cmd || ("mousemove3d" == cmd ) ? this.product instanceof Opening || this.product instanceof Product : "keydown" == cmd && "ESC" == position && utilEntityRemoveLink(this.fp, this.product));

            ;
        }
    }), ActionAddAnnotation.prototype.type = "AddAnnotation", classInherit(ActionAddAnnotation, ActionBase),
    utilExtend(ActionAddAnnotation.prototype, {
        needViewportMouseMove: function () {
            return !0;
        },
        begin: function (copy) {
            __log("run this action: " + this.type), this.annotation = new Annotation("", 1), utilEntityAddLink(this.fp, this.annotation);
            var annotation = copy || this.annotation;
            return this.delta.x = annotation.tx - annotation.x, this.delta.y = annotation.ty - annotation.y,
                this.annotation;
        },
        end: function () {
        },
        run: function (cmd, evt, position, attachments) {
            __log(cmd), "view2d_mousemove" == cmd || "setPos" == cmd ? (this.annotation.x = position.x,
                this.annotation.y = position.y, this.annotation.tx = this.delta.x + this.annotation.x,
                this.annotation.ty = this.delta.y + this.annotation.y) : "view2d_mouseup" == cmd && utilActionEnd(this.mgr);
        }
    }), ActionAddSimpleAnnotation.prototype.type = "AddSimpleAnnotation", classInherit(ActionAddSimpleAnnotation, ActionBase),
    utilExtend(ActionAddSimpleAnnotation.prototype, {
        //纯文本注释 add by hcw
        needViewportMouseMove: function () {
            return !0;
        },
        begin: function (copy) {
            __log("run this action: " + this.type), this.annotation = new Annotation("", 2), utilEntityAddLink(this.fp, this.annotation);
            var annotation = copy || this.annotation;
            return this.delta.x = annotation.tx - annotation.x, this.delta.y = annotation.ty - annotation.y,
                this.annotation;
        },
        end: function () {
        },
        run: function (cmd, evt, position, attachments) {
            __log(cmd), "view2d_mousemove" == cmd || "setPos" == cmd ? (this.annotation.x = position.x,
                this.annotation.y = position.y, this.annotation.tx = this.delta.x + this.annotation.x,
                this.annotation.ty = this.delta.y + this.annotation.y) : "view2d_mouseup" == cmd && utilActionEnd(this.mgr);
        }
    }), ActionAddCamera.prototype.type = "AddCamera", classInherit(ActionAddCamera, ActionBase),
    utilExtend(ActionAddCamera.prototype, {
        needViewportMouseMove: function () {
            return !0;
        },
        begin: function (opt) {
        	  //__log("run this action: " + this.type);
            return this.camera = new Camera(), this.camera.x = NaN,
                this.lastCamera = utilFloorplanGetActiveCamera(this.fp), this.camera;
        },
        end: function () {
        },
        run: function (cmd, evt, position, attachments) {
            if (__log(cmd), "view2d_mousedown" == cmd || "setPos" == cmd) this.camera.x = position.x,
                this.camera.y = position.y; else if ("view2d_mousemove" == cmd || "setTar" == cmd) {
                if (isNaN(this.camera.x)) return;
                utilEntityAddLink(this.fp, this.camera), utilFloorplanSetActiveCamera(this.fp, [this.camera.id]),
                    this.camera.tx = position.x, this.camera.ty = position.y;
            } else "view2d_mouseup" == cmd && utilActionEnd(this.mgr);
        }
    }), ActionMakeGroup.prototype.type = "MakeGroup", classInherit(ActionMakeGroup, ActionBase),
    utilExtend(ActionMakeGroup.prototype, {
        begin: function (group) {
            return this.group = group, this.group || (this.group = new Group(), this.group.name = "Group_" + Math.round(1e3 * Math.random()),
                utilEntityAddLink(this.fp, this.group)), this.group;
        },
        end: function () {
        },
        run: function (cmd, event, model) {
            function moveGroupItem(from, to) {
                for (var i = from.children.length - 1; i >= 0; --i) {
                    var child = from.children[i];
                    child instanceof Group ? (utilGroupRemoveItem(from, child), moveGroupItem(child, to),
                        utilGroupUpdateCenter(fp, child)) : (utilGroupRemoveItem(from, child), utilGroupAddItem(to, child));
                }
                utilGroupUpdateCenter(fp, from);
            }

            if ("fromTempGroup" == cmd) {
                var tmpGroup = GROUP_TEMP, newGroup = this.group, fp = this.fp;
                moveGroupItem(tmpGroup, newGroup), utilGroupReset(fp, tmpGroup), utilPickMgrUnpickAll(application.pickMgr);
            } else "attach" == cmd ? (__assert(!1, "NOT IMPLEMENTED"), __assert(model && model.type != Group.prototype.type, "group could not attach another group"),
                utilGroupAddItem(this.group, model), utilGroupUpdateCenter(this.fp, this.group)) : "detach" == cmd && (utilGroupRemoveItem(this.group, model),
                utilGroupUpdateCenter(this.fp, this.group));
            utilGroupUpdateBoxCenter(this.group)
        }
    }), ActionAddGroup.prototype.type = "AddGroup", classInherit(ActionAddGroup, ActionBase),
    utilExtend(ActionAddGroup.prototype, {
        begin: function (group) {
            return this.group = group, this.group || (this.group = new Group(), this.group.name = "Group_" + Math.round(1e3 * Math.random()),
                utilEntityAddLink(this.fp, this.group)), this.group;
        },
        end: function () {
        },
        needViewportMouseMove: function () {
            return !0;
        },
        fromTempGroup: function (del) {
            function moveGroupItem(from, to) {
                for (var i = from.children.length - 1; i >= 0; --i) {
                    var child = from.children[i];
                    child instanceof Group ? (utilGroupRemoveItem(from, child), moveGroupItem(child, to),
                        utilGroupUpdateCenter(fp, child)) : (utilGroupRemoveItem(from, child), utilGroupAddItem(to, child));
                }
                utilGroupUpdateCenter(fp, from);
            }
            var tmpGroup = GROUP_TEMP, newGroup = this.group, fp = this.fp;
            moveGroupItem(tmpGroup, newGroup), utilGroupReset(fp, tmpGroup), utilPickMgrUnpickAll(application.pickMgr);
            utilActionEnd(this.mgr);
            utilGroupUpdateBoxCenter(newGroup)
            if (del) {
                utilActionBegin(this.mgr, "DeleteGroup", newGroup)
                utilActionEnd(this.mgr);
            }
        },
        run: function (cmd, evt, position, attachments, names) {
            if (__log(cmd), "view2d_mousemove" == cmd) {
                utilPickMgrUnpickAll(application.pickMgr)
                var childPos = {};
                GROUP_TEMP.children.forEach(function (child) {
                    childPos[child.id] = {
                        x: child.x,
                        y: child.y,
                        px: child.px,
                        py: child.py
                    };
                })
                var db = this.group.database;
                Object.keys(childPos).forEach(function (childId) {
                    var child = db[childId], pos = child.x ? child : child.center;
                    pos.x = position.x + childPos[child.id].px, pos.y = position.y + childPos[child.id].py;
                }, this);

            } else if ("view2d_mouseup" == cmd) {
                this.fromTempGroup(false);
            } else if ("keydown" == cmd && "ESC" == position) {
                this.fromTempGroup(true);
            }
            ;
        }
    }), ActionExplodeGroup.prototype.type = "ExplodeGroup", classInherit(ActionExplodeGroup, ActionBase),
    utilExtend(ActionExplodeGroup.prototype, {
        begin: function (group) {
            this.group = group, this.childrenIds = group.children.map(function (child) {
                return child.id;
            }), utilGroupReset(this.fp, group), utilEntityRemoveLink(this.fp, group);
        },
        end: function () {
        },
        run: function (cmd, event, old, delta) {
        }
    }), ActionDeleteProduct.prototype.type = "DeleteProduct", classInherit(ActionDeleteProduct, ActionBase),
    utilExtend(ActionDeleteProduct.prototype, {
        canUndoRedo: function () {
            return !0;
        },
        undo: function () {
            classBase(this, "undo");
            var attachedWall = this.product.attached;
            //utilEntityAddLink(this.fp, this.product);
            //change by gaoning 2017.5.11 修改删除物品后返回物品旋转出错的问题。
            var productMeta = this.mgr.app.catalogMgr.productsMeta[this.product.id] || this.product.meta;
            var category = productMeta && productMeta.category;
            var Class = Product;
            "opening" == category ? Class = Opening : "door" == category ? Class = Door : "window" == category ? Class = Windows :("customparquet" == category || "custom_tile" == category || "tile" == category )? Class = Material : "parquet" == category ? Class = Parquet : "furniture_replacement" == category ? Class = ProductReplacement : "rawcolor" == category && (Class = MaterialRawColor);
            var product = new Class(productMeta);
            Class instanceof Material || utilEntityAddLink(this.fp, product);

            product.x = this.product.x;
            product.y = this.product.y;
            product.z = this.product.z;
            product.rot = this.product.rot;
            product.flip = this.product.flip;
            product.sx = this.product.sx;
            product.sy = this.product.sy;
            product.sz = this.product.sz;
            // attached group quaternion_x
            product.rotx = this.product.rotx;
            product.roty = this.product.roty;
            product.rotz = this.product.rotz;
            product.quaternion_x = this.product.quaternion_x;
            product.quaternion_y = this.product.quaternion_y;
            product.quaternion_z = this.product.quaternion_z;
            product.quaternion_w = this.product.quaternion_w;
            product.attached = this.product.attached;
            product.group = this.product.group;

            this.product = product;

            attachedWall && utilModelSetFlagOn(attachedWall, WALLFLAG_DETAILEDUPDATED_3D);
        },
        redo: function () {
            classBase(this, "redo");
            var attachedWall = this.product.attached;
            this.product;
            utilEntityRemoveLink(this.fp, this.product), attachedWall && utilModelSetFlagOn(attachedWall, WALLFLAG_DETAILEDUPDATED_3D);
        },
        begin: function (product) {
            if (product) {
                this.product = product;
                this.savedForUndo = this.product.save();
                __log("run this action: " + this.type + ", pid=" + product.pid);
                var attachedWall = product.attached;
                utilEntityRemoveLink(this.fp, product);
                utilActionEnd(this.mgr);
                product.group && (utilGroupRemoveItem(product.group, product)/*, utilGroupUpdateCenter(this.fp, product.group)*/);
                attachedWall && utilModelSetFlagOn(attachedWall, WALLFLAG_DETAILEDUPDATED_3D);
                this.product.isdelete = 1;//添加物体被删除标识 add by hcw
                application.laberFrame(false)//添加物体标注线输入框显示
            } else {
                utilActionEnd(this.mgr);
            }
        }
    }), ActionDeleteArea.prototype.type = "DeleteArea", classInherit(ActionDeleteArea, ActionBase),
    utilExtend(ActionDeleteArea.prototype, {
        isEnable: function () {
            return !0;
        },
        begin: function (area) {
            this.area = area;
            //__log("run this action: " + this.type + ", area id=" + area.pid);
            area.profile && area.profile.forEach(function (curve) {
                curve && (curve.begin = void 0, curve.end = void 0, utilEntityRemoveLink(this.fp, curve));
            }, this);
            area.center && (area.center = void 0), area.profile = [], utilEntityRemoveLink(this.fp, area);
            area.group && (utilGroupRemoveItem(area.group, area)/*, utilGroupUpdateCenter(this.fp, area.group)*/);
            
            //刷新area3d
            if(area.type == Baseboard.prototype.type || area.type == Wallboard.prototype.type){
            	utilFloorplanUpdateWallAreaByWall(area.host);
            }
            
            return area;
        }
    }), ActionDeleteGroup.prototype.type = "DeleteGroup", classInherit(ActionDeleteGroup, ActionBase),
    utilExtend(ActionDeleteGroup.prototype, {
        isEnable: function () {
            return !0;
        },
        begin: function (group) {
            if (this.group = group, __log("run this action: " + this.type), group.id != GROUP_TEMP.id) return utilEntityRemoveLink(this.fp, group),
                this.deleteGroup(void 0, void 0, group), !0;
            var subGroups = group.children.filter(function (child) {
                return child instanceof Group;
            });
            subGroups.forEach(function (group) {
                this.deleteGroup(void 0, void 0, group);
            }, this), this.deleteGroup(void 0, void 0, group), utilGroupReset(this.fp, group);
        },
        deleteGroup: function (cmd, evt, group) {
            for (var i = group.children.length - 1; i >= 0; --i) {
                var child = group.children[i];
                utilGroupRemoveItem(group, child), utilEntityRemoveLink(this.fp, child);
            }
        }
    }), ActionDeleteAutoLight.prototype.type = "DeleteAutoLight", classInherit(ActionDeleteAutoLight, ActionDeleteProduct),
    utilExtend(ActionDeleteAutoLight.prototype, {
        canUndoRedo: function () {
            return !1;
        }
    }), ActionMoveMaterial.prototype.type = "MoveMat", classInherit(ActionMoveMaterial, ActionBase),
    utilExtend(ActionMoveMaterial.prototype, {
        begin: function (material) {
            this.material = material, this.material && (this.tx = this.material.tx, this.ty = this.material.ty);
        },
        end: function () {
        },
        run: function (cmd, axis, behavior, offset) {
            if ("move" == cmd) {
                if ("x" != axis && "y" != axis)
                    return;

                if (this.material) {
                    var translateProperty = "t" + axis;
                    this.material[translateProperty] = ("delta" == behavior ? this[translateProperty] : 0) + offset;
                }
            }
        }
    }), ActionMoveArea.prototype.type = "MoveArea", classInherit(ActionMoveArea, ActionBase),
    utilExtend(ActionMoveArea.prototype, {
        canUndoRedo: function () {
            return !0;
        },
        undo: function () {
            classBase(this, "undo"), this.copiedArea && utilEntityRemoveLink(this.fp, this.copiedArea);
            var orig = {
                x: this.area.center.x,
                y: this.area.center.y
            };
            this.area.center.x = this.orig.x, this.area.center.y = this.orig.y, this.orig = orig;
        },
        redo: function () {
            classBase(this, "redo"), this.copiedArea && utilEntityAddLink(this.fp, this.copiedArea);
            var orig = {
                x: this.area.center.x,
                y: this.area.center.y
            };
            this.area.center.x = this.orig.x, this.area.center.y = this.orig.y, this.orig = orig;
        },
        begin: function (area, opt) {
            this.area = area;
            var orig = this.area.center || this.area.profile[0];
            this.orig = {
                x: orig.x,
                y: orig.y
            };
        },
        end: function () {
        },
        run: function (cmd, event, offset, attached) {
            "mousemove2d" == cmd && this.area.center && (this.area.center.x = this.orig.x + offset.x,
                this.area.center.y = this.orig.y + offset.y, event && event.altKey === !1 && this.area.boundSnap(),
            this.area.group && utilModelChangeFlag(this.area.group, GROUPFLAG_VIEW_UPDATE));
        }
    }), ActionMoveGroup.prototype.type = "MoveGroup", classInherit(ActionMoveGroup, ActionBase),
    utilExtend(ActionMoveGroup.prototype, {
        begin: function (group, opt) {
            this.group = group, __assert(this.group && this.group instanceof Group, "Move group needs a group");
            var leafItems = utilGroupGetAllLeafChildren(this.group);
            leafItems.forEach(function (child) {
                var pos = child.x ? child : child.center;
                this.childPos[child.id] = {
                    x: pos.x,
                    y: pos.y
                };
            }, this);
            this.groupCenter={
                x:group.x,
                y:group.y
            }
        },
        end: function () {
            var fp = this.fp;
            /*utilGroupUpdateCenter(fp, this.group),*/utilModelChangeFlag(this.group, GROUPFLAG_VIEW_UPDATE),
                this.group.children.forEach(function (child) {
                    child instanceof Group && (utilGroupUpdateCenter(fp, child), utilModelChangeFlag(child, GROUPFLAG_VIEW_UPDATE));
                });
        },
        run: function (cmd, event, position, offsetFromBegin) {
            if ("mousemove3d_transformctrl" == cmd || "mousemove2d" == cmd) {
                var db = this.group.database;
                Object.keys(this.childPos).forEach(function (childId) {
                    var child = db[childId], pos = child.x ? child : child.center;
                    pos.x = offsetFromBegin.x + this.childPos[child.id].x, pos.y = offsetFromBegin.y + this.childPos[child.id].y;
                    }, this), utilGroupUpdateCenter(this.fp, this.group);
                this.group.x=offsetFromBegin.x+this.groupCenter.x,this.group.y=offsetFromBegin.y+this.groupCenter.y;
            }
        }
    }), ActionRotateProduct.prototype.type = "RotateProduct", classInherit(ActionRotateProduct, ActionBase),
    utilExtend(ActionRotateProduct.prototype, {
        canUndoRedo: function () {
            return !0;
        },
        undo: function () {
            classBase(this, "undo");
            var rot = this.product.rot;
            this.product.rot = this.srcRot, this.srcRot = rot;
        },
        redo: function () {
            classBase(this, "redo");
            var rot = this.product.rot;
            this.product.rot = this.srcRot, this.srcRot = rot;
        },
        begin: function (product) {
            this.product = product, this.srcRot = this.product.rot;
        },
        end: function () {
        },
        run: function (cmd, event, old, delta) {
            "mousemove3d_transformctrl" == cmd ? (this.product.rot = utilMathRotationSnap((old.z + delta.z + 360) % 360),
                //修改最小的旋转角度为10度 --change by gaoning 2017.4.20
                __log("content rotation=" + this.product.rot)) : "whitespace" == cmd && !this.product.group && (this.product.rot = utilMathRotationSnap((this.product.rot + 90) % 360)),
            this.product.group && utilModelChangeFlag(this.product.group, GROUPFLAG_VIEW_UPDATE);
        }
    }), ActionChangeDoorSwing.prototype.type = "ChangeDoorSwing", classInherit(ActionChangeDoorSwing, ActionBase),
    utilExtend(ActionChangeDoorSwing.prototype, {
        begin: function (product) {
            this.product = product;
        },
        end: function () {
        },
        run: function (cmd, event, old, delta) {
            "mousemove_transformctrl" == cmd ? (this.product.rot = (old.z + delta.z) % 360,
                __log("content rotation=" + this.product.rot)) : "whitespace" == cmd && (this.product.swing = (this.product.swing + 1) % 4);
        }
    }), ActionRotateMaterial.prototype.type = "RotMat", classInherit(ActionRotateMaterial, ActionBase),
    utilExtend(ActionRotateMaterial.prototype, {
        begin: function (material) {
            this.material = material, this.srcRot = this.material.rot;
        },
        end: function () {
        },
        run: function (cmd, behavior, angle) {
            "rot" == cmd && (this.material.rot = ("delta" == behavior ? this.srcRot : 0) + Number(angle));
        }
    }), ActionScaleProduct.prototype.type = "ScaleProduct", classInherit(ActionScaleProduct, ActionBase);

var ActionScaleProduct_MAX_FACTOR = 4, ActionScaleProduct_MIN_FACTOR = 0.05;

utilExtend(ActionScaleProduct.prototype, {
    canUndoRedo: function () {
        return !0;
    },
    undo: function () {
        classBase(this, "undo");
        var scale = {x: this.product.sx, y: this.product.sy, z: this.product.sz};
        this.product.sx = this.srcScale.x, this.product.sy = this.srcScale.y, this.product.sz = this.srcScale.z, this.srcScale = scale;
    },
    redo: function () {
        classBase(this, "redo");
        var scale = {x: this.product.sx, y: this.product.sy, z: this.product.sz};
        this.product.sx = this.srcScale.x, this.product.sy = this.srcScale.y, this.product.sz = this.srcScale.z, this.srcScale = scale;
    },
    begin: function (product) {
        this.product = product;
        this.srcScale = {x: this.product.sx, y: this.product.sy, z: this.product.sz};
    },
    end: function () {
        var attached = this.product.attached;
        attached && this.product instanceof Opening && attached instanceof Wall && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
    },
    run: function (cmd, event, scale) {
        scale && "mouseup3d_transformctrl" != cmd && ("mousemove3d_transformctrl" != cmd && "mousemove" != cmd && "set" != cmd ||
        (scale.x && (this.product.sx = Math.max(ActionScaleProduct_MIN_FACTOR, Math.min(ActionScaleProduct_MAX_FACTOR, scale.x))),
        scale.y && (this.product.sy = Math.max(ActionScaleProduct_MIN_FACTOR, Math.min(ActionScaleProduct_MAX_FACTOR, scale.y))),
        scale.z && (this.product.sz = Math.max(ActionScaleProduct_MIN_FACTOR, Math.min(ActionScaleProduct_MAX_FACTOR, scale.z))),
        this.product instanceof Cube && (this.product.sx = scale.x || this.product.sx, this.product.sy = scale.y || this.product.sy,
            this.product.sz = scale.z || this.product.sz)));
    }
}), ActionScaleMaterial.prototype.type = "ScaleMaterial", classInherit(ActionScaleMaterial, ActionBase);

var ActionScaleMaterial_MAX_FACTOR = 8, ActionScaleMaterial_MIN_FACTOR = 1 / ActionScaleMaterial_MAX_FACTOR;

utilExtend(ActionScaleMaterial.prototype, {
    begin: function (material) {
        this.material = material;
    },
    end: function () {
    },
    run: function (cmd, event, scale) {
        "mousemove" == cmd && (this.material.sx = Math.max(ActionScaleMaterial_MIN_FACTOR, Math.min(ActionScaleMaterial_MAX_FACTOR, scale.x)),
            this.material.sy = Math.max(ActionScaleMaterial_MIN_FACTOR, Math.min(ActionScaleMaterial_MAX_FACTOR, scale.y)));
    }
}), ActionRotateGroup.prototype.type = "RotateGroup", classInherit(ActionRotateGroup, ActionBase),
    utilExtend(ActionRotateGroup.prototype, {
        begin: function (group) {
            this.group = group;
        },
        end: function () {
           /* utilGroupUpdateCenter(this.fp, this.group),*/utilModelChangeFlag(this.group, GROUPFLAG_VIEW_UPDATE);
        },
        run: function (cmd, event, delta,rot) {
            rot=rot?rot:0;
            "mousemove3d_transformctrl" == cmd || "contextmenu" == cmd ? (/*this.group.rot=rot,*/utilGrouptRotateDelta(this.group, delta)) : "whitespace" == cmd && utilGrouptRotateDelta(this.group, 45),
                utilModelChangeFlag(this.group, GROUPFLAG_VIEW_UPDATE);
        }
    }), ActionCopyProduct.prototype.type = "CopyProduct", classInherit(ActionCopyProduct, ActionBase),
    utilExtend(ActionCopyProduct.prototype, {
        begin: function (source) {
            if (!(source instanceof Product)) return void __assert(!1, "only furniture could be copied.");
            var productMeta = this.mgr.app.catalogMgr.productsMeta[source.pid];
            var product = this.product = new TYPE[source.type](productMeta);
            product.copy(source);
            utilEntityAddLink(this.fp, product);
            product.x += .5;
            product.y -= .5;
            product.rot += 10;
            product.rot -= 10;
        },
        end: function () {
            globalModelIndex++;
        },
        run: function (cmd, event, old, delta) {
        }
    }), ActionCopyArea.prototype.type = "CopyArea", classInherit(ActionCopyArea, ActionBase),
    utilExtend(ActionCopyArea.prototype, {
        begin: function (source) {
            if (!(source instanceof Area)) return void __assert(!1, "only Area could be copied.");
            if (!source.center) return void __assert(!1, "not implemented");
            var area = this.area = new TYPE[source.type]({});
            area.copy(source);
            utilEntityAddLink(this.fp, area);
            area.center ? (area.center.x += .5, area.center.y -= .5) : __assert(!1, "not implemented");

            //没有结束复制命令
        },
        end: function () {
        },
        run: function (cmd, event, old, delta) {
        }
    }), ActionCopyGroup.prototype.type = "CopyGroup", classInherit(ActionCopyGroup, ActionBase),
    utilExtend(ActionCopyGroup.prototype, {
        begin: function (group) {
            if (!(group instanceof Group)) return void __assert(!1, "only group could be copied.");
            var bound = group.getBound(), offset = (bound.center(), {
                x: bound.width,
                y: -bound.height
            }), fp = this.fp;
            group.id == GROUP_TEMP.id ? group.children.forEach(function (child) {
                if (child instanceof Group) this.copiedGroup = utilActionCopyGroup(fp, child, offset); else if (child instanceof Product) {
                    utilActionCopyProduct(fp, child, void 0, offset);
                }
            }, this) : this.copiedGroup = utilActionCopyGroup(fp, group, offset);
        },
        end: function () {
           this.copiedGroup && (this.copiedGroup.id != GROUP_TEMP.id && utilGroupUpdateBoxCenter(this.copiedGroup))
        }
    }), ActionSplitWall.prototype.type = "SplitWall", classInherit(ActionSplitWall, ActionBase),
    utilExtend(ActionSplitWall.prototype, {
        _updateFloorAndWallCorner: function () {
            utilFloorplanRebuildFloor(this.fp);
            utilFloorplanForEachWall(this.fp, function (w) {
                utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D);
                utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
            });
        },
        isEnable: function () {
            return utilModelIsFlagOff(this.fp, MODELFLAG_LOCKED);
        },
        begin: function (model, lerp) {
            this.current = model, this.added = utilWallBreak(this.fp, this.current, lerp);
        },
        end: function () {
            this._updateFloorAndWallCorner();
        },
        run: function (cmd, lerp) {
        }
    }), ActionAnalyzeNormalized.prototype.type = "AnalyzeNormalized", classInherit(ActionAnalyzeNormalized, ActionBase),
    utilExtend(ActionAnalyzeNormalized.prototype, {
        begin: function () {
            this.analyzed = utilFloorplanAnalyzeNormalization(this.fp);
        },
        end: function () {
        },
        run: function (cmd, event, old, delta) {
            return "analyze" == cmd ? (0 == this.analyzed.length && utilActionEnd(this.mgr, ActionAnalyzeNormalized.prototype.type),
                this.analyzed) : void 0;
        }
    }), ActionRulerMeasure.prototype.type = "RulerMeasure", classInherit(ActionRulerMeasure, ActionBase),
    utilExtend(ActionRulerMeasure.prototype, {
        canUndoRedo: function () {
            return !1;
        },
        _getMeasument: function () {
            for (var measure = 0, i = 1; i < this.points.length; ++i) measure += utilMathLineLength(this.points[i - 1], this.points[i]);
            return measure;
        },
        begin: function () {
            this.points = [], application.rulerMeasurementChanged.dispatch(0);
        },
        end: function () {
            application.rulerMeasurementChanged.dispatch(void 0);
        },
        run: function (cmd, event, position) {
            if ("mouseup" == cmd) {
                this.points.push(position);
                var measure = this._getMeasument();
                application.rulerMeasurementChanged.dispatch(measure);
            }
        }
    }), ActionMaterialDropper.prototype.type = "MaterialDropper", classInherit(ActionMaterialDropper, ActionBase),
    utilExtend(ActionMaterialDropper.prototype, {
        begin: function () {
        },
        end: function () {
        },
        _getPickedMaterial: function (pickResult) {
            if (pickResult && pickResult.model) {
                var model = pickResult.model, view = pickResult.opt && pickResult.opt.src;
                pickResult.opt && pickResult.opt.elementName;
                if (model.type == Floor.prototype.type) return model.floorMaterial;
                if (model instanceof Area) return model.areaMaterial;
                if (model.type == Wall.prototype.type && "3d" == view) {
                    var mat = pickResult.opt.elementName + "Material";
                    return model[mat] || new Material({
                            pid: DEFAULT_TILE_MATERIAL_ID
                        });
                }
                if (model.type == ProductReplacement.prototype.type && "3d" == view) {
                    var mat = pickResult.opt.elementName + "Material";
                    return model[mat];
                }
                if (model instanceof Cube && "3d" == view) {
                    var mat = pickResult.opt.elementName + "Material";
                    return model[mat];
                }
            }
        },
        _setPickedMaterial: function (pickResult, option) {
            if (this.pickMat && pickResult && pickResult.model) {
                var model = pickResult.model, view = pickResult.opt && pickResult.opt.src, clonedMat = (pickResult.opt && pickResult.opt.elementName,
                    this.pickMat.clone ? this.pickMat.clone() : new Material({
                        pid: this.pickMat.pid
                    }));
                for (var key in option) clonedMat[key] = option[key];
                if (model.type == Floor.prototype.type) model.floorMaterial = clonedMat; else if (model instanceof Area) model.areaMaterial = clonedMat; else if (model.type == Wall.prototype.type && "3d" == view) {
                    var mat = pickResult.opt.elementName + "Material";
                    model[mat] = clonedMat;
                } else if (model.type == ProductReplacement.prototype.type && "3d" == view) {
                    var mat = pickResult.opt.elementName + "Material";
                    model[mat] = clonedMat;
                } else if (model instanceof Cube && "3d" == view) {
                    var mat = pickResult.opt.elementName + "Material";
                    model[mat] = clonedMat;
                }
            }
        },
        run: function (cmd, param, opt) {
            if ("pick" == cmd) {
                var pickMat = this._getPickedMaterial(param);
                return pickMat ? (this.pickMat = pickMat, this.pickMat) : -1;
            }
            if ("drop" == cmd) return this.droppedInfos.push({
                pick: param,
                mat: pickMat
            }), this._setPickedMaterial(param, opt), this.droppedInfos.length;
            if ("click3d" == cmd || "view2d_mouseup" == cmd) {
                var evt = param;
                2 == evt.button && utilActionEnd(this.mgr);
            }
        }
    }), ActionWallDropper.prototype.type = "WallDropper", classInherit(ActionWallDropper, ActionBase),
    utilExtend(ActionWallDropper.prototype, {
        begin: function () {
        },
        end: function () {
        },
        _getPickedWallboards: function (pickResult) {
            if (pickResult && pickResult.model) {
                var model = pickResult.model;
                var view = pickResult.opt && pickResult.opt.src;
                pickResult.opt && pickResult.opt.elementName;
                if ((model.type == "WALL" ||
                     model.type == "RECTAREA" ||
                     model.type == "ROUNDAREA" ||
                     model.type == "FREEAREA")  && "3d" == view) {
                     	
                    if(model[pickResult.opt.elementName + "Boards"]){	                    	 	
	                	  var wall = model;
	                	  var smoothStart = utilModelWallGetSmoothStart(wall, pickResult.opt.elementName);
	                	  wall = smoothStart.wall;
	                	  var elementName = smoothStart.side;
	                	  
	                	  var mat = elementName + "Material";
	                    return {wall:wall, boards:wall[elementName + "Boards"] || [], mat:wall[mat], elementName:elementName};
                    }                    
                }else if(model.host && 
                	       (model.host.type == "WALL" ||
			                    model.host.type == "RECTAREA" ||
			                    model.host.type == "ROUNDAREA" ||
			                    model.host.type == "FREEAREA")
			                     && "3d" == view) {
                	  //墙上的物体
                	  var wall = model.host;
                	  var mat = model.category + "Material";
                	  return {wall:wall,boards:wall[model.category + "Boards"] || [], mat:wall[mat], elementName:model.category};
                }
            }
        },
        _setPickedWallboards: function (pickResult, option) {
            if (this.pickinfo && pickResult && pickResult.model) {            	  
            	  var model = pickResult.model;
            	  var view = pickResult.opt && pickResult.opt.src;
                if ((model.type == "WALL" ||
                     model.type == "RECTAREA" ||
                     model.type == "ROUNDAREA" ||
                     model.type == "FREEAREA") && "3d" == view) {
                	  var wall = model;  
                	  var smoothStart = utilModelWallGetSmoothStart(wall, pickResult.opt.elementName);
                	  wall = smoothStart.wall;
                	  var elementName = smoothStart.side;               	               	
                	  if(this.pickinfo.wall == wall && this.pickinfo.elementName == elementName){
                	  	return;
                	  }                	                  	  
                	  this._clearWallboards(wall, elementName);
                	  this._copyWallboards(wall, elementName, this.pickinfo);
                }else if(model.host && 
                	       (model.host.type == "WALL" ||
			                    model.host.type == "RECTAREA" ||
			                    model.host.type == "ROUNDAREA" ||
			                    model.host.type == "FREEAREA")
			                     && "3d" == view) {
                	  var wall = model.host;
                	  if(this.pickinfo.wall == wall && this.pickinfo.elementName == model.category){
                	  	return;
                	  }
                	  this._clearWallboards(wall, model.category);
                	  this._copyWallboards(wall, model.category, this.pickinfo);
                }
            }
        },
        _clearWallboards: function(wall, elementName){
        	  var elementBoards = wall[elementName + "Boards"];
        	  var fp = this.fp;
        	  if(elementBoards && elementBoards.length > 0){		    			
                  //清空列表
                  wall[elementName + "Boards"] = [];
                  elementBoards.forEach(function(id){
                      var board = fp.lf[id];
                      utilEntityRemoveLink(fp, board);
                  });
              }
        },
        _copyWallboards: function(wall, elementName, pickinfo){
        	if(wall[elementName + "Boards"]){
        	  var wallboards = pickinfo.boards;
        	  var mat = pickinfo.mat;        	  
        	  
        	  //wall[elementName + "Material"] = mat;
        	  var fp = this.fp;
        	  for(var i=wallboards.length - 1; i>=0; i--){
        	  	var board = this.fp.lf[wallboards[i]];
        	  	if(board){
	        	  	if(board.type == Wallboard.prototype.type){
	        	  		var area = new Wallboard({
						    		category:elementName,
						    		host:wall
						    	});
						    	wall[elementName + "Boards"].splice(0,0,area.id);
						    	area.copy(board);					    	
						    	area.host = wall;
						    	area.category = elementName;
						    	utilEntityAddLink(fp, area);
						    	utilModelSetFlagOn(area, AREAFLAG_HOST_CHANGED_UPDATE3D);
	        	  	}else if(board.type == Baseboard.prototype.type){
	        	  		var area = new Baseboard({
						    		category:elementName,
						    		host:wall
						    	});
						    	wall[elementName + "Boards"].splice(0,0,area.id);
						    	area.copy(board);
						    	area.host = wall;
						    	area.category = elementName;
						    	utilEntityAddLink(fp, area);
						    	utilModelSetFlagOn(area, AREAFLAG_HOST_CHANGED_UPDATE3D);
	        	  	}
	        	  }
        	  }
        	}
        },
        run: function (cmd, param, opt) {
            if ("pick" == cmd) {
                var pickinfo = this._getPickedWallboards(param);
                return pickinfo ? (this.pickinfo = pickinfo, this.pickinfo) : -1;
            }
            if ("drop" == cmd){ 
	            return this.droppedInfos.push({
	                pick: param,
	                //mat: pickMat
	            }), this._setPickedWallboards(param, opt), this.droppedInfos.length;
	          }
            if ("click3d" == cmd || "view2d_mouseup" == cmd) {
                var evt = param;
                2 == evt.button && utilActionEnd(this.mgr);
            }	          
        }
    });
//-- gaoning
ActionApplyModelroom.prototype.type = "ApplyModelroom";
classInherit(ActionApplyModelroom, ActionBase);
utilExtend(ActionApplyModelroom.prototype, {
    begin: function (room, ghostFp, ghostRoom) {
        this.thisRoom = room;
        this.ghostRoom = ghostRoom;
        this.ghostFp = ghostFp;
    },
    end: function () {
    },
    run: function (cmd, data, opt) {

        "setconfig" == cmd ? (this.applyConfig = data, this.ghostUpdate.dispatch("init")) :
            "apply" == cmd ? utilAppFloorplanApplyGhostRoomStyles(application, void 0, this.thisRoom, this.ghostFp, this.ghostRoom, this.applyConfig) :
                "whitespace" == cmd ? (this.ghostRot = 90, this.ghostUpdate.dispatch("rot")) :
                "move" == cmd && (this.ghostMove.x = data.x, this.ghostMove.y = data.y, this.ghostUpdate.dispatch("move"));
    }
}), ActionSetFloorDirection.prototype.type = "SetFloorDirection", classInherit(ActionSetFloorDirection, ActionBase),
    utilExtend(ActionSetFloorDirection.prototype, {
        begin: function (model) {
            this.model = model;
        },
        end: function () {

        },
        run: function (val) {
            this.model.direction = val;
        }
    }),ActionSetHeight3d.prototype.type = "SetHeight3d", classInherit(ActionSetHeight3d, ActionBase),
    utilExtend(ActionSetHeight3d.prototype, {
        begin: function (model) {
            model && (model.type != Wall.prototype.type && model.type != Floor.prototype.type && model.type != Floorplan.prototype.type || (this.model = model,
                this.height3dBefore = this.model.height3d || DEFAULT_WALL_HEIGHT3D));
        },
        end: function () {
            this.walls.forEach(function (w) {
                utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
            });
        },
        run: function (cmd, height) {
            return this.model ? "reset" == cmd ? (this.model.width = DEFAULT_WALL_HEIGHT3D,
                void this.walls.push(this.model)) : void (this.model.type == Wall.prototype.type ? (this.model.height3d = height,
                this.walls.push(this.model)) : this.model.type == Floor.prototype.type && (this.model.height3d = height,
                this.model.profile.forEach(function (wall) {
                    wall.height3d = height, -1 == this.walls.indexOf(wall) && this.walls.push(wall);
                }, this))) : void 0;
        }
    }), ActionSetWallLength.prototype.type = "SetWallLength", classInherit(ActionSetWallLength, ActionBase),
    utilExtend(ActionSetWallLength.prototype, {
        begin: function (model, fixed) {
            if (model) {
                if (model.type != Wall.prototype.type) return !1;
                var wall = this.wall = model;
                this.wallLengthBefore = utilMathLineLength(wall.begin, wall.end);
                var movedWallsBegin = [], movedWallsEnd = [], movedPointsBegin = [], movedPointsEnd = [], changed = "begin";
                switch (fixed) {
                    case "left":
                        wall.begin.x < wall.end.x && (changed = "end");
                        break;

                    case "right":
                        wall.begin.x > wall.end.x && (changed = "end");
                        break;

                    case "up":
                        wall.begin.y > wall.end.y && (changed = "end");
                        break;

                    case "down":
                        wall.begin.y < wall.end.y && (changed = "end");
                }
                return utilFloorplanForEachWall(this.fp, function (w) {
                    w.id != wall.id && (utilMathIsSamePoint(w.begin, wall.begin, .1) && (movedWallsBegin.push(w),
                        movedPointsBegin.push(w.begin)), utilMathIsSamePoint(w.end, wall.begin, .1) && (movedWallsBegin.push(w),
                        movedPointsBegin.push(w.end)), utilMathIsSamePoint(w.begin, wall.end, .1) && (movedWallsEnd.push(w),
                        movedPointsEnd.push(w.begin)), utilMathIsSamePoint(w.end, wall.end, .1) && (movedWallsEnd.push(w),
                        movedPointsEnd.push(w.end)));
                }), this.movedInfo.which = "end" == changed ? "end" : "begin", this.movedInfo.walls = "begin" == this.movedInfo.which ? movedWallsBegin : movedWallsEnd,
                    this.movedInfo.points = "begin" == this.movedInfo.which ? movedPointsBegin : movedPointsEnd,
                    !0;
            }
        },
        end: function () {
            utilFloorplanRebuildFloor(this.fp), utilFloorplanForEachWall(this.fp, function (w) {
                utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
            });
            utilFloorplanUpdateWallArea(this.fp);
        },
        run: function (cmd, length) {
            if (this.wall && "set" == cmd) {
                var newPt = utilMathGetScaledPoint("begin" == this.movedInfo.which ? this.wall.end : this.wall.begin, "begin" == this.movedInfo.which ? this.wall.begin : this.wall.end, length);
                return this.wall[this.movedInfo.which].x = newPt.x, this.wall[this.movedInfo.which].y = newPt.y,
                    void this.movedInfo.points.forEach(function (pt) {
                        pt.x = newPt.x, pt.y = newPt.y;
                    });
            }
        }
    }), ActionSetMaterial.prototype.type = "SetMat", classInherit(ActionSetMaterial, ActionBase),
    utilExtend(ActionSetMaterial.prototype, {
        begin: function (model, side, tileId) {
            this.model = model;
            var catalogMgr = this.mgr.app.catalogMgr, matProperty = side + "Material";
            this.old_material = model[matProperty], utilCatalogGetProductsMetaPromise(catalogMgr, [tileId]).then(function (meta) {
                var productMeta = meta[tileId];
                model[matProperty] = void 0;
                var mat = new Material(productMeta);
                model[matProperty] = mat, mat.tx = 1, mat.tx = 0;
            });
        },
        end: function () {
        },
        run: function (cmd, model, angle) {
        }
    }), ActionSetAreaLevel.prototype.type = "SetAreaLevel", classInherit(ActionSetAreaLevel, ActionBase),
    utilExtend(ActionSetAreaLevel.prototype, {
        begin: function (area) {
            this.area = area;
        },
        end: function () {
        },
        run: function (cmd, isToTop) {
            this.oldLevel = this.area.level;
            var areas = utilAppFloorplanGetAreasByHostId(application, void 0, this.area.host.id, this.area.category);
            utilAppFloorplanUpdateAreasLevel(areas, this.area, isToTop);
        }
    }), ActionSetGeneralProperty.prototype.type = "SetGeneralProp", classInherit(ActionSetGeneralProperty, ActionBase),
    utilExtend(ActionSetGeneralProperty.prototype, {
        canUndoRedo: function () {
            return !0;
        },
        undo: function () {
            var db = application.database;
            classBase(this, "undo");
            var oldVal = void 0;
            if (this.batchOldValue) {
                oldVal = {};
                for (var key in this.batchOldValue) {
                    var value = this.batchOldValue[key];
                    oldVal[key] = this.model[key];
                    this.model[key] = value;
                }
                this.batchOldValue = oldVal;
            } else {
                this.model && (oldVal = this.model[this.propName], this.model[this.propName] = this.oldValue,
                    this.oldValue = oldVal);
            }
            if (this.modelsSetBatch) {
                var data = this.modelsSetBatch;
                for (var model in data) for (var prop in data[model]) {
                    var oldvalue = this.modelsSetBatch[model][prop];
                    var newvalue = db[model][prop];
                    this.modelsSetBatch[model][prop] = newvalue;
                    db[model][prop] = oldvalue;
                }
            }
        },
        redo: function () {
            var db = application.database;
            classBase(this, "redo");
            var oldVal = void 0;
            if (this.batchOldValue) {
                oldVal = {};
                for (var key in this.batchOldValue) {
                    var value = this.batchOldValue[key];
                    oldVal[key] = this.model[key], this.model[key] = value;
                }
                this.batchOldValue = oldVal;
            } else this.model && (oldVal = this.model[this.propName], this.model[this.propName] = this.oldValue,
                this.oldValue = oldVal);
            if (this.modelsSetBatch) {
                var data = this.modelsSetBatch;
                for (var model in data) for (var prop in data[model]) {
                    var oldvalue = this.modelsSetBatch[model][prop], newvalue = db[model][prop];
                    this.modelsSetBatch[model][prop] = newvalue, db[model][prop] = oldvalue;
                }
            }
        },
        begin: function (model) {
            this.model = model;
        },
        end: function () {
        },
        run: function (cmd, prop, newValue) {
            var db = application.database;
            if ("set" == cmd) {
                this.propName = prop;
                this.oldValue = this.oldValue || this.model[prop];
                this.model[prop] = newValue;
            }
            else if ("setbatch" == cmd) {
                this.batchOldValue = this.batchOldValue || {};
                for (var key in prop) {
                    var value = prop[key];
                    this.batchOldValue[key] = this.batchOldValue[key] || this.model[key];
                    this.model[key] = value;
                }
            } else if ("manymodelsetbatch" == cmd) {
                this.modelsSetBatch = this.modelsSetBatch || {};
                var data = prop;
                for (var model in data) {
                    this.modelsSetBatch[model] = this.modelsSetBatch[model] || {};
                    for (var prop in data[model]) {
                        void 0 === this.modelsSetBatch[model][prop] && (this.modelsSetBatch[model][prop] = db[model][prop]);
                        var value = data[model][prop];
                        db[model][prop] = value;
                    }
                }
            }
        }
    }), ActionSetgeneralFlag.prototype.type = "SetGeneralFlag", classInherit(ActionSetgeneralFlag, ActionBase),
    utilExtend(ActionSetgeneralFlag.prototype, {
        canUndoRedo: function () {
            return !0;
        },
        undo: function () {
            classBase(this, "undo");
            this.oldValue;
            this.run(this.cmd, this.flag, this.oldValue);
        },
        redo: function () {
            classBase(this, "redo");
            this.oldValue;
            this.run(this.cmd, this.flag, this.oldValue);
        },
        begin: function (model) {
            this.model = model;
        },
        end: function () {
        },
        run: function (cmd, flag, trueOrFalse) {
            if (this.flag = flag, "change" == cmd) {
                return this.cmd = cmd, void utilModelChangeFlag(this.model, flag);
            }

            if (Array.isArray(this.model) && this.model.length > 0) {
                this.oldValue = utilModelIsFlagOn(this.model[0], flag);
                for (var i = 0; i < this.model.length; ++i) {
                    var model = this.model[i];
                    trueOrFalse ? utilModelSetFlagOn(model, flag) : utilModelSetFlagOff(model, flag);
                }
            } else this.oldValue = utilModelIsFlagOn(this.model, flag), trueOrFalse ? utilModelSetFlagOn(this.model, flag) : utilModelSetFlagOff(this.model, flag);
        }
    });

function ActionFlipProduct(mgr) {
    classBase(this, mgr), this.product = void 0;
}
ActionFlipProduct.prototype.type = "FlipProduct", classInherit(ActionFlipProduct, ActionBase);
utilExtend(ActionFlipProduct.prototype, {
    canUndoRedo: function () {
        return !0;
    },
    undo: function () {
        classBase(this, "undo");
        var flip = this.product.flip;
        this.product.flip = this.srcFlip, this.srcFlip = flip;
    },
    redo: function () {
        classBase(this, "redo");
        var flip = this.product.flip;
        this.product.flip = this.srcFlip, this.srcFlip = flip;
    },
    begin: function (product) {
        this.product = product;
        this.srcFlip = this.product.flip || false;
    },
    end: function () {

    },
    run: function (cmd, event, flip) {

        //if( this.product instanceof Cube){
        this.product.flip = flip;
        //}
    }
});