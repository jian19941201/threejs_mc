//2D snap
function DisplaySnapRectArea(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

classInherit(DisplaySnapRectArea, DisplaySnapArea);
utilExtend(DisplaySnapRectArea.prototype, {
    create: function () {
        classBase(this, "create");
        this.showDe={arrow:[],label:[],moveArrow:[]};
        var rectObj=this;
        var context = this.view.context;
        var view = this.view;
        var layer = this.view.layers[this.model.category];
        //var fillUrl = utilSnapAreaGetAreaMaterial(this);
        var fp = this.view.doc.floorplan;
        var app = application;
        var actionMgr = this.view.app.actionMgr;
        this.model.textpos=[];
        this.model.isdelete=0;
        if (this.de.length > 0 && 0 == layer.node.hasChildNodes(this.de[0]))
            return void layer.add(this.de);
            
        this.model.rebuild();
        var style = context.g().attr({
            opacity: (utilModelIsFlagOn(fp, MODELFLAG_LOCKED)||this.model.cavern) ? 1 : .4,
            did:this.id
        });
        style.add(utilFloorCreateSnapStyles(this));
        
        var highlight = context.rect().attr({
            fill: "#fff",
            "fill-opacity": .0,
            "stroke":"#ffe400",
            "stroke-opacity": 1,
            "stroke-width": 2
        })
        .drag(function (dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button && !(utilAppFloorplanIsLocked(app)||this.model.cavern)) {
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
                actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, modelOffset, modelOffset));
            }
        }, function (x, y, e) {
            if (e.stopPropagation(), 1 != e.button) {
                this._modelCenter = {
                    x: this.model.center.x,
                    y: this.model.center.y
                };
                var model = this.model;
                if (!actionMgr.current) {
                    var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveArea.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                    utilActionBegin(actionMgr, actionType, actionModel, {
                        shiftKey: e.shiftKey
                    });
                }
            }
        }, function (e) {
            e.stopPropagation(), 1 != e.button && (delete this._modelCenter, actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionEnd(actionMgr),
                areaCenter.attr({
                    opacity: 0
                })));
        }, this, this, this);
        
        var lineDragMove = function (side, dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button && !(utilAppFloorplanIsLocked(app)||this.model.cavern)) {
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy), rot = this.model.rot, center = this.model.center, sideVec = RECT_SIDE_VECTOR_MAP[side], moveDir = utilMathRotatePointCW({
                    x: 0,
                    y: 0
                }, sideVec, rot), moveLength = Vec2.dot(moveDir, modelOffset), centerBeforRotate = {
                    x: this._modelCenter.x,
                    y: this._modelCenter.y
                }, width = this.model.width, height = this.model.height;
                "left" == side || "right" == side ? (width = Math.abs(this._modelSize.width + moveLength),
                    centerBeforRotate.x += moveLength * sideVec.x / 2) : "top" != side && "bottom" != side || (height = Math.abs(this._modelSize.height + moveLength),
                        centerBeforRotate.y += moveLength * sideVec.y / 2);
                var centerRotated = utilMathRotatePointCW(this._modelCenter, centerBeforRotate, rot), center_x = centerRotated.x, center_y = centerRotated.y, changed = {};
                changed[this.model.id] = {
                    width: width,
                    height: height
                }, changed[center.id] = {
                    x: center_x,
                    y: center_y
                }, utilActionRun(actionMgr, "manymodelsetbatch", changed),this.model.group && utilModelChangeFlag(this.model.group, GROUPFLAG_VIEW_UPDATE), e && e.altKey === !1 && this.model.edgeSnap(side);
            }
        };
        var lineDragDown = function (side, x, y, e) {
            //add by gaoning 2017.3.9增加开关控制区域是否锁定。
            if (this.model.fixation)
                return;

            e.stopPropagation(), 1 != e.button && (this._modelCenter = {
                x: this.model.center.x,
                y: this.model.center.y
            }, this._modelSize = {
                width: this.model.width,
                height: this.model.height
            }, utilActionBegin(actionMgr, "SetGeneralProp"));
        };
        var lineDragUp = function (side, e) {
            e.stopPropagation(), 1 != e.button && (delete this._modelCenter, delete this._modelSize,
                utilActionEnd(actionMgr, "SetGeneralProp"));
        };
        var lineMouseOver = function (line, e) {
            //add by gaoning 2017.3.9增加开关控制区域边缘锁定。
            if (this.model.fixation)
                return;

            var locked = utilModelIsFlagOn(fp, MODELFLAG_LOCKED);
            locked || line.attr({
                "stroke-opacity": .9
            });
        };
        var lineMouseOut = function (line, e) {
            line.attr({
                "stroke-opacity": 0
            });
        };
        var lineAttr = {
            stroke: "#F07070",
            "stroke-opacity": 0,
            fill: "none",
            "stroke-width": 3,
            cursor: "move"
        };
        lineAttr.cursor='col-resize'
        var leftLine = context.path().attr(lineAttr).drag(lineDragMove.bind(this, "left"), lineDragDown.bind(this, "left"), lineDragUp.bind(this, "left"));
        leftLine.mouseover(lineMouseOver.bind(this, leftLine)).mouseout(lineMouseOut.bind(this, leftLine));
        var rightLine = context.path().attr(lineAttr).drag(lineDragMove.bind(this, "right"), lineDragDown.bind(this, "right"), lineDragUp.bind(this, "right"));
        rightLine.mouseover(lineMouseOver.bind(this, rightLine)).mouseout(lineMouseOut.bind(this, rightLine));
        lineAttr.cursor='row-resize'
        var topLine = context.path().attr(lineAttr).drag(lineDragMove.bind(this, "top"), lineDragDown.bind(this, "top"), lineDragUp.bind(this, "top"));
        topLine.mouseover(lineMouseOver.bind(this, topLine)).mouseout(lineMouseOut.bind(this, topLine));
        var bottomLine = context.path().attr(lineAttr).drag(lineDragMove.bind(this, "bottom"), lineDragDown.bind(this, "bottom"), lineDragUp.bind(this, "bottom"));
        bottomLine.mouseover(lineMouseOver.bind(this, bottomLine)).mouseout(lineMouseOut.bind(this, bottomLine));
        
        var areaCenter = context.circle(null, null, 5).attr({
            fill: "#F02012",
            "stroke-width": 0,
            opacity: 0
        });        
        this.de = [style, highlight, leftLine, rightLine, topLine, bottomLine, areaCenter];
        layer.add([style, highlight, leftLine, rightLine, topLine, bottomLine, areaCenter]);

        var updateFun = function (propertyName, oldValue, newValue, param) {
            if(propertyName instanceof Material){
                if("rot" == oldValue || "width" == oldValue || "height" == oldValue || "tx" == oldValue || "ty" == oldValue || "sx" == oldValue || "sy" == oldValue){
                    this.dF |= 2;
                }else if("flag" == oldValue){
                    (param & PAQUETFLAG_MATERIAL_CHANGED_FOR_REDRAW) != (newValue & PAQUETFLAG_MATERIAL_CHANGED_FOR_REDRAW) && (this.dF |= 2);
                }
            }else if("flag" == propertyName || "areaMaterial" == propertyName){
                (oldValue & AREAFLAG_CHANGED_FOR_REDRAWN) != (newValue & AREAFLAG_CHANGED_FOR_REDRAWN) && (this.dF |= 1,this.model.paveRebuild = true);
              (oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 2);
              (oldValue & MODELFLAG_LOCKED) != (newValue & MODELFLAG_LOCKED) && (this.dF |= 2);
            }else if("level" == propertyName){
                this.dF |= 8;
            } else if ("paveType" == propertyName) {
                this.dF |= 1;
                this.model.clearPaveDB();
                this.model.paveRebuild = true;
            }else if ("gapwidth" == propertyName || "gapcolor" == propertyName) {
                this.dF |= 1;
                this.model.paveRebuild = true;
            }else{
                this.dF |= 1;
                this.model.paveRebuild = true;
            }
        }.bind(this);
        var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
            if(changeFrom instanceof Material){
                this.dF |= 1;
                this.dF |= 2;
                this.model.paveRebuild = true;
                
                changeFrom.ignoreUV = true;
                this.model.clearPaveDB();
            }
        }.bind(this);
        
        var linkPropertyChangedFun = function(propertyName, linksOp, changeFrom, changeTo) {
              this.dF |= 1;
              this.dF |= 2;
              this.model.paveRebuild = true;
        }.bind(this);
        this.model.propertyChangedEvent.add(updateFun);
        this.model.linksChangedEvent.add(linksChangedFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    update: function () {
        var model=this.model;
        var style = this.de[0];
        var highlight = this.de[1];
        (this.showDe.label && this.showDe.label.length>0)? (this.showDe.label[0].attr("display", "none"),this.showDe.label[1].attr("display", "none"),this.showDe.label[2].attr("display", "none"),this.showDe.label[3].attr("display", "none")):"";
        (this.showDe.arrow && this.showDe.arrow.length > 0) ? (
            this.showDe.arrow.forEach(function (a) {
                a.attr("display", "none")
            })) : "";
        model.textpos=[];
        
        //重置铺砖
        this.model.rebuild();      
        if( 0 != (1 & this.dF)){
              style.clear();
              style.add(utilFloorCreateSnapStyles(this));
        }
        
        if (0 != (8 & this.dF) && utilSnapAreaLevelUpdated(this.view, this.model), 0 != (1 & this.dF)) {
            if (!this.model || !this.model.center){
                return;
            }
            if(isNaN(this.model.center.x) || isNaN(this.model.center.y)){
                  return;
            }
            var topLeft_x = this.model.center.x - this.model.width / 2;
            var topLeft_y = this.model.center.y + this.model.height / 2;
            var rot = this.model.rot;
            var attr = {
                x: 100 * topLeft_x,
                y: -100 * topLeft_y,
                width: 100 * this.model.width,
                height: 100 * this.model.height
            };
            //"M" + attr.x + "," + attr.y + "L" + (attr.x + attr.width) + "," + attr.y + "L" + (attr.x + attr.width) + "," + (attr.y + attr.height) + "L" + attr.x + "," + (attr.y + attr.height) + "Z";
            //style.attr(attr).transform("r" + -rot);
            highlight.attr(attr).transform("r" + -rot);
            
            //utilSnapAreaGetAreaMaterial(this);
            var viewArea = {};
            var modelArea = this.model;
            viewArea.width = modelArea.width;
            viewArea.height = modelArea.height;
            viewArea.center = modelArea.center;
            var obb = [utilMathRotatePointCW(viewArea.center, {
                x: viewArea.center.x - viewArea.width / 2,
                y: viewArea.center.y + viewArea.height / 2
            }, rot), utilMathRotatePointCW(viewArea.center, {
                x: viewArea.center.x + viewArea.width / 2,
                y: viewArea.center.y + viewArea.height / 2
            }, rot), utilMathRotatePointCW(viewArea.center, {
                x: viewArea.center.x + viewArea.width / 2,
                y: viewArea.center.y - viewArea.height / 2
            }, rot), utilMathRotatePointCW(viewArea.center, {
                x: viewArea.center.x - viewArea.width / 2,
                y: viewArea.center.y - viewArea.height / 2
            }, rot)];

            //change bu gaoning 2017.1.10 修改鼠标经过时红线的长度。
            var areaReadIndex = 3;
            var topLeft = obb[0];
            var topRight = obb[1];
            var bottomRight = obb[2];
            var bottomLeft = obb[3];
            var displays = this.de;
            var leftLine = (displays[0], displays[1], displays[2]);
            var rightLine = displays[3];
            var topLine = displays[4];
            var bottomLine = displays[5];
            var leftLineTop = Vec2.lerp(topLeft, bottomLeft, 0 / 3);
            var leftLineBottom = Vec2.lerp(topLeft, bottomLeft, areaReadIndex / 3);
            leftLine.attr("path", "M" + toFixedNumber(100 * leftLineTop.x, 2) + "," + toFixedNumber(-100 * leftLineTop.y, 2) + "L" + toFixedNumber(100 * leftLineBottom.x, 2) + "," + toFixedNumber(-100 * leftLineBottom.y, 2));
            var rightLineTop = Vec2.lerp(topRight, bottomRight, 0 / 3);
            var rightLineBottom = Vec2.lerp(topRight, bottomRight, areaReadIndex / 3);
            rightLine.attr("path", "M" + toFixedNumber(100 * rightLineTop.x, 2) + "," + toFixedNumber(-100 * rightLineTop.y, 2) + "L" + toFixedNumber(100 * rightLineBottom.x, 2) + "," + toFixedNumber(-100 * rightLineBottom.y, 2));
            var topLineLeft = Vec2.lerp(topLeft, topRight, 0 / 3);
            var topLineRight = Vec2.lerp(topLeft, topRight, areaReadIndex / 3);
            topLine.attr("path", "M" + toFixedNumber(100 * topLineLeft.x, 2) + "," + toFixedNumber(-100 * topLineLeft.y, 2) + "L" + toFixedNumber(100 * topLineRight.x, 2) + "," + toFixedNumber(-100 * topLineRight.y, 2));
            var bottomLineLeft = Vec2.lerp(bottomLeft, bottomRight, 0 / 3);
            var bottomLineRight = Vec2.lerp(bottomLeft, bottomRight, areaReadIndex / 3);
            bottomLine.attr("path", "M" + toFixedNumber(100 * bottomLineLeft.x, 2) + "," + toFixedNumber(-100 * bottomLineLeft.y, 2) + "L" + toFixedNumber(100 * bottomLineRight.x, 2) + "," + toFixedNumber(-100 * bottomLineRight.y, 2));
        }
        if (0 != (2 & this.dF)) {
            var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            highlight.attr({
                "stroke-opacity": void 0 != picked ? .85 : .0,
            });
            var fp = this.view.doc.floorplan;
            //var fillUrl = utilSnapAreaGetAreaMaterial(this);
            //fillUrl != style.attr("fill") && style.attr({
            //    fill: fillUrl
            //});
            var locked = utilModelIsFlagOn(fp, MODELFLAG_LOCKED) || this.model.cavern;
            style.attr({
                opacity: locked ? 1 : .5
            });

        }

        //add by hcw 区域标注线
        var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
            return e;
        });
        var picked = utilPickMgrIsPicked(this.view.app.pickMgr, model);
        if(void 0 != picked&&this.model.center!=void 0){
            //添加垂直，水平箭头拖拽 add by hcw 
            (utilModelIsFlagOn(model, MODELFLAG_HIDDEN) || this.model.cavern) ? "" : (createLabelLine(this), createArrowLine(this), createRectAreaArrow(this));
        }else{
            clearRectAreaArrow(this);
            utilModelIsFlagOn(model, MODELFLAG_HIDDEN) && (utilPickMgrUnpick(this.view.app.pickMgr, model),application.laberFrame()),!pickObjs_product[0] &&(application.laberFrame());
        }
    },
    destroy: function () {
        this.model.isdelete = 1;
        this.view.layers[this.model.type];
        this.de.forEach(function (ele) {
            ele.remove();
        });
        if(this.showDe.arrow){
            this.showDe.arrow.forEach(function (ele) {
                ele.remove();
            });
        }
        if (this.showDe.label) {
            application.laberFrame();
            this.showDe.label.forEach(function (ele) {
                ele.remove();
            });
        }
        //删除区域三角形
        if (this.showDe.moveArrow) {
            this.showDe.moveArrow.forEach(function (ele) {
                ele.remove();
            });
        };
        destroyArrowLine(this);
    }
})

function DisplayThreeFloorArea(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplayThreeFloorArea, DisplayObject);
utilExtend(DisplayThreeFloorArea.prototype, {
    create: function () {
        if (classBase(this, "create"), void 0 == this.de) {
            this.de = new THREE.Object3D();
            this.de.did = this.de.name = this.id;
            var area3d = utilThreeCreateArea(this);
            this.de.add(area3d);
        }
        this.view.layers[Area.prototype.type].add(this.de);
        var propertyChangedFun = function (propertyName, oldValue, newValue) {
            if("flag" == propertyName){ 
                (oldValue & AREAFLAG_CHANGED_FOR_REDRAWN) != (newValue & AREAFLAG_CHANGED_FOR_REDRAWN) && (this.dF |= 1);
                (oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 4);
              //this.dF |= 1;
            }else if ("paveType" == propertyName) {
                this.dF |= 1;
            }else if ("gapwidth" == propertyName ||
                        "gapcolor" == propertyName ||
                        "level" == propertyName) {
                this.dF |= 1;                
            }else if("cavern" == propertyName){
            	  //挖空刷新所有地面
            	  utilRedrawnAllFloor3D();
    					  this.dF |= 1;
    				}else if("height3d" == propertyName){
            	  this.dF |= 1;
            	  utilFloorplanUpdateWallAreaByWall(this.model);
            	  if(newValue < 0){
            	  	this.model.cavern = true;
            	  	utilRedrawnAllFloor3D();
            	  }else if(newValue >= 0){
            	  	this.model.cavern = false;            	  	
            	  }
    				}else {
                this.dF |= 1;
                utilFloorplanUpdateWallAreaByWall(this.model);
            }         
        }.bind(this);
        var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
            this.dF |= 1;
        }.bind(this);
        var linkPropertyChangedFun = function (changedLinkEntity, propertyName) {
            if(changedLinkEntity instanceof Point && ("x" == propertyName || "y" == propertyName)){
                this.dF |= 1;  
                utilFloorplanUpdateWallAreaByWall(this.model);             
            }
                                    
            if(changedLinkEntity instanceof Material){
                this.dF |= 1;
                this.dF |= 2;               
            }
        }.bind(this);
        this.model.propertyChangedEvent.add(propertyChangedFun);
        this.model.linksChangedEvent.add(linksChangedFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    /*TODO 产品，拼花读取图片跟踪,前面2个条件都会同时执行，图片会加载2次,两次
     * 0 != (1 & this.dF) 这个条件注释掉貌似无影响运行
     * TOFIX -add by oxl 2017-03-27*/
    update: function () {
          //重置铺砖        
        var view = this.view;
        var areaModel = this.model;
        var isNotCustomTile = !(areaModel && (areaModel.areaMaterial.category == "custom_tile" || areaModel.areaMaterial.category == "customparquet"));

        this.model.rebuild();
        if (0 != (1 & this.dF)) {
            this.de.remove(this.de.children[0]);
            var area3d = utilThreeCreateArea(this);
            if(areaModel.cavern && areaModel.height3d >= 0){
            	//隐藏
            }else{
            	var area3d = utilThreeCreateArea(this);
              this.de.add(area3d);
              this.de.position.z = this.model.z;
            }
            //this.custom_tile_update();
        }
        if (0 != (2 & this.dF) && isNotCustomTile) {
            //var mat = (areaModel.areaMaterial ? areaModel.areaMaterial.pid : DEFAULT_AREA_MATERIAL[areaModel.category],
            //    areaModel.areaMaterial);
            //var areaMeshMat = utilThreeViewCreateTileMaterial(view, mat, {});
            //var matScale = mat.getScale();
            //mat && (areaMeshMat.scUniform1 = [utilMathToRadius(-mat.rot), mat.tx, mat.ty, 0]);
            //areaMeshMat.scUniform2 = [matScale.x, matScale.y, 0, 0];
            //this.de.traverse(function (child) {
            //    "area" == child.name && (child.material = areaMeshMat);
            //});
            //
            //this.custom_tile_update();
        }
        if (0 != (4 & this.dF)) {
            var selected = utilModelIsFlagOn(this.model, MODELFLAG_PICKED);
            utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            this.de.traverse(function (child) {
                -1 != child.name.indexOf("highlight") && (child.visible = selected);
            });
        }
    },
    destroy: function () {
        this.view.layers[Area.prototype.type].remove(this.de);
    },
    custom_tile_update: function () {
        var areaModel = this.model;
        var mat = (areaModel.areaMaterial ? areaModel.areaMaterial.pid : DEFAULT_AREA_MATERIAL[areaModel.category],
            areaModel.areaMaterial);

        if (mat.category != "custom_tile" && mat.category != "customparquet")
            return;

        //根据rect大小,所放mat sx,sy
        switch (areaModel.type) {
            case RectArea.prototype.type:
                mat.sx = areaModel.width / mat.meta.xlen;
                mat.sy = areaModel.height / mat.meta.ylen;
                break;
            case RoundArea.prototype.type:
                mat.sx = areaModel.radius * 2 / mat.meta.xlen;
                mat.sy = areaModel.radius * 2 / mat.meta.ylen;
                break;
            case FreeArea.prototype.type:
                var loop = areaModel.getLoop();
                if (loop) {
                    var freeRect = null;
                    loop.forEach(function (point) {
                        if (freeRect) {
                            freeRect.l = Math.min(point.x, freeRect.l);
                            freeRect.r = Math.max(point.x, freeRect.r);
                            freeRect.t = Math.max(point.y, freeRect.t);
                            freeRect.b = Math.min(point.y, freeRect.b);
                        } else {
                            freeRect = {};
                            freeRect.l = point.x;
                            freeRect.r = point.x;
                            freeRect.t = point.y;
                            freeRect.b = point.y;
                        }
                    });
                    mat.sx = (freeRect.r - freeRect.l) / mat.meta.xlen;
                    mat.sy = (freeRect.t - freeRect.b) / mat.meta.ylen;
                }
                break;
        }
    }
});

function utilThreeCreateArea(areadisplay) {
    var view = areadisplay.view;
    var areaModel = areadisplay.model;
    var area3d = new THREE.Object3D();
    
    //创建root砖缝用
    var centerProfile = areaModel.getLoop();
    if (!centerProfile || centerProfile.length < 4) 
        return area3d;
        
    var mat = areaModel.areaMaterial;
    //var floorMeshMat = utilThreeViewCreatePaveTileMaterial(view, mat, {}); 
    var zBias = (mat ? mat.pid : DEFAULT_AREA_MATERIAL[areaModel.category], areaModel.category == AREA_INNER_CATEGORY_ID ? 0 : -.002);
    var areaOffset = 4e-5 * (areaModel.level + 1) + zBias;
    
    var rootProfile = centerProfile;
    var rootShape = new THREE.Shape(rootProfile);
    var rootGeom = rootShape.makeGeometry();
    var rootMeshMat = utilThreeViewCreateTileMaterial(view, areaModel.rootMaterial, {});
    var rootMesh = new THREE.Mesh(rootGeom, rootMeshMat);
    rootMesh.position.set(0, 0, areaOffset - (2e-5) + areaModel.height3d);
    rootMesh.name = "root";
    area3d.add(rootMesh);
    
    //地面
    var clipperFactor = 10000.0;//clipper缩放因子
    var gap = areaModel.gapwidth;  //砖缝
    var cpr = new ClipperLib.Clipper();
    var floorRectOrigin = areaModel.floorRectOrigin;
    var singlepaveRot = areaModel.singlepaveRot;
    var isSquare = areaModel.isSquare;
    
    //初始化
    if(areaModel.floorRectTiles){
      var areaMeshMat = utilThreeViewCreatePaveTileMaterial(view, areaModel.areaMaterial, {});
          var paveMeshMats = [];
          var paveGeoms    = [new THREE.Geometry()]; //对应的geom
          for(var i=0;i<10;++i){
              areaModel["pave"+i+"Material"] && (paveMeshMats[i] = utilThreeViewCreatePaveTileMaterial(view, areaModel["pave"+i+"Material"], {}), paveGeoms[i + 1] = new THREE.Geometry());                
          }
          
      areaModel.floorRectTiles.forEach(function(frTile){
          if(frTile.type == "group"){ //组类型不显示                    
          return;
        }
        
          var tileProfile = frTile.tileProfile;       
              if(tileProfile){
                  tileProfile.forEach(function(subProfile){
                      var pos = frTile.pos;
                  var origin = frTile.origin;
                  var subTileProfiles = utilAdaptorClipperOffsetArray(subProfile, -gap*0.5);
                  subTileProfiles && subTileProfiles.forEach(function(subTileProfile){
                      subTileProfile = subTileProfile.map(function(t){                                 
                                //偏移到原点，并补充砖缝偏移       
                                var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                oT = {x:oT.x - origin.x, y:oT.y - origin.y};
                                
                                if(frTile.rot){
                                  var x = frTile.rot.x != null ? frTile.rot.x*frTile.paveW : 0;
                              var y = frTile.rot.y != null ? frTile.rot.y*frTile.paveH : 0;
                              var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.paveH : 0;
                              var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.paveW : 0;
                              oT = {x:oT.x - x - hx, y:oT.y - y - wy};
                              oT = utilMathRotatePointCW({x:0,y:0}, oT, -frTile.rot.r);
                                }
                                
                                return oT;
                          });
                                              
                          var mrot = 0;
                          //铺贴模板固定铺砖朝向
                          switch(frTile.dir){
                              case 1:
                                mrot = 0;
                              break;
                              case 2:
                                mrot = 90;
                              break;
                              case 3:
                                mrot = 180;
                              break;
                              case 4:
                                mrot = 270;
                              break;
                          }               
                          
                          var mrotCenter = {x:frTile.paveW*0.5, y:frTile.paveH*0.5};
                          if(mrot != 0){
                              //进行随机旋转
                              subTileProfile = subTileProfile.map(function(t){                               
                                return utilMathRotatePointCW(mrotCenter, t, -mrot);
                              });
                          }
                          
                          subTileProfile = subTileProfile.map(function(t){                               
                              //选砖                                               
                              return {x:t.x + frTile.tileIndex.th * frTile.paveW,
                                      y:t.y + frTile.tileIndex.tv * frTile.paveH};
                          });
                      
                          var floorShape = new THREE.Shape(subTileProfile);
                      var floorGeom = floorShape.makeGeometry();
                      var vertexMin = {x: 1e3,y: 1e3};
                      for (var i = 0, len = floorGeom.vertices.length; len > i; ++i) {
                          var vertex = floorGeom.vertices[i];
                          //vertexMin.x = Math.min(vertexMin.x, vertex.x);
                          //vertexMin.y = Math.min(vertexMin.y, vertex.y);
                          
                          vertex.x -= frTile.tileIndex.th * frTile.paveW;
                                  vertex.y -= frTile.tileIndex.tv * frTile.paveH;
                          
                          if(mrot != 0){
                              var v = utilMathRotatePointCW(mrotCenter, vertex, mrot);
                              vertex.x = v.x;
                              vertex.y = v.y;
                            }
                            
                            if(frTile.rot){
                              var x = frTile.rot.x != null ? frTile.rot.x*frTile.paveW : 0;
                              var y = frTile.rot.y != null ? frTile.rot.y*frTile.paveH : 0;
                              var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.paveH : 0;
                              var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.paveW : 0;
                               
                              var v = utilMathRotatePointCW({x:0,y:0}, vertex, frTile.rot.r);
                              vertex.x = v.x + x + hx;
                              vertex.y = v.y + y + wy;                        
                          }
                          
                          //vertex.x += origin.x + gap*0.5; vertex.y += origin.y + gap*0.5; //真砖缝
                          vertex.x += origin.x; vertex.y += origin.y; //假砖缝
                          var v = utilMathRotatePointCW({x:floorRectOrigin.x, y:floorRectOrigin.y}, vertex, singlepaveRot);
                          vertex.x = v.x;
                          vertex.y = v.y;
                      }
                      
                      //进行纹理缩放
                      floorGeom.faceVertexUvs[0].forEach(function (uvs) {
                          Array.isArray(uvs) && uvs.forEach(function (uv) {
                              //uv.x -= vertexMin.x,
                              //uv.y -= vertexMin.y;
                              uv.x /= mat.sx;
                              uv.y /= mat.sy;
                          });
                      });
                      
                      var paveGeom = paveGeoms[0];
                      (frTile.pidIndex != null) && (paveGeom = paveGeoms[frTile.pidIndex + 1]);
                      if(paveGeom){
                          utilMergeGeom(floorGeom, paveGeom);
                      }
                    });
                  });
                  
              }   
      });
      
      paveGeoms.forEach(function(geom, index){
          var meshMat = areaMeshMat;
          (parseInt(index) > 0) && (meshMat = paveMeshMats[parseInt(index) - 1]);
          
          var areaMesh = new THREE.Mesh(geom, meshMat);
          areaMesh.position.set(0, 0, areaOffset + areaModel.height3d); //mond 不精确的areaOffset
          areaMesh.name = (parseInt(index) > 0) ? ("pave" + (parseInt(index) - 1)) : "area";                      
          area3d.add(areaMesh);
      });
    }
    
    //高亮区
    var highlightShape = new THREE.Shape(rootProfile);
    var highlightGeom = highlightShape.makeGeometry();    
    var highlightMat = new THREE.MeshBasicMaterial({
        color: 15790144,
        transparent: !0,
        opacity: .15
    });
    var areaOutline = new THREE.Mesh(highlightGeom, highlightMat);
    areaOutline.position.set(0, 0, areaOffset + (2e-5) + areaModel.height3d);
    areaOutline.updateMatrix();
    areaOutline.name = "area_highlight";
    areaOutline.visible = utilModelIsFlagOn(areaModel, MODELFLAG_PICKED);
    areaOutline.raycastable = !1;
    area3d.add(areaOutline);
    
    //绘制侧面
    var defaultMeshMat = utilThreeViewCreateTileMaterial(view, void 0, {});
    if(areaModel.height3d > 0){
  		if(!areaModel["side0Boards"]){
    		for(var i=0;i<rootProfile.length-1;++i){
			    !areaModel["side" + i + "Boards"] && (areaModel["side" + i + "Boards"] = []);
			  }
			  areaModel.profileNum = rootProfile.length;
			}
    	
    	if(utilMathPolyIsClockWise(rootProfile)){
    		for(var i = 0, len = rootProfile.length - 1;i < len;++i){    		
	    		var wallHeight3d = areaModel.height3d;
	    		var openings = [];
	    		var line = [rootProfile[i], rootProfile[i + 1]];
	    		var leftBuiltData = utilThreeExtrude2dline(line, wallHeight3d, openings);
			    var wall = utilThreeTurn2DWallBuiltDataToSideWall(leftBuiltData, "side" + i, highlightMat, defaultMeshMat);
			    area3d.add(wall);
	    	}
    	}else{
    		for(var i = rootProfile.length - 1;i > 0;--i){
	    		var wallHeight3d = areaModel.height3d;
	    		var openings = [];
	    		var line = [rootProfile[i], rootProfile[i - 1]];
	    		var leftBuiltData = utilThreeExtrude2dline(line, wallHeight3d, openings);
			    var wall = utilThreeTurn2DWallBuiltDataToSideWall(leftBuiltData, "side" + (i - 1), highlightMat, defaultMeshMat);
			    area3d.add(wall);
	    	}
    	}
    }else if(areaModel.height3d < 0){
    	if(!areaModel["side0Boards"]){
    		for(var i=0;i<rootProfile.length-1;++i){
			    !areaModel["side" + i + "Boards"] && (areaModel["side" + i + "Boards"] = []);
			  }
			  areaModel.profileNum = rootProfile.length;
			}
    	
    	if(!utilMathPolyIsClockWise(rootProfile)){
    		for(var i = 0, len = rootProfile.length - 1;i < len;++i){    		
	    		var wallHeight3d = Math.abs(areaModel.height3d);
	    		var openings = [];
	    		var line = [rootProfile[i], rootProfile[i + 1]];
	    		var leftBuiltData = utilThreeExtrude2dline(line, wallHeight3d, openings);
			    var wall = utilThreeTurn2DWallBuiltDataToSideWall(leftBuiltData, "side" + i, highlightMat, defaultMeshMat);
			    wall.position.z = areaModel.height3d;
			    area3d.add(wall);
	    	}
    	}else{
    		for(var i = rootProfile.length - 1;i > 0;--i){
	    		var wallHeight3d = Math.abs(areaModel.height3d);
	    		var openings = [];
	    		var line = [rootProfile[i], rootProfile[i - 1]];
	    		var leftBuiltData = utilThreeExtrude2dline(line, wallHeight3d, openings);
			    var wall = utilThreeTurn2DWallBuiltDataToSideWall(leftBuiltData, "side" + (i - 1), highlightMat, defaultMeshMat);
			    wall.position.z = areaModel.height3d;
			    area3d.add(wall);
	    	}
    	}
    }
    
    //绘制底部
    if(areaModel.height3d > 0){
    	//bottom
    	rootGeom.faces.forEach(function (f) {
	        var b = f.b;
	        f.b = f.c, f.c = b;
	    });
	    rootGeom.computeFaceNormals();
    	var bottomMesh = new THREE.Mesh(rootGeom, defaultMeshMat);
	    bottomMesh.position.set(0, 0, 0);
	    bottomMesh.name = "bottom";
	    area3d.add(bottomMesh);	    
	    
	    var bottomMeshOutline = new THREE.Mesh(rootGeom, highlightMat);
	    bottomMeshOutline.position.set(0, 0, -(2e-5));
	    bottomMeshOutline.name = "bottom_highlight";
	    area3d.add(bottomMeshOutline);
    }
    
    return area3d;
}
// sourceURL=src\display\area\rectarea.js