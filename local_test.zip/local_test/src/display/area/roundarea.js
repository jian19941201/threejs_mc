function DisplaySnapRoundArea(modelObject, view) {
    classBase(this, modelObject, view), this.de = [];
}

classInherit(DisplaySnapRoundArea, DisplaySnapArea);
utilExtend(DisplaySnapRoundArea.prototype, {
    create: function () {
        classBase(this, "create");
        var roundObj=this;
        this.showDe = {arrow: [], label: [], moveArrow: []}; //moveArrow用来记录
        var context = this.view.context, view = this.view, model = this.model, layer = this.view.layers[this.model.category], fillUrl = utilSnapAreaGetAreaMaterial(this), fp = this.view.doc.floorplan, app = application, actionMgr = this.view.app.actionMgr;
        var pickMgr=this.view.app.pickMgr;
        this.model.textpos=[], this.model.isdelete=0;;
        if (this.de.length > 0 && 0 == layer.node.hasChildNodes(this.de[0])) return void layer.add(this.de);
        //var style = context.circle().attr({
        //    fill: fillUrl,
        //    stroke: "#2020e0",
        //    "stroke-width": 0,
        //    "stroke-opacity": 1,
        //    "stroke-linejoin": "round",
        //    opacity: utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? 1 : .4,
        //    did: this.id
        //}),
        
        this.model.rebuild();
        var style = context.g().attr({
        	opacity: (utilModelIsFlagOn(fp, MODELFLAG_LOCKED)||this.model.cavern) ? 1 : .4,
        	did:this.id
        });
        style.add(utilFloorCreateSnapStyles(this));
        
        var highlight = context.circle().attr({
            fill: "green",
            "fill-opacity": .0,
            "stroke":"#49fffe",
            "stroke-opacity": .0,
            "stroke-width": 3
        }).drag(function (dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button && !(utilAppFloorplanIsLocked(app)||this.model.cavern)) {
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
                actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, modelOffset, modelOffset));
            }
        }, function (x, y, e) {
            if (e.stopPropagation(), 1 != e.button) {
                this._modelCenter = {
                    x: this.model.center.x,
                    y: this.model.center.y
                };
                var model = this.model;
                if (!actionMgr.current) {
                    var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveArea.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                    utilActionBegin(actionMgr, actionType, actionModel, {
                        shiftKey: e.shiftKey
                    });
                }
            }
        }, function (e) {
            e.stopPropagation(), 1 != e.button && (delete this._modelCenter, actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionEnd(actionMgr),
                areaCenter.attr({
                    opacity: 0
                })));
        }, this, this, this), circleCursors = ["ew-resize", "nesw-resize", "ns-resize", "nwse-resize"], arc = context.circle().attr({
            stroke: "#000",
            "stroke-opacity": 0,
            fill: "none",
            "stroke-width": 6
        }).mousemove(function (e, x, y) {
            var center = model.center;
            var mouse = utilSvgScreenSpaceToModelSpace(view, x, y);
            var angle = 180 * Math.atan2(mouse.y - center.y, mouse.x - center.x) / Math.PI;
            angle = Math.floor(Math.round(angle + 360 + 22.5) % 360 / 45) % 4, this.attr("cursor", circleCursors[angle]);

        }).drag(function (dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button && !(utilAppFloorplanIsLocked(app)||this.model.cavern)) {
                var modelOffset = utilSvgScreenSpaceToModelSpace(view, x, y);
                this.model.radius = Vec2.difference(modelOffset, this._modelCenter).magnitude();
                this.model.group && utilModelChangeFlag(this.model.group, GROUPFLAG_VIEW_UPDATE);
            }
        }, function (x, y, e) {
            e.stopPropagation(), this._modelCenter = {
                x: this.model.center.x,
                y: this.model.center.y
            };
        }, function (e) {
            e.stopPropagation(), delete this._modelCenter;
        }, this, this, this), areaCenter = context.circle(null, null, 5).attr({
            fill: "#F02012",
            "stroke-width": 0,
            opacity: 0
        });

        this.de = [style, highlight, arc, areaCenter];
        layer.add(this.de);
        var updateFun = function (propertyName, oldValue, newValue) {
            if(propertyName instanceof Material){
            	if(!("rot" != oldValue && "tx" != oldValue && "ty" != oldValue && "sx" != oldValue && "sy" != oldValue)){
            		this.dF |= 2,this.dF |= 1,this.model.paveRebuild = true;
            	}
            }else if("flag" == propertyName || "areaMaterial" == propertyName){
              (oldValue & AREAFLAG_CHANGED_FOR_REDRAWN) != (newValue & AREAFLAG_CHANGED_FOR_REDRAWN) && (this.dF |= 1,this.model.paveRebuild = true);
              (oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 2);
              (oldValue & MODELFLAG_LOCKED) != (newValue & MODELFLAG_LOCKED) && (this.dF |= 2);
            }else if("level" == propertyName){
            	this.dF |= 8;
            }else{
            	this.dF |= 1;
            	this.model.paveRebuild = true;
            }
        }.bind(this);
        var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
            if(changeFrom instanceof Material){
            	this.dF |= 1;
	            this.dF |= 2;
	            this.model.paveRebuild = true;
	            
            	changeFrom.ignoreUV = true;
            	this.model.clearPaveDB();
            }
        }.bind(this);        
        var linkPropertyChangedFun = function(propertyName, linksOp, changeFrom, changeTo) {
        	  this.dF |= 1;
        	  this.model.paveRebuild = true;
        }.bind(this);
        
        this.model.propertyChangedEvent.add(updateFun);
        this.model.linksChangedEvent.add(linksChangedFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    update: function () {
    	  //重置铺砖        
        var style = this.de[0];
        var highlight = this.de[1];
        var arc = this.de[2];
        var model = this.model;
        (this.showDe.label && this.showDe.label.length>0)? (this.showDe.label[0].attr("display", "none"),this.showDe.label[1].attr("display", "none"),this.showDe.label[2].attr("display", "none"),this.showDe.label[3].attr("display", "none")):"";
        (this.showDe.arrow && this.showDe.arrow.length > 0) ? (
            this.showDe.arrow.forEach(function (a) {
                a.attr("display", "none")
            })) : "";
        this.de[3],this.model.textpos=[];
        
        this.model.rebuild();      
        if( 0 != (1 & this.dF)){
        	  style.clear();
        	  style.add(utilFloorCreateSnapStyles(this));
        }
        if (0 != (8 & this.dF) && utilSnapAreaLevelUpdated(this.view, this.model), 0 != (1 & this.dF)) {
            if (!this.model || !this.model.center) 
                return;
            if( isNaN(this.model.center.x) || isNaN(this.model.center.y))
                return;
            var attr = {
                cx: 100 * this.model.center.x,
                cy: -100 * this.model.center.y,
                r: 100 * this.model.radius
            };
            style.attr(attr);
            highlight.attr(attr);
            arc.attr(attr);
            //utilSnapAreaGetAreaMaterial(this);
        }
        if (0 != (2 & this.dF)) {
            var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            highlight.attr({
                "stroke-opacity": void 0 != picked ? .85 : .0
            });
            var fp = this.view.doc.floorplan;
            //var fillUrl = utilSnapAreaGetAreaMaterial(this);
            //fillUrl != style.attr("fill") && style.attr({
            //    fill: fillUrl
            //});
            style.attr({
                opacity: (utilModelIsFlagOn(fp, MODELFLAG_LOCKED)||this.model.cavern) ? 1 : .5
            });
        }

        //add by hcw 区域标注线        
        var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
            return e;
        });
        var picked = utilPickMgrIsPicked(this.view.app.pickMgr, model);
        if(void 0 != picked && this.model.center!=void 0 && !this.model.cavern){
            //添加垂直，水平箭头拖拽 add by hcw
            utilModelIsFlagOn(model, MODELFLAG_HIDDEN)?"":createLabelLine(this),createArrowLine(this),createRectAreaArrow(this);

        }else{
            clearRectAreaArrow(this);
            utilModelIsFlagOn(model, MODELFLAG_HIDDEN) && (utilPickMgrUnpick(this.view.app.pickMgr, model),application.laberFrame()),!pickObjs_product[0] && (application.laberFrame())
        }
    },
    destroy: function () {
        this.model.isdelete=1;
        this.view.layers[this.model.type];
        this.de.forEach(function (ele) {
            ele.remove();
        });
        if(this.showDe.arrow){
	        this.showDe.arrow.forEach(function (ele) {
	            ele.remove();
	        });
	      }
        if(this.showDe.label){
            application.laberFrame()
            this.showDe.label.forEach(function (ele) {
                ele.remove();
            });
        }
        //删除区域三角形
        if (this.showDe.moveArrow) {
            this.showDe.moveArrow.forEach(function (ele) {
                ele.remove();
            });
        };
        destroyArrowLine(this);
    }
});

//# sourceURL=src\display\area\roundarea.js