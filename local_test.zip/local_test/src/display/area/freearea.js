function DisplaySnapFreeArea(modelObject, view) {
    classBase(this, modelObject, view), this.offset = 0;
}

classInherit(DisplaySnapFreeArea, DisplaySnapArea);
utilExtend(DisplaySnapFreeArea.prototype, {
    create: function () {
        classBase(this, "create");
        var freeObj=this;
        this.showDe={arrow:[]};
        var actionMgr = this.view.app.actionMgr;
        var context = this.view.context;
        var pickMgr=this.view.app.pickMgr;
        var model=this.model,view = this.view;
        var layer = this.view.layers[this.model.category];
        var path = utilSnapAreaCreatePathString(this.model, this.offset);
        //var fillUrl = utilSnapAreaGetAreaMaterial(this);
        var fp = this.view.doc.floorplan;
        var app = application;
        this.model.isdelete=0;
        //var style = context.path(path).attr({
        //    fill: fillUrl,
        //    stroke: "#707070",
        //    "stroke-width": 2,
        //    "stroke-opacity": 1,
        //    "stroke-linejoin": "round",
        //    opacity: utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? 1 : .4,
        //    did: this.id
        //});
        this.model.rebuild();
        var style = context.g().attr({
        	opacity: (utilModelIsFlagOn(fp, MODELFLAG_LOCKED)||this.model.cavern) ? 1 : .4,
        	did:this.id
        });
        style.add(utilFloorCreateSnapStyles(this));
        
        var highlight = context.path(path).attr({
            fill: "#fff",
            "fill-opacity": .0,
            "stroke": "#ffe400",
            "stroke-opacity": 1,
            "stroke-width": 2
        }).drag(function (dx, dy, x, y, e) {
            if (e.stopPropagation(), 1 != e.button && !(utilAppFloorplanIsLocked(app)||this.model.cavern)) {
            	  if(e.buttons && e.buttons == 1){
	                var offset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
	                for (var id in this._modelPos) {
	                    var pos = this._modelPos[id];
	                    pos.m.x = pos.x + offset.x, pos.m.y = pos.y + offset.y;
	                }
	                this.dF |= 1;
	                utilModelChangeFlag(this.model, AREAFLAG_CHANGED_FOR_REDRAWN);
	              }
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy);
                actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionRun(actionMgr, e.type + "2d", e, modelOffset, modelOffset));
            }
        }, function (x, y, e) {
            if (e.stopPropagation(), 1 != e.button) {
                var profile = this.model.profile, pos = this._modelPos = {};
                profile.forEach(function (curve) {
                    var begin = curve.begin, end = curve.end;
                    pos[begin.id] = {
                        m: begin,
                        x: begin.x,
                        y: begin.y
                    }, pos[end.id] = {
                        m: end,
                        x: end.x,
                        y: end.y
                    };
                });
                if (!actionMgr.current) {
                    var actionType = model.group && utilModelIsFlagOff(model.group, GROUPFLAG_OPENED) ? ActionMoveGroup.prototype.type : ActionMoveArea.prototype.type, actionModel = actionType == ActionMoveGroup.prototype.type ? model.group.group || model.group : model;
                    utilActionBegin(actionMgr, actionType, actionModel, {
                        shiftKey: e.shiftKey
                    });
                }
            }
        }, function (e) {
            e.stopPropagation(), 1 != e.button && (delete this._modelPos,actionMgr.current && (actionMgr.current.type != ActionMoveGroup.prototype.type && actionMgr.current.type != ActionMoveArea.prototype.type || utilActionEnd(actionMgr)));
        }, this, this, this);
        
        //用于绘制边缘
        var border = context.g();        
        this.de = [style, highlight, border];        
        layer.add(this.de);
        
        var updateFun = function (propertyName, oldValue, newValue) {
           if(propertyName instanceof Material){
            	if(!("rot" != oldValue && "tx" != oldValue && "ty" != oldValue && "sx" != oldValue && "sy" != oldValue)){
            		this.dF |= 2,this.dF |= 1,this.model.paveRebuild = true;
            	}
            }else if("flag" == propertyName || "areaMaterial" == propertyName){
              (oldValue & AREAFLAG_CHANGED_FOR_REDRAWN) != (newValue & AREAFLAG_CHANGED_FOR_REDRAWN) && (this.dF |= 1,this.model.paveRebuild = true);
              (oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 2);
              (oldValue & MODELFLAG_LOCKED) != (newValue & MODELFLAG_LOCKED) && (this.dF |= 2);
            }else if("level" == propertyName){
            	this.dF |= 8;
            }else if("cavern" == propertyName){
            	var cavern = this.model.cavern;
            	this.model.profile && this.model.profile.forEach(function(curve){
            		if(curve.begin){
            		  cavern ? utilModelSetFlagOn(curve.begin, POINT_CHANGED_FOR_FROZEN) : utilModelSetFlagOff(curve.begin, POINT_CHANGED_FOR_FROZEN);
            		}
            		if(curve.end){
            		  cavern ? utilModelSetFlagOn(curve.end, POINT_CHANGED_FOR_FROZEN) : utilModelSetFlagOff(curve.end, POINT_CHANGED_FOR_FROZEN);
            		}
            	});
            	this.dF |= 1;
            }else{
            	this.dF |= 1;
            	this.model.paveRebuild = true;
            }
        }.bind(this);
        var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
            if(changeFrom instanceof Material){
            	this.dF |= 1;
	            this.dF |= 2;
	            this.model.paveRebuild = true;
	            
            	changeFrom.ignoreUV = true;
            	this.model.clearPaveDB();
            }
        }.bind(this);        
        var linkPropertyChangedFun = function(propertyName, linksOp, changeFrom, changeTo) {
        	  this.dF |= 1;
        	  this.model.paveRebuild = true;
        }.bind(this);
        
        this.model.propertyChangedEvent.add(updateFun);
        this.model.linksChangedEvent.add(linksChangedFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    update: function () {
    	  //重置铺砖        
        var style = this.de[0];
        var highlight = this.de[1];
        var border = this.de[2];
        var model=this.model;
        (this.showDe.arrow && this.showDe.arrow.length > 0) ? (
            this.showDe.arrow.forEach(function (a) {
                a.attr("display", "none")
            })) : "";
        
        var context = this.view.context;
        var fp = this.view.doc.floorplan;
        var app = application;
        
        this.model.rebuild();        
        if( 0 != (1 & this.dF)){
        	  style.clear();
        	  style.add(utilFloorCreateSnapStyles(this));
        }
        
        if( 0 != (1 & this.dF)){        
            var path = utilSnapAreaCreatePathString(this.model, this.offset);
            //path != style.attr("path") && (style.attr({
            //    path: path
            //}),
            path != style.attr("path") && (highlight.attr({
                path: path
            })); 
            //utilSnapAreaGetAreaMaterial(this);
            
            border.clear();
            var borderLine = [];
            this.model.profile.forEach(function (curve, i) {
                if (curve) {
                    var factor = 100;
                    var begin = curve.begin;
                    var end = curve.end;
                    if (begin && end && (!isNaN(end.x) && !isNaN(end.y))) {
                        var svgString = "M" + Math.round(begin.x * factor) + "," + Math.round(-begin.y * factor) + "L" + Math.round(end.x * factor) + "," + Math.round(-end.y * factor);
                        //var border = this.de[2 + i];
                        //border.attr("path") != svgString && border.attr({
                        //    path: svgString
                        //});
                        var l = context.path("").attr({
                                stroke: "#9090b0",
                                "stroke-width": 2,
                                "stroke-opacity": (utilModelIsFlagOn(fp, MODELFLAG_LOCKED)||this.model.cavern) ? 0 : .4,
                                "stroke-linejoin": "round",
                                opacity: (utilModelIsFlagOn(fp, MODELFLAG_LOCKED)||this.model.cavern) ? 0 : .4,
                                path: svgString
                            });
                            borderLine.push(l);
                    }
                }
            }, this);
            border.add(borderLine);
        }
        if (0 != (2 & this.dF)) {
            var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            highlight.attr({
                "stroke-opacity": void 0 != picked ? .85 : .0
            });
            var fp = this.view.doc.floorplan;
            //var fillUrl = utilSnapAreaGetAreaMaterial(this);
            //fillUrl != style.attr("fill") && style.attr({
            //    fill: fillUrl
            //});
            var locked = (utilModelIsFlagOn(fp, MODELFLAG_LOCKED)||this.model.cavern);
            style.attr({
                opacity: locked ? 1 : .4
            });
        }
        if (0 != (8 & this.dF) && utilSnapAreaLevelUpdated(this.view, this.model)){
        }
        //添加垂直，水平箭头拖拽 add by hcw
        var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
        if(picked && !this.model.cavern){
            if(model.profile.length<3)return
            //添加垂直，水平箭头拖拽 add by hcw
            createArrowLine(this);
        }
    },
    destroy: function () {
        this.model.isdelete=1;
        this.view.layers[this.model.type];
        this.de.forEach(function (ele) {
            ele.remove();
        });
        if(this.showDe.arrow){
            this.showDe.arrow.forEach(function (ele) {
                ele.remove();
            });
        }
        destroyArrowLine(this);
    }
});

//# sourceURL=src\display\area\freearea.js