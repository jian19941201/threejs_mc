/*
 DisplaySnapWall
 */
function DisplaySnapWall(modelObject, view) {
    classBase(this, modelObject, view);
}

function utilSnapWallCreateLoopString(wall, isSimplified) {	
  	var wallTessellate = utilModelWallGetTessellates(wall, isSimplified);
    if (void 0 == wallTessellate)
        return "";
    __assert(Array.isArray(wallTessellate) && 7 == wallTessellate.length);
    var svgString = "";
    var geom = wallTessellate;
    var factor = 100;
    if(wall.bezier && geom.length == 9){
    	var bezierGeom = [];
    	bezierGeom.push(geom[0]);bezierGeom.push(geom[1]);    	
    	for(var i=0;i<geom[7].length;++i){
    		bezierGeom.push(geom[7][i]);
    	}
    	bezierGeom.push(geom[2]);bezierGeom.push(geom[3]);bezierGeom.push(geom[4]);
    	for(var i=0;i<geom[8].length;++i){
    		bezierGeom.push(geom[8][i]);
    	}
    	bezierGeom.push(geom[5]);
    	bezierGeom.push(geom[6]);    	
    	
    	for (var i = 0; bezierGeom.length > i; ++i) {
        var pt = bezierGeom[i];
        __assert(!isNaN(pt.x) && !isNaN(pt.y));
        svgString += (0 == i ? "M" : "L") + (pt.x * factor) + "," + (-pt.y * factor);
      }
    }else{
    	for (var i = 0; geom.length > i; ++i) {
        var pt = geom[i];
        __assert(!isNaN(pt.x) && !isNaN(pt.y));
        svgString += (0 == i ? "M" : "L") + (pt.x * factor) + "," + (-pt.y * factor);
      }
    }
    
    return svgString += "Z";    
}

classInherit(DisplaySnapWall, DisplayWall), utilExtend(DisplaySnapWall.prototype, {
    create: function () {
        classBase(this, "create");
        var context = this.view.context, layer = this.view.layers[this.model.type], actionMgr = this.view.app.actionMgr, isLoadBearing = utilModelIsFlagOn(this.model, WALLFLAG_LOAD_BEARING);
        if (context) {
            var line = context.path().attr({
                stroke: "#707070",
                "stroke-width": 0,
                "stroke-opacity": 1,
                "stroke-linejoin": "round"
            }), style = context.path().attr({
                fill: isLoadBearing ? "#202020" : "#cccccc",
                stroke: "#707070",
                "stroke-width": 0.5,
                "stroke-opacity": 1,
                "stroke-linejoin": "round",
                "fill-opacity": 1,
                did: this.id
            }), highlight = context.path().attr({
                fill: "#FEBE39",
                "fill-opacity": .0,
                "stroke":"#FEBE39",
                "stroke-opacity": .0,
                "stroke-width": 2,
                cursor: 'url(asset/imgSnap/wallhCursor.png) 7 20,move'
            }), lLine = context.path().attr({
						    "stroke-width": 1,
						    "fill":"none",
						    stroke: "#68B4ff"
						}), rLine = context.path().attr({
						    "stroke-width": 1,
						    "fill":"none",
						    stroke: "#68B4ff"
						});
            this.de = [line, style, highlight, lLine, rLine], layer.add(this.de);
            var dimLayer = this.view.layers[SNAP_LAYER_IN_DIMENSION];//墙中线标尺
            if (dimLayer) {
                var dimText = context.text().attr({  //标尺字体
                    stroke: "none",
                    "font-size": 20,
                    fill: "#5f5f5f",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "text-anchor": "middle"
                }), dimLine = context.path().attr({  //标尺
                    fill: "none",
                    stroke: "#5f5f5f",
                    "stroke-width": 1
                });
                this.de.push(dimLine, dimText), dimLayer.add([dimLine, dimText]);
            }

            //start add by gaoning 2017.8.10  内墙线标尺
            var innerDimLayer = this.view.layers[SNAP_LAYER_IN_DIMENSION_INNER];
            if (innerDimLayer) {
                var dimText = context.text().attr({  //标尺字体
                    stroke: "none",
                    "font-size": 20,
                    fill: "#5f5f5f",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "text-anchor": "middle"
                }), dimLine = context.path().attr({  //标尺
                    fill: "none",
                    stroke: "#5f5f5f",
                    "stroke-width": 1
                });
                this.de.push(dimLine, dimText), innerDimLayer.add([dimLine, dimText]);
            }
            //第二条线
            var innerDimLayer2 = this.view.layers[SNAP_LAYER_IN_DIMENSION_INNER];
            if (innerDimLayer2) {
                var dimText = context.text().attr({  //标尺字体
                    stroke: "none",
                    "font-size": 20,
                    fill: "#5f5f5f",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "text-anchor": "middle"
                }), dimLine = context.path().attr({  //标尺
                    fill: "none",
                    stroke: "#5f5f5f",
                    "stroke-width": 1
                });
                this.de.push(dimLine, dimText), innerDimLayer2.add([dimLine, dimText]);
            }
            //end

            var updateFun = function (propertyName, oldValue, newValue) {
                if ("transparent" == propertyName) {
                    this.dF |= 16;
                } else if ("flag" == propertyName) {
                    if (utilModelIsFlagOn(this.model, WALLFLAG_DETAILEDUPDATED_2D)) {
                        this.dF |= 1;
                    } else if ((oldValue & MODELFLAG_HIDDEN) != (newValue & MODELFLAG_HIDDEN)) {
                        this.dF |= 4;
                    } else if ((oldValue & WALLFLAG_LOAD_BEARING) != (newValue & WALLFLAG_LOAD_BEARING)) {
                        this.dF |= 8;
                    } else {
                        this.dF |= 2;
                    }
                } else {
                    "leftMaterial" != propertyName &&
                    "rightMaterial" != propertyName &&
                    "side0Material" != propertyName &&
                    "side1Material" != propertyName &&
                    "side2Material" != propertyName &&
                    "side3Material" != propertyName &&
                    "stoneMaterial" != propertyName || (utilModelSetFlagOn(this.model, WALLFLAG_DETAILEDUPDATED_2D),
                        this.dF |= 1);
                }
            }.bind(this);

            var linkPropertyChanged = function () {
                utilModelSetFlagOn(this.model, WALLFLAG_DETAILEDUPDATED_2D), this.dF |= 1;
            }.bind(this);

            this.model.propertyChangedEvent.add(updateFun);
            this.model.linksChangedEvent.add(updateFun);
            this.model.linkPropertyChangedEvent.add(linkPropertyChanged);

            var touchHandler = function (e, a0, a1, a2) {
                if (e.stopPropagation(), e.touches) {
                    var touch = e.touches[0];
                    if (__log("wall:" + e.type), "touchstart" == e.type) {
                        if (utilActionBegin(actionMgr, ActionMoveWall.prototype.type, this.model), !touch || 1 != e.touches.length) return;
                        this._touchpos = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY);
                    } else if ("touchmove" == e.type) {
                        if (e.stopPropagation(), !touch || 1 != e.touches.length) return;
                        var modelPt = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY), offset = {
                            x: modelPt.x - this._touchpos.x,
                            y: modelPt.y - this._touchpos.y
                        };
                        utilActionRun(actionMgr, e.type, e, offset);
                    } else "touchend" == e.type && (utilActionEnd(actionMgr, ActionMoveWall.prototype.type),
                        delete this._touchpos);
                }
            }.bind(this);
            var clickHandler = function (e) {
                e.stopPropagation();
            }.bind(this);
            highlight.click(clickHandler).mouseover(function (e) {
            }).mouseout(function (e) {
            }).drag(function (dx, dy, x, y, e) {
                if (e.stopPropagation(), e instanceof Event && 1 != e.button) {
                    var modelOffset = utilSvgVectorScreenSpaceToModelSpace(this.view, dx, dy);
                    !this._dragBegin && (Math.abs(dx) > 1 || Math.abs(dy) > 1) && (utilActionBegin(actionMgr, ActionMoveWall.prototype.type, this.model),
                        this._dragBegin = !0), utilActionRun(actionMgr, "dragmove", e, {
                        x: modelOffset.x,
                        y: modelOffset.y
                    });
                }
            }, function (x, y, e) {
                actionMgr.current;
            }, function (e) {
                utilActionEnd(actionMgr, ActionMoveWall.prototype.type), delete this._dragBegin;
            }, this, this, this).touchstart(touchHandler).touchmove(touchHandler).touchend(touchHandler);
        }
    },
    makeSvgLine: function (p0, p1){
			  return "M" + 100*p0.x + "," + -100*p0.y + "L" + 100*p1.x + "," + -100*p1.y;
		},
    update: function () {
        var style = (this.de[0], this.de[1]);
        var highlight = this.de[2];
        var lLine = this.de[3];
        var rLine = this.de[4];
        
        var dimLine = this.de[5];
        var dimText = this.de[6];

        //增加内墙中线--add by gaoning 2017.8.12
        var dimLine_inner = this.de[7];
        var dimText_inner = this.de[8];
        //第二条线
        var dimLine_inner2 = this.de[9];
        var dimText_inner2 = this.de[10];

        var fp = this.view.doc.floorplan;
        if (0 != (2 & this.dF)) {
            var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            highlight.attr({
                "stroke-opacity": void 0 != picked ? .85 : .0,
                "fill-opacity": void 0 != picked ? .45 : .0
            });
            var locked = utilModelIsFlagOn(fp, MODELFLAG_LOCKED);
            style.attr({
                "fill-opacity": locked ? 1 - this.model.transparent : .6
            });
            
            lLine.attr(
            	"display", (void 0 != picked && !locked ? "block" : "none")
            );
            rLine.attr(
            	"display", (void 0 != picked && !locked ? "block" : "none")
            );           
        }
        if (0 != (32 & this.dF), 0 != (16 & this.dF) && style.attr({
                "fill-opacity": 1 - this.model.transparent
            }), 0 != (4 & this.dF)) {
            var isHidden = utilModelIsFlagOn(this.model, MODELFLAG_HIDDEN);
            style.attr("stroke-dasharray", isHidden ? "8,6" : ""), style.attr("opacity", isHidden ? .5 : 1);
        }
        if (0 != (8 & this.dF)) {
            var isLoadBearing = utilModelIsFlagOn(this.model, WALLFLAG_LOAD_BEARING);
            style.attr("fill", isLoadBearing ? "#202020" : "#cccccc");
        }
        if (0 != (1 & this.dF)) {
            var wallLen = utilModelWallGetLength(this.model);
            if (isNaN(wallLen) || .149 > wallLen) {
                style.attr("display", "none");
                highlight.attr("display", "none");
                dimLine && dimLine.attr("display", "none");

                //增加内墙中线--add by gaoning 2017.8.12
                dimLine_inner && dimLine_inner.attr("display", "none");
                //第二条线
                dimLine_inner2 && dimLine_inner2.attr("display", "none");

                return void (dimText && dimText.attr("display", "none"));
            }
            style.attr("display", "block");
            var angle=utilMathLineYAxisAngle(this.model.begin,this.model.end);
            if(angle<45){
                highlight.attr({"display": "block",cursor: 'url(asset/imgSnap/wallvCursor.png) 20 7,move'});
            }else{
                highlight.attr({"display": "block",cursor: 'url(asset/imgSnap/wallhCursor.png) 7 20,move'});
            }

            dimLine && dimLine.attr("display", "block");
            dimText && dimText.attr("display", "block");

            //增加内墙中线--add by gaoning 2017.8.12
            dimLine_inner && dimLine_inner.attr("display", "block");
            dimText_inner && dimText_inner.attr("display", "block");
            //第二条线
            dimLine_inner2 && dimLine_inner2.attr("display", "block");
            dimText_inner2 && dimText_inner2.attr("display", "block");

            var path = utilSnapWallCreateLoopString(this.model, utilModelIsFlagOff(this.model, WALLFLAG_DETAILEDUPDATED_2D));

            path != style.attr("path") && (style.attr({
                path: path
            }), highlight.attr({
                path: path   //增加内墙中线--add by gaoning 2017.8.12
            }), utilSnapWallUpdateDimension(this.view, this.model, dimLine, dimText),
                //第二条线
                utilSnapWallUpdateDimensionInner2(this.view, this.model, dimLine_inner2, dimText_inner2),
                utilSnapWallUpdateDimensionInner(this.view, this.model, dimLine_inner, dimText_inner));

            utilModelSetFlagOff(this.model, WALLFLAG_DETAILEDUPDATED_2D);
            utilWallForEachFloor(fp, this.model, function (floor) {
                utilModelChangeFlag(floor, 1 << 20);
            }), application.structureChangedEvent.dispatch(this.model);
            
            //更新曲点辅助线
            if(this.model.bezier){            	
	            lLine.attr({
								  path: this.makeSvgLine(this.model.begin, this.model.bezier)
							})
							rLine.attr({
								  path: this.makeSvgLine(this.model.end, this.model.bezier)
							})
						}else{
							lLine.attr({
								  path: ""
							})
							rLine.attr({
								  path: ""
							})
						}
        }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.remove();
        });
    }
});

//墙中心线--gaoning
var utilSnapWallUpdateDimension = function () {
    var defaultDimensionPositionComparedCallback = function (begin, end) {
        return 1;
    };
    return function (view, wall, dimPath, dimText, dimensionPositionComparedCallback) {
        var wallBegin = wall.begin;
        var wallEnd = wall.end;
        var dimPosCompared = dimensionPositionComparedCallback || defaultDimensionPositionComparedCallback;
        if (dimPath && dimText && wallBegin && wallEnd && !isNaN(wallBegin.x) && !isNaN(wallEnd.x)) {
            __assert("path" == dimPath.type && "text" == dimText.type, "Error dimension type.");
            var perpendicularOffset = DEFAULT_WALL_WIDTH + wall.width / 2, dimBeginInWall = wallBegin, dimEndInWall = wallEnd, dimBegin = utilMathGetScaledPoint(dimBeginInWall, utilMathRotatePointCW(dimBeginInWall, dimEndInWall, 90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset), dimEnd = utilMathGetScaledPoint(dimEndInWall, utilMathRotatePointCW(dimEndInWall, dimBeginInWall, -90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset), dimMiddle = {
                x: (dimBegin.x + dimEnd.x) / 2,
                y: (dimBegin.y + dimEnd.y) / 2
            }, dimBeginPerpendicularLineBegin = utilMathGetScaledPoint(dimBegin, utilMathRotatePointCW(dimBegin, dimEnd, -90), DEFAULT_WALL_WIDTH / 2), dimBeginPerpendicularLineEnd = utilMathGetScaledPoint(dimBeginPerpendicularLineBegin, dimBegin, DEFAULT_WALL_WIDTH), dimBeginSlopeLineBegin = utilMathRotatePointCW(dimBegin, dimBeginPerpendicularLineBegin, -45), dimBeginSlopeLineEnd = utilMathRotatePointCW(dimBegin, dimBeginPerpendicularLineEnd, -45), dimEndPerpendicularLineBegin = utilMathGetScaledPoint(dimEnd, utilMathRotatePointCW(dimEnd, dimBegin, 90), DEFAULT_WALL_WIDTH / 2), dimEndPerpendicularLineEnd = utilMathGetScaledPoint(dimEndPerpendicularLineBegin, dimEnd, DEFAULT_WALL_WIDTH), dimEndSlopeLineBegin = utilMathRotatePointCW(dimEnd, dimEndPerpendicularLineBegin, -45), dimEndSlopeLineEnd = utilMathRotatePointCW(dimEnd, dimEndPerpendicularLineEnd, -45), cx = function (coord) {
                return Math.ceil(100 * coord);
            }, cy = function (coord) {
                return Math.ceil(-100 * coord);
            }, linePath = "M" + cx(dimBeginPerpendicularLineBegin.x) + "," + cy(dimBeginPerpendicularLineBegin.y) + "L" + cx(dimBeginPerpendicularLineEnd.x) + "," + cy(dimBeginPerpendicularLineEnd.y) + "M" + cx(dimBeginSlopeLineBegin.x) + "," + cy(dimBeginSlopeLineBegin.y) + "L" + cx(dimBeginSlopeLineEnd.x) + "," + cy(dimBeginSlopeLineEnd.y) + "M" + cx(dimEndPerpendicularLineBegin.x) + "," + cy(dimEndPerpendicularLineBegin.y) + "L" + cx(dimEndPerpendicularLineEnd.x) + "," + cy(dimEndPerpendicularLineEnd.y) + "M" + cx(dimEndSlopeLineBegin.x) + "," + cy(dimEndSlopeLineBegin.y) + "L" + cx(dimEndSlopeLineEnd.x) + "," + cy(dimEndSlopeLineEnd.y) + "M" + cx(dimBegin.x) + "," + cy(dimBegin.y) + "L" + cx(dimEnd.x) + "," + cy(dimEnd.y), length = Math.round(1e3 * utilMathLineLength(wallBegin, wallEnd));
            dimPath.attr({
                path: linePath
            }), dimText.attr({
                x: 100 * dimMiddle.x,
                y: -100 * dimMiddle.y,
                text: length
            });
        }
    };
}();

//计算内墙中线--add by gaoning 2017.8.12
var utilSnapWallUpdateDimensionInner = function () {
    var defaultDimensionPositionComparedCallback = function (begin, end) {
        return 1;
    };
    return function (view, wall, dimPath, dimText, dimensionPositionComparedCallback) {
        //第一条线
        var wallBegin = wall._lines[1];//wall.begin;
        var wallEnd = wall._lines[2];//wall.end;

        var dimPosCompared = dimensionPositionComparedCallback || defaultDimensionPositionComparedCallback;
        if (dimPath && dimText && wallBegin && wallEnd && !isNaN(wallBegin.x) && !isNaN(wallEnd.x)) {
            __assert("path" == dimPath.type && "text" == dimText.type, "Error dimension type.");

            //第一条线
            var perpendicularOffset = DEFAULT_WALL_WIDTH_INNER + wall.width / 2;
            var dimBeginInWall = wallBegin;
            var dimEndInWall = wallEnd;
            var dimBegin = utilMathGetScaledPoint(dimBeginInWall, utilMathRotatePointCW(dimBeginInWall, dimEndInWall, 90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
            var dimEnd = utilMathGetScaledPoint(dimEndInWall, utilMathRotatePointCW(dimEndInWall, dimBeginInWall, -90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
            var dimMiddle = {
                x: (dimBegin.x + dimEnd.x) / 2,
                y: (dimBegin.y + dimEnd.y) / 2
            };
            var dimBeginPerpendicularLineBegin = utilMathGetScaledPoint(dimBegin, utilMathRotatePointCW(dimBegin, dimEnd, -90), DEFAULT_WALL_WIDTH / 2);
            var dimBeginPerpendicularLineEnd = utilMathGetScaledPoint(dimBeginPerpendicularLineBegin, dimBegin, DEFAULT_WALL_WIDTH);
            var dimBeginSlopeLineBegin = utilMathRotatePointCW(dimBegin, dimBeginPerpendicularLineBegin, -45);
            var dimBeginSlopeLineEnd = utilMathRotatePointCW(dimBegin, dimBeginPerpendicularLineEnd, -45);
            var dimEndPerpendicularLineBegin = utilMathGetScaledPoint(dimEnd, utilMathRotatePointCW(dimEnd, dimBegin, 90), DEFAULT_WALL_WIDTH / 2);
            var dimEndPerpendicularLineEnd = utilMathGetScaledPoint(dimEndPerpendicularLineBegin, dimEnd, DEFAULT_WALL_WIDTH);
            var dimEndSlopeLineBegin = utilMathRotatePointCW(dimEnd, dimEndPerpendicularLineBegin, -45);
            var dimEndSlopeLineEnd = utilMathRotatePointCW(dimEnd, dimEndPerpendicularLineEnd, -45);
            var cx = function (coord) {
                return Math.ceil(100 * coord);
            };
            var cy = function (coord) {
                return Math.ceil(-100 * coord);
            };
            var linePath = "M" + cx(dimBeginPerpendicularLineBegin.x) + "," + cy(dimBeginPerpendicularLineBegin.y) + "L" + cx(dimBeginPerpendicularLineEnd.x) + "," + cy(dimBeginPerpendicularLineEnd.y) + "M" + cx(dimBeginSlopeLineBegin.x) + "," + cy(dimBeginSlopeLineBegin.y) + "L" + cx(dimBeginSlopeLineEnd.x) + "," + cy(dimBeginSlopeLineEnd.y) + "M" + cx(dimEndPerpendicularLineBegin.x) + "," + cy(dimEndPerpendicularLineBegin.y) + "L" + cx(dimEndPerpendicularLineEnd.x) + "," + cy(dimEndPerpendicularLineEnd.y) + "M" + cx(dimEndSlopeLineBegin.x) + "," + cy(dimEndSlopeLineBegin.y) + "L" + cx(dimEndSlopeLineEnd.x) + "," + cy(dimEndSlopeLineEnd.y) + "M" + cx(dimBegin.x) + "," + cy(dimBegin.y) + "L" + cx(dimEnd.x) + "," + cy(dimEnd.y);
            var length = Math.round(1e3 * utilMathLineLength(wallBegin, wallEnd));
            dimPath.attr({
                path: linePath
            }), dimText.attr({
                x: 100 * dimMiddle.x,
                y: -100 * dimMiddle.y,
                text: length
            });
        }

    };
}();

//计算内墙中线--第二条线--add by gaoning 2017.8.12
var utilSnapWallUpdateDimensionInner2 = function () {
    var defaultDimensionPositionComparedCallback = function (begin, end) {
        return 1;
    };
    return function (view, wall, dimPath, dimText, dimensionPositionComparedCallback) {
        //第二条线
        var wallBegin = wall._lines[4];//wall.begin;
        var wallEnd = wall._lines[5];//wall.end;

        var length = Math.round(1e3 * utilMathLineLength(wallBegin, wallEnd));
        var length2 = Math.round(1e3 * utilMathLineLength(wall._lines[1], wall._lines[2]));
        if(length==length2){
            //return null;
        }

        var dimPosCompared = dimensionPositionComparedCallback || defaultDimensionPositionComparedCallback;
        if (dimPath && dimText && wallBegin && wallEnd && !isNaN(wallBegin.x) && !isNaN(wallEnd.x)) {
            __assert("path" == dimPath.type && "text" == dimText.type, "Error dimension type.");
            var perpendicularOffset = DEFAULT_WALL_WIDTH_INNER + wall.width / 2;
            var dimBeginInWall = wallBegin;
            var dimEndInWall = wallEnd;
            var dimBegin = utilMathGetScaledPoint(dimBeginInWall, utilMathRotatePointCW(dimBeginInWall, dimEndInWall, 90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
            var dimEnd = utilMathGetScaledPoint(dimEndInWall, utilMathRotatePointCW(dimEndInWall, dimBeginInWall, -90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
            var dimMiddle = {
                x: (dimBegin.x + dimEnd.x) / 2,
                y: (dimBegin.y + dimEnd.y) / 2
            };
            var dimBeginPerpendicularLineBegin = utilMathGetScaledPoint(dimBegin, utilMathRotatePointCW(dimBegin, dimEnd, -90), DEFAULT_WALL_WIDTH / 2);
            var dimBeginPerpendicularLineEnd = utilMathGetScaledPoint(dimBeginPerpendicularLineBegin, dimBegin, DEFAULT_WALL_WIDTH);
            var dimBeginSlopeLineBegin = utilMathRotatePointCW(dimBegin, dimBeginPerpendicularLineBegin, -45);
            var dimBeginSlopeLineEnd = utilMathRotatePointCW(dimBegin, dimBeginPerpendicularLineEnd, -45);
            var dimEndPerpendicularLineBegin = utilMathGetScaledPoint(dimEnd, utilMathRotatePointCW(dimEnd, dimBegin, 90), DEFAULT_WALL_WIDTH / 2);
            var dimEndPerpendicularLineEnd = utilMathGetScaledPoint(dimEndPerpendicularLineBegin, dimEnd, DEFAULT_WALL_WIDTH);
            var dimEndSlopeLineBegin = utilMathRotatePointCW(dimEnd, dimEndPerpendicularLineBegin, -45);
            var dimEndSlopeLineEnd = utilMathRotatePointCW(dimEnd, dimEndPerpendicularLineEnd, -45);
            var cx = function (coord) {
                return Math.ceil(100 * coord);
            };
            var cy = function (coord) {
                return Math.ceil(-100 * coord);
            };
            var linePath = "M" + cx(dimBeginPerpendicularLineBegin.x) + "," + cy(dimBeginPerpendicularLineBegin.y) + "L" + cx(dimBeginPerpendicularLineEnd.x) + "," + cy(dimBeginPerpendicularLineEnd.y) + "M" + cx(dimBeginSlopeLineBegin.x) + "," + cy(dimBeginSlopeLineBegin.y) + "L" + cx(dimBeginSlopeLineEnd.x) + "," + cy(dimBeginSlopeLineEnd.y) + "M" + cx(dimEndPerpendicularLineBegin.x) + "," + cy(dimEndPerpendicularLineBegin.y) + "L" + cx(dimEndPerpendicularLineEnd.x) + "," + cy(dimEndPerpendicularLineEnd.y) + "M" + cx(dimEndSlopeLineBegin.x) + "," + cy(dimEndSlopeLineBegin.y) + "L" + cx(dimEndSlopeLineEnd.x) + "," + cy(dimEndSlopeLineEnd.y) + "M" + cx(dimBegin.x) + "," + cy(dimBegin.y) + "L" + cx(dimEnd.x) + "," + cy(dimEnd.y);
            var length = Math.round(1e3 * utilMathLineLength(wallBegin, wallEnd));
            dimPath.attr({
                path: linePath
            }), dimText.attr({
                x: 100 * dimMiddle.x,
                y: -100 * dimMiddle.y,
                text: length
            });
        }

        if(length==length2){
            //var linePath = "M";
            //dimPath.attr({
            //    path: linePath
            //}), dimText.attr({
            //    x: 0,
            //    y: 0,
            //    text: ""
            //});
            //dimPath.remove();
            //dimText.remove();
        }

    };
}();

/*
 DisplayThreeWall
 */

function DisplayThreeWall(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplayThreeWall, DisplayObject), utilExtend(DisplayThreeWall.prototype, {
    create: function () {
        classBase(this, "create"), void 0 == this.de && (this.de = new THREE.Object3D(),
            this.de.did = this.de.name = this.id), this.view.layers[this.model.type].add(this.de);
        var updateFun = function (propertyName, oldValue, newValue) {
        	  if((oldValue & WALLFLAG_DETAILEDUPDATED_3D) || (newValue & WALLFLAG_DETAILEDUPDATED_3D)){
        	  	//同时刷新smoothStart WALLFLAG_DETAILEDUPDATED_3D 开关
        	  	var smoothStart = utilModelWallGetSmoothStart(this.model, "right");
        	  	if(smoothStart.wall != this.model){
        	  		utilFloorplanUpdateWallAreaByWall(smoothStart.wall);
        	  	}
        	  	smoothStart = utilModelWallGetSmoothStart(this.model, "left");
        	  	if(smoothStart.wall != this.model){
        	  		utilFloorplanUpdateWallAreaByWall(smoothStart.wall);
        	  	}
        	  }
        	
        	  var fp = this.view.doc.floorplan;
            "transparent" != propertyName && ("flag" == propertyName ? utilModelIsFlagOn(this.model, WALLFLAG_DETAILEDUPDATED_3D) ? (this.dF |= 1, utilFloorplanUpdateWallAreaByWall(this.model)) : (oldValue & MODELFLAG_HIDDEN) != (newValue & MODELFLAG_HIDDEN) ? (this.dF |= 512,utilFloorplanUpdateWallAreaByWall(this.model)) : (oldValue & MODELFLAG_LOCKED) != (newValue & MODELFLAG_LOCKED) ? this.dF |= 0 : this.dF |= 2 :
            "leftMaterial" != propertyName &&
            "rightMaterial" != propertyName &&
            "side0Material" != propertyName &&
            "side1Material" != propertyName &&
            "side2Material" != propertyName &&
            "side3Material" != propertyName ||
            (utilModelSetFlagOn(this.model, WALLFLAG_DETAILEDUPDATED_3D),
             this.model[propertyName] && (this.model[propertyName].type != "MATERIALRAWCOLOR") && (this.model[propertyName] = null),
                this.dF |= 1),
            "stoneMaterial" == propertyName &&
            (utilModelSetFlagOn(this.model, WALLFLAG_DETAILEDUPDATED_3D),
            this.dF |= 1));
        }.bind(this);
        var linkPropertyChangedFun = function (property, linksOp, changeFrom, changeTo) {
            var model = this.model;
            property instanceof Material && (model.leftMaterial && property.id == model.leftMaterial.id && (this.dF |= 4),
            model.rightMaterial && property.id == model.rightMaterial.id && (this.dF |= 8),
            model.side0Material && property.id == model.side0Material.id && (this.dF |= 16),
            model.side1Material && property.id == model.side1Material.id && (this.dF |= 32),
            model.side2Material && property.id == model.side2Material.id && (this.dF |= 64),
            model.side3Material && property.id == model.side3Material.id && (this.dF |= 128),
            model.stoneMaterial && property.id == model.stoneMaterial.id && (this.dF |= 256));
        }.bind(this);
        this.model.propertyChangedEvent.add(updateFun);
        this.model.linksChangedEvent.add(updateFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    update: function () {
        var fp = this.view.doc.floorplan;
        /*isNotCustomTile add by oxl 2017-04-13*/
        var mat = this.model.rightMaterial;  //rightMaterial
        var isNotCustomTile = !(mat && (mat.category == "custom_tile" || mat.category == "customparquet"));

        if (0 == _utilThreeDisplayElementGetMesh(this.de).length && isNotCustomTile) {
            var wall3d = utilThreeCreateWall(this, !1);
            this.de.add(wall3d);
        }
        if (0 != (1 & this.dF) && isNotCustomTile) {
            var oldChildren = this.de.children.slice(0);
            oldChildren.forEach(function (oldChild) {
                _utilDisposeResource(oldChild), this.de.remove(oldChild);
            }, this);
            var wall3d = utilThreeCreateWall(this, utilModelIsFlagOff(this.model, WALLFLAG_DETAILEDUPDATED_3D));
            this.de.add(wall3d);
            utilModelSetFlagOff(this.model, WALLFLAG_DETAILEDUPDATED_3D);
        }
        if (0 != (2 & this.dF) && isNotCustomTile) {
        	  var pickresult = application.pickMgr.pickResults[this.model.id];
        	  if(pickresult){
        	  	this.de.traverse(function (child) {
	                if(pickresult.opt && pickresult.opt.elementName + "highlight" == child.name){
	                	child.visible = true;
	                }else if(child.name.indexOf("highlight") != -1){
	                	child.visible = false;
	                }
	            });
        	  }else{
	            this.de.traverse(function (child) {
	                (child.name.indexOf("highlight") != -1) && (child.visible = false);
	            });
            }
        }
        0 != (512 & this.dF) && (this.de.visible = utilModelIsFlagOff(this.model, MODELFLAG_HIDDEN));
        var needUpdateMeshMaterials = [], changedModelMaterial = void 0;
        if (0 != (4 & this.dF) && (changedModelMaterial = this.model.leftMaterial, this.de.traverse(function (child) {
                "left" == child.name && (needUpdateMeshMaterials.push(child.material));

            })), 0 != (8 & this.dF) && (changedModelMaterial = this.model.rightMaterial, this.de.traverse(function (child) {
                "right" == child.name && (needUpdateMeshMaterials.push(child.material));

            })), 0 != (16 & this.dF) && (changedModelMaterial = this.model.side0Material, this.de.traverse(function (child) {
                "side0" == child.name && (needUpdateMeshMaterials.push(child.material));

            })), 0 != (32 & this.dF) && (changedModelMaterial = this.model.side1Material, this.de.traverse(function (child) {
                "side1" == child.name && (needUpdateMeshMaterials.push(child.material));

            })), 0 != (64 & this.dF) && (changedModelMaterial = this.model.side2Material, this.de.traverse(function (child) {
                "side2" == child.name && (needUpdateMeshMaterials.push(child.material));

            })), 0 != (128 & this.dF) && (changedModelMaterial = this.model.side3Material, this.de.traverse(function (child) {
                "side3" == child.name && (needUpdateMeshMaterials.push(child.material));

            })), 0 != (256 & this.dF) && (changedModelMaterial = this.model.stoneMaterial, this.de.traverse(function (child) {
                "stone" == child.name && (needUpdateMeshMaterials.push(child.material));

            })), (needUpdateMeshMaterials.length > 0) && changedModelMaterial) {

            needUpdateMeshMaterials.forEach(function (needUpdateMeshMaterial) {
                var matScale = changedModelMaterial.getScale();
                needUpdateMeshMaterial.scUniform1 = [utilMathToRadius(-changedModelMaterial.rot), changedModelMaterial.tx, changedModelMaterial.ty, 0];
                needUpdateMeshMaterial.scUniform2 = [matScale.x, matScale.y, 0, 0];

                if (changedModelMaterial.type == MaterialRawColor.prototype.type) {
                    var textureUrl = changedModelMaterial.getUrl();
                    var texture = THREE.ImageUtils.loadTexture(textureUrl, void 0, function (t) {
                        t.needsUpdate = !0, fp && utilModelChangeFlag(fp, FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN);
                    });
                    needUpdateMeshMaterial.map = texture;
                }
                //add by gaoning 2017.6.12  修改墙面切割没法显示的问题。
                if (changedModelMaterial.type == Parquet.prototype.type) {
                    if (needUpdateMeshMaterial.map) {
                        var textureUrl = changedModelMaterial.getThreeUrl();
                        needUpdateMeshMaterial.map.image.src = textureUrl;
                    }
                }
            })
        }
    },
    destroy: function () {
        _utilDisposeResource(this.de);
        this.view.layers[this.model.type].remove(this.de);
    }
});

function utilThreeCreateWall(displayWall, isSimplified) {
    var view = displayWall.view;
    var wallModel = displayWall.model;
    var fp = view.doc.floorplan;
    var rightTileId = wallModel.rightMaterial && wallModel.rightMaterial.pid;
    var leftTileId = wallModel.leftMaterial && wallModel.leftMaterial.pid;
    var wall3d = new THREE.Object3D();
    var wallProfile = utilModelWallGetTessellates(wallModel, isSimplified);
    if (!wallProfile) return wall3d;
    var openings = utilModelWallGetAttached(fp, wallModel, Opening);
    openings.length > 0 && __log("holes count = " + openings.length);
    var wallHeight3d = wallModel.height3d;
    var highlightMat = new THREE.MeshBasicMaterial({
        color: 15790144,
        transparent: !0,
        opacity: .15
    });
    var defaultMeshMat = utilThreeViewCreateTileMaterial(view, void 0, {});
    
    //创建左右两侧墙体
    var leftMeshMat = leftTileId ? utilThreeViewCreateTileMaterial(view, wallModel.leftMaterial, {}) : defaultMeshMat;
    var rightMeshMat = rightTileId ? utilThreeViewCreateTileMaterial(view, wallModel.rightMaterial, {}) : defaultMeshMat;
    
    var rightLine = [wallProfile[1], wallProfile[2]];   
    var leftLine = [wallProfile[4], wallProfile[5]];    
    if(wallModel.bezier && wallProfile.length == 9){
    	rightLine = wallProfile[7];
    	rightLine.splice(0,0,wallProfile[1]);
    	rightLine.push(wallProfile[2]);
    	
    	leftLine = wallProfile[8];
    	leftLine.splice(0,0,wallProfile[4]);
    	leftLine.push(wallProfile[5]);
    }
    
    var leftBuiltData = utilThreeExtrude2dline(leftLine, wallHeight3d, openings);
    var rightBuiltData = utilThreeExtrude2dline(rightLine, wallHeight3d, openings);
    var leftWall = utilThreeTurn2DWallBuiltDataToSideWall(leftBuiltData, "left", highlightMat, leftMeshMat);
    var rightWall = utilThreeTurn2DWallBuiltDataToSideWall(rightBuiltData, "right", highlightMat, rightMeshMat);
    wall3d.add(leftWall);
    wall3d.add(rightWall);
    /////////////////////////

    //添加门槛石    
    var midLine = [wallProfile[0], wallProfile[3]];
    for (var i = 0; i < openings.length; ++i) {
        var opening = openings[i];
        if (opening.z < 0.001) {
            var profile = utilThreeExtrude2dStoneLoop(midLine, wallModel.width, opening);
            var wallStone = utilThreeCreateWallStone(displayWall.view, profile, highlightMat, wallModel.stoneMaterial);
            wall3d.add(wallStone);
        }
    }

    //原来是墙侧面由两部分组成，改成只有一面组成
    //var sideWallLine = [[wallProfile[0], wallProfile[1]], [wallProfile[2], wallProfile[3]], [wallProfile[3], wallProfile[4]], [wallProfile[5], wallProfile[6]]];
    var sideWallLine = [[wallProfile[5], wallProfile[1]], [wallProfile[2], wallProfile[4]]];
    for (var i = 0; i < sideWallLine.length; ++i) {
        var sideBuiltData = utilThreeExtrude2dline(sideWallLine[i], wallHeight3d, void 0, !1);

        var sideTileId = wallModel["side" + i + "Material"] && wallModel["side" + i + "Material"].pid;
        var sideMeshMat = sideTileId ? utilThreeViewCreateTileMaterial(view, wallModel["side" + i + "Material"], {}) : defaultMeshMat;

        var sideWall = utilThreeTurn2DWallBuiltDataToSideWall(sideBuiltData, "side" + i, highlightMat, sideMeshMat);
        wall3d.add(sideWall);
    }
    
    var topProfile = [];
    if(wallModel.bezier && wallProfile.length == 9){    	
    	topProfile.push(wallProfile[0]);
    	topProfile = topProfile.concat(wallProfile[7]);
    	topProfile.push(wallProfile[3]);
    	topProfile = topProfile.concat(wallProfile[8]);
    	topProfile.push(wallProfile[6]);    	
    }else{
    	topProfile = wallProfile;
    }
    var topRoot = new THREE.Object3D();
    var topShape = new THREE.Shape(topProfile);
    var topGeom = topShape.makeGeometry();
    var topMesh = new THREE.Mesh(topGeom, defaultMeshMat);
    topMesh.name = "top";
    topMesh.position.set(0, 0, wallHeight3d);
    topRoot.add(topMesh);
    wall3d.add(topRoot);
    var defaultHoleMat = defaultMeshMat;
    return leftBuiltData.h && leftBuiltData.h.forEach(function (h, i) {
        var holeMesh = utilThreeBuildExtrudeMesh(h, wallModel.width, "hole" + i, defaultHoleMat);
        wall3d.add(holeMesh);
    }), wall3d;
}



// sourceURL=src\display\wall.js