//point
function DisplaySnapPoint(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplaySnapPoint, DisplayObject);
utilExtend(DisplaySnapPoint.prototype, {
    create: function () {
        var layer = this.view.layers[this.model.type];
        context = this.view.context, actionMgr = this.view.app.actionMgr, fp = this.view.doc.floorplan, color = "#8f8f8f", factor = (this.model,
            100), x = -100, y = -100;
        if (context) {
            var circle = context.circle(x * factor, -y * factor, .1 * factor).attr({
                fill: color,
                stroke: color,
                "fill-opacity": utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? .0 : .2,
                "stroke-opacity": utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? .0 : .2,
                "stroke-width": 1,
                cursor: 'url(asset/imgSnap/pointCursor.png) 16 16,move',
                did: this.id
            });
            this.de = [circle], layer.add(this.de);
            this.model.propertyChangedEvent.add(function (propertyName) {
                "x" != propertyName && "y" != propertyName || (this.dF |= 1);
                "flag" == propertyName && (this.dF |= 2);
            }.bind(this));
            var touchHandler = function (e, a0, a1, a2) {
                if (e.stopPropagation(), "touchstart" == e.type){ 
                    utilActionBegin(actionMgr, ActionMovePoint.prototype.type, this.model); 
                }else if ("touchmove" == e.type) {
                    e.stopPropagation();
                    var touch = e.touches[0], modelPt = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY);
                    utilActionRun(actionMgr, e.type, e, modelPt);
                } else {
                	"touchend" == e.type && utilActionEnd(actionMgr, ActionMovePoint.prototype.type);
                }
            }.bind(this), onclick = function (e) {
                __log("point click");
            }.bind(this);
            var self = this.model;
            circle.mouseover(function (e) {
            }).mouseout(function (e) {
            }).drag(function (dx, dy, x, y, e) {
                utilSvgScreenSpaceToModelSpace(this.view, x, y);
                this._isMove = this._isMove || dx >= 1 || dy >= 1;
            }, function (x, y, e) {
            	  var forean = utilModelIsFlagOn(this.model, POINT_CHANGED_FOR_FROZEN);
                if(!forean)(utilActionBegin(actionMgr, ActionMovePoint.prototype.type, this.model), this._isMove = !1);
            }, function (e) {
            	  var forean = utilModelIsFlagOn(this.model, POINT_CHANGED_FOR_FROZEN);
                if(!forean)(utilActionEnd(actionMgr, ActionMovePoint.prototype.type), delete this._isMove);
            }, this, this, this).click(onclick).touchstart(touchHandler).touchmove(touchHandler).touchend(touchHandler);
        }
    },
    update: function () {
        var circle = this.de[0];
        var fp = this.view.doc.floorplan;
        var host = utilPointGetHost(this.model);
        var radius = (host && host.type == Wall.prototype.type, .05);
        var model = this.model;
        var factor = 100;
        if(0 != (1 & this.dF)){ 
        	circle.attr("cx") == model.x * factor && circle.attr("cy") == -model.y * factor || circle.attr({
	            cx: model.x * factor,
	            cy: -model.y * factor,
	            r: factor * radius
	        });
        }
        if(0 != (2 & this.dF)){
        	var forean = utilModelIsFlagOn(this.model, POINT_CHANGED_FOR_FROZEN);
        	circle.attr({
            "fill-opacity": (utilModelIsFlagOn(fp, MODELFLAG_LOCKED) || forean) ? .0 : .2,
            "stroke-opacity": (utilModelIsFlagOn(fp, MODELFLAG_LOCKED) || forean) ? .0 : .2
	        });
	      }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            //ele.attr("display", "none");
            ele.remove();
        });
    }
})

//bezierpoint贝塞尔控制点
function DisplaySnapBezierPoint(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplaySnapBezierPoint, DisplayObject);
utilExtend(DisplaySnapBezierPoint.prototype, {
    create: function () {
        var layer = this.view.layers[this.model.type];
        var context = this.view.context;
        var actionMgr = this.view.app.actionMgr;
        var fp = this.view.doc.floorplan;
        var color = "#0000ff";
        var factor = (this.model,
            100), x = -100, y = -100;
        var radius = .05;
        if (context) {
            var circle = context.circle(this.model.x * factor, -this.model.y * factor, .1 * factor).attr({
                fill: color,
                stroke: color,
                r: factor * radius,
                "fill-opacity": utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? .0 : .3,
                "stroke-opacity": utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? .0 : .3,
                "stroke-width": 1,
                cursor: "move",
                did: this.id
            });
            
            this.de = [circle];
            layer.add(this.de);
            this.model.propertyChangedEvent.add(function (propertyName) {
                "x" != propertyName && "y" != propertyName || (this.dF |= 1);
                "flag" == propertyName && (this.dF |= 2);
            }.bind(this));
            var touchHandler = function (e, a0, a1, a2) {
                if (e.stopPropagation(), "touchstart" == e.type) {
                	  utilActionBegin(actionMgr, ActionMoveBezierPoint.prototype.type, this.model); 
                }else if ("touchmove" == e.type) {
                    e.stopPropagation();
                    var touch = e.touches[0];
                    var modelPt = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY);
                    utilActionRun(actionMgr, e.type, e, modelPt);
                } else {
                	"touchend" == e.type && utilActionEnd(actionMgr, ActionMoveBezierPoint.prototype.type);
                }
            }.bind(this), onclick = function (e) {
                __log("point click");
            }.bind(this);
            circle.mouseover(function (e) {
            }).mouseout(function (e) {
            }).drag(function (dx, dy, x, y, e) {
                utilSvgScreenSpaceToModelSpace(this.view, x, y);
                this._isMove = this._isMove || dx >= 1 || dy >= 1;
            }, function (x, y, e) {
                utilActionBegin(actionMgr, ActionMoveBezierPoint.prototype.type, this.model);
                this._isMove = !1;
            }, function (e) {
                utilActionEnd(actionMgr, ActionMoveBezierPoint.prototype.type);
                delete this._isMove;
            }, this, this, this).click(onclick).touchstart(touchHandler).touchmove(touchHandler).touchend(touchHandler);
        }
    },
    update: function () {
        var circle = this.de[0];
        var fp = this.view.doc.floorplan;
        var host = utilPointGetHost(this.model);
        var radius = (host && host.type == Wall.prototype.type,
            .05), model = this.model, factor = 100;
        if(0 != (1 & this.dF)){
        	circle.attr("cx") == model.x * factor && circle.attr("cy") == -model.y * factor || circle.attr({
            cx: model.x * factor,
            cy: -model.y * factor,
            r: factor * radius
          });
        }
        if(0 != (2 & this.dF)){
        	circle.attr({
            "fill-opacity": utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? .0 : .3,
            "stroke-opacity": utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? .0 : .3
          });
        }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            //ele.attr("display", "none");
            ele.remove();
        });
    }
})