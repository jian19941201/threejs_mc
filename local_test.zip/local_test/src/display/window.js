//2d窗户显示对象
function DisplaySnapWindow(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplaySnapWindow, DisplaySnapOpening);
utilExtend(DisplaySnapWindow.prototype, {
    createAux: function (bound) {
        function createAux_bayWindow() {
           var model=this.model,pickMgr = this.view.app.pickMgr;
            var auxAttr = {
                fill: "#FFFFFF",
                stroke: SNAP_OPENING_STROKE_COLOR.normal,
                "stroke-width": 3,
                "fill-opacity": 1
            }, click = function (e) {
                e.stopPropagation();
            }, dragMove = function (dx, dy, x, y, e) {
                e.stopPropagation();
                var modelOffset = utilSvgVectorScreenSpaceToModelSpace(this.view, dx, dy), mPos = {
                    x: this.ox + modelOffset.x,
                    y: this.oy + modelOffset.y
                }, hitPt = {
                    x: 100 * mPos.x,
                    y: 100 * -mPos.y
                }, picked = utilSnapDisplaySelect(this.view, hitPt, [Wall.prototype.type]), attachedWall = picked.length > 0 ? picked[0].model : void 0;
                utilActionRun(actionMgr, e.type + "2d", e, mPos, attachedWall);
            }, dragDown = function (x, y, e) {
                e.stopPropagation(), this.ox = this.model.x, this.oy = this.model.y, actionMgr.current || utilActionBegin(actionMgr, ActionMoveProduct.prototype.type, this.model);
            }, dragUp = function (e) {
                utilPickMgrPick(pickMgr, model)
                e.stopPropagation(), utilActionEnd(actionMgr, ActionMoveProduct.prototype.type);
            }, bigRect = context.path().attr(auxAttr).click(click).drag(dragMove, dragDown, dragUp, this, this, this), smallRect = context.path().attr(auxAttr).click(click).drag(dragMove, dragDown, dragUp, this, this, this);
            return [bigRect, smallRect];
        }

        function createAux_slidingWindow() {
            var line = context.line().attr({
                stroke: SNAP_OPENING_STROKE_COLOR.normal,
                "stroke-width": 3
            });
            return [line];
        }

        function createAux_frenchWindow() {
            return [context.path().attr({
                fill: "none",
                stroke: SNAP_OPENING_STROKE_COLOR.normal,
                "stroke-width": 3,
                "fill-opacity": 1
            })];
        }
        var context = (this.view, this.view.context);
        var actionMgr = this.view.app.actionMgr;
        switch (this.model.meta.subcategory) {
            case "baywindow":
                return createAux_bayWindow.bind(this)();

            case "slidingwindow":
                return createAux_slidingWindow.bind(this)();

            case "frenchwindow":
                return createAux_frenchWindow.bind(this)();

            default:
                return [];
        }
    },
    updateAuxGeom: function (bound) {
        function getAuxPath_bayWindow(extra, rot) {
            var center = {
                x: bound.left + bound.width / 2,
                y: bound.top + bound.height / 2
            }, p0 = {
                x: bound.left - 100 * extra.x,
                y: bound.top - 100 * extra.y
            }, p1 = {
                x: bound.left + 100 * extra.x + bound.width,
                y: bound.top - 100 * extra.y
            }, p2 = {
                x: bound.left + 100 * extra.x + bound.width,
                y: bound.top
            }, p3 = {
                x: bound.left - 100 * extra.x,
                y: bound.top
            }, rp0 = utilMathRotatePointCW(center, p0, rot), rp1 = utilMathRotatePointCW(center, p1, rot), rp2 = utilMathRotatePointCW(center, p2, rot), rp3 = utilMathRotatePointCW(center, p3, rot), path = "M" + rp0.x + "," + rp0.y + "L" + rp1.x + "," + rp1.y + "L" + rp2.x + "," + rp2.y + "L" + rp3.x + "," + rp3.y + "Z";
            return path;
        }

        function getAuxPath_frenchWindow() {
            var l = bound.left, t = bound.top, w = bound.width, h = bound.height;
            return "M" + l + "," + (t + h / 3) + "L" + (l + w) + "," + (t + h / 3) + "M" + l + "," + (t + 2 * h / 3) + "L" + (l + w) + "," + (t + 2 * h / 3) + "M" + (l + w / 2) + "," + (t + h / 3) + "L" + (l + w / 2) + "," + (t + 2 * h / 3);
        }

        var auxes = this.auxiliaries;
        this.view, this.view.context;
        switch (this.model.meta.subcategory) {
            case "baywindow":
                var bigRect = auxes[0], smallRect = auxes[1], rot = (this.model.rot + 180 * this.model.swing) % 360, smallExtra = {
                    x: .2,
                    y: .3
                }, bigExtra = {
                    x: .4,
                    y: .5
                }, smallPath = getAuxPath_bayWindow(smallExtra, -rot), bigPath = getAuxPath_bayWindow(bigExtra, -rot);
                bigRect.attr({
                    path: bigPath
                }).transform(""), smallRect.attr({
                    path: smallPath
                }).transform("");
                break;

            case "slidingwindow":
                var line = auxes[0];
                line.attr({
                    x1: bound.left,
                    y1: bound.top + bound.height / 2,
                    x2: bound.left + bound.width,
                    y2: bound.top + bound.height / 2
                }).transform("r" + -this.model.rot);
                break;

            case "frenchwindow":
                var pathSnap = auxes[0], path = getAuxPath_frenchWindow();
                pathSnap.attr({
                    path: path
                }).transform("r" + -this.model.rot);
        }
    },
    updateAuxFlag: function () {
        var auxes = this.auxiliaries, view = this.view, picked = (this.view.context, utilPickMgrIsPicked(view.app.pickMgr, this.model));
        auxes.forEach(function (aux) {
            aux.attr({
                stroke: picked ? SNAP_OPENING_STROKE_COLOR.pick : SNAP_OPENING_STROKE_COLOR.normal
            });
        });
    }
});

//3d窗户显示对象
function DisplayThreeWindow(model, view) {
    classBase(this, model, view);
}

classInherit(DisplayThreeWindow, DisplayThreeOpening);
utilExtend(DisplayThreeWindow.prototype, {
    create: function () {
        classBase(this, "create");
    },
    update: function () {
        classBase(this, "update");
        var displayElement = this.de;
        if (0 != (1 & this.dF)) {
            var rot = (this.model.rot + 180 * this.model.swing) % 360;
            displayElement.position.set(this.model.x, this.model.y, this.model.z + .004);
            displayElement.setRotationFromAxisAngle(new THREE.Vector3(0, 0, 1), rot * Math.PI / 180);
            displayElement.scale.set(this.model.sx, this.model.sy, this.model.sz), displayElement.updateMatrix();
        }
    },
    destroy: function () {
        classBase(this, "destroy");
    }
});

