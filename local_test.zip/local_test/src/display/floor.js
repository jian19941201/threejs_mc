//测试地面能否正常扩展(通常是往内扩会出现失败)
function utilSnapFloorTestOffset(floorModel, offset) {
    if (offset == 0) {
        return true;
    }
    var profile = floorModel.profile;
    if (profile.length < 3)
        return false;
    for (var i = 0, len = profile.length; len > i; ++i) {
        var curve = profile[i];
        if (!curve.begin || !curve.end)
            return false;
    }

    var geom = utilFloorInsideLoopFromProfile(floorModel);
    var clipperGeom = utilAdaptorClipperOffset(geom, offset);

    return clipperGeom != null;
}

//生成地面轮廓线
function utilSnapFloorCreatePathString(floorModel, offset) {
    var profile = floorModel.profile;
    if (profile.length < 3)
        return ["", ""];
    for (var i = 0, len = profile.length; len > i; ++i) {
        var curve = profile[i];
        if (!curve.begin || !curve.end)
            return ["", ""];
    }

    var paths = [];

    //导出中心线path
    var centerGeom = utilFloorGetLoopFromProfile(floorModel);
    paths.push(centerGeom ? utilSnapFloorCreatePathFromLoop(centerGeom) : "");

    //导出内墙线path
    var insideGeom = utilFloorInsideLoopFromProfile(floorModel);
    insideGeom = utilAdaptorClipperOffset(insideGeom, offset);
    paths.push(insideGeom ? utilSnapFloorCreatePathFromLoop(insideGeom) : "");

    return paths;
}

//生成地面轮廓线for样板间套用--add by gaoning 2017.10.12
function utilSnapFloorCreatePathStringForModelRoom(floorModel, offset) {
    var profile = floorModel.profile;
    if (profile.length < 3)
        return ["", ""];
    for (var i = 0, len = profile.length; len > i; ++i) {
        var curve = profile[i];
        if (!curve.begin || !curve.end)
            return ["", ""];
    }

    var paths = [];

    //导出中心线path
    var centerGeom = utilFloorGetLoopFromProfile(floorModel);
    paths.push(centerGeom ? utilSnapFloorCreatePathFromLoop(centerGeom) : "");

    //导出内墙线path
    var insideGeom = utilFloorInsideLoopFromProfile(floorModel);
    insideGeom = utilAdaptorClipperOffset(insideGeom, offset);
    paths.push(insideGeom ? utilSnapFloorCreatePathFromLoop(insideGeom) : "");

    return paths;
}

//获取地面波打线总尺寸
function utilFloorGetBoundaryOffset(floor) {
    var fp = application.doc.floorplan;
    var model = floor;
    var boundaryOffset = 0;
    utilFloorplanForEachBoundary(fp, function (boundary) {
        if (boundary.host.id == model.id) {
            boundaryOffset += boundary.size;
        }
    });
    return -boundaryOffset;
}

//生成房间snap纹理
function utilSnapFloorGetMaterialInfo(display, side) {
    var floor = display.model;
    var view = display.view;
    var sideMaterial = side + "Material";
    var material = floor[sideMaterial];

    if (!material)
        return null;

    var meta = material.meta;
    var imageUrl = material.getUrl();
    return {url: imageUrl, width: 100 * meta.xlen * material.sx, height: 100 * meta.ylen * material.sy};
}
//var floorPattern = {};
//function utilSnapFloorGetMaterial(displayFloor, side, patternCallback) {
//    var floor = displayFloor.model;
//    var view = displayFloor.view;
//    var context = view.context;
//    __assert("2d" == view.id, "Floor url could only be used in 2d view.");
//    var sideMaterial = side + "Material";
//    var material = floor[sideMaterial];
//    //return mat ? utilSnapViewUpdateMaterial(displayFloor, mat, patternCallback) : "";
//
//    if (!material)
//        return "";
//
//    var patternId = material.id;
//    var pattern = floorPattern[material.id];
//    if (pattern) {
//        if (pattern._scale.sx != material.sx ||
//            pattern._scale.sy != material.sy ||
//            pattern._url != material.getUrl()) {
//            pattern.remove();
//            pattern = null;
//            delete floorPattern[material.id];
//        }
//    }
//
//    if (!pattern) {
//        var meta = material.meta;
//        if (!meta.xlen || !meta.ylen) {
//            return "";
//        }
//        var width = 100 * meta.xlen * material.sx;
//        var height = 100 * meta.ylen * material.sy;
//        var imageUrl = material.getUrl();
//        var pattern = context.image(imageUrl, 0, 0, width, height).toPattern(0, 0, width, height).attr({
//            id: patternId
//        });
//        pattern._scale = {sx: material.sx, sy: material.sy};
//        pattern._url = imageUrl;
//        floorPattern[material.id] = pattern;
//    }
//
//    return "url(#" + patternId + ")";
//}

//def裁剪，加速
var floorClippath = {};
function utilSnapFloorGetClipPath(display, path, context) {
    var model = display.model;
    var clipPathId = utilUUID();
    var clippath = context.path(path).toClippath().attr({id: clipPathId});
    floorClippath[clipPathId] = clippath;

    return "url(#" + clipPathId + ")";
}
//function utilSnapClearClipPath(material) {
//    var pattern = floorPattern[material.id];
//    if (pattern) {
//        pattern.remove();
//        delete floorPattern[material.id];
//    }
//}
//function utilSnapClearAllPattern() {
//    for (var i in floorPattern) {
//        floorPattern[i].remove();
//    }
//    floorPattern = {};
//}

//def裁剪，加速 export导出用
var floorClippathExport = {};
function utilSnapFloorGetClipPathExport(display, path, context) {
    var model = display.model;

    var clipPathId = utilUUID();
    var clippath = context.path(path).toClippath().attr({id: clipPathId});
    floorClippathExport[clipPathId] = clippath;

    return "url(#" + clipPathId + ")";
}

//生成2维铺贴
function utilFloorCreateSnapStyles(display) {
    var clipperFactor = 10000.0;//clipper缩放因子
    var model = display.model;
    var gap = model.gapwidth;  //砖缝
    var fp = display.view.doc.floorplan;
    var context = display.view.context;
    var cpr = new ClipperLib.Clipper();
    var materialInfo = null;
    var catalog = "floor";

    var ret = [];
    var fillUrl = "";
    var profile = null;
    switch (model.type) {
        case "RECTAREA":
        case "ROUNDAREA":
        case "FREEAREA":
            profile = model.getLoop();
            catalog = "area";
            //fillUrl = utilSnapFloorGetMaterial(display, "area");
            //materialInfo = utilSnapFloorGetMaterialInfo(display, "area");
            break;
        case "FLOOR":
            profile = model.getInsideLoop();
            if (profile)
                profile = utilAdaptorClipperOffset(profile, utilFloorGetBoundaryOffset(this));

            //fillUrl = display.needFillImgUrl === !0 ? utilSnapFloorGetMaterial(display, "floor") : "";
            //materialInfo = utilSnapFloorGetMaterialInfo(display, "floor");
            break;
    }

    if (profile) {
        //生成砖缝颜色底
        var path = utilSnapFloorCreatePathFromLoop(profile);
        var root
        if (model instanceof RoundArea) {
            var attr = {
                cx: 100 * model.center.x,
                cy: -100 * model.center.y,
                r: 100 * model.radius
            }
            root = context.circle(attr);
        } else {
            root = context.path(path);
        }
        root.attr({
            fill: "#" + model.gapcolor,
            "stroke-width": 0,
            "stroke-opacity": 1,
            did: display.id
        })
        ret.push(root);

        var floorRectOrigin = model.floorRectOrigin;
        var singlepaveRot = model.singlepaveRot;

        //step2 对所有铺砖生成纹理(实际用砖)
        if (model.floorRectTiles) {
            model.floorRectTiles.forEach(function (frTile) {
                if (frTile.type == "group") { //组类型不显示
                    return;
                }

                //重置element列表
                frTile.elements = [];
                //裁剪
                var tileProfile = frTile.tileProfile;
                if (tileProfile) {
                    tileProfile.forEach(function (subProfile, subTileIndex) {
                        var pos = frTile.pos;
                        var origin = frTile.origin;
                        var material = frTile.material;
                        var subTileProfiles = utilAdaptorClipperOffsetArray(subProfile, -gap * 0.5);
                        subTileProfiles && subTileProfiles.forEach(function (subTileProfile) {
                            subTileProfile = subTileProfile.map(function (t) {
                                //偏移到原点，并补充砖缝偏移
                                //var patternPos = utilMathRotatePointCW({x:0,y:0}, {x:p.x - pos.x, y:p.y - pos.y}, singlepaveRot);
                                //return {x:patternPos.x - gap*0.5, y:patternPos.y - gap*0.5};
                                var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                oT = {x: oT.x - origin.x, y: oT.y - origin.y};   //假砖缝(砖与砖之间不留砖缝)

                                if (frTile.rot) {
                                    var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                    var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                    var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                    var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                    var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                    var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                    var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                    oT = {x: oT.x - x - hx - lx, y: oT.y - y - wy - ly};
                                    oT = utilMathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
                                }

                                return oT;
                            });

                            var mtx = new Snap.Matrix();

                            //铺贴旋转(所有)
                            var fRm = new Snap.Matrix();
                            fRm.rotate(-singlepaveRot, floorRectOrigin.x * 100, -floorRectOrigin.y * 100);
                            mtx.add(fRm);

                            var tm = new Snap.Matrix();
                            //tm.translate(100.0*(origin.x + gap*0.5), -100.0*(origin.y + gap*0.5)); //真砖缝
                            tm.translate(100.0 * (origin.x), -100.0 * (origin.y));   //假砖缝
                            mtx.add(tm);

                            //还原旋转
                            if (frTile.rot) {
                                var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                var tm = new Snap.Matrix();
                                tm.translate(100.0 * (x + hx + lx), -100.0 * (y + wy + ly));
                                mtx.add(tm);

                                var rm = new Snap.Matrix();
                                rm.rotate(-frTile.rot.r, 0, 0);
                                mtx.add(rm);
                            }

                            //sm = new Snap.Matrix();
                            //sm.scale(10);
                            //mtx.add(sm);

                            //还原选砖偏移
                            tm = new Snap.Matrix();
                            tm.translate(-100.0 * (frTile.tileIndex.th * frTile.paveW), 100.0 * (frTile.tileIndex.tv * frTile.paveH));
                            mtx.add(tm);

                            var path = utilSnapFloorCreatePathFromLoop(subTileProfile);
                            //选砖(切割后)
                            tm = new Snap.Matrix();
                            tm.translate(100.0 * (frTile.tileIndex.th * frTile.paveW), -100.0 * (frTile.tileIndex.tv * frTile.paveH));
                            path = Snap.path.map(path, tm);

                            var mrot = 0;
                            switch (frTile.dir) {
                                case 1:
                                    mrot = 0;
                                    break;
                                case 2:
                                    mrot = 90;
                                    break;
                                case 3:
                                    mrot = 180;
                                    break;
                                case 4:
                                    mrot = 270;
                                    break;
                            }

                            if (mrot != 0) {
                                //随机旋转
                                var rotCenter = {
                                    x: (frTile.tileIndex.th * frTile.paveW + frTile.paveW * 0.5) * 100,
                                    y: -(frTile.tileIndex.tv * frTile.paveH + frTile.paveH * 0.5) * 100
                                };
                                var rm = new Snap.Matrix();
                                rm.rotate(mrot, rotCenter.x, rotCenter.y);
                                path = Snap.path.map(path, rm);

                                rm = new Snap.Matrix();
                                rm.rotate(-mrot, rotCenter.x, rotCenter.y);
                                mtx.add(rm);
                            }


                            if (material) {
                                var materialInfo = {
                                    url: material.getUrl(),
                                    width: 100 * material.meta.xlen * material.sx,
                                    height: 100 * material.meta.ylen * material.sy
                                };
                                var clipPathUrl = utilSnapFloorGetClipPath(display, path, display.view.context);
                                var s = context.image(material.getUrl(), 0, -materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                    //var s = context.rect(0,-materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                    //fill: fillUrl,
                                    did: display.id,//降低选中消耗
                                    style: "clip-path:" + clipPathUrl
                                }).transform(mtx.toTransformString());

                                s.name = frTile.pidIndex != null ? ("pave" + frTile.pidIndex) : catalog;

                                frTile.elements[subTileIndex] = s;
                                ret.push(s);
                            }
                        });
                    });

                }
            });
        }

        if (model.floorRectTiles) {
            //添加辅助点
            model.floorRectTiles.forEach(function (frTile) {
                if (frTile.center) {
                    //绘制中心点
                    var factor = 100;
                    var color = "#8f0000";
                    var circle = context.circle(frTile.center.x * factor, -frTile.center.y * factor, .1 * factor).attr({
                        fill: color,
                        stroke: color,
                        r: 2,
                        "stroke-width": 1
                    });
                    ret.push(circle);
                }
            })
        }
    }

    return ret;
}

//绘制导出部分特定layer
function utilFloorCreateSnapStylesExport(opt, svgView) {
    var fp = application.doc.floorplan;
    var context = svgView.context;
    var floorLayer = svgView.layers["FLOOR"];

    var clipperFactor = 10000.0;//clipper缩放因子
    var model = opt.model;
    var walls = opt.walls;
    var gap = model.gapwidth;  //砖缝
    var display = {model: model, view: svgView};

    var cpr = new ClipperLib.Clipper();
    var materialInfo = null;
    var catalog = "floor";
    var minX = 0;
    var maxY = 0;

    var ret = [];
    var fillUrl = "";
    var profile = null;
    var gapcolor = model.gapcolor;
    switch (model.type) {
        case "FREEAREA":
        case "RECTAREA":
        case "ROUNDAREA":
            profile = model.getLoop();
            catalog = "area";
            break;
        case "FLOOR":
            profile = model.getInsideLoop();
            break;
    }

    if (profile) {
        var floorBound = {max: {x: -150, y: -150}, min: {x: 150, y: 150}};
        for (var i = 0, len = profile.length; i < len; ++i) {
            var pt = profile[i];
            floorBound.max.x = Math.max(floorBound.max.x, pt.x);
            floorBound.max.y = Math.max(floorBound.max.y, pt.y);
            floorBound.min.x = Math.min(floorBound.min.x, pt.x);
            floorBound.min.y = Math.min(floorBound.min.y, pt.y);
        }
        var offset = {x: -(floorBound.max.x + 2), y: -floorBound.min.y};//-floorBound.min.x - 2, y:-floorBound.min.y};
        minX = floorBound.min.x - floorBound.max.x - 2;
        maxY = floorBound.max.y - floorBound.min.y + 2;
        var path = "";
        for (var i = 0, len = profile.length; i < len; ++i) {
            var pt = profile[i];
            path += (i == 0 ? "M" : "L") + toFixedNumber((pt.x + offset.x) * 100, 2) + "," + toFixedNumber(-(pt.y + offset.y) * 100, 2);
        }
        path += "Z";
        var floorRoot = context.path(path).attr({
            fill: "#" + gapcolor,
            'opacity': 1
        })
        floorLayer.add(floorRoot);

        var floorRectOrigin = {x: model.floorRectOrigin.x + offset.x, y: model.floorRectOrigin.y + offset.y};
        var singlepaveRot = model.singlepaveRot;

        //step2 对所有铺砖生成纹理(实际用砖)
        if (model.floorRectTiles) {
            model.floorRectTiles.forEach(function (frTile) {
                if (frTile.type == "group") { //组类型不显示
                    return;
                }

                //裁剪
                var tileProfile = frTile.tileProfile;
                if (tileProfile) {
                    tileProfile.forEach(function (subProfile, subTileIndex) {
                        var pos = frTile.pos;
                        var origin = {x: frTile.origin.x + offset.x, y: frTile.origin.y + offset.y};
                        var material = frTile.material;
                        var subTileProfiles = api.adaptorClipperOffsetArray(subProfile, -gap * 0.5);
                        subTileProfiles && subTileProfiles.forEach(function (subTileProfile) {
                            subTileProfile = subTileProfile.map(function (t) {
                                t = {x: t.x + offset.x, y: t.y + offset.y};
                                //偏移到原点，并补充砖缝偏移
                                //var patternPos = utilMathRotatePointCW({x:0,y:0}, {x:p.x - pos.x, y:p.y - pos.y}, singlepaveRot);
                                //return {x:patternPos.x - gap*0.5, y:patternPos.y - gap*0.5};
                                var oT = api.mathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                oT = {x: oT.x - origin.x, y: oT.y - origin.y};   //假砖缝(砖与砖之间不留砖缝)

                                if (frTile.rot) {
                                    var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                    var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                    var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                    var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                    var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                    var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                    var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                    oT = {x: oT.x - x - hx - lx, y: oT.y - y - wy - ly};
                                    oT = api.mathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
                                }

                                return oT;
                            });

                            var mtx = new Snap.Matrix();

                            //铺贴旋转(所有)
                            var fRm = new Snap.Matrix();
                            fRm.rotate(-singlepaveRot, floorRectOrigin.x * 100, -floorRectOrigin.y * 100);
                            mtx.add(fRm);

                            var tm = new Snap.Matrix();
                            //tm.translate(100.0*(origin.x + gap*0.5), -100.0*(origin.y + gap*0.5)); //真砖缝
                            tm.translate(100.0 * (origin.x), -100.0 * (origin.y));   //假砖缝 + offset
                            mtx.add(tm);

                            //还原旋转
                            if (frTile.rot) {
                                var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                var tm = new Snap.Matrix();
                                tm.translate(100.0 * (x + hx + lx), -100.0 * (y + wy + ly));
                                mtx.add(tm);

                                var rm = new Snap.Matrix();
                                rm.rotate(-frTile.rot.r, 0, 0);
                                mtx.add(rm);
                            }

                            //还原选砖偏移
                            tm = new Snap.Matrix();
                            tm.translate(-100.0 * (frTile.tileIndex.th * frTile.paveW), 100.0 * (frTile.tileIndex.tv * frTile.paveH));
                            mtx.add(tm);

                            var path = api.floorCreatePathFromLoop(subTileProfile);
                            //选砖(切割后)
                            tm = new Snap.Matrix();
                            tm.translate(100.0 * (frTile.tileIndex.th * frTile.paveW), -100.0 * (frTile.tileIndex.tv * frTile.paveH));
                            path = Snap.path.map(path, tm);

                            var mrot = 0;
                            switch (frTile.dir) {
                                case 1:
                                    mrot = 0;
                                    break;
                                case 2:
                                    mrot = 90;
                                    break;
                                case 3:
                                    mrot = 180;
                                    break;
                                case 4:
                                    mrot = 270;
                                    break;
                            }

                            if (mrot != 0) {
                                //随机旋转
                                var rotCenter = {
                                    x: (frTile.tileIndex.th * frTile.paveW + frTile.paveW * 0.5) * 100,
                                    y: -(frTile.tileIndex.tv * frTile.paveH + frTile.paveH * 0.5) * 100
                                };
                                var rm = new Snap.Matrix();
                                rm.rotate(mrot, rotCenter.x, rotCenter.y);
                                path = Snap.path.map(path, rm);

                                rm = new Snap.Matrix();
                                rm.rotate(-mrot, rotCenter.x, rotCenter.y);
                                mtx.add(rm);
                            }

                            if (material) {
                                var materialInfo = {
                                    url: material.getUrl(),
                                    width: 100 * material.meta.xlen * material.sx,
                                    height: 100 * material.meta.ylen * material.sy
                                };
                                var clipPathUrl = utilSnapFloorGetClipPathExport(display, path, context);
                                var s = context.image(material.getUrl(), 0, -materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                    style: "clip-path:" + clipPathUrl
                                }).transform(mtx.toTransformString());
                                ret.push(s);
                            }
                        });
                    });

                }
            });
        }

        var floorInsidePath = profile.map(function (p) {
            return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
        });

        //绘制房间内的波打线
        utilFloorplanForEachBoundary(fp, function (boundary) {
            if (boundary.host.id == model.id) {
                viewFloorBoundaryExport(floorInsidePath, context, cpr, boundary, offset, {
                    model: boundary,
                    view: svgView
                }, ret);
            }
        });

        //绘制区域铺贴
        var areas = api.floorplanFilterEntity(function (e) {
            return e.type == "RECTAREA" || e.type == "ROUNDAREA" || e.type == "FREEAREA";
        })
        areas = areas.sort(function (a, b) {
            return a.level > b.level ? 1 : 0;
        });
        areas.forEach(function (area) {
            var loop = area.getLoop();
            if (!loop)return;
            var path = loop.map(function (p) {
                return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
            });
            cpr.Clear();
            cpr.AddPath(path, ClipperLib.PolyType.ptSubject, true);
            cpr.AddPath(floorInsidePath, ClipperLib.PolyType.ptClip, true);
            var solution = new ClipperLib.PolyTree();
            cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
            if (solution.m_AllPolys.length > 0) {
                solution.m_AllPolys.forEach(function (poly) {
                    var profile = poly.m_polygon.map(function (p) {
                        return {x: p.X / clipperFactor, y: p.Y / clipperFactor};
                    });

                    var path = "";
                    for (var i = 0, len = profile.length; i < len; ++i) {
                        var pt = profile[i];
                        path += (i == 0 ? "M" : "L") + toFixedNumber((pt.x + offset.x) * 100, 2) + "," + toFixedNumber(-(pt.y + offset.y) * 100, 2);
                    }
                    path += "Z";
                    var areaRoot = context.path(path).attr({
                        fill: "#" + gapcolor,
                        'opacity': 1
                    })
                    ret.push(areaRoot);
                });
                viewFloorAreaExport(floorInsidePath, context, cpr, area, offset, {model: area, view: svgView}, ret);

                utilFloorplanForEachBoundary(fp, function (boundary) {
                    if (boundary.host.id == area.id) {
                        viewFloorBoundaryExport(floorInsidePath, context, cpr, boundary, offset, {
                            model: boundary,
                            view: svgView
                        }, ret);
                    }
                });
            }
        });

        //绘制标尺，尺寸长度
        var DEFAULT_WALL_WIDTH_INNER = -0.25;
        var DEFAULT_WALL_WIDTH = .15;
        var dimPosCompared = function (begin, end) {
            return 1;
        };

        var wallIndex = 0; //记录当前画到第几面墙

        walls.forEach(function (wallInfo, index) {
            var wall = wallInfo[0];
            //wallIndex = index;
            var wallBegin = index == 0 ? walls[walls.length - 1][1] : walls[index - 1][1];
            var wallEnd = wallInfo[1];

            var innerDirection = 1, outDirection = -1;
            //计算是否显示墙信息
            var widthSide = utilModelWallGetSideLength(wall, wallInfo[2]);
            var sideWidths = utilModelWallGetSmoothRawDatas(wall, wallInfo[2]);
            //获取墙标尺的坐标点
            if (sideWidths && sideWidths.length > 0) {
                var startWallSide = sideWidths[0].side;
                if (startWallSide == "left") {
                    wallBegin = sideWidths[0].wall._lines[1];
                    wallEnd = sideWidths[0].wall._lines[2];
                    innerDirection = -2, outDirection = 1.5;
                } else if (startWallSide == "right") {
                    wallBegin = sideWidths[0].wall._lines[5];
                    wallEnd = sideWidths[0].wall._lines[4];
                    innerDirection = 2, outDirection = -1;
                }
            }

            wallBegin = {x: wallBegin.x + offset.x, y: wallBegin.y + offset.y};
            wallEnd = {x: wallEnd.x + offset.x, y: wallEnd.y + offset.y};

            if (wallBegin && wallEnd && !isNaN(wallBegin.x) && !isNaN(wallEnd.x)) {
                //计算用于画墙标尺
                var perpendicularOffset = DEFAULT_WALL_WIDTH_INNER * outDirection + wall.width;
                var dimBeginInWall = wallBegin;
                var dimEndInWall = wallEnd;
                var dimBegin = api.mathGetScaledPoint(dimBeginInWall, api.mathRotatePointCW(dimBeginInWall, dimEndInWall,
                    90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
                var dimEnd = api.mathGetScaledPoint(dimEndInWall, api.mathRotatePointCW(dimEndInWall,
                    dimBeginInWall, -90 * (dimPosCompared(dimBeginInWall, dimEndInWall) ? 1 : -1)), perpendicularOffset);
                var dimMiddle = {
                    x: (dimBegin.x + dimEnd.x) / 2,
                    y: (dimBegin.y + dimEnd.y) / 2
                };
                var dimBeginPerpendicularLineBegin = api.mathGetScaledPoint(dimBegin, api.mathRotatePointCW(dimBegin, dimEnd, -90), DEFAULT_WALL_WIDTH / 2);
                var dimBeginPerpendicularLineEnd = api.mathGetScaledPoint(dimBeginPerpendicularLineBegin, dimBegin, DEFAULT_WALL_WIDTH);
                var dimEndPerpendicularLineBegin = api.mathGetScaledPoint(dimEnd, api.mathRotatePointCW(dimEnd, dimBegin, 90), DEFAULT_WALL_WIDTH / 2);
                var dimEndPerpendicularLineEnd = api.mathGetScaledPoint(dimEndPerpendicularLineBegin, dimEnd, DEFAULT_WALL_WIDTH);
                /////////////////////////////////////////////////////////////////////////////
                var dimTextDim = context.text().attr({  //标尺字体
                    stroke: "none",
                    "font-size": 20,
                    fill: "#5f5f5f",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "text-anchor": "middle"
                }), dimLineDim = context.path().attr({  //标尺
                    fill: "none",
                    stroke: "#5f5f5f",
                    "stroke-width": 1
                });

                //ret.push(dimTextLabel);
                ret.push(dimTextDim);
                ret.push(dimLineDim);

                var cx = function (coord) {
                    return Math.ceil(100 * coord);
                };
                var cy = function (coord) {
                    return Math.ceil(-100 * coord);
                };
                var linePath = "M" + cx(dimBegin.x) + "," + cy(dimBegin.y) + "L" + cx(dimEnd.x) + "," + cy(dimEnd.y) + "M" + cx(dimBeginPerpendicularLineBegin.x) + "," + cy(dimBeginPerpendicularLineBegin.y) + "L" + cx(dimBeginPerpendicularLineEnd.x) + "," + cy(dimBeginPerpendicularLineEnd.y) + "M" + cx(dimEndPerpendicularLineBegin.x) + "," + cy(dimEndPerpendicularLineBegin.y) + "L" + cx(dimEndPerpendicularLineEnd.x) + "," + cy(dimEndPerpendicularLineEnd.y);
                var length = Math.round(1e3 * api.utilMathLineLength(wallBegin, wallEnd));
                dimLineDim.attr({
                    path: linePath
                })
                dimTextDim.attr({
                    x: 100 * dimMiddle.x,
                    y: -100 * dimMiddle.y,
                    text: length
                });

                //计算用于画墙标记ABCD
                if (wall && widthSide != 0) {
                    var isStart = utilModelWallIsSmoothStart(wall, wallInfo[2]);
                    var sideWidths = utilModelWallGetSmoothRawDatas(wall, wallInfo[2]);
                    if (isStart) {
                        if (sideWidths && sideWidths.length > 0) {
                            //start
                            var startWallSide = sideWidths[0].side;
                            if (startWallSide == "left") {
                                wallBegin = sideWidths[0].wall._lines[1];
                                innerDirection = 1;
                            } else if (startWallSide == "right") {
                                wallBegin = sideWidths[0].wall._lines[5];
                                innerDirection = 1;
                            }
                            //end
                            var endWallSide = sideWidths[sideWidths.length - 1].side;
                            if (endWallSide == "left") {
                                wallEnd = sideWidths[sideWidths.length - 1].wall._lines[2];
                            } else if (endWallSide == "right") {
                                wallEnd = sideWidths[sideWidths.length - 1].wall._lines[4];
                            }
                        }
                    }else{
                        var startWallSide = sideWidths[0].side;
                        if (startWallSide == "left") {
                            wallBegin = sideWidths[0].wall._lines[1];
                            wallEnd = sideWidths[0].wall._lines[2];
                        } else if (startWallSide == "right") {
                            wallBegin = sideWidths[0].wall._lines[5];
                            wallEnd = sideWidths[0].wall._lines[4];
                        }
                    }
                    wallBegin = {x: wallBegin.x + offset.x, y: wallBegin.y + offset.y};
                    wallEnd = {x: wallEnd.x + offset.x, y: wallEnd.y + offset.y};

                    var perpendicularOffset2 = DEFAULT_WALL_WIDTH_INNER * 2 * innerDirection + wall.width;
                    var dimBeginInWall2 = wallBegin;
                    var dimEndInWall2 = wallEnd;
                    var dimBegin2 = api.mathGetScaledPoint(dimBeginInWall2, api.mathRotatePointCW(dimBeginInWall2, dimEndInWall2,
                        90 * (dimPosCompared(dimBeginInWall2, dimEndInWall2) ? 1 : -1)), perpendicularOffset2);
                    var dimEnd2 = api.mathGetScaledPoint(dimEndInWall2, api.mathRotatePointCW(dimEndInWall2,
                        dimBeginInWall2, -90 * (dimPosCompared(dimBeginInWall2, dimEndInWall2) ? 1 : -1)), perpendicularOffset2);
                    var dimMiddle2 = {
                        x: (wallBegin.x + wallEnd.x) / 2,
                        y: (wallBegin.y + wallEnd.y) / 2
                    };

                    var dimTextLabel = context.text().attr({  //墙体标注
                            stroke: "#ffffff",
                            "stroke-width": 1,
                            "font-size": 40,
                            fill: "#5f5f5f",
                            "font-family": "Calibri,Arial,Helvetica,sans-serif",
                            "text-anchor": "middle"
                        }).attr({
                        x: 100 * dimMiddle2.x,
                        y: -100 * dimMiddle2.y,
                        text: String.fromCharCode(65 + Number(wallIndex))
                    });
                    ret.push(dimTextLabel);
                    
                    wallIndex++;
                }
                ///////////////////////////////////////////////////////////////////////////
            }
        });
    }

    floorLayer.add(ret);

    return [minX, maxY];
}
//房间内area导出绘制
function viewFloorAreaExport(floorInsidePath, context, cpr, model, offset, display, ret) {
    var clipperFactor = 10000.0;//clipper缩放因子
    var gap = model.gapwidth;
    var gapcolor = model.gapcolor;
    var floorRectOrigin = {x: model.floorRectOrigin.x + offset.x, y: model.floorRectOrigin.y + offset.y};
    var singlepaveRot = model.singlepaveRot;

    if (model.floorRectTiles) {
        model.floorRectTiles.forEach(function (frTile) {
            if (frTile.type == "group") { //组类型不显示
                return;
            }

            //裁剪
            var tileProfile = frTile.tileProfile;
            if (tileProfile) {
                tileProfile.forEach(function (subProfile, subTileIndex) {
                    var pos = frTile.pos;
                    var origin = {x: frTile.origin.x + offset.x, y: frTile.origin.y + offset.y};
                    var material = frTile.material;
                    var subTileProfiles = api.adaptorClipperOffsetArray(subProfile, -gap * 0.5);
                    subTileProfiles && subTileProfiles.forEach(function (subTileProfile) {
                        var path = subTileProfile.map(function (p) {
                            return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
                        });

                        cpr.Clear();
                        cpr.AddPath(path, ClipperLib.PolyType.ptSubject, true);
                        cpr.AddPath(floorInsidePath, ClipperLib.PolyType.ptClip, true);
                        var solution = new ClipperLib.PolyTree();
                        cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
                        if (solution.m_AllPolys.length > 0) {
                            solution.m_AllPolys.forEach(function (poly) {
                                var profile = poly.m_polygon.map(function (p) {
                                    return {x: p.X / clipperFactor, y: p.Y / clipperFactor};
                                });

                                subTileProfile = profile.map(function (t) {
                                    t = {x: t.x + offset.x, y: t.y + offset.y};
                                    //偏移到原点，并补充砖缝偏移
                                    var oT = api.mathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                    //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                    oT = {x: oT.x - origin.x, y: oT.y - origin.y};   //假砖缝(砖与砖之间不留砖缝)

                                    if (frTile.rot) {
                                        var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                        var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                        var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                        var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                        var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                        var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                        var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                        oT = {x: oT.x - x - hx - lx, y: oT.y - y - wy - ly};
                                        oT = api.mathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
                                    }

                                    return oT;
                                });

                                var mtx = new Snap.Matrix();

                                //铺贴旋转(所有)
                                var fRm = new Snap.Matrix();
                                fRm.rotate(-singlepaveRot, floorRectOrigin.x * 100, -floorRectOrigin.y * 100);
                                mtx.add(fRm);

                                var tm = new Snap.Matrix();
                                //tm.translate(100.0*(origin.x + gap*0.5), -100.0*(origin.y + gap*0.5)); //真砖缝
                                tm.translate(100.0 * (origin.x), -100.0 * (origin.y));   //假砖缝
                                mtx.add(tm);

                                //还原旋转
                                if (frTile.rot) {
                                    var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                    var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                    var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                    var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                    var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                    var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                    var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                    var tm = new Snap.Matrix();
                                    tm.translate(100.0 * (x + hx + lx), -100.0 * (y + wy + ly));
                                    mtx.add(tm);

                                    var rm = new Snap.Matrix();
                                    rm.rotate(-frTile.rot.r, 0, 0);
                                    mtx.add(rm);
                                }

                                //还原选砖偏移
                                tm = new Snap.Matrix();
                                tm.translate(-100.0 * (frTile.tileIndex.th * frTile.paveW), 100.0 * (frTile.tileIndex.tv * frTile.paveH));
                                mtx.add(tm);

                                var path = api.floorCreatePathFromLoop(subTileProfile);
                                //选砖(切割后)
                                tm = new Snap.Matrix();
                                tm.translate(100.0 * (frTile.tileIndex.th * frTile.paveW), -100.0 * (frTile.tileIndex.tv * frTile.paveH));
                                path = Snap.path.map(path, tm);

                                var mrot = 0;
                                switch (frTile.dir) {
                                    case 1:
                                        mrot = 0;
                                        break;
                                    case 2:
                                        mrot = 90;
                                        break;
                                    case 3:
                                        mrot = 180;
                                        break;
                                    case 4:
                                        mrot = 270;
                                        break;
                                }

                                if (mrot != 0) {
                                    //随机旋转
                                    var rotCenter = {
                                        x: (frTile.tileIndex.th * frTile.paveW + frTile.paveW * 0.5) * 100,
                                        y: -(frTile.tileIndex.tv * frTile.paveH + frTile.paveH * 0.5) * 100
                                    };
                                    var rm = new Snap.Matrix();
                                    rm.rotate(mrot, rotCenter.x, rotCenter.y);
                                    path = Snap.path.map(path, rm);

                                    rm = new Snap.Matrix();
                                    rm.rotate(-mrot, rotCenter.x, rotCenter.y);
                                    mtx.add(rm);
                                }

                                if (material) {
                                    var materialInfo = {
                                        url: material.getUrl(),
                                        width: 100 * material.meta.xlen * material.sx,
                                        height: 100 * material.meta.ylen * material.sy
                                    };
                                    var clipPathUrl = utilSnapFloorGetClipPathExport(display, path, context);
                                    var s = context.image(material.getUrl(), 0, -materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                        style: "clip-path:" + clipPathUrl
                                    }).transform(mtx.toTransformString());
                                    ret.push(s);
                                }
                            });
                        }
                    });
                });

            }
        });
    }
}
//房间内波打线导出绘制
function viewFloorBoundaryExport(floorInsidePath, context, cpr, model, offset, display, ret) {
    var clipperFactor = 10000.0;//clipper缩放因子
    var gap = model.gapwidth;  //砖缝

    if (model.floorRectTiles) {
        model.floorRectTiles.forEach(function (floorRectTile) {
            var materialInfo = null;

            var fillUrl = "";
            var profile = floorRectTile.profile;
            var styleName = floorRectTile.name + "_" + floorRectTile.index;

            materialInfo = utilSnapFloorGetMaterialInfo(display, floorRectTile.name);

            if (profile) {
                //////////////////生成砖缝颜色底
                var profilePath = profile.map(function (p) {
                    return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
                });
                cpr.Clear();
                cpr.AddPath(profilePath, ClipperLib.PolyType.ptSubject, true);
                cpr.AddPath(floorInsidePath, ClipperLib.PolyType.ptClip, true);
                var solution = new ClipperLib.PolyTree();
                cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
                if (solution.m_AllPolys.length > 0) {
                    solution.m_AllPolys.forEach(function (poly) {
                        var profile = poly.m_polygon.map(function (p) {
                            return {x: p.X / clipperFactor + offset.x, y: p.Y / clipperFactor + offset.y};
                        });

                        var path = utilSnapFloorCreatePathFromLoop(profile);
                        var root = context.path(path);
                        root.attr({
                            fill: "#" + model.gapcolor,
                            "stroke-width": 0,
                            "stroke-opacity": 1,
                            did: display.id
                        })
                        ret.push(root);
                    })
                }
                //////////////////生成砖缝底色 end

                var floorRectOrigin = {
                    x: floorRectTile.floorRectOrigin.x + offset.x,
                    y: floorRectTile.floorRectOrigin.y + offset.y
                };
                var singlepaveRot = floorRectTile.singlepaveRot;
                //var isSquare = model.isSquare;

                //step2 对所有铺砖生成纹理(实际用砖)
                if (floorRectTile.tiles) {
                    floorRectTile.tiles.forEach(function (frTile) {
                        //重置element列表
                        //裁剪
                        var tileProfile = frTile.tileProfile;
                        if (tileProfile) {
                            tileProfile.forEach(function (subTileProfile, subTileIndex) {
                                var pos = frTile.pos;
                                var origin = {x: frTile.origin.x + offset.x, y: frTile.origin.y + offset.y};
                                subTileProfile = utilAdaptorClipperOffset(subTileProfile, -gap * 0.5);
                                if (subTileProfile) {
                                    var path = subTileProfile.map(function (p) {
                                        return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
                                    });

                                    cpr.Clear();
                                    cpr.AddPath(path, ClipperLib.PolyType.ptSubject, true);
                                    cpr.AddPath(floorInsidePath, ClipperLib.PolyType.ptClip, true);
                                    var solution = new ClipperLib.PolyTree();
                                    cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
                                    if (solution.m_AllPolys.length > 0) {
                                        solution.m_AllPolys.forEach(function (poly) {
                                            var profile = poly.m_polygon.map(function (p) {
                                                return {x: p.X / clipperFactor, y: p.Y / clipperFactor};
                                            });

                                            subTileProfile = profile.map(function (t) {
                                                t = {x: t.x + offset.x, y: t.y + offset.y};
                                                //偏移到原点，并补充砖缝偏移
                                                //var patternPos = utilMathRotatePointCW({x:0,y:0}, {x:p.x - pos.x, y:p.y - pos.y}, singlepaveRot);
                                                //return {x:patternPos.x - gap*0.5, y:patternPos.y - gap*0.5};
                                                var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                                //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                                oT = {x: oT.x - origin.x, y: oT.y - origin.y};   //假砖缝(砖与砖之间不留砖缝)

                                                if (frTile.rot) {
                                                    var x = frTile.rot.x != null ? frTile.rot.x * frTile.tileW : 0;
                                                    var y = frTile.rot.y != null ? frTile.rot.y * frTile.tileH : 0;
                                                    var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.tileH : 0;
                                                    var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.tileW : 0;
                                                    oT = {x: oT.x - x - hx, y: oT.y - y - wy};
                                                    oT = utilMathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
                                                }

                                                return oT;
                                            });

                                            var mtx = new Snap.Matrix();

                                            //铺贴旋转(所有)
                                            var fRm = new Snap.Matrix();
                                            fRm.rotate(-singlepaveRot, floorRectOrigin.x * 100, -floorRectOrigin.y * 100);
                                            mtx.add(fRm);

                                            var tm = new Snap.Matrix();
                                            //tm.translate(100.0*(origin.x + gap*0.5), -100.0*(origin.y + gap*0.5)); //真砖缝
                                            tm.translate(100.0 * (origin.x), -100.0 * (origin.y));   //假砖缝
                                            mtx.add(tm);

                                            //还原旋转
                                            if (frTile.rot) {
                                                var x = frTile.rot.x != null ? frTile.rot.x * frTile.tileW : 0;
                                                var y = frTile.rot.y != null ? frTile.rot.y * frTile.tileH : 0;
                                                var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.tileH : 0;
                                                var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.tileW : 0;

                                                var tm = new Snap.Matrix();
                                                tm.translate(100.0 * (x + hx), -100.0 * (y + wy));
                                                mtx.add(tm);

                                                var rm = new Snap.Matrix();
                                                rm.rotate(-frTile.rot.r, 0, 0);
                                                mtx.add(rm);
                                            }

                                            var path = utilSnapFloorCreatePathFromLoop(subTileProfile);

                                            var mrot = 0;

                                            if (mrot != 0) {
                                                //随机旋转
                                                var rotCenter = {
                                                    x: frTile.tileW * 0.5 * 100,
                                                    y: -frTile.tileH * 0.5 * 100
                                                };
                                                var rm = new Snap.Matrix();
                                                rm.rotate(mrot, rotCenter.x, rotCenter.y);
                                                path = Snap.path.map(path, rm);

                                                rm = new Snap.Matrix();
                                                rm.rotate(-mrot, rotCenter.x, rotCenter.y);
                                                mtx.add(rm);
                                            }

                                            if (materialInfo) {
                                                var clipPathUrl = utilSnapFloorGetClipPathExport(display, path, display.view.context);
                                                var s = context.image(materialInfo.url, 0, -materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                                    //var s = context.rect(0,-materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                                    //fill: fillUrl,
                                                    //did: display.id,//降低选中消耗
                                                    style: "clip-path:" + clipPathUrl,
                                                }).transform(mtx.toTransformString());

                                                ret.push(s);
                                            }
                                        });
                                    }

                                }
                            });

                        }

                    });
                }
            }
        });
    }


    return ret;
}
//绘制导出部分特定layer end

/*
 DisplaySnapFloor
 */
function DisplaySnapFloor(modelObject, view) {
    classBase(this, modelObject, view);
    this.needFillImgUrl = !0;
}

classInherit(DisplaySnapFloor, DisplayObject);

var SNAP_FLOOR_NONAME_LABEL = "未命名";

utilExtend(DisplaySnapFloor.prototype, {
    create: function () {
        classBase(this, "create");
        var context = this.view.context;
        var layer = this.view.layers[this.model.type];
        var labelLayer = this.view.layers[SNAP_LAYER_ROOMLABEL];
        var paths = utilSnapFloorCreatePathString(this.model, this.ignoreOffset ? 0 : utilFloorGetBoundaryOffset(this.model));
        //var fillUrl = this.needFillImgUrl === !0 ? utilSnapFloorGetMaterial(this, "floor") : "";
        var fp = this.view.doc.floorplan;
        var view = (this.model, this.view);

        if (context) {
            //作为砖缝的基底使用
            //var root = context.path(paths[0]).attr({
            //	  fill: "#"+this.model.rootMaterial.getColor().getHexString(),
            //	  "stroke-width": 0,
            //	  "stroke-opacity": 1,
            //    opacity: utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? 1 : .0,                
            //})

            //内部铺砖区域path
            this.model.rebuild();
            var style = context.g().attr({did: this.id});
            style.add(utilFloorCreateSnapStyles(this));
            //var insidePath = paths[1];
            //var style = context.path(paths[1]).attr({
            //    fill: fillUrl,
            //    stroke: "#707070",
            //    "stroke-width": 0,
            //    "stroke-opacity": 1,
            //    "stroke-linejoin": "round",
            //    opacity: utilModelIsFlagOn(fp, MODELFLAG_LOCKED) ? 1 : .5,
            //    did: this.id
            //})
            //utilUUID()            
            var highlight = context.path(paths[1]).attr({
                fill: "none",
                "fill-opacity": .0,
                "stroke": "#49fffe",
                "stroke-opacity": .0,
                "stroke-width": 5,
            });
            this.de = [style, highlight];
            layer.add(this.de);

            if (labelLayer) {
                var textAttr = {
                    "font-size": this.view.getRoomLabelFontSize(),
                    fill: "#202020",
                    "font-family": "Calibri,Arial,Helvetica,sans-serif",
                    "font-weight": "bold",
                    "text-anchor": "middle",
                    cursor: "move"
                };
                var dragMove = function (dx, dy, x, y, e) {
                    if (e.stopPropagation(), 1 != e.button && this._modelCenter) {
                        var modelOffset = utilSvgVectorScreenSpaceToModelSpace(view, dx, dy), candidate = {
                            x: this._modelCenter.x + modelOffset.x,
                            y: this._modelCenter.y + modelOffset.y
                        }, modelPos = utilSvgScreenSpaceToModelSpace(view, x, y);
                        candidate = modelPos, utilMathIsPointInPoly(this._modelLoop, candidate) && (this.model.labelX = candidate.x,
                            this.model.labelY = candidate.y);
                    }
                };
                var dragDown = function (x, y, e) {
                    e.stopPropagation();
                    1 != e.button && (this._modelCenter = {
                        x: this.model.labelX,
                        y: this.model.labelY
                    },
                        //this._modelLoop = utilFloorGetLoopFromProfile(this.model));
                        this._modelLoop = utilFloorInsideLoopFromProfile(this.model));
                }
                var dragUp = function (e) {
                    e.stopPropagation(), 1 != e.button && (delete this._modelCenter, delete this._modelLoop);
                }
                //var label = context.text(0, 0, this.model.label).attr(textAttr).drag(dragMove, dragDown, dragUp, this, this, this);
                //var measurement = context.text(0, 0, "").attr(textAttr).drag(dragMove, dragDown, dragUp, this, this, this);
                //labelLayer.add([label, measurement]);
                //this.de.push(label, measurement);

                var label = context.text(0, 0, this.model.label).attr(textAttr).drag(dragMove, dragDown, dragUp, this, this, this);
                labelLayer.add([label]);
                this.de.push(label);
            }

            var updateFun = function (propertyName, oldValue, newValue) {
                if (propertyName instanceof Material) {
                    "rot" != oldValue && "tx" != oldValue && "ty" != oldValue && "sx" != oldValue && "sy" != oldValue || (this.dF |= 2);
                } else if ("flag" == propertyName) {
                    (oldValue & FLOORFLAG_CHANGED_FOR_REDRAWN) != (newValue & FLOORFLAG_CHANGED_FOR_REDRAWN) && (this.dF |= 1, this.model.redrawn = true);
                    (oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 2);
                    (oldValue & MODELFLAG_LOCKED) != (newValue & MODELFLAG_LOCKED) && (this.dF |= 2);
                } else if ("label" == propertyName) {
                    this.dF |= 4;
                } else if ("labelX" == propertyName || "labelY" == propertyName) {
                    this.dF |= 8;
                } else if ("floorMaterial" == propertyName) {
                    this.dF |= 1;
                    this.dF |= 2;
                    this.model.paveRebuild = true;
                } else if ("paveType" == propertyName || "height3d" == propertyName) {
                    this.dF |= 1;
                    this.model.clearPaveDB();
                    this.model.paveRebuild = true;
                } else if ("gapwidth" == propertyName || "gapcolor" == propertyName || "direction" == propertyName) {
                    this.dF |= 1;
                    this.model.paveRebuild = true;
                } else {
                    this.dF |= 1;
                }
            }.bind(this);

            var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
                if (changeFrom instanceof Material) {
                    changeFrom.ignoreUV = true;
                    this.model.clearPaveDB();
                }
                this.dF |= 1;
                this.dF |= 2;
                this.model.paveRebuild = true;
            }.bind(this);

            var linkPropertyChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
                this.dF |= 1;
                this.model.paveRebuild = true;
            }.bind(this);

            this.model.propertyChangedEvent.add(updateFun);
            this.model.linksChangedEvent.add(linksChangedFun);
            this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
        }
    },
    update: function () {  //utilFloorGetBoundaryOffset(this)--修改画房间时，房间名称位置偏移问题--change by gaoning 2017.7.30
        //重置铺砖
        this.model.rebuild();

        var style = this.de[0];
        var highlight = this.de[1];
        var label = this.de[2];
        //var measurement = this.de[3];

        var measure = this.model.measurement;
        var textArr = [];
        textArr.push("" == this.model.label ? SNAP_FLOOR_NONAME_LABEL : this.model.label);
        textArr.push(Math.abs(toFixedNumber(measure, 2)).toString() + " m²");

        if (0 != (1 & this.dF)) {
            //当要求redrawn时，对需要是否重画进行优化
            if (this.model.redrawn2D) {
                style.clear();
                style.add(utilFloorCreateSnapStyles(this));
                this.model.redrawn2D = false;
            }
            var geom = utilFloorGetLoopFromProfile(this.model);
            var paths = utilSnapFloorCreatePathString(this.model, this.ignoreOffset ? 0 : utilFloorGetBoundaryOffset(this.model));
            if (paths[1] != highlight.attr("path") && (
                    highlight.attr({
                        path: paths[1]
                    })),
                geom && geom.length > 3) {
                var center = {x: this.model.labelX, y: this.model.labelY};
                measure = this.model.measurement;
                center && !isNaN(center.x) && measure > .5 ? (label && label.attr({
                        x: 100 * center.x,
                        y: -100 * center.y,
                        text: textArr,//"" == this.model.label ? SNAP_FLOOR_NONAME_LABEL : this.model.label,
                        display: "block"
                    })
                ) : (label && label.attr({
                        display: "none"
                    })
                );
            }
        }
        if (0 != (2 & this.dF)) {
            var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            highlight.attr({
                "stroke-opacity": void 0 != picked ? .85 : .0
            });
            var fp = this.view.doc.floorplan;
            var locked = utilModelIsFlagOn(fp, MODELFLAG_LOCKED);
            style.attr({
                opacity: locked ? 1 : .5
            });
            measure = this.model.getMeasurement("inner");
            textArr[1] = (Math.abs(toFixedNumber(measure, 2)).toString() + " m²");
            label && label.attr({
                display: measure > .5 ? "block" : "none"
            });
        }
        0 != (4 & this.dF) && label && label.attr({
            text: textArr//"" == this.model.label ? SNAP_FLOOR_NONAME_LABEL : this.model.label
        }), 0 != (8 & this.dF) && (label && label.attr({
                x: 100 * this.model.labelX,
                y: -100 * this.model.labelY
            })
        );

        //排序
        if (label.node.childNodes[0]) {
            var length = label.node.childNodes[0].getComputedTextLength();
            label.node.childNodes[1].setAttribute('dx', (-length).toString());
            label.node.childNodes[1].setAttribute('dy', this.view.getDimensionFontSize().toString());
        }
    },
    destroy: function () {
        this.de.forEach(function (ele) {
            ele.remove();
        });
    }
})


function utilThreeCreateFloorAndCeiling(floordisplay) {
    var clipperFactor = 10000.0;//clipper缩放因子
    var view = floordisplay.view;
    var floorModel = floordisplay.model;
    var room3d = new THREE.Object3D();
    var fMat = floorModel.floorMaterial;

    //var profile = utilFloorGetLoopFromProfile(floorModel);
    var profile = (floorModel.ceilingMaterial, utilFloorInsideLoopFromProfile(floorModel));
    if (floorModel.profile.length < 3 || !profile || profile.length < 3)
        return room3d;

    var insideProfile = utilAdaptorClipperOffset(profile, utilFloorGetBoundaryOffset(floordisplay.model));
    var floor3d = new THREE.Object3D();

    //创建root砖缝用
    var rootProfile = insideProfile;//utilAdaptorClipperOffset(profile, 0.010);
    var rootProfilePaths = [rootProfile.map(function (p) {
        return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
    })];

    var areaPaths = [];
    var holePaths = [];
    var holes = [];
    utilFloorplanForEachArea(fp, function (area) {
        if ((area.type == "RECTAREA" || area.type == "ROUNDAREA" || area.type == "FREEAREA" ) && area.cavern) {
            var areaProfile = area.getLoop();
            areaPaths.push(areaProfile.map(function (p) {
                return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
            }));//new THREE.Shape(areaProfile));
        }
    });
    var cpr = new ClipperLib.Clipper();
    if (areaPaths.length > 0) {
        var areaPath = areaPaths.splice(0, 1);
        var retProfile = utilCliperFromPaths(areaPath, areaPaths, cpr, ClipperLib.ClipType.ctUnion, clipperFactor);
        if (retProfile) {
            retProfile.forEach(function (profileAndHoles) {
                holePaths.push(profileAndHoles.profile.map(function (p) {
                    return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
                }));
            });
        }
    }

    var retProfile = utilCliperFromPaths(rootProfilePaths, holePaths, cpr, ClipperLib.ClipType.ctDifference, clipperFactor);
    if (retProfile) {
        //rootProfile = retProfile[0];
        retProfile.forEach(function (profileAndHoles) {
            var rootShape = new THREE.Shape(profileAndHoles.profile);
            profileAndHoles.holes.forEach(function (hole) {
                rootShape.holes.push(new THREE.Shape(hole));
            });

            var rootGeom = rootShape.makeGeometry();
            var rootMeshMat = utilThreeViewCreateTileMaterial(view, floorModel.rootMaterial, {});
            var rootMesh = new THREE.Mesh(rootGeom, rootMeshMat);
            rootMesh.position.set(0, 0, -.0001);
            rootMesh.name = "root";
            floor3d.add(rootMesh);
        });
    }

    var rootShape = new THREE.Shape(rootProfile);
    //holes.forEach(function(hole){
    //	rootShape.holes.push(hole);
    //});

    //var rootGeom = rootShape.makeGeometry();
    //var rootMeshMat = utilThreeViewCreateTileMaterial(view, floorModel.rootMaterial, {});
    //var rootMesh = new THREE.Mesh(rootGeom, rootMeshMat);
    //rootMesh.position.set(0, 0, -.0001);
    //rootMesh.name = "root";
    //floor3d.add(rootMesh);

    //地面
    var clipperFactor = 10000.0;//clipper缩放因子
    var gap = floorModel.gapwidth;  //砖缝
    var cpr = new ClipperLib.Clipper();
    var floorRectOrigin = floorModel.floorRectOrigin;
    var singlepaveRot = floorModel.singlepaveRot;
    if (floorModel.floorRectTiles) {
        var floorMeshMat = utilThreeViewCreatePaveTileMaterial(view, floorModel.floorMaterial, {});
        var paveMeshMats = []; //对应的材质
        var paveGeoms = [new THREE.Geometry()]; //对应的geom
        for (var i = 0; i < 10; ++i) {
            floorModel["pave" + i + "Material"] && (paveMeshMats[i] = utilThreeViewCreatePaveTileMaterial(view, floorModel["pave" + i + "Material"], {}), paveGeoms[i + 1] = new THREE.Geometry());
        }

        floorModel.floorRectTiles.forEach(function (frTile) {
            if (frTile.type == "group") {//组类型不作显示
                return;
            }

            var tileProfile = frTile.tileProfile;
            if (tileProfile) {
                tileProfile.forEach(function (subProfile) {
                    var pos = frTile.pos;
                    var origin = frTile.origin;
                    var subTileProfiles = utilAdaptorClipperOffsetArray(subProfile, -gap * 0.5);
                    subTileProfiles && subTileProfiles.forEach(function (subTileProfile) {
                        var subTilePaths = subTileProfile.map(function (p) {
                            return {X: Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
                        });

                        var subTileClippeds = null;
                        if (holePaths.length > 0) {
                            subTileClippeds = utilCliperFromPaths([subTilePaths], holePaths, cpr, ClipperLib.ClipType.ctDifference, clipperFactor);
                        } else {
                            subTileClippeds = [{profile: subTileProfile}];
                        }
                        if (subTileClippeds) {
                            subTileClippeds.forEach(function (subTileClipped) {
                                subTileProfile = subTileClipped.profile.map(function (t) {
                                    //偏移到原点，并补充砖缝偏移
                                    var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                    //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                    oT = {x: oT.x - origin.x, y: oT.y - origin.y}; //假砖缝

                                    if (frTile.rot) {
                                        var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                        var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                        var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                        var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                        var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                        var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                        var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                        oT = {x: oT.x - x - hx - lx, y: oT.y - y - wy - ly};
                                        oT = utilMathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
                                    }

                                    return oT;
                                });

                                var mrot = 0;
                                //铺贴模板固定铺砖朝向
                                switch (frTile.dir) {
                                    case 1:
                                        mrot = 0;
                                        break;
                                    case 2:
                                        mrot = 90;
                                        break;
                                    case 3:
                                        mrot = 180;
                                        break;
                                    case 4:
                                        mrot = 270;
                                        break;
                                }

                                var mrotCenter = {x: frTile.paveW * 0.5, y: frTile.paveH * 0.5};
                                if (mrot != 0) {
                                    //进行随机旋转
                                    subTileProfile = subTileProfile.map(function (t) {
                                        return utilMathRotatePointCW(mrotCenter, t, -mrot);
                                    });
                                }

                                subTileProfile = subTileProfile.map(function (t) {
                                    //选砖
                                    return {
                                        x: t.x + frTile.tileIndex.th * frTile.paveW,
                                        y: t.y + frTile.tileIndex.tv * frTile.paveH
                                    };
                                });

                                var floorShape = new THREE.Shape(subTileProfile);
                                subTileClipped.holes && subTileClipped.holes.forEach(function (hole) {
                                    hole = hole.map(function (t) {
                                        //偏移到原点，并补充砖缝偏移
                                        var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                        //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                        oT = {x: oT.x - origin.x, y: oT.y - origin.y}; //假砖缝

                                        if (frTile.rot) {
                                            var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                            var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                            var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                            var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                            var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                            var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                            var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                            oT = {x: oT.x - x - hx - lx, y: oT.y - y - wy - ly};
                                            oT = utilMathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
                                        }

                                        if (mrot != 0) {
                                            var v = utilMathRotatePointCW(mrotCenter, oT, -mrot);
                                            oT.x = v.x;
                                            oT.y = v.y;
                                        }

                                        return oT;
                                    });

                                    floorShape.holes.push(new THREE.Shape(hole));
                                });

                                var floorGeom = floorShape.makeGeometry();
                                var vertexMin = {x: 1e3, y: 1e3};
                                for (var i = 0, len = floorGeom.vertices.length; len > i; ++i) {
                                    var vertex = floorGeom.vertices[i];
                                    //vertexMin.x = Math.min(vertexMin.x, vertex.x);
                                    //vertexMin.y = Math.min(vertexMin.y, vertex.y);

                                    vertex.x -= frTile.tileIndex.th * frTile.paveW;
                                    vertex.y -= frTile.tileIndex.tv * frTile.paveH;

                                    if (mrot != 0) {
                                        var v = utilMathRotatePointCW(mrotCenter, vertex, mrot);
                                        vertex.x = v.x;
                                        vertex.y = v.y;
                                    }

                                    if (frTile.rot) {
                                        var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                        var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                        var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                        var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                        var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                                        var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                                        var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                                        var v = utilMathRotatePointCW({x: 0, y: 0}, vertex, frTile.rot.r);
                                        vertex.x = v.x + x + hx + lx;
                                        vertex.y = v.y + y + wy + ly;
                                    }

                                    //vertex.x += origin.x + gap*0.5; vertex.y += origin.y + gap*0.5; //真砖缝
                                    vertex.x += origin.x;
                                    vertex.y += origin.y;	   //假砖缝

                                    var v = utilMathRotatePointCW({
                                        x: floorRectOrigin.x,
                                        y: floorRectOrigin.y
                                    }, vertex, singlepaveRot);
                                    vertex.x = v.x;
                                    vertex.y = v.y;
                                }

                                //进行纹理缩放
                                floorGeom.faceVertexUvs[0].forEach(function (uvs) {
                                    Array.isArray(uvs) && uvs.forEach(function (uv) {
                                        uv.x /= floorModel.floorMaterial.sx;
                                        uv.y /= floorModel.floorMaterial.sy;
                                    });
                                });

                                var paveGeom = paveGeoms[0];
                                (frTile.pidIndex != null) && (paveGeom = paveGeoms[frTile.pidIndex + 1]);
                                if (paveGeom) {
                                    utilMergeGeom(floorGeom, paveGeom);
                                }
                            });
                        }
                    });
                });
            }
        });

        paveGeoms.forEach(function (geom, index) {
            var meshMat = floorMeshMat;
            (parseInt(index) > 0) && (meshMat = paveMeshMats[parseInt(index) - 1]);

            var floorMesh = new THREE.Mesh(geom, meshMat);
            floorMesh.position.set(0, 0, 0);
            floorMesh.name = (parseInt(index) > 0) ? ("pave" + (parseInt(index) - 1)) : "floor";
            floor3d.add(floorMesh);
        });
    }


    //高亮区域
    var floorInsideShape = new THREE.Shape(insideProfile);
    var floorInsideGeom = floorInsideShape.makeGeometry();
    var vertexMin = {x: 1e3, y: 1e3};
    for (var i = 0, len = floorInsideGeom.vertices.length; len > i; ++i) {
        var vertex = floorInsideGeom.vertices[i];
        vertexMin.x = Math.min(vertexMin.x, vertex.x), vertexMin.y = Math.min(vertexMin.y, vertex.y);
    }
    floorInsideGeom.faceVertexUvs[0].forEach(function (uvs) {
        Array.isArray(uvs) && uvs.forEach(function (uv) {
            uv.x -= vertexMin.x, uv.y -= vertexMin.y;
        });
    });
    var highlightMat = new THREE.MeshBasicMaterial({
        color: 15790144,
        transparent: !0,
        opacity: .15
    });
    var floorOutline = new THREE.Mesh(floorInsideGeom, highlightMat);
    floorOutline.position.set(0, 0, 0.00001);
    floorOutline.name = "floor_highlight";
    floorOutline.visible = !1;
    floorOutline.raycastable = !1;
    floor3d.add(floorOutline);
    room3d.add(floor3d);

    //天花板    
    for (var ceilingShape = new THREE.Shape(profile), ceilingGeom = ceilingShape.makeGeometry(), vertexMin = {
        x: 1e3,
        y: 1e3
    }, i = 0, len = ceilingGeom.vertices.length; len > i; ++i) {
        var vertex = ceilingGeom.vertices[i];
        vertexMin.x = Math.min(vertexMin.x, vertex.x), vertexMin.y = Math.min(vertexMin.y, vertex.y);
    }
    ceilingGeom.faceVertexUvs[0].forEach(function (uvs) {
        Array.isArray(uvs) && uvs.forEach(function (uv) {
            uv.x -= vertexMin.x, uv.y -= vertexMin.y;
        });
    });
    var roomHeight3d = floorModel.height3d;
    var ceiling3d = new THREE.Object3D();
    ceilingGeom.faces.forEach(function (f) {
        var b = f.b;
        f.b = f.c, f.c = b;
    });
    //反转uv坐标 add by hcw
    ceilingGeom.faceVertexUvs[0].forEach(function (f) {
        var c = f[1];
        f[1] = f[2], f[2] = c;
    });
    ceilingGeom.computeFaceNormals();
    var ceilingMeshMat = utilThreeViewCreateTileMaterial(view, floorModel.ceilingMaterial, {});
    ceilingMeshMat.side = THREE.FrontSide;
    var ceilingMesh = new THREE.Mesh(ceilingGeom, ceilingMeshMat);
    ceilingMesh.position.set(0, 0, roomHeight3d), ceilingMesh.name = "ceiling", ceiling3d.add(ceilingMesh);
    var ceilingOutline = new THREE.Mesh(ceilingGeom, highlightMat);
    ceilingOutline.name = "ceiling_highlight";
    ceilingOutline.visible = !1;
    ceilingOutline.raycastable = !1;
    ceilingOutline.position.set(0, 0, roomHeight3d);
    ceiling3d.add(ceilingOutline);
    room3d.add(ceiling3d);

    return room3d;
}
/*
 DisplayThreeFloor
 */

function DisplayThreeFloor(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplayThreeFloor, DisplayObject);
var DisplayThreeFloorTextureLoadingCompleteFlag = 1 << 17;

utilExtend(DisplayThreeFloor.prototype, {
    create: function () {
        if (classBase(this, "create"), void 0 == this.de) {
            this.de = new THREE.Object3D();
            this.de.did = this.de.name = this.id;
            var room3d = utilThreeCreateFloorAndCeiling(this);
            this.de.add(room3d);
        }
        this.view.layers[this.model.type].add(this.de);

        var propertyChangedFun = function (propertyName, oldValue, newValue) {
            //if ("flag" == propertyName) {
            //    if ((oldValue & FLOORFLAG_CHANGED_FOR_REDRAWN) != (newValue & FLOORFLAG_CHANGED_FOR_REDRAWN)) {
            //        this.dF |= 1;
            //    } else if ((oldValue & FLOORFLAG_HIDE_CEILING) != (newValue & FLOORFLAG_HIDE_CEILING)) {
            //        this.dF |= 8;
            //    } else {
            //        this.dF |= 4;
            //    }
            //} else if ("height3d" == propertyName && (this.dF |= 1)) {
            //    //...
            //} else{
            //	"paveType" == propertyName && (this.dF |= 1); 
            //}
            if (propertyName instanceof Material) {
                "rot" != oldValue && "tx" != oldValue && "ty" != oldValue && "sx" != oldValue && "sy" != oldValue || (this.dF |= 2);
            } else if ("flag" == propertyName) {
                ((oldValue & FLOORFLAG_CHANGED_FOR_REDRAWN) != (newValue & FLOORFLAG_CHANGED_FOR_REDRAWN) && (this.dF |= 1));
                ((oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 2));
                ((oldValue & MODELFLAG_LOCKED) != (newValue & MODELFLAG_LOCKED) && (this.dF |= 2));
            } else if ((oldValue & FLOORFLAG_HIDE_CEILING) != (newValue & FLOORFLAG_HIDE_CEILING)) {
                this.dF |= 8;
            } else if ("floorMaterial" == propertyName) {
                this.dF |= 2;
            } else if ("paveType" == propertyName || "height3d" == propertyName) {
                this.dF |= 1;
                this.model.clearPaveDB();
                this.model.paveRebuild = true;
            } else if ("gapwidth" == propertyName || "gapcolor" == propertyName) {
                this.dF |= 1;
                this.model.paveRebuild = true;
            } else {
                this.dF |= 1;
            }
        }.bind(this);

        var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
            this.dF |= 1;
            this.dF |= 2;
        }.bind(this);

        var linkPropertyChangedFun = function (changedLinkEntity, propertyName) {
            if (changedLinkEntity instanceof Point && ("x" == propertyName || "y" == propertyName)) {
                this.dF |= 1;
            }

            if (changedLinkEntity instanceof Material) {
                this.dF |= 1;
                this.dF |= 2;
            }
        }.bind(this);

        this.model.propertyChangedEvent.add(propertyChangedFun);
        this.model.linksChangedEvent.add(linksChangedFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    update: function () {
        //重置铺砖
        this.model.rebuild();

        var view = this.view;
        var floorModel = this.model;
        var fMat = floorModel.floorMaterial;
        var cMat = floorModel.ceilingMaterial;
        /*TOFIX 这一句貌似没用，适时删除*/
        /*自定义拼花不能画房间地面 isNotCustomTile add by oxl 2017-04-13*/
        if (0 != (1 & this.dF)) {
            if (this.model.redrawn3D) {
                var children = this.de.children.slice(0);
                children.forEach(function (d) {
                    this.de.remove(d);
                }.bind(this));
                var room3d = utilThreeCreateFloorAndCeiling(this);
                this.de.add(room3d);
                this.model.redrawn3D = false;
            }
        }
        if (0 != (2 & this.dF)) {
            //var floorMeshMat = utilThreeViewCreatePaveTileMaterial(view, floorModel.floorMaterial, {});
            //var matScale
            //fMat && (matScale = fMat.getScale(), floorMeshMat.scUniform1 = [utilMathToRadius(-fMat.rot), fMat.tx, fMat.ty, 0], floorMeshMat.scUniform2 = [matScale.x, matScale.y, 0, 0]);

            var ceilingMeshMat = utilThreeViewCreateTileMaterial(view, floorModel.ceilingMaterial, {});
            this.de.traverse(function (child) {
                "ceiling" == child.name && (child.material = ceilingMeshMat);
            });

            var selected = utilModelIsFlagOn(this.model, MODELFLAG_PICKED), pickInfo = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            this.de.traverse(function (child) {
                return -1 != child.name.indexOf("highlight") ? 0 == selected ? void (child.visible = !1) : void (pickInfo && "ceiling" == pickInfo.opt.elementName ? (child.visible = !1,
                -1 != child.name.indexOf("ceiling") && (child.visible = !0)) : (pickInfo && "floor" == pickInfo.opt.elementName || pickInfo && "2d" == pickInfo.opt.src) && (child.visible = !1,
                -1 != child.name.indexOf("floor") && (child.visible = !0))) : void 0;
            });
        }
        if (0 != (8 & this.dF)) {
            var showCeiling = utilModelIsFlagOff(this.model, FLOORFLAG_HIDE_CEILING);
            this.de.traverse(function (child) {
                "ceiling" == child.name && (child.visible = showCeiling);
            });
        }
    },
    destroy: function () {
        this.view.layers[this.model.type].remove(this.de);
    }
})


//===============商品清单计算 oxl0927 2017-11-17完成 TODO优化性能 ===================
//统计瓷砖各种规格的数量 -oxl0927
function utilTileAmountCount(arr) {
    var _arr = arr;
    var _res = []; //
    _arr.sort();
    for (var i = 0; i < _arr.length;) {
        var count = 0;
        for (var j = i; j < _arr.length; j++) {
            if (_arr[i] == _arr[j]) {
                count++;
            }
        }
        _res.push([_arr[i], count]);
        i += count;
    }
    //_res 二维数维中保存了 值和值的重复数
    var _newArr = [];
    //var _newArr = {};
    for (var i = 0; i < _res.length; i++) {
        var obj = {}, key = _res[i][0];
        obj.value = key;
        obj.count = _res[i][1]
        // _newArr[key]=obj;
        _newArr.push(obj);
    }

    return _newArr
}

//向上取整且保留小数点后几位:4位 -> utilCeilDecimals(number,4,10000) -oxl0927
function utilCeilDecimals(num, decimal, gutter) {
    return Math.ceil(num.toFixed(decimal) * gutter) / gutter
}


function genPerimeterItemData(model, frTile, points, hasSubTile) {
    //points 代表一块砖4个坐标点-> 右上 左上 左下 右下 oxl0927
    //1.计算4个点的长度，保存一个数组，用来区分单块砖的数量
    //2.长方形：计算两条边的长度计算面积，三角形：用海伦公式，s=1/2周长，s(s-a)(s-b)(s-c) 的 开方，自由形状：长方形；
    // 圆型用 roundarea获取半径
    var tempmArray = [], tempPerimeter = 0;
    // 有子砖时直接当四边形计算
    if (hasSubTile == true) {
        tempmArray.push(frTile.paveH);
        tempmArray.push(frTile.paveW);
        tempPerimeter = ( frTile.paveH * 1 + frTile.paveW * 1 ) * 2;
    } else {
        switch (model.type) {
            case "RECTAREA":
            case "FLOOR":
            case "WALLBOARD":
            case "RECTAREA3D":
                if (points.length <= 4 && model.singlepaveRot == 0) {
                    //计算2条边相加的周长
                    var a1 = utilCeilDecimals(utilMathLineLength(points[0], points[1]), 3, 1000);
                    var a2 = utilCeilDecimals(utilMathLineLength(points[1], points[2]), 3, 1000);
                    tempPerimeter = ( a1 + a2 ) * 2;
                    tempmArray.push(a1), tempmArray.push(a2);
                } else {
                    //TODO 整合为方法 计算各条边相加的周长，类型为长方形，但剪切后需要重新计算
                    for (var i = 0; i <= points.length - 1; i++) {
                        var tempNum;
                        tempNum = utilCeilDecimals(utilMathLineLength(points[i], points[i + 1]), 3, 1000);
                        if (i == points.length - 1) {
                            tempNum = utilCeilDecimals(utilMathLineLength(points[i], points[0]), 3, 1000);
                        }

                        tempmArray.push(tempNum);
                        tempPerimeter += tempmArray[i];

                    }
                }

                break;
            case "FREEAREA":
            case "ROUNDAREA":
            case "BOUNDARY":
            case "ROUNDAREA3D":

                //fun()
                //计算各条边相加的周长
                for (var i = 0; i <= points.length - 1; i++) {
                    var tempNum;
                    tempNum = utilCeilDecimals(utilMathLineLength(points[i], points[i + 1]), 3, 1000);
                    if (i == points.length - 1) {
                        tempNum = utilCeilDecimals(utilMathLineLength(points[i], points[0]), 3, 1000);
                    }

                    tempmArray.push(tempNum);
                    tempPerimeter += tempmArray[i];

                }
                break;
        }
    }


    frTile.sideLength = tempmArray;
    //var tempmArrayMaxMin=tempmArray;
    //tempmArrayMaxMin.sort(function(a,b){return b-a});
    //实际的高/长，宽
    var rectH = tempmArray[0], rectW = tempmArray[1];

    //各个规格的数组，备用
    window.tempPerimeterArr.push(utilCeilDecimals(tempPerimeter, 3, 1000));
    //插入周长
    frTile.perimeter = utilCeilDecimals(tempPerimeter, 3, 1000);
    //插入高宽
    frTile.rectH = utilCeilDecimals(rectH, 3, 1000) , frTile.rectW = utilCeilDecimals(rectW, 3, 1000);
    window.tempPerimeterItemObj = {}
    window.tempPerimeterItemObj.perimeter = frTile.perimeter,
        window.tempPerimeterItemObj.rectH = frTile.rectH,
        window.tempPerimeterItemObj.rectW = frTile.rectW
    window.tempPerimeterItemObjArr.push(this.tempPerimeterItemObj);
    tempmArray.forEach(function (v, i) {
        if (v == 0) {
            frTile.notCount = true;
            window.tempPerimeterItemObj.notCount = true;
        }
    })
}
//计算波打线的实际长宽
function genBoundaryItemWH(points) {
    var tempmArray = [];
    for (var i = 0; i <= points.length - 1; i++) {
        var tempNum;
        tempNum = utilCeilDecimals(utilMathLineLength(points[i], points[i + 1]), 3, 1000);
        if (i == points.length - 1) {
            tempNum = utilCeilDecimals(utilMathLineLength(points[i], points[0]), 3, 1000);
        }
        tempmArray.push(tempNum);
    }

    //实际的高/长，宽
    var rectH = Math.max.apply(null, tempmArray), rectW = Math.min.apply(null, tempmArray);
    var cornerBoundaryWH = {rectH: rectH, rectW: rectW};
    return cornerBoundaryWH
}


//计算面积
function genMeasurementItemData(model, frTile, points, hasSubTile) {

    var tempMeasurement, rectH, rectW;
    //有子砖时，直接当是一块整砖
    if (hasSubTile == true) {
        tempMeasurement = (frTile.paveH * 1) * (frTile.paveW * 1);
    } else {
        //多边形面积
        tempMeasurement = utilCeilDecimals(utilMathPolyMeasurement(points), 3, 1000)
    }

    //各个规格的数组，备用
    window.tempMeasurementArr.push(tempMeasurement);
    //插入面积到砖块
    frTile.measurement = tempMeasurement;


    window.tempMeasurementItemObj = {}
    if (tempMeasurement == 0) {
        window.tempMeasurementItemObj.notCount = true;
    }

    rectH = frTile.rectH, rectW = frTile.rectW;
    if (model.type == "BOUNDARY") {
        //获取波打线的真实长宽
        var cornerBoundaryWH = genBoundaryItemWH(points);
        rectH = cornerBoundaryWH.rectH;
        rectW = cornerBoundaryWH.rectW;
        //覆盖原砖裁减后的尺寸
        frTile.rectH = rectH;
        frTile.rectW = rectW;
    }

    window.tempMeasurementItemObj = {
        measurement: tempMeasurement,
        rectH: rectH,
        rectW: rectW,
        paveH: frTile.paveH,
        paveW: frTile.paveW
    }

    window.tempMeasurementItemObjArr.push(this.tempMeasurementItemObj);
    if (model.type == "BOUNDARY") {
        var cornerMatId = model.cornerMaterial.id,
            leftMatId = model.leftMaterial && model.leftMaterial.id,
            rightMatId = model.rightMaterial && model.rightMaterial.id,
            frTileBounaryMatId = frTile.bounaryMaterialId, a = 1;
        //model(实例)里面[cornerMaterial]对象添加切砖数据(来自[model.clipedTiles]过滤出角砖数据);
        //model.clipedTiles.forEach(function(clipedTile,index){//tile 波打线实例-单块砖
        if (frTileBounaryMatId == cornerMatId || frTileBounaryMatId == leftMatId && (a = 2) || frTileBounaryMatId == rightMatId && (a = 3)) {//相等时就是顶角，辅助左顶角，辅助右顶角
            if (frTile.measurement > 0) {//有面积才插入数据到cornerMaterial
                a == 1 && model.cornerMaterial.clipedTiles.push(frTile);
                a == 2 && model.leftMaterial.clipedTiles.push(frTile);
                a == 3 && model.rightMaterial.clipedTiles.push(frTile);
            }
            window.tempMeasurementArr.pop();
            //存到cornerMaterial后删除这个tile
        }
    }
    return window.tempMeasurementItemObjArr
}

//计算用砖-oxl0927
//application.views.2d.dl.xxxxxid,dl->display list -oxl0927
//转换后要用snap.path转成matrix
function utilSnapAreaCreateClipPathString(areaModel, offset) {
    var geom, svgString = "", profile = areaModel, factor = 100;
    if (profile.length < 3) return "";
    for (var i = 0, len = profile.length; len > i; ++i) {
        var pt = profile[i];
        __assert(!isNaN(pt.x) && !isNaN(pt.y)), svgString += (0 == i ? "M" : "L") + Math.round(pt.x * factor) + "," + Math.round(-pt.y * factor);
    }
    return svgString += "Z";
}

function utilBoundaryCreateSvgPath(subTileProfile, frTile, model, index) {
    var floorRectOrigin = frTile.floorRectOrigin;
    var gap = model.gapwidth
    var singlepaveRot = frTile.singlepaveRot;
    //step2 对所有铺砖生成纹理(实际用砖)
    //重置element列表
    frTile.elements = [];
    //裁剪
    var pos = frTile.pos;
    var origin = frTile.origin;
    if (subTileProfile) {
        subTileProfile = subTileProfile.map(function (t) {
            var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
            oT = {x: oT.x - origin.x, y: oT.y - origin.y};   //假砖缝(砖与砖之间不留砖缝)

            if (frTile.rot) {
                var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                var l = Math.sqrt(frTile.paveW * frTile.paveW + frTile.paveH * frTile.paveH);
                var lx = frTile.rot.lx != null ? l * frTile.rot.lx : 0;
                var ly = frTile.rot.ly != null ? l * frTile.rot.ly : 0;

                oT = {x: oT.x - x - hx - lx, y: oT.y - y - wy - ly};
                oT = utilMathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
            }

            return oT;
        });
        var path = utilSnapFloorCreatePathFromLoop(subTileProfile);
        tm = new Snap.Matrix();
        path = Snap.path.map(path, tm);
        model.svgstr["clippaths"].push(path);
    }
}

var productTopUrl = function (id) {
    return "https://pic.oceano.com.cn/h5filesystem/products/" + id + "/top.jpg"
}
//生成订单-获取已存在的 patternId oxl0927
//参考 utilSnapFloorGetMaterial 方法 oxl1122
function utilOrderListFloorGetMaterial(floor, side) {
    window.tempParentSvg == undefined ? window.tempParentSvg = Snap("100%", "100%").attr({
        title: "仅存放Pattern用",
        class: "tempParentSvg",
        id: "tempParentSvg"
    }) : "";
    var sideMaterial = side + "Material";

    window.bomPattern == undefined ? (window.bomPattern = {}) : "";

    if (floor.floorRectTiles.length > 0) {
        var material = floor.floorRectTiles[0].material;
    } else {
        return;
    }


    //floor area 结构需要的pid和id
    var pid = floor.pid;
    var patternId = floor.materialid

    //波打线需要的pid和id base
    //顶角需要的pid和id  corner
    //左顶角辅助砖需要的pid和id left
    //右顶角辅助砖需要的pid和id right
    if (side == "base" || side == "corner" || side == "left" || side == "right") {
        material = floor[sideMaterial],
            pid = floor[sideMaterial].pid,
            patternId = floor[sideMaterial].id;
    }


    var pattern = bomPattern[patternId];
    if (!pattern) {
        var meta = material.meta;
        if (!meta.xlen || !meta.ylen) {
            return "";
        }
        var width = 100 * meta.xlen * material.sx;
        var height = 100 * meta.ylen * material.sy;
        var imageUrl = productTopUrl(pid);
        var pattern = tempParentSvg.image(imageUrl, 0, 0, width, height).toPattern(0, 0, width, height).attr({
            id: patternId
        });
        bomPattern[patternId] = pattern;
    }

    return "url(#" + patternId + ")";
}

function utilFloorTileAmountCompute(model, resolve) {
    window.tempMeasurementItemObj = {};
    window.tempMeasurementItemObjArr = [];
    window.tempMeasurementArr = [];

    window.tempPerimeterItemObj = {};
    window.tempPerimeterItemObjArr = [];
    window.tempPerimeterArr = [];
    var fillUrl = "";
    switch (model.type) {
        case "RECTAREA":
        case "ROUNDAREA":
        case "FREEAREA":
            fillUrl = utilOrderListFloorGetMaterial(model, "area")
            // fillUrl = "url(#" + model.materialid + ")";
            break;
        case "BOUNDARY":
            fillUrl = utilOrderListFloorGetMaterial(model, "base");
            // fillUrl = "url(#" + model.floorRectTiles[0].material.id + ")";
            //顶角，顶角辅助砖（leftMaterial+rightMaterial） 暂时不画出到svg,【utilOrderListFloorGetMaterial】方法已经预留 -2017-11-21
            if (model.corner == "corner") {
                //utilOrderListFloorGetMaterial(model, "corner");
            }
            //model.leftMaterial && utilOrderListFloorGetMaterial(model, "left");
            //model.rightMaterial && utilOrderListFloorGetMaterial(model, "right");

            model.cornerMaterial.clipedTiles = [];//存储波打线个角的砖
            model.leftMaterial && (model.leftMaterial.clipedTiles = []);
            model.rightMaterial && (model.rightMaterial.clipedTiles = []);
            break;
        case "FLOOR":
            fillUrl = utilOrderListFloorGetMaterial(model, "floor");//"url(#" + model.materialid + ")";
            // fillUrl ="url(#" + model.materialid + ")";
            break;
    }

    //根据 model.perimeterCount[x] 的 index 反选对应规格的 瓷砖 meta数据，floorRectTiles[x] || clipedTile[x]的sideLength 如果有0数据，就不要输出清单
    //application.doc.floorplan.lf 获取各种 铺砖方案的 数据 -> 生成订单数据
    //缓存切砖的pattern和路径，生成清单时获取再用snap 画一次在页面 -oxl0927
    model.svgstr || (model.svgstr = {});
    model.svgstr["fillUrl"] = fillUrl;
    model.svgstr["paths"] = []
    model.svgstr["clippaths"] = []
    model.measurementCount = []

    var hasSubTile;
    var clipperProfileFlag;

    model.clipedTiles.forEach(function (clipedTile, index) {
        hasSubTile = false;
        var clipperProfile = clipedTile.clipperProfile;
        var tileProfile = clipedTile.tileProfile;
        // 有子砖时返回一个参数hasSubTile 传给 genPerimeterItemData
        if (clipperProfile.length >= 2) {
            console.log("clipperProfile.length的数量是 %o", clipperProfile.length)
            clipperProfile = [clipperProfile[0]];
            hasSubTile = true;
        }
        //波打线的计算流程
        if (model.type == "BOUNDARY") {
            tileProfile.forEach(function (subTileProfile, index2) {
                var points = subTileProfile;
                genPerimeterItemData(model, clipedTile, points, hasSubTile);
                genMeasurementItemData(model, clipedTile, points, hasSubTile);
                utilBoundaryCreateSvgPath(subTileProfile, clipedTile, model, index)
                if ((index2 + 1) == tileProfile.length) {
                    clipperProfileFlag = true;
                }
            })
        } else {
            //其他区域的计算流程
            clipperProfile.forEach(function (subTileProfile, index2) {
                //subTileProfile 代表一块砖4个坐标点 oxl0927
                var points = subTileProfile;
                genPerimeterItemData(model, clipedTile, points, hasSubTile);
                genMeasurementItemData(model, clipedTile, points, hasSubTile);

                var matrix = new Snap.Matrix();
                var clippaths = Snap.path.map(utilSnapFloorCreatePathFromLoop(points, 0), matrix);

                model.svgstr["clippaths"].push(clippaths);

                if ((index2 + 1) == clipperProfile.length) {
                    clipperProfileFlag = true;
                }

            })

        }


        if ((index + 1) == model.clipedTiles.length && clipperProfileFlag) {
            //数量，宽高，统计砖数，绑定后，直接放在model上-oxl0927
            model.perimeterCount = utilTileAmountCount(window.tempPerimeterArr);
            model.perimeterCount.length > 0 ? model.perimeterCount.some(function (v1, index1) {
                window.tempPerimeterItemObjArr.some(function (v2, index2) {
                    if (v1.value == v2.perimeter) {
                        v1.rectH = v2.rectH,
                            v1.rectW = v2.rectW,
                            v1.index = index2;
                        if (v2.notCount) {
                            v1.notCount = true;
                        }
                        return true
                    }
                });
            }) : null

            //数组去重并统计数量
            model.measurementCount = utilTileAmountCount(window.tempMeasurementArr);
            model.measurementCount.length > 0 ? model.measurementCount.some(function (v1, index1) {
                window.tempMeasurementItemObjArr.some(function (v2, index2) {
                    if (v1.value == v2.measurement) {
                        v1.paveH = v2.paveH,
                            v1.paveW = v2.paveW,
                            v1.rectH = v2.rectH,
                            v1.rectW = v2.rectW,
                            v1.index = index2;
                        if (v2.notCount) {
                            v1.notCount = true;
                        }
                        return true
                    }
                });
            }) : null;

            if (resolve) {

                resolve();

            }
        }
    });
}


//生成墙体的pattern-oxl-20180225
function utilSnapWallGetMaterial(floor, side) {
    window.tempParentSvg == undefined ? window.tempParentSvg = Snap("100%", "100%").attr({
        title: "仅存放Pattern用",
        class: "tempParentSvg",
        id: "tempParentSvg"
    }) : "";
    var sideMaterial = side + "Material";

    window.bomPattern == undefined ? (window.bomPattern = {}) : "";

    if (floor.floorRectTiles.length > 0) {
        var material = floor.floorRectTiles[0].material;
    } else {
        return;
    }

    var pid, patternId;

    //波打线需要的pid和id base
    //顶角需要的pid和id  corner
    //左顶角辅助砖需要的pid和id left
    //右顶角辅助砖需要的pid和id right
    if (side == "area") {
        material = floor[sideMaterial],
            pid = floor[sideMaterial].pid,
            patternId = floor[sideMaterial].id;
    }


    var pattern = bomPattern[patternId];
    if (!pattern) {
        var meta = material.meta;
        if (!meta.xlen || !meta.ylen) {
            return "";
        }
        var width = 100 * meta.xlen * material.sx;
        var height = 100 * meta.ylen * material.sy;
        var imageUrl = productTopUrl(pid);
        var pattern = tempParentSvg.image(imageUrl, 0, 0, width, height).toPattern(0, 0, width, height).attr({
            id: patternId
        });
        bomPattern[patternId] = pattern;
    }

    return "url(#" + patternId + ")";
}

function utilWallTileAmountCompute(model, resolve) {
    window.tempMeasurementItemObj = {};
    window.tempMeasurementItemObjArr = [];
    window.tempMeasurementArr = [];

    window.tempPerimeterItemObj = {};
    window.tempPerimeterItemObjArr = [];
    window.tempPerimeterArr = [];
    var fillUrl = "";
    fillUrl = utilSnapWallGetMaterial(model, "area");

    //根据 model.perimeterCount[x] 的 index 反选对应规格的 瓷砖 meta数据，floorRectTiles[x] || clipedTile[x]的sideLength 如果有0数据，就不要输出清单
    //application.doc.floorplan.lf 获取各种 铺砖方案的 数据 -> 生成订单数据
    //缓存切砖的pattern和路径，生成清单时获取再用snap 画一次在页面 -oxl0927
    model.svgstr || (model.svgstr = {});
    model.svgstr["fillUrl"] = fillUrl;
    model.svgstr["paths"] = []
    model.svgstr["clippaths"] = []
    model.measurementCount = []

    var hasSubTile;
    var tileProfileFlag;

    model.floorRectTiles.forEach(function (floorRectTile, index) {
        hasSubTile = false;
        var tileProfile = floorRectTile.tileProfile;
        //计算流程
        tileProfile.forEach(function (subTileProfile, index2) {
            //subTileProfile 代表一块砖4个坐标点 oxl0927
            var points = subTileProfile;
            genPerimeterItemData(model, floorRectTile, points, hasSubTile);
            genMeasurementItemData(model, floorRectTile, points, hasSubTile);

            var matrix = new Snap.Matrix();
            var clippaths = Snap.path.map(utilSnapFloorCreatePathFromLoop(points, 0), matrix);

            model.svgstr["clippaths"].push(clippaths);

            if ((index2 + 1) == tileProfile.length) {
                tileProfileFlag = true;
            }

        })


        if ((index + 1) == model.floorRectTiles.length && tileProfileFlag) {
            //数量，宽高，统计砖数，绑定后，直接放在model上-oxl0927
            model.perimeterCount = utilTileAmountCount(window.tempPerimeterArr);
            model.perimeterCount.length > 0 ? model.perimeterCount.some(function (v1, index1) {
                window.tempPerimeterItemObjArr.some(function (v2, index2) {
                    if (v1.value == v2.perimeter) {
                        v1.rectH = v2.rectH,
                            v1.rectW = v2.rectW,
                            v1.index = index2;
                        if (v2.notCount) {
                            v1.notCount = true;
                        }
                        return true
                    }
                });
            }) : null

            //数组去重并统计数量
            model.measurementCount = utilTileAmountCount(window.tempMeasurementArr);
            model.measurementCount.length > 0 ? model.measurementCount.some(function (v1, index1) {
                window.tempMeasurementItemObjArr.some(function (v2, index2) {
                    if (v1.value == v2.measurement) {
                        v1.paveH = v2.paveH,
                            v1.paveW = v2.paveW,
                            v1.rectH = v2.rectH,
                            v1.rectW = v2.rectW,
                            v1.index = index2;
                        if (v2.notCount) {
                            v1.notCount = true;
                        }
                        return true
                    }
                });
            }) : null;

            if (resolve) {
                resolve();

            }
        }
    });


}


function localPromise(fun) {
    return new Promise(function (resolve, reject) {
        fun(resolve, reject);
    });
}
//移除订单-获取已存在的 patternId
function removeTempParentSvg() {
    if (window.tempParentSvg) {
        window.tempParentSvg.remove()
        window.tempParentSvg = undefined
        window.bomPattern = undefined;
    }
}
//===============商品清单计算 oxl0927 2017-11-17完成 TODO优化性能 ===================

// sourceURL=src\display\floor.js