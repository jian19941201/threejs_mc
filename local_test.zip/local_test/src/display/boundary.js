//取得波打线的内外线


function utilSnapBoundaryGetMaterial(displayBoundary, side, index, patternCallback) {	  
    var boundary = displayBoundary.model;
    var loop = boundary[side + "Loops"][index];
    var view = displayBoundary.view;
    __assert("2d" == view.id, "Boundary url could only be used in 2d view.");
    var mat = boundary[side + index + "Material"];
    if(mat){
    	  return utilSnapViewUpdateMaterialBoundary(displayBoundary, mat, loop, patternCallback);
    }
    return "";
}

var utilSnapViewUpdateMaterialBoundary = function (displayBoundary, material, loop, patternCallback) {
    var model = displayBoundary.model;
    var view = displayBoundary.view;
    if (!material)
        return "";
        
    var patternId = material.id;
    utilSnapViewCreatePattern(view, material, patternId, function (pattern) {
        if (pattern && pattern.transform) {
            var mat = material;
            //左下角坐标
            
            var rot = mat?mat.rot:0;
            var p1 = loop[0], p2 = loop[1];
            var modelBottomLeft = {
                x: (p2.x + Math.cos((rot - 90)*Math.PI/180.0) * model.size),
                y: (p2.y + Math.sin((rot - 90)*Math.PI/180.0) * model.size)
            };
                        
            var scale = mat ? mat.getScale() : {
                x: 1,
                y: 1
            };
            var translate = {
                x: mat ? mat.tx : 0,
                y: mat ? mat.ty : 0
            };
            pattern.transform("T" + toFixedNumber(100 * modelBottomLeft.x, 3) + "," + toFixedNumber(-100 * modelBottomLeft.y, 3) + "r" + (-rot) + "S" + toFixedNumber(scale.x, 3) + "," + toFixedNumber(scale.y, 3) + "T" + toFixedNumber(100 * translate.x, 3) + "," + toFixedNumber(-100 * translate.y, 3)),
            patternCallback && patternCallback.call(displayBoundary, pattern);            
        }
    })
    return "url(#" + patternId + ")";
}

/*
DisplaySnapBoundary
*/
function DisplaySnapBoundary(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplaySnapBoundary, DisplayObject);

utilExtend(DisplaySnapBoundary.prototype, {
    create: function () {
        classBase(this, "create");
        
        this.de = [];  //主体
        this.hl = [];  //高亮
                        
        var updateFun = function (propertyName, oldValue, newValue) {
            if(propertyName instanceof Material){
            //	"rot" != oldValue && "tx" != oldValue && "ty" != oldValue && "sx" != oldValue && "sy" != oldValue || (this.dF |= 2);
                this.dF |= 2;
            }else if("flag" == propertyName){
            	if((oldValue & BOUNDARY_CHANGED_FOR_REDRAWN) != (newValue & BOUNDARY_CHANGED_FOR_REDRAWN)){            		
            		utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_LOOPS);
            		utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_MATERIALS);
            		this.dF |= 1;
            		this.model.paveRebuild = true;            	  
            	};
            	((oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 8));
            //}else if("label" == propertyName){
            //	this.dF |= 4;
            //}else if("labelX" == propertyName || "labelY" == propertyName){
            //	this.dF |= 8;
            }
            //else if("cornerMaterial" == propertyName || 
            //	       "baseMaterial" == propertyName || 
            //	       "rightMaterial" == propertyName || 
            //	       "leftMaterial" == propertyName){
            //	  utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_LOOPS);
            //	  utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_MATERIALS);            	  
            //	  this.dF |= 1;
            //	  this.model.paveRebuild = true;
            //}
            else if(propertyName.indexOf("Material") != -1){
            	  utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_LOOPS);
            	  utilModelSetFlagOn(this.model, BOUNDARY_DETAILEDUPDATED_MATERIAL);
            	  this.dF |= 1;
            	  this.model.paveRebuild = true;
            }else if(oldValue == "add" && (newValue instanceof Floorplan || newValue instanceof RectArea || newValue instanceof FreeArea)){
        	  	  utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_LOOPS);
        	      utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_MATERIALS);
        	      this.dF |= 1;
        	      this.model.paveRebuild = true;        	      
            }else if("cornerRot" == propertyName ||
            	       "baseRot" == propertyName ||
            	       "leftRot" == propertyName ||
            	       "rightRot" == propertyName){
            	  utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_MATERIALS);
            	  this.dF |= 1;
            	  this.model.paveRebuild = true;
            }else if ("paveType" == propertyName) {
                this.dF |= 1;
                this.model.paveRebuild = true;
            }else if ("gapwidth" == propertyName || "gapcolor" == propertyName) {
                this.dF |= 1;
                this.model.paveRebuild = true;
            }else if(newValue instanceof Material){
            	  newValue.ignoreUV = true;
            }else if("level" == propertyName){
            	this.dF |= 16;
            }
        }.bind(this);
        
        var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {            
            //if(changeFrom instanceof Floorplan){
            //    this.dF |= 1;
            //}else if(changeFrom instanceof Material){
            //	  this.dF |= 2;
            //}
            
            if(propertyName instanceof Material){
            	 //utilModelChangeFlag(this.model, BOUNDARY_DETAILEDUPDATED_MATERIAL);
            	 utilModelSetFlagOn(this.model, BOUNDARY_REBUILD_MATERIALS);
            	 this.dF |= 1;
            	 this.model.paveRebuild = true;
            };            
        }.bind(this);
        
        this.model.propertyChangedEvent.add(updateFun);
        this.model.linksChangedEvent.add(updateFun);
        this.model.linkPropertyChangedEvent.add(linksChangedFun);
    },
    rebuildDisplay: function(){
    	  this.removeAll();
    	  
    	  var context = this.view.context;
               
        var view = this.view;
        if (context) {
        	if(this.model.floorRectTiles && this.model.floorRectTiles.length > 0){
        		var style = context.g().attr({did:this.id});
        		style.add(utilBoundaryCreateSnapStyles(this));
        		this.de.push(style);
        		
        		var buildLoops = function(name){
        			for(var i=0;i<this.model[name+"Loops"].length;++i){ 
        				if(this.model[name+"Loops"][i].length >= 3){       				
			        		var path = utilSnapFloorCreatePathFromLoop(this.model[name+"Loops"][i]);
				          var highlight = context.path(path).attr({
		                fill: "#707000",
		                "fill-opacity": .05,
		                "stroke-width": 0
		              });
				          this.hl.push(highlight);
				          this.de.push(highlight);
				        }
		        	}
        		}.bind(this);
        		
        		buildLoops("base");
        		buildLoops("corner");
        		buildLoops("left");
        		buildLoops("right");
	        	            
            if(this.model.host.type == "FLOOR"){
            	var layer = this.view.layers[Boundary.prototype.type];
            	layer.add(this.de);
            }else{
            	utilSnapAreaLevelUpdated(this.view, this.model);
            }
        	}        	
        }
    },
    update: function () {
    	  this.model.updateLoops();
        this.model.updateMaterial();
        this.model.rebuild();
        
        if (0 != (1 & this.dF)) {
        	this.rebuildDisplay();
        }
               
        if (0 != (8 & this.dF)) {
        	  var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
        	  for(var i=0;i<this.hl.length;++i){
        	  	  var highlight = this.hl[i];
        	  	  highlight.attr({
		                "fill-opacity": void 0 != picked ? .65 : .05
		            });
        	  }            
        }
        if (0 != (16 & this.dF) && this.model.host.type != "FLOOR" && utilSnapAreaLevelUpdated(this.view, this.model)){
        }
    },
    removeAll: function (){
    	  this.de.forEach(function (ele) {
            ele.remove();
        });
        this.de = [];
        
        //this.hl.forEach(function (ele) {
        //    ele.remove();
        //});
        this.hl = [];
    },
    destroy: function () {
    	  this.removeAll();
    }
})

function utilBoundaryCreateSnapStyles(display){
	  var clipperFactor = 10000.0;//clipper缩放因子	  
	  var model = display.model;
	  var gap = model.gapwidth;  //砖缝
	  var fp = display.view.doc.floorplan;
	  var context = display.view.context;
	  var cpr = new ClipperLib.Clipper();
	  var ret = [];
	  
	  if(model.floorRectTiles){
	  	model.floorRectTiles.forEach(function(floorRectTile){	  		
		    var materialInfo = null;
		  	
		  	var fillUrl = "";
		  	var profile = floorRectTile.profile;
		  	var styleName = floorRectTile.name+"_"+floorRectTile.index;
		  	 
		  	materialInfo = utilSnapFloorGetMaterialInfo(display, floorRectTile.name);
		  			  	
		    if(profile){
		    	//生成砖缝颜色底
		    	var path = utilSnapFloorCreatePathFromLoop(profile);
		      var root = context.path(path);		        
		      root.attr({
		  	  	  fill: "#"+model.gapcolor,
		  	  	  "stroke-width": 0,
		  	  	  "stroke-opacity": 1,
		  	  	  did: display.id               
		      })
		      root.name = styleName;
		      ret.push(root);
		    	
				  var floorRectOrigin = floorRectTile.floorRectOrigin;
				  var singlepaveRot = floorRectTile.singlepaveRot;
				  //var isSquare = model.isSquare;
				  
			  	//step2 对所有铺砖生成纹理(实际用砖)
			  	if(floorRectTile.tiles){
				  	floorRectTile.tiles.forEach(function(frTile){
				  		//重置element列表
				  		frTile.elements = [];
					  	//裁剪              
					  	var tileProfile = frTile.tileProfile;
				  		if(tileProfile){	  			
				  			tileProfile.forEach(function(subTileProfile,subTileIndex){
				  				var pos = frTile.pos;
					  			var origin = frTile.origin;
					    		subTileProfile = utilAdaptorClipperOffset(subTileProfile, -gap*0.5);
					    		if(subTileProfile){                                                             
									    subTileProfile = subTileProfile.map(function(t){                                 
												  //偏移到原点，并补充砖缝偏移
												  //var patternPos = utilMathRotatePointCW({x:0,y:0}, {x:p.x - pos.x, y:p.y - pos.y}, singlepaveRot);
												  //return {x:patternPos.x - gap*0.5, y:patternPos.y - gap*0.5};             
												  var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
												  //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
												  oT = {x:oT.x - origin.x, y:oT.y - origin.y};   //假砖缝(砖与砖之间不留砖缝)
												  
												  if(frTile.rot){
												  	var x = frTile.rot.x != null ? frTile.rot.x*frTile.tileW : 0;
									    	    var y = frTile.rot.y != null ? frTile.rot.y*frTile.tileH : 0;
									    	    var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.tileH : 0;
									    	    var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.tileW : 0;
									    	    oT = {x:oT.x - x - hx, y:oT.y - y - wy};
									    	    oT = utilMathRotatePointCW({x:0,y:0}, oT, -frTile.rot.r);
												  }
												  
												  return oT; 
											});   	                                                                   
											                                                                           
											var mtx = new Snap.Matrix();							
											
											//铺贴旋转(所有)
											var fRm = new Snap.Matrix();
											fRm.rotate(-singlepaveRot, floorRectOrigin.x*100, -floorRectOrigin.y*100);
											mtx.add(fRm);
											
											var tm = new Snap.Matrix();                                                
											//tm.translate(100.0*(origin.x + gap*0.5), -100.0*(origin.y + gap*0.5)); //真砖缝
											tm.translate(100.0*(origin.x), -100.0*(origin.y));   //假砖缝
											mtx.add(tm);
											
											//还原旋转
											if(frTile.rot){
												var x = frTile.rot.x != null ? frTile.rot.x*frTile.tileW : 0;
							    	    var y = frTile.rot.y != null ? frTile.rot.y*frTile.tileH : 0;
							    	    var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.tileH : 0;
							    	    var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.tileW : 0;
							    	    
							    	    var tm = new Snap.Matrix();
							    	    tm.translate(100.0*(x+hx), -100.0*(y+wy));
							    	    mtx.add(tm);
							    	    
							    	    var rm = new Snap.Matrix();
							    	    rm.rotate(-frTile.rot.r, 0, 0);
							    	    mtx.add(rm);				    	    
											}
											                            
											var path = utilSnapFloorCreatePathFromLoop(subTileProfile);
											
											var mrot = 0;	
											
											if(mrot != 0){
												//随机旋转
												var rotCenter = {x:frTile.tileW*0.5*100, y:-frTile.tileH*0.5*100};
												var rm = new Snap.Matrix();                                              
												rm.rotate(mrot, rotCenter.x, rotCenter.y);       
												path = Snap.path.map(path, rm);
												
												rm = new Snap.Matrix();                                                  
											  rm.rotate(-mrot, rotCenter.x, rotCenter.y);      
											  mtx.add(rm);
											}					
										  
										  if(materialInfo){
										  	var clipPathUrl = utilSnapFloorGetClipPath(display, path, display.view.context);
										  	var s = context.image(materialInfo.url, 0, -materialInfo.height, materialInfo.width, materialInfo.height).attr({
											  //var s = context.rect(0,-materialInfo.height, materialInfo.width, materialInfo.height).attr({
											  	//fill: fillUrl,                                             
											    //did: display.id,//降低选中消耗
											    style: "clip-path:"+clipPathUrl,
											  }).transform(mtx.toTransformString());
											  
											  frTile.elements[subTileIndex] = s;                                     
											  ret.push(s); 
										  }                                                                 
									}
				  			});
				  			
				  		}
				  		
				  	});
				  }
		  	}
		  });
	  }
	            
    return ret;
}

/*
DisplayThreeBoundary
*/

function DisplayThreeBoundary(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplayThreeBoundary, DisplayObject);

var DisplayThreeBoundaryTextureLoadingCompleteFlag = 1 << 17;

utilExtend(DisplayThreeBoundary.prototype, {
    create: function () {
        classBase(this, "create");
        if(void 0 == this.de){
            this.de = new THREE.Object3D();
            this.de.did = this.de.name = this.id;
            this.view.layers[this.model.type].add(this.de);
        }
        var updateFun = function (propertyName, oldValue, newValue) {
            if(propertyName instanceof Material){
            //	"rot" != oldValue && "tx" != oldValue && "ty" != oldValue && "sx" != oldValue && "sy" != oldValue || (this.dF |= 2);
            }else if("flag" == propertyName){
            	if((oldValue & BOUNDARY_CHANGED_FOR_REDRAWN) != (newValue & BOUNDARY_CHANGED_FOR_REDRAWN)){
            		this.dF |= 1;
            	};
            	((oldValue & MODELFLAG_PICKED) != (newValue & MODELFLAG_PICKED) && (this.dF |= 8));
            }
            //else if("cornerMaterial" == propertyName || 
            //	       "baseMaterial" == propertyName || 
            //	       "leftMaterial" == propertyName || 
            //	       "rightMaterial" == propertyName){
            //	  this.dF |= 1;
            //}
            else if(propertyName.indexOf("Material") != -1){
            	  this.dF |= 1;
            }else if(oldValue == "add" && (newValue instanceof Floorplan || newValue instanceof RectArea || newValue instanceof FreeArea)){
            	  this.dF |= 1;            	             	  
            }else if("cornerRot" == propertyName ||
            	       "baseRot" == propertyName ||
            	       "leftRot" == propertyName ||
            	       "rightRot" == propertyName ||
            	       "gapwidth" == propertyName ||
            	       "gapcolor" == propertyName){            	  
            	  this.dF |= 1;
            }else if("level" == propertyName){
            	  this.dF |= 1;
            }
        }.bind(this);
        var linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
            if(propertyName instanceof Material){
            	  this.dF |= 1;
            };
            
        }.bind(this);
        this.model.propertyChangedEvent.add(updateFun);
        this.model.linksChangedEvent.add(updateFun);
        this.model.linkPropertyChangedEvent.add(linksChangedFun);
    },
    update: function () {
    	  var view = this.view;
    	  var boundaryModel = this.model;
    	  
    	  this.model.updateLoops();
        this.model.updateMaterial();
        this.model.rebuild();
    	  
        //if (0 == _utilThreeDisplayElementGetMesh(this.de).length) {
        //    var boundary3d = utilThreeCreateBoundary(this);
        //    this.de.add(boundary3d);
        //}
        
        if (0 != (1 & this.dF)) {
            var oldChildren = this.de.children.slice(0);
            oldChildren.forEach(function (oldChild) {
                _utilDisposeResource(oldChild), this.de.remove(oldChild);
            }, this);
            var boundary3d = utilThreeCreateBoundary(this);
            this.de.add(boundary3d);
        }   
        
        if (0 != (8 & this.dF)) {
            var selected = utilModelIsFlagOn(this.model, MODELFLAG_PICKED);
            this.de.traverse(function (child) {
                if(child.name.indexOf("highlight") != -1){
                	child.visible = selected;
                }
            });
        }       
    },
    destroy: function () {
    	  _utilDisposeResource(this.de);
    	  this.view.layers[this.model.type].remove(this.de);
    }
})

function utilThreeCreateBoundary(displayBoundary) {
    var view = displayBoundary.view;
    var boundaryModel = displayBoundary.model;   
        
    var cpr = new ClipperLib.Clipper();
    var fp = displayBoundary.view.doc.floorplan;
    var db = fp.database;
    var gap = boundaryModel.gapwidth;  //砖缝
    var boundary3d = new THREE.Object3D();
    var zBias = 0;
    var boundaryOffset = 4e-5 * (boundaryModel.level + 1) + zBias;
    
    if(boundaryModel.floorRectTiles){
	  	boundaryModel.floorRectTiles.forEach(function(floorRectTile){
		    var materialInfo = null;
		    var profile = floorRectTile.profile;
		    var styleName = floorRectTile.name+"_"+floorRectTile.index;
		    var material = floorRectTile.material;
		    var floorMeshMat = utilThreeViewCreatePaveTileMaterial(view, material, {}); 
		    
		    if(profile){
		    	//创建root砖缝用
			    var rootShape = new THREE.Shape(profile);
			    var rootGeom = rootShape.makeGeometry();
			    var rootMeshMat = utilThreeViewCreateTileMaterial(view, boundaryModel.rootMaterial, {});
			    var rootMesh = new THREE.Mesh(rootGeom, rootMeshMat);
			    rootMesh.position.set(0, 0, boundaryOffset - (2e-5));
			    rootMesh.name = "root";
			    boundary3d.add(rootMesh);
		    	
		    	var floorRectOrigin = floorRectTile.floorRectOrigin;
				  var singlepaveRot = floorRectTile.singlepaveRot;
				  if(floorRectTile.tiles){
				  	floorRectTile.tiles.forEach(function(frTile){
				  		var tileProfile = frTile.tileProfile;
				  		if(tileProfile){
				  			tileProfile.forEach(function(subTileProfile,subTileIndex){
				  				var pos = frTile.pos;
					  			var origin = frTile.origin;
					    		subTileProfile = utilAdaptorClipperOffset(subTileProfile, -gap*0.5);
					    		if(subTileProfile){   
					    			subTileProfile = subTileProfile.map(function(t){                                 
											  //偏移到原点，并补充砖缝偏移       
											  var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
											  //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
											  oT = {x:oT.x - origin.x, y:oT.y - origin.y}; //假砖缝
											  
											  if(frTile.rot){
											  	var x = frTile.rot.x != null ? frTile.rot.x*frTile.tileW : 0;
								    	    var y = frTile.rot.y != null ? frTile.rot.y*frTile.tileH : 0;
								    	    var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.tileH : 0;
								    	    var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.tileW : 0;
								    	    oT = {x:oT.x - x - hx, y:oT.y - y - wy};
								    	    oT = utilMathRotatePointCW({x:0,y:0}, oT, -frTile.rot.r);
											  }
											  
											  return oT;
										});
										
										var mrot = 0;						
										var mrotCenter = {x:frTile.tileW*0.5, y:frTile.tileH*0.5};
										if(mrot != 0){
											//进行随机旋转
											subTileProfile = subTileProfile.map(function(t){						       
											  return utilMathRotatePointCW(mrotCenter, t, -mrot);
											});
										}
										
										subTileProfile = subTileProfile.map(function(t){						       
											//选砖                                               
											return {x:t.x,
											        y:t.y};
										});
					    			
										var floorShape = new THREE.Shape(subTileProfile);
								    var floorGeom = floorShape.makeGeometry();
								    var vertexMin = {x: 1e3,y: 1e3};
								    for (var i = 0, len = floorGeom.vertices.length; len > i; ++i) {
								        var vertex = floorGeom.vertices[i];								        
								        if(mrot != 0){
								        	var v = utilMathRotatePointCW(mrotCenter, vertex, mrot);
								        	vertex.x = v.x;
								        	vertex.y = v.y;
								    	  }
								    	  
								    	  if(frTile.rot){
								    	  	var x = frTile.rot.x != null ? frTile.rot.x*frTile.tileW : 0;
								    	    var y = frTile.rot.y != null ? frTile.rot.y*frTile.tileH : 0;
								    	    var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.tileH : 0;
								    	    var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.tileW : 0;
								    	     
								    	    var v = utilMathRotatePointCW({x:0,y:0}, vertex, frTile.rot.r);
								    	    vertex.x = v.x + x + hx;
								        	vertex.y = v.y + y + wy;			        	
								        }
								        
								        //vertex.x += origin.x + gap*0.5; vertex.y += origin.y + gap*0.5; //真砖缝			
								        vertex.x += origin.x; vertex.y += origin.y;	   //假砖缝     
								        
								        var v = utilMathRotatePointCW({x:floorRectOrigin.x, y:floorRectOrigin.y}, vertex, singlepaveRot);
							        	vertex.x = v.x;
							        	vertex.y = v.y;
								    }
								    
								    //进行纹理缩放
								    floorGeom.faceVertexUvs[0].forEach(function (uvs) {
								        Array.isArray(uvs) && uvs.forEach(function (uv) {
								            uv.x /= material.sx;
								            uv.y /= material.sy;
								        });
								    });
								    var floorMesh = new THREE.Mesh(floorGeom, floorMeshMat);								    
								    floorMesh.position.set(0, 0, boundaryOffset);
								    floorMesh.name = floorRectTile.name;//+floorRectTile.index;
								    floorMesh.side = styleName;
								    boundary3d.add(floorMesh);
					    		}
				  			});
				  		}
				  	});
				  }
		    }		    
		  });
		}
    
    function buildLoops(loops, name){
    	if(loops && loops.length > 0){
	    	for(var l=0;l < loops.length;++l){
		    	var profile = loops[l];		    
			    var center2d = null;//areaModel.center;
			    if (!profile || profile.length < 4) 
			        continue;
			    	       
	        var p1 = profile[0];
	        var p2 = profile[1]; //center	        
	        	        	        
	        var mat = boundaryModel[name + l + "Material"];
			    var zBias = 0;//(mat ? mat.pid : DEFAULT_BOUNDARY_MATERIAL, boundaryModel.category == AREA_INNER_CATEGORY_ID ? 0 : -.002);
			    var boundaryOffset = 4e-5 * (boundaryModel.level + 1) + zBias; 
			    var boundaryMeshMat = utilThreeViewCreateTileMaterial(view, mat, {});			    
			    var areaShape = new THREE.Shape(profile);
			    var areaGeom = areaShape.makeGeometry();
			    var vertexMin = {
		             x: 1e3,
		             y: 1e3
		           };	    	       
			    for (var i = 0, len = areaGeom.vertices.length; len > i; ++i) {
			        var vertex = areaGeom.vertices[i];
			        //vertex.z = boundaryOffset + (1e-5);
			    }
			    
			    areaGeom.faceVertexUvs[0].forEach(function (uvs) {
			        Array.isArray(uvs) && uvs.forEach(function (uv) {
			            uv.x -= p2.x;//vertexMin.x;
			            uv.y -= p2.y;//vertexMin.y;
			        });
			    });
			    		    
			    var highlightMat = new THREE.MeshBasicMaterial({
			        color: 15790144,
			        transparent: !0,
			        opacity: .15
			    });
			    var areaOutline = new THREE.Mesh(areaGeom, highlightMat);
			    areaOutline.position.set(0, 0, boundaryOffset + (2e-5) );
			    areaOutline.updateMatrix();
			    areaOutline.name = name + "_highlight";
	        areaOutline.visible = false;
	        areaOutline.raycastable = false;
	        boundary3d.add(areaOutline);
	      };
	    }
    }
    
    buildLoops(boundaryModel.baseLoops, "base");
    buildLoops(boundaryModel.cornerLoops, "corner");
    buildLoops(boundaryModel.leftLoops, "left");
    buildLoops(boundaryModel.rightLoops, "right");
    
    return boundary3d;
}




//# sourceURL=src\display\boundary.js