

function utilSnapAreaCreatePathString(areaModel, offset) {
    var geom, svgString = "", profile = areaModel.profile, factor = 100;
    if (profile.length < 3) return "";
    if (geom = areaModel.getLoop(), utilMathEquals(offset, 0, .01) || (geom = utilAdaptorClipperOffset(geom, offset)),
            !geom) return "";
    for (var i = 0, len = geom.length; len > i; ++i) {
        var pt = geom[i];
        __assert(!isNaN(pt.x) && !isNaN(pt.y)), svgString += (0 == i ? "M" : "L") + Math.round(pt.x * factor) + "," + Math.round(-pt.y * factor);
    }
    return svgString += "Z";
}

//跟canvas.snap.comp.js utilSnapAreaGetAreaMaterial 重复
//function utilSnapAreaGetAreaMaterial(displayArea, patternCallback) {
//    var area = displayArea.model, mat = (displayArea.view, area.areaMaterial);
//    return mat ? utilSnapViewUpdateMaterial(displayArea, mat, patternCallback) : "#c0c0c0";
//}

function utilSnapAreaLevelUpdated(view, changedModel) {
	  var model = changedModel;
	  var cat = model.category;
	  var layer = view.layers["inner" == cat ? AREA_INNER_CATEGORY_ID : AREA_OUTER_CATEGORY_ID];
	  
	  var hostId = model instanceof Area ? model.host.id : model instanceof Boundary ? model.host.host ? model.host.host.id : 0 : 0;
	  var models = utilAppFloorplanGetAreasAndBoundarysByHostId(view.app, void 0, hostId, cat);
	  
    for (var i = 0; i < models.length; ++i) {
        var a = models[i], de = view.dl[a.id].de;
        layer.add(de);
    }
}

function DisplayThreeWallArea(modelObject, view) { //3d墙自定义区域
    classBase(this, modelObject, view);
}

classInherit(DisplayThreeWallArea, DisplayObject), utilExtend(DisplayThreeWallArea.prototype, { //3d墙面自定义区域
    create: function () {
        if (classBase(this, "create"), void 0 == this.de) {
            this.de = new THREE.Object3D();
            this.de.did = this.de.name = this.id;
            this.model.rebuild();
            var area3d = utilThreeCreateWallArea(this);
            this.de.add(area3d);
            this.fp = application.doc.floorplan; 
        }
        this.view.layers[Area.prototype.type].add(this.de);
        var propertyChangedFun = function (propertyName, oldValue, newValue) {
            if( "flag" == propertyName){
                (oldValue & AREAFLAG_HOST_CHANGED_UPDATE3D) != (newValue & AREAFLAG_HOST_CHANGED_UPDATE3D) ? (utilModelSetFlagOff(this.model, AREAFLAG_HOST_CHANGED_UPDATE3D),
                    this.dF |= 1,this.model.paveRebuild = true ) : this.dF |= 4
            }else if ("paveType" == propertyName) {
                this.dF |= 1;
                this.model.clearPaveDB();
                this.model.paveRebuild = true;
            }else{
                this.dF |= 1;
                this.model.paveRebuild = true;
                utilFloorplanUpdateWallAreaByWall(this.model.host);
            }
        }.bind(this), 
        linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
        	if(changeFrom instanceof Material){
        		this.dF |= 1;
            this.dF |= 2;
            this.model.paveRebuild = true;
            
            changeFrom.ignoreUV = true;
            this.model.clearPaveDB();
          }
        }.bind(this), 
        linkPropertyChangedFun = function (changedLinkEntity, propertyName) {
            changedLinkEntity instanceof Point && ("x" == propertyName || "y" == propertyName) && (this.dF |= 1 ,this.dF |= 2, this.model.paveRebuild = true, utilFloorplanUpdateWallAreaByWall(this.model.host));
            
            changedLinkEntity instanceof Material && (
            this.dF |= 1,
        	  this.dF |= 2,
        	  this.model.paveRebuild = true);
        }.bind(this);
        this.model.propertyChangedEvent.add(propertyChangedFun);
        this.model.linksChangedEvent.add(linksChangedFun);
        this.model.linkPropertyChangedEvent.add(linkPropertyChangedFun);
    },
    update: function () {
    	  this.model.rebuild();    	  
    	  
        var view = this.view;
        var areaModel = this.model;
        if (0 != (1 & this.dF)) {
            this.de.remove(this.de.children[0]);
            var area3d = utilThreeCreateWallArea(this);
            this.de.add(area3d);
            
            var visible = utilModelIsFlagOff(this.model.host, MODELFLAG_HIDDEN);
            this.de.visible = visible;
            
            //this.custom_tile_update();
        }
        if (0 != (2 & this.dF)) {
            //var mat = (areaModel.areaMaterial ? areaModel.areaMaterial.pid : DEFAULT_AREA_MATERIAL[areaModel.category],
            //    areaModel.areaMaterial), areaMeshMat = utilThreeViewCreateTileMaterial(view, mat, {});
            //var matScale = mat.getScale()
            //mat && (areaMeshMat.scUniform1 = [utilMathToRadius(-mat.rot), mat.tx, mat.ty, 0],areaMeshMat.scUniform2 = [matScale.x, matScale.y, 0, 0]),
            //    this.de.traverse(function (child) {
            //        "area" == child.name && (child.material = areaMeshMat);
            //    });
            //
            //this.custom_tile_update();
        }
        if (0 != (4 & this.dF)) {
            var selected = utilModelIsFlagOn(this.model, MODELFLAG_PICKED);
            utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
            this.de.traverse(function (child) {
                -1 != child.name.indexOf("highlight") && (child.visible = selected);
            });
        }
    },
    custom_tile_update:function(){
       
    	var areaModel = this.model;
    	var mat = (areaModel.areaMaterial ? areaModel.areaMaterial.pid : DEFAULT_AREA_MATERIAL[areaModel.category],
                areaModel.areaMaterial);
      
      if(mat.category == "custom_tile" || mat.category == "customparquet"){
      	//根据rect大小,所放mat sx,sy
        switch (areaModel.type) {
            case RectArea3d.prototype.type:
                mat.sx = areaModel.width / mat.meta.xlen;
                mat.sy = areaModel.height / mat.meta.ylen;
                break;
            case RoundArea3d.prototype.type:
                mat.sx = areaModel.radius * 2 / mat.meta.xlen;
                mat.sy = areaModel.radius * 2 / mat.meta.ylen;
                break;
        }
      }
    },
    destroy: function () {
        this.view.layers[Area.prototype.type].remove(this.de);
    }
});

function utilThreeCreateWallArea(areadisplay) {
    var fp = application.doc.floorplan;
    var view = areadisplay.view;
    var areaModel = areadisplay.model;
    var area3d = new THREE.Object3D();
    if (!areaModel.host || 
        !(areaModel.host.type == "WALL" ||
          areaModel.host.type == "RECTAREA" ||
          areaModel.host.type == "ROUNDAREA" ||
          areaModel.host.type == "FREEAREA"))
        return area3d;
    var side = areaModel.category;
    var wallModel = areaModel.host;
    var wall3d = view.dl[wallModel.id].de;
    var wallSideMesh = void 0;
    wallModel[side + "Material"];
    if (wall3d.traverse(function (child) {
            child.name == side && "Mesh" == child.type && (wallSideMesh = child);
        }), !wallSideMesh)
        return area3d;
    var profile = areaModel.getLoop();//{rot: 0});
    if (!profile || profile.length < 4)
        return area3d;
    var rot = areaModel.rot || 0;
    var center2d = areaModel.center;
    var mat = areaModel.areaMaterial;
    if(!mat){
    	return area3d;
    }
    var matScale = mat.getScale();
    var wallOffset = 4e-5;//(areaModel.type == "WALLBOARD" || areaModel.type == "BASEBOARD")? (4e-5) : 4e-5 * (areaModel.level + 2);
    var areaMeshMat = utilThreeViewCreateTileMaterial(view, mat, {});
    mat && (areaMeshMat.scUniform1 = [utilMathToRadius(-mat.rot), mat.tx, mat.ty, 0],areaMeshMat.scUniform2 = [matScale.x, matScale.y, 0, 0]);
    var rootMeshMat = utilThreeViewCreateTileMaterial(view, areaModel.rootMaterial, {});
    
    var clipperFactor = 10000.0;//clipper缩放因子
    var cpr = new ClipperLib.Clipper();
    
    //通过墙面裁剪（包括曲面)
    //var geom = utilModelWallGetTessellates(wallModel, 0);
    var sideWidth = 0;
    var sideHeight = Math.abs(wallModel.height3d);
        
    /////////////////////////////铺贴    
	  var gap = areaModel.gapwidth;  //砖缝
	  var cpr = new ClipperLib.Clipper();
	  var floorRectOrigin = areaModel.floorRectOrigin;
	  var singlepaveRot = areaModel.singlepaveRot;
	  var isSquare = areaModel.isSquare;
	  //初始化
	  if(areaModel.floorRectTiles && areaModel.floorRectTiles.length > 0){			
	  	var areaMeshMat = utilThreeViewCreatePaveTileMaterial(view, areaModel.areaMaterial, {});
	  	var paveMeshMats = [];
			var paveGeoms    = [new THREE.Geometry()]; //对应的geom
			var rootGeom = new THREE.Geometry();       //对应砖缝色底
			for(var i=0;i<10;++i){
				areaModel["pave"+i+"Material"] && (paveMeshMats[i] = utilThreeViewCreatePaveTileMaterial(view, areaModel["pave"+i+"Material"], {}), paveGeoms[i + 1] = new THREE.Geometry());				 
			}
			
			//合并多个砖块模型数据
	    areaModel.floorRectTiles.forEach(function(frTile){
	    	if(frTile.type == "group"){ //组类型不显示            	  	
    	    return;
    	  }
    	  var pos = frTile.pos;
		  	var origin = frTile.origin;
    	  
    	  //砖图形生成
    	  var tileGeomCreate = function(tileProfile, sideStart, sideWidth, ox){
    	  	var retProfiles = [];
    	  	var retFloorGeoms = [];
    	  	
    	  	var paths = tileProfile.map(function(p){
						 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
					});
					var clipPath = [];
					clipPath.push({X:Math.ceil(sideStart * clipperFactor), Y: Math.ceil(0* clipperFactor)});
					clipPath.push({X:Math.ceil(sideStart * clipperFactor), Y: Math.ceil(sideHeight* clipperFactor)});
					clipPath.push({X:Math.ceil((sideStart+sideWidth) * clipperFactor), Y: Math.ceil(sideHeight* clipperFactor)});
					clipPath.push({X:Math.ceil((sideStart+sideWidth) * clipperFactor), Y: Math.ceil(0* clipperFactor)});
					
					cpr.Clear();
					cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
		      cpr.AddPath(clipPath, ClipperLib.PolyType.ptClip, true);
		      var solution = new ClipperLib.PolyTree();
		      cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
		      if(solution.m_AllPolys.length > 0){
		      	var clippedProfile = [];
		      	solution.m_AllPolys.forEach(function(poly){
		      		var profile = poly.m_polygon.map(function(p){
								//return {x:(p.X/clipperFactor) - ox, y:p.Y/clipperFactor};
								return {x:p.X/clipperFactor, y:p.Y/clipperFactor};
							});
							retProfiles.push(profile);
		      	});
		      	
		      	retProfiles.forEach(function(profile){
		      		profile = profile.map(function(t){                                 
								  //偏移到原点，并补充砖缝偏移       
								  var oT = utilMathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
								  //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
								  oT = {x:oT.x - origin.x, y:oT.y - origin.y};
								  
								  if(frTile.rot){
								  	var x = frTile.rot.x != null ? frTile.rot.x*frTile.paveW : 0;
					    	    var y = frTile.rot.y != null ? frTile.rot.y*frTile.paveH : 0;
					    	    var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.paveH : 0;
					    	    var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.paveW : 0;
					    	    oT = {x:oT.x - x - hx, y:oT.y - y - wy};
					    	    oT = utilMathRotatePointCW({x:0,y:0}, oT, -frTile.rot.r);
								  }
								  
								  return oT;
							});
												
							var mrot = 0;
							//铺贴模板固定铺砖朝向
							switch(frTile.dir){
								case 1:
								  mrot = 0;
								break;
								case 2:
								  mrot = 90;
								break;
								case 3:
								  mrot = 180;
								break;
								case 4:
								  mrot = 270;
								break;
							}    			
							
							var mrotCenter = {x:frTile.paveW*0.5, y:frTile.paveH*0.5};
							if(mrot != 0){
								//进行随机旋转
								profile = profile.map(function(t){						       
								  return utilMathRotatePointCW(mrotCenter, t, -mrot);
								});
							}
							
							profile = profile.map(function(t){						       
								//选砖                                               
								return {x:t.x + frTile.tileIndex.th * frTile.paveW,
								        y:t.y + frTile.tileIndex.tv * frTile.paveH};
							});
			  			
							var floorShape = new THREE.Shape(profile);
					    var floorGeom = floorShape.makeGeometry();
					    var vertexMin = {x: 1e3,y: 1e3};
					    for (var i = 0, len = floorGeom.vertices.length; len > i; ++i) {
					        var vertex = floorGeom.vertices[i];
					        //vertexMin.x = Math.min(vertexMin.x, vertex.x);
					        //vertexMin.y = Math.min(vertexMin.y, vertex.y);
					        
					        vertex.x -= frTile.tileIndex.th * frTile.paveW;
									vertex.y -= frTile.tileIndex.tv * frTile.paveH;
					        
					        if(mrot != 0){
					        	var v = utilMathRotatePointCW(mrotCenter, vertex, mrot);
					        	vertex.x = v.x;
					        	vertex.y = v.y;
					    	  }
					    	  
					    	  if(frTile.rot){
					    	  	var x = frTile.rot.x != null ? frTile.rot.x*frTile.paveW : 0;
					    	    var y = frTile.rot.y != null ? frTile.rot.y*frTile.paveH : 0;
					    	    var hx = frTile.rot.hx != null ? frTile.rot.hx*frTile.paveH : 0;
					    	    var wy = frTile.rot.wy != null ? frTile.rot.wy*frTile.paveW : 0;
					    	     
					    	    var v = utilMathRotatePointCW({x:0,y:0}, vertex, frTile.rot.r);
					    	    vertex.x = v.x + x + hx;
					        	vertex.y = v.y + y + wy;			        	
					        }
					        
					        //vertex.x += origin.x + gap*0.5; vertex.y += origin.y + gap*0.5; //真砖缝
					        vertex.x += origin.x; vertex.y += origin.y; //假砖缝
					        var v = utilMathRotatePointCW({x:floorRectOrigin.x, y:floorRectOrigin.y}, vertex, singlepaveRot);
				        	vertex.x = v.x - ox; //添加x轴偏移量
				        	vertex.y = v.y;
					    }
					    
					    //进行纹理缩放
					    floorGeom.faceVertexUvs[0].forEach(function (uvs) {
					        Array.isArray(uvs) && uvs.forEach(function (uv) {
					            //uv.x -= vertexMin.x,
					            //uv.y -= vertexMin.y;
					            uv.x /= mat.sx;
					            uv.y /= mat.sy;
					        });
					    });
					    
					    retFloorGeoms.push(floorGeom);
		      	});		      	
		      }
		      
		      return retFloorGeoms;
				}
    	  
	    	var tileProfile = frTile.tileProfile;    	
				if(tileProfile){
					tileProfile.forEach(function(subProfile){						
						//首先生成砖缝底
						if(wallModel.bezier && (side == "right" || side == "left")){
	    				//曲面
	    				var sideWidths = []; 
				    	if(side == "right"){    		  		
				    		sideWidths.push(utilMathLineLength(geom[1],geom[7][0]));
				    		for(var i=1;i<geom[7].length;++i){
				    			sideWidths.push(utilMathLineLength(geom[7][i-1],geom[7][i]));
				    		}
				    		sideWidths.push(utilMathLineLength(geom[7][geom[7].length-1],geom[2]));
				    	}else if(side == "left"){
				    		sideWidths.push(utilMathLineLength(geom[4],geom[8][0]));
				    		for(var i=1;i<geom[8].length;++i){
				    			sideWidths.push(utilMathLineLength(geom[8][i-1],geom[8][i]));
				    		}
				    		sideWidths.push(utilMathLineLength(geom[8][geom[8].length-1],geom[5]));
				    	}
				    	
				    	var sideStart = 0;
				  		if(sideWidths.length == wallSideMesh._rawDatas.length){
				    		for(var i=0;i<sideWidths.length;++i){
				    			var sideWidth = sideWidths[i];					    			
				    			
				    			var subGeoms = tileGeomCreate(subProfile, sideStart, sideWidth, sideStart);
					    	  if(subGeoms.length > 0){
					    	  	subGeoms.forEach(function(subGeom){
								    	var vn = wallSideMesh._rawDatas[i].vn;
									    var lineDir = {
									        x: -vn.y,
									        y: vn.x
									    };						    	
								    	utilMergeGeomArea(subGeom, rootGeom, wallSideMesh._rawDatas[i].o, lineDir, wallOffset);
					    	  	});						    		  
					    		}
					    		sideStart += sideWidth;
				    		}
				    	}
	    			}else{
	    				//非曲面
	    				if(utilModelWallIsSmoothStart(wallModel, areaModel.category)){
	    					var rawDatas = utilModelWallGetSmoothRawDatas(wallModel, areaModel.category);
						    if(rawDatas){
						    	var sideStart = 0;
						  		for(var i=0;i<rawDatas.length;++i){
					    			var sideWidth = rawDatas[i].width;					    			
					    			
					    			var floorGeoms = tileGeomCreate(subProfile, sideStart, sideWidth, sideStart);
						    	  if(floorGeoms.length > 0){
						    	  	floorGeoms.forEach(function(floorGeom){
										    utilMergeGeomArea(floorGeom, rootGeom, rawDatas[i].o, rawDatas[i].lineDir, wallOffset);
						    	  	});						    		  
						    		}
						    		sideStart += sideWidth;
					    		}
								}
	    				}else{
		    				var sideWidth = utilModelWallGetSideLength(wallModel, areaModel.category);
		    				var floorGeoms = tileGeomCreate(subProfile, 0, sideWidth, 0);
		    				if(floorGeoms.length > 0){
		    					floorGeoms.forEach(function(floorGeom){		    						
							    	var vn = wallSideMesh._rawData.vn;
								    var lineDir = {
								        x: -vn.y,
								        y: vn.x
								    };						    	
								    utilMergeGeomArea(floorGeom, rootGeom, wallSideMesh._rawData.o, lineDir, wallOffset);
		    					});		    					
		    				}	
		    			}	    				
	    			}
						//首先生成砖缝底 end
						
		    		var subTileProfiles = utilAdaptorClipperOffsetArray(subProfile, -gap*0.5);
		    		subTileProfiles && subTileProfiles.forEach(function(subTileProfile){
		    			//对每个subTileProfile进行曲面切割
		    			if(wallModel.bezier && (side == "right" || side == "left")){
		    				//曲面
		    				var sideWidths = []; 
					    	if(side == "right"){    		  		
					    		sideWidths.push(utilMathLineLength(geom[1],geom[7][0]));
					    		for(var i=1;i<geom[7].length;++i){
					    			sideWidths.push(utilMathLineLength(geom[7][i-1],geom[7][i]));
					    		}
					    		sideWidths.push(utilMathLineLength(geom[7][geom[7].length-1],geom[2]));
					    	}else if(side == "left"){
					    		sideWidths.push(utilMathLineLength(geom[4],geom[8][0]));
					    		for(var i=1;i<geom[8].length;++i){
					    			sideWidths.push(utilMathLineLength(geom[8][i-1],geom[8][i]));
					    		}
					    		sideWidths.push(utilMathLineLength(geom[8][geom[8].length-1],geom[5]));
					    	}
					    	
					    	var sideStart = 0;
					  		if(sideWidths.length == wallSideMesh._rawDatas.length){
					    		for(var i=0;i<sideWidths.length;++i){
					    			var sideWidth = sideWidths[i];					    			
					    			
					    			var subGeoms = tileGeomCreate(subTileProfile, sideStart, sideWidth, sideStart);
						    	  if(subGeoms.length > 0){
						    	  	subGeoms.forEach(function(subGeom){
						    	  		var paveGeom = paveGeoms[0];
										    (frTile.pidIndex != null) && (paveGeom = paveGeoms[frTile.pidIndex + 1]);
										    if(paveGeom){
										    	var vn = wallSideMesh._rawDatas[i].vn;
											    var lineDir = {
											        x: -vn.y,
											        y: vn.x
											    };						    	
										    	utilMergeGeomArea(subGeom, paveGeom, wallSideMesh._rawDatas[i].o, lineDir, wallOffset*2);
										    }
						    	  	});						    		  
						    		}
						    		sideStart += sideWidth;
					    		}
					    	}
		    			}else{
		    				//非曲面
		    				if(utilModelWallIsSmoothStart(wallModel, areaModel.category)){
		    					var rawDatas = utilModelWallGetSmoothRawDatas(wallModel, areaModel.category);
							    if(rawDatas){
							    	var sideStart = 0;
							  		for(var i=0;i<rawDatas.length;++i){
						    			var sideWidth = rawDatas[i].width;					    			
						    			
						    			var subGeoms = tileGeomCreate(subTileProfile, sideStart, sideWidth, sideStart);
							    	  if(subGeoms.length > 0){
							    	  	subGeoms.forEach(function(subGeom){
							    	  		var paveGeom = paveGeoms[0];
											    (frTile.pidIndex != null) && (paveGeom = paveGeoms[frTile.pidIndex + 1]);
											    if(paveGeom){
											    	utilMergeGeomArea(subGeom, paveGeom, rawDatas[i].o, rawDatas[i].lineDir, wallOffset*2);
											    }
							    	  	});						    		  
							    		}
							    		sideStart += sideWidth;
						    		}
									}
		    				}else{
		    					var sideWidth = utilModelWallGetSideLength(wallModel, areaModel.category);
		    					var floorGeoms = tileGeomCreate(subTileProfile, 0, sideWidth, 0);
			    				if(floorGeoms.length > 0){
			    					floorGeoms.forEach(function(floorGeom){
			    						var paveGeom = paveGeoms[0];
									    (frTile.pidIndex != null) && (paveGeom = paveGeoms[frTile.pidIndex + 1]);
									    if(paveGeom){
									    	var vn = wallSideMesh._rawData.vn;
										    var lineDir = {
										        x: -vn.y,
										        y: vn.x
										    };						    	
									    	utilMergeGeomArea(floorGeom, paveGeom, wallSideMesh._rawData.o, lineDir, wallOffset*2);
									    }
			    					});		    					
			    				}
		    				}	    				
		    			}		    			
					  });
					});
					
				}	
	    });	    
	    
	    //生成砖缝底
	    rootGeom.computeFaceNormals();
	    var meshMat = rootMeshMat;	    
	    var rootMesh = new THREE.Mesh(rootGeom, meshMat);
	    //areaMesh.position.set(0, 0, areaOffset);
	    rootMesh.name = "root";
	    area3d.add(rootMesh);
	    
	    //生成同一砖块模型
	    paveGeoms.forEach(function(geom, index){
	    	geom.mergeVertices();
		    geom.computeFaceNormals();
		    geom.computeVertexNormals(); 
	    
	    	var meshMat = areaMeshMat;
		    (parseInt(index) > 0) && (meshMat = paveMeshMats[parseInt(index) - 1]);
		    
		    var areaMesh = new THREE.Mesh(geom, meshMat);
		    //areaMesh.position.set(0, 0, areaOffset);
		    areaMesh.name = (parseInt(index) > 0) ? ("pave" + (parseInt(index) - 1)) : "area";					    
		    area3d.add(areaMesh);
	    });
	  }
	  /////////////////////////////铺贴 end
	  
	  //////////////////////////独立geom生成过程
		var areaGeomCreate = function(sideStart, sideWidth, paths, rawData, lineDir, ox){
			var clipPath = [];
			clipPath.push({X:Math.ceil(sideStart * clipperFactor), Y: Math.ceil(0* clipperFactor)});
			clipPath.push({X:Math.ceil(sideStart * clipperFactor), Y: Math.ceil(sideHeight* clipperFactor)});
			clipPath.push({X:Math.ceil((sideStart+sideWidth) * clipperFactor), Y: Math.ceil(sideHeight* clipperFactor)});
			clipPath.push({X:Math.ceil((sideStart+sideWidth) * clipperFactor), Y: Math.ceil(0* clipperFactor)});
			
			cpr.Clear();
			cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
      cpr.AddPath(clipPath, ClipperLib.PolyType.ptClip, true);
      var solution = new ClipperLib.PolyTree();
      cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
      if(solution.m_AllPolys.length > 0){
      	var clippedProfile = [];
      	solution.m_AllPolys.forEach(function(poly){
      		var profile = poly.m_polygon.map(function(p){
						return {x:(p.X/clipperFactor) - ox, y:p.Y/clipperFactor};
					});
					clippedProfile = profile;
      	});      	
      	
      	var areaShape = new THREE.Shape(clippedProfile);
      	areaShape.autoClose = true;
		    var areaGeom = areaShape.makeGeometry();
		    var vertexMin = {
		        x: 1e3,
		        y: 1e3
		    };
		    areaGeom.vertices = areaGeom.vertices.map(function (vertex) {
		        vertex.z -= wallOffset*3;
		        var xyz = utilThreeUVW2XYZ(vertex, rawData.o, lineDir);
		        return new THREE.Vector3(xyz.x, xyz.y, xyz.z);
		    });
		    //areaGeom.faceVertexUvs[0].forEach(function (uvs) {
		    //    Array.isArray(uvs) && uvs.forEach(function (uv) {
		    //        uv.x -= vertexMin.x, uv.y -= vertexMin.y;
		    //    });
		    //});
		    areaGeom.computeFaceNormals();
		    return areaGeom;
		  }
		}		
	  //高亮选中模型以及无铺贴
	  var paths = profile.map(function(p){
			 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
		});
	  if(wallModel.bezier && (side == "right" || side == "left")){
    	//对于曲面屏的right 和 left 面要进行曲面裁剪
    	var areaGeom = new THREE.Geometry();
    	var sideWidths = []; 
    	if(side == "right"){    		  		
    		sideWidths.push(utilMathLineLength(geom[1],geom[7][0]));
    		for(var i=1;i<geom[7].length;++i){
    			sideWidths.push(utilMathLineLength(geom[7][i-1],geom[7][i]));
    		}
    		sideWidths.push(utilMathLineLength(geom[7][geom[7].length-1],geom[2]));
    	}else if(side == "left"){
    		sideWidths.push(utilMathLineLength(geom[4],geom[8][0]));
    		for(var i=1;i<geom[8].length;++i){
    			sideWidths.push(utilMathLineLength(geom[8][i-1],geom[8][i]));
    		}
    		sideWidths.push(utilMathLineLength(geom[8][geom[8].length-1],geom[5]));
    	}    	
    	
    	var sideStart = 0;
  		if(sideWidths.length == wallSideMesh._rawDatas.length){
  			var areaPaths = [];
		    var holePaths = [];
		    var holes = [];
		    utilFloorplanForEachArea(fp,function(area){
		    	if(area.id != areaModel.id){
			    	if((area.type == "RECTAREA3D" || area.type == "ROUNDAREA3D")){
			    		if(areaModel.host == area.host && area.level > areaModel.level){
			    			var areaProfile = area.getLoop();
				    		areaPaths.push(areaProfile.map(function(p){
						  		return {X:Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
						  	}));
						  }
			    	}
			    }
		    });
		    if(areaPaths.length > 0){
		    	var areaPath = areaPaths.splice(0,1);
		    	var retProfile = utilCliperFromPaths(areaPath, areaPaths, cpr, ClipperLib.ClipType.ctUnion, clipperFactor);
		    	if(retProfile){
		    		retProfile.forEach(function(profileAndHoles){
		    			holePaths.push(profileAndHoles.profile.map(function(p){
					  		return {X:Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
					  	}));
		    		});
		    	}
		    }
		    var retProfile = utilCliperFromPaths([paths], holePaths, cpr, ClipperLib.ClipType.ctDifference,clipperFactor);    
	    	if(retProfile){
	    		retProfile.forEach(function(profileAndHoles){
				    var paths = profileAndHoles.profile.map(function(p){
							 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
						});
						
						for(var i=0;i<sideWidths.length;++i){
		    			var sideWidth = sideWidths[i];
		    			var lineDir = {x: -wallSideMesh._rawDatas[i].vn.y, y:wallSideMesh._rawDatas[i].vn.x};
		    			var subGeom = areaGeomCreate(sideStart, sideWidth, paths, wallSideMesh._rawDatas[i], lineDir, sideStart);
			    	  if(subGeom){
			    		  utilMergeGeom(subGeom, areaGeom);
			    		}
			    		sideStart += sideWidth;
		    		}
						//var partAreaGeom = areaGeomCreate(0, sideWidth, paths, wallSideMesh._rawData, 0, profileAndHoles.holes);
						//var colorMaterial = new MaterialRawColor({color:utilStringToHexCharCode(areaModel.areaColor)});
			    	//var colorMeshMat = utilThreeViewCreateTileMaterial(view, colorMaterial, {});
				  	//var areaMesh = new THREE.Mesh(partAreaGeom, colorMeshMat);
				    //areaMesh.name = "area";
				    //area3d.add(areaMesh);
		    	});
	    	}
    	}
    	
    	areaGeom.mergeVertices();
	    areaGeom.computeFaceNormals();
	    areaGeom.computeVertexNormals(); 
    
    	if(areaModel.floorRectTiles && areaModel.floorRectTiles.length > 0){
	    	//...
	    }else{
	    	//空的
	    	var colorMaterial = new MaterialRawColor({color:utilStringToHexCharCode(areaModel.areaColor)});
				var colorMeshMat = utilThreeViewCreateTileMaterial(view, colorMaterial, {});
		  	var areaMesh = new THREE.Mesh(areaGeom, colorMeshMat);
		    areaMesh.name = "area";
		    area3d.add(areaMesh);
	    }
	    
	    var highlightMat = new THREE.MeshBasicMaterial({
	        color: 15790144,
	        transparent: !0,
	        opacity: .15
	    });
	    
	    var areaOutline = new THREE.Mesh(areaGeom, highlightMat);
	    areaOutline.name = "area_highlight";
	    areaOutline.visible = !1;
	    areaOutline.raycastable = !1;
	    area3d.add(areaOutline);
    }else{
			var areaGeom = new THREE.Geometry();
			var areaPaths = [];
	    var holePaths = [];
	    var holes = [];
	    utilFloorplanForEachArea(fp,function(area){
	    	if(area.id != areaModel.id){
		    	if((area.type == "RECTAREA3D" || area.type == "ROUNDAREA3D")){
		    		if(areaModel.host == area.host && area.level > areaModel.level){
		    			var areaProfile = area.getLoop();
			    		areaPaths.push(areaProfile.map(function(p){
					  		return {X:Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
					  	}));
					  }
		    	}
		    }
	    });
	    if(areaPaths.length > 0){
	    	var areaPath = areaPaths.splice(0,1);
	    	var retProfile = utilCliperFromPaths(areaPath, areaPaths, cpr, ClipperLib.ClipType.ctUnion, clipperFactor);
	    	if(retProfile){
	    		retProfile.forEach(function(profileAndHoles){
	    			holePaths.push(profileAndHoles.profile.map(function(p){
				  		return {X:Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
				  	}));
	    		});
	    	}
	    }
	    
	    var retProfile = utilCliperFromPaths([paths], holePaths, cpr, ClipperLib.ClipType.ctDifference,clipperFactor);    
    	if(retProfile){
    		retProfile.forEach(function(profileAndHoles){
			    var paths = profileAndHoles.profile.map(function(p){
						 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
					});
					
					if(utilModelWallIsSmoothStart(wallModel, areaModel.category)){
  					var rawDatas = utilModelWallGetSmoothRawDatas(wallModel, areaModel.category);
				    if(rawDatas){
				    	var sideStart = 0;
				    	for(var i=0;i<rawDatas.length;++i){
			    			var sideWidth = rawDatas[i].width;
			    			var subGeom = areaGeomCreate(sideStart, sideWidth, paths, rawDatas[i], rawDatas[i].lineDir, sideStart, profileAndHoles.holes);
				    	  if(subGeom){
				    		  utilMergeGeom(subGeom, areaGeom);
				    		}
				    		sideStart += sideWidth;
			    		}
				    }
				  }else{
				  	var sideWidth = utilModelWallGetSideLength(wallModel, areaModel.category);
				  	var lineDir = {x:-wallSideMesh._rawData.vn.y, y:wallSideMesh._rawData.vn.x};
				  	var subGeom = areaGeomCreate(0, sideWidth, paths, wallSideMesh._rawData, lineDir, 0, profileAndHoles.holes);
						if(subGeom){
		    		  utilMergeGeom(subGeom, areaGeom);
		    		}
				  }
	    	});
    	}
    	
    	if(areaModel.floorRectTiles && areaModel.floorRectTiles.length > 0){
	    	//...
	    }else{
	    	//空的
	    	var colorMaterial = new MaterialRawColor({color:utilStringToHexCharCode(areaModel.areaColor)});
	    	var colorMeshMat = utilThreeViewCreateTileMaterial(view, colorMaterial, {});
		  	var areaMesh = new THREE.Mesh(areaGeom, colorMeshMat);
		    areaMesh.name = "area";
		    area3d.add(areaMesh);
	    }
	    
	    var highlightMat = new THREE.MeshBasicMaterial({
	        color: 15790144,
	        transparent: !0,
	        opacity: .15
	    });
	    
	    var areaOutline = new THREE.Mesh(areaGeom, highlightMat);
	    areaOutline.name = "area_highlight";
	    areaOutline.visible = !1;
	    areaOutline.raycastable = !1;
	    area3d.add(areaOutline);
    }  
	  //////////////////////////独立geom生成过程 end
	  
	  if(areaModel.host.type == "RECTAREA" ||
       areaModel.host.type == "ROUNDAREA" ||
       areaModel.host.type == "FREEAREA"){
       //增加离地距离
       if(areaModel.host.height3d < 0){
       	 area3d.position.z = areaModel.host.z + areaModel.host.height3d;
       }else{
       	 area3d.position.z = areaModel.host.z;
       }       
    }
	  
    return area3d;
}


classInherit(DisplaySnapArea, DisplayObject), 
utilExtend(DisplaySnapArea.prototype, {
    create: function () {
        classBase(this, "create");
        var updateFun = (this.view.context, this.view.layers[this.model.category], this.view.doc.floorplan,
            function (propertyName, oldValue, newValue) {
                if ("category" == propertyName) {
                    var layer = this.view.layers[this.model.category];
                    layer.add(this.de);
                }
            }.bind(this));
        this.model.propertyChangedEvent.add(updateFun);
    },
    update: function () {
    },
    destroy: function () {
        this.view.layers[this.model.category];
        destroyArrowLine(this);
    }
});

function utilAreaCreateSnapStylesExport(opt, svgView){
	  var self = this;
    var context = svgView.context;
    var boardLayer = svgView.layers["BOARD"];
    var offset = opt.offset;    

    var clipperFactor = 10000.0;//clipper缩放因子
    var model = opt.model;
    var gap = model.gapwidth;  //砖缝  
    var display = {model:model, view:svgView};
      
    var cpr = new ClipperLib.Clipper();
    var materialInfo = null;
    var catalog = "floor";

    var ret = [];
    var fillUrl = "";
    var profile = null;
    switch (model.type) {
        case "WALLBOARD":
        case "BASEBOARD":
        case "RECTAREA3D":
        case "ROUNDAREA3D":        
            profile = model.getLoop();
            catalog = "area";
            break;
    }

    if (profile) {
        var floorRectOrigin = model.floorRectOrigin;
        var singlepaveRot = model.singlepaveRot;

        //step2 对所有铺砖生成纹理(实际用砖)
        if (model.floorRectTiles) {
            model.floorRectTiles.forEach(function (frTile) {
            	  if(frTile.type == "group"){ //组类型不显示            	  	
            	    return;
            	  }
            	    
                //重置element列表
                frTile.elements = [];
                //裁剪
                var tileProfile = frTile.tileProfile;
                if (tileProfile) {                	
                    tileProfile.forEach(function (subProfile, subTileIndex) {
                        var pos = frTile.pos;
                        var origin = frTile.origin;
                        var material = frTile.material;
                        
                        //添加底色 start
                        var path = utilSnapFloorCreatePathFromLoop(subProfile);
								        var root = null;
								        if (model instanceof RoundArea) {
								            var attr = {
								                cx: 100 * model.center.x,
								                cy: -100 * model.center.y,
								                r: 100 * model.radius
								            }
								            root = context.circle(attr);
								        } else {
								            root = context.path(path);
								        }
								        var tm = new Snap.Matrix();
								        tm.translate(100.0 * offset.x, -100.0 * offset.y);
								        root.attr({
								            fill: "#" + model.gapcolor,
								            "stroke-width": 0,
								            "stroke-opacity": 1,
								            did: display.id
								        }).transform(tm.toTransformString());
								        ret.push(root);  
								        //添加底色 end                      
                        
                        var subTileProfiles = api.adaptorClipperOffsetArray(subProfile, -gap * 0.5);
                        subTileProfiles && subTileProfiles.forEach(function(subTileProfile){                        	
                            subTileProfile = subTileProfile.map(function (t) {
                                //偏移到原点，并补充砖缝偏移
                                //var patternPos = utilMathRotatePointCW({x:0,y:0}, {x:p.x - pos.x, y:p.y - pos.y}, singlepaveRot);
                                //return {x:patternPos.x - gap*0.5, y:patternPos.y - gap*0.5};
                                var oT = api.mathRotatePointCW(floorRectOrigin, t, -singlepaveRot);
                                //oT = {x:oT.x - origin.x - gap*0.5, y:oT.y - origin.y - gap*0.5}; //真砖缝
                                oT = {x: oT.x - origin.x, y: oT.y - origin.y};   //假砖缝(砖与砖之间不留砖缝)

                                if (frTile.rot) {
                                    var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                    var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                    var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                    var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;
                                    
                                    var l = Math.sqrt(frTile.paveW*frTile.paveW + frTile.paveH*frTile.paveH);
													    	    var lx = frTile.rot.lx != null ? l*frTile.rot.lx:0;
													    	    var ly = frTile.rot.ly != null ? l*frTile.rot.ly:0;
													    	    
                                    oT = {x: oT.x - x - hx - lx, y: oT.y - y - wy - ly};
                                    oT = api.mathRotatePointCW({x: 0, y: 0}, oT, -frTile.rot.r);
                                }

                                return oT;
                            });

                            var mtx = new Snap.Matrix();

                            //铺贴旋转(所有)
                            var fRm = new Snap.Matrix();
                            fRm.rotate(-singlepaveRot, (floorRectOrigin.x + offset.x) * 100, -(floorRectOrigin.y + offset.y) * 100);
                            mtx.add(fRm);

                            var tm = new Snap.Matrix();
                            //tm.translate(100.0*(origin.x + gap*0.5), -100.0*(origin.y + gap*0.5)); //真砖缝
                            tm.translate(100.0 * (origin.x + offset.x), -100.0 * (origin.y + offset.y));   //假砖缝
                            mtx.add(tm);

                            //还原旋转
                            if (frTile.rot) {
                                var x = frTile.rot.x != null ? frTile.rot.x * frTile.paveW : 0;
                                var y = frTile.rot.y != null ? frTile.rot.y * frTile.paveH : 0;
                                var hx = frTile.rot.hx != null ? frTile.rot.hx * frTile.paveH : 0;
                                var wy = frTile.rot.wy != null ? frTile.rot.wy * frTile.paveW : 0;

                                var l = Math.sqrt(frTile.paveW*frTile.paveW + frTile.paveH*frTile.paveH);
											    	    var lx = frTile.rot.lx != null ? l*frTile.rot.lx:0;
											    	    var ly = frTile.rot.ly != null ? l*frTile.rot.ly:0;
                                
                                var tm = new Snap.Matrix();
                                tm.translate(100.0 * (x + hx + lx), -100.0 * (y + wy + ly));
                                mtx.add(tm);

                                var rm = new Snap.Matrix();
                                rm.rotate(-frTile.rot.r, 0, 0);
                                mtx.add(rm);
                            }

                            //sm = new Snap.Matrix();
                            //sm.scale(10);
                            //mtx.add(sm);

                            //还原选砖偏移
                            tm = new Snap.Matrix();
                            tm.translate(-100.0 * (frTile.tileIndex.th * frTile.paveW), 100.0 * (frTile.tileIndex.tv * frTile.paveH));
                            mtx.add(tm);

                            var path = api.floorCreatePathFromLoop(subTileProfile);
                            //选砖(切割后)
                            tm = new Snap.Matrix();
                            tm.translate(100.0 * (frTile.tileIndex.th * frTile.paveW), -100.0 * (frTile.tileIndex.tv * frTile.paveH));
                            path = Snap.path.map(path, tm);

                            var mrot = 0;
                            switch (frTile.dir) {
                                case 1:
                                    mrot = 0;
                                    break;
                                case 2:
                                    mrot = 90;
                                    break;
                                case 3:
                                    mrot = 180;
                                    break;
                                case 4:
                                    mrot = 270;
                                    break;
                            }

                            if (mrot != 0) {
                                //随机旋转
                                var rotCenter = {
                                    x: (frTile.tileIndex.th * frTile.paveW + frTile.paveW * 0.5) * 100,
                                    y: -(frTile.tileIndex.tv * frTile.paveH + frTile.paveH * 0.5) * 100
                                };
                                var rm = new Snap.Matrix();
                                rm.rotate(mrot, rotCenter.x, rotCenter.y);
                                path = Snap.path.map(path, rm);
                                
                                rm = new Snap.Matrix();
                                rm.rotate(-mrot, rotCenter.x, rotCenter.y);
                                mtx.add(rm);
                            }

                            if (material) {
                                var materialInfo = {
                                    url: material.getUrl(),
                                    width: 100 * material.meta.xlen * material.sx,
                                    height: 100 * material.meta.ylen * material.sy
                                };                                
                                var clipPathUrl = utilSnapFloorGetClipPathExport(display, path, context);
                                var s = context.image(material.getUrl(), 0, -materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                    //var s = context.rect(0,-materialInfo.height, materialInfo.width, materialInfo.height).attr({
                                    //fill: fillUrl,
                                    style: "clip-path:" + clipPathUrl
                                }).transform(mtx.toTransformString());
                                ret.push(s);
                            }
                        });                   
                    });

                }
            });
        }        
    }
    
    boardLayer.add(ret);
    
    return ret;
}




// sourceURL=src\display\area.js