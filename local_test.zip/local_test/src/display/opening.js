//门窗2D显示对象
function DisplaySnapOpening(modelObject, view) {
    classBase(this, modelObject, view), this.base = void 0, this.auxiliaries = void 0,
        this.mask = void 0;
}

var SNAP_OPENING_STROKE_COLOR = {
    normal: "#909090",
    pick: "#3eb3de"
};

classInherit(DisplaySnapOpening, DisplaySnapProduct);
utilExtend(DisplaySnapOpening.prototype, {
    createAux: function (bound) {
        return [];
    },
    updateAuxGeom: function (bound) {
    },
    updateAuxFlag: function () {
    },
    create: function () {
        var openObj=this;
        var bound = utilDisplaySnapOpeningBound(this.model);
        var layer = this.view.layers[this.model.type];
        var actionMgr = this.view.app.actionMgr;
        var view = this.view, context = this.view.context;
        if (context) {
            if (this.de.length > 0) return void layer.add(this.de);

            this.base = context.rect(bound.left, bound.top, bound.width, bound.height).attr({
                fill: "#FFFFFF",
                stroke: SNAP_OPENING_STROKE_COLOR.normal,
                "stroke-width": 3,
                "fill-opacity": 1,
                did: this.id
            }).transform("r" + this.model.rot), this.auxiliaries = this.createAux(bound), this.auxiliaries.forEach(function (aux) {
                aux.transform("r" + this.model.rot);
            }, this), this.mask = context.rect(bound.left, bound.top, bound.width, bound.height).attr({
                fill: "#FFFFFF",
                "fill-opacity": 0
            }).transform("r" + this.model.rot), this.de.push(this.base), Array.prototype.push.apply(this.de, this.auxiliaries),
                this.de.push(this.mask), layer.add(this.de), this.model.propertyChangedEvent.add(function (propertyName) {
                "x" == propertyName || "y" == propertyName || "sx" == propertyName || "sy" == propertyName || "rot" == propertyName || "swing" == propertyName ? this.dF |= 1 : "flag" == propertyName && (this.dF |= 2);
            }.bind(this));
            var touchHandler = function (e, a0, a1, a2) {
                if ("touchstart" == e.type) this.ox = this.model.x, this.oy = this.model.y; else if ("touchmove" == e.type) {
                    var touch = e.touches[0], modelPt = utilSvgScreenSpaceToModelSpace(this.view, touch.pageX, touch.pageY);
                    this.model.x = modelPt.x, this.model.y = modelPt.y;
                } else "touchend" == e.type;
            }.bind(this);
            this.mask.click(function (e, screen_x, screen_y) {
            }).mouseover(function (e) {
            }).mouseout(function (e) {
            }).drag(function (dx, dy, x, y, e) {
                if (e.stopPropagation(), e instanceof Event && 1 != e.button) {
                    var modelOffset = utilSvgVectorScreenSpaceToModelSpace(this.view, dx, dy), mPos = {
                        x: this.ox + modelOffset.x,
                        y: this.oy + modelOffset.y
                    }, hitPt = {
                        x: 100 * mPos.x,
                        y: 100 * -mPos.y
                    }, picked = utilSnapDisplaySelect(view, hitPt, [Wall.prototype.type]), attachedWall = picked.length > 0 ? picked[0].model : void 0;
                    attachedWall && __log("attach to wall [" + mPos.x + ", " + mPos.y), utilActionRun(actionMgr, e.type + "2d", e, mPos, attachedWall);
                }
            }, function (x, y, e) {
                this.ox = this.model.x, this.oy = this.model.y, actionMgr.current || utilActionBegin(actionMgr, ActionMoveProduct.prototype.type, this.model);
            }, function (e) {
                utilActionEnd(actionMgr, ActionMoveProduct.prototype.type);
            }, this, this, this).touchstart(touchHandler).touchmove(touchHandler).touchend(touchHandler);

        }
    },
    update: function () {
        var bound = utilDisplaySnapOpeningBound(this.model);
        if (0 != (1 & this.dF)) {
            var attr = {
                x: bound.left,
                y: bound.top,
                width: bound.width,
                height: bound.height
            };
            this.base.attr(attr).transform("r" + -this.model.rot);
            this.mask.attr(attr).transform("r" + -this.model.rot);
            this.updateAuxGeom(bound);
        }
        var picked = utilPickMgrIsPicked(this.view.app.pickMgr, this.model);
        if (0 != (2 & this.dF)) {
            this.base.attr({
                stroke: picked ? SNAP_OPENING_STROKE_COLOR.pick : SNAP_OPENING_STROKE_COLOR.normal,
                "stroke-opacity": picked ? .85 : 1.0,                
            });
            this.updateAuxFlag();
        }
    },
    destroy: function () {
        this.view.layers[this.model.type];
        this.de.forEach(function (ele) {
            ele.remove();
        });
    }
})

//3D门窗显示对象
function DisplayThreeOpening(model, view) {
    classBase(this, model, view);
}

classInherit(DisplayThreeOpening, DisplayThreeProduct);
utilExtend(DisplayThreeOpening.prototype, {
    create: function () {
        classBase(this, "create"), this.model.propertyChangedEvent.add(function (propertyName) {
            "swing" == propertyName && (this.dF |= 1);
        }.bind(this));
    },
    update: function () {
        classBase(this, "update");
    },
    destroy: function () {
        classBase(this, "destroy");
    }
});