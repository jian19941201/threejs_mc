var SNAP_LAYER_IN_DIMENSION = "INDIMENSION";
var SNAP_LAYER_IN_DIMENSION_INNER = "INDIMENSION_INNER";  //add by gaoning 2017.8.10增加内墙标尺
var SNAP_LAYER_OUT_DIMENSION = "OUTDIMENSION";
var SNAP_LAYER_ROOMLABEL = "ROOMLABEL";
var SNAP_LAYER_STATE = "INNER";  //INNER:内墙线，OUT:墙中线--用来记录墙标线状态
var PRODUCT_MARK = "PRODUCT_MARK";
var DEFAULT_2D_VIEW_SETTINGS = {
    showCeilingProductLayer: !0,
    showIESProductLayer: !0,
    showGridLayer: !0,
    showDimensionLayer: 0,
    showInnerDimensionLayer: !0, //add by gaoning 2017.8.10增加内墙标尺 --默认不显示
    showRoomLabel: !0,
    showTextAnnotation: !0,
    showUnderlayLayer: !0,
    showWalkThroughLayer: !1
};


/*TODO classInherit(BaseView, AView), utilExtend(BaseView.prototype, 在 canvas.base.comp.js 定义
 * 0.AView 继承 root
 * 1.BaseView 继承 AView
 * 2.SnapView 继承 BaseView
 * 3.BaseView 里面有 onDocumentChanged 方法--在【canvas.base.comp.js】
 * 4.onDocumentChanged 方法 里面 执行了 utilViewLinksChangedEventCallback 回调函数
 * 5.utilViewLinksChangedEventCallback 调用了 SnapView.prototype 的 createDO 方法--在【canvas.base.comp.js】
 * 6.最终生成在页面的底图；
 * todo add by oxl 2017-02-27
 * */
SnapView.prototype.type = "SnapView";
classInherit(SnapView, BaseView);
utilExtend(SnapView.prototype, {
    orginViewPointWidth: 0,
    orginLabelFontSizeMin: false,
    getRoomLabelFontSize: function () {
        var oSize = this.orginLabelFontSizeMin ? 10 : 20;
        return oSize / (this.orginViewPointWidth / this.viewport.width);
    },
    getDimensionFontSize: function () {
        var oSize = this.orginLabelFontSizeMin ? 10: 20;
        return oSize / (this.orginViewPointWidth / this.viewport.width);
    },
    getAreaLabelSize: function (newSize , oldSize) {
        var oSize = this.orginLabelFontSizeMin ? newSize : oldSize;
        return oSize / (this.orginViewPointWidth / this.viewport.width);
    },

    // getAreaLabelFontSize: function () {
    //     var oSize = this.orginLabelFontSizeMin ? 10 : 20;
    //     return oSize / (this.orginViewPointWidth / this.viewport.width);
    // },
    // getAreaLabelWidth: function () {
    //     var oSize = this.orginLabelFontSizeMin ? 10 : 50;
    //     return oSize / (this.orginViewPointWidth / this.viewport.width);
    // },
    // getAreaLabelHeight: function () {
    //     var oSize = this.orginLabelFontSizeMin ? 10 : 30;
    //     return oSize / (this.orginViewPointWidth / this.viewport.width);
    // },
    // getAreaRectStrokeWidth: function () {
    //     var oSize = this.orginLabelFontSizeMin ? 1 : 1;
    //     return oSize / (this.orginViewPointWidth / this.viewport.width);
    // },
    viewFontSizeMin: function (min) {
        this.orginLabelFontSizeMin = min;
    },
    clear: function () {
        classBase(this, "clear");
        utilExtend(this.settings, DEFAULT_2D_VIEW_SETTINGS);
        utilSvgCreateDimension(this, {
            id: SNAP_LAYER_OUT_DIMENSION
        }, this.layers[SNAP_LAYER_OUT_DIMENSION]);
    },
    changeSettings: function (settingKey, settingValue) {
        classBase(this, "changeSettings", settingKey, settingValue);
        this.layers.Grid.attr("display", this.settings.showGridLayer === !0 ? "block" : "none");
        this.layers.IES.attr("display", this.settings.showIESProductLayer === !0 ? "block" : "none");
        this.layers.FILLLIGHT.attr("display", this.settings.showIESProductLayer === !0 ? "block" : "none");
        this.layers.CEILING.attr("display", this.settings.showCeilingProductLayer === !0 ? "block" : "none");
        this.layers[SNAP_LAYER_ROOMLABEL].attr("display", this.settings.showRoomLabel === !0 ? "block" : "none");
        if (this.settings.showDimensionLayer == true) {
            SNAP_LAYER_STATE = "OUT";
        }
        if (this.settings.showInnerDimensionLayer == true) {
            SNAP_LAYER_STATE = "INNER";
        }
        this.layers[SNAP_LAYER_IN_DIMENSION].attr("display", this.settings.showDimensionLayer === !0 ? "block" : "none");
        this.layers[SNAP_LAYER_IN_DIMENSION_INNER].attr("display", this.settings.showInnerDimensionLayer === !0 ? "block" : "none");//add by gaoning 2017.8.10增加内墙标尺
        this.layers[Annotation.prototype.type].attr("display", this.settings.showTextAnnotation === !0 ? "block" : "none");
        this.layers[Underlay.prototype.type].attr("display", this.settings.showUnderlayLayer === !0 ? "block" : "none");
        this.layers[WalkThrough.prototype.type].attr("display", this.settings.showWalkThroughLayer === !0 ? "block" : "none");

    },
    onUpdate: function () {
        return this.context ? classBase(this, "onUpdate") : !1;
    },
    createContextInternal: function () {
        if (this.domElement) {
            var context = Snap(this.domElement);
            return context;
        }
    },
    zoom: function (delta, mousePtX, mousePtY) {
        var factor = delta > 0 ? .9 : 1.11;
        var origPt = utilSvgModelSpaceToScreenSpace(this, 0, 0);
        this.zoomWithFactor(factor, mousePtX || origPt.x, mousePtY || origPt.y);
        var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
            return e;
        });
        if (pickObjs_product[0]) {
            application.laberFrame(pickObjs_product[0].model);//添加物体标注线输入框显示
        }
    },
    zoomWithFactor: function (factor, mousePtX, mousePtY) {
        var ptOldModelPt = utilSvgScreenSpaceToModelSpace(this, mousePtX, mousePtY);
        this.viewport.width *= factor, this.viewport.height *= factor;
        var ptNewModelPt = utilSvgScreenSpaceToModelSpace(this, mousePtX, mousePtY);
        this.viewport.left += 100 * (ptOldModelPt.x - ptNewModelPt.x), this.viewport.top += -100 * (ptOldModelPt.y - ptNewModelPt.y);
        this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);
        this.zoomChangedEvent && this.zoomChangedEvent.dispatch(this.viewport, factor);

        // 计算viewPoint的变化量
        //var scale = this.orginViewPointWidth / this.viewport.width;

        //SNAP_LAYER_IN_DIMENSION_INNER
        if (this.layers[SNAP_LAYER_IN_DIMENSION_INNER]) {
            for (var i = 0; i < this.layers[SNAP_LAYER_IN_DIMENSION_INNER].node.children.length; i++) {
                if (this.layers[SNAP_LAYER_IN_DIMENSION_INNER].node.children[i].style.fontSize) {
                    var newFontSize = this.getRoomLabelFontSize();
                    this.layers[SNAP_LAYER_IN_DIMENSION_INNER].node.children[i].style.fontSize = newFontSize + "px";
                }
            }
        }
        ;

        //SNAP_LAYER_IN_DIMENSION
        if (this.layers[SNAP_LAYER_IN_DIMENSION]) {
            for (var i = 0; i < this.layers[SNAP_LAYER_IN_DIMENSION].node.children.length; i++) {
                if (this.layers[SNAP_LAYER_IN_DIMENSION].node.children[i].style.fontSize) {
                    var newFontSize = this.getRoomLabelFontSize();
                    this.layers[SNAP_LAYER_IN_DIMENSION].node.children[i].style.fontSize = newFontSize + "px";
                }
            }
        };

        //画区域时鼠标点与墙的距离显示
        if (this.layers[PRODUCT_MARK]) {
            for (var i = 0; i < this.layers[PRODUCT_MARK].node.children.length; i++) {
                if (this.layers[PRODUCT_MARK].node.children[i].style.fontSize) {
                    var newFontSize = this.getAreaLabelSize(10,20);
                    this.layers[PRODUCT_MARK].node.children[i].style.fontSize = newFontSize + "px";
                }
                if (this.layers[PRODUCT_MARK].node.children[i].width){
                    var newWidth = this.getAreaLabelSize(10, 50);
                    this.layers[PRODUCT_MARK].node.children[i].tagName!='image' && this.layers[PRODUCT_MARK].node.children[i].setAttribute("width", newWidth);

                }
                if (this.layers[PRODUCT_MARK].node.children[i].height) {
                    var newHeight = this.getAreaLabelSize(10, 30);
                    this.layers[PRODUCT_MARK].node.children[i].tagName!='image' && this.layers[PRODUCT_MARK].node.children[i].setAttribute("height", newHeight);
                }                             
            }

            reFreshMouseToWallLine();
            refreshDimensions();
        };
        
        

        if (this.layers[SNAP_LAYER_ROOMLABEL]) {
            for (var i = 0; i < this.layers[SNAP_LAYER_ROOMLABEL].node.children.length; i++) {
                if (this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0]) {
                    var newFontSize = this.getDimensionFontSize();
                    this.layers[SNAP_LAYER_ROOMLABEL].node.children[i].style.fontSize = newFontSize + "px";
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0].setAttribute('dx', "0");
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0].setAttribute('dy', "0");
                    var length = this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0].getComputedTextLength();
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[1].setAttribute('dx', (-length).toString());
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[1].setAttribute('dy', (newFontSize).toString());
                }
            }
        }
        ;
    },
    resetFontSize: function () {
        if (!this.layers[SNAP_LAYER_IN_DIMENSION_INNER]) {
            return;
        }

        for (var i = 0; i < this.layers[SNAP_LAYER_IN_DIMENSION_INNER].node.children.length; i++) {
            if (this.layers[SNAP_LAYER_IN_DIMENSION_INNER].node.children[i].style.fontSize) {
                this.layers[SNAP_LAYER_IN_DIMENSION_INNER].node.children[i].style.fontSize = this.getRoomLabelFontSize() + "px";
            }
        }
        //SNAP_LAYER_IN_DIMENSION
        for (var i = 0; i < this.layers[SNAP_LAYER_IN_DIMENSION].node.children.length; i++) {
            if (this.layers[SNAP_LAYER_IN_DIMENSION].node.children[i].style.fontSize) {
                this.layers[SNAP_LAYER_IN_DIMENSION].node.children[i].style.fontSize = this.getRoomLabelFontSize() + "px";
            }
        }

        for (var i = 0; i < this.layers[SNAP_LAYER_ROOMLABEL].node.children.length; i++) {
            if (this.layers[SNAP_LAYER_ROOMLABEL].node.children[i].style.fontSize) {
                if (this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0]) {
                    this.layers[SNAP_LAYER_ROOMLABEL].node.children[i].style.fontSize = this.getDimensionFontSize() + "px";
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0].setAttribute('dx', "0");
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0].setAttribute('dy', "0");
                    var length = this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[0].getComputedTextLength();
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[1].setAttribute('dx', (-length).toString());
                    this.layers[SNAP_LAYER_ROOMLABEL].node.childNodes[i].childNodes[1].setAttribute('dy', this.getDimensionFontSize().toString());
                }
            }
        }
    },
    pan: function (delta_x, delta_y) {
        var mPosOffset = utilSvgVectorScreenSpaceToModelSpace(this, delta_x, delta_y);
        this.viewport.left -= 100 * mPosOffset.x, this.viewport.top += 100 * mPosOffset.y,
            this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);
        var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
            return e;
        });
        if (pickObjs_product[0]) {
            application.laberFrame(pickObjs_product[0].model);//添加物体标注线输入框显示
        }
    },
    /*
     * 在misc.footer.js 下面 addView时被调用
     * addView: function (v) {
     * return v instanceof AView || __assert(!1, "bad view!"), v.init(), this.views[v.id] = v,v;
     }在【app.comp.js】
     * add -by oxl -2017-02-27
     * */
    init: function () {
        try {
            classBase(this, "init");
        } catch (e) {
        }
        if (this.context) {
            this.hammer = "undefined" != typeof Hammer && this.domElement ? new Hammer.Manager(this.domElement) : void 0;
            utilSvgBindTouchEvent(this);
            utilSvgBindMouseEvent(this);
            utilSvgCreateLayers(this, this.layerOrder);
            var walkthroughLayer = this.layers[WalkThrough.prototype.type];
            walkthroughLayer && walkthroughLayer.attr("display", "none");
            utilSvgCreateGrid(this, {
                id: "Grid"
            }, this.layers.Grid);
            utilSvgCreateDimension(this, {
                id: SNAP_LAYER_OUT_DIMENSION
            }, this.layers[SNAP_LAYER_OUT_DIMENSION]);
            this.fit();
        }
    },
    fit: function (expectModelBound, opt) {
        var f = 1.5;
        var width = this.getBoundingClientRect().width * f;
        var height = this.getBoundingClientRect().height * f;

        this.orginViewPointWidth = width;
        this.resetFontSize();

        if (this.viewport = this.viewport || new Bound(1 / 0, 1 / 0, 0, 0), this.viewport.left = -width / 2,
                this.viewport.top = -height / 2, this.viewport.width = width, this.viewport.height = height,
            !this.doc || !this.doc.floorplan) {

            this.orginViewPointWidth = width;
            this.resetFontSize();
            return void this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);
        }
        if (this.id != 'map') {
            this.zoomChangedEvent && this.zoomChangedEvent.dispatch(this.viewport);
        }
        var bound = expectModelBound || utilFloorplanGetBound(this.doc.floorplan);
        var factor = 100;
        var extFactor = opt && opt.extFactor || 0.2;
        var ext = Math.min(bound.width, bound.height) * extFactor;
        if (bound = utilBoundAddMarginClone(bound, ext, ext), bound.scale(factor, factor),
                !utilBoundIsValid(bound)) {

            this.orginViewPointWidth = width;
            this.resetFontSize();
            return void this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);
        }
        var center = bound.center();
        var actualWidth = bound.width;
        var actualHeight = bound.height;
        width / height > bound.width / bound.height ? actualWidth = width / height * bound.height : actualHeight = height / width * bound.width;

        this.viewport.left = center.x - actualWidth / 2;
        this.viewport.top = -center.y - actualHeight / 2;
        this.viewport.width = actualWidth;
        this.viewport.height = actualHeight;

        this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);

        var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
            return e;
        });
        if (pickObjs_product[0]) {
            application.laberFrame(pickObjs_product[0].model);//添加物体标注线输入框显示
        }
        if (this.id != 'map') {
            this.zoomChangedEvent && this.zoomChangedEvent.dispatch(this.viewport);
        }
        this.orginViewPointWidth = width;
        this.resetFontSize();
    },

    fitToExport: function (h, w, centerPoint, expectModelBound, opt) {
        var f = 1.5;
        var width = this.getBoundingClientRect().width * f;
        var height = this.getBoundingClientRect().height * f;
        if (this.viewport = this.viewport || new Bound(1 / 0, 1 / 0, 0, 0), this.viewport.left = -width / 2,
                this.viewport.top = -height / 2, this.viewport.width = width, this.viewport.height = height,
            !this.doc || !this.doc.floorplan) {
            return void this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);
        }
        if (this.id != 'map') {
            this.zoomChangedEvent && this.zoomChangedEvent.dispatch(this.viewport);
        }
        var bound = expectModelBound || utilFloorplanGetBound(this.doc.floorplan);
        var factor = 100;
        var extFactor = opt && opt.extFactor || 0.2;
        var ext = Math.min(bound.width, bound.height) * extFactor;
        if (bound = utilBoundAddMarginClone(bound, ext, ext), bound.scale(factor, factor),
                !utilBoundIsValid(bound)) {
            return void this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);
        }
        var center = bound.center();
        var actualWidth = bound.width;
        var actualHeight = bound.height;
        width / height > bound.width / bound.height ? actualWidth = width / height * bound.height : actualHeight = height / width * bound.width;

        //this.viewport.left = center.x - actualWidth / 2;
        //this.viewport.top = -center.y - actualHeight / 2;
        //this.viewport.width = actualWidth;
        //this.viewport.height = actualHeight;

        //if (w > h) {
        //    this.viewport.left = center.x - w / 2;
        //    this.viewport.top = -center.y - h / 2  - (w/1.1312 - h)/2;
        //} else if (w < h) {
        //    this.viewport.left = center.x - w / 2  - (1.1312*h - w)/2;
        //    this.viewport.top = -center.y - h / 2;
        //}else{
        //    this.viewport.left = center.x - w / 2;
        //    this.viewport.top = -center.y - h / 2;
        //}

        if (w / 1.1312 > h) {
            this.viewport.left = centerPoint.x / 10 - w / 2;
            this.viewport.top = -centerPoint.y / 10 - h / 2 - (w / 1.1312 - h) / 2;
        } else if (w / 1.1312 < h) {
            this.viewport.left = centerPoint.x / 10 - w / 2 - (1.1312 * h - w) / 2;
            this.viewport.top = -centerPoint.y / 10 - h / 2;
        } else {
            this.viewport.left = centerPoint.x / 10 - w / 2;
            this.viewport.top = -centerPoint.y / 10 - h / 2;
        }

        //this.viewport.left = centerPoint.x /10 - w / 2;
        //this.viewport.top = -centerPoint.y/10 - h / 2;
        this.viewport.width = w;
        this.viewport.height = h;

        this.context.attr("viewBox", this.viewport.left + "," + this.viewport.top + "," + this.viewport.width + "," + this.viewport.height);

        var pickObjs_product = api.pickGetPicked(function (e) {//获取当前选中物体
            return e;
        });
        if (pickObjs_product[0]) {
            application.laberFrame(pickObjs_product[0].model);//添加物体标注线输入框显示
        }
        if (this.id != 'map') {
            this.zoomChangedEvent && this.zoomChangedEvent.dispatch(this.viewport);
        }
    },
    createDO: function (modelObject) {
        var model = modelObject, action = modelObject;
        if (this.context) {
            return model.type == Camera.prototype.type ? new DisplaySnapCamera(model, this) :
                model.type == Product.prototype.type || model.type == ProductReplacement.prototype.type ? new DisplaySnapProduct(model, this) :
                    model.type == Wall.prototype.type ? new DisplaySnapWall(model, this) :
                        model.type == Point.prototype.type ? new DisplaySnapPoint(model, this) :
                            model.type == BezierPoint.prototype.type ? new DisplaySnapBezierPoint(model, this) :
                                model.type == Floor.prototype.type ? new DisplaySnapFloor(model, this) :
                                    model.type == Opening.prototype.type ? new DisplaySnapOpening(model, this) :
                                        model.type == Door.prototype.type ? new DisplaySnapDoor(model, this) :
                                            model.type == Windows.prototype.type ? new DisplaySnapWindow(model, this) :
                                                model.type == Underlay.prototype.type ? new DisplaySnapUnderlay(model, this) :
                                                    model.type == FreeArea.prototype.type ? new DisplaySnapFreeArea(model, this) :
                                                        model.type == RoundArea.prototype.type ? new DisplaySnapRoundArea(model, this) :
                                                            model.type == RectArea.prototype.type ? new DisplaySnapRectArea(model, this) :
                                                                model.type == Annotation.prototype.type ? new DisplaySnapAnnotation(model, this) :
                                                                    model.type == WalkThrough.prototype.type ? new DisplaySnapWalkThrough(model, this) :
                                                                        model instanceof Cube ? new DisplaySnapCube(model, this) :
                                                                            model.type == Group.prototype.type ? new DisplaySnapGroup(model, this) :
                                                                                model.type == VRHotspot.prototype.type ? new DisplaySnapVRHotspot(model, this) :
                                                                                    model.type == Boundary.prototype.type ? new DisplaySnapBoundary(model, this) :
                                                                                        action.type == ActionAddWall.prototype.type ? new DisplaySnapActionAddWall(action, this) :
                                                                                            action.type == ActionAddFreeArea.prototype.type ? new DisplaySnapActionAddArea(action, this) :
                                                                                                action.type == ActionAddRectArea.prototype.type ? new DisplaySnapActionAddRectArea(action, this) :
                                                                                                    action.type == ActionAddRoundArea.prototype.type ? new DisplaySnapActionAddRoundArea(action, this) :
                                                                                                        action.type == ActionMovePoint.prototype.type ? new DisplaySnapActionMovePoint(action, this) :
                                                                                                            action.type == ActionMoveBezierPoint.prototype.type ? new DisplaySnapActionMoveBezierPoint(action, this) :
                                                                                                                action.type == ActionAnalyzeNormalized.prototype.type ? new DisplaySnapActionAnalyzeNormalized(action, this) :
                                                                                                                    action.type == ActionRulerMeasure.prototype.type ? new DisplaySnapActionRulerMeasure(action, this) :
                                                                                                                        action.type == ActionApplyModelroom.prototype.type ? new DisplaySnapActionApplyModelroom(action, this) :
                                                                                                                            void 0;
        }
    },
    PS2M: utilSvgScreenSpaceToModelSpace,
    VS2M: utilSvgVectorScreenSpaceToModelSpace,
    PM2S: utilSvgModelSpaceToScreenSpace
});

utilSnapViewCreatePattern = function () {
    /*2d 读取图片到场景;
     * TODO 产品和自定义拼花添加到画布时，添加图片的动作，add by oxl -2017-04-07*/
    var patterns = {};
    return function (view, material, patternId, onSuccess) {
        patternId = patternId || material.id;
        var context = view.context;
        var pid = material.pid;
        if (patterns[patternId]) {
            var patten = patterns[patternId];
            if (patten.children) {
                var children = patten.children();
                children.filter(function (child) {
                    return "image" == child.type;
                }).forEach(function (img) {
                    img.attr({
                        href: material.getUrl()
                    });
                });
            }
            return onSuccess && onSuccess(patten), patternId;
        }
        if ("dummy" == patterns[patternId])
            return patternId;
        patterns[patternId] = "dummy";
        var cMgr = view.app.catalogMgr;
        utilCatalogGetProductsMetaPromise(cMgr, [pid]).then(function (data) {
            var meta = data[pid];
            if (meta) {
                var width = 100 * meta.xlen;
                var height = 100 * meta.ylen;
                var pattern = context.image(material.getUrl(), 0, 0, width, height).toPattern(0, 0, width, height).attr({
                    id: patternId
                });
                patterns[patternId] = pattern;
                onSuccess && onSuccess(pattern);
            }
        });
        return patternId;
    };
}();