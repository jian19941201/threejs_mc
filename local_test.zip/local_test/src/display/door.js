//2D门显示对象
function DisplaySnapDoor(modelObject, view) {
    classBase(this, modelObject, view);
}

classInherit(DisplaySnapDoor, DisplaySnapOpening);
utilExtend(DisplaySnapDoor.prototype, {
    createAux: function (bound) {
        function createAux_generalDoor() {
            return [context.path("").attr({
                stroke: SNAP_OPENING_STROKE_COLOR.normal,
                "stroke-width": 3,
                "fill-opacity": .01,
                fill: "#c0c0c0"
            })];
        }

        function createAux_slidingDoor() {
            return [context.path("").attr({
                stroke: SNAP_OPENING_STROKE_COLOR.normal,
                "stroke-width": 3,
                "fill-opacity": 1,
                fill: "#E0E0E0"
            })];
        }
        var context = (this.view, this.view.context);
        switch (this.model.meta.subcategory) {
            case "slidingdoor":
                return createAux_slidingDoor.bind(this)();

            case "doublecasementdoor":
                return createAux_generalDoor.bind(this)();

            default:
                return createAux_generalDoor.bind(this)();
        }
    },
    updateAuxGeom: function (bound) {
        function getAuxPath_doubleCasementDoor() {
            var taper_begin, taper_end, swing = this.model.swing, rot = this.model.rot, path = "", w = bound.width / 2, center = Bound.prototype.center.call(bound), begin = {
                x: center.x - bound.width / 2,
                y: center.y
            }, end = {
                x: center.x + bound.width / 2,
                y: center.y
            };
            switch (begin = utilMathRotatePointCW(center, begin, -rot), end = utilMathRotatePointCW(center, end, -rot),
                swing) {
                case 0:
                case 2:
                    taper_begin = utilMathRotatePointCW(begin, center, 90), taper_end = utilMathRotatePointCW(end, center, -90),
                        path = "M" + begin.x + " " + begin.y + "L" + taper_begin.x + " " + taper_begin.y + "A" + w + " " + w + " 0 0 0 " + center.x + " " + center.y + "A" + w + " " + w + " 0 0 0 " + taper_end.x + " " + taper_end.y + "L" + end.x + " " + end.y;
                    break;

                case 1:
                case 3:
                    taper_begin = utilMathRotatePointCW(begin, center, -90), taper_end = utilMathRotatePointCW(end, center, 90),
                        path = "M" + begin.x + " " + begin.y + "L" + taper_begin.x + " " + taper_begin.y + "A" + w + " " + w + " 0 0 1 " + center.x + " " + center.y + "A" + w + " " + w + " 0 0 1 " + taper_end.x + " " + taper_end.y + "L" + end.x + " " + end.y;
            }
            return path;
        }

        function getAuxPath_generalDoor() {
            var taper, swing = this.model.swing, rot = this.model.rot, path = "", w = bound.width, center = Bound.prototype.center.call(bound), begin = {
                x: center.x - bound.width / 2,
                y: center.y
            }, end = {
                x: center.x + bound.width / 2,
                y: center.y
            };
            switch (begin = utilMathRotatePointCW(center, begin, -rot), end = utilMathRotatePointCW(center, end, -rot),
                swing) {
                case 0:
                    taper = utilMathRotatePointCW(begin, end, 90), path = "M" + begin.x + " " + begin.y + "L" + taper.x + " " + taper.y + "A" + w + " " + w + " 0 0 0 " + end.x + " " + end.y;
                    break;

                case 1:
                    taper = utilMathRotatePointCW(begin, end, -90), path = "M" + begin.x + " " + begin.y + "L" + taper.x + " " + taper.y + "A" + w + " " + w + " 0 0 1 " + end.x + " " + end.y;
                    break;

                case 3:
                    taper = utilMathRotatePointCW(end, begin, -90), path = "M" + end.x + " " + end.y + "L" + taper.x + " " + taper.y + "A" + w + " " + w + " 0 0 1 " + begin.x + " " + begin.y;
                    break;

                case 2:
                    taper = utilMathRotatePointCW(end, begin, 90), path = "M" + end.x + " " + end.y + "L" + taper.x + " " + taper.y + "A" + w + " " + w + " 0 0 0 " + begin.x + " " + begin.y;
            }
            return path;
        }

        function getAuxPath_slidingDoor() {
            var l = bound.left, t = bound.top, w = bound.width, h = bound.height;
            return "M" + l + "," + t + "L" + (l + 2 * w / 3) + "," + t + "L" + (l + 2 * w / 3) + "," + (t + h / 2) + "L" + l + "," + (t + h / 2) + "ZM" + (l + w / 3) + "," + (t + h / 2) + "L" + (l + w) + "," + (t + h / 2) + "L" + (l + w) + "," + (t + h) + "L" + (l + w / 3) + "," + (t + h) + "Z";
        }

        var auxes = this.auxiliaries;
        this.view, this.view.context;

        switch (this.model.meta.subcategory) {
            case "slidingdoor":
                var path = getAuxPath_slidingDoor.bind(this)();
                auxes[0].attr({
                    path: path
                }).transform("r" + -this.model.rot);
                break;

            case "doublecasementdoor":
                var path = getAuxPath_doubleCasementDoor.bind(this)();
                auxes[0].attr({
                    path: path
                }).transform("");
                break;

            default:
                var path = getAuxPath_generalDoor.bind(this)();
                auxes[0].attr({
                    path: path
                }).transform("");
        }
    },
    updateAuxFlag: function () {
        var auxes = this.auxiliaries, view = this.view, picked = (this.view.context, utilPickMgrIsPicked(view.app.pickMgr, this.model));
        auxes.forEach(function (aux) {
            aux.attr({
                stroke: picked ? SNAP_OPENING_STROKE_COLOR.pick : SNAP_OPENING_STROKE_COLOR.normal
            });
        });
    }
})

//3D门显示对象
function DisplayThreeDoor(model, view) {
    classBase(this, model, view);
}

classInherit(DisplayThreeDoor, DisplayThreeOpening), utilExtend(DisplayThreeDoor.prototype, {
    create: function () {
        classBase(this, "create");
    },
    update: function () {
        classBase(this, "update");
    },
    destroy: function () {
        classBase(this, "destroy");
    }
})