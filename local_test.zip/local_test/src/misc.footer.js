function brandOceanoSettings(setting) {
    /*1.欧神诺品牌的时*/
    SNAP_CAMERA_REGION.color = "#e85200", SNAP_CAMERA_REGION["stroke-width"] = 1, MAP_VIEW_FLOOR_COLOR.select = "#ff7836";
    var _srcUtilCatalogGetFileUrl = utilCatalogGetFileUrl, /*保存原有的方法，utilCatalogGetFileUrl方法在app.comp.js定义*/

        oceanoUtilCatalogGetFileUrl = function (catalogMgr, category, productId, type, imgSuffix) {
            return "top" == type && "png" == imgSuffix ? ("product" == category && (category = "products"),
            "http://pic.oceano.com.cn/h5filesystem/" + category + "/" + productId + "/top.png") : "top" == type && "jpg" == imgSuffix ? ("product" == category && (category = "products"),
            "http://pic.oceano.com.cn/h5filesystem/" + category + "/" + productId + "/top.jpg") : "iso" == type || "texture" == type ? ("product" == category && (category = "products"),
            "http://pic.oceano.com.cn/h5filesystem/" + category + "/" + productId + "/" + ("iso" == type ? "thumb.jpg" : "product.png")) : 
            (("thumb" == type && "jpg" == imgSuffix && "underlay" == category) ? ("http://pic.oceano.com.cn/h5filesystem/" + category + "/" + productId + "/thumb.jpg") : _srcUtilCatalogGetFileUrl(catalogMgr, category, productId, type));
        };
    /*2.就将oceanoUtilCatalogGetFileUrl赋值给 utilCatalogGetFileUrl 覆盖原有获取效果图资源的方法,_srcUtilCatalogGetFileUrl是兜底的作用；
     * --add by oxl*/
    utilCatalogGetFileUrl = oceanoUtilCatalogGetFileUrl;
}

/*给api对象绑定各种方法*/
/*bind方法将参数插到原来参数队列的第一个
 * https://segmentfault.com/a/1190000002662251 javasctipt 中bind方法的使用与实现
 * */
function utilInitApi() {
    utilExtend(api, {
        pickChangedEvent: application.pickMgr.pickChangedEvent,
        /*application.actionMgr.actionBeginEvent 引用在 action.comp.js function ActionManager(app)
         * add by oxl 2017-03-01
         * */
        actionBeginEvent: application.actionMgr.actionBeginEvent,
        actionEndEvent: application.actionMgr.actionEndEvent,
        actionUndoRedoChangedEvent: application.actionMgr.actionUndoRedoChangedEvent,
        documentReadyEvent: application.documentReadyEvent,
        documentLockChangedEvent: application.documentLockChangedEvent,
        structureChangedEvent: application.structureChangedEvent,
        rulerMeasurementChanged: application.rulerMeasurementChanged,
        appGetVersion: utilAppGetVersion.bind(void 0, application),
        pickGetPicked: utilPickMgrGetPickResults.bind(void 0, application.pickMgr),
        pickGetPickedGroup: utilPickMgrGetPickGroupResults.bind(void 0, application.pickMgr),
        unPickAll:utilPickMgrUnpickAll.bind(void 0, application.pickMgr),
        documentSave: utilAppDocumentSave.bind(void 0, application),
        documentLoad: utilAppDocumentLoad.bind(void 0, application),
        documentLoadGhost: utilAppDocumentLoadGhost.bind(void 0, application),
        documentSetActiveCameras: utilAppDocumentSetActiveCameras.bind(void 0, application),//set 鸟瞰
        documentGetCameras: utilAppDocumentGetCameras.bind(void 0, application),
        documentGetActiveCamera: utilAppDocumentGetActiveCamera.bind(void 0, application),
        documentGetActiveCameraMatrix: utilActiveCameraMatrix.bind(void 0),
        floorplanIsLocked: utilAppFloorplanIsLocked.bind(void 0, application),
        floorplanLock: utilAppFloorplanLock.bind(void 0, application),
        floorplanGetUnderImageScale: utilAppFloorplanGetUnderImageScale.bind(void 0, application),
        floorplanSetUnderImageScale: utilAppFloorplanSetUnderImageScale.bind(void 0, application),
        floorplanGetAreasByHostId: utilAppFloorplanGetAreasByHostId.bind(void 0, application),
        floorplanGetBoardsByWall: utilAppFloorplanGetBoardsByWall.bind(void 0, application),
        floorplanGetCompassRotation: utilAppFloorplanGetCompassRotation.bind(void 0, application),
        floorplanSetCompassRotation: utilAppFloorplanSetCompassRotation.bind(void 0, application),
        floorplanIsNormalized: utilAppFloorplanIsNormalized.bind(void 0, application),
        floorplanMakeNormalized: utilAppFloorplanMakeNormalized.bind(void 0, application),
        floorplanFilterEntity: utilAppFloorplanFilterEntity.bind(void 0, application),
        floorplanGetOrCreateAnimationByName: utilAppFloorplanGetOrCreateAnimationByName.bind(void 0, application),
        floorplanGetAnimationNames: utilAppFloorplanGetAnimationNames.bind(void 0, application),
        floorCreatePathFromLoop: utilSnapFloorCreatePathFromLoop.bind(void 0),
        animationKeyBuildFromModel: utilAnimationKeyBuildFromModel.bind(void 0),
        animationKeyFlushToModel: utilAnimationKeyFlushToModel.bind(void 0),
        animationGetAllKeys: utilAnimationGetAllKeys.bind(void 0),
        animationAddKey: utilAnimationAddKey.bind(void 0),
        animationDeleteKey: utilAnimationDeleteKey.bind(void 0),
        animationGetLerpKeys: utilAnimationGetLerpKeys.bind(void 0),
        animationInterpolator: AnimationInterpolator,
        getServicePrefix: utilAppGetServicePrefix.bind(void 0, application),
        getServiceJSONResponsePromise: utilAppGetServiceJSONResponsePromise.bind(void 0, application),
        getServiceJSONResponsePromiseUpload: utilAppGetServiceJSONResponsePromiseUpload.bind(void 0, application),//add by hcw
        catalogGetFileUrl: utilCatalogGetFileUrl.bind(void 0, application.catalogMgr), /*初始化加载Catalog资源，application = globalCreateApplication(settings)--add by oxl*/
        catalogGetProductsMetaPromise: utilCatalogGetProductsMetaPromise.bind(void 0, application.catalogMgr),
        catalogGetCustomProductsMetaPromise: utilCatalogGetCustomProductsMetaPromise.bind(void 0, application.catalogMgr), /*获取自定义拼花的元数据（之后插入画布）--add by oxl*/
        catalogGetCustomModelProductsMetaPromise: utilCatalogGetCustomModelProductsMetaPromise.bind(void 0, application.catalogMgr), /*获取自定义模型的元数据（之后插入画布）--add by hcw*/
        catalogGetProductsDetailPromise: utilCatalogGetProductsDetailPromise.bind(void 0, application.catalogMgr),
        catalogGetCatalogTreePromise: utilCatalogGetCatalogTreePromise.bind(void 0, application.catalogMgr), /*catalog目录树读取 utilCatalogGetCatalogTreePromise ，在app.comp.js定义--add by oxl*/
        catalogSetUserRootCustomCatalogPromise: utilSetUserRootCustomCatalogPromise.bind(void 0, application.catalogMgr), /*创建自定义拼花catalog根目录，在app.comp.js定义--2017-03-14 add by oxl*/
        catalogGetCustomTileCatalogTreePromise: utilGetCustomTileCatalogTreePromise.bind(void 0, application.catalogMgr), /*自定义拼花catalog目录树读取，在app.comp.js定义--2017-03-04 add by oxl*/
        catalogGetFileContentPromise: utilCatalogGetFileContentPromise.bind(void 0, application.catalogMgr),
        catalogGetCustomFileContentPromise: utilCustomModelGetFileContentPromise.bind(void 0, application.catalogMgr), /* 自定义模型目录树读取，在app.comp.js定义 add by hcw*/
        actionBegin: utilActionBegin.bind(void 0, application.actionMgr),
        actionRun: utilActionRun.bind(void 0, application.actionMgr),
        actionEnd: utilActionEnd.bind(void 0, application.actionMgr),
        getCurrentAction: utilActionGetCurrentAction.bind(void 0, application.actionMgr),
        actionUndo: utilActionUndo.bind(void 0, application.actionMgr),
        actionRedo: utilActionRedo.bind(void 0, application.actionMgr),
        viewSetFPS: utilViewSetFPS.bind(void 0, application),
        viewFit: utilViewFit.bind(void 0, application),
        adaptorClipperOffsetArray: utilAdaptorClipperOffsetArray.bind(void 0),

        getViewById: utilAppGetViewById.bind(void 0, application),
        materialGetRasterizedOffsetFromUV: materialGetRasterizedOffsetFromUV.bind(void 0),
        materialComputeRasterizedTranslationFromOffset: materialComputeRasterizedTranslationFromOffset.bind(void 0),
        materialRawColorCreate: utilMaterialRawColorCreate.bind(void 0),
        tileSingleCreate: utilTileSingleCreate.bind(void 0),
        tileSingleGetUrl: utilTileSingleGetUrl,
        threeSetTransformMode: "undefined" != typeof utilThreeViewSetTransformMode ? utilThreeViewSetTransformMode.bind(void 0, application.views["3d"]) : void 0,
        threeExport: "undefined" != typeof utilThreeViewExport ? utilThreeViewExport.bind(void 0, application.views["3d"]) : void 0,
        wallAdjacentPoint: utilWallAdjacentPoint.bind(void 0),
        snapExport: "undefined" != typeof utilSnapViewExport ? utilSnapViewExport.bind(void 0, application.views["2d"]) : void 0,
        saveAs: saveAs.bind(),
        uuid: utilUUID,
        getBase64:Base64, //base64 编码解码 add by hcw
        decodeStringToByteArray: goog_crypt_base64_decodeStringToByteArray,
        stringToByteArray: stringToByteArray,
        uintToString: uintToString,
        getBomData: utilAppFloorplanGetBomData.bind(void 0, application),
        getBomOneData: utilAppFloorplanGetBomOneData.bind(void 0, application),
        mathRotatePointCW: utilMathRotatePointCW.bind(void 0),
        utilEncryptString: utilEncryptString.bind(void 0),
        utilMathLineLineIntersection: utilMathLineLineIntersection.bind(void 0),
        utilMathLinelineCCWAngle: utilMathLinelineCCWAngle.bind(void 0),
        utilMathLineLength: utilMathLineLength.bind(void 0),
        utilExportJSONData2: utilExportJSONData2.bind(void 0),
        utilExportJSONData3: utilExportJSONData3.bind(void 0),//立面CAD  gaonig
        getWallInsideLoopFromProfile: getWallInsideLoopFromProfile.bind(void 0), //获取房间墙面数据
        stringToHexCharCode: utilStringToHexCharCode.bind(void 0), //颜色string to hex格式
        mathGetScaledPoint:utilMathGetScaledPoint.bind(void 0),
        utilFloorCreateSnapStylesExport: utilFloorCreateSnapStylesExport.bind(void 0),
        utilAreaCreateSnapStylesExport: utilAreaCreateSnapStylesExport.bind(void 0),
        utilModelWallGetSmoothStart: utilModelWallGetSmoothStart.bind(void 0), //获取墙体平滑开端
        utilModelWallGetSideLength: utilModelWallGetSideLength.bind(void 0),   //获取墙体长度
        utilModelWallGetSmoothHoleprofiles: utilModelWallGetSmoothHoleprofiles.bind(void 0), //获取墙体门窗

        //add by gaoning 2017.7.1  导出户型图设置
        InitLabels: InitLabels.bind(void 0),
        SetLabelActive: SetLabelActive.bind(void 0),
        setShowOutRoomLabel: setShowOutRoomLabel.bind(void 0),
        setShowOutLabel: setShowOutLabel.bind(void 0),
        getLengthIndex : getLengthIndex.bind(void 0),
        getSVGImageLength : getSVGImageLength.bind(void 0),//获取户型图大小
        getLabelCenterPoint : getCenterPoint.bind(void 0),
        getSnapLayerState : getSnapLayerState.bind(void 0),

        //导出CAD设置--add by gaoning 2017.7.13
        setDimensionLayer: setDimensionLayer.bind(void 0),
        getDimensionLayer: getDimensionLayer.bind(void 0),
        setRoomLabel: setRoomLabel.bind(void 0),
        getRoomLabel: getRoomLabel.bind(void 0),
        setTextAnnotation: setTextAnnotation.bind(void 0),
        getTextAnnotation: getTextAnnotation.bind(void 0),
        setOutRoomLabel: setOutRoomLabel.bind(void 0),
        getOutRoomLabel: getOutRoomLabel.bind(void 0),
        setOutLabel: setOutLabel.bind(void 0),
        getOutLabel: getOutLabel.bind(void 0),
        //初始化数据
        InitCADData: InitCADData.bind(void 0),
        //房间信息
        getTopRoomInfoArr: getTopRoomInfoArr.bind(void 0),
        getBottomRoomInfoArr: getBottomRoomInfoArr.bind(void 0),
        //墙标线
        getCADWallLines: getCADWallLines.bind(void 0),
        //还原设置数据
        getPaveTypeInfo: function(pavetype){return PAVEMODEL[pavetype];},

        PAVEMODEL:PAVEMODEL,
        Vec2: Vec2,
        Line: Line,
        THREE: THREE,
        checkPointInPolygon: checkPointInPolygon,//判断点是否在矩形内--gaoning 2017.2.15
        addTempGroup:addTempGroup,  //添加可拖动临时组合 add by hcw
        removeTempGroup:removeTempGroup, //删除所有临时组合  add by hcw
        checkEditGroupModel:checkEditGroupModel, // 判断是否为套装编辑模式 add by hcw
        clearCatalogProductMetaCache:clearProductMetaCache.bind(void 0, application.catalogMgr), //清除productsMeta里面的指定产品缓存数据 add by hcw
        getTmallOrderinfo:getTmallOrderinfoPromise, //获取天猫订单客户信息 add by hcw
        utilFloorTileAmountCompute:utilFloorTileAmountCompute,
        utilWallTileAmountCompute:utilWallTileAmountCompute,
        removeTempParentSvg:removeTempParentSvg,
        getIsGroupFlag:utilModelIsFlagOff,
        setWallInfo:setWallInfo,
        laberFrameEntry: function (entry) {
            application.laberFrame = entry;
        },
        showCustomModelProgress: function (entry) {
            application.CustomModelProgress = entry;
        },
        allCameraInit2D:function (entry) {
            application.allCameraInit=entry
        },
        makeCrash: function (msg) {
            throw new Error("make crash! + err msg :" + msg);
        }
    });
}
/*
 * oxl 2016-12-27
 * TODO 下次跟踪这里的入口代码：EditorApp(),2017-02-13,暂时看完
 * TODO 下次跟踪这里 new Document() 在app.comp.js，[classBase]和[classInherit] 在 model.comp.js 定义，优先看代码去理解
 *--add by oxl
 * */
function globalCreateApplication(settings) {
    /*EditorApp在app.comp.js定义和继承了[ AppBase ] ,[ AppBase ]继承于[Root]classInherit(AppBase, Root)
     * 最终暴露出去的接口是[ app ]
     * --add by oxl
     * */
    var app = new EditorApp({
        id: "application"
    }, settings);
    /*AppBase.prototype的 addView方法，在下面实例化后 就是 app.addView； 传入参数 v 参数 时，会调用参数对象的 init 方法；
     * addView: function (v) {
     return v instanceof AView || __assert(!1, "bad view!"), v.init(), this.views[v.id] = v,
     v;
     }在【app.comp.js】
     * add by oxl -2017-02-27
     * */
    "undefined" != typeof SnapView && app.addView(new SnapView(app, document.getElementById("paper2dsvg"), {
        id: "2d",
        fps: 15
    }));
    "undefined" != typeof MapView && app.addView(new MapView(app, document.getElementById("papermapsvg"), {
        id: "map",
        fps: 5
    }));
    "undefined" != typeof ThreeView && app.addView(new ThreeView(app, document.getElementById("paper3dwebgl"), {
        id: "3d",
        fps: 60,
        helpers: !0
    }));

    "undefined" != typeof ThreeView && document.getElementById("preview3d"), app.run();
    var doc1 = new Document({
        id: "doc01"
    });
    return app.doc = doc1, doc1.open(), app;
}

/*
 * oxl 2016-12-27
 * http://www.javascriptoo.com/js-signals 事件例子（发布订阅模式）
 * 绑定到全局，加载完bootstrap.js后，代码底部会执行dispatch调用这里发布（add）的事件：
 * ----if (window.bootstrap_complete_event)window.bootstrap_complete_event.dispatch(appSetting);-----调用
 * 完成调用后，又会再执行一次这里的dispatch：
 * ----application_ready_event.dispatch(settings)
 * 这里的参数settings(是形参)  ===  bootstrap.js 的appSetting(是实参)
 * --add by oxl
 * */
global.bootstrap_complete_event.add(function (settings) {
    var brand = settings.brand;
    /*品牌是oceano时才会执行这个在阿里云oss取资源素材，否则在本地服务器取素材
     * add by oxl 2017-04-07*/
    "oceano" == brand && brandOceanoSettings(settings);

    ///模拟编辑套件模式  add by hcw
    var edit=settings.edit
    "oceano" == edit && (EDIT_GROUP_MODEL=true);
}), global.bootstrap_complete_event.add(function (settings) {
    __log("Application settings = " + JSON.stringify(settings)), application = globalCreateApplication(settings), /*全站application在此处定义*/
        utilInitApi(), application_ready_event.dispatch(settings);
});