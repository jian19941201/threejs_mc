//添加波打线
function ActionAddBoundary(mgr) {
    classBase(this, mgr);
}

ActionAddBoundary.prototype.type = "AddBoundary";
classInherit(ActionAddBoundary, ActionBase);
utilExtend(ActionAddBoundary.prototype, {
    canUndoRedo: function () {
        return !0;
    },
    
    undo: function () {
    	
    },
    
    redo: function () {
    	
    },
    
    begin: function (opt, failcb) {
        this._opt = opt || {type:"base"};
        this._failcb = failcb;
    },
    
    end: function () {
        
    },
    
    run: function (cmd, evt, position, attachments) {
        if ("view2d_mouseup" == cmd) {
        	if (attachments[0] && (
        	    attachments[0].type == "FLOOR" ||
        	    attachments[0].type == "RECTAREA" ||
        	    attachments[0].type == "FREEAREA")
        	    ){
        		this.add(attachments[0]);
          }else if(attachments[0] && (attachments[0].type == "BOUNDARY")){
          	this.change(attachments[0]);
          }
        } else if ("click3d" == cmd) {
        	var modelType = position.model.type;
        	if(modelType == "FLOOR" || modelType == "RECTAREA" || modelType == "FREEAREA"){       		
        		this.add(position.model);
        	}else if(modelType == "BOUNDARY"){
        		this.change(position.model);
        	}
        }
    },
    
    add: function(host){
    	  if(host instanceof Floor){
    	  	  var offset = utilFloorGetBoundaryOffset(host) - DEFAULT_BOUNDARY_SIZE; //初始化默认 0.15 厚度
		        if(utilSnapFloorTestOffset(host, offset)){
		        	  var fp = application.doc.floorplan;
		        	  var boundary = new Boundary({host:host, type:this._opt.type});
		        	  boundary.level = 1;
		        	  boundary.size = this._opt.size;
		        	  boundary.cornerRot = this._opt.cornerRot ? this._opt.cornerRot : 0;
		        	  boundary.baseRot = this._opt.baseRot ? this._opt.baseRot : 0;
		        	  boundary.leftRot = this._opt.leftRot ? this._opt.leftRot : 0;
		        	  boundary.rightRot = this._opt.rightRot ? this._opt.rightRot : 0;
		        	  
								utilEntityAddLink(fp, boundary);
								
								var pids = [];
		            this._opt.corner && pids.push(this._opt.corner);
		            this._opt.base && pids.push(this._opt.base);
		            this._opt.left && pids.push(this._opt.left);
		            this._opt.right && pids.push(this._opt.right);
								utilCatalogGetProductsMetaPromise(application.catalogMgr, pids).then(function (meta) {
								    meta[this._opt.corner] ? (boundary.cornerMaterial = new Material(meta[this._opt.corner])) : boundary.cornerMaterial = null;
								    meta[this._opt.base]   ? (boundary.baseMaterial = new Material(meta[this._opt.base])) : boundary.baseMaterial = null;
								    meta[this._opt.left]   ? (boundary.leftMaterial = new Material(meta[this._opt.left])) : boundary.leftMaterial = null;
								    meta[this._opt.right]  ? (boundary.rightMaterial = new Material(meta[this._opt.right])) : boundary.rightMaterial = null;                
								}.bind(this));
								
								utilModelChangeFlag(host, FLOORFLAG_CHANGED_FOR_REDRAWN);
								utilActionEnd(this.mgr);        	 
		        }else{
		        	  //无法添加
		        	  utilActionEnd(this.mgr);
		        	  this._failcb && this._failcb();
		        }
    	  }else if(host instanceof RectArea || host instanceof FreeArea){
    	  	  var fp = application.doc.floorplan;
        	  var boundary = new Boundary({host:host, type:this._opt.type});
        	  boundary.level = host.level;
        	  boundary.size = this._opt.size;
        	  boundary.cornerRot = this._opt.cornerRot ? this._opt.cornerRot : 0;
        	  boundary.baseRot = this._opt.baseRot ? this._opt.baseRot : 0;
        	  boundary.leftRot = this._opt.leftRot ? this._opt.leftRot : 0;
        	  boundary.rightRot = this._opt.rightRot ? this._opt.rightRot : 0;
        	  
						utilEntityAddLink(fp, boundary);
						
            var pids = [];
            this._opt.corner && pids.push(this._opt.corner);
            this._opt.base && pids.push(this._opt.base);
            this._opt.left && pids.push(this._opt.left);
            this._opt.right && pids.push(this._opt.right);            
						utilCatalogGetProductsMetaPromise(application.catalogMgr, pids).then(function (meta) {
						    meta[this._opt.corner] ? (boundary.cornerMaterial = new Material(meta[this._opt.corner])) : boundary.cornerMaterial = null;
						    meta[this._opt.base]   ? (boundary.baseMaterial = new Material(meta[this._opt.base])) : boundary.baseMaterial = null;
						    meta[this._opt.left]   ? (boundary.leftMaterial = new Material(meta[this._opt.left])) : boundary.leftMaterial = null;
						    meta[this._opt.right]  ? (boundary.rightMaterial = new Material(meta[this._opt.right])) : boundary.rightMaterial = null;                
						}.bind(this));						
						utilActionEnd(this.mgr);
    	  }
        
    },
    
    change: function(boundary){
    	  boundary.corner = this._opt.type;
    	  boundary.size = this._opt.size;
    	  boundary.cornerRot = this._opt.cornerRot ? this._opt.cornerRot : 0;
    	  boundary.baseRot = this._opt.baseRot ? this._opt.baseRot : 0;
    	  boundary.leftRot = this._opt.leftRot ? this._opt.leftRot : 0;
    	  boundary.rightRot = this._opt.rightRot ? this._opt.rightRot : 0;
    	  
    	  var pids = [];
        this._opt.corner && pids.push(this._opt.corner);
        this._opt.base && pids.push(this._opt.base);
        this._opt.left && pids.push(this._opt.left);
        this._opt.right && pids.push(this._opt.right);
				utilCatalogGetProductsMetaPromise(application.catalogMgr, pids).then(function (meta) {
				    meta[this._opt.corner] ? (boundary.cornerMaterial = new Material(meta[this._opt.corner])) : boundary.cornerMaterial = null;
				    meta[this._opt.base]   ? (boundary.baseMaterial = new Material(meta[this._opt.base])) : boundary.baseMaterial = null;
				    meta[this._opt.left]   ? (boundary.leftMaterial = new Material(meta[this._opt.left])) : boundary.leftMaterial = null;
				    meta[this._opt.right]  ? (boundary.rightMaterial = new Material(meta[this._opt.right])) : boundary.rightMaterial = null;                
				}.bind(this));
				utilModelChangeFlag(boundary.host, AREAFLAG_CHANGED_FOR_REDRAWN);
				utilActionEnd(this.mgr);
    }
})


//删除波打线
function ActionDeleteBoundary(mgr) {
    classBase(this, mgr);
    this.boundary = void 0;
}

ActionDeleteBoundary.prototype.type = "DeleteBoundary";
classInherit(ActionDeleteBoundary, ActionBase);
utilExtend(ActionDeleteBoundary.prototype, {
    end: function () {
        utilFloorplanRebuildFloor(this.fp);        
    },
    begin: function (boundary) {
        this.boundary = boundary;
               
        var host = this.boundary.host;
        utilEntityRemoveLink(this.fp, boundary);
        
        if(host instanceof Floor){
        	  utilModelChangeFlag(host, FLOORFLAG_CHANGED_FOR_REDRAWN);
        }else if(host instanceof RectArea || host instanceof FreeArea){
        	  utilModelChangeFlag(host, AREAFLAG_CHANGED_FOR_REDRAWN);
        }
        
        utilActionEnd(this.mgr);
    }
});


//调整波打线大小
function ActionSetBoundarySize(mgr) {
    classBase(this, mgr);
    this.boundary = void 0;
}
ActionSetBoundarySize.prototype.type = "SetBoundarySize";
classInherit(ActionSetBoundarySize, ActionBase);
utilExtend(ActionSetBoundarySize.prototype, {
    end: function () {       
    },
    begin: function (boundary, size) {
    	  utilActionEnd(this.mgr);
    	  
    	  size = size < 0.01 ? 0.01 : size;
    	      	  
        this.boundary = boundary;
                       
        var host = this.boundary.host;
        var oldSize = this.boundary.size;        
        this.boundary.size = size;
        
        if(host instanceof Floor){
	        var offset = utilFloorGetBoundaryOffset(host);
	        if(utilSnapFloorTestOffset(host, offset)){
	        	 utilModelChangeFlag(host, FLOORFLAG_CHANGED_FOR_REDRAWN);
	        	 return true;
	        }else{
	        	 //无法扩展
	        	 this.boundary.size = oldSize;
	        	 return false;
	        }   
	      }else if(host instanceof RectArea || host instanceof FreeArea){
	      	utilModelChangeFlag(host, AREAFLAG_CHANGED_FOR_REDRAWN);
	      	return true;
	      }
    }
});

//调整波打线角度
function ActionSetBoundaryRot(mgr) {
    classBase(this, mgr);
    this.boundary = void 0;
}
ActionSetBoundaryRot.prototype.type = "SetBoundaryRot";
classInherit(ActionSetBoundaryRot, ActionBase);
utilExtend(ActionSetBoundaryRot.prototype, {
    end: function () {
    },
    begin: function (boundary, type, rot) {
    	  utilActionEnd(this.mgr);
    	     	      	  
        this.boundary = boundary;        
        this.boundary[type + "Rot"] = rot;
    }
});

//调整波打线砖缝
function ActionSetBoundaryGapOffsetX(mgr) {
    classBase(this, mgr);
    this.boundary = void 0;
}
ActionSetBoundaryGapOffsetX.prototype.type = "SetBoundaryGapOffsetX";
classInherit(ActionSetBoundaryGapOffsetX, ActionBase);
utilExtend(ActionSetBoundaryGapOffsetX.prototype, {
    end: function () {
    },
    begin: function (boundary, baseLoopIndex, offsetX) {
    	  utilActionEnd(this.mgr);
    	     	      	  
        this.boundary = boundary;
        this.boundary.baseOffsetX[baseLoopIndex] = offsetX;

        utilModelChangeFlag(this.boundary, BOUNDARY_CHANGED_FOR_REDRAWN);
				utilActionEnd(this.mgr);
    }
});

//# sourceURL=src\action\boundary.js