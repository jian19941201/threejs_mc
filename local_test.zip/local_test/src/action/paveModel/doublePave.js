//双砖模板

//双砖错位铺砖2
PAVEMODEL.DOUBLEPAVE_01 = {
	name:"DOUBLEPAVE_01",
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ],
    /*正方形或横向的砖用下面*/
	tiles: [
	 { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
	          {id:2,offset:{x:-0.5,y:1},center:{x:0,y:1.5}},
	          {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
	          {id:2,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}
	         ]	   
	 },
	 { id:2,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
	 	 pidIndex:0,	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:2,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
	          {id:1,offset:{x:-0.5,y:1},center:{x:0,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:2,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
	          {id:1,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}
	         ]
	 }
	]

}

PAVEMODEL.DOUBLEPAVE_02 = {//点铺
	name:"DOUBLEPAVE_02",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:2,offset:{x:1,y:0},center:{x:1,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:2,offset:{x:0,y:1},center:{x:0,y:1}},
			       {id:2,offset:{x:-1,y:0},center:{x:-1,y:0}},
			       {id:2,offset:{x:0,y:-1},center:{x:0,y:-1}}
			      ]
	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_03 = {//点铺
	name:"DOUBLEPAVE_03",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:0,x:-0.5,y:-0.5},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:2,offset:{x:1,y:0},center:{x:1,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:2,offset:{x:0,y:1},center:{x:0,y:1}},
			       {id:2,offset:{x:-1,y:0},center:{x:-1,y:0}},
			       {id:2,offset:{x:0,y:-1},center:{x:0,y:-1}}
			      ]
	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_04 = {//点铺
	name:"DOUBLEPAVE_04",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
			       {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
			       {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}}
			      ]
	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_05 = {//点铺
	name:"DOUBLEPAVE_05",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:2,offset:{x:1,y:1},center:{x:1,y:1}},
			       {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
			       {id:2,offset:{x:-1,y:1},center:{x:-1,y:1}},
			       {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
			       {id:2,offset:{x:-1,y:-1},center:{x:-1,y:-1}},
			       {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}},
			       {id:2,offset:{x:1,y:-1},center:{x:1,y:-1}}
			      ]
	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_06 = {//点铺
	name:"DOUBLEPAVE_06",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:0,x:-0.5,y:-0.5},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:2,offset:{x:1,y:1},center:{x:1,y:1}},
			       {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
			       {id:2,offset:{x:-1,y:1},center:{x:-1,y:1}},
			       {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
			       {id:2,offset:{x:-1,y:-1},center:{x:-1,y:-1}},
			       {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}},
			       {id:2,offset:{x:1,y:-1},center:{x:1,y:-1}}
			      ]
	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_07 = {//点铺
	name:"DOUBLEPAVE_07",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:-1,ay:0.08},center:{x:1.5,y:-0.5,ay:0.04}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:1,y:0,ay:0.08},center:{x:1.5,y:0.5,ay:0.04}}, 
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:1,ay:-0.08},center:{x:-1.5,y:1.5,ay:-0.04}},
			       {id:1,offset:{x:-1,y:0,ay:-0.08},center:{x:-1.5,y:0.5,ay:-0.04}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:0,y:-1},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
			      {id:2,offset:{x:1,y:0,ay:0.08},center:{x:1,y:0,ax:0.04,ay:0.04}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			      {id:2,offset:{x:0,y:1},center:{x:0,y:1,ax:0.04,ay:-0.04}},
			      {id:2,offset:{x:-1,y:0,ay:-0.08},center:{x:-1,y:0,ax:0.04,ay:-0.12}},
			      {id:2,offset:{x:0,y:-1},center:{x:0,y:-1,ax:0.04,ay:-0.04}}
			      ]
	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_08 = {//点铺
	name:"DOUBLEPAVE_08",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:0,y:-1},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
			      {id:2,offset:{x:1,y:0},center:{x:1,y:0,ax:0.04,ay:-0.04}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			      {id:2,offset:{x:0,y:1},center:{x:0,y:1,ax:0.04,ay:-0.04}},
			      {id:2,offset:{x:-1,y:0},center:{x:-1,y:0,ax:0.04,ay:-0.04}},
			      {id:2,offset:{x:0,y:-1},center:{x:0,y:-1,ax:0.04,ay:-0.04}}
			      ]
	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_09 = {//点铺
	name:"DOUBLEPAVE_09",
	//需要加载的pids列表(用于初始化材质列表)
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ], 
	tiles: //主砖
	[
	 {  id:1,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			       {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
			       {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
			       {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
			      ]
	 }
	],
	topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
	[
	  { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material	  	
			rot:{r:0,y:-1},   //旋转45度后偏移l(自身对角线长度)
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
			      {id:2,offset:{x:1,y:0},center:{x:1,y:0,ax:0.04,ay:-0.04}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
			      {id:2,offset:{x:0,y:1},center:{x:0,y:1,ax:0.04,ay:-0.04}},
			      {id:2,offset:{x:-1,y:0},center:{x:-1,y:0,ax:0.04,ay:-0.04}},
			      {id:2,offset:{x:0,y:-1},center:{x:0,y:-1,ax:0.04,ay:-0.04}},			      
			      {id:3,offset:{x:0,y:0,ax:-0.08},center:{x:0,y:0,ax:-0.04,ay:0.04}}
			      ]	  	
	  },
	  { id:3,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
			aw:0.08,  //绝对长宽aw,ah，单位m
			ah:0.08,
			pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
			      {id:3,offset:{x:1,y:0},center:{x:1,y:0,ax:0.04,ay:0.04}},
			      {id:3,offset:{x:0,y:1},center:{x:0,y:1,ax:0.04,ay:0.04}},
			      {id:3,offset:{x:-1,y:0},center:{x:-1,y:0,ax:0.04,ay:0.04}},
			      {id:3,offset:{x:0,y:-1},center:{x:0,y:-1,ax:0.04,ay:0.04}}
			      ]	  	
	  }
	]
}

PAVEMODEL.DOUBLEPAVE_10 = {//对角线三角形点铺
    name:"DOUBLEPAVE_10",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,
                aw:0.16,  //绝对长宽aw,ah，单位m
                ah:0.16,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:0,y:-1},   //旋转45度后偏移l(自身对角线长度)
                profile:[{x:0,y:0},{x:0,y:1},{x:1,y:1}],
                nodes:[
                    {id:2,offset:{x:1,y:0},center:{x:1,y:0,ax:0.04,ay:-0.04}},
                    {id:2,offset:{x:0,y:1},center:{x:0,y:1,ax:0.04,ay:-0.04}},
                    {id:2,offset:{x:-1,y:0},center:{x:-1,y:0,ax:0.04,ay:-0.04}},
                    {id:2,offset:{x:0,y:-1},center:{x:0,y:-1,ax:0.04,ay:-0.04}},
                    {id:3,offset:{x:0,y:0,ax:-0.08},center:{x:0,y:0,ax:-0.04,ay:0.04}}
                ]
            },
            { id:3,
                aw:0.16,
                ah:0.16,
                pidIndex:0,
                rot:{r:0,x:-0.5},
                profile:[{x:0,y:0},{x:1,y:1},{x:1,y:0}],
                nodes:[
                    {id:3,offset:{x:1,y:0},center:{x:1,y:0,ax:0.04,ay:0.04}},
                    {id:3,offset:{x:0,y:1},center:{x:0,y:1,ax:0.04,ay:0.04}},
                    {id:3,offset:{x:-1,y:0},center:{x:-1,y:0,ax:0.04,ay:0.04}},
                    {id:3,offset:{x:0,y:-1},center:{x:0,y:-1,ax:0.04,ay:0.04}}
                ]
            }
        ]
}

PAVEMODEL.DOUBLEPAVE_11 = {//左大砖右小砖
    name:"DOUBLEPAVE_11",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        { id:1,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
            nodes:[
                {id:2,offset:{x:1,y:0.5},center:{x:1.25,y:0.75}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                {id:1,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
                {id:2,offset:{x:0,y:1},center:{x:0.25,y:1.25}},

                {id:1,offset:{x:-1,y:0.5},center:{x:-0.5,y:1}},
                {id:2,offset:{x:-0.5,y:0},center:{x:-0.25,y:0.25}},

                {id:1,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
                {id:2,offset:{x:0.5,y:-0.5},center:{x:0.75,y:-0.25}},
                {id:1,offset:{x:1,y:-0.5},center:{x:1.5,y:0}}

            ]
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            pidIndex:0,
            profile:[{x:0,y:0},{x:0.5,y:0},{x:0.5,y:0.5},{x:0,y:0.5}],   //切砖路径,以切砖后的大小为单位
            nodes:[
                {id:1,offset:{x:0.5,y:0},center:{x:1,y:0.5}},
                {id:1,offset:{x:-0.5,y:0.5},center:{x:0,y:1}},
                {id:1,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0}},
                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}

            ]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_12 = {
    name:"DOUBLEPAVE_12",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:2,offset:{x:0,y:-0.25},center:{x:0.5,y:-0.125}},
                {id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},
                {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.125}},
                {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}}

            ]
        },
        { id:2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:0.25},{x:0,y:0.25}],
            nodes:[
                {id:1,offset:{x:0,y:0.25},center:{x:0.5,y:0.75}},
                {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.125}},
                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},
                {id:2,offset:{x:1,y:0},center:{x:1.5,y:0.125}}

            ]
        }
    ]
}


PAVEMODEL.DOUBLEPAVE_13 = {
	name:"DOUBLEPAVE_13",
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	     ],
	tiles: [
	 { id:1,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
         profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
         nodes:[{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
             {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
             {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
             {id:2,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
         ]
	 },
	 { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
	 	 pidIndex:0,	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 }
	]
}

PAVEMODEL.DOUBLEPAVE_14 = {
    name:"DOUBLEPAVE_14",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
         tw:2,
         th:2,
            //最小的砖(id3)的宽度/高度 是id1的 2*(1/4)===0.5 ,
         profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
         type:"group", //组类型
         nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，

               {id:1,offset:{x:2,y:0},center:{x:3,y:1}},
               {id:1,offset:{x:0,y:2},center:{x:1,y:3}},
               {id:1,offset:{x:-2,y:0},center:{x:-1,y:1}},
               {id:1,offset:{x:0,y:-2},center:{x:1,y:-1}}
         ],
         groupnodes:[
               {id:2,offset:{x:0,y:0}},
               {id:2,offset:{x:1,y:1}},
               
               {id:3,offset:{x:0,y:1}},
               {id:3,offset:{x:0,y:1.5}},
               {id:3,offset:{x:0.5,y:1}},
               {id:3,offset:{x:0.5,y:1.5}},
               
               {id:3,offset:{x:1,y:0}},
               {id:3,offset:{x:1,y:0.5}},
               {id:3,offset:{x:1.5,y:0}},
               {id:3,offset:{x:1.5,y:0.5}},
         ],
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
          profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
          nodes:[]
        },
        { id:3,   
        	  tw:0.5,
        	  th:0.5,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_15 = {
    name:"DOUBLEPAVE_15",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
                {id:1,offset:{x:2,y:0},center:{x:3,y:1}},
                {id:1,offset:{x:0,y:2},center:{x:1,y:3}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:1}},
                {id:1,offset:{x:0,y:-2},center:{x:1,y:-1}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:0,y:0.5}},

                {id:2,offset:{x:1,y:1}},
                {id:2,offset:{x:1,y:1.5}},

                {id:3,offset:{x:0,y:1}},
                {id:3,offset:{x:0.5,y:1}},

                {id:3,offset:{x:1,y:0}},
                {id:3,offset:{x:1.5,y:0}},
            ],
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            tw:1,
            th:0.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}], //切砖路径,以切砖后的大小为单位
            nodes:[]
        },
        { id:3,
            tw:0.5,
            th:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_16 = {
    name:"DOUBLEPAVE_16",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1,
            th:1.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
                {id:1,offset:{x:1,y:0},center:{x:1.5,y:0.75}},
                {id:1,offset:{x:0,y:1.5},center:{x:0.5,y:2.25}},
                {id:1,offset:{x:-1,y:0},center:{x: -0.5,y:0.75}},
                {id:1,offset:{x:0,y:-1.5},center:{x:0.5,y:-0.75}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:0.5,y:0}},
                {id:3,offset:{x:0,y:0.5}},

            ],
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            tw:0.5,
            th:0.5,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}], //切砖路径,以切砖后的大小为单位
            nodes:[]
        },
        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_17 = {
    name:"DOUBLEPAVE_17",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1,
            th:1.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
                {id:1,offset:{x:1,y:-0.5},center:{x:1.5,y:0.25}},
                {id:1,offset:{x:0,y:1.5},center:{x:0.5,y:2.25}},
                {id:1,offset:{x:-1,y:0.5},center:{x: -0.5,y:1.25}},
                {id:1,offset:{x:0,y:-1.5},center:{x:0.5,y:-0.75}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:0.5,y:0}},
                {id:3,offset:{x:0,y:0.5}},
            ],
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            tw:0.5,
            th:0.5,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}], //切砖路径,以切砖后的大小为单位
            nodes:[]
        },
        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_18 = {
    name:"DOUBLEPAVE_18",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1,
            th:1.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
				{id:1,offset:{x:2,y:0},center:{x:3,y:0.5}},
				{id:1,offset:{x:-2,y:0},center:{x:-1,y:0.5}},
				{id:1,offset:{x:0,y:1.5},center:{x:1,y:2}},
				{id:1,offset:{x:0,y:-1.5},center:{x:1,y:-1}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:0.5,y:0}},
                {id:3,offset:{x:0,y:0.5}},

				{id:2,offset:{x:1,y:-0.5}},
				{id:2,offset:{x:1.5,y:-0.5}},
				{id:3,offset:{x:1,y:0}},
            ],
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            tw:0.5,
            th:0.5,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}], //切砖路径,以切砖后的大小为单位
            nodes:[]
        },
        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_19 = {
    name:"DOUBLEPAVE_19",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
                {id:1,offset:{x:2,y:0},center:{x:3,y:1}},                
                {id:1,offset:{x:0,y:2},center:{x:1,y:3}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:1}},
                {id:1,offset:{x:0,y:-2},center:{x:1,y:-1}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:1,y:0}},
                {id:3,offset:{x:0,y:1}},
                {id:4,offset:{x:0,y:1.8}},
                {id:3,offset:{x:1,y:1.2}},
                {id:4,offset:{x:1,y:1}},
            ],
        },
        { id:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:3,
        	  tw:1,
            th:0.8,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4,
            tw:1,
            th:0.2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
    ]
}

PAVEMODEL.DOUBLEPAVE_20 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
    name:"DOUBLEPAVE_20",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
                {id:1,offset:{x:2,y:0},center:{x:3,y:1}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:1}},
                {id:1,offset:{x:1,y:-2},center:{x:2,y:-1}},
                {id:1,offset:{x:1,y:2},center:{x:2,y:3}}
            ],
            groupnodes:[
				{id:3,offset:{x:0,y:0}},
				{id:4,offset:{x:0.2,y:0}},
                {id:2,offset:{x:1,y:0}},
                {id:2,offset:{x:0,y:1}},
                {id:2,offset:{x:1,y:1}},

            ],
        },
        { id:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:3,
            tw:0.2,
            th:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4,
            tw:0.8,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_21 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
    name:"DOUBLEPAVE_21",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:2,offset:{x:1,y:0},center:{x:1.075,y:0.5}},
                {id:3,offset:{x:0.15,y:1},center:{x:0.65,y:1.5}},
                {id:4,offset:{x:0,y:1},center:{x:0.075,y:1.5}},
                {id:2,offset:{x:-0.15,y:0},center:{x:-0.075,y:0.5}},
                {id:4,offset:{x:0,y:-1},center:{x:0.075,y:-0.5}},
                {id:3,offset:{x:0.15,y:-1},center:{x:0.65,y:-0.5}}

            ]
        },
        { id:2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:0.15,y:0},{x:0.15,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:0.15,y:0},center:{x:0.65,y:0.5}},
                {id:3,offset:{x:-0.85,y:1},center:{x:-0.35,y:1.5}},
                {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:3,offset:{x:-0.85,y:-1},center:{x:-0.35,y:-0.5}}

            ]
        },
        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:4,offset:{x:1,y:0},center:{x:1.075,y:0.5}},
                {id:1,offset:{x:-0.15,y:1},center:{x:0.35,y:1.5}},
                {id:2,offset:{x:0.85,y:1},center:{x:0.925,y:1.5}},
                {id:4,offset:{x:-0.15,y:0},center:{x:-0.075,y:0.5}},
                {id:1,offset:{x:0.15,y:-1},center:{x:0.35,y:-0.5}},
                {id:2,offset:{x:0.85,y:-1},center:{x:0.925,y:-0.5}}


            ]
        },
        { id:4,
            pidIndex:0,
            profile:[{x:0,y:0},{x:0.15,y:0},{x:0.15,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:0.15,y:0},center:{x:0.65,y:0.5}},
                {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}

            ]
        }
    ]
}


PAVEMODEL.DOUBLEPAVE_23 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
    name:"DOUBLEPAVE_23",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
		{id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
			nodes:[
				//wy为以w为长度的y轴偏移
				//hx为以h为长度的x轴偏移
				{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}},
				{id:4,offset:{x:0,y:0},center:{x:0,y:0,hx:0.5,wy:-0.5}},
				{id:2,offset:{x:-1,y:0,wy:-2},center:{x:-0.5,y:0.5,wy:-2}},
				{id:4,offset:{x:0,y:1,hx:-1,wy:0},center:{x:0,y:1,hx:-0.5,wy:-0.5}},
				{id:3,offset:{x:0,y:1,hx:-1,wy:-1},center:{x:0,y:1,hx:-0.5,wy:-1.5}},
				{id:3,offset:{x:0,y:1,hx:-0.5,wy:1},center:{x:0,y:1,hx:0,wy:0.5}}
			]
		},
		{ id:2,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
				{id:1,offset:{x:-1,y:0,hx:0,wy:0},center:{x:-0.5,y:0.5,wx:0,wy:0}},
				{id:3,offset:{x:1,y:0,hx:0,wy:1},center:{x:1,y:0,hx:0.5,wy:0.5}},
				{id:4,offset:{x:1,y:0,hx:0,wy:2},center:{x:1,y:0,hx:0.5,wy:1.5}},
				{id:1,offset:{x:1,y:0,hx:0,wy:2},center:{x:1.5,y:0.5,wx:0,wy:2}},
				{id:3,offset:{x:1,y:1,hx:-1,wy:1},center:{x:1,y:1,hx:-0.5,wy:0.5}},
				{id:4,offset:{x:-1,y:0,hx:0,wy:0},center:{x:-1,y:0,hx:0.5,wy:-0.5}},
			]
		},
		{ id:3,
			pidIndex:0,
			rot:{r:-90},	//围绕pos点旋转r度后
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
				{id:4,offset:{x:0,y:0,hx:0,wy:1},center:{x:0,y:0,hx:0.5,wy:0.5}},
				{id:4,offset:{x:0,y:0,hx:-0.5,wy:-1},center:{x:0,y:0,hx:0,wy:-1.5}},
				{id:2,offset:{x:-1,y:0,hx:0,wy:-1},center:{x:-0.5,y:0.5,hx:0,wy:-1}},
				{id:1,offset:{x:0,y:-1,hx:1,wy:1},center:{x:0.5,y:-0.5,hx:1,wy:1}},
				{id:1,offset:{x:0,y:-1,hx:0.5,wy:-1},center:{x:0.5,y:-0.5,hx:0.5,wy:-1}},
				{id:2,offset:{x:1,y:-1,hx:0.5,wy:-1},center:{x:1.5,y:-0.5,hx:0.5,wy:-1}},
			]
		},
		{ id:4,
			pidIndex:0,
			rot:{r:-90},	//围绕pos点旋转r度后
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
				{id:1,offset:{x:0,y:0,hx:0,wy:0},center:{x:0.5,y:0.5,hx:0,wy:0}},
				{id:2,offset:{x:1,y:0,hx:0,wy:0},center:{x:1.5,y:0.5,hx:0,wy:0}},
				{id:3,offset:{x:0,y:0,hx:0,wy:-1},center:{x:0,y:0,hx:0.5,wy:-1.5}},
				{id:3,offset:{x:2,y:0,wx:0,wy:1},center:{x:2,y:0,hx:0.5,wy:0.5}},
				{id:1,offset:{x:0,y:-1,hx:1,wy:0},center:{x:0.5,y:-0.5,hx:1,wy:0}},
				{id:2,offset:{x:-1,y:0,hx:0,wy:-1},center:{x:-0.5,y:0.5,hx:0,wy:-1}},

			]
		}
    ],

	//tilesHW
	tilesHW: [
		{id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
			rot:{r:-90},	//围绕pos点旋转r度后
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
			nodes:[
				//wy为以w为长度的y轴偏移
				//hx为以h为长度的x轴偏移
				{id:2,offset:{x:0,y:0,hx:-0.5,wy:1},center:{x:0,y:0,hx:0,wy:0.5}},
				{id:2,offset:{x:0,y:0,hx:0,wy:-1},center:{x:0,y:0,hx:0.5,wy:-1.5}},
				{id:3,offset:{x:0,y:0,hx:0.5,wy:0},center:{x:0.5,y:0.5,hx:0.5,wy:0}},
				{id:4,offset:{x:1,y:0,hx:0.5,wy:0},center:{x:1.5,y:0.5,hx:0.5,wy:0}},
				{id:3,offset:{x:0,y:-1,hx:1,wy:0},center:{x:0.5,y:-0.5,hx:1,wy:0}},
				{id:4,offset:{x:-1,y:-1,hx:0,wy:0},center:{x:-0.5,y:-0.5,hx:0,wy:0}},
			]
		},
		{ id:2,
			rot:{r:-90},	//围绕pos点旋转r度后
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
				{id:1,offset:{x:0,y:0,hx:0,wy:1},center:{x:0,y:0,hx:0.5,wy:0.5}},
				{id:1,offset:{x:2,y:0,hx:0,wy:-1},center:{x:2,y:0,hx:0.5,wy:-1.5}},
				{id:3,offset:{x:0,y:0,hx:1,wy:-1},center:{x:0.5,y:0.5,hx:1,wy:-1}},
				{id:4,offset:{x:-1,y:-1,hx:0,wy:1},center:{x:-0.5,y:-0.5,hx:0,wy:1}},
				{id:3,offset:{x:0,y:-1,hx:0,wy:-1},center:{x:0.5,y:-0.5,hx:0,wy:-1}},
				{id:4,offset:{x:1,y:-1,hx:0,wy:-1},center:{x:1.5,y:-0.5,hx:0,wy:-1}},
			]
		},
		{ id:3,
			pidIndex:0,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
				{id:4,offset:{x:1,y:0,hx:0,wy:0},center:{x:1.5,y:0.5,hx:0,wy:0}},
				{id:4,offset:{x:-1,y:0,hx:0,wy:2},center:{x:-0.5,y:0.5,hx:0,wy:2}},
				{id:2,offset:{x:0,y:1,hx:0,wy:1},center:{x:0,y:1,hx:0.5,wy:0.5}},
				{id:1,offset:{x:0,y:0,hx:-0.5,wy:0},center:{x:0,y:0,hx:0,wy:-0.5}},
				{id:1,offset:{x:0,y:0,hx:-1,wy:2},center:{x:0,y:0,hx:-0.5,wy:1.5}},
				{id:2,offset:{x:0,y:0,hx:-1,wy:1},center:{x:0,y:0,hx:-0.5,wy:0.5}},
			]
		},
		{ id:4,
			pidIndex:0,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[
				{id:3,offset:{x:1,y:0,hx:0,wy:-2},center:{x:1.5,y:0.5,hx:0,wy:-2}},
				{id:3,offset:{x:-1,y:0,hx:0,wy:0},center:{x:-0.5,y:0.5,hx:0,wy:0}},
				{id:2,offset:{x:-1,y:1,hx:0,wy:1},center:{x:-1,y:1,hx:0.5,wy:0.5}},
				{id:1,offset:{x:1,y:0,hx:-1,wy:0},center:{x:1,y:0,hx:-0.5,wy:-0.5}},
				{id:1,offset:{x:1,y:1,hx:0,wy:0},center:{x:1,y:1,hx:0.5,wy:-0.5}},
				{id:2,offset:{x:1,y:1,hx:0,wy:-1},center:{x:1,y:1,hx:0.5,wy:-1.5}},

			]
		}
    ]
}

PAVEMODEL.DOUBLEPAVE_27 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
	name:"DOUBLEPAVE_27",
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	],
	tiles: [
		{id:1,
			tw:2,
			th:2,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			type:"group", //组类型
			nodes:[
				{id:1,offset:{x:2,y:0},center:{x:3,y:1}},
				{id:1,offset:{x:-2,y:0},center:{x:-1,y:1}},
				{id:1,offset:{x:0,y:2},center:{x: 1,y:3}},
				{id:1,offset:{x:0,y:-2},center:{x:1,y:-1}}
			],
			groupnodes:[

				//下1
				{id:2,offset:{x:0,y:0}},
				{id:3,offset:{x:1,y:0}},
				{id:4,offset:{x:0,y:0}},
				{id:5,offset:{x:1,y:0}},

				{id:6,offset:{x:0,y:1}},
				{id:7,offset:{x:1,y:1}},
				{id:8,offset:{x:0,y:1}},
				{id:9,offset:{x:1,y:1}},

			],
		},
		{ id:2,
			//tw:0.5,
			//th:0.5,
			profile:[{x:0,y:0},{x:0,y:1},{x:1,y:1}],
			nodes:[]
		},
		{ id:3,
			//tw:0.5,
			//th:0.5,
			profile:[{x:1,y:0},{x:0,y:1},{x:1,y:1}],
			nodes:[]
		},
		{ id:4,
			//tw:0.5,
			//th:0.5,
			pidIndex:0,
			profile:[{x:0,y:0},{x:1,y:1},{x:1,y:0}],
			nodes:[]
		},
		{ id:5,
			//tw:0.5,
			//th:0.5,
			pidIndex:0,
			profile:[{x:0,y:0},{x:0,y:1},{x:1,y:0}],
			nodes:[]
		},
		{ id:6,
			//tw:0.5,
			//th:0.5,
			profile:[{x:0,y:0},{x:1,y:1},{x:1,y:0}],
			nodes:[]
		},
		{ id:7,
			//tw:0.5,
			//th:0.5,
			profile:[{x:0,y:0},{x:0,y:1},{x:1,y:0}],
			nodes:[]
		},
		{ id:8,
			//tw:0.5,
			//th:0.5,
			pidIndex:0,
			profile:[{x:0,y:0},{x:0,y:1},{x:1,y:1}],
			nodes:[]
		},
		{ id:9,
			//tw:0.5,
			//th:0.5,
			pidIndex:0,
			profile:[{x:1,y:0},{x:0,y:1},{x:1,y:1}],
			nodes:[]
		}
	]
}

PAVEMODEL.DOUBLEPAVE_28 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
    name:"DOUBLEPAVE_28",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
                {id:1,offset:{x:2,y:0},center:{x:3,y:1}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:1}},
                {id:1,offset:{x:0,y:2},center:{x: 1,y:3}},
                {id:1,offset:{x:0,y:-2},center:{x:1,y:-1}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:3,offset:{x:0,y:0.3}},
                {id:2,offset:{x:0,y:0.7}},

                {id:4,offset:{x:1,y:0}},
                {id:5,offset:{x:1.3,y:0}},
                {id:4,offset:{x:1.7,y:0}},

                {id:4,offset:{x:0,y:1}},
                {id:5,offset:{x:0.3,y:1}},
                {id:4,offset:{x:0.7,y:1}},

                {id:2,offset:{x:1,y:1}},
                {id:3,offset:{x:1,y:1.3}},
                {id:2,offset:{x:1,y:1.7}},

            ],
        },
        { id:2,
            tw:1,
            th:0.3,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:3,
            tw:1,
            th:0.4,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4,
            tw:0.3,
            th:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:5,
            tw:0.4,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_29 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
	name:"DOUBLEPAVE_29",
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	],
	tiles: [
		{id:1,
			tw:2,
			th:2,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			type:"group", //组类型
			nodes:[
				{id:1,offset:{x:2,y:0},center:{x:3,y:1}},
				{id:1,offset:{x:-2,y:0},center:{x:-1,y:1}},
				{id:1,offset:{x:0,y:2},center:{x: 1,y:3}},
				{id:1,offset:{x:0,y:-2},center:{x:1,y:-1}}
			],
			groupnodes:[
				//主砖正方形
				{id:2,offset:{x:0,y:1}},
				{id:2,offset:{x:1,y:0}},
				//{id:2,offset:{x:1,y:2}},
				//{id:2,offset:{x:2,y:1}},

				//左下
				{id:3,offset:{x:0,y:0}},
				{id:3,offset:{x:0.25,y:0}},
				{id:4,offset:{x:0.5,y:0}},
				{id:4,offset:{x:0.5,y:0.25}},
				{id:4,offset:{x:0,y:0.5}},
				{id:4,offset:{x:0,y:0.75}},
				{id:3,offset:{x:0.5,y:0.5}},
				{id:3,offset:{x:0.75,y:0.5}},


				//右下
				//{id:3,offset:{x:2,y:0}},
				//{id:3,offset:{x:2.25,y:0}},
				//{id:4,offset:{x:2.5,y:0}},
				//{id:4,offset:{x:2.5,y:0.25}},
				//{id:4,offset:{x:2,y:0.5}},
				//{id:4,offset:{x:2,y:0.75}},
				//{id:3,offset:{x:2.5,y:0.5}},
				//{id:3,offset:{x:2.75,y:0.5}},

				//中
				{id:3,offset:{x:1,y:1}},
				{id:3,offset:{x:1.25,y:1}},
				{id:4,offset:{x:1.5,y:1}},
				{id:4,offset:{x:1.5,y:1.25}},
				{id:4,offset:{x:1,y:1.5}},
				{id:4,offset:{x:1,y:1.75}},
				{id:3,offset:{x:1.5,y:1.5}},
				{id:3,offset:{x:1.75,y:1.5}},

				//左上
				//{id:3,offset:{x:0,y:2}},
				//{id:3,offset:{x:0.25,y:2}},
				//{id:4,offset:{x:0.5,y:2}},
				//{id:4,offset:{x:0.5,y:2.25}},
				//{id:4,offset:{x:0,y:2.5}},
				//{id:4,offset:{x:0,y:2.75}},
				//{id:3,offset:{x:0.5,y:2.5}},
				//{id:3,offset:{x:0.75,y:2.5}},

				//右上
				//{id:3,offset:{x:2,y:2}},
				//{id:3,offset:{x:2.25,y:2}},
				//{id:4,offset:{x:2.5,y:2}},
				//{id:4,offset:{x:2.5,y:2.25}},
				//{id:4,offset:{x:2,y:2.5}},
				//{id:4,offset:{x:2,y:2.75}},
				//{id:3,offset:{x:2.5,y:2.5}},
				//{id:3,offset:{x:2.75,y:2.5}},
			],
		},
		{ id:2,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[]
		},
		{ id:3,
			tw:0.25,
			th:0.5,
			pidIndex:0,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[]
		}
		,
		{ id:4,
			tw:0.5,
			th:0.25,
			pidIndex:0,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[]
		}
	]
}

PAVEMODEL.DOUBLEPAVE_30 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
	name:"DOUBLEPAVE_30",
	pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
	],
	tiles: [
		{id:1,
			tw:3,
			th:3,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			type:"group", //组类型
			nodes:[
				{id:1,offset:{x:3,y:0},center:{x:4.5,y:1.5}},
				{id:1,offset:{x:-3,y:0},center:{x:-1.5,y:1.5}},
				{id:1,offset:{x:0,y:3},center:{x: 1.5,y:4.5}},
				{id:1,offset:{x:0,y:-3},center:{x:1.5,y:-1.5}}
			],
			groupnodes:[

				{id:2,offset:{x:1,y:1}},
				{id:3,offset:{x:0,y:0}},
				{id:4,offset:{x:1,y:0}},
				{id:4,offset:{x:0,y:2}},
				{id:3,offset:{x:2,y:1}},

				////左下
				//{id:2,offset:{x:0.3,y:0.3}},
				//{id:3,offset:{x:0,y:0}},
				//{id:4,offset:{x:0.3,y:0}},
				//{id:4,offset:{x:0,y:0.7}},
				//{id:3,offset:{x:0.7,y:0.3}},
                //
				////右下
				//{id:2,offset:{x:1.3,y:0.3}},
				//{id:3,offset:{x:1,y:0}},
				//{id:4,offset:{x:1.3,y:0}},
				//{id:4,offset:{x:1,y:0.7}},
				//{id:3,offset:{x:1.7,y:0.3}},
                //
				////左上
				//{id:2,offset:{x:0.3,y:1.3}},
				//{id:3,offset:{x:0,y:1}},
				//{id:4,offset:{x:0.3,y:1}},
				//{id:4,offset:{x:0,y:1.7}},
				//{id:3,offset:{x:0.7,y:1.3}},
                //
				////右上
				//{id:2,offset:{x:1.3,y:1.3}},
				//{id:3,offset:{x:1,y:1}},
				//{id:4,offset:{x:1.3,y:1}},
				//{id:4,offset:{x:1,y:1.7}},
				//{id:3,offset:{x:1.7,y:1.3}},
			],
		},
		{ id:2,
			//tw:0.4,
			//th:0.4,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[]
		},
		{ id:3,
			tw:1,
			th:2,
			pidIndex:0,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[]
		}
		,
		{ id:4,
			tw:2,
			th:1,
			pidIndex:0,
			profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
			nodes:[]
		}
	]
}

PAVEMODEL.DOUBLEPAVE_32 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
    name:"DOUBLEPAVE_32",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:2.25,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[
                {id:1,offset:{x:2,y:0},center:{x:3,y:1.25}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:1.25}},
                {id:1,offset:{x:0,y:2.5},center:{x: 1,y:3.75}},
                {id:1,offset:{x:0,y:-2.5},center:{x:1,y:-1.25}}
            ],
            groupnodes:[
                {id:3,offset:{x:0,y:0}},
                {id:3,offset:{x:0.25,y:0}},
                {id:2,offset:{x:0.5,y:0}},
                {id:2,offset:{x:0.75,y:0}},
                {id:3,offset:{x:1,y:0}},
                {id:3,offset:{x:1.25,y:0}},
                {id:2,offset:{x:1.5,y:0}},
                {id:2,offset:{x:1.75,y:0}},

                {id:4,offset:{x:0,y:1}},
                {id:4,offset:{x:1,y:1}},

                {id:2,offset:{x:0,y:1.25}},
                {id:2,offset:{x:0.25,y:1.25}},
                {id:3,offset:{x:0.5,y:1.25}},
                {id:3,offset:{x:0.75,y:1.25}},
                {id:2,offset:{x:1,y:1.25}},
                {id:2,offset:{x:1.25,y:1.25}},
                {id:3,offset:{x:1.5,y:1.25}},
                {id:3,offset:{x:1.75,y:1.25}},

				{id:4,offset:{x:0,y:2.25}},
				{id:4,offset:{x:1,y:2.25}},
            ],
        },
        { id:2,
            tw:0.25,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:3,
            tw:0.25,
            th:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
        ,
        { id:4,
            tw:1,
            tWh:0.25,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.DOUBLEPAVE_24 = {//id1+id2作为（组）=>pattern1，id3+id4（组）=>pattern2;
    name:"DOUBLEPAVE_24",
    rotate:45,
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:2,offset:{x:1,y:-1},center:{x:1.025,y:0}},

                {id:3,offset:{x:0.05,y:1},center:{x:0.55,y:1.5}},

                {id:2,offset:{x:0,y:1},center:{x:0.025,y:2}},

                {id:4,offset:{x:-0.05,y:0},center:{x:-0.025,y:1}},

                {id:3,offset:{x:-0.05,y:-1},center:{x:0.45,y:-0.5}},
                {id:4,offset:{x:0.95,y:-2},center:{x:0.975,y:-1}}
            ]
        },
        { id:2,
            tw:0.05,
            th:2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:3,offset:{x:0.05,y:0},center:{x:0.55,y:0.5}},

                {id:4,offset:{x:0.05,y:1},center:{x:0.075,y:2}},
                {id:3,offset:{x:-0.95,y:2},center:{x:-0.45,y:2.5}},

                {id:1,offset:{x:-1,y:1},center:{x:-0.5,y:1.5}},

                {id:4,offset:{x:-0.05,y:-1},center:{x:-0.025,y:0}},

                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
            ]
        },
        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:4,offset:{x:1,y:-1},center:{x:1.025,y:0}},

                {id:1,offset:{x:0.05,y:1},center:{x:0.55,y:1.5}},

                {id:4,offset:{x:0,y:1},center:{x:0.025,y:2}},

                {id:2,offset:{x:-0.05,y:0},center:{x:-0.025,y:1}},

                {id:1,offset:{x:-0.05,y:-1},center:{x:0.45,y:-0.5}},
                {id:2,offset:{x:0.95,y:-2},center:{x:0.975,y:-1}}
            ]
        },

        { id:4,
            tw:0.05,
            th:2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:1,offset:{x:0.05,y:0},center:{x:0.55,y:0.5}},

                {id:2,offset:{x:0.05,y:1},center:{x:0.075,y:2}},
                {id:1,offset:{x:-0.95,y:2},center:{x:-0.45,y:2.5}},

                {id:3,offset:{x:-1,y:1},center:{x:-0.5,y:1.5}},

                {id:2,offset:{x:-0.05,y:-1},center:{x:-0.025,y:0}},

                {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
            ]
        }
    ],

    /*竖起来的砖用下面*/
    tilesHW: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:1,y:-0.05},center:{x:1.5,y:0.45}},
                {id:2,offset:{x:1,y:0.95},center:{x:2,y:0.975}},
                {id:4,offset:{x:0,y:1},center:{x:1,y:1.025}},
                {id:3,offset:{x:-1,y:0.05},center:{x:-0.5,y:0.55}},
                {id:4,offset:{x:-2,y:0},center:{x:-1,y:0.025}},
                {id:2,offset:{x:-1,y:-0.05},center:{x:0,y:-0.025}}
            ]
        },

        { id:2,
            tw:2,
            th:0.05,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:3,offset:{x:2,y:0},center:{x:2.5,y:0.5}},
                {id:1,offset:{x:1,y:0.05},center:{x:1.5,y:0.55}},
                {id:4,offset:{x:-1,y:0.05},center:{x:0,y:0.075}},
                {id:1,offset:{x:-1,y:-0.95},center:{x:-0.5,y:-0.45}},
                {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},
                {id:4,offset:{x:1,y:-0.05},center:{x:2,y:-0.025}}
            ]
        },

        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:1,y:-0.05},center:{x:1.5,y:0.45}},
                {id:4,offset:{x:1,y:0.95},center:{x:2,y:0.975}},
                {id:2,offset:{x:0,y:1},center:{x:1,y:1.025}},
                {id:1,offset:{x:-1,y:0.05},center:{x:-0.5,y:0.55}},
                {id:2,offset:{x:-2,y:0},center:{x:-1,y:0.025}},
                {id:4,offset:{x:-1,y:-0.05},center:{x:0,y:-0.025}}
            ]
        },

        // 根据主砖的wh做位移
        { id:4,
            tw:2,
            th:0.05,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:1,offset:{x:2,y:0},center:{x:2.5,y:0.5}},
                {id:3,offset:{x:1,y:0.05},center:{x:1.5,y:0.55}},

                {id:2,offset:{x:-1,y:0.05},center:{x:0,y:0.075}},

                {id:3,offset:{x:-1,y:-0.95},center:{x:-0.5,y:-0.45}},

                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},
                {id:2,offset:{x:1,y:-0.05},center:{x:2,y:-0.025}}
            ]
        }
    ]
}


PAVEMODEL.DOUBLEPAVE_25 = {
    name:"DOUBLEPAVE_25",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [

        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:2,offset:{x:1,y:0},center:{x:1,y:0.5,hx:0.5}},
                {id:2,offset:{x:1,y:1,hx:-1},center:{x:1,y:1.5, hx:-0.5}},
                {id:1,offset:{x:0,y:1,hx:-1},center:{x:0.5,y:1.5,hx:-1}},
                {id:3,offset:{x:0,y:1,hx:-1},center:{x:0,y:1,hx:-0.5, wy:-0.5}},
                {id:3,offset:{x:0,y:0},center:{x:0,y:0, hx:0.5, wy:-0.5}},
                {id:1,offset:{x:0,y:-1,hx:1},center:{x:0.5,y:-0.5, hx:1}}

            ]
        },
        { id:2,
            tw:0,
            th:1,
            tHw:1,//以h为单位的w
            tWh:0,//以w为单位的h
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:0,y:0,wy:1,hx:1},center:{x:0,y:0,wy:0.5,hx:1.5}},
                {id:3,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
                {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:1,offset:{x:-1,y:-1,hx:1},center:{x:-0.5,y:-0.5,hx:1}}
            ]
        },
        { id:3,
            rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            //相对3号砖的左上角作为 坐标原点， 之后再计算坐标
            nodes:[
                {id:3,offset:{x:0,y:-1,hx:1},center:{x:0,y:-1,hx:1.5,wy:-0.5}},
                {id:1,offset:{x:0,y:-1,hx:1},center:{x:0.5,y:-0.5,hx:1}},
                {id:1,offset:{x:0,y:0},center:{x:0.5,y:0.5}},
                {id:3,offset:{x:0,y:1,hx:-1},center:{x:0,y:1,hx:-0.5,wy:-0.5}},
                {id:2,offset:{x:0,y:0,hx:-1,wy:-1},center:{x:0,y:0.5,hx:-0.5,wy:-1}},
                {id:2,offset:{x:0,y:-1,wy:-1},center:{x:0,y:-0.5,wy:-1,hx:0.5}},
            ]
        }
    ],
    
    tilesHW:[
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:1,y:0,wy:-1},center:{x:1.5,y:0.5,wy:-1}},
                {id:2,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:2,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
                {id:1,offset:{x:-1,y:0,wy:1},center:{x:-0.5,y:0.5,wy:1}},
                {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0,wy:0.5}},
                {id:3,offset:{x:0,y:0,wy:-1},center:{x:0.5,y:0,wy:-0.5}},                
            ]
        },
        { id:2,
        	  rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:0,y:0,hx:1,wy:-1},center:{x:0.5,y:0,hx:1,wy:-0.5}},
                {id:3,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0,hx:1,wy:0.5}},
                {id:2,offset:{x:-1,y:0,wy:1},center:{x:-1,y:0,hx:0.5,wy:0.5}},
                {id:1,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:1,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}},
                {id:2,offset:{x:1,y:0,wy:-1},center:{x:1,y:0,wy:-1.5,hx:0.5}}
            ]
        },
        { id:3,
            tw:1,
            th:0,
            tWh:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},
                {id:1,offset:{x:0,y:0,wy:1},center:{x:0.5,y:0.5,wy:1}},
                {id:2,offset:{x:0,y:0,wy:1,hx:-1},center:{x:0,y:0,wy:0.5,hx:-0.5}},
                {id:2,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,wy:-0.5,hx:-0.5}}
            ]
        },
    ]    
}

//模式1整体竖放，模式2横放
PAVEMODEL.DOUBLEPAVE_26 = {
    name:"DOUBLEPAVE_26",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:6,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:5,offset:{x:0,y:1,hx:1},center:{x:0.5,y:1.5,hx:1}},
                {id:4,offset:{x:0,y:1,wy:1},center:{x:0,y:1,hx:0.5,wy:0.5}},
                {id:8,offset:{x:0,y:0,hx:-1,wy:1},center:{x:0,y:0,hx:-0.5,wy:0.5}},
                {id:5,offset:{x:0,y:-1,hx:-1},center:{x:0.5,y:-0.5,hx:-1}},
                {id:2,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}}
            ]
        },
        { id:2,
            rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:0,y:0,hx:1,wy:-1},center:{x:0.5,y:0.5,hx:1,wy:-1}},
                {id:6,offset:{x:0,y:1,hx:1},center:{x:0,y:1,hx:1.5,wy:-0.5}},
                {id:1,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:5,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:6,offset:{x:0,y:-1,hx:-1},center:{x:0,y:-1,hx:-0.5,wy:-0.5}},
                {id:7,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}}
            ]
        }
        ,
        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:8,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:7,offset:{x:0,y:1,hx:1},center:{x:0.5,y:1.5,hx:1}},
                {id:6,offset:{x:0,y:1,wy:1},center:{x:0,y:1,hx:0.5,wy:0.5}},
                {id:2,offset:{x:0,y:0,hx:-1,wy:1},center:{x:0,y:0,hx:-0.5,wy:0.5}},
                {id:7,offset:{x:0,y:-1,hx:-1},center:{x:0.5,y:-0.5,hx:-1}},
                {id:4,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}}
            ]
        }
        ,
        { id:4,
            rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:5,offset:{x:0,y:0,hx:1,wy:-1},center:{x:0.5,y:0.5,hx:1,wy:-1}},
                {id:8,offset:{x:0,y:1,hx:1},center:{x:0,y:1,hx:1.5,wy:-0.5}},
                {id:3,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:7,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:8,offset:{x:0,y:-1,hx:-1},center:{x:0,y:-1,hx:-0.5,wy:-0.5}},
                {id:1,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}}
            ]
        }
        ,
        { id:5,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:2,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:1,offset:{x:0,y:1,hx:1},center:{x:0.5,y:1.5,hx:1}},
                {id:8,offset:{x:0,y:1,wy:1},center:{x:0,y:1,hx:0.5,wy:0.5}},
                {id:4,offset:{x:0,y:0,hx:-1,wy:1},center:{x:0,y:0,hx:-0.5,wy:0.5}},
                {id:1,offset:{x:0,y:-1,hx:-1},center:{x:0.5,y:-0.5,hx:-1}},
                {id:6,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}}

            ]
        },
        { id:6,
            pidIndex:0,
            rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:7,offset:{x:0,y:0,hx:1,wy:-1},center:{x:0.5,y:0.5,hx:1,wy:-1}},
                {id:2,offset:{x:0,y:1,hx:1},center:{x:0,y:1,hx:1.5,wy:-0.5}},
                {id:5,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:1,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:2,offset:{x:0,y:-1,hx:-1},center:{x:0,y:-1,hx:-0.5,wy:-0.5}},
                {id:3,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}}
            ]
        },
        { id:7,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:4,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:3,offset:{x:0,y:1,hx:1},center:{x:0.5,y:1.5,hx:1}},
                {id:2,offset:{x:0,y:1,wy:1},center:{x:0,y:1,hx:0.5,wy:0.5}},
                {id:6,offset:{x:0,y:0,hx:-1,wy:1},center:{x:0,y:0,hx:-0.5,wy:0.5}},
                {id:3,offset:{x:0,y:-1,hx:-1},center:{x:0.5,y:-0.5,hx:-1}},
                {id:8,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}}

            ]
        }
        ,
        { id:8,
            rot:{r:-90},
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:0,y:0,hx:1,wy:-1},center:{x:0.5,y:0.5,hx:1,wy:-1}},
                {id:4,offset:{x:0,y:1,hx:1},center:{x:0,y:1,hx:1.5,wy:-0.5}},
                {id:7,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:3,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:4,offset:{x:0,y:-1,hx:-1},center:{x:0,y:-1,hx:-0.5,wy:-0.5}},
                {id:5,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}}

            ]
        }

    ],
    tilesHW: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:2,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:6,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
                {id:5,offset:{x:-1,y:0,wy:1},center:{x:-0.5,y:0.5,wy:1}},
                {id:4,offset:{x:0,y:0,wy:1,hx:-1},center:{x:0,y:0,wy:0.5,hx:-0.5}},
                {id:8,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}},
                {id:5,offset:{x:1,y:0,wy:-1},center:{x:1.5,y:0.5,wy:-1}}

            ]
        },
        { id:2,
            rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:7,offset:{x:0,y:0,wy:-1,hx:1},center:{x:0.5,y:0.5,wy:-1,hx:1}},
                {id:3,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:6,offset:{x:-1,y:0,wy:1},center:{x:-1,y:0,wy:0.5,hx:0.5}},
                {id:1,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:5,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}},
                {id:6,offset:{x:1,y:0,wy:-1},center:{x:1,y:0,hx:0.5,wy:-1.5}}

            ]
        },
        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:4,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:8,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
                {id:7,offset:{x:-1,y:0,wy:1},center:{x:-0.5,y:0.5,wy:1}},
                {id:6,offset:{x:0,y:0,wy:1,hx:-1},center:{x:0,y:0,wy:0.5,hx:-0.5}},
                {id:2,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}},
                {id:7,offset:{x:1,y:0,wy:-1},center:{x:1.5,y:0.5,wy:-1}}

            ]
        },
        { id:4,
            rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:0,y:0,wy:-1,hx:1},center:{x:0.5,y:0.5,wy:-1,hx:1}},
                {id:5,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:8,offset:{x:-1,y:0,wy:1},center:{x:-1,y:0,wy:0.5,hx:0.5}},
                {id:3,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:7,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}},
                {id:8,offset:{x:1,y:0,wy:-1},center:{x:1,y:0,hx:0.5,wy:-1.5}}

            ]
        }
        ,
        { id:5,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:6,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:2,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
                {id:1,offset:{x:-1,y:0,wy:1},center:{x:-0.5,y:0.5,wy:1}},
                {id:8,offset:{x:0,y:0,wy:1,hx:-1},center:{x:0,y:0,wy:0.5,hx:-0.5}},
                {id:4,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}},
                {id:1,offset:{x:1,y:0,wy:-1},center:{x:1.5,y:0.5,wy:-1}}

            ]
        },
        { id:6,
            pidIndex:0,
            rot:{r:-90},
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:0,y:0,wy:-1,hx:1},center:{x:0.5,y:0.5,wy:-1,hx:1}},
                {id:7,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:2,offset:{x:-1,y:0,wy:1},center:{x:-1,y:0,wy:0.5,hx:0.5}},
                {id:5,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:1,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}},
                {id:2,offset:{x:1,y:0,wy:-1},center:{x:1,y:0,hx:0.5,wy:-1.5}}

            ]
        },
        { id:7,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:8,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},
                {id:4,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
                {id:3,offset:{x:-1,y:0,wy:1},center:{x:-0.5,y:0.5,wy:1}},
                {id:2,offset:{x:0,y:0,wy:1,hx:-1},center:{x:0,y:0,wy:0.5,hx:-0.5}},
                {id:6,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}},
                {id:3,offset:{x:1,y:0,wy:-1},center:{x:1.5,y:0.5,wy:-1}}

            ]
        },
        { id:8,
            rot:{r:-90},
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:5,offset:{x:0,y:0,wy:-1,hx:1},center:{x:0.5,y:0.5,wy:-1,hx:1}},
                {id:1,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
                {id:4,offset:{x:-1,y:0,wy:1},center:{x:-1,y:0,wy:0.5,hx:0.5}},
                {id:7,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
                {id:3,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}},
                {id:4,offset:{x:1,y:0,wy:-1},center:{x:1,y:0,hx:0.5,wy:-1.5}}

            ]
        }

    ]

}



//模式1横放，模式2竖放
PAVEMODEL.DOUBLEPAVE_31 = {
    name:"DOUBLEPAVE_31",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},
                {id:2,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
                {id:2,offset:{x:-0.5,y:1},center:{x:0,y:1.5}},
                {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:2,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
                {id:2,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}
            ]
        },
        { id:2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}},
                {id:1,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
                {id:1,offset:{x:-0.5,y:1},center:{x:0,y:1.5}},
                {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:1,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
                {id:1,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}
            ]

        }
    ],
    tilesHW: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:2,offset:{x:1,y:-0.5},center:{x:1.5,y:0}},
                {id:2,offset:{x:1,y:0.5},center:{x:1.5,y:1}},

                {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},

                {id:2,offset:{x:-1,y:0.5},center:{x:-0.5,y:1}},

                {id:2,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0}},
                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
            ]
        },
        { id:2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:1,offset:{x:1,y:-0.5},center:{x:1.5,y:0}},
                {id:1,offset:{x:1,y:0.5},center:{x:1.5,y:1}},

                {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.5}},

                {id:1,offset:{x:-1,y:0.5},center:{x:-0.5,y:1}},

                {id:1,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0}},
                {id:2,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
            ]
        }
    ]
}


//所有砖的 x和y 都是以主砖的x y为基础
PAVEMODEL.DOUBLEPAVE_33 = {
    name:"DOUBLEPAVE_33",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
	tiles: [
	 { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[
	          {id:2,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},        //wy为以w为长度的y轴偏移
            {id:1,offset:{x:0,y:1,hx:1},center:{x:0.5,y:1.5,hx:1}},          //hx为以h为长度的x轴偏移
            {id:2,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
            {id:2,offset:{x:0,y:0,wy:1,hx:-1},center:{x:0,y:0,wy:0.5,hx:-0.5}},
            {id:1,offset:{x:0,y:-1,hx:-1},center:{x:0.5,y:-0.5,hx:-1}},
            {id:2,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}}
	         ]
	 },
	 { id:2,
	 	 pidIndex:0,
	 	 rot:{r:-90},	//围绕pos点旋转r度后  	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
	   nodes:[{id:1,offset:{x:0,y:0,wy:-1,hx:1},center:{x:0.5,y:0.5,wy:-1,hx:1}},
	          {id:2,offset:{x:0,y:1,hx:1},center:{x:0,y:1,wy:-0.5,hx:1.5}},
	          {id:1,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
	          {id:1,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
	          {id:2,offset:{x:0,y:-1,hx:-1},center:{x:0,y:-1,hx:-0.5,wy:-0.5}},
	          {id:1,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}}
	         ]
	 }
	],
	//长宽调转
	tilesHW:[      
	  { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	                                     
		  profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],                                                  
		  nodes:[
		         {id:2,offset:{x:1,y:0,wy:1},center:{x:1,y:0,wy:0.5,hx:0.5}}, 
		         {id:1,offset:{x:1,y:0,wy:1},center:{x:1.5,y:0.5,wy:1}},
		         {id:2,offset:{x:1,y:1,hx:-1,wy:1},center:{x:1,y:1,hx:-0.5, wy:0.5}},
		         {id:2,offset:{x:0,y:1,hx:-1},center:{x:0,y:1,hx:-0.5,wy:-0.5}},
		         {id:1,offset:{x:-1,y:0,wy:-1},center:{x:-0.5,y:0.5,wy:-1}},
		         {id:2,offset:{x:0,y:0},center:{x:0,y:0,wy:-0.5,hx:0.5}}
		        ]                                                                                           
		},                                                                                                    
		{ id:2,
			pidIndex:0,                                                                                               
			rot:{r:-90},	//围绕pos点旋转r度	 	  	                                                     
		  profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位                              
		  nodes:[
		         {id:1,offset:{x:0,y:-1,hx:1},center:{x:0.5,y:-0.5,hx:1}},        //wy为以w为长度的y轴偏移
		         {id:2,offset:{x:1,y:0,wy:1},center:{x:1,y:0,wy:0.5,hx:0.5}},          //hx为以h为长度的x轴偏移
		         {id:1,offset:{x:0,y:0},center:{x:0.5,y:0.5}},
		         {id:1,offset:{x:-1,y:0,wy:-1},center:{x:-0.5,y:0.5,wy:-1}},
		         {id:2,offset:{x:-1,y:0,wy:-1},center:{x:-1,y:0,wy:-1.5,hx:0.5}},
		         {id:1,offset:{x:-1,y:-1,hx:1,wy:-1},center:{x:-0.5,y:-0.5,hx:1,wy:-1}}
		        ]                                                                                              
		}                                                                                                     

	]
}



PAVEMODEL.DOUBLEPAVE_35 = {//点铺
    name:"DOUBLEPAVE_35",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
                aw:0.073,  //绝对长宽aw,ah，单位m
                ah:0.073,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
                profile:[
                    {x:0,y:0},
                    {x:0.06,y:0},{x:0.15,y:0.06},{x:0.235,y:0.1},{x:0.325,y:0.13},{x:0.415,y:0.143},{x:0.5,y:0.147},
                    {x:0.59,y:0.145},{x:0.675,y:0.13},{x:0.765,y:0.097},{x:0.85,y:0.055},{x:0.94,y:0},
                    {x:1,y:0},
                    {x:1,y:0.06},{x:0.94,y:0.15},{x:0.9,y:0.235},{x:0.87,y:0.325},{x:0.857,y:0.415},
                    {x:0.853,y:0.5},{x:0.855,y:0.59},{x:0.87,y:0.675},{x:0.903,y:0.765},{x:0.945,y:0.85},{x:1,y:0.94},
                    {x:1,y:1},
                    {x:0.94,y:1},{x:0.85,y:0.94},{x:0.765,y:0.9},{x:0.675,y:0.87},{x:0.59,y:0.855},
                    {x:0.5,y:0.853},{x:0.415,y:0.855},{x:0.325,y:0.87},{x:0.235,y:0.903},{x:0.15,y:0.945},{x:0.06,y:1},
                    {x:0,y:1},
                    {x:0,y:0.94},{x:0.06,y:0.85},{x:0.1,y:0.765},{x:0.13,y:0.675},{x:0.143,y:0.585},
                    {x:0.15,y:0.5},{x:0.145,y:0.41},{x:0.13,y:0.325},{x:0.1,y:0.235},{x:0.055,y:0.15},{x:0,y:0.06}
                ],
                nodes:[{id:2,offset:{x:1,y:0},center:{x:1,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:0,y:1},center:{x:0,y:1}},
                    {id:2,offset:{x:-1,y:0},center:{x:-1,y:0}},
                    {id:2,offset:{x:0,y:-1},center:{x:0,y:-1}}
                ]

            }
        ]
}

PAVEMODEL.DOUBLEPAVE_36 = {//对角线三角形点铺
    name:"DOUBLEPAVE_36",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,
                aw:0.16,  //绝对长宽aw,ah，单位m
                ah:0.16,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:0,y:-1},   //旋转45度后偏移l(自身对角线长度)
                profile:[{x:0,y:0},{x:0,y:1},{x:1,y:1}],
                nodes:[
                    {id:2,offset:{x:2,y:0},center:{x:2,y:0,ax:0.04,ay:-0.04}},
                    {id:2,offset:{x:0,y:2},center:{x:0,y:2,ax:0.04,ay:-0.04}},
                    {id:2,offset:{x:-2,y:0},center:{x:-2,y:0,ax:0.04,ay:-0.04}},
                    {id:2,offset:{x:0,y:-2},center:{x:0,y:-2,ax:0.04,ay:-0.04}},

                    {id:3,offset:{x:0,y:0,ax:-0.08},center:{x:0,y:0,ax:-0.04,ay:0.04}},
                    {id:2,offset:{x:-1,y:-1},center:{x:-1,y:-1,ax:0.04,ay:-0.04}},
                ]
            },
            { id:3,
                aw:0.16,
                ah:0.16,
                pidIndex:0,
                rot:{r:0,x:-0.5},
                profile:[{x:0,y:0},{x:1,y:1},{x:1,y:0}],
                nodes:[
                    {id:3,offset:{x:2,y:0},center:{x:2,y:0,ax:0.04,ay:0.04}},
                    {id:3,offset:{x:0,y:2},center:{x:0,y:2,ax:0.04,ay:0.04}},
                    {id:3,offset:{x:-2,y:0},center:{x:-2,y:0,ax:0.04,ay:0.04}},
                    {id:3,offset:{x:0,y:-2},center:{x:0,y:-2,ax:0.04,ay:0.04}},
                ]
            }
        ]
}

//备用参考模版
PAVEMODEL.DOUBLEPAVE_01111 = {
    name:"DOUBLEPAVE_01111",
    pids:["p37165201b855480e9360f682ab690654" //pid(深啡网)
    ],
    /*正方形或横向的砖用下面*/
    tiles: [
        { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
            nodes:[{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                {id:1,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
                {id:2,offset:{x:-0.5,y:1},center:{x:0,y:1.5}},
                {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:1,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
                {id:2,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}
            ]
        },
        { id:2,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
            nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                {id:2,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
                {id:1,offset:{x:-0.5,y:1},center:{x:0,y:1.5}},
                {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:2,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
                {id:1,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}
            ]
        }
    ],
    /*竖起来的砖用下面*/
    tilesHW: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:2,offset:{x:1,y:0.5},center:{x:1.5,y:1}},
                {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                {id:2,offset:{x:-1,y:0.5},center:{x:-0.5,y:1}},
                {id:2,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0}},
                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},
                {id:2,offset:{x:1,y:-0.5},center:{x:1.5,y:0}}
            ]
        },
        { id:2,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[{id:1,offset:{x:1,y:0.5},center:{x:1.5,y:1}},
                {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                {id:1,offset:{x:-1,y:0.5},center:{x:-0.5,y:1}},
                {id:1,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0}},
                {id:2,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},
                {id:1,offset:{x:1,y:-0.5},center:{x:1.5,y:0}}
            ]
        }
    ]

}
