//多砖模板


PAVEMODEL.MULTPAVE_01 = {//点铺
    name:"MULTPAVE_01",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:3,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:3,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            },
            {  id:3,
                pidIndex:1, //指定用砖索引，对应pids，没有指定将使用主material
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
                aw:0.08,  //绝对长宽aw,ah，单位m
                ah:0.08,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:1,y:1},center:{x:1,y:1}},
                    {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
                    {id:2,offset:{x:-1,y:1},center:{x:-1,y:1}},
                    {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
                    {id:2,offset:{x:-1,y:-1},center:{x:-1,y:-1}},
                    {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}},
                    {id:2,offset:{x:1,y:-1},center:{x:1,y:-1}},

                    {id:2,offset:{x:1,y:0},center:{x:1,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:0,y:1},center:{x:0,y:1}},
                    {id:2,offset:{x:-1,y:0},center:{x:-1,y:0}},
                    {id:2,offset:{x:0,y:-1},center:{x:0,y:-1}}
                ]

            }
        ]
}


PAVEMODEL.MULTPAVE_02 = {//点铺
    name:"MULTPAVE_02",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:3,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:4,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:5,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:4,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            },
            {  id:3,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:4,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:5,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:5,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            },
            {  id:4,
                pidIndex:1, //指定用砖索引，对应pids，没有指定将使用主material
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:5,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            },
            {  id:5,
                pidIndex:1, //指定用砖索引，对应pids，没有指定将使用主material
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:3,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:4,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
                aw:0.08,  //绝对长宽aw,ah，单位m
                ah:0.08,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:1,y:1},center:{x:1,y:1}},
                    {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
                    {id:2,offset:{x:-1,y:1},center:{x:-1,y:1}},
                    {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
                    {id:2,offset:{x:-1,y:-1},center:{x:-1,y:-1}},
                    {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}},
                    {id:2,offset:{x:1,y:-1},center:{x:1,y:-1}},

                    {id:2,offset:{x:1,y:0},center:{x:1,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:0,y:1},center:{x:0,y:1}},
                    {id:2,offset:{x:-1,y:0},center:{x:-1,y:0}},
                    {id:2,offset:{x:0,y:-1},center:{x:0,y:-1}}
                ]

            }
        ]
}

PAVEMODEL.MULTPAVE_03 = {//点铺
    name:"MULTPAVE_03",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:3,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:3,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            },
            {  id:3,
                pidIndex:1, //指定用砖索引，对应pids，没有指定将使用主material
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
                aw:0.08,  //绝对长宽aw,ah，单位m
                ah:0.08,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
                    {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
                    {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}}
                ]

            }
        ]
}

PAVEMODEL.MULTPAVE_04 = {//点铺
    name:"MULTPAVE_04",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:3,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:3,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            },
            {  id:3,
                pidIndex:1, //指定用砖索引，对应pids，没有指定将使用主material
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
                aw:0.08,  //绝对长宽aw,ah，单位m
                ah:0.08,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:45,ly:-0.5},   //旋转45度后偏移l(自身对角线长度)
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
                    {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
                    {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}},
                    {id:2,offset:{x:1,y:1},center:{x:1,y:1}},
                ]

            }
        ]
}


PAVEMODEL.MULTPAVE_05 = {//点铺
    name:"MULTPAVE_05",
    //需要加载的pids列表(用于初始化材质列表)
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: //主砖
        [
            {  id:1,
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:3,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:3,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            },
            {  id:3,
                pidIndex:1, //指定用砖索引，对应pids，没有指定将使用主material
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
                    {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                    {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
                ]
            }
        ],
    topTiles: //顶层(用于对tiles层进行裁剪,可定义是否使用整砖)
        [
            { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
                aw:0.08,  //绝对长宽aw,ah，单位m
                ah:0.08,
                pidIndex:0, //指定用砖索引，对应pids，没有指定将使用主material
                rot:{r:0,x:-0.5,y:-0.5},   //旋转45度后偏移l(自身对角线长度)
                profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
                nodes:[{id:2,offset:{x:2,y:0},center:{x:2,y:0}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
                    {id:2,offset:{x:0,y:2},center:{x:0,y:2}},
                    {id:2,offset:{x:-2,y:0},center:{x:-2,y:0}},
                    {id:2,offset:{x:0,y:-2},center:{x:0,y:-2}},
                    {id:2,offset:{x:1,y:1},center:{x:1,y:1}},
                ]

            }
        ]
}

PAVEMODEL.MULTPAVE_07 = {
    name:"MULTPAVE_07",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1.15,
            th:1.15,//id1要设置大小
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1

                {id:1,offset:{x:1.15,y:0},center:{x:1.725,y:0.575}},
                {id:1,offset:{x:0,y:1.15},center:{x:0.575,y:1.725}},
                {id:1,offset:{x:-1.15,y:0},center:{x:-0.575,y:0.575}},
                {id:1,offset:{x:0,y:-1.15},center:{x:0.575,y:-0.575}}
            ],
            groupnodes:[
                {id:4,offset:{x:1,y:1}},
                {id:2,offset:{x:0,y:0}},
                {id:3,offset:{x:1,y:0}},
                {id:5,offset:{x:0,y:1}}
            ],
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
            nodes:[]
        },
        { id:3,//竖线
            tw:0.15,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:5,//横线
            th:0.15,
            tw:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4,//顶点
            tw:0.15,
            th:0.15,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.MULTPAVE_08 = {
    name:"MULTPAVE_08",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2.2,
            th:2.2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:2.2,y:0},center:{x:3.2,y:1.2}},
                {id:1,offset:{x:0,y:2.2},center:{x:1.2,y:3.2}},
                {id:1,offset:{x:-2.2,y:0},center:{x:-1.2,y:1.2}},
                {id:1,offset:{x:0,y:-2.2},center:{x:1.2,y:-1.2}}
            ],
            groupnodes:[
                //小边线+小顶点
                {id:4,offset:{x:0,y:0}},
                {id:5,offset:{x:0,y:1}},
                {id:6,offset:{x:0.1,y:1}},

                {id:4,offset:{x:1.1,y:0}},
                {id:5,offset:{x:1.1,y:1}},
                {id:6,offset:{x:1.2,y:1}},

                {id:4,offset:{x:0,y:1.1}},
                {id:5,offset:{x:0,y:2.1}},
                {id:6,offset:{x:0.1,y:2.1}},

                {id:4,offset:{x:1.1,y:1.1}},
                {id:5,offset:{x:1.1,y:2.1}},
                {id:6,offset:{x:1.2,y:2.1}},

                //子砖
                {id:2,offset:{x:0.1,y:1.1}},
                {id:2,offset:{x:1.2,y:0}},
                {id:3,offset:{x:0.1,y:0}},
                {id:3,offset:{x:1.2,y:1.1}},


            ],
        },
        { id:2,   //子砖1
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:3,  //子砖2
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
        ,
        { id:4,   //小边线
            tw:0.1,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:5, //小顶角
            tw:0.1,
            th:0.1,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:6,   //小边线
            th:0.1,
            tw:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }

    ]
}


PAVEMODEL.MULTPAVE_09 = {
    name:"MULTPAVE_08",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2.2,
            th:2.2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:2.2,y:0},center:{x:3.2,y:1.}},
                {id:1,offset:{x:0,y:2.2},center:{x:1.2,y:3.2}},
                {id:1,offset:{x:-2.2,y:0},center:{x:-1.2,y:1.2}},
                {id:1,offset:{x:0,y:-2.2},center:{x:1.2,y:-1.2}}
            ],
            groupnodes:[
                //小边线+小顶点
                {id:4,offset:{x:0,y:0}},
                {id:5,offset:{x:0,y:1}},
                {id:6,offset:{x:0.1,y:1}},

                {id:4,offset:{x:1.1,y:0}},
                {id:5,offset:{x:1.1,y:1}},
                {id:6,offset:{x:1.2,y:1}},

                {id:4,offset:{x:0,y:1.1}},
                {id:5,offset:{x:0,y:2.1}},
                {id:6,offset:{x:0.1,y:2.1}},

                {id:4,offset:{x:1.1,y:1.1}},
                {id:5,offset:{x:1.1,y:2.1}},
                {id:6,offset:{x:1.2,y:2.1}},

                //子砖
                {id:2,offset:{x:0.1,y:0}},
                {id:2,offset:{x:0.6,y:0}},
                {id:2,offset:{x:0.1,y:0.5}},
                {id:2,offset:{x:0.6,y:0.5}},

                {id:2,offset:{x:0.1,y:1.1}},
                {id:2,offset:{x:0.6,y:1.1}},
                {id:2,offset:{x:0.1,y:1.6}},
                {id:2,offset:{x:0.6,y:1.6}},

                {id:2,offset:{x:1.2,y:0}},
                {id:2,offset:{x:1.7,y:0}},
                {id:2,offset:{x:1.2,y:0.5}},
                {id:2,offset:{x:1.7,y:0.5}},

                {id:2,offset:{x:1.2,y:1.1}},
                {id:2,offset:{x:1.7,y:1.1}},
                {id:2,offset:{x:1.2,y:1.6}},
                {id:2,offset:{x:1.7,y:1.6}},





            ],
        },
        { id:2,   //子砖1
            tw:0.5,
            th:0.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4,   //小边线
            tw:0.1,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:5, //小顶角
            tw:0.1,
            th:0.1,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:6,   //小边线
            th:0.1,
            tw:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }

    ]
}

PAVEMODEL.MULTPAVE_10 = {
    name:"MULTPAVE_10",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48","p47119e1574c4481ab4172255978428a6" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1.12,
            th:1.12,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:1.12,y:0},center:{x:1.62,y:0.62}},
                {id:1,offset:{x:0,y:1.12},center:{x:0.62,y:1.62}},
                {id:1,offset:{x:-1.12,y:0},center:{x:-0.62,y:0.62}},
                {id:1,offset:{x:0,y:-1.12},center:{x:0.62,y:-0.62}}
            ],
            groupnodes:[
                //下边线
                {id:3,offset:{x:0,y:0}},
                {id:4,offset:{x:0.04,y:0}},
                {id:3,offset:{x:0.08,y:0}},

                //顶点-下
                {id:7,offset:{x:0,y:1}},
                {id:8,offset:{x:0.04,y:1}},
                {id:7,offset:{x:0.08,y:1}},
                //顶点-中
                {id:8,offset:{x:0,y:1.04}},
                {id:7,offset:{x:0.04,y:1.04}},
                {id:8,offset:{x:0.08,y:1.04}},
                //顶点-上
                {id:7,offset:{x:0,y:1.08}},
                {id:8,offset:{x:0.04,y:1.08}},
                {id:7,offset:{x:0.08,y:1.08}},

                //上边线
                {id:5,offset:{x:0.12,y:1}},
                {id:6,offset:{x:0.12,y:1.04}},
                {id:5,offset:{x:0.12,y:1.08}},

                //子砖
                {id:2,offset:{x:0.12,y:0}}
            ],
        },
        { id:2,   //子砖1
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,   //下边线1
            tw:0.04,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4, //下边线2
            tw:0.04,
            th:1,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },


        { id:5,   //上边线1
            tw:1,
            th:0.04,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:6, //上边线2
            tw:1,
            th:0.04,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:7, //顶点1
            tw:0.04,
            th:0.04,
            pidIndex:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:8, //顶点2
            tw:0.04,
            th:0.04,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.MULTPAVE_11 = {
    name:"MULTPAVE_11",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1.12,
            th:1.12,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:1.12,y:0},center:{x:1.62,y:0.62}},
                {id:1,offset:{x:0,y:1.12},center:{x:0.62,y:1.62}},
                {id:1,offset:{x:-1.12,y:0},center:{x:-0.62,y:0.62}},
                {id:1,offset:{x:0,y:-1.12},center:{x:0.62,y:-0.62}}
            ],
            groupnodes:[
                //下边线
                {id:3,offset:{x:0,y:0}},
                {id:4,offset:{x:0.06,y:0}},

                //顶点
                {id:7,offset:{x:0,y:1}},

                //上边线
                {id:5,offset:{x:0.12,y:1}},
                {id:6,offset:{x:0.12,y:1.06}},

                //子砖
                {id:2,offset:{x:0.12,y:0}}
            ]
        },
        { id:2,   //子砖1
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,   //下边线1
            tw:0.06,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4, //下边线2
            tw:0.06,
            th:1,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },


        { id:5,   //上边线1
            tw:1,
            th:0.06,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:6, //上边线2
            tw:1,
            th:0.06,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:7, //顶点1
            tw:0.12,
            th:0.12,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}


PAVEMODEL.MULTPAVE_12 = {
    name:"MULTPAVE_12",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48","p47119e1574c4481ab4172255978428a6" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2.4,
            th:2.4,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:2.4,y:0},center:{x:3.6,y:1.2}},
                {id:1,offset:{x:0,y:2.4},center:{x:1.2,y:3.6}},
                {id:1,offset:{x:-2.4,y:0},center:{x:-1.2,y:1.2}},
                {id:1,offset:{x:0,y:-2.4},center:{x:1.2,y:-1.2}}
            ],
            groupnodes:[
                //小边线+小顶点-左下角
                {id:6,offset:{x:0,y:0}},
                {id:7,offset:{x:0.1,y:0}},
                {id:8,offset:{x:0,y:0.1}},

                {id:6,offset:{x:0,y:1.1}},
                {id:7,offset:{x:0.1,y:1.1}},
                {id:6,offset:{x:1.1,y:1.1}},
                {id:8,offset:{x:1.1,y:0.1}},

                {id:6,offset:{x:1.1,y:0}},

                //小边线+小顶点-右下下角
                {id:3,offset:{x:1.2,y:0}},
                {id:4,offset:{x:1.3,y:0}},
                {id:5,offset:{x:1.2,y:0.1}},

                {id:3,offset:{x:1.2,y:1.1}},
                {id:4,offset:{x:1.3,y:1.1}},
                {id:3,offset:{x:2.3,y:1.1}},
                {id:5,offset:{x:2.3,y:0.1}},

                {id:3,offset:{x:2.3,y:0}},

                //小边线+小顶点-左上角
                {id:3,offset:{x:0,y:1.2}},
                {id:4,offset:{x:0.1,y:1.2}},
                {id:5,offset:{x:0,y:1.3}},

                {id:3,offset:{x:0,y:2.3}},
                {id:4,offset:{x:0.1,y:2.3}},
                {id:3,offset:{x:1.1,y:2.3}},
                {id:5,offset:{x:1.1,y:1.3}},

                {id:3,offset:{x:1.1,y:1.2}},

                //小边线+小顶点-右上角
                {id:6,offset:{x:1.2,y:1.2}},
                {id:7,offset:{x:1.3,y:1.2}},
                {id:8,offset:{x:1.2,y:1.3}},

                {id:6,offset:{x:1.2,y:2.3}},
                {id:7,offset:{x:1.3,y:2.3}},
                {id:6,offset:{x:2.3,y:2.3}},
                {id:8,offset:{x:2.3,y:1.3}},

                {id:6,offset:{x:2.3,y:1.2}},

                //子砖
                {id:2,offset:{x:0.1,y:0.1}},
                {id:2,offset:{x:1.3,y:0.1}},
                {id:2,offset:{x:0.1,y:1.3}},
                {id:2,offset:{x:1.3,y:1.3}},


            ],
        },
        { id:2,   //子砖1
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
        ,
        { id:3, //小顶角
            tw:0.1,
            th:0.1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4,   //小边线-横
            tw:1,
            th:0.1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:5,   //小边线-竖
            tw:0.1,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:6, //小顶角
            tw:0.1,
            th:0.1,
            pidIndex:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:7,   //小边线-横
            tw:1,
            th:0.1,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:8,   //小边线-竖
            tw:0.1,
            th:1,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }

    ]
}


PAVEMODEL.MULTPAVE_14 = {
    name:"MULTPAVE_14",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48","p47119e1574c4481ab4172255978428a6" //pid(深啡网)，，黑金花
    ],
    tiles: [
        {id:1,
            tw:1.32,
            th:1.32,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:1.32,y:0},center:{x:1.98,y:0.66}},
                {id:1,offset:{x:0,y:1.32},center:{x:0.66,y:1.98}},
                {id:1,offset:{x:-1.32,y:0},center:{x:-0.66,y:0.66}},
                {id:1,offset:{x:0,y:-1.32},center:{x:0.66,y:-0.66}}
            ],
            groupnodes:[
                //右边线
                {id:3,offset:{x:1,y:0}},
                {id:4,offset:{x:1.08,y:0}},
                {id:3,offset:{x:1.24,y:0}},

                //顶点-下
                {id:7,offset:{x:1,y:1}},
                {id:8,offset:{x:1.08,y:1}},
                {id:7,offset:{x:1.24,y:1}},
                //顶点-中
                {id:9,offset:{x:1,y:1.08}},
                {id:10,offset:{x:1.08,y:1.08}},
                {id:9,offset:{x:1.24,y:1.08}},
                //顶点-上
                {id:7,offset:{x:1,y:1.24}},
                {id:8,offset:{x:1.08,y:1.24}},
                {id:7,offset:{x:1.24,y:1.24}},

                //上边线
                {id:5,offset:{x:0,y:1}},
                {id:6,offset:{x:0,y:1.08}},
                {id:5,offset:{x:0,y:1.24}},

                //子砖
                {id:2,offset:{x:0,y:0}}
            ],
        },
        { id:2,   //子砖1
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,   //右边线1
            tw:0.08,
            th:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4, //右边线2-粗
            tw:0.16,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:5,   //上边线1
            tw:1,
            th:0.08,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:6, //上边线2-粗
            tw:1,
            th:0.16,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:7, //顶点1-小
            tw:0.08,
            th:0.08,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:8, //顶点2-横
            tw:0.16,
            th:0.08,
            pidIndex:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:9, //顶点2-竖
            tw:0.08,
            th:0.16,
            pidIndex:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:10, //顶点3-中
            tw:0.16,
            th:0.16,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.MULTPAVE_16 = {
    name:"MULTPAVE_16",
    pids:["p1d98559f96864be19a6c72819e9291d7","p680f89422fd34663af2ff7d742841a72","p76285b7c938442fcba12e30e69f11138","pb4e7498917b543da813da9f6b21b11b2","p25c6885f8f714f9aab3ff0a2af526428"
    ],
    tiles: [
        {id:1,
            tw:1.16,
            th:1.16,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:1.16,y:0},center:{x:1.5,y:0.82}},
                {id:1,offset:{x:0,y:1.16},center:{x:0.5,y:1.82}},
                {id:1,offset:{x:-1.16,y:0},center:{x:-0.5,y:0.82}},
                {id:1,offset:{x:0,y:-1.16},center:{x:0.5,y:-0.82}}
            ],
            groupnodes:[
                //右边线
                {id:3,offset:{x:1,y:0.08}},
                {id:4,offset:{x:1.08,y:0.08}},

                //顶点
                {id:7,offset:{x:1.08,y:0}},

                //下边线
                {id:5,offset:{x:0,y:0}},
                {id:6,offset:{x:0,y:0.08}},

                //子砖
                {id:2,offset:{x:0,y:0.16}}
            ]
        },
        { id:2,   //子砖1
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,   //右边线1-内裁剪
            tw:0.08,
            th:1.08,
            pidIndex:0,
            profile:[{x:0,y:0.075},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4, //右边线2
            tw:0.08,
            th:1.08,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },


        { id:5,   //下边线1
            tw:1.08,
            th:0.08,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:6, //下边线2 -内裁剪
            tw:1.08,
            th:0.08,
            pidIndex:3,

            profile:[{x:0,y:0},{x:1,y:0},{x:0.925,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:7, //顶点1
            tw:0.08,
            th:0.08,
            pidIndex:4,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.MULTPAVE_22 = {
    name:"MULTPAVE_22",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1.1,
            th:1.1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，

                {id:1,offset:{x:1.1,y:-0.1},center:{x:1.55,y:0.5}},
                {id:1,offset:{x:-0.1,y:1.1},center:{x:0.55,y:1.5}},
                {id:1,offset:{x:-1.1,y:0.1},center:{x:-0.55,y:0.5}},
                {id:1,offset:{x:0.1,y:-1.1},center:{x:0.55,y:-0.5}}
            ],
            groupnodes:[
                {id:3,offset:{x:1,y:0}},
                {id:4,offset:{x:0,y:1}},
                {id:2,offset:{x:0,y:0}}
            ],
        },
        { id:2,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
            nodes:[]
        },
        { id:3,//竖线
            tw:0.1,
            th:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },
        { id:4,//横线
            th:0.1,
            tw:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        }
    ]
}

PAVEMODEL.MULTPAVE_24 = {
    name:"MULTPAVE_24",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48","p47119e1574c4481ab4172255978428a6","p6866902dcac84dac9484f703743e13a4","p875f4c6f6f894478910a001ad39db265","p25c6885f8f714f9aab3ff0a2af526428" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:7,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:7,y:0},center:{x:10.5,y:0.5}},
                {id:1,offset:{x:0,y:1},center:{x:3.5,y:1.5}},
                {id:1,offset:{x:-7,y:0},center:{x:-3.5,y:0.5}},
                {id:1,offset:{x:0,y:-1},center:{x:3.5,y:-0.5}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:3,offset:{x:1,y:0}},
                {id:4,offset:{x:2,y:0}},
                {id:5,offset:{x:3,y:0}},
                {id:6,offset:{x:4,y:0}},
                {id:7,offset:{x:5,y:0}},
                {id:8,offset:{x:6,y:0}}
            ]
        },
        { id:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            //pidIndex:6,
            nodes:[]
        },

        { id:3,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },
        { id:4,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:1,
            nodes:[]
        },
        { id:5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:2,
            nodes:[]
        },
        { id:6,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:3,
            nodes:[]
        },
        { id:7,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:4,
            nodes:[]
        },
        { id:8,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:5,
            nodes:[]
        }
    ]
}

PAVEMODEL.MULTPAVE_25 = {
    name:"MULTPAVE_25",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1.5,
            th:0.6,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:1.5,y:0},center:{x:2.25,y:0.3}},
                {id:1,offset:{x:0,y:0.6},center:{x:0.75,y:0.9}},
                {id:1,offset:{x:-1.5,y:0},center:{x:-0.75,y:0.3}},
                {id:1,offset:{x:0,y:-0.6},center:{x:0.75,y:-0.3}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:3,offset:{x:1,y:0}},
                {id:4,offset:{x:0,y:0.5}},
                {id:5,offset:{x:1,y:0.5}}
            ]
        },
        { id:2,//主砖
            tw:1,
            th:0.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,//次砖
            tw:0.5,
            th:0.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },
        { id:4,//主横线
            tw:1,
            th:0.1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:1,
            nodes:[]
        },
        { id:5,//短横线
            tw:0.5,
            th:0.1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:2,
            nodes:[]
        }

    ]
}

PAVEMODEL.MULTPAVE_26 = {
    name:"MULTPAVE_26",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:2,y:0},center:{x:3,y:0.5}},
                {id:1,offset:{x:0,y:1},center:{x:1,y:1.5}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:0.5}},
                {id:1,offset:{x:0,y:-1},center:{x:1,y:-0.5}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:1,y:0}},

                {id:3,offset:{x:0,y:0.5}},
                {id:4,offset:{x:0,y:0.9}},

                {id:3,offset:{x:1,y:0.6}},
                {id:4,offset:{x:1,y:0.5}}
            ]
        },
        { id:2,//主砖
            tw:1,
            th:0.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,//次砖
            tw:1,
            th:0.4,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },
        { id:4,//横线
            tw:1,
            th:0.1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:1,
            nodes:[]
        }

    ]
}

PAVEMODEL.MULTPAVE_27 = {
    name:"MULTPAVE_27",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:1.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:2,y:0},center:{x:3,y:0.75}},
                {id:1,offset:{x:0,y:1.5},center:{x:0,y:2.25}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:0.75}},
                {id:1,offset:{x:0,y:-1.5},center:{x:1,y:-0.75}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:1,y:0.8}},

                {id:3,offset:{x:0,y:0.7}},
                {id:4,offset:{x:0,y:1.1}},

                {id:3,offset:{x:1,y:0.4}},
                {id:4,offset:{x:1,y:0}}
            ]
        },
        { id:2,//主砖
            tw:1,
            th:0.7,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,//次砖1
            tw:1,
            th:0.4,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },
        { id:4,//次砖2
            tw:1,
            th:0.4,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:1,
            nodes:[]
        }

    ]
}

PAVEMODEL.MULTPAVE_28 = {
    name:"MULTPAVE_28",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:2,
            th:1.77,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:2,y:0},center:{x:3,y:0.885}},
                {id:1,offset:{x:0,y:1.77},center:{x:0,y:2.655}},
                {id:1,offset:{x:-2,y:0},center:{x:-1,y:0.885}},
                {id:1,offset:{x:0,y:-1.77},center:{x:1,y:-0.885}}
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:2,offset:{x:1,y:0.77}},

                {id:3,offset:{x:0,y:1}},
                {id:4,offset:{x:0.2,y:1}},

                {id:3,offset:{x:1,y:0}},
                {id:4,offset:{x:1.2,y:0}}
            ]
        },
        { id:2,//主砖
            tw:1,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,//竖线
            tw:0.2,
            th:0.77,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },
        { id:4,//次砖
            tw:0.8,
            th:0.77,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:1,
            nodes:[]
        }

    ]
}

PAVEMODEL.MULTPAVE_30 = {
    name:"MULTPAVE_30",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8","pea034619de184edb85490191626d1a48" //pid(深啡网)
    ],
    tiles: [
        { id:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:2,offset:{x:1,y:0},center:{x:1.25,y:0.5}},
                {id:4,offset:{x:0.5,y:1},center:{x:1,y:1.25}},
                {id:3,offset:{x:-0.5,y:1},center:{x:0,y:1.25}},
                {id:4,offset:{x:-1,y:0.5},center:{x:-0.5,y:0.75}},
                {id:2,offset:{x:-0.5,y:-0.5},center:{x:-0.25,y:0}},
                {id:3,offset:{x:0,y:-0.5},center:{x:0.5,y:-0.25}}
            ]
        },
        { id:2,
            tw:0.5,
            th:1,
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:0.5,y:0},center:{x:1,y:0.25}},
                {id:1,offset:{x:0.5,y:0.5},center:{x:1,y:1}},
                {id:4,offset:{x:-0.5,y:1},center:{x:0,y:1.25}},
                {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
                {id:4,offset:{x:0,y:-0.5},center:{x:0.5,y:-0.25}}

            ]
        }
        ,
        { id:3,
            tw:1,
            th:0.5,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:4,offset:{x:1,y:0},center:{x:1.5,y:0.25}},
                {id:1,offset:{x:0,y:0.5},center:{x:0.5,y:1}},


                {id:2,offset:{x:-0.5,y:0},center:{x:-0.25,y:0.5}},
                {id:4,offset:{x:-0.5,y:-0.5},center:{x:0,y:-0.25}},
                {id:1,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}

            ]
        }
        ,
        { id:4,
            tw:1,
            th:0.5,
            pidIndex:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:1,y:-0.5},center:{x:1.5,y:0}},
                {id:3,offset:{x:0.5,y:0.5},center:{x:1,y:0.75}},


                {id:2,offset:{x:0,y:0.5},center:{x:0.25,y:1}},
                {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.25}},
                {id:1,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
                {id:2,offset:{x:0.5,y:-1},center:{x:0.75,y:-0.5}}
            ]
        }

    ]
}


PAVEMODEL.MULTPAVE_31 = {
    name:"MULTPAVE_31",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1,
            th:1.95,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:1,y:0.35},center:{x:1.5,y:1.325}},//右边
                {id:1,offset:{x:0,y:1.95},center:{x:0.5,y:2.925}},//上边
                {id:1,offset:{x:-1,y:1.6},center:{x:-0.5,y:2.575}},//左上角
                {id:1,offset:{x:-1,y:-0.35},center:{x:-0.5,y:0.885}},//左边
                {id:1,offset:{x:0,y:-1.95},center:{x:0.5,y:-0.975}},//下边
                {id:1,offset:{x:1,y:-1.6},center:{x:0.5,y:-0.625}}//右下边
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:3,offset:{x:0,y:1}},
                {id:4,offset:{x:0.4,y:1}},
                {id:5,offset:{x:0,y:1.6}}
            ]
        },
        { id:2,//主砖
            tw:1,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,//次砖1-竖
            tw:0.4,
            th:0.6,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },
        { id:4,//次砖2-竖
            tw:0.6,
            th:0.6,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:1,
            nodes:[]
        },
        { id:5,//次砖3-横
            tw:1,
            th:0.35,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },

    ]
}

PAVEMODEL.MULTPAVE_32 = {
    name:"MULTPAVE_32",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        {id:1,
            tw:1,
            th:2,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            type:"group", //组类型
            nodes:[//整个组作为id1 ，围绕id1 四周上下左右 4个都是id1，
                {id:1,offset:{x:1,y:0.5},center:{x:1.5,y:1}},//右边
                {id:1,offset:{x:0.5,y:2},center:{x:1,y:3}},//右上边
                {id:1,offset:{x:-0.5,y:1.5},center:{x:0,y:2.5}},//左上角

                {id:1,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0.5}},//左边

                {id:1,offset:{x:-0.5,y:-2},center:{x:0,y:-1}},//下边
                {id:1,offset:{x:0.5,y:-1.5},center:{x:1,y:-0.5}}//右下边
            ],
            groupnodes:[
                {id:2,offset:{x:0,y:0}},
                {id:3,offset:{x:0,y:1}},
                {id:4,offset:{x:0.5,y:1}},
            ]
        },
        { id:2,//主砖
            tw:1,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[]
        },

        { id:3,//次砖1-方
            tw:0.5,
            th:0.5,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:0,
            nodes:[]
        },
        { id:4,//次砖2-竖
            tw:0.5,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            pidIndex:1,
            nodes:[]
        }

    ]
}

PAVEMODEL.MULTPAVE_33 = {
    name:"MULTPAVE_33",
    pids:["p37165201b855480e9360f682ab690654","p93e96e3ec3b14b87941c846ec3d394b8" //pid(深啡网)
    ],
    tiles: [
        { id:1,
            tw:1,
            th:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:1,y:-0.5},center:{x:1.5,y:0}},
                {id:2,offset:{x:1,y:0.5},center:{x:1.5,y:0.75}},
                {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.25}},
                {id:1,offset:{x:-1,y:0.5},center:{x:-0.5,y:1}},
                {id:4,offset:{x:-1,y:0},center:{x:-0.5,y:0.25}},
                {id:4,offset:{x:0,y:-0.5},center:{x:0.5,y:-0.25}}
            ]
        },
        { id:2,
            tw:1,
            th:0.5,
            // tHw:0,//以h为单位的w
            // tWh:1,//以w为单位的h
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:3,offset:{x:1,y:0.5},center:{x:1,y:0.25,hx:0.5}},
                {id:3,offset:{x:0,y:1},center:{x:0,y:0.75,hx:0.5}},
                {id:1,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0}},
                {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
            ]
        }
        ,
        { id:3,
            rot:{r:-90},
            tw:0,
            tHw:0.5,
            th:1,
            pidIndex:1,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:4,offset:{x:0,y:-0.5,hx:1},center:{x:0.5,y:-0.25,hx:1}},//偏移值相对于1号主砖
                {id:4,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.25,hx:1}},
                {id:3,offset:{x:-1,y:0.5},center:{x:-1,y:0.25,hx:0.5}},
                {id:2,offset:{x:-1,y:-0.5},center:{x:-0.5,y:-0.25}},
                {id:2,offset:{x:0,y:-1},center:{x:0.5,y:-0.75}},
                {id:3,offset:{x:1,y:-0.5},center:{x:1,y:-0.75,hx:0.5}}
            ]
        }
        ,
        { id:4,
            tw:1,
            th:0.5,
            // tHw:0,//以h为单位的w
            // tWh:1,//以w为单位的h
            pidIndex:0,
            profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
            nodes:[
                {id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},
                {id:1,offset:{x:0,y:0.5},center:{x:0.5,y:1}},
                {id:3,offset:{x:0,y:0.5,hx:-1},center:{x:0,y:0.25,hx:-0.5}},
                {id:3,offset:{x:1,y:0,wy:0,hx:-1},center:{x:1,y:-0.25,hx:-0.5}}
            ]
        }

    ]

}
