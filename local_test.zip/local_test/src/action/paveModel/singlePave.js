//单砖模板

PAVEMODEL.SINGLEPAVE_01 = {
	name:"SINGLEPAVE_01",
	tiles: [
	 { id:1,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 }
	]
}
//连续混铺
PAVEMODEL.SINGLEPAVE_01X = {
	name:"SINGLEPAVE_01X",
	tiles: [
	 { id:1,
	 	 dir:1,   //砖的朝向指定 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:4,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:4,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 },
	 { id:2,
	 	 dir:1, 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:3,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 },
	 { id:3,
	 	 dir:1,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:4,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:4,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:2,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 },
	 { id:4,
	 	 dir:1,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:3,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 }
	]
}

//连续斜铺
PAVEMODEL.SINGLEPAVE_02 = {
	name:"SINGLEPAVE_02",
	rotate: 45,//所有砖以x,y为旋转点，旋转45度
	tiles: [
	 { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 }
	]
}

//旋转铺砖
PAVEMODEL.SINGLEPAVE_03 = {
	name:"SINGLEPAVE_03",
	tiles: [
	 { id:1,
	 	 dir:1,   //砖的朝向指定 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:4,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:4,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 },
	 { id:2,
	 	 dir:2, 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:3,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:3,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 },
	 { id:3,
	 	 dir:3,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:4,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:4,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:2,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 },
	 { id:4,
	 	 dir:4,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:3,offset:{x:1,y:0},center:{x:1.5,y:0.5}}, 
	          {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},
	          {id:3,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}}
	         ]
	 }
	]
} 

//人字铺砖
PAVEMODEL.SINGLEPAVE_04 = {
	name:"SINGLEPAVE_04",
	tiles: [
	 { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[
	          {id:2,offset:{x:1,y:1},center:{x:1,y:1,hx:0.5,wy:-0.5}},        //wy为以w为长度的y轴偏移
            {id:1,offset:{x:0,y:1,hx:1},center:{x:0.5,y:1.5,hx:1}},          //hx为以h为长度的x轴偏移
            {id:2,offset:{x:0,y:1,wy:1},center:{x:0,y:1,wy:0.5,hx:0.5}},
            {id:2,offset:{x:0,y:0,wy:1,hx:-1},center:{x:0,y:0,wy:0.5,hx:-0.5}},
            {id:1,offset:{x:0,y:-1,hx:-1},center:{x:0.5,y:-0.5,hx:-1}},
            {id:2,offset:{x:1,y:0,hx:-1},center:{x:1,y:0,hx:-0.5,wy:-0.5}}
	         ]
	 },
	 { id:2,
	 	 rot:{r:-90},	//围绕pos点旋转r度	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
	   nodes:[
	          {id:1,offset:{x:0,y:0,wy:-1,hx:1},center:{x:0.5,y:0.5,wy:-1,hx:1}},
	          {id:2,offset:{x:0,y:1,hx:1},center:{x:0,y:1,wy:-0.5,hx:1.5}},
	          {id:1,offset:{x:-1,y:0,hx:1},center:{x:-0.5,y:0.5,hx:1}},
	          {id:1,offset:{x:-1,y:-1},center:{x:-0.5,y:-0.5}},
	          {id:2,offset:{x:0,y:-1,hx:-1},center:{x:0,y:-1,hx:-0.5,wy:-0.5}},
	          {id:1,offset:{x:0,y:-1,wy:-1},center:{x:0.5,y:-0.5,wy:-1}}
	         ]
	 }
	],
	//长宽调转
	tilesHW:[      
	  { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	                                     
		  profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],                                                  
		  nodes:[
		         {id:2,offset:{x:1,y:0,wy:1},center:{x:1,y:0,wy:0.5,hx:0.5}}, 
		         {id:1,offset:{x:1,y:0,wy:1},center:{x:1.5,y:0.5,wy:1}},
		         {id:2,offset:{x:1,y:1,hx:-1,wy:1},center:{x:1,y:1,hx:-0.5, wy:0.5}},
		         {id:2,offset:{x:0,y:1,hx:-1},center:{x:0,y:1,hx:-0.5,wy:-0.5}},    
		         {id:1,offset:{x:-1,y:0,wy:-1},center:{x:-0.5,y:0.5,wy:-1}},
		         {id:2,offset:{x:0,y:0},center:{x:0,y:0,wy:-0.5,hx:0.5}}      
		        ]                                                                                           
		},                                                                                                    
		{ id:2,                                                                                               
			rot:{r:-90},	//围绕pos点旋转r度                                                    
		  profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位                              
		  nodes:[
		         {id:1,offset:{x:0,y:-1,hx:1},center:{x:0.5,y:-0.5,hx:1}},        //wy为以w为长度的y轴偏移             
		         {id:2,offset:{x:1,y:0,wy:1},center:{x:1,y:0,wy:0.5,hx:0.5}},          //hx为以h为长度的x轴偏移             
		         {id:1,offset:{x:0,y:0},center:{x:0.5,y:0.5}},                                      
		         {id:1,offset:{x:-1,y:0,wy:-1},center:{x:-0.5,y:0.5,wy:-1}},                               
		         {id:2,offset:{x:-1,y:0,wy:-1},center:{x:-1,y:0,wy:-1.5,hx:0.5}},                                  
		         {id:1,offset:{x:-1,y:-1,hx:1,wy:-1},center:{x:-0.5,y:-0.5,hx:1,wy:-1}}                         
		        ]                                                                                              
		}                                                                                                     

	]
}

//错位铺砖1
PAVEMODEL.SINGLEPAVE_05 = {
	name:"SINGLEPAVE_05",
	rotate: 0,	
	tiles: [
	 { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:2,offset:{x:0.25,y:1},center:{x:0.75,y:1.5}},
	          {id:2,offset:{x:-0.75,y:1},center:{x:-0.25,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:2,offset:{x:-0.75,y:-1},center:{x:-0.25,y:-0.5}},
	          {id:2,offset:{x:0.25,y:-1},center:{x:0.75,y:-0.5}}
	         ]
	 },
	 { id:2,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:2,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        
	          {id:1,offset:{x:0.75,y:1},center:{x:1.25,y:1.5}},
	          {id:1,offset:{x:-0.25,y:1},center:{x:0.25,y:1.5}},
	          {id:2,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:-0.25,y:-1},center:{x:0.25,y:-0.5}},
	          {id:1,offset:{x:0.75,y:-1},center:{x:1.25,y:-0.5}}
	         ]
	 }
	],
	tilesHW: [
	 { id:1,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:2,offset:{x:1,y:0.25},center:{x:1.5,y:0.75}},	   
	          {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},	          
	          {id:2,offset:{x:-1,y:0.25},center:{x:-0.5,y:0.75}},	          
	          {id:2,offset:{x:-1,y:-0.75},center:{x:-0.5,y:-0.25}},	          
	          {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},	          
	          {id:2,offset:{x:1,y:-0.75},center:{x:1.5,y:-0.25}}
	         ]
	 },
	 { id:2,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   
	   nodes:[{id:1,offset:{x:1,y:0.75},center:{x:1.5,y:1.25}},	           
	          {id:2,offset:{x:0,y:1},center:{x:0.5,y:1.5}},	          
	          {id:1,offset:{x:-1,y:0.75},center:{x:-0.5,y:1.25}},	          
	          {id:1,offset:{x:-1,y:-0.25},center:{x:-0.5,y:0.25}},	          
	          {id:2,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},	          
	          {id:1,offset:{x:1,y:-0.25},center:{x:1.25,y:0.25}}
	         ]
	 }
	]
} 

//错位铺砖2
PAVEMODEL.SINGLEPAVE_06 = {
	name:"SINGLEPAVE_06",
	tiles: [
	 { id:1,    //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:1,y:0},center:{x:1.5,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0.5,y:1},center:{x:1,y:1.5}},
	          {id:1,offset:{x:-0.5,y:1},center:{x:0,y:1.5}},
	          {id:1,offset:{x:-1,y:0},center:{x:-0.5,y:0.5}},
	          {id:1,offset:{x:-0.5,y:-1},center:{x:0,y:-0.5}},
	          {id:1,offset:{x:0.5,y:-1},center:{x:1,y:-0.5}}
	         ]
	 }
	],
	tilesHW: [
	 { id:1,    
	   profile:[{x:0,y:0},{x:1,y:0},{x:1,y:1},{x:0,y:1}],
	   nodes:[{id:1,offset:{x:1,y:0.5},center:{x:1.5,y:1}},	   
	          {id:1,offset:{x:0,y:1},center:{x:0.5,y:1.5}},	          
	          {id:1,offset:{x:-1,y:0.5},center:{x:-0.5,y:1}},	          
	          {id:1,offset:{x:-1,y:-0.5},center:{x:-0.5,y:0}},	          
	          {id:1,offset:{x:0,y:-1},center:{x:0.5,y:-0.5}},	          
	          {id:1,offset:{x:1,y:-0.5},center:{x:1.5,y:0}}
	         ]
	 }
	]
}

//六角铺砖
PAVEMODEL.SINGLEPAVE_07 = {
	name:"SINGLEPAVE_07",
	tiles: [
	 { id:1,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0.5,y:0},{x:0.5+0.433,y:0.5-0.25},{x:0.5+0.433,y:0.5+0.25},{x:0.5,y:1},{x:0.5-0.433,y:0.75},{x:0.5-0.433,y:0.25}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:0.866,y:0},center:{x:1.299,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0.433,y:0.75},center:{x:0.866,y:1.25}},
	          {id:1,offset:{x:-0.433,y:0.75},center:{x:0,y:1.25}},
	          {id:1,offset:{x:-0.866,y:0},center:{x:-0.433,y:0.5}},
	          {id:1,offset:{x:-0.433,y:-0.75},center:{x:0,y:-0.25}},
	          {id:1,offset:{x:0.433,y:-0.75},center:{x:0.866,y:-0.25}}
	         ]
	 }
	]
}

//六角铺砖
PAVEMODEL.SINGLEPAVE_08 = {
	name:"SINGLEPAVE_08",
	rotate:90,
	tiles: [
	 { id:1,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 
	   profile:[{x:0.5,y:0},{x:0.5+0.433,y:0.5-0.25},{x:0.5+0.433,y:0.5+0.25},{x:0.5,y:1},{x:0.5-0.433,y:0.75},{x:0.5-0.433,y:0.25}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:0.866,y:0},center:{x:1.299,y:0.5}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0.433,y:0.75},center:{x:0.866,y:1.25}},
	          {id:1,offset:{x:-0.433,y:0.75},center:{x:0,y:1.25}},
	          {id:1,offset:{x:-0.866,y:0},center:{x:-0.433,y:0.5}},
	          {id:1,offset:{x:-0.433,y:-0.75},center:{x:0,y:-0.25}},
	          {id:1,offset:{x:0.433,y:-0.75},center:{x:0.866,y:-0.25}}
	         ]
	 }
	]
} 

//六角铺砖
PAVEMODEL.SINGLEPAVE_09 = {
	name:"SINGLEPAVE_09",
	//rotate:0,
	tiles: [
	 { id:1,   //切砖id,当铺贴nodes指定使用对应id时，先从切砖里面找对应的id,如果没有，默认使用1号切砖	 	 	   
	   profile:[{x:0.0,y:0.2},{x:0.2,y:0.0},{x:1,y:0},{x:1,y:0.8},{x:0.8,y:1.0},{x:0,y:1}],   //切砖路径,以切砖后的大小为单位
	   nodes:[{id:1,offset:{x:1,y:-0.2},center:{x:1.5,y:0.3}},        //各个方向的节点offset为偏移量，center为节点中心（用于检测是否存在已有节点)
	          {id:1,offset:{x:0.8,y:0.8},center:{x:1.3,y:1.3}},
	          {id:1,offset:{x:-0.2,y:1.0},center:{x:0.3,y:1.5}},
	          {id:1,offset:{x:-1,y:0.2},center:{x:-0.5,y:0.7}},
	          {id:1,offset:{x:-0.8,y:-0.8},center:{x:-0.3,y:-0.3}},
	          {id:1,offset:{x:0.2,y:-1.0},center:{x:0.7,y:-0.5}}
	         ]
	 }
	]
}