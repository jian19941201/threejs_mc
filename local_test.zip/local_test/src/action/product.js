function ActionAddProduct(mgr) {
    classBase(this, mgr), this.product = void 0, this.materialEntity = void 0, this.materialSide = void 0,
        this.materialBefore = void 0;
}
/*更新产品使用次数功能*/
function updateUsageCount(req){
    var servicePrefix = api.getServicePrefix("catalog");
    var url = servicePrefix + "/updateUsageCount";
    var pid = req.pid
    var param = {};
    param.pid = req.pid;
    api.getServiceJSONResponsePromise({
        type: 'post',
        url: url,
        cache: true,
        data: param
    }).then(function (res) {
        //TODO 将来可能需要/getUsageCount 获取点击数 2017.09.20
        window.swapUsagecount[pid]=req.usagecount*1>=swapUsagecount[pid]*1?req.usagecount*1 +1 : swapUsagecount[pid]*1+1 ;
    });
}

ActionAddProduct.prototype.type = "AddProduct";
classInherit(ActionAddProduct, ActionBase);
utilExtend(ActionAddProduct.prototype, {
    canUndoRedo: function () {
        return !0;
    },
    _materialUndoRedo: function () {
        var before = this.materialEntity[this.materialSide];
        this.materialEntity[this.materialSide] = this.materialBefore;
        this.materialBefore = before;
        if (this.materialEntity instanceof Floor) {
            utilModelChangeFlag(this.materialEntity, FLOORFLAG_CHANGED_FOR_REDRAWN);
        } else if (this.materialEntity instanceof Area) {
            utilModelChangeFlag(this.materialEntity, AREAFLAG_CHANGED_FOR_REDRAWN);
        }
    },
    undo: function () {
        if (this.product instanceof Material){
         this._materialUndoRedo(); 
        }else if (utilEntityRemoveLink(this.fp, this.product),
            this.product instanceof Opening) {
            var attached = this.product.attached;
            attached && attached.type == Wall.prototype.type && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
        }
    },
    redo: function () {
        if (this.product instanceof Material) {
            this._materialUndoRedo(); 
        }else if (utilEntityAddLink(this.fp, this.product),
            this.product instanceof Opening) {
            var attached = this.product.attached;
            attached && attached.type == Wall.prototype.type && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
        }
    },
    needViewportMouseMove: function () {
        return !0;
    },
    viewportMouseHitTypes: function () {
        return this.product && this.product instanceof Opening ? [Wall.prototype.type] : void 0;
    },
    /*自定义拼花 添加了类型"custom_tile",判断添加产品的类型，返回和执行带有参数的函数 add by oxl 2017-03-29
     * 自定义拼花添加到画布第一步 "custom_tile" == category;
     * */
    begin: function (productId, x, y, productMeta) {
        var allObjArrary = api.floorplanFilterEntity(function (e) {
            return (e.type == "PRODUCT" || e.type == 'PRODUCTREPLACEMENT' || e.type == "DOOR" || e.type == "WINDOW" || e.type == "PILLAR" || e.type == 'BEAM' || e.type == 'BASEMENT');
        });
        if (allObjArrary[0] == undefined) {
            globalModelIndex = 1;
        } else {
            globalModelIndex = getAllObjArraryLength() + 1;
        }
        __log("run this action: " + this.type + ", param=[" + x + ", " + y + "]");
        var productMeta = this.mgr.app.catalogMgr.productsMeta[productId] || productMeta;
        var category = productMeta && productMeta.category;
        var Class = Product;
        if("opening" == category){
        	  Class = Opening;
        }else if("door" == category){
        	  Class = Door;
        }else if("window" == category){
        	  Class = Windows;
        }else if("custom_tile" == category || "tile" == category){
        	  Class = Material;
        }else if("parquet" == category || category=='customparquet'){
        	  Class = Parquet;
        }else if("furniture_replacement" == category){
        	  Class = ProductReplacement;
        }else if("rawcolor" == category){
        	  Class = MaterialRawColor;
        }
        var product = this.product = new Class(productMeta);
        void 0 != x && isNumber(x) && (product.x = x);
        void 0 != y && isNumber(x) && (product.y = y);
        product instanceof Material || utilEntityAddLink(this.fp, product);
        return product;
    },
    end: function () {
        Flag = 1;        
        if (this.product instanceof Product) {
      	  if (this.product.x < -99 && this.product.y < -99){
	          return void utilEntityRemoveLink(this.fp, this.product);
	        }else{
            updateUsageCount(this.product);//更新热点
            var attached = this.product.attached;
            attached && attached.type == Wall.prototype.type && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
          }
        }else if(this.product instanceof Material){
        	  if(Object.keys(this.product.lt).length == 0){
        	  	return void utilEntityRemoveLink(this.fp, this.product), delete Root.prototype.database[this.product.id];
        	  }else{
        	  	updateUsageCount(this.product);//更新热点
        	  }
        }
    },
    run: function (cmd, evt, position, attachments, names) {
        if (1 == Flag) {
            globalModelIndex++;
            Flag = 0;
        }
        var cat = this.product.category;
        if (__log(cmd), "view2d_mousemove" == cmd) {
            if (this.product.x = position.x, this.product.y = position.y, this.product instanceof Opening) {
                var attached = attachments.reduce(function (previous, attachment) {
                    return previous || (attachment && attachment.type == Wall.prototype.type ? attachment : void 0);
                }, void 0);
                if (this.product.attached = attached, attached && attached.type == Wall.prototype.type && !attached.bezier) {
                    var pos = utilMathGetPerpendicularIntersect(position, attached.begin, attached.end);
                    this.product.x = pos.x, this.product.y = pos.y, this.product.rot = utilMathGetAngleHorizontaleCCW(attached.begin, attached.end);
                }
            }
        } else if ("view2d_mouseup" == cmd) {
            if (this.product instanceof Material) {
                /*2d 模式：如果是自定义拼花类型，添加附件是FLOOR时，不能继续后续操作 add by oxl 2017-04-15*/
                if (attachments[0] && (attachments[0].type == "FLOOR" || attachments[0].type == "BOUNDARY") && (cat == "custom_tile" ||cat == "customparquet") ) {
                    return
                }

                var painted = attachments.reduce(function (previous, attachment) {
                    return previous || (attachment && (attachment.type == Floor.prototype.type || attachment.type == Boundary.prototype.type || attachment instanceof Area) ? attachment : void 0);
                }, void 0);
                
                var floor = painted && painted.type == Floor.prototype.type ? painted : void 0;
                var area = painted && painted instanceof Area ? painted : void 0;
                var boundary = painted && Boundary.prototype.type ? painted : void 0;
                
                if(floor){ 
                	  this.materialSide   = names[0] == "" ? "floorMaterial" : names[0]+"Material";
                	  this.materialBefore = floor[this.materialSide];
                	  this.materialEntity = floor;
                    floor[this.materialSide] = this.product;
                }
                    
                if(area){                	 
                	  this.materialSide   = names[0] == "" ? "areaMaterial" : (names[0]+"Material");
                    this.materialBefore = area[this.materialSide];                   
                    this.materialEntity = area;
                    area[this.materialSide] = this.product;
                }
                    
                if(boundary){
                	  this.materialEntity = boundary;
                	  var name_index = names[0].split("_");
                	  if(name_index[0] == "corner"){
                	  	  this.materialBefore = boundary.cornerMaterial;                	  	  
                	  	  this.materialSide = "cornerMaterial";
                	  	  boundary.cornerMaterial = this.product;
                	  }else if(name_index[0] == "base"){
                	  	  this.materialBefore = boundary.baseMaterial;
                	  	  this.materialSide = "baseMaterial";
                	  	  boundary.baseMaterial = this.product;
                	  }else if(name_index[0] == "left"){
                	  	  this.materialBefore = boundary.leftMaterial;
                	  	  this.materialSide = "leftMaterial";
                	  	  boundary.leftMaterial = this.product;
                	  }else if(name_index[0] == "right"){
                	  	  this.materialBefore = boundary.rightMaterial;
                	  	  this.materialSide = "rightMaterial";
                	  	  boundary.rightMaterial = this.product;
                	  }
                }
            }
            utilActionEnd(this.mgr);
        } else if ("click3d" == cmd) {
            if (this.product instanceof Material) {
                /*3d模式点击时绑定产品数据到 model 判断model的类型是不是如下3样，不是则走回正常流程 -step1
                 *  add by oxl 2017-04-17*/
                var normalPlace = ["FLOOR", "WALL", "PRODUCTREPLACEMENT"];
                var modelType = position.model.type;
                if (position && ( modelType && normalPlace.indexOf(modelType) >= 0 ? 1 : 0 ) && (cat == "custom_tile" || cat == "customparquet")) {
                    return;
                }

                var pickedResult = position;
                if (pickedResult) {
                    var model = pickedResult.model;
                    this.materialEntity = model;
                    var side = pickedResult.opt && pickedResult.opt.elementName;
                    /*TODO 3d模式点击时绑定产品数据到 model，实际调用这里的数据在别处（如 DisplayThreeWall DisplayThreeFloor DisplayThreeProductReplacement）-step2
                     *  具体流程有时间再跟踪 例如 墙体：model.rightMaterial = this.product；地板：model.floorMaterial = this.product；区域：model.areaMaterial = this.product
                     *  add by oxl 2017-04-17*/
                    if (model.type == Wall.prototype.type && side) {
                    	  if ("stone" == side) {
                    	  	  this.materialSide = side + "Material";
                            this.materialBefore = model[this.materialSide];
                            model.stoneMaterial = this.product;
                        }else{
                        	  utilActionEnd(this.mgr);

		                        utilActionBegin(this.mgr, "AddWallboard",[{pid:this.product.meta.pid,height:1}]);
		                        var smoothStart = utilModelWallGetSmoothStart(model, side);
		                        utilActionRun(this.mgr, "click3d", null, {model:smoothStart.wall, opt:{elementName:smoothStart.side}});
                        }
                    } else if (model.type == Floor.prototype.type) {
                        this.materialSide = side + "Material";
                        this.materialBefore = model[this.materialSide];
                        if ("ceiling" == side) {
                            model.ceilingMaterial = this.product;
                        } else {
                            model[this.materialSide] = this.product;
                        }
                    } else if (model instanceof Area) {
                        if(side == "root"){
                          side = "area";
                        }
                          
                        if(side == "area"){
                        	this.materialSide = side + "Material";
	                        this.materialBefore = model[this.materialSide];
	                        model[this.materialSide] = this.product;
	                      }else if(side.indexOf("pave") != -1){
	                      	this.materialSide = side + "Material";
	                        this.materialBefore = model[this.materialSide];
	                        model[this.materialSide] = this.product;
                        }else if(side.indexOf("side") != -1){
                        	//sideX 侧面墙
                        	utilActionEnd(this.mgr);

	                        utilActionBegin(this.mgr, "AddWallboard",[{pid:this.product.meta.pid, height:1}]);
	                        var smoothStart = utilModelWallGetSmoothStart(model, side);
	                        utilActionRun(this.mgr, "click3d", null, {model:smoothStart.wall, opt:{elementName:smoothStart.side}});
                        }
                    } else if (model instanceof Cube) {
                        this.materialSide = side + "Material";
                        this.materialBefore = model[this.materialSide];
                        model[side + "Material"] = this.product;
                    } else if (model.type == ProductReplacement.prototype.type) {
                        this.materialSide = side + "Material";
                        this.materialBefore = model[this.materialSide];
                        model[side + "Material"] = this.product;
                    } else if (model.type == Boundary.prototype.type) {
                    	  if(side.indexOf("corner") != -1){
                    	  	  this.materialSide = "cornerMaterial";
		                        this.materialBefore = model[this.materialSide];
		                        model.cornerMaterial = this.product;
                    	  }else if(side.indexOf("base") != -1){
                    	  	  this.materialSide = "baseMaterial";
		                        this.materialBefore = model[this.materialSide];
		                        model.baseMaterial = this.product;
                    	  }else if(side.indexOf("left") != -1){
                    	  	  this.materialSide = "leftMaterial";
		                        this.materialBefore = model[this.materialSide];
		                        model.leftMaterial = this.product;
                    	  }else if(side.indexOf("right") != -1){
                    	  	  this.materialSide = "rightMaterial";
		                        this.materialBefore = model[this.materialSide];
		                        model.rightMaterial = this.product;
                    	  }
                        
                    }
                }
            }
            utilActionEnd(this.mgr);
        } else "mouseup3d" == cmd || ("mousemove3d" == cmd ? this.product instanceof Opening || this.product instanceof Product : "keydown" == cmd && "ESC" == position && utilEntityRemoveLink(this.fp, this.product));
    }
})


function ActionMoveProduct(mgr) {
    classBase(this, mgr), this.copiedProduct = void 0, this.product = void 0, this.attachments = [];
}

ActionMoveProduct.prototype.type = "MoveProduct", classInherit(ActionMoveProduct, ActionBase),
utilExtend(ActionMoveProduct.prototype, {
    canUndoRedo: function () {
        return !0;
    },
    undo: function () {
        classBase(this, "undo"), this.copiedProduct && utilEntityRemoveLink(this.fp, this.copiedProduct),
            this.savedForRedo = this.product.save(), this.product.load(this.savedForUndo);
    },
    redo: function () {
        classBase(this, "redo"), this.copiedProduct && utilEntityAddLink(this.fp, this.copiedProduct),
            this.product.load(this.savedForRedo);
    },
    begin: function (product, opt) {
        if (opt && opt.shiftKey === !0) {
            var productMeta = this.mgr.app.catalogMgr.productsMeta[product.pid], Class = TYPE[product.type], copied = this.copiedProduct = new Class(productMeta);
            utilEntityAddLink(this.fp, copied), copied.copy(product), copied.x += 0;
        }
        this.product = product, this.savedForUndo = this.product.save();
    },
    end: function () {
        this.attachments.forEach(function (attached) {
            attached && this.product instanceof Opening && attached instanceof Wall && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
        }, this);
    },
    run: function (cmd, event, position, attached) {
        if ("mousemove3d_transformctrl" == cmd || "mousemove2d" == cmd) {
            var oldX = this.product.x;
            var oldY = this.product.y;
            var oldZ = this.product.z;
            var productId = this.product.id;
            attached instanceof ModelObject || (attached = void 0);
            this.product.attached instanceof ModelObject || (this.product.attached = void 0);
            this.product.x = position.x;
            this.product.y = position.y;
            if (this.product.group) {
                var products = utilGroupGetAllLeafChildren(this.product.group);
                var zMinDiffer = products[0].z;
                products.forEach(function (child) {
                    zMinDiffer = zMinDiffer < child.z ? zMinDiffer : child.z;
                })
                if (zMinDiffer <= 0 && (position.z < oldZ)) {
                    return
                }
            }

            //添加天花吸咐功能--add by gaoning 2017.12.8
            if(this.product.meta.subcategory == "ceiling"){
                event && event.altKey === !1 && this.product.boundSnap();
            }

            var host = this.product.attached || utilProductFindHostRoom(this.fp, this.product);
            if (position.z && (this.product.z = Math.min((host ? host.height3d : 10) - this.product.meta.zlen * this.product.sz, Math.max(0, position.z))), isNaN(this.product.z) && (this.product.z = position.z), "mousemove3d_transformctrl" == cmd) {
                //add by gaonin 添加3D视图下产品组的操作--add by gaoning
                if (this.product.group) {
                    var positionZ = Math.min((host ? host.height3d : 10) - this.product.meta.zlen * this.product.sz, Math.max(0, position.z))
                    var leafItems = utilGroupGetAllLeafChildren(this.product.group);
                    if ((zMinDiffer += positionZ - oldZ) < 0)this.product.z -= zMinDiffer, positionZ -= zMinDiffer;
                    leafItems.forEach(function (child) {
                        if (productId != child.id) {
                            child.x += position.x - oldX;
                            child.y += position.y - oldY;
                            child.z += positionZ - oldZ;
                            if (child.z < 0)child.z = 0;
                            if (position.z >= 0 && child.z <= position.z) {
                                //child.z += position.z - oldZ;
                            }

                        }
                    });
                    this.product.group.x+=position.x - oldX
                    this.product.group.y+=position.y - oldY;
                }
                return;
            }

            if (this.product.attached = attached, attached && (-1 == this.attachments.indexOf(attached) && this.attachments.push(attached), attached.type == Wall.prototype.type && !attached.bezier)) {
                var pos = utilMathGetPerpendicularIntersect(position, attached.begin, attached.end);
                this.product.x = pos.x;
                this.product.y = pos.y;
                this.product.rot = utilMathGetAngleHorizontaleCCW(attached.begin, attached.end);
            }
            this.product.group && utilModelChangeFlag(this.product.group, GROUPFLAG_VIEW_UPDATE);
        }
        if ("mouseup3d_transformctrl" == cmd) {
            __log("mouseup");
            var attached = this.product.attached;
            attached && this.product instanceof Opening && attached instanceof Wall && utilModelSetFlagOn(attached, WALLFLAG_DETAILEDUPDATED_3D);
        }
    }
})

//直接替换砖
function ActionChangeProduct(mgr) {
	  classBase(this, mgr);
}
ActionChangeProduct.prototype.type = "ChangeProduct";
classInherit(ActionChangeProduct, ActionBase);
utilExtend(ActionChangeProduct.prototype, {
	begin: function (model, meta, materialName) {
        var category = meta && meta.category;
        var Class = Material;
        if("custom_tile" == category || "tile" == category){
            Class = Material;
        }else if("parquet" == category || category=='customparquet'){
            Class = Parquet;
        }
        this.model=model[materialName] && (model[materialName] = new Class(meta));
	},
	end: function (){
        utilModelChangeFlag(this.model, FLOORFLAG_CHANGED_FOR_REDRAWN);
	},
    run: function (){
    }
});



// sourceURL=src\action\product.js