function ActionMovePoint(mgr) {
    classBase(this, mgr), this.point = void 0, this.points = [], this.walls = [], this.curves = [],
        this.areas = [];
}
ActionMovePoint.prototype.type = "MovePoint";
classInherit(ActionMovePoint, ActionBase);
utilExtend(ActionMovePoint.prototype, {
    isEnable: function () {
        return utilModelIsFlagOff(this.fp, MODELFLAG_LOCKED);
    },
    begin: function (model) {
        this.point = model;
        this.points.push(this.point);
        utilFloorplanForEachPoint(this.fp, function (pt, wall) {
            utilMathIsSamePoint(pt, this.point, .1) && (-1 == this.points.indexOf(pt) && this.points.push(pt),
            wall.type == Curve.prototype.type && -1 == this.curves.indexOf(wall) && (this.curves.push(wall),
                utilFloorplanForEachArea(this.fp, function (area) {
                    area.profile && -1 != area.profile.indexOf(wall) && -1 == this.areas.indexOf(area) && this.areas.push(area);
                }, this)), wall.type == Wall.prototype.type && -1 == this.walls.indexOf(wall) && this.walls.push(wall));
        }, this);
    },
    end: function () {
        utilFloorplanForEachWall(this.fp, function (w) {
            utilMathIsSamePoint(w.begin, w.end) && utilEntityRemoveLink(this.fp, w);
        }, this);
        utilFloorplanRebuildFloor(this.fp);
        utilFloorplanForEachWall(this.fp, function (w) {
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D);
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
        });
        utilFloorplanUpdateWallArea(this.fp);
    },
    run: function (cmd, event, position) {
        //__log("run this action: " + this.type + ", position=[" + position.x + ", " + position.y + "]"),
        //    "mousemove" == cmd || "touchmove" == cmd ? (this.points.forEach(function (pt) {
        //        pt.x = position.x, pt.y = position.y;
        //    }), this.walls.forEach(function (w) {
        //        utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_3D);
        //    }, this), this.areas.forEach(function (area) {
        //        utilModelChangeFlag(area, AREAFLAG_CHANGED_FOR_REDRAWN);
        //    })) : "mouseup" == cmd && utilActionEnd(this.mgr, this.type);

        //console.log(event.which);
        if (event.which == 1 ) {  //只让鼠标左键拖动  1:左键  2：中键 3：右键
            __log("run this action: " + this.type + ", position=[" + position.x + ", " + position.y + "]");
            //"mousemove" == cmd || "touchmove" == cmd ? (this.points.forEach(function (pt) {
            //    pt.x = position.x, pt.y = position.y;
            //}), this.walls.forEach(function (w) {
            //    utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_3D);
            //}, this), this.areas.forEach(function (area) {
            //    utilModelChangeFlag(area, AREAFLAG_CHANGED_FOR_REDRAWN);
            //})) : "mouseup" == cmd && utilActionEnd(this.mgr, this.type);

            if("mousemove" == cmd || "touchmove" == cmd ){
                this.points.forEach(function (pt) {
                    pt.x = position.x, pt.y = position.y;
                });
                this.walls.forEach(function (w) {
                    utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_2D);
                    utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_3D);
                }, this);
                this.areas.forEach(function (area) {
                    utilModelChangeFlag(area, AREAFLAG_CHANGED_FOR_REDRAWN);
                });
            }else{
                "mouseup" == cmd && utilActionEnd(this.mgr, this.type);
            }
        }else{
            utilActionEnd(this.mgr, this.type);
        }
    }
})

//贝塞尔控制点
function ActionMoveBezierPoint(mgr) {
    classBase(this, mgr), this.point = void 0, this.points = [], this.walls = [], this.curves = [],
        this.areas = [];
}
ActionMoveBezierPoint.prototype.type = "MoveBezierPoint";
classInherit(ActionMoveBezierPoint, ActionBase);
utilExtend(ActionMoveBezierPoint.prototype, {
    isEnable: function () {
        return utilModelIsFlagOff(this.fp, MODELFLAG_LOCKED);
    },
    begin: function (model) {
        this.point = model;
        for(var i in this.point.lt){
        	this.wall = this.point.lt[i];
        	break;
        }
        this.walls.push(this.wall);
    },
    end: function () {
        utilFloorplanRebuildFloor(this.fp);
        utilFloorplanForEachWall(this.fp, function (w) {
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D);
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
        });
        utilFloorplanUpdateWallArea(this.fp);
    },
    run: function (cmd, event, position) {
        //__log("run this action: " + this.type + ", position=[" + position.x + ", " + position.y + "]"),
            "mousemove" == cmd || "touchmove" == cmd ? ((this.point.x = position.x, this.point.y = position.y
            ), this.walls.forEach(function (w) {
                utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_2D);
                utilModelSetFlagOff(w, WALLFLAG_DETAILEDUPDATED_3D);
            }, this),
                this.areas.forEach(function (area) {
                utilModelChangeFlag(area, AREAFLAG_CHANGED_FOR_REDRAWN);
            })) : "mouseup" == cmd && utilActionEnd(this.mgr, this.type);
    }
})