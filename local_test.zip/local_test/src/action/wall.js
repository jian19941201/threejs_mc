/*TYPE对象集合看到以下这部分*/
function ActionAddWall(mgr) {
    classBase(this, mgr);
    this.lastPoint = void 0;
    this.model = void 0;
    this.opt = void 0;
    this.mouseMoveEvt = new Signal();
}

ActionAddWall.prototype.type = "AddWall";
classInherit(ActionAddWall, ActionBase);
utilExtend(ActionAddWall.prototype, {
    _updateFloorAndWallCorner: function () {
        utilFloorplanRebuildFloor(this.fp);
        utilAppFloorplanMakeNormalized(application);
        utilFloorplanUpdateWallArea(this.fp);
    },
    isEnable: function () {
        return utilModelIsFlagOff(this.fp, MODELFLAG_LOCKED);
    },
    begin: function (opt) {
        this.opt = opt || {}, this.lastPoint = this.opt.last ? this.opt.last : void 0;
        var wall = new Wall();
        utilEntityAddLink(this.fp, wall);
        this.model = wall;
        var end = new Point();
        wall.end = end;
        //var bezier = new BezierPoint();
        //wall.bezier = bezier;

        if (this.lastPoint) {
            var begin = new Point();
            wall.begin = begin;
            begin.x = this.lastPoint.x;
            begin.y = this.lastPoint.y;
        }
    },
    end: function () {
        this.model && (!this.model.begin || !this.model.end || utilMathLineLength(this.model.begin, this.model.end) < .05) && utilEntityRemoveLink(this.fp, this.model);
    },
    run: function (cmd, evt, modelPos) {
        if (__log(cmd), "mousemove" == cmd) {
            if (!this.model.begin)
                return;
            var end = this.model.end;
            end.x = modelPos.x;
            end.y = modelPos.y;

            //测试
            //var bezier = this.model.bezier;
            //bezier.x = (end.x + this.model.begin.x)/2;
            //bezier.y = (end.y + this.model.begin.y)/2;

            this.mouseMoveEvt.dispatch(cmd, evt);
        } else if ("click" == cmd || "setLength" == cmd) {
            if ("setLength" == cmd) {
                var length = modelPos;
                if (this.model.end) {
                    var newEndPt = utilMathGetScaledPoint(this.model.begin, this.model.end, length);
                    this.model.end.x = newEndPt.x, this.model.end.y = newEndPt.y;
                }
            }
            if (1 == evt.button)
                return;
            if (void 0 != this.model.begin) {
                utilActionEnd(this.mgr);
                var last = this.model.end, snap = last ? utilWallGetSnapPt(this.fp, last, [this.model]) : void 0;
                if (snap) {
                    var snapPt = snap.point;
                    this.end.x = snapPt.x;
                    this.end.y = snapPt.y;
                    last = void 0;
                }
                if (void 0 == last && (this._updateFloorAndWallCorner(), this.opt.continuous === !1))
                    return;
                utilActionBegin(this.mgr, this.type, {
                    continuous: this.opt.continuous,
                    last: last
                });
            } else {
                var begin = new Point();
                this.model.begin = begin;
                modelPos.x && (begin.x = modelPos.x);
                modelPos.y && (begin.y = modelPos.y);
            }
        } else {
            if ("ESC" == cmd || "keydown" == cmd && 27 == evt.keyCode || "mouseup" == cmd && 2 == evt.button) {
                utilEntityRemoveLink(this.fp, this.model);
                utilActionEnd(this.mgr);
                this._updateFloorAndWallCorner();
                void 0 != this.lastPoint && utilActionBegin(this.mgr, this.type);
                return !0;
            }

            if ("keydown" == cmd && 115 == evt.keyCode) {
                utilF4KeyDown(evt);
            }
            else if ("exit" == cmd) {
                utilActionEnd(this.mgr);
            }
            else if ("scale" == cmd) {
                var factor = arguments[1];
                var others = arguments[2];
                var begin = this.model.begin;
                var end = this.model.end;
                begin && (begin.x *= factor, begin.y *= factor);
                end && (end.x *= factor, end.y *= factor);
                Array.isArray(others) && others.forEach(function (other) {
                    if (other.type == Wall.prototype.type) {
                        var begin = other.begin;
                        var end = other.end;
                        begin && (begin.x *= factor, begin.y *= factor);
                        end && (end.x *= factor, end.y *= factor);
                    }
                });
            }
        }
    }
})

function ActionMoveWall(mgr) {
    classBase(this, mgr), this.wall = void 0, this.dir = void 0, this.orig = {}, this.origBegin = {}, this.origEnd = {};
    this.beginWall = [], this.endWall = [];
    this.AddBeginWall = void 0;
    this.AddBeginWallBegin = void 0, this.AddBeginWallEnd = void 0;
    this.AddEndWall = void 0;
    this.AddEndWallBegin = void 0, this.AddEndWallEnd = void 0;
    this.wallBreakFlag = false;
    this.wallLen = void 0;
    this.origBeginPoint = {}, this.origEndPoint = {};
}

ActionMoveWall.prototype.type = "MoveWall";
classInherit(ActionMoveWall, ActionBase);
utilExtend(ActionMoveWall.prototype, {
    isEnable: function () {
        return utilModelIsFlagOff(this.fp, MODELFLAG_LOCKED);
    },
    begin: function (wall) {
        this.wall = wall;
        var tol = .1;
        var begin = this.wall.begin;
        var end = this.wall.end;
        this.orig[begin.id] = {
            x: begin.x,
            y: begin.y
        };
        this.orig[end.id] = {
            x: end.x,
            y: end.y
        }
        this.dir = new Vec2(end.y - begin.y, begin.x - end.x).normalize();
        utilModelWallGetAttached(this.fp, this.wall, Opening).forEach(function (opening) {
            this.orig[opening.id] = {
                x: opening.x,
                y: opening.y
            };
        }, this);
        utilFloorplanForEachWall(this.fp, function (wall) {
            if (wall.id != this.wall.id) {
                if (utilMathIsSamePoint(wall.end, begin, tol)) {
                    this.beginWall.push(wall)
                }
                if (utilMathIsSamePoint(wall.end, end, tol)) {
                    this.endWall.push(wall)
                }
                if (utilMathIsSamePoint(wall.begin, end, tol)) {
                    this.endWall.push(wall)
                }
                if (utilMathIsSamePoint(wall.begin, begin, tol)) {
                    this.beginWall.push(wall)
                }
            }
        }, this)
        utilFloorplanForEachPoint(this.fp, function (pt, wall) {
            if (pt.id != begin.id && pt.id != end.id) {
                if (utilMathIsSamePoint(pt, begin, tol)) {
                    this.origBegin[pt.id] = {
                        x: pt.x,
                        y: pt.y
                    };
                    this.origBeginPoint[pt.id] = pt;
                } else if (utilMathIsSamePoint(pt, end, tol)) {
                    this.origEnd[pt.id] = {
                        x: pt.x,
                        y: pt.y
                    };
                    this.origEndPoint[pt.id] = pt;
                } else if (utilMathIsPointInLineSegment(pt, begin, end, tol)) {
                    this.orig[pt.id] = {
                        x: pt.x,
                        y: pt.y
                    };
                }
            }
        }, this);
    },
    end: function () {

        utilFloorplanForEachWall(this.fp, function (w) {
            var len = new Line(w.begin.x,w.begin.y, w.end.x, w.end.y).length();
            if(len<0.09){
                utilEntityRemoveLink(this.fp, w)
            }else{
                utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
            }

        });
        utilFloorplanRebuildFloor(this.fp);
        utilFloorplanUpdateWallArea(this.fp);
        //utilFloorplanForEachWall(this.fp, function (wall) {console.log(new Line(wall.begin.x,wall.begin.y, wall.end.x, wall.end.y).length()+",,,begin="+wall.begin.x+','+wall.begin.y+",,,end="+wall.end.x+','+wall.end.y)},this)

        utilAppFloorplanMakeNormalized(application)
    },
    run: function (cmd, event, offset) {
        if ("dragmove" == cmd || "touchmove" == cmd) {
            if (event.buttons && event.buttons != 1) {
                return;
            }

            var db = this.wall.database;
            var offset = offset;
            var moveAmount = Vec2.dot(offset, this.dir);
            offset = utilMathGetScaledPoint({x: 0, y: 0}, this.dir, moveAmount);

            var end = this.wall.end;
            var begin = this.wall.begin;

            this.wallLen = new Line(this.wall.begin.x, this.wall.begin.y, this.wall.end.x, this.wall.end.y).length();

            function getPointForPointToLine(point, line) {
                var P = {};
                if (line.x0 - line.x1 == 0) {
                    P.x = line.x0;
                    P.y = point.y;
                } else {
                    var A = (line.y0 - line.y1) / (line.x0 - line.x1)
                    var B = line.y0 - A * line.x0
                    var m = point.x + A * point.y

                    P.x = (m - A * B) / (A * A + 1)
                    P.y = A * P.x + B
                }
                return P
            }

            function getDistanceForPointToLine(point, line) {
                var len;
                if (line.x0 - line.x1 == 0) {
                    len = Math.abs(point.x - line.x0)
                } else {
                    var A = (line.y0 - line.y1) / (line.x0 - line.x1)
                    var B = line.y0 - A * line.x0

                    len = Math.abs((A * point.x + B - point.y) / Math.sqrt(A * A + 1))
                }
                return len
            }

            function isPointInSegments(point, line) {
                return ((point.x - line.x0) * (point.x - line.x1) <= 1e-5 && (point.y - line.y0) * (point.y - line.y1) <= 1e-10)
            }

            var moveAfterBeginPoint = {
                x: this.orig[this.wall.begin.id].x + offset.x,
                y: this.orig[this.wall.begin.id].y + offset.y
            }
            var moveAfterEndPoint = {
                x: this.orig[this.wall.end.id].x + offset.x,
                y: this.orig[this.wall.end.id].y + offset.y
            }
            var DistanceBegin = []
            var isDistanceBegin = []
            var isDistanceEnd = []
            var PointBegin = []
            var DistanceEnd = []
            var PointEnd = []
            var isBegin = [];
            var isBeginIndex = [];
            var isEnd = [];
            var isEndIndex = [];
            var endIndex = 0;
            var beginIndex = 0;
            var tol = .2


            for (var i = 0; i < this.beginWall.length; i++) {
                PointBegin[i] = linesIntr(
                    moveAfterBeginPoint,
                    moveAfterEndPoint,
                    {x: this.beginWall[i].begin.x, y: this.beginWall[i].begin.y},
                    {x: this.beginWall[i].end.x, y: this.beginWall[i].end.y}
                )
                if (PointBegin[i]) {
                    var line = new Line(PointBegin[i].x, PointBegin[i].y, moveAfterEndPoint.x, moveAfterEndPoint.y)
                    DistanceBegin[i] = line.length();

                    isBegin[i] = isPointInSegments(PointBegin[i], {
                        x0: this.beginWall[i].begin.x,
                        y0: this.beginWall[i].begin.y,
                        x1: this.beginWall[i].end.x,
                        y1: this.beginWall[i].end.y
                    })

                } else {
                    var line = new Line(moveAfterBeginPoint.x, moveAfterBeginPoint.y, moveAfterEndPoint.x, moveAfterEndPoint.y)
                    DistanceBegin[i] = line.length();
                    isBegin[i] = 0;
                }
                isBegin[i] && (isBeginIndex[isBeginIndex.length] = i, isDistanceBegin[isBeginIndex.length] = DistanceBegin[i] );
            }

            for (var i = 0; i < this.endWall.length; i++) {
                PointEnd[i] = linesIntr(
                    moveAfterBeginPoint,
                    moveAfterEndPoint,
                    {x: this.endWall[i].begin.x, y: this.endWall[i].begin.y},
                    {x: this.endWall[i].end.x, y: this.endWall[i].end.y}
                )
                if (PointEnd[i]) {
                    var line = new Line(PointEnd[i].x, PointEnd[i].y, moveAfterBeginPoint.x, moveAfterBeginPoint.y)
                    DistanceEnd[i] = line.length();
                    isEnd[i] = isPointInSegments(PointEnd[i], {
                        x0: this.endWall[i].begin.x,
                        y0: this.endWall[i].begin.y,
                        x1: this.endWall[i].end.x,
                        y1: this.endWall[i].end.y
                    })
                } else {
                    var line = new Line(moveAfterBeginPoint.x, moveAfterBeginPoint.y, moveAfterEndPoint.x, moveAfterEndPoint.y)
                    DistanceEnd[i] = line.length();
                    isEnd[i] = 0;
                }
                isEnd[i] && (isEndIndex[isEndIndex.length] = i, isDistanceEnd[isDistanceEnd.length] = DistanceEnd[i]);
            }
            if (isBeginIndex.length == 0) {
                beginIndex = DistanceBegin.indexOf(DistanceBegin.sort()[0])
            } else if (isBeginIndex.length == 1) {
                beginIndex = isBeginIndex[0]
            } else {
                beginIndex = DistanceBegin.indexOf(isDistanceBegin.sort()[0])
            }
            if (isEndIndex.length == 0) {
                endIndex = DistanceEnd.indexOf(DistanceEnd.sort()[0])
            } else if (isEndIndex.length == 1) {
                endIndex = isEndIndex[0]
            } else {
                endIndex = DistanceEnd.indexOf(isDistanceEnd.sort()[0])

            }
            var beginCross = PointBegin[beginIndex]
            var endCross = PointEnd[endIndex]
            var czBeginFlag = isBegin[beginIndex] == 0 && this.beginWall.length > 1 ? 0 : 1;
            var czEndFlag = isEnd[endIndex] == 0 && this.endWall.length > 1 ? 0 : 1;
            var moveWallLen = 0;
            var moveWallBegin = beginCross || {
                    x: this.orig[this.wall.begin.id].x + offset.x,
                    y: this.orig[this.wall.begin.id].y + offset.y
                };
            var moveWallEnd = endCross || {
                    x: this.orig[this.wall.end.id].x + offset.x,
                    y: this.orig[this.wall.end.id].y + offset.y
                };
            moveWallLen = new Line(moveWallBegin.x, moveWallBegin.y, moveWallEnd.x, moveWallEnd.y).length();
            if (this.wallLen < 0.5 && moveWallLen < this.wallLen)return;
            function endInit(obj){
                obj.origEnd = [];
                obj.origEndPoint = [];
                utilFloorplanForEachPoint(obj.fp, function (pt, wall) {
                    if (pt.id != begin.id && pt.id != end.id) {
                        if (utilMathIsSamePoint(pt, end, tol)) {
                            this.origEnd[pt.id] = {
                                x: pt.x,
                                y: pt.y
                            };
                            this.origEndPoint[pt.id] = pt;
                        } else if (utilMathIsPointInLineSegment(pt, begin, end, tol)) {
                            this.orig[pt.id] = {
                                x: pt.x,
                                y: pt.y
                            };
                        }
                    }
                }, obj);
                obj.endWall=[];
                utilFloorplanForEachWall(obj.fp, function (wall) {
                    if (wall.id != this.wall.id) {
                        if (utilMathIsSamePoint(wall.end, end, tol)) {
                            this.endWall.push(wall)
                        }
                        if (utilMathIsSamePoint(wall.begin, end, tol)) {
                            this.endWall.push(wall)
                        }
                    }
                }, obj)
            }
            function beginInit(obj){
                obj.origBegin = [];
                obj.origBeginPoint = [];
                utilFloorplanForEachPoint(obj.fp, function (pt, wall) {
                    if (pt.id != begin.id && pt.id != end.id) {
                        if (utilMathIsSamePoint(pt, begin, tol)) {
                            this.origBegin[pt.id] = {
                                x: pt.x,
                                y: pt.y
                            };
                            this.origBeginPoint[pt.id] = pt;
                        } else if (utilMathIsPointInLineSegment(pt, begin, end, tol)) {
                            this.orig[pt.id] = {
                                x: pt.x,
                                y: pt.y
                            };
                        }
                    }
                }, obj);
                obj.beginWall=[];
                utilFloorplanForEachWall(obj.fp, function (wall) {
                    if (wall.id != this.wall.id) {
                        if (utilMathIsSamePoint(wall.end, begin, tol)) {
                            this.beginWall.push(wall)
                        }
                        if (utilMathIsSamePoint(wall.begin, begin, tol)) {
                            this.beginWall.push(wall)
                        }
                    }
                }, obj)
            }

            if (endCross && endCross.x < 100 && endCross.x > -100 && czEndFlag) {
                var cross = void  0;
                db[this.wall.end.id].x = endCross.x;
                db[this.wall.end.id].y = endCross.y;
                this.endWall.length == 2 && (cross = linesIntr(
                    {
                        x: this.endWall[1].begin.x,
                        y: this.endWall[1].begin.y,
                    }, {
                        x: this.endWall[1].end.x,
                        y: this.endWall[1].end.y
                    },
                    {
                        x: this.endWall[0].begin.x,
                        y: this.endWall[0].begin.y,
                    }, {
                        x: this.endWall[0].end.x,
                        y: this.endWall[0].end.y
                    }
                ))
                if (this.endWall.length == 1 || (this.endWall.length == 2 && (!cross || (cross.x > 100 || cross.x < -100)))) {
                    for (var id in this.origEnd) {
                        if (db[id])
                            db[id].x = end.x, db[id].y = end.y;
                    }
                    if (this.endWall.length == 1) {
                        var Len1 = new Line(end.x, end.y, this.endWall[0].end.x, this.endWall[0].end.y).length();
                        var Len2 = new Line(end.x, end.y, this.endWall[0].begin.x, this.endWall[0].begin.y).length();
                        if (Len1 != 0 && Len1 < tol) {
                            db[this.wall.end.id].x = this.endWall[0].end.x;
                            db[this.wall.end.id].y = this.endWall[0].end.y;
                            for (var id in this.origEnd) {
                                if(db[id]){
                                    db[id].x = this.endWall[0].end.x, db[id].y = this.endWall[0].end.y;
                                    utilEntityRemoveLink(this.fp, this.origEndPoint[id]);
                                }

                            }
                            utilEntityRemoveLink(this.fp, this.endWall[0]);
                            endInit(this)

                        }
                        if (Len2 != 0 && Len2 < tol) {
                            db[this.wall.end.id].x = this.endWall[0].begin.x;
                            db[this.wall.end.id].y = this.endWall[0].begin.y;
                            for (var id in this.origEnd) {
                                if (db[id]){
                                    db[id].x = this.endWall[0].begin.x, db[id].y = this.endWall[0].begin.y;
                                    utilEntityRemoveLink(this.fp, this.origEndPoint[id]);
                                }

                            }
                            utilEntityRemoveLink(this.fp, this.endWall[0]);
                            endInit(this)
                        }
                    }
                    if (this.endWall.length == 2) {
                        var Len1 = new Line(end.x, end.y, this.endWall[0].end.x, this.endWall[0].end.y).length();
                        var Len2 = new Line(end.x, end.y, this.endWall[0].begin.x, this.endWall[0].begin.y).length();
                        var Len3 = new Line(end.x, end.y, this.endWall[1].end.x, this.endWall[1].end.y).length();
                        var Len4 = new Line(end.x, end.y, this.endWall[1].begin.x, this.endWall[1].begin.y).length();
                        if (Len1 != 0 && Len1 < tol) {
                            db[this.wall.end.id].x = this.endWall[0].end.x;
                            db[this.wall.end.id].y = this.endWall[0].end.y;
                            this.endWall[1].end.x = this.endWall[0].end.x;
                            this.endWall[1].end.y = this.endWall[0].end.y;
                            for (var id in this.origEnd) {
                                if (db[id]) {
                                    db[id].x = this.endWall[0].end.x, db[id].y = this.endWall[0].end.y;
                                    utilEntityRemoveLink(this.fp, this.origEndPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.endWall[0]);
                            endInit(this)
                        }
                        if (Len2 != 0 && Len2 < tol) {
                            db[this.wall.end.id].x = this.endWall[0].begin.x;
                            db[this.wall.end.id].y = this.endWall[0].begin.y;
                            this.endWall[1].begin.x = this.endWall[0].begin.x;
                            this.endWall[1].begin.y = this.endWall[0].begin.y;
                            for (var id in this.origEnd) {
                                if (db[id]) {
                                    db[id].x = this.endWall[0].begin.x, db[id].y = this.endWall[0].begin.y;
                                    utilEntityRemoveLink(this.fp, this.origEndPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.endWall[0]);
                            endInit(this)
                        }

                        if (Len3 != 0 && Len3 < tol) {
                            db[this.wall.end.id].x = this.endWall[1].end.x;
                            db[this.wall.end.id].y = this.endWall[1].end.y;
                            this.endWall[0].end.x = this.endWall[1].end.x;
                            this.endWall[0].end.y = this.endWall[1].end.y;
                            for (var id in this.origEnd) {
                                if (db[id]) {
                                    db[id].x = this.endWall[1].end.x, db[id].y = this.endWall[1].end.y;
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.endWall[1]);
                            endInit(this)

                        }
                        if (Len4 != 0 && Len4 < tol) {
                            db[this.wall.end.id].x = this.endWall[1].begin.x;
                            db[this.wall.end.id].y = this.endWall[1].begin.y;
                            this.endWall[0].begin.x = this.endWall[1].begin.x;
                            this.endWall[0].begin.y = this.endWall[1].begin.y;
                            for (var id in this.origEnd) {
                                if (db[id]) {
                                    db[id].x = this.endWall[1].begin.x, db[id].y = this.endWall[1].begin.y;
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.endWall[1]);
                            endInit(this)
                        }

                    }

                } else {
                    var Len = new Line(end.x, end.y, this.endWall[endIndex].end.x, this.endWall[endIndex].end.y).length();
                    var Len1 = new Line(end.x, end.y, this.endWall[endIndex].begin.x, this.endWall[endIndex].begin.y).length();
                    if(Len>.5&&Len1>.5){
                        var lerpNumber = utilMathGetLerpNumber(this.endWall[endIndex].begin, this.endWall[endIndex].end, {x:end.x,y:end.y});
                        utilWallBreak(this.fp, this.endWall[endIndex], lerpNumber);
                        endInit(this)
                    }
                }

            } else if(this.endWall.length==0){
                db[this.wall.end.id].x = moveWallEnd.x;
                db[this.wall.end.id].y = moveWallEnd.y;
                for (var id in this.origEnd) {
                    if (db[id])
                        db[id].x = end.x, db[id].y = end.y;
                }
            }else {
                if (!this.AddEndWall) {
                    this.AddEndWall = this.AddEndWall || new Wall();
                    this.AddEndWallBegin = this.AddEndWallBegin || new Point(), this.AddEndWallEnd = this.AddEndWallEnd || new Point();
                    utilEntityAddLink(this.fp, this.AddEndWall);
                    this.AddEndWall.begin = this.AddEndWallBegin;
                    this.AddEndWall.end = this.AddEndWallEnd;
                    this.AddEndWallEnd.x = db[this.wall.end.id].x;
                    this.AddEndWallEnd.y = db[this.wall.end.id].y;
                }
                db[this.wall.end.id].x = this.AddEndWallBegin.x = moveWallEnd.x;
                db[this.wall.end.id].y = this.AddEndWallBegin.y = moveWallEnd.y;
                endInit(this)
            }

            if (beginCross && beginCross.x < 100 && beginCross.x > -100 && czBeginFlag) {
                var cross = void 0;
                db[this.wall.begin.id].x = beginCross.x;
                db[this.wall.begin.id].y = beginCross.y;
                this.beginWall.length == 2 && (cross = linesIntr(
                    {
                        x: this.beginWall[1].begin.x,
                        y: this.beginWall[1].begin.y,
                    }, {
                        x: this.beginWall[1].end.x,
                        y: this.beginWall[1].end.y
                    },
                    {
                        x: this.beginWall[0].begin.x,
                        y: this.beginWall[0].begin.y,
                    }, {
                        x: this.beginWall[0].end.x,
                        y: this.beginWall[0].end.y
                    }
                ))
                if (this.beginWall.length == 1 || (this.beginWall.length == 2 && (!cross || (cross.x > 100 || cross.x < -100)))) {
                    for (var id in this.origBegin) {
                        if (db[id])
                            db[id].x = begin.x, db[id].y = begin.y;
                    }
                    if (this.beginWall.length == 1) {
                        var Len1 = new Line(begin.x, begin.y, this.beginWall[0].end.x, this.beginWall[0].end.y).length();
                        var Len2 = new Line(begin.x, begin.y, this.beginWall[0].begin.x, this.beginWall[0].begin.y).length();
                        if (Len1 != 0 && Len1 < tol) {
                            db[this.wall.begin.id].x = this.beginWall[0].end.x;
                            db[this.wall.begin.id].y = this.beginWall[0].end.y;
                            for (var id in this.origBegin) {
                                if (db[id]) {
                                    db[id].x = this.beginWall[0].end.x, db[id].y = this.beginWall[0].end.y;
                                    utilEntityRemoveLink(this.fp, this.origBeginPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.beginWall[0]);
                            beginInit(this)
                        }
                        if (Len2 != 0 && Len2 < tol) {
                            db[this.wall.begin.id].x = this.beginWall[0].begin.x;
                            db[this.wall.begin.id].y = this.beginWall[0].begin.y;
                            for (var id in this.origBegin) {
                                if (db[id]) {
                                    db[id].x = this.beginWall[0].begin.x, db[id].y = this.beginWall[0].begin.y;
                                    utilEntityRemoveLink(this.fp, this.origBeginPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.beginWall[0]);
                            beginInit(this)
                        }
                    }
                    if (this.beginWall.length == 2) {
                        var Len1 = new Line(begin.x, begin.y, this.beginWall[0].end.x, this.beginWall[0].end.y).length();
                        var Len2 = new Line(begin.x, begin.y, this.beginWall[0].begin.x, this.beginWall[0].begin.y).length();
                        var Len3 = new Line(begin.x, begin.y, this.beginWall[1].end.x, this.beginWall[1].end.y).length();
                        var Len4 = new Line(begin.x, begin.y, this.beginWall[1].begin.x, this.beginWall[1].begin.y).length();
                        console.log("Len1=",Len1,"Len2=",Len2,"Len3=",Len3,"Len4=",Len4)
                        if (Len1 != 0 && Len1 < tol) {
                            db[this.wall.begin.id].x = this.beginWall[0].end.x;
                            db[this.wall.begin.id].y = this.beginWall[0].end.y;
                            this.beginWall[1].end.x = this.beginWall[0].end.x;
                            this.beginWall[1].end.y = this.beginWall[0].end.y;
                            for (var id in this.origBegin) {
                                if (db[id]) {
                                    db[id].x = this.beginWall[0].end.x, db[id].y = this.beginWall[0].end.y;
                                    utilEntityRemoveLink(this.fp, this.origBeginPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.beginWall[0]);
                            beginInit(this)

                        }
                        if (Len2 != 0 && Len2 < tol) {
                            db[this.wall.begin.id].x = this.beginWall[0].begin.x;
                            db[this.wall.begin.id].y = this.beginWall[0].begin.y;
                            this.beginWall[1].begin.x = this.beginWall[0].begin.x;
                            this.beginWall[1].begin.y = this.beginWall[0].begin.y;
                            for (var id in this.origBegin) {
                                if (db[id]) {
                                    db[id].x = this.beginWall[0].begin.x, db[id].y = this.beginWall[0].begin.y;
                                    utilEntityRemoveLink(this.fp, this.origBeginPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.beginWall[0]);
                            beginInit(this)
                        }

                        if (Len3 != 0 && Len3 < tol) {
                            db[this.wall.begin.id].x = this.beginWall[1].end.x;
                            db[this.wall.begin.id].y = this.beginWall[1].end.y;
                            this.beginWall[0].end.x = this.beginWall[1].end.x;
                            this.beginWall[0].end.y = this.beginWall[1].end.y;

                            for (var id in this.origBegin) {
                                if (db[id]) {
                                    db[id].x = this.beginWall[1].end.x, db[id].y = this.beginWall[1].end.y;
                                    utilEntityRemoveLink(this.fp, this.origBeginPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.beginWall[1]);
                            beginInit(this)
                        }
                        if (Len4 != 0 && Len4 < tol) {
                            db[this.wall.begin.id].x = this.beginWall[1].begin.x;
                            db[this.wall.begin.id].y = this.beginWall[1].begin.y;
                            this.beginWall[0].begin.x = this.beginWall[1].begin.x;
                            this.beginWall[0].begin.y = this.beginWall[1].begin.y;

                            for (var id in this.origBegin) {
                                if (db[id]) {
                                    db[id].x = this.beginWall[1].begin.x, db[id].y = this.beginWall[1].begin.y;
                                    utilEntityRemoveLink(this.fp, this.origBeginPoint[id])
                                }
                            }
                            utilEntityRemoveLink(this.fp, this.beginWall[1]);
                            beginInit(this)
                        }

                    }
                } else {
                    var Len = new Line(begin.x, begin.y, this.beginWall[beginIndex].end.x, this.beginWall[beginIndex].end.y).length();
                    var Len1 = new Line(begin.x, begin.y, this.beginWall[beginIndex].begin.x, this.beginWall[beginIndex].begin.y).length();
                    if(Len>.5&&Len1>.5){
                        var lerpNumber = utilMathGetLerpNumber(this.beginWall[beginIndex].begin, this.beginWall[beginIndex].end, {x:begin.x,y:begin.y});
                        utilWallBreak(this.fp, this.beginWall[beginIndex], lerpNumber);
                        this.origBegin = [];
                        this.origBeginPoint = [];
                        beginInit(this)
                    }
                }
            }else if(this.beginWall.length==0){
                db[this.wall.begin.id].x = moveWallBegin.x;
                db[this.wall.begin.id].y = moveWallBegin.y;
                for (var id in this.origBegin) {
                    if (db[id])
                        db[id].x = begin.x, db[id].y = begin.y;
                }

            } else {
                if (!this.AddBeginWall) {
                    this.AddBeginWall = this.AddBeginWall || new Wall();
                    this.AddBeginWallBegin = this.AddBeginWallBegin || new Point(), this.AddBeginWallEnd = this.AddBeginWallEnd || new Point();
                    utilEntityAddLink(this.fp, this.AddBeginWall);
                    this.AddBeginWall.begin = this.AddBeginWallBegin;
                    this.AddBeginWall.end = this.AddBeginWallEnd;
                    this.AddBeginWallBegin.x = db[this.wall.begin.id].x;
                    this.AddBeginWallBegin.y = db[this.wall.begin.id].y;
                }
                db[this.wall.begin.id].x = this.AddBeginWallEnd.x = moveWallBegin.x;
                db[this.wall.begin.id].y = this.AddBeginWallEnd.y = moveWallBegin.y;
                beginInit(this)
            }

        }
    }
})

function ActionDeleteWall(mgr) {
    classBase(this, mgr), this.wall = void 0, this.beginPt = void 0, this.endPt = void 0;
}

ActionDeleteWall.prototype.type = "DeleteWall";
classInherit(ActionDeleteWall, ActionBase);
utilExtend(ActionDeleteWall.prototype, {
    isEnable: function () {
        return utilModelIsFlagOff(this.fp, MODELFLAG_LOCKED);
    },
    end: function () {
        utilFloorplanForEachWall(this.fp, function (w) {
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
        });
        utilFloorplanRebuildFloor(this.fp);
        utilFloorplanUpdateWallArea(this.fp);
    },
    begin: function (wall) {
        this.wall = wall;
        this.beginPt = wall.begin;
        this.endPt = wall.end;
        __log("run this action: " + this.type + ", pid=" + wall.pid);
        wall.begin = void 0;
        wall.end = void 0;
        wall.bezier = void 0;
        utilEntityRemoveLink(this.fp, wall);
        utilActionEnd(this.mgr);
    }
});


//设置墙的厚度
function ActionSetThickness(mgr) {
    classBase(this, mgr), this.model = void 0, this.thicknessBefore = void 0, this.walls = [];
}

ActionSetThickness.prototype.type = "SetThickness";
classInherit(ActionSetThickness, ActionBase);
utilExtend(ActionSetThickness.prototype, {
    begin: function (model) {
        model && (model.type != Wall.prototype.type && model.type != Floor.prototype.type && model.type != Floorplan.prototype.type || (this.model = model,
            this.thicknessBefore = this.model.width || DEFAULT_WALL_WIDTH));
    },
    end: function () {
        utilFloorplanForEachWall(this.fp, function (w) {
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
        });
        utilFloorplanRebuildFloor(this.fp);
        utilFloorplanUpdateWallArea(this.fp);
    },
    run: function (cmd, width) {
        return this.model ? "reset" == cmd ? (this.model.width = DEFAULT_WALL_WIDTH,
            void this.walls.push(this.model)) : void (this.model.type == Wall.prototype.type ? (this.model.width = width,
            this.walls.push(this.model)) : this.model.type == Floor.prototype.type && (this.model.width = width,
                this.model.profile.forEach(function (wall) {
                    wall.width = height, -1 == this.walls.indexOf(wall) && this.walls.push(wall);
                }, this))) : void 0;
    }
});

//创建矩形空间
function ActionAddRectRoom(mgr, opt) {
    classBase(this, mgr), this.firstPoint = void 0, this.lastPoint = void 0, this.top = void 0,
        this.bottom = void 0, this.left = void 0, this.right = void 0;
}
ActionAddRectRoom.prototype.type = "AddRectRoom";
classInherit(ActionAddRectRoom, ActionBase);
utilExtend(ActionAddRectRoom.prototype, {
    _updateRoomAndCurve: function () {
        utilFloorplanRebuildFloor(this.fp)
        utilFloorplanForEachWall(this.fp, function (w) {
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D);
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
        });
    },
    needViewportMouseMove: function () {
        return !0;
    },
    isEnable: function () {
        return utilModelIsFlagOff(this.fp, MODELFLAG_LOCKED);
    },
    end: function (opt) {
        this.firstPoint && this.lastPoint && !utilMathIsSamePoint(this.firstPoint, this.lastPoint, .5) ? this._updateRoomAndCurve() : (
            utilEntityRemoveLink(this.fp, this.top),
            utilEntityRemoveLink(this.fp, this.bottom),
            utilEntityRemoveLink(this.fp, this.left),
            utilEntityRemoveLink(this.fp, this.right));
            
        this.firstPoint && (delete Root.prototype.database[this.firstPoint.id], this.firstPoint = null);
    },
    begin: function (opt) {
        this.top = new Wall();
        utilEntityAddLink(this.fp, this.top);
        this.top.begin = new Point(), this.top.end = new Point();//,this.top.bezier = new BezierPoint();

        this.bottom = new Wall();
        utilEntityAddLink(this.fp, this.bottom);
        this.bottom.begin = new Point(), this.bottom.end = new Point();//,this.bottom.bezier = new BezierPoint();

        this.left = new Wall();
        utilEntityAddLink(this.fp, this.left);
        this.left.begin = new Point(), this.left.end = new Point();//,this.left.bezier = new BezierPoint();

        this.right = new Wall();
        utilEntityAddLink(this.fp, this.right);
        this.right.begin = new Point(), this.right.end = new Point();//,this.right.bezier = new BezierPoint();
    },
    run: function (cmd, evt, modelPos) {
        __log(cmd);
        var _moveSencondPoint = function (pos) {
            var x = pos.x, y = pos.y;
            this.top.end.x = this.right.begin.x = x;
            this.right.end.x = this.bottom.begin.x = x;
            this.right.end.y = this.bottom.begin.y = y;
            this.bottom.end.y = this.left.begin.y = y;
            this.lastPoint = pos;
        }.bind(this);

        if ("view2d_mousemove" == cmd) {
            if (!this.firstPoint) return;
            _moveSencondPoint(modelPos);
        } else if ("view2d_mouseup" == cmd) {
            if (1 == evt.button)
                return;
            if (void 0 == this.firstPoint) {
                var x = modelPos.x, y = modelPos.y;
                this.firstPoint = new Point();
                this.firstPoint.x = x, this.firstPoint.y = y;

                this.top.begin.x = this.top.end.x = x, this.top.begin.y = this.top.end.y = y;
                this.bottom.begin.x = this.bottom.end.x = x, this.bottom.begin.y = this.bottom.end.y = y;
                this.left.begin.x = this.left.end.x = x, this.left.begin.y = this.left.end.y = y;
                this.right.begin.x = this.right.end.x = x, this.right.begin.y = this.right.end.y = y;
            } else {
                _moveSencondPoint(modelPos);
                utilActionEnd(this.mgr);
            }
        }
    }
})

//开启曲线编辑模式
function ActionSetWallBezier(mgr) {
    classBase(this, mgr), this.model = void 0, this.bezierBefore = void 0, this.walls = [];
}

ActionSetWallBezier.prototype.type = "SetWallBezier";
classInherit(ActionSetWallBezier, ActionBase);
utilExtend(ActionSetWallBezier.prototype, {
    begin: function (model) {
        model && (model.type != Wall.prototype.type && model.type != Floor.prototype.type && model.type != Floorplan.prototype.type || (this.model = model,
            this.bezierBefore = this.model.bezier));
    },
    end: function () {
        utilFloorplanForEachWall(this.fp, function (w) {
            utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_2D), utilModelSetFlagOn(w, WALLFLAG_DETAILEDUPDATED_3D);
        });
        utilFloorplanRebuildFloor(this.fp);
        utilFloorplanUpdateWallArea(this.fp);
    },
    run: function (cmd, bezier) {
        if (bezier) {
            var opt = {};
            opt.x = (this.model.begin.x + this.model.end.x) / 2;
            opt.y = (this.model.begin.y + this.model.end.y) / 2;
            var bezierPoint = new BezierPoint(opt);
            this.model.bezier = bezierPoint;

            var wallDir = new Vec2(this.model.end.x - this.model.begin.x, this.model.end.y - this.model.begin.y);
            var wallLength = utilMathLineLength(this.model.begin, this.model.end);
            if (!isNaN(wallDir.x) && 0 != Vec2.dot(wallDir, wallDir)) {
                var wallDirOffset = wallDir.normalize().scale(wallLength / 2);
                var movePoint = Vec2.rotateAroundPoint(wallDirOffset.clone().add(opt), opt, Math.PI / 2);
                this.model.bezier.x = movePoint.x;
                this.model.bezier.y = movePoint.y;
            } else {
                this.model.bezier.x = opt.x;
                this.model.bezier.y = opt.y;
            }

            var fp = application.doc.floorplan;
            var isLockOn = utilModelIsFlagOn(fp, MODELFLAG_LOCKED);
            if (isLockOn)
                utilModelSetFlagOn(bezierPoint, MODELFLAG_LOCKED);
        } else {
            this.model.bezier = 0;
        }

        utilFloorplanUpdateWallArea(this.fp);
        //utilFloorplanForEachBezierPoint(fp, function (pt) {
        //    isLockOn ? utilModelSetFlagOn(pt, MODELFLAG_LOCKED) : utilModelSetFlagOff(pt, MODELFLAG_LOCKED);
        //});
        utilActionEnd(this.mgr);
    }
});
// sourceURL=src\action\wall.js