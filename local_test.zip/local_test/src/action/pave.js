//单砖铺砖action by mond 20170822

//////////////////////////////////////////////////////////////////
//连续直铺
var PAVEMODEL = {};	
//action/paveModel/singlePave.js doublePave.js multPave.js

/////////////////////////////////////////////////////////////////
//设置砖缝大小
function ActionSetGapwidth(mgr) {
    classBase(this, mgr);
}
ActionSetGapwidth.prototype.type = "ActionSetGapwidth";
classInherit(ActionSetGapwidth, ActionBase);
utilExtend(ActionSetGapwidth.prototype, {
	  canUndoRedo: function () {
        return !0;
    },
    undo: function () {
    	  this.model.gapwidth = this.oldgapwidth;
    },
    redo: function () {
    	  this.model.gapwidth = this.gapwidth;
    },
    end: function () {
    },
    begin: function (model,gapwidth) {
    	  this.model = model;
    	  this.oldgapwidth = this.model.gapwidth;
    	  this.gapwidth = gapwidth;    	  
    },
    run: function(cmd, evt, position, attachments){        
        this.model.gapwidth = this.gapwidth;
    }
});

//设置砖缝颜色
function ActionSetGapcolor(mgr) {
    classBase(this, mgr);
}
ActionSetGapcolor.prototype.type = "ActionSetGapcolor";
classInherit(ActionSetGapcolor, ActionBase);
utilExtend(ActionSetGapcolor.prototype, {
	  canUndoRedo: function () {
        return !0;
    },
    undo: function () {
    	  this.model.gapcolor = this.oldgapcolor;
    },
    redo: function () {
    	  this.model.gapcolor = this.gapcolor;
    },
    end: function () {
    },
    begin: function (model,gapcolor) {
    	  this.model = model;
    	  this.oldgapcolor = this.model.gapcolor;
    	  this.gapcolor = gapcolor;    	  
    },
    run: function(cmd, evt, position, attachments){        
        this.model.gapcolor = this.gapcolor;
    }
});

function ActionTilesingleSetPave(mgr) {
    classBase(this, mgr);
}
ActionTilesingleSetPave.prototype.type = "TilesingleSetPave";
classInherit(ActionTilesingleSetPave, ActionBase);
utilExtend(ActionTilesingleSetPave.prototype, {
    end: function () {
    },
    begin: function (paveType) {
    	  this.paveType = paveType;
    },
    run: function(cmd, evt, position, attachments){        
        if ("view2d_mouseup" == cmd) {
        	if (attachments[0] && (attachments[0].type == "FLOOR" ||
        	                       attachments[0].type == "RECTAREA" ||
        	                       attachments[0].type == "ROUNDAREA" ||
        	                       attachments[0].type == "FREEAREA")){
        		utilActionEnd(this.mgr);
        		utilActionBegin(this.mgr, "TilesingleChangePave", attachments[0], this.paveType); 
          }
        } else if ("click3d" == cmd) {
        	var modelType = position.model.type;
        	if(modelType == "FLOOR" ||
        	   modelType == "RECTAREA" ||
        	   modelType == "ROUNDAREA" ||
        	   modelType == "ROUNDAREA3D" ||
        	   modelType == "FREEAREA" ||
        	   modelType == "WALLBOARD" ||
        	   modelType == "RECTAREA3D"){   		
        		utilActionEnd(this.mgr);
        		utilActionBegin(this.mgr, "TilesingleChangePave", position.model, this.paveType);
        	}
        }
    }
});

function ActionTilesingleChangePave(mgr) {
    classBase(this, mgr);
}
ActionTilesingleChangePave.prototype.type = "TilesingleChangePave";
classInherit(ActionTilesingleChangePave, ActionBase);
utilExtend(ActionTilesingleChangePave.prototype, {
	  canUndoRedo: function () {
        return true;
    },
    undo: function () {
    	  classBase(this, "undo");
    	  this.savedForRedo = this.model.paveType;
    	  this.model.paveType = this.savedForUndo;
    },    
    redo: function () {
    	  classBase(this, "redo");
    	  this.model.paveType = this.savedForRedo;
    },
    end: function () {
    },
    begin: function (model, paveType) {
    	  this.model = model;
    	  this.savedForUndo = this.model.paveType;
    	  this.model.paveType = paveType;
    	  
    	  var paveInfo = PAVEMODEL[paveType];
    	  if(paveInfo.pids){
    	  	//使用pids初始化纹理组
    	  	var model = this.model;
    	  	utilCatalogGetProductsMetaPromise(application.catalogMgr, paveInfo.pids).then(function (meta) {
    	  		paveInfo.pids.forEach(function(pid,index){
    	  			meta[pid] && (model["pave" + index + "Material"] = new Material(meta[pid]));
    	  		});               
					});
					
					//清空paveMaterial
					for(var i=0;i<10;++i){
	    	  	model["pave" + i + "Material"] = null;
	    	  }
    	  }    	  
    	  
    	  utilActionEnd(this.mgr);
    }
});


//立面铺贴
function ActionAddWallBaseboard(mgr) {
	classBase(this, mgr);
}
ActionAddWallBaseboard.prototype.type = "AddWallBaseboard";
classInherit(ActionAddWallBaseboard, ActionBase);
utilExtend(ActionAddWallBaseboard.prototype, {
    end: function () {
    },
    begin: function () {
    	  
    },
    run: function(cmd, evt, position, attachments){        
      if ("click3d" == cmd) {
      	var model = null;
      	var category = "";
	    	var modelType = position.model.type;
	    	if(modelType == "WALL" ||
	    	   modelType == "RECTAREA" ||
	    	   modelType == "ROUNDAREA" ||
	    	   modelType == "FREEAREA"){
	    		model = position.model;
	    		category = position.opt.elementName;
	    	}else if(modelType == Baseboard.prototype.type || modelType == Wallboard.prototype.type){
	    		model = position.model.host;
	    		category = position.model.category;
	    	}
	    	
	    	if(model){
	    		var smoothStart = utilModelWallGetSmoothStart(model, category);
	    		model = smoothStart.wall;
	    		category = smoothStart.side;
	    		
		    	var elementBoards = model[category + "Boards"];
		    	if(elementBoards){
		    		var added = true;
		    		if(elementBoards.length > 0){
		    			var board = this.fp.lf[elementBoards[elementBoards.length - 1]];
		    			board && board.type == Baseboard.prototype.type && (added = false);
		    			//已经有踢脚
		    		}
		    		
		    		if(added){
		    			var area = new Baseboard({
				    		category:category,
				    		host:model
				    	});
				    	area.center = new Point();
			        area.level = 0;
			        area.height = 0.15;
			        area.paveType = "SINGLEPAVE_01X";
			        
			        var fp = this.fp;				    	
		    			elementBoards.push(area.id);
		    			
		    			//清空paveMaterial
							for(var pM=0;pM<10;++pM){
			    	  	area["pave" + pM + "Material"] = null;
			    	  }
			    	  var basepid = DEFAULT_AREA_MATERIAL["baseboard"];
				    	utilCatalogGetProductsMetaPromise(application.catalogMgr, [basepid]).then(function (meta) {
		    	  		meta[basepid] && (area["areaMaterial"] = new Material(meta[basepid]));		    	  		               
		    	  						    					    		
				    		utilFloorplanUpdateWallAreaByWall(area.host);
							});
							
							utilEntityAddLink(fp, area);
		    		}
		    	}
          
	    		utilActionEnd(this.mgr);
	    	}
	    }
    }
});

function ActionSetWallboard(mgr) {
	classBase(this, mgr);
}
ActionSetWallboard.prototype.type = "SetWallboard";
classInherit(ActionSetWallboard, ActionBase);
utilExtend(ActionSetWallboard.prototype, {
    end: function () {
    },
    begin: function (opt) {
    	  this.opt = opt;
    },
    run: function(cmd, evt, position, attachments){        
      if ("click3d" == cmd) {
	    	var model = null;
      	var category = "";
	    	var modelType = position.model.type;
	    	if(modelType == "WALL" ||
	    	   modelType == "RECTAREA" ||
	    	   modelType == "ROUNDAREA" ||
	    	   modelType == "FREEAREA"){
	    		model = position.model;
	    		category = position.opt.elementName;
	    	}else if(modelType == Baseboard.prototype.type || modelType == Wallboard.prototype.type){
	    		model = position.model.host;
	    		category = position.model.category;
	    		
	    		var view = api.getViewById('3d');
			    var pickMgr = view.app.pickMgr;
	    		utilPickMgrUnpickAll(pickMgr);//取消选中
	    	}
		    	
		    if(model){
		    	var smoothStart = utilModelWallGetSmoothStart(model, category);
	    		model = smoothStart.wall;
	    		category = smoothStart.side;
	    		
		    	var elementBoards = model[category + "Boards"];
		    	if(elementBoards){
		    		var wallHeight = Math.abs(model.height3d);
		    		var baseboardid = null; //保留踢脚线		    		
		    		if(elementBoards.length > 0){
		    			var board = this.fp.lf[elementBoards[elementBoards.length - 1]];
		    			board && board.type == Baseboard.prototype.type && (baseboardid = elementBoards.pop(), wallHeight -= board.height);
		    			
		    			//清空列表
		    			model[category + "Boards"] = [];
		    			
		    			elementBoards.forEach(function(id){
		    				var board = this.fp.lf[id];
		    				utilEntityRemoveLink(this.fp, board);
		    			});
		    		}
		    	
		    	  var boardsNum = this.opt.length;
		    	  for(var i = boardsNum-1;i>=0;--i){
		    	  	if(wallHeight>0){
		    	  		var boardInfo = this.opt[i];
		    	  		var height = (wallHeight >= boardInfo.height) ? boardInfo.height : wallHeight;		    	  		
		    	  		if(i == 0){
		    	  			height = wallHeight;
		    	  		}	
		    	  		wallHeight -= height;	    	  		
		    	  		var fp = this.fp;
			    	  	var area = new Wallboard({
					    		category:category,
					    		host:model
					    	});
					    	model[category + "Boards"].splice(0,0,area.id);
					    	area.height = height;
					    	area.center = new Point();
			          area.level = 0;
			          
					    	//清空paveMaterial
								for(var pM=0;pM<10;++pM){
				    	  	area["pave" + pM + "Material"] = null;
				    	  }
					    	utilCatalogGetProductsMetaPromise(application.catalogMgr, [boardInfo.pid]).then(function (area,boardInfo,meta) {
			    	  		meta[boardInfo.pid] && (area["areaMaterial"] = new Material(meta[boardInfo.pid]));
			    	  					    	  		
			    	  		utilFloorplanUpdateWallAreaByWall(area.host);
								}.bind(this,area, boardInfo));
								
								utilEntityAddLink(fp, area);
		    	  	}		    	  	
		    	  }			    	
		    	  
		    	  if(baseboardid){
		    	  	//重新加入踢脚线id
		    	  	model[category + "Boards"].push(baseboardid);
		    	  }
		    	  
		    	  utilFloorplanUpdateWallAreaByWall(model);
		    	}
	    		utilActionEnd(this.mgr);
	    	}
	    }
    }
});

function ActionAddWallboard(mgr) {
	classBase(this, mgr);
}
ActionAddWallboard.prototype.type = "AddWallboard";
classInherit(ActionAddWallboard, ActionBase);
utilExtend(ActionAddWallboard.prototype, {
    end: function () {
    },
    begin: function (opt) {
    	  this.opt = opt;
    },
    run: function(cmd, evt, position, attachments){        
      if ("click3d" == cmd) {
	    	var model = null;
      	var category = "";
	    	var modelType = position.model.type;
	    	if(modelType == "WALL" ||
	    	   modelType == "RECTAREA" ||
	    	   modelType == "ROUNDAREA" ||
	    	   modelType == "FREEAREA"){
	    		model = position.model;
	    		category = position.opt.elementName;
	    	}else if(modelType == Baseboard.prototype.type || modelType == Wallboard.prototype.type){
	    		model = position.model.host;
	    		category = position.model.category;
	    		
	    		var view = api.getViewById('3d');
			    var pickMgr = view.app.pickMgr;
	    		utilPickMgrUnpickAll(pickMgr);//取消选中
	    	}else if(modelType == RectArea.prototype.type){
	    		model = position.model;
	    		category = position.opt.elementName;
	    	}
		    	
		    if(model){
		    	var smoothStart = utilModelWallGetSmoothStart(model, category);
	    		model = smoothStart.wall;
	    		category = smoothStart.side;
	    		
		    	var elementBoards = model[category + "Boards"];
		    	if(elementBoards){
		    		var wallHeight = Math.abs(model.height3d);
		    		if(elementBoards.length > 0){
		    			var board = this.fp.lf[elementBoards[elementBoards.length - 1]];
		    			board && (wallHeight -= board.height);		    			
		    		}
		    			    	
		    	  var boardsNum = this.opt.length;
		    	  for(var i = boardsNum-1;i>=0;--i){
		    	  	if(wallHeight>0){
		    	  		var boardInfo = this.opt[i];
		    	  		var height = (wallHeight >= boardInfo.height) ? boardInfo.height : wallHeight;		    	  		
		    	  		if(i == 0){
		    	  			height = wallHeight;
		    	  		}	
		    	  		wallHeight -= height;	    	  		
		    	  		var fp = this.fp;
			    	  	var area = new Wallboard({
					    		category:category,
					    		host:model
					    	});
					    	model[category + "Boards"].splice(0,0,area.id);
					    	area.height = height;
					    	area.center = new Point();
			          area.level = 0;
			          
					    	//清空paveMaterial
								for(var pM=0;pM<10;++pM){
				    	  	area["pave" + pM + "Material"] = null;
				    	  }
					    	utilCatalogGetProductsMetaPromise(application.catalogMgr, [boardInfo.pid]).then(function (area,boardInfo,meta) {
			    	  		meta[boardInfo.pid] && (area["areaMaterial"] = new Material(meta[boardInfo.pid]));
			    	  					    	  		
			    	  		utilFloorplanUpdateWallAreaByWall(area.host);
								}.bind(this,area, boardInfo));
								
								utilEntityAddLink(fp, area);
		    	  	}		    	  	
		    	  }			    	
		    	  
		    	  utilFloorplanUpdateWallAreaByWall(model);
		    	}
	    		utilActionEnd(this.mgr);
	    	}
	    }
    }
});
// sourceURL=src\action\pave.js