function utilEncryptString(str) {
    return Base64.e(str);
}

function utilDecryptString(str) {
    return Base64.d(str);
}

function Line(x0, y0, x1, y1) {
    this.x0 = Number(x0), this.y0 = Number(y0), this.x1 = Number(x1), this.y1 = Number(y1);
}

function Bound(x, y, w, h) {
    this.left = x, this.top = y, this.width = w, this.height = h;
}

function utilBoundIsValid(bound) {
    return isFinite(bound.top) && isFinite(bound.left) && bound.width >= 0 && bound.height >= 0;
}

function utilBoundReset(bound) {
    bound.top = bound.left = 1 / 0, bound.width = bound.height = 0;
}

function utilBoundAddMarginClone(bound, ex, ey) {
    var cloned = new Bound();
    return cloned.left = bound.left - ex, cloned.top = bound.top - ey, cloned.width = bound.width + 2 * ex,
        cloned.height = bound.height + 2 * ey, cloned;
}

function utilBoundAddPoint(bound, point) {
    return !isFinite(bound.left) || isNaN(bound.left) ? (bound.left = point.x, void (bound.top = point.y)) : (point.x < bound.left ? (bound.width += bound.left - point.x,
        bound.left = point.x) : bound.width = Math.max(bound.width, point.x - bound.left),
        void (point.y < bound.top ? (bound.height += bound.top - point.y, bound.top = point.y) : bound.height = Math.max(bound.height, point.y - bound.top)));
}

function utilBoundFromLoop(poly) {
    var bound = new Bound();
    return utilBoundReset(bound), poly && poly.forEach(function (p) {
        isNaN(p.x) || isNaN(p.y) || utilBoundAddPoint(bound, p);
    }), bound;
}

function utilBoundToLoop(bound) {
    return utilBoundIsValid(bound) ? [{
        x: bound.left,
        y: bound.top
    }, {
        x: bound.left + bound.width,
        y: bound.top
    }, {
        x: bound.left + bound.width,
        y: bound.top + bound.height
    }, {
        x: bound.left,
        y: bound.top + bound.height
    }, {
        x: bound.left,
        y: bound.top
    }] : void 0;
}

function utilBoundAddBound(thisBound, anotherBound) {
    utilBoundAddPoint(thisBound, {
        x: anotherBound.left,
        y: anotherBound.top
    }), utilBoundAddPoint(thisBound, {
        x: anotherBound.left + anotherBound.width,
        y: anotherBound.top
    }), utilBoundAddPoint(thisBound, {
        x: anotherBound.left,
        y: anotherBound.top + anotherBound.height
    }), utilBoundAddPoint(thisBound, {
        x: anotherBound.left + anotherBound.width,
        y: anotherBound.top + anotherBound.height
    });
}

function utilBoundOBBNormalize(obb) {
    __assert(Array.isArray(obb) && 4 == obb.length, "invalid OBB");
    for (var topLeftIndex = 0, topLeftIntercept = 1 / 0, i = 0; 4 > i; ++i) {
        var pt = obb[i];
        topLeftIntercept > pt.x - pt.y && (topLeftIndex = i, topLeftIntercept = pt.x - pt.y);
    }
    return [obb[topLeftIndex], obb[(topLeftIndex + 1) % 4], obb[(topLeftIndex + 2) % 4], obb[(topLeftIndex + 3) % 4]];
}

function utilBoundOBBGetLoop(info, margin) {
    var marginBound = margin || 0, p = info, minXminY = {
        x: p.x - p.width / 2 - marginBound,
        y: p.y - p.height / 2 - marginBound
    }, minXmaxY = {
        x: p.x - p.width / 2 - marginBound,
        y: p.y + p.height / 2 + marginBound
    }, maxXminY = {
        x: p.x + p.width / 2 + marginBound,
        y: p.y - p.height / 2 - marginBound
    }, maxXmaxY = {
        x: p.x + p.width / 2 + marginBound,
        y: p.y + p.height / 2 + marginBound
    }, pts = [minXminY, maxXminY, maxXmaxY, minXmaxY, minXminY];
    return !p.rot || utilMathEquals(p.rot, 0) ? pts : pts.map(function (pt) {
        return utilMathRotatePointCW(p, pt, p.rot);
    });
}

function Vec2(x, y) {
    this.x = x, this.y = y;
}

//自定义字典对象
function Dictionary() {

    this.data = new Array();

    this.set = function (key, value) {
        this.data[key] = value;
    };

    this.get = function (key) {
        return this.data[key];
    }

    this.remove = function (key) {
        if (this.hasKey(key))
            this.data[key] = null;
    }

    this.isEmpty = function () {
        return this.data.length == 0;
    }

    this.size = function () {
        return this.data.length;
    }

    this.hasKey = function (key) {
        return this.data[key] != null;
    }

    this.clear = function () {
        this.data.splice(0, this.data.length);
    }
}

/**
 * Created by gaoning on 2018/4/10.
 */
var uDictionary = function() {
    this.elements = new Array();
    //Length of Dictionary
    this.length = function () {
        return this.elements.length;
    };
    //Check whether the Dictionary is empty
    this.isEmpty = function () {
        return (this.length() < 1);
    };
    //remove all elements from the Dictionary
    this.removeAll = function () {
        this.elements = new Array();
    };
    //get specify element of the dictionary
    this.element = function (index) {
        var rlt = null;
        if (index >= 0 && index < this.elements.length) {
            rlt = this.elements[index];
        }
        return rlt;
    }
    //check whether the Dictionary contains this key
    this.Exists = function (key) {
        var rlt = false;
        try {
            for (var i = 0, iLen = this.length(); i < iLen; i++) {
                if (this.elements[i].key == key) {
                    rlt = true;
                    break;
                }
            }
        }
        catch (ex) {
        }
        return rlt;
    };
    //check whether the Dictionary contains this value
    this.containsValue = function (value) {
        var rlt = false;
        try {
            for (var i = 0, iLen = this.length(); i < iLen; i++) {
                if (this.elements[i].value == value) {
                    rlt = true;
                    break;
                }
            }
        }
        catch (ex) {
        }
        return rlt;
    };
    //remove this key from the Dictionary
    this.remove = function (key) {
        var rlt = false;
        try {
            for (var i = 0, iLen = this.length(); i < iLen; i++) {
                if (this.elements[i].key == key) {
                    this.elements.splice(i, 1);
                    rlt = true;
                    break;
                }
            }
        }
        catch (ex) {
        }
        return rlt;
    };
    //add this key/value to the Dictionary,if key is exists,replace the value
    this.add = function (key, value) {
        this.remove(key);
        this.elements.push({
            key: key,
            value: value
        });
    };
    //add this key/value to the Dictionary,if key is exists,append value
    this.set = function (key, value) {
        var arr = this.getItem(key);
        if (arr != null) {
            if (typeof(arr) == "object") {
                arr.unshift.apply(arr, value);
                value = arr;
            }
            else {
                var array = [];
                array.push(arr);
                array.unshift.apply(array, value);
                value = array;
            }
            this.remove(key);
        }
        this.elements.push({
            key: key,
            value: value
        });
    }
    //get value of the key
    this.getItem = function (key) {
        var rlt = null;
        try {
            for (var i = 0, iLen = this.length(); i < iLen; i++) {
                if (this.elements[i].key == key) {
                    rlt = this.elements[i].value;
                    break;
                }
            }
        }
        catch (ex) {
        }
        return rlt;
    };
    //get all keys of the dictionary
    this.keys = function () {
        var arr = [];
        for (var i = 0, iLen = this.length(); i < iLen; i++) {
            arr.push(this.elements[i].key);
        }
        return arr;
    }
    //get all values of the dictionary
    this.values = function () {
        var arr = [];
        for (var i = 0, iLen = this.length(); i < iLen; i++) {
            arr.push(this.elements[i].value);
        }
        return arr;
    }
}

function utilMathToRadius(angle) {
    return angle * Math.PI / 180;
}

function utilMathEquals(a, b, tolerance) {
    return Math.abs(a - b) <= (tolerance || .001);
}

function utilMathIsSamePoint(a, b, tolerance) {
    return a && b ? utilMathEquals(a.x, b.x, tolerance) && utilMathEquals(a.y, b.y, tolerance) : !1;
}

function utilMathIsLineParallel(p1, p2, p3, p4, tolerance) {
    return utilMathEquals((p1.x - p2.x) * (p3.y - p4.y) - (p1.y - p2.y) * (p3.x - p4.x), 0, tolerance);
}
function utilMathLineYAxisAngle(p1,p2){
    var x = Math.abs(p1.x-p2.x);
    var y = Math.abs(p1.y-p2.y);
    var z = Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
    var cos = y/z;
    var radina = Math.acos(cos);//用反三角函数求弧度
    var angle = Math.floor(180/(Math.PI/radina));//将弧度转换成角度
    return angle;
}
//两线段交点坐标
function utilMathLineLineIntersection(p1, p2, p3, p4) {
    var det = (p1.x - p2.x) * (p3.y - p4.y) - (p1.y - p2.y) * (p3.x - p4.x);
    var invDet = 1 / det;
    var _tmp1 = p1.x * p2.y - p1.y * p2.x;
    var _tmp2 = p3.x * p4.y - p3.y * p4.x;
    var _x = _tmp1 * (p3.x - p4.x) - (p1.x - p2.x) * _tmp2;
    var _y = _tmp1 * (p3.y - p4.y) - (p1.y - p2.y) * _tmp2;
    return {
        x: _x * invDet,
        y: _y * invDet
    };
}

function utilMathGetLerpNumber(start, end, your) {
    var project = utilMathGetPerpendicularIntersect(your, start, end);
    return Math.abs(start.x - end.x) > Math.abs(start.y - end.y) ? (project.x - start.x) / (end.x - start.x) : (project.y - start.y) / (end.y - start.y);
}

function utilMathGetPerpendicularIntersect(your, start, end) {
    var line = new Line(start.x, start.y, end.x, end.y);
    return line.getClosestPoint(your.x, your.y);
}

function utilMathGetClosestSegmentPoint(your, start, end) {
    var line = new Line(start.x, start.y, end.x, end.y);
    return line.getClosestSegmentPoint(your.x, your.y);
}

function utilMathToDegree(angleRadians) {
    return 180 * angleRadians / Math.PI;
}

function utilMathGetScaledPoint(base, your, expectedLength) {
    var line = new Line(base.x, base.y, your.x, your.y), lineLen = line.length();
    return utilMathEquals(lineLen, 0) ? base : line.getInterpolatedPoint(expectedLength / lineLen);
}

function utilMathGetExtendPoint(base, your, extendLength) {
    var line = new Line(base.x, base.y, your.x, your.y);
    var lineLen = line.length();
    return utilMathEquals(lineLen, 0) ? base : line.getInterpolatedPoint((lineLen + extendLength) / lineLen);
}

function utilMathGetAngleHorizontaleCCW(from, to) {
    return utilMathToDegree(Math.atan2(to.y - from.y, to.x - from.x));
}

function utilMathLineLength(start, end) {
    if (!start || !end) return NaN;
    var line = new Line(start.x, start.y, end.x, end.y);
    return line.length();
}

function utilMathIsPointInPoly(poly, pt) {
    if (!poly || poly.length < 3)
        return !1;
    for (var c = !1, i = -1, l = poly.length, j = l - 1; ++i < l; j = i)
        (poly[i].y <= pt.y && pt.y < poly[j].y
        || poly[j].y <= pt.y && pt.y < poly[i].y)
        && pt.x < (poly[j].x - poly[i].x) * (pt.y - poly[i].y) / (poly[j].y - poly[i].y) + poly[i].x
        && (c = !c);
    return c;
}

function utilMathIsPointInLine(pt, line_start, line_end, tolerance) {
    var perpendicular = utilMathGetPerpendicularIntersect(pt, line_start, line_end), lineLength = new Line(perpendicular.x, perpendicular.y, pt.x, pt.y).length();
    return tolerance > lineLength;
}

function utilMathIsPointInLineSegment(pt, lineFrom, lineTo, tolerance) {
    var line = new Line(lineFrom.x, lineFrom.y, lineTo.x, lineTo.y), closestPt = line.getClosestPoint(pt.x, pt.y);
    if (!utilMathIsSamePoint(closestPt, pt, Math.abs(tolerance))) return !1;
    var length = line.length(), proportion = -tolerance / length, lerpFrom = Vec2.lerp(lineFrom, lineTo, proportion), lerpTo = Vec2.lerp(lineTo, lineFrom, proportion);
    return Math.min(lerpFrom.x, lerpTo.x) <= closestPt.x && Math.max(lerpFrom.x, lerpTo.x) >= closestPt.x && Math.min(lerpFrom.y, lerpTo.y) <= closestPt.y && Math.max(lerpFrom.y, lerpTo.y) >= closestPt.y;
}

function utilMathLinelineCCWAngle(base, from, to) {
    var angle1 = utilMathGetAngleHorizontaleCCW(base, from);
    var angle2 = utilMathGetAngleHorizontaleCCW(base, to);
    var delta = angle2 - angle1;
    return delta > 0 ? delta : 360 + delta;
}

function utilMathRotatePointCW(base, your, angle) {
    return Vec2.rotateAroundPoint(Vec2.fromCoordinate(your), base, utilMathToRadius(angle));
}

function utilMathGetMinMaxFromPointArray(points) {
    var bound_min = {
        x: 1 / 0,
        y: 1 / 0
    }, bound_max = {
        x: -(1 / 0),
        y: -(1 / 0)
    };
    return points.forEach(function (pt) {
        bound_min.x > pt.x && (bound_min.x = pt.x), bound_min.y > pt.y && (bound_min.y = pt.y),
        bound_max.x < pt.x && (bound_max.x = pt.x), bound_max.y < pt.y && (bound_max.y = pt.y);
    }), {
        min: bound_min,
        max: bound_max
    };
}

//计算不规则面积
function utilMathPolyMeasurement(poly) {
    var cnt = poly.length;
    if (3 > cnt)
        return 0;
    for (var a = 0, i = 0, j = cnt - 1; cnt > i; ++i) {
        a += (poly[j].x + poly[i].x) * (poly[j].y - poly[i].y);
        j = i;
    }

    return .5 * -a;
}

function utilMathPolyIsClockWise(poly) {
    return utilMathPolyMeasurement(poly) > 0;
}

//计算房间中心位置-- gaoning
function utilMathPolyMassCenter(poly) {
    if (!poly) {
        return null;
    }
    var cnt = poly.length;
    if (!(3 > cnt)) {
        for (var a = 0, x = 0, y = 0, i = 0; cnt - 1 > i; ++i) {
            var p0 = poly[i], p1 = poly[i + 1], dot = p0.x * p1.y - p1.x * p0.y;
            x += (p0.x + p1.x) * dot, y += (p0.y + p1.y) * dot, a += dot;
        }
        return {
            x: x / (3 * a),
            y: y / (3 * a)
        };
    }
}
function sortNumber(a, b) {
    return a - b;
}

function utilColorHexString(r, g, b) {
    var color = (r || 255 * Math.random()) << 16 ^ (g || 255 * Math.random()) << 8 ^ (b || 255 * Math.random()) << 0;
    return ("000000" + color.toString(16)).slice(-6);
}

function utilStringToHexCharCode(str) {
    var ret = 0x0;
    ret = "0x" + str;
    eval("ret = " + ret);
    return ret;
}

function utilIsPointInsideOBB(AABB, degress, pt) {
    var center = Bound.prototype.center.call(AABB);
    var rotatedPt = utilMathRotatePointCW(center, pt, degress);
    return utilIsPointInsideAABB(AABB, rotatedPt);
}

function utilIsPointInsideAABB(AABB, pt) {
    return Bound.prototype.contains.call(AABB, pt);
}

function utilAdaptorClipperMakePath(loop) {
    for (var scaleFactor = 1e3, path = [], i = 0, len = loop.length - 1; len > i; ++i) {
        var p = loop[i];
        path.push({
            X: Math.floor(p.x * scaleFactor),
            Y: Math.floor(p.y * scaleFactor)
        });
    }
    return path;
}

function utilIsNumber(obj) {
    return !isNaN(parseFloat(obj));
}

function toFixedNumber(num, digits) {
    var factor = 2 == digits ? 100 : 3 == digits ? 1e3 : 10;
    return Math.ceil(num * factor) / factor;
}

var utilUUID = function () {
    var r, chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""), uuid = new Array(36), rnd = 0;
    return uuid[0] = "i", uuid[1] = "d", function () {
        for (var i = 2; 32 > i; i++) 2 >= rnd && (rnd = 33554432 + 16777216 * Math.random() | 0),
            r = 15 & rnd, rnd >>= 4, uuid[i] = chars[19 == i ? 3 & r | 8 : r];
        return uuid.join("");
    };
}(), utilIsUUID = function () {
    var uuid = {
        "3": /^[0-9A-F]{8}-[0-9A-F]{4}-3[0-9A-F]{3}-[0-9A-F]{4}-[0-9A-F]{12}$/i,
        "4": /^[0-9A-F]{8}-[0-9A-F]{4}-4[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$/i,
        "5": /^[0-9A-F]{8}-[0-9A-F]{4}-5[0-9A-F]{3}-[89AB][0-9A-F]{3}-[0-9A-F]{12}$/i,
        all: /^[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}$/i
    };
    return function (str, version) {
        var pattern = uuid[version ? version : "all"];
        return pattern && pattern.test(str);
    };
}(), utilExtend = function () {
    var class2type = {}, core_toString = class2type.toString, core_hasOwn = class2type.hasOwnProperty;
    "Boolean Number String Function Array Date RegExp Object Error".split(" ").forEach(function (name, i) {
        class2type["[object " + name + "]"] = name.toLowerCase();
    });
    var jQuery = {
        isFunction: function (obj) {
            return "function" === jQuery.type(obj);
        },
        isArray: Array.isArray || function (obj) {
            return "array" === jQuery.type(obj);
        },
        isWindow: function (obj) {
            return null != obj && obj == obj.window;
        },
        isNumeric: function (obj) {
            return !isNaN(parseFloat(obj)) && isFinite(obj);
        },
        type: function (obj) {
            return null == obj ? String(obj) : "object" == typeof obj || "function" == typeof obj ? class2type[core_toString.call(obj)] || "object" : typeof obj;
        },
        isPlainObject: function (obj) {
            var key;
            if (!obj || "object" !== jQuery.type(obj) || obj.nodeType || jQuery.isWindow(obj)) return !1;
            try {
                if (obj.constructor && !core_hasOwn.call(obj, "constructor") && !core_hasOwn.call(obj.constructor.prototype, "isPrototypeOf")) return !1;
            } catch (e) {
                return !1;
            }
            if (jQuery.support && jQuery.support.ownLast) for (key in obj) return core_hasOwn.call(obj, key);
            for (key in obj) ;
            return void 0 === key || core_hasOwn.call(obj, key);
        },
        isEmptyObject: function (obj) {
            var name;
            for (name in obj) return !1;
            return !0;
        },
        error: function (msg) {
            throw new Error(msg);
        },
        extend: function () {
            var src, copyIsArray, copy, name, options, clone, target = arguments[0] || {}, i = 1, length = arguments.length, deep = !1;
            for ("boolean" == typeof target && (deep = target, target = arguments[1] || {},
                i = 2), "object" == typeof target || jQuery.isFunction(target) || (target = {}),
                 length === i && (target = this, --i); length > i; i++) if (null != (options = arguments[i])) for (name in options) src = target[name],
                copy = options[name], target !== copy && (deep && copy && (jQuery.isPlainObject(copy) || (copyIsArray = jQuery.isArray(copy))) ? (copyIsArray ? (copyIsArray = !1,
                clone = src && jQuery.isArray(src) ? src : []) : clone = src && jQuery.isPlainObject(src) ? src : {},
                target[name] = jQuery.extend(deep, clone, copy)) : void 0 !== copy && (target[name] = copy));
            return target;
        }
    };
    return jQuery.extend;
}(), goog_isString = function (val) {
    return "string" == typeof val;
}, Md5 = function () {
    this.chain_ = new Array(4), this.block_ = new Array(64), this.blockLength_ = 0,
        this.totalLength_ = 0, this.reset();
};

Md5.prototype.reset = function () {
    this.chain_[0] = 1732584193, this.chain_[1] = 4023233417, this.chain_[2] = 2562383102,
        this.chain_[3] = 271733878, this.blockLength_ = 0, this.totalLength_ = 0;
}, Md5.prototype.compress_ = function (buf, opt_offset) {
    opt_offset || (opt_offset = 0);
    var X = new Array(16);
    if (goog_isString(buf)) for (var i = 0; 16 > i; ++i) X[i] = buf.charCodeAt(opt_offset++) | buf.charCodeAt(opt_offset++) << 8 | buf.charCodeAt(opt_offset++) << 16 | buf.charCodeAt(opt_offset++) << 24; else for (var i = 0; 16 > i; ++i) X[i] = buf[opt_offset++] | buf[opt_offset++] << 8 | buf[opt_offset++] << 16 | buf[opt_offset++] << 24;
    var A = this.chain_[0], B = this.chain_[1], C = this.chain_[2], D = this.chain_[3], sum = 0;
    sum = A + (D ^ B & (C ^ D)) + X[0] + 3614090360 & 4294967295, A = B + (sum << 7 & 4294967295 | sum >>> 25),
        sum = D + (C ^ A & (B ^ C)) + X[1] + 3905402710 & 4294967295, D = A + (sum << 12 & 4294967295 | sum >>> 20),
        sum = C + (B ^ D & (A ^ B)) + X[2] + 606105819 & 4294967295, C = D + (sum << 17 & 4294967295 | sum >>> 15),
        sum = B + (A ^ C & (D ^ A)) + X[3] + 3250441966 & 4294967295, B = C + (sum << 22 & 4294967295 | sum >>> 10),
        sum = A + (D ^ B & (C ^ D)) + X[4] + 4118548399 & 4294967295, A = B + (sum << 7 & 4294967295 | sum >>> 25),
        sum = D + (C ^ A & (B ^ C)) + X[5] + 1200080426 & 4294967295, D = A + (sum << 12 & 4294967295 | sum >>> 20),
        sum = C + (B ^ D & (A ^ B)) + X[6] + 2821735955 & 4294967295, C = D + (sum << 17 & 4294967295 | sum >>> 15),
        sum = B + (A ^ C & (D ^ A)) + X[7] + 4249261313 & 4294967295, B = C + (sum << 22 & 4294967295 | sum >>> 10),
        sum = A + (D ^ B & (C ^ D)) + X[8] + 1770035416 & 4294967295, A = B + (sum << 7 & 4294967295 | sum >>> 25),
        sum = D + (C ^ A & (B ^ C)) + X[9] + 2336552879 & 4294967295, D = A + (sum << 12 & 4294967295 | sum >>> 20),
        sum = C + (B ^ D & (A ^ B)) + X[10] + 4294925233 & 4294967295, C = D + (sum << 17 & 4294967295 | sum >>> 15),
        sum = B + (A ^ C & (D ^ A)) + X[11] + 2304563134 & 4294967295, B = C + (sum << 22 & 4294967295 | sum >>> 10),
        sum = A + (D ^ B & (C ^ D)) + X[12] + 1804603682 & 4294967295, A = B + (sum << 7 & 4294967295 | sum >>> 25),
        sum = D + (C ^ A & (B ^ C)) + X[13] + 4254626195 & 4294967295, D = A + (sum << 12 & 4294967295 | sum >>> 20),
        sum = C + (B ^ D & (A ^ B)) + X[14] + 2792965006 & 4294967295, C = D + (sum << 17 & 4294967295 | sum >>> 15),
        sum = B + (A ^ C & (D ^ A)) + X[15] + 1236535329 & 4294967295, B = C + (sum << 22 & 4294967295 | sum >>> 10),
        sum = A + (C ^ D & (B ^ C)) + X[1] + 4129170786 & 4294967295, A = B + (sum << 5 & 4294967295 | sum >>> 27),
        sum = D + (B ^ C & (A ^ B)) + X[6] + 3225465664 & 4294967295, D = A + (sum << 9 & 4294967295 | sum >>> 23),
        sum = C + (A ^ B & (D ^ A)) + X[11] + 643717713 & 4294967295, C = D + (sum << 14 & 4294967295 | sum >>> 18),
        sum = B + (D ^ A & (C ^ D)) + X[0] + 3921069994 & 4294967295, B = C + (sum << 20 & 4294967295 | sum >>> 12),
        sum = A + (C ^ D & (B ^ C)) + X[5] + 3593408605 & 4294967295, A = B + (sum << 5 & 4294967295 | sum >>> 27),
        sum = D + (B ^ C & (A ^ B)) + X[10] + 38016083 & 4294967295, D = A + (sum << 9 & 4294967295 | sum >>> 23),
        sum = C + (A ^ B & (D ^ A)) + X[15] + 3634488961 & 4294967295, C = D + (sum << 14 & 4294967295 | sum >>> 18),
        sum = B + (D ^ A & (C ^ D)) + X[4] + 3889429448 & 4294967295, B = C + (sum << 20 & 4294967295 | sum >>> 12),
        sum = A + (C ^ D & (B ^ C)) + X[9] + 568446438 & 4294967295, A = B + (sum << 5 & 4294967295 | sum >>> 27),
        sum = D + (B ^ C & (A ^ B)) + X[14] + 3275163606 & 4294967295, D = A + (sum << 9 & 4294967295 | sum >>> 23),
        sum = C + (A ^ B & (D ^ A)) + X[3] + 4107603335 & 4294967295, C = D + (sum << 14 & 4294967295 | sum >>> 18),
        sum = B + (D ^ A & (C ^ D)) + X[8] + 1163531501 & 4294967295, B = C + (sum << 20 & 4294967295 | sum >>> 12),
        sum = A + (C ^ D & (B ^ C)) + X[13] + 2850285829 & 4294967295, A = B + (sum << 5 & 4294967295 | sum >>> 27),
        sum = D + (B ^ C & (A ^ B)) + X[2] + 4243563512 & 4294967295, D = A + (sum << 9 & 4294967295 | sum >>> 23),
        sum = C + (A ^ B & (D ^ A)) + X[7] + 1735328473 & 4294967295, C = D + (sum << 14 & 4294967295 | sum >>> 18),
        sum = B + (D ^ A & (C ^ D)) + X[12] + 2368359562 & 4294967295, B = C + (sum << 20 & 4294967295 | sum >>> 12),
        sum = A + (B ^ C ^ D) + X[5] + 4294588738 & 4294967295, A = B + (sum << 4 & 4294967295 | sum >>> 28),
        sum = D + (A ^ B ^ C) + X[8] + 2272392833 & 4294967295, D = A + (sum << 11 & 4294967295 | sum >>> 21),
        sum = C + (D ^ A ^ B) + X[11] + 1839030562 & 4294967295, C = D + (sum << 16 & 4294967295 | sum >>> 16),
        sum = B + (C ^ D ^ A) + X[14] + 4259657740 & 4294967295, B = C + (sum << 23 & 4294967295 | sum >>> 9),
        sum = A + (B ^ C ^ D) + X[1] + 2763975236 & 4294967295, A = B + (sum << 4 & 4294967295 | sum >>> 28),
        sum = D + (A ^ B ^ C) + X[4] + 1272893353 & 4294967295, D = A + (sum << 11 & 4294967295 | sum >>> 21),
        sum = C + (D ^ A ^ B) + X[7] + 4139469664 & 4294967295, C = D + (sum << 16 & 4294967295 | sum >>> 16),
        sum = B + (C ^ D ^ A) + X[10] + 3200236656 & 4294967295, B = C + (sum << 23 & 4294967295 | sum >>> 9),
        sum = A + (B ^ C ^ D) + X[13] + 681279174 & 4294967295, A = B + (sum << 4 & 4294967295 | sum >>> 28),
        sum = D + (A ^ B ^ C) + X[0] + 3936430074 & 4294967295, D = A + (sum << 11 & 4294967295 | sum >>> 21),
        sum = C + (D ^ A ^ B) + X[3] + 3572445317 & 4294967295, C = D + (sum << 16 & 4294967295 | sum >>> 16),
        sum = B + (C ^ D ^ A) + X[6] + 76029189 & 4294967295, B = C + (sum << 23 & 4294967295 | sum >>> 9),
        sum = A + (B ^ C ^ D) + X[9] + 3654602809 & 4294967295, A = B + (sum << 4 & 4294967295 | sum >>> 28),
        sum = D + (A ^ B ^ C) + X[12] + 3873151461 & 4294967295, D = A + (sum << 11 & 4294967295 | sum >>> 21),
        sum = C + (D ^ A ^ B) + X[15] + 530742520 & 4294967295, C = D + (sum << 16 & 4294967295 | sum >>> 16),
        sum = B + (C ^ D ^ A) + X[2] + 3299628645 & 4294967295, B = C + (sum << 23 & 4294967295 | sum >>> 9),
        sum = A + (C ^ (B | ~D)) + X[0] + 4096336452 & 4294967295, A = B + (sum << 6 & 4294967295 | sum >>> 26),
        sum = D + (B ^ (A | ~C)) + X[7] + 1126891415 & 4294967295, D = A + (sum << 10 & 4294967295 | sum >>> 22),
        sum = C + (A ^ (D | ~B)) + X[14] + 2878612391 & 4294967295, C = D + (sum << 15 & 4294967295 | sum >>> 17),
    sum = B + (D ^ (C | ~A)) + X[5] + 4237533241 & 4294967295, B = C + (sum << 21 & 4294967295 | sum >>> 11),
    sum = A + (C ^ (B | ~D)) + X[12] + 1700485571 & 4294967295, A = B + (sum << 6 & 4294967295 | sum >>> 26),
    sum = D + (B ^ (A | ~C)) + X[3] + 2399980690 & 4294967295, D = A + (sum << 10 & 4294967295 | sum >>> 22),
    sum = C + (A ^ (D | ~B)) + X[10] + 4293915773 & 4294967295, C = D + (sum << 15 & 4294967295 | sum >>> 17),
    sum = B + (D ^ (C | ~A)) + X[1] + 2240044497 & 4294967295, B = C + (sum << 21 & 4294967295 | sum >>> 11),
    sum = A + (C ^ (B | ~D)) + X[8] + 1873313359 & 4294967295, A = B + (sum << 6 & 4294967295 | sum >>> 26),
    sum = D + (B ^ (A | ~C)) + X[15] + 4264355552 & 4294967295, D = A + (sum << 10 & 4294967295 | sum >>> 22),
    sum = C + (A ^ (D | ~B)) + X[6] + 2734768916 & 4294967295, C = D + (sum << 15 & 4294967295 | sum >>> 17),
    sum = B + (D ^ (C | ~A)) + X[13] + 1309151649 & 4294967295, B = C + (sum << 21 & 4294967295 | sum >>> 11),
    sum = A + (C ^ (B | ~D)) + X[4] + 4149444226 & 4294967295, A = B + (sum << 6 & 4294967295 | sum >>> 26),
    sum = D + (B ^ (A | ~C)) + X[11] + 3174756917 & 4294967295, D = A + (sum << 10 & 4294967295 | sum >>> 22),
    sum = C + (A ^ (D | ~B)) + X[2] + 718787259 & 4294967295, C = D + (sum << 15 & 4294967295 | sum >>> 17),
    sum = B + (D ^ (C | ~A)) + X[9] + 3951481745 & 4294967295, B = C + (sum << 21 & 4294967295 | sum >>> 11),
    this.chain_[0] = this.chain_[0] + A & 4294967295, this.chain_[1] = this.chain_[1] + B & 4294967295,
    this.chain_[2] = this.chain_[2] + C & 4294967295, this.chain_[3] = this.chain_[3] + D & 4294967295;
}, Md5.prototype.update = function (bytes, opt_length) {
    opt_length = opt_length || bytes.length;
    for (var lengthMinusBlock = opt_length - 64, block = this.block_, blockLength = this.blockLength_, i = 0; opt_length > i;) {
        if (0 == blockLength) for (; lengthMinusBlock >= i;) this.compress_(bytes, i), i += 64;
        if (goog_isString(bytes)) {
            for (; opt_length > i;) if (block[blockLength++] = bytes.charCodeAt(i++), 64 == blockLength) {
                this.compress_(block), blockLength = 0;
                break;
            }
        } else for (; opt_length > i;) if (block[blockLength++] = bytes[i++], 64 == blockLength) {
            this.compress_(block), blockLength = 0;
            break;
        }
    }
    this.blockLength_ = blockLength, this.totalLength_ += opt_length;
}, Md5.prototype.digest = function () {
    var pad = new Array((this.blockLength_ < 56 ? 64 : 128) - this.blockLength_);
    pad[0] = 128;
    for (var i = 1; i < pad.length - 8; ++i) pad[i] = 0;
    for (var totalBits = 8 * this.totalLength_, i = pad.length - 8; i < pad.length; ++i) pad[i] = 255 & totalBits,
        totalBits /= 256;
    this.update(pad);
    for (var digest = new Array(16), n = 0, i = 0; 4 > i; ++i) for (var j = 0; 32 > j; j += 8) digest[n++] = this.chain_[i] >>> j & 255;
    return digest;
};

var crypt_byteArrayToHex = function (array) {
    return array.map(function (numByte) {
        var hexByte = numByte.toString(16);
        return hexByte.length > 1 ? hexByte : "0" + hexByte;
    }).join("");
}, utilMakeMD5 = function () {
    var _md5 = new Md5();
    return function (str) {
        return _md5.reset(), _md5.update(str), crypt_byteArrayToHex(_md5.digest());
    };
}(), Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    e: function (input) {
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4, enc0, output = "", i = 0;
        for (input = Base64._ue(input); i < input.length;) chr1 = input.charCodeAt(i++),
            chr2 = input.charCodeAt(i++), chr3 = input.charCodeAt(i++), enc0 = chr2 >> 2, enc1 = chr1 >> 2,
            enc2 = (3 & chr1) << 4 | chr2 >> 4, enc3 = (15 & chr2) << 2 | chr3 >> 6, enc4 = 63 & chr3,
            isNaN(chr2) ? enc3 = enc4 = 64 : isNaN(chr3) && (enc4 = 64), output = output + Base64._keyStr.charAt(enc4) + Base64._keyStr.charAt(enc3) + Base64._keyStr.charAt(enc2) + Base64._keyStr.charAt(enc1) + Base64._keyStr.charAt(enc0);
        return output;
    },
    d: function (input) {
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4, enc0, output = "", i = 0;
        for (input = input.replace(/[^A-Za-z0-9\+\/\=]/g, ""); i < input.length;) enc4 = Base64._keyStr.indexOf(input.charAt(i++)),
            enc3 = Base64._keyStr.indexOf(input.charAt(i++)), enc2 = Base64._keyStr.indexOf(input.charAt(i++)),
            enc1 = Base64._keyStr.indexOf(input.charAt(i++)), enc0 = Base64._keyStr.indexOf(input.charAt(i++)),
            chr1 = enc1 << 2 | enc2 >> 4, chr2 = (15 & enc2) << 4 | enc3 >> 2, chr3 = (3 & enc3) << 6 | enc4,
            output += String.fromCharCode(chr1), 64 != enc3 && (output += String.fromCharCode(chr2)),
        64 != enc4 && (output += String.fromCharCode(chr3));
        return output = Base64._ud(output);
    },
    _ue: function (string) {
        string = string.replace(/\r\n/g, "\n");
        for (var utftext = "", n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            128 > c ? utftext += String.fromCharCode(c) : c > 127 && 2048 > c ? (utftext += String.fromCharCode(c >> 6 | 192),
                utftext += String.fromCharCode(63 & c | 128)) : (utftext += String.fromCharCode(c >> 12 | 224),
                utftext += String.fromCharCode(c >> 6 & 63 | 128), utftext += String.fromCharCode(63 & c | 128));
        }
        return utftext;
    },
    _ud: function (utftext) {
        for (var string = "", i = 0, c = c1 = c2 = 0; i < utftext.length;) c = utftext.charCodeAt(i),
            128 > c ? (string += String.fromCharCode(c), i++) : c > 191 && 224 > c ? (c2 = utftext.charCodeAt(i + 1),
                string += String.fromCharCode((31 & c) << 6 | 63 & c2), i += 2) : (c2 = utftext.charCodeAt(i + 1),
                c3 = utftext.charCodeAt(i + 2), string += String.fromCharCode((15 & c) << 12 | (63 & c2) << 6 | 63 & c3),
                i += 3);
        return string;
    }
}, utilCreateInternalTime = function (useMS) {
    var n = new Date();
    return 1 * n.getSeconds() + 100 * n.getMinutes() + 1e4 * n.getHours() + 1e4 * n.getDate() * 100 + 1e4 * (n.getMonth() + 1) * 1e4 + 1e4 * n.getFullYear() * 1e4 * 100 + (1 == useMS ? .001 * n.getMilliseconds() : 0);
}, utilImageResize = function () {
    var resizeCanvas = document && document.createElement ? document.createElement("canvas") : void 0, img = new Image();
    return img.crossOrigin = "anonymous", function (uri, width, height, quality, keepRatio, onSuccess, onFail) {
        if (onSuccess) {
            if (!width || !height || 0 > width || 0 > height) return void onSuccess(uri);
            img.onload = function (e) {
                var img = e.target;
                if (width === img.width && height === img.height) return void onSuccess(uri);
                var w = width, h = height;
                1 == keepRatio && (width / height < img.width / img.height ? h = img.height / img.width * width : w = img.width / img.height * height),
                    resizeCanvas.width = w, resizeCanvas.height = h;
                var resizeContext = resizeCanvas.getContext("2d");
                resizeContext.drawImage(img, 0, 0, w, h);
                var dataUrl = resizeCanvas.toDataURL("image/jpeg", quality);
                onSuccess(dataUrl);
            }, img.onerror = onFail, img.src = uri;
        }
    };
}();

goog_crypt_base64_byteToCharMap_ = null, goog_crypt_base64_charToByteMap_ = null,
    goog_crypt_base64_byteToCharMapWebSafe_ = null, goog_crypt_base64_charToByteMapWebSafe_ = null,
    goog_crypt_base64_ENCODED_VALS_BASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
    goog_crypt_base64_ENCODED_VALS = goog_crypt_base64_ENCODED_VALS_BASE + "+/=", goog_crypt_base64_ENCODED_VALS_WEBSAFE = goog_crypt_base64_ENCODED_VALS_BASE + "-_.",
    goog_crypt_base64_encodeByteArray = function (input, opt_webSafe) {
        goog_crypt_base64_init_();
        for (var byteToCharMap = opt_webSafe ? goog_crypt_base64_byteToCharMapWebSafe_ : goog_crypt_base64_byteToCharMap_, output = [], i = 0; i < input.length; i += 3) {
            var byte1 = input[i], haveByte2 = i + 1 < input.length, byte2 = haveByte2 ? input[i + 1] : 0, haveByte3 = i + 2 < input.length, byte3 = haveByte3 ? input[i + 2] : 0, outByte1 = byte1 >> 2, outByte2 = (3 & byte1) << 4 | byte2 >> 4, outByte3 = (15 & byte2) << 2 | byte3 >> 6, outByte4 = 63 & byte3;
            haveByte3 || (outByte4 = 64, haveByte2 || (outByte3 = 64)), output.push(byteToCharMap[outByte1], byteToCharMap[outByte2], byteToCharMap[outByte3], byteToCharMap[outByte4]);
        }
        return output.join("");
    }, goog_crypt_base64_encodeString = function (input, opt_webSafe) {
    return goog_crypt_base64_HAS_NATIVE_SUPPORT && !opt_webSafe ? goog.global.btoa(input) : goog_crypt_base64_encodeByteArray(goog.crypt.stringToByteArray(input), opt_webSafe);
}, goog_crypt_base64_decodeString = function (input, opt_webSafe) {
    return goog_crypt_base64_HAS_NATIVE_SUPPORT && !opt_webSafe ? goog.global.atob(input) : goog.crypt.byteArrayToString(goog_crypt_base64_decodeStringToByteArray(input, opt_webSafe));
}, goog_crypt_base64_decodeStringToByteArray = function (input, opt_webSafe) {
    goog_crypt_base64_init_();
    for (var charToByteMap = opt_webSafe ? goog_crypt_base64_charToByteMapWebSafe_ : goog_crypt_base64_charToByteMap_, output = [], i = 0; i < input.length;) {
        var byte1 = charToByteMap[input.charAt(i++)], haveByte2 = i < input.length, byte2 = haveByte2 ? charToByteMap[input.charAt(i)] : 0;
        ++i;
        var haveByte3 = i < input.length, byte3 = haveByte3 ? charToByteMap[input.charAt(i)] : 0;
        ++i;
        var haveByte4 = i < input.length, byte4 = haveByte4 ? charToByteMap[input.charAt(i)] : 0;
        if (++i, null == byte1 || null == byte2 || null == byte3 || null == byte4) throw Error();
        var outByte1 = byte1 << 2 | byte2 >> 4;
        if (output.push(outByte1), 64 != byte3) {
            var outByte2 = byte2 << 4 & 240 | byte3 >> 2;
            if (output.push(outByte2), 64 != byte4) {
                var outByte3 = byte3 << 6 & 192 | byte4;
                output.push(outByte3);
            }
        }
    }
    return output;
}, goog_crypt_base64_init_ = function () {
    if (!goog_crypt_base64_byteToCharMap_) {
        goog_crypt_base64_byteToCharMap_ = {}, goog_crypt_base64_charToByteMap_ = {}, goog_crypt_base64_byteToCharMapWebSafe_ = {},
            goog_crypt_base64_charToByteMapWebSafe_ = {};
        for (var i = 0; i < goog_crypt_base64_ENCODED_VALS.length; i++) goog_crypt_base64_byteToCharMap_[i] = goog_crypt_base64_ENCODED_VALS.charAt(i),
            goog_crypt_base64_charToByteMap_[goog_crypt_base64_byteToCharMap_[i]] = i, goog_crypt_base64_byteToCharMapWebSafe_[i] = goog_crypt_base64_ENCODED_VALS_WEBSAFE.charAt(i),
            goog_crypt_base64_charToByteMapWebSafe_[goog_crypt_base64_byteToCharMapWebSafe_[i]] = i;
    }
}, Line.prototype.clone = function () {
    return new Line(this.x0, this.y0, this.x1, this.y1);
}, Line.prototype.equals = function (other) {
    return this.x0 == other.x0 && this.y0 == other.y0 && this.x1 == other.x1 && this.y1 == other.y1;
}, Line.prototype.lengthSquared = function () {
    var xdist = this.x1 - this.x0, ydist = this.y1 - this.y0;
    return xdist * xdist + ydist * ydist;
}, Line.prototype.length = function () {
    return Math.sqrt(this.lengthSquared());
}, Line.prototype.closestInte_ = function (x, opt_y) {
    var y = opt_y, x0 = this.x0, y0 = this.y0, xChange = this.x1 - x0, yChange = this.y1 - y0;
    return ((x - x0) * xChange + (y - y0) * yChange) / this.lengthSquared();
}, Line.prototype.getInterpolatedPoint = function (t) {
    function lerp(a, b, x) {
        return a + x * (b - a);
    }

    return {
        x: lerp(this.x0, this.x1, t),
        y: lerp(this.y0, this.y1, t)
    };
}, Line.prototype.getClosestPoint = function (x, opt_y) {
    return this.getInterpolatedPoint(this.closestInte_(x, opt_y));
}, Line.prototype.getClosestSegmentPoint = function (x, opt_y) {
    function clamp(value, min, max) {
        return Math.min(Math.max(value, min), max);
    }

    return this.getInterpolatedPoint(clamp(this.closestInte_(x, opt_y), 0, 1));
}, Bound.prototype.clone = function () {
    return new Bound(this.left, this.top, this.width, this.height);
}, Bound.prototype.toString = function () {
    return "(" + this.left + ", " + this.top + " - " + this.width + "w x " + this.height + "h)";
}, Bound.equals = function (a, b) {
    return a == b ? !0 : a && b ? a.left == b.left && a.width == b.width && a.top == b.top && a.height == b.height : !1;
}, Bound.prototype.intersection = function (rect) {
    var x0 = Math.max(this.left, rect.left), x1 = Math.min(this.left + this.width, rect.left + rect.width);
    if (x1 >= x0) {
        var y0 = Math.max(this.top, rect.top), y1 = Math.min(this.top + this.height, rect.top + rect.height);
        if (y1 >= y0) return this.left = x0, this.top = y0, this.width = x1 - x0, this.height = y1 - y0,
            !0;
    }
    return !1;
}, Bound.intersection = function (a, b) {
    var x0 = Math.max(a.left, b.left), x1 = Math.min(a.left + a.width, b.left + b.width);
    if (x1 >= x0) {
        var y0 = Math.max(a.top, b.top), y1 = Math.min(a.top + a.height, b.top + b.height);
        if (y1 >= y0) return new Bound(x0, y0, x1 - x0, y1 - y0);
    }
    return null;
}, Bound.intersects = function (a, b) {
    return a.left <= b.left + b.width && b.left <= a.left + a.width && a.top <= b.top + b.height && b.top <= a.top + a.height;
}, Bound.prototype.intersects = function (rect) {
    return Bound.intersects(this, rect);
};

var utilBoundDifference = function (a, b) {
    var intersection = Bound.intersection(a, b);
    if (!intersection || !intersection.height || !intersection.width) return [a.clone()];
    var result = [], top = a.top, height = a.height, ar = a.left + a.width, ab = a.top + a.height, br = b.left + b.width, bb = b.top + b.height;
    return b.top > a.top && (result.push(new Bound(a.left, a.top, a.width, b.top - a.top)),
        top = b.top, height -= b.top - a.top), ab > bb && (result.push(new Bound(a.left, bb, a.width, ab - bb)),
        height = bb - top), b.left > a.left && result.push(new Bound(a.left, top, b.left - a.left, height)),
    ar > br && result.push(new Bound(br, top, ar - br, height)), result;
};

Bound.prototype.difference = function (rect) {
    return Bound.difference(this, rect);
}, Bound.prototype.boundingRect = function (rect) {
    var right = Math.max(this.left + this.width, rect.left + rect.width), bottom = Math.max(this.top + this.height, rect.top + rect.height);
    this.left = Math.min(this.left, rect.left), this.top = Math.min(this.top, rect.top),
        this.width = right - this.left, this.height = bottom - this.top;
};

var utilBoundBoundingRect = function (a, b) {
    if (!a || !b) return null;
    var clone = a.clone();
    return clone.boundingRect(b), clone;
};

Bound.prototype.contains = function (another) {
    return another instanceof Bound ? this.left <= another.left && this.left + this.width >= another.left + another.width && this.top <= another.top && this.top + this.height >= another.top + another.height : another.x >= this.left && another.x <= this.left + this.width && another.y >= this.top && another.y <= this.top + this.height;
}, Bound.prototype.ceil = function () {
    return this.left = Math.ceil(this.left), this.top = Math.ceil(this.top), this.width = Math.ceil(this.width),
        this.height = Math.ceil(this.height), this;
}, Bound.prototype.floor = function () {
    return this.left = Math.floor(this.left), this.top = Math.floor(this.top), this.width = Math.floor(this.width),
        this.height = Math.floor(this.height), this;
}, Bound.prototype.round = function () {
    return this.left = Math.round(this.left), this.top = Math.round(this.top), this.width = Math.round(this.width),
        this.height = Math.round(this.height), this;
}, Bound.prototype.translate = function (tx, opt_ty) {
    return tx.x ? (this.left += tx.x, this.top += tx.y) : (this.left += tx, opt_ty && (this.top += opt_ty)),
        this;
}, Bound.prototype.scale = function (sx, opt_sy) {
    var sy = opt_sy ? opt_sy : sx;
    return this.left *= sx, this.width *= sx, this.top *= sy, this.height *= sy, this;
}, Bound.prototype.center = function () {
    return {
        x: this.left + this.width / 2,
        y: this.top + this.height / 2
    };
}, Bound.prototype.radius = function () {
    return Math.sqrt(this.width * this.width + this.height * this.height) / 2;
}, Vec2.randomUnit = function () {
    var angle = Math.random() * Math.PI * 2;
    return new Vec2(Math.cos(angle), Math.sin(angle));
}, Vec2.random = function () {
    var mag = Math.sqrt(Math.random()), angle = Math.random() * Math.PI * 2;
    return new Vec2(Math.cos(angle) * mag, Math.sin(angle) * mag);
}, Vec2.fromCoordinate = function (a) {
    return new Vec2(a.x, a.y);
}, Vec2.prototype.clone = function () {
    return new Vec2(this.x, this.y);
}, Vec2.prototype.magnitude = function () {
    return Math.sqrt(this.x * this.x + this.y * this.y);
}, Vec2.prototype.squaredMagnitude = function () {
    return this.x * this.x + this.y * this.y;
}, Vec2.prototype.scale = function (sx, opt_sy) {
    var sy = opt_sy ? opt_sy : sx;
    return this.x *= sx, this.y *= sy, this;
}, Vec2.prototype.invert = function () {
    return this.x = -this.x, this.y = -this.y, this;
}, Vec2.prototype.normalize = function () {
    return this.scale(1 / this.magnitude());
}, Vec2.prototype.add = function (b) {
    return this.x += b.x, this.y += b.y, this;
}, Vec2.prototype.subtract = function (b) {
    return this.x -= b.x, this.y -= b.y, this;
}, Vec2.prototype.rotate = function (angle) {
    var cos = Math.cos(angle), sin = Math.sin(angle), newX = this.x * cos - this.y * sin, newY = this.y * cos + this.x * sin;
    return this.x = newX, this.y = newY, this;
}, Vec2.rotateAroundPoint = function (v, axisPoint, angle) {
    var res = v.clone();
    return res.subtract(axisPoint).rotate(angle).add(axisPoint);
}, Vec2.prototype.equals = function (b) {
    return this == b || !!b && this.x == b.x && this.y == b.y;
}, Vec2.sum = function (a, b) {
    return new Vec2(a.x + b.x, a.y + b.y);
}, Vec2.difference = function (a, b) {
    return new Vec2(a.x - b.x, a.y - b.y);
}, Vec2.dot = function (a, b) {
    return a.x * b.x + a.y * b.y;
}, Vec2.lerp = function (a, b, x) {
    function lerp(a, b, x) {
        return a + x * (b - a);
    }

    return new Vec2(lerp(a.x, b.x, x), lerp(a.y, b.y, x));
}, Vec2.getRotAngle = function (base, from, to) {
    return utilMathLinelineCCWAngle(base, from, to);
};

//旋转控制-- gaoning
var utilMathRotationSnap = function () {
    var snapAngles = [0, 45, 90, 135, 180, 225, 270, 315, 360];
    var snapLen = snapAngles.length;
    return function (angle) {
        for (var a = Math.round(angle), i = 0; snapLen > i; ++i) {
            var snap = snapAngles[i];
            if (Math.abs(a - snap) < 3) {
                a = snap;
                break;
            }
        }
        return a;
    };
}(), Bezier = function (p0, p1, p2, p3) {
    this.x0 = p0.x, this.y0 = p0.y, this.x1 = p1.x, this.y1 = p1.y, this.x2 = p2.x,
        this.y2 = p2.y, this.x3 = p3.x, this.y3 = p3.y;
}, goog_math_lerp = function (a, b, x) {
    return a + x * (b - a);
};

Bezier.KAPPA = 4 * (Math.sqrt(2) - 1) / 3, Bezier.prototype.getPointQ = function (t) {
    var x = (1 - t) * (1 - t) * this.x0 + 2 * (1 - t) * t * this.x1 + t * t * this.x3, y = (1 - t) * (1 - t) * this.y0 + 2 * (1 - t) * t * this.y1 + t * t * this.y3;
    return {
        x: x,
        y: y
    };
}, Bezier.prototype.getPointC = function (t) {
    if (0 == t) return {
        x: this.x0,
        y: this.y0
    };
    if (1 == t) return {
        x: this.x3,
        y: this.y3
    };
    var ix0 = goog_math_lerp(this.x0, this.x1, t), iy0 = goog_math_lerp(this.y0, this.y1, t), ix1 = goog_math_lerp(this.x1, this.x2, t), iy1 = goog_math_lerp(this.y1, this.y2, t), ix2 = goog_math_lerp(this.x2, this.x3, t), iy2 = goog_math_lerp(this.y2, this.y3, t);
    return ix0 = goog_math_lerp(ix0, ix1, t), iy0 = goog_math_lerp(iy0, iy1, t), ix1 = goog_math_lerp(ix1, ix2, t),
        iy1 = goog_math_lerp(iy1, iy2, t), {
        x: goog_math_lerp(ix0, ix1, t),
        y: goog_math_lerp(iy0, iy1, t)
    };
};

var httpclient = "undefined" != typeof httpclient ? httpclient : "undefined" != typeof $ ? $ : {};

httpclient.ajax = httpclient.ajax || function (obj) {
        __assert(!1, "not implemented function!");
    };

var utilAdaptorClipperExecute = function () {
    var cp = new ClipperLib.Clipper();
    new ClipperLib.PolyTree();
    return function (positives, negatives, algorithm) {
        var solution = new ClipperLib.Paths();
        cp.Clear();
        cp.AddPaths(positives, ClipperLib.PolyType.ptSubject, !0);
        negatives && cp.AddPaths(negatives, ClipperLib.PolyType.ptClip, !0);
        cp.Execute(algorithm, solution);
        return solution;
    };
}();
var utilAdaptorClipperOffset = function () {
    var co = new ClipperLib.ClipperOffset(2, 0.25);
    var solution = new ClipperLib.Paths();
    var scaleFactor = 1e4;

    return function (profile, offset) {
        for (var path = [], i = 0, len = profile.length; len > i; ++i) {
            var p = profile[i];
            path.push({
                X: p.x,
                Y: p.y
            });
        }
        if (ClipperLib.JS.ScaleUpPath(path, scaleFactor), co.Clear(), co.AddPath(path, ClipperLib.JoinType.jtMiter, ClipperLib.EndType.etClosedPolygon),
                co.Execute(solution, offset * scaleFactor), ClipperLib.JS.ScaleDownPaths(solution, scaleFactor),
                solution[0]) {
            var rv = solution[0].map(function (pt) {
                return {
                    x: pt.X,
                    y: pt.Y
                };
            });
            return rv;
        }
    };
}();
var utilAdaptorClipperOffsetArray = function () {
    var co = new ClipperLib.ClipperOffset(2, 0.25);
    var solution = new ClipperLib.Paths();
    var scaleFactor = 1e4;

    return function (profile, offset) {
        for (var path = [], i = 0, len = profile.length; len > i; ++i) {
            var p = profile[i];
            path.push({
                X: p.x,
                Y: p.y
            });
        }
        if (ClipperLib.JS.ScaleUpPath(path, scaleFactor), co.Clear(), co.AddPath(path, ClipperLib.JoinType.jtMiter, ClipperLib.EndType.etClosedPolygon),
                co.Execute(solution, offset * scaleFactor), ClipperLib.JS.ScaleDownPaths(solution, scaleFactor),
                solution) {
            var rvs = [];
            solution.forEach(function(so){
            	var rv = so.map(function (pt) {
	                return {
	                    x: pt.X,
	                    y: pt.Y
	                };
	            });
	            rvs.push(rv);
            });            
            return rvs;
        }
    };
}();
var utilAdaptorClipperExtend = function () {
    var co = new ClipperLib.ClipperOffset(100, 0.25);
    var solution = new ClipperLib.Paths();
    var scaleFactor = 1e3;

    return function (profile, offset) {
        for (var path = [], i = 0, len = profile.length; len > i; ++i) {
            var p = profile[i];
            path.push({
                X: p.x,
                Y: p.y
            });
        }
        if (ClipperLib.JS.ScaleUpPath(path, scaleFactor), co.Clear(), co.AddPath(path, ClipperLib.JoinType.jtMiter, ClipperLib.EndType.etClosedPolygon),
                co.Execute(solution, offset * scaleFactor), ClipperLib.JS.ScaleDownPaths(solution, scaleFactor),
                solution[0]) {
            var rv = solution[0].map(function (pt) {
                return {
                    x: pt.X,
                    y: pt.Y
                };
            });
            return rv;
        }
    };
}();
var utilAdaptorClipperExtendArray = function () {
    var co = new ClipperLib.ClipperOffset(100, 0.25);
    var solution = new ClipperLib.Paths();
    var scaleFactor = 1e3;

    return function (profile, offset) {
        for (var path = [], i = 0, len = profile.length; len > i; ++i) {
            var p = profile[i];
            path.push({
                X: p.x,
                Y: p.y
            });
        }
        if (ClipperLib.JS.ScaleUpPath(path, scaleFactor), co.Clear(), co.AddPath(path, ClipperLib.JoinType.jtMiter, ClipperLib.EndType.etClosedPolygon),
                co.Execute(solution, offset * scaleFactor), ClipperLib.JS.ScaleDownPaths(solution, scaleFactor),
                solution[0]) {
            var rv = solution[0].map(function (pt) {
                return {
                    x: pt.X,
                    y: pt.Y
                };
            });
            return rv;
        }
    };
}();
var utilAdaptorClipperArea = function (path) {
    return ClipperLib.Clipper.Area(path);
};

var utilFloorMaterialOrigin = function (loop) {
    if (loop.length == 0) {
        return {x: 0, y: 0};
    }

    var origin = {x: loop[0].x, y: loop[0].y};
    for (var i = 1; i < loop.length; i++) {
        origin.x = Math.min(origin.x, loop[i].x);
        origin.y = Math.min(origin.y, loop[i].y);
    }
    return origin;
}


//对solution裁剪后的内容进行挖空
function clipperFromSH(solution, holds, extra) {

    holds.forEach(function (area) {
        var cpr = new ClipperLib.Clipper();

        var paths = [];
        if (solution) {
            for (var i = 0; i < solution.m_AllPolys.length; ++i) {
                var line = [];
                line.push({X: solution.m_AllPolys[i].m_polygon[0].X, Y: solution.m_AllPolys[i].m_polygon[0].Y});
                line.push({X: solution.m_AllPolys[i].m_polygon[1].X, Y: solution.m_AllPolys[i].m_polygon[1].Y});
                paths.push(line);
            }
        }

        //添加额外线段
        if (extra) {
            for (var i = 0; i < extra.length; ++i) {
                var line = [];
                line.push({X: extra[i][0].X, Y: extra[i][0].Y});
                line.push({X: extra[i][1].X, Y: extra[i][1].Y});
                paths.push(line);
            }
            extra = null;//只需要添加一次额外线段
        }

        var clipPaths = [];
        var wallPoly = [];
        for (var i = 0; i < area.loop.length - 1; ++i) {
            wallPoly.push({X: Math.ceil(area.loop[i].x * 1000), Y: Math.ceil(area.loop[i].y * 1000)});
        }

        if (wallPoly.length > 0) {
            clipPaths.push(wallPoly);

            cpr.AddPaths(paths, ClipperLib.PolyType.ptSubject, false);
            cpr.AddPaths(clipPaths, ClipperLib.PolyType.ptClip, true);

            solution = new ClipperLib.PolyTree();
            cpr.Execute(ClipperLib.ClipType.ctDifference, solution);
        }
    });

    return solution;
}

//创建铺贴线段
function createAreaPavement(arealoop, areadata) {
    var material = areadata.areaMaterial;
    var rot = areadata.rot;
    var center = areadata.center;	//作为旋转的中心点,缺乏center的,不需要进行旋转处理

    var loop = [];
    for (var i = 0; i < arealoop.length; ++i) {
        if (center) {
            var point = api.mathRotatePointCW(center, arealoop[i], -rot);
            loop.push(point);
        } else {
            loop.push(arealoop[i]);
        }
    }

    var origin = null;
    for (var i = 0; i < loop.length; ++i) {
        var point = api.mathRotatePointCW({x: 0, y: 0}, loop[i], 0);
        if (!origin) {
            origin = {};
            origin.x = point.x;
            origin.y = point.y;
        } else {
            origin.x = Math.min(point.x, origin.x);
            origin.y = Math.min(point.y, origin.y);
        }
    }

    //把房间的所有顶点先转换为地砖的坐标系,并求得需要绘制铺砖线段的总区域
    var meterialRect = null;
    for (var i = 0; i < loop.length; ++i) {
        var materialLoop = {};
        materialLoop.x = loop[i].x - origin.x - material.tx;
        materialLoop.y = loop[i].y - origin.y - material.ty;
        var point = api.mathRotatePointCW({x: 0, y: 0}, materialLoop, -material.rot);

        if (!meterialRect) {
            meterialRect = {};
            meterialRect.l = point.x;
            meterialRect.r = point.x;
            meterialRect.t = point.y;
            meterialRect.b = point.y;
        } else {
            meterialRect.l = Math.min(point.x, meterialRect.l);
            meterialRect.r = Math.max(point.x, meterialRect.r);
            meterialRect.b = Math.min(point.y, meterialRect.b);
            meterialRect.t = Math.max(point.y, meterialRect.t);
        }
    }
    //计算水平方向
    var floorW = material.meta.xlen * material.sx;
    var hPoints = [];
    for (var i = Math.floor(meterialRect.l / floorW); i <= 0; ++i) {
        hPoints.push(i * floorW);
    }
    for (var i = 1; i <= Math.ceil(meterialRect.r / floorW); ++i) {
        hPoints.push(i * floorW);
    }

    //计算垂直方向
    var floorH = material.meta.ylen * material.sy;
    var vPoints = [];
    for (var i = Math.floor(meterialRect.b / floorH); i <= 0; ++i) {
        vPoints.push(i * floorH);
    }
    for (var i = 1; i <= Math.ceil(meterialRect.t / floorH); ++i) {
        vPoints.push(i * floorH);
    }

    //计算两个方向的线段
    var lineRect = {};
    lineRect.l = hPoints[0];
    lineRect.r = hPoints[hPoints.length - 1];
    lineRect.b = vPoints[0];
    lineRect.t = vPoints[vPoints.length - 1];

    var materialAreaToFloorArea = function (point) {
        var ret = {};
        ret = api.mathRotatePointCW({x: 0, y: 0}, point, material.rot);
        ret.x = ret.x + origin.x + material.tx;
        ret.y = ret.y + origin.y + material.ty;
        return ret;
    }

    var lines = [];
    hPoints.forEach(function (hPoint) {
        var line = [];
        line.push(materialAreaToFloorArea({x: hPoint, y: lineRect.b}));
        line.push(materialAreaToFloorArea({x: hPoint, y: lineRect.t}));
        lines.push(line);
    });
    vPoints.forEach(function (vPoint) {
        var line = [];
        line.push(materialAreaToFloorArea({x: lineRect.l, y: vPoint}));
        line.push(materialAreaToFloorArea({x: lineRect.r, y: vPoint}));
        lines.push(line);
    });

    for (var i = 0; i < lines.length; ++i) {
        var line = [];
        if (center) {
            line.push(api.mathRotatePointCW(center, lines[i][0], rot));
            line.push(api.mathRotatePointCW(center, lines[i][1], rot));
        } else {
            line.push(lines[i][0]);
            line.push(lines[i][1]);
        }

        lines[i] = line;
    }

    return lines;
}


//add by gaoning 2016.8.17 判断点是否在多边形内
//*****************************************************************************************
//计算向量叉乘  
var crossMul = function (v1, v2) {
    return v1.x * v2.y - v1.y * v2.x;
}
//javascript判断两条线段是否相交  
var checkCross = function (p1, p2, p3, p4) {
    var v1 = {x: p1.x - p3.x, y: p1.y - p3.y};
    var v2 = {x: p2.x - p3.x, y: p2.y - p3.y};
    var v3 = {x: p4.x - p3.x, y: p4.y - p3.y};
    var v = crossMul(v1, v3) * crossMul(v2, v3);
    v1 = {x: p3.x - p1.x, y: p3.y - p1.y};
    v2 = {x: p4.x - p1.x, y: p4.y - p1.y};
    v3 = {x: p2.x - p1.x, y: p2.y - p1.y};
    return (v <= 0 && crossMul(v1, v3) * crossMul(v2, v3) <= 0) ? true : false;
}
//判断点是否在多边形内  
var checkPointInPolygon = function (point, polygon) {
    var p1, p2, p3, p4;
    p1 = point;
    p2 = {x: -100, y: point.y};
    var count = 0;
    //对每条边都和射线作对比  
    for (var i = 0; i < polygon.length - 1; i++) {
        p3 = polygon[i];
        p4 = polygon[i + 1];
        if (checkCross(p1, p2, p3, p4) == true) {
            count++;
        }
    }
    p3 = polygon[polygon.length - 1];
    p4 = polygon[0];
    if (checkCross(p1, p2, p3, p4) == true) {
        count++;
    }
    //console.log(count)  
    return (count % 2 == 0) ? false : true;
}

//求点与线段的距离p1 p2 为线段两端点，p为线段外的点--add by gaoning 2018.4.12
function getDistFromPointToLine(p1,p2,p) {

    var x1 = p1.x,y1 = p1.y,x2 = p2.x,y2 = p2.y,xx = p.x,yy = p.y;

    var a, b, c, ang1, ang2, ang, m;
    var result = 0;
    //分别计算三条边的长度
    a = Math.sqrt((x1 - xx) * (x1 - xx) + (y1 - yy) * (y1 - yy));
    if (a == 0)
        return -1;
    b = Math.sqrt((x2 - xx) * (x2 - xx) + (y2 - yy) * (y2 - yy));
    if (b == 0)
        return -1;
    c = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    //如果线段是一个点则退出函数并返回距离
    if (c == 0) {
        result = a;
        return result;
    }
    //如果点(xx,yy到点x1,y1)这条边短
    if (a < b) {
        //如果直线段AB是水平线。得到直线段AB的弧度
        if (y1 == y2) {
            if (x1 < x2)
                ang1 = 0;
            else
                ang1 = Math.PI;
        }
        else {
            m = (x2 - x1) / c;
            if (m - 1 > 0.00001)
                m = 1;
            ang1 = Math.acos(m);
            if (y1 > y2)
                ang1 = Math.PI * 2 - ang1;//直线(x1,y1)-(x2,y2)与折X轴正向夹角的弧度
        }
        m = (xx - x1) / a;
        if (m - 1 > 0.00001)
            m = 1;
        ang2 = Math.acos(m);
        if (y1 > yy)
            ang2 = Math.PI * 2 - ang2;//直线(x1,y1)-(xx,yy)与折X轴正向夹角的弧度

        ang = ang2 - ang1;
        if (ang < 0) ang = -ang;

        if (ang > Math.PI) ang = Math.PI * 2 - ang;
        //如果是钝角则直接返回距离
        if (ang > Math.PI / 2)
            return a;
        else
            return a * Math.sin(ang);
    }
    else//如果(xx,yy)到点(x2,y2)这条边较短
    {
        //如果两个点的纵坐标相同，则直接得到直线斜率的弧度
        if (y1 == y2)
            if (x1 < x2)
                ang1 = Math.PI;
            else
                ang1 = 0;
        else {
            m = (x1 - x2) / c;
            if (m - 1 > 0.00001)
                m = 1;
            ang1 = Math.acos(m);
            if (y2 > y1)
                ang1 = Math.PI * 2 - ang1;
        }
        m = (xx - x2) / b;
        if (m - 1 > 0.00001)
            m = 1;
        ang2 = Math.acos(m);//直线(x2-x1)-(xx,yy)斜率的弧度
        if (y2 > yy)
            ang2 = Math.PI * 2 - ang2;
        ang = ang2 - ang1;
        if (ang < 0) ang = -ang;
        if (ang > Math.PI) ang = Math.PI * 2 - ang;//交角的大小
        //如果是对角则直接返回距离
        if (ang > Math.PI / 2)
            return b;
        else
            return b * Math.sin(ang);//如果是锐角，返回计算得到的距离
    }
}

//*********************************************************************************

function utilFloorInsideLoopFromProfile(floor) {
    var floorLoop = utilFloorGetLoopFromProfile(floor);
    //if(floorLoop)
    //    floorLoop = utilAdaptorClipperOffset(floorLoop, -0.010); //10毫米内部,解决其他墙体嵌入问题
    
    //检查所有转角的wall是否在房间内部，如果属于房间内部，加入队列中
    var fp = application.doc.floorplan;
    var profile = floor.profile;
    var allProfile = {};
    profile.forEach(function(wall){ 
    	allProfile[wall.id] = wall;
    });
    
    var geom = [];
    if(profile.length >= 3){
    	var fp = application.doc.floorplan;
	    //确定中心点位于墙的左侧还是右侧，展开获得内墙线
	    	    
	    var wallStart = profile[0];
	    var wall = wallStart;
	    var wallCenter = {x:(wall.begin.x + wall.end.x)*0.5, y:(wall.begin.y + wall.end.y)*0.5};
	    var wallDir = new Vec2(wall.end.x - wall.begin.x, wall.end.y - wall.begin.y);	    
	    var wallDirOffset = wallDir.normalize().scale(0.01);
	    var v12 = Vec2.rotateAroundPoint(wallDirOffset.clone().add(wallCenter), wallCenter, -Math.PI / 2);
	    
	    var wallLoop = utilModelWallGetTessellates(wall, !1);	    	   	    
	    var concatBezierLoop = function(loop, index, backward){
	    	var len = loop[index].length;
	    	if(backward){
	    		//逆向	    		
	    		for(var i=0;i<len;++i){
		    		geom.push(loop[index][len - i - 1]);
		    	}
	    	}else{
	    		for(var i=0;i<len;++i){
		    		geom.push(loop[index][i]);
		    	}
	    	}	    	
	    }
	    
	    if(utilMathIsPointInPoly(floorLoop, v12)){
	    	//右转
	    	if(wall.bezier){
	    		geom.push(wallLoop[1]);	    		
	    		concatBezierLoop(wallLoop, 7, false);
	    		geom.push(wallLoop[2]);
	    	}else{
	    		geom.push(wallLoop[1],wallLoop[2]);
	    	}	    	
	    	var turnType = 0;//0 endRight 1:beginRight
	    	var loopNum = 0;
	    	while(1){
	    		loopNum++;
	    		if(loopNum > 100){
	    			return [];
	    		}
	    		if(turnType == 0){
	    			var turnRight = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !0);
	    			if(turnRight){
	    				wall = turnRight.road;
	    				if(wall == wallStart){
	    					//结束
		    				break;
		    			}
	    				wallLoop = utilModelWallGetTessellates(wall, !1);
	    				if(turnRight.sameRoadDir){
		    				turnType = 0;
		    				if(wall.bezier){
					    		concatBezierLoop(wallLoop, 7, false);					    		
					    	}
					    	geom.push(wallLoop[2]);					    	
		    			}else{
		    				turnType = 1;
		    				if(wall.bezier){
					    		concatBezierLoop(wallLoop, 8, false);
					    	}
					    	geom.push(wallLoop[5]);
		    			}		    					    			
	    			}else{
	    				//断头(end)
	    				turnType = 1;
	    				geom.push(wallLoop[4]);
	    				if(wall.bezier){
				    		concatBezierLoop(wallLoop, 8, false);					    		
				    	}
				    	geom.push(wallLoop[5]);
	    			}	    			
	    		}else{
	    			var turnRight = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !0);
	    			if(turnRight){
	    				wall = turnRight.road;
	    				if(wall == wallStart){
		    				break;
		    			}
	    				wallLoop = utilModelWallGetTessellates(wall, !1);
	    				if(turnRight.sameRoadDir){
	    					turnType = 0;
	    					if(wall.bezier){
					    		concatBezierLoop(wallLoop, 7, false);
					    	}
					    	geom.push(wallLoop[2]);
		    			}else{
		    				turnType = 1;
		    				if(wall.bezier){
					    		concatBezierLoop(wallLoop, 8, false);					    		
					    	}
					    	geom.push(wallLoop[5]);
		    			}
	    			}else{
	    				//断头(begin)
	    				turnType = 0;
	    				geom.push(wallLoop[1]);
	    				if(wall.bezier){
				    		concatBezierLoop(wallLoop, 7, false);					    		
				    	}
				    	geom.push(wallLoop[2]);
	    			}	    			
	    		}
	    	}
	    }else{
	    	//左转
	    	if(wall.bezier){
	    		geom.push(wallLoop[5]);
	    		concatBezierLoop(wallLoop, 8, true);
	    		geom.push(wallLoop[4]);
	    	}else{
	    		geom.push(wallLoop[5],wallLoop[4]);
	    	}
	    	var turnType = 0;//0 endLeft 1:beginLeft
	    	var loopNum = 0;
	    	while(1){
	    		loopNum++;
	    		if(loopNum > 100){
	    			return [];
	    		}
	    		if(turnType == 0){
	    			var turnLeft = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !1);
	    			if(turnLeft){
	    				wall = turnLeft.road;
	    				if(wall == wallStart){
	    					//结束
		    				break;
		    			}
	    				wallLoop = utilModelWallGetTessellates(wall, !1);
	    				if(turnLeft.sameRoadDir){
		    				turnType = 0;
		    				if(wall.bezier){
					    		concatBezierLoop(wallLoop, 8, true);
					    	}
					    	geom.push(wallLoop[4]);			    	
		    			}else{
		    				turnType = 1;
		    				if(wall.bezier){
					    		concatBezierLoop(wallLoop, 7, true);					    		
					    	}
					    	geom.push(wallLoop[1]);	
		    			}		    					    			
	    			}else{
	    				//断头(end)
	    				turnType = 1;
	    				geom.push(wallLoop[2]);
	    				if(wall.bezier){
				    		concatBezierLoop(wallLoop, 7, true);
				    	}
				    	geom.push(wallLoop[1]);
	    			}
	    		}else{
	    			var turnLeft = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !1);
	    			if(turnLeft){
	    				wall = turnLeft.road;
	    				if(wall == wallStart){
		    				break;
		    			}
	    				wallLoop = utilModelWallGetTessellates(wall, !1);
	    				if(turnLeft.sameRoadDir){
	    					turnType = 0;
	    					if(wall.bezier){
					    		concatBezierLoop(wallLoop, 8, true);					    		
					    	}
					    	geom.push(wallLoop[4]);
		    			}else{
		    				turnType = 1;
		    				if(wall.bezier){
					    		concatBezierLoop(wallLoop, 7, true);
					    	}
					    	geom.push(wallLoop[1]);
		    			}
	    			}else{
	    				//断头(begin)
	    				turnType = 0;
	    				geom.push(wallLoop[4]);
	    				if(wall.bezier){
				    		concatBezierLoop(wallLoop, 7, true);					    		
				    	}
				    	geom.push(wallLoop[1]);
	    			}	 
	    		}
	    	}
	    }
	  }
    
    //检查墙体是否在房间内
    //var isInFloor = function(wall){
    //	if(utilMathIsPointInPoly(floorLoop, wall.begin)){
    //		return true;
    //	}
    //	if(utilMathIsPointInPoly(floorLoop, wall.end)){
    //		return true;
    //	}
    //	return false;
    //}
    //
    ////加入到墙体列表中
    //var insertToProfile = function(insert){
    //	if(insert && !allProfile[insert.road.id] && isInFloor(insert.road)){
    //  	allProfile[insert.road.id] = insert.road;
    //  	profile.push(insert.road);
    //  }
    //}
    //
    //profile.forEach(function(wall){
    //  var beginTurnLeft = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !1);
    //  var beginTurnRight = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !0);
    //  var endTurnLeft = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !1);
    //  var endTurnRight = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !0);
    //  
    //  insertToProfile(beginTurnLeft);
    //  insertToProfile(beginTurnRight);
    //  insertToProfile(endTurnLeft);
    //  insertToProfile(endTurnRight);
    //});    
    //
    //var walls = [];
    //for(var i in allProfile){
    //	  var wall = allProfile[i];
    //    if (wall.begin && wall.end) {
    //        //var wallMiddle = Vec2.lerp(wall.begin, wall.end, .5);
    //        //var middleTurnRight = utilMathRotatePointCW(wallMiddle, wall.begin, 90);
    //        //var middleTurnRightSmall = utilMathGetScaledPoint(wallMiddle, middleTurnRight, wall.width);
    //        //var side = utilMathIsPointInPoly(floorLoop, middleTurnRightSmall) ? "right" : "left";
    //        //var wallMaterial = wall[side + "Material"];
    //        var wallLoop = utilModelWallGetTessellates(wall, !1);//utilModelWallGetTessellates(wall, !1);
    //        
    //        //添加bezier类型
    //        if(wall.bezier && wallLoop.length == 9){
    //        	var bezierLoop = [];
		//		    	bezierLoop.push(wallLoop[0]);bezierLoop.push(wallLoop[1]);    	
		//		    	for(var i=0;i<wallLoop[7].length;++i){
		//		    		bezierLoop.push(wallLoop[7][i]);
		//		    	}
		//		    	bezierLoop.push(wallLoop[2]);bezierLoop.push(wallLoop[3]);bezierLoop.push(wallLoop[4]);
		//		    	for(var i=0;i<wallLoop[8].length;++i){
		//		    		bezierLoop.push(wallLoop[8][i]);
		//		    	}
		//		    	bezierLoop.push(wallLoop[5]);
		//		    	bezierLoop.push(wallLoop[6]);
		//		    	wallLoop = bezierLoop;
    //        }
    //        
    //        void 0 == wallLoop || wallLoop.length < 3 || (wallLoop = [utilAdaptorClipperMakePath(wallLoop)]);
    //
    //        walls.push({
    //            wallLoop: wallLoop
    //        });
    //    } else {
    //        return null;
    //    }
    //}
    //
    ////计算内墙线
    //var wallPaths = [];
    //walls.forEach(function (wall) {
    //    var paths = wall.wallLoop;
    //    wallPaths = wallPaths.concat(paths);
    //});
    //
    ////标准化相近的交接点解决有时出现无法形成地面的问题--add by gaoning  2017.8.8
    //wallPaths = utilMathIsSamePointForPath(wallPaths);
    //
    //var wallLines = utilAdaptorClipperExecute(wallPaths, void 0, ClipperLib.ClipType.ctUnion);
    //var geom = [];
    //if (wallLines.length > 0) {
    //    wallLines[0].forEach(function (wallline) {
    //        geom.push({x: wallline.X / 1000.0, y: wallline.Y / 1000.0});
    //    });
    //}
    
    return geom;
}

//for 样板间套用--add by gaoning 2017.10.13
function utilFloorInsideLoopFromProfileForModelRoom(floor) {
    var floorLoop = utilFloorGetLoopFromProfile(floor);
    if(floorLoop)
        floorLoop = utilAdaptorClipperOffset(floorLoop, -0.010); //10毫米内部,解决其他墙体嵌入问题

    //检查所有转角的wall是否在房间内部，如果属于房间内部，加入队列中
    var fp = application.doc.floorplan;
    var profile = floor.profile;
    var allProfile = {};
    profile.forEach(function(wall){
        allProfile[wall.id] = wall;
    });

    //检查墙体是否在房间内
    var isInFloor = function(wall){
        if(utilMathIsPointInPoly(floorLoop, wall.begin)){
            return false;  //套用空间时，设为False
        }
        if(utilMathIsPointInPoly(floorLoop, wall.end)){
            return false;//套用空间时，设为False
        }
        return false;
    }

    //加入到墙体列表中
    var insertToProfile = function(insert){
        if(insert && !allProfile[insert.road.id] && isInFloor(insert.road)){
            allProfile[insert.road.id] = insert.road;
            profile.push(insert.road);
        }
    }

    profile.forEach(function(wall){
        var beginTurnLeft = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !1);
        var beginTurnRight = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !0);
        var endTurnLeft = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !1);
        var endTurnRight = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !0);

        insertToProfile(beginTurnLeft);
        insertToProfile(beginTurnRight);
        insertToProfile(endTurnLeft);
        insertToProfile(endTurnRight);
    });

    var walls = [];
    //allProfile.forEach(function (wall) {
    for(var i in allProfile){
        var wall = allProfile[i];
        if (wall.begin && wall.end) {
            var wallMiddle = Vec2.lerp(wall.begin, wall.end, .5);
            var middleTurnRight = utilMathRotatePointCW(wallMiddle, wall.begin, 90);
            var middleTurnRightSmall = utilMathGetScaledPoint(wallMiddle, middleTurnRight, wall.width);
            var side = utilMathIsPointInPoly(floorLoop, middleTurnRightSmall) ? "right" : "left";
            var wallMaterial = wall[side + "Material"];
            var wallLoop = utilModelWallGetTessellates(wall, !1);//utilModelWallGetTessellates(wall, !1);
            void 0 == wallLoop || wallLoop.length < 3 || (wallLoop = [utilAdaptorClipperMakePath(wallLoop)]);

            walls.push({
                wallLoop: wallLoop
            });
        } else {
            return null;
        }
    }

    //计算内墙线
    var wallPaths = [];
    walls.forEach(function (wall) {
        var paths = wall.wallLoop;
        wallPaths = wallPaths.concat(paths);
    });

    //标准化相近的交接点解决有时出现无法形成地面的问题--add by gaoning  2017.8.8
    wallPaths = utilMathIsSamePointForPath(wallPaths);

    var wallLines = utilAdaptorClipperExecute(wallPaths, void 0, ClipperLib.ClipType.ctUnion);
    var geom = [];
    if (wallLines.length > 0) {
        wallLines[0].forEach(function (wallline) {
            geom.push({x: wallline.X / 1000.0, y: wallline.Y / 1000.0});
        });
    }
    return geom;
}

//start
//标准化相近的交接点解决有时出现无法形成地面的问题--add by gaoning  2017.8.8
function utilMathIsSamePointForPath(wallPaths) {

    var posArr = new Array();

    //先获取数据
    wallPaths.forEach(function (wallPath) {
        wallPath.forEach(function (pos) {

            var posVec2 = new Vec2(pos.X, pos.Y);
            var value = ChechSamePoint(posArr, posVec2);
            if (value != null) {
                pos.X = value.x;
                pos.Y = value.y;
            } else {
                posArr.push(posVec2);
            }
        });
    });
    return wallPaths;
}

function ChechSamePoint(arr, pos) {
    for (var i = 0; i < arr.length; i++) {
        if (getLength(arr[i], pos) < 15) {
            return arr[i];
        }
    }
    return null;
}

function getLength(p1, p2) {
    var line = new Line(p1.x, p1.y, p2.x, p2.y);
    return line.length();
}

function isNumber(obj) {
    return obj === +obj;
}

function stringToByteArray(string){
	return new TextEncoder("utf-8").encode(string);
}
function uintToString(uintArray) {
    return new TextDecoder("utf-8").decode(uintArray);
}

//贝塞尔曲线
function utilMathBerzier(p0,p1,p2,t){  
    var x = (1 - t) * (1 - t) * p0.x + 2 * t * (1 - t) * p1.x + t * t * p2.x;  
    var y = (1 - t) * (1 - t) * p0.y + 2 * t * (1 - t) * p1.y + t * t * p2.y;  
    return {x:x,y:y};  
}
function linesIntr(a, b, c, d){

    /** 1 解线性方程组, 求线段交点. **/
// 如果分母为0 则平行或共线, 不相交
    var denominator = (b.y - a.y)*(d.x - c.x) - (a.x - b.x)*(c.y - d.y);
    if (Math.abs(denominator)<1e-5) {
        return false;
    }

// 线段所在直线的交点坐标 (x , y)
    var x = ( (b.x - a.x) * (d.x - c.x) * (c.y - a.y)
        + (b.y - a.y) * (d.x - c.x) * a.x
        - (d.y - c.y) * (b.x - a.x) * c.x ) / denominator ;
    var y = -( (b.y - a.y) * (d.y - c.y) * (c.x - a.x)
        + (b.x - a.x) * (d.y - c.y) * a.y
        - (d.x - c.x) * (b.y - a.y) * c.y ) / denominator;

    /** 2 判断交点是否在两条线段上 **/
    /*if (
        // 交点在线段1上
    (x - a.x) * (x - b.x) <= 0 && (y - a.y) * (y - b.y) <= 0
    // 且交点也在线段2上
    && (x - c.x) * (x - d.x) <= 0 && (y - c.y) * (y - d.y) <= 0
    ){
*/
        // 返回交点p
        return {
            x :  x,
            y :  y
        }
   /* }*/
    //否则不相交
    //return false

}
//求两线段的交点
function segmentsIntr(a, b, c, d){
    // 三角形abc 面积的2倍  
    var area_abc = (a.x - c.x) * (b.y - c.y) - (a.y - c.y) * (b.x - c.x);  

    // 三角形abd 面积的2倍  
    var area_abd = (a.x - d.x) * (b.y - d.y) - (a.y - d.y) * (b.x - d.x);   

    // 面积符号相同则两点在线段同侧,不相交 (对点在线段上的情况,本例当作不相交处理);  
    if ( area_abc*area_abd>=0 ) {  
        return false;  
    }  

    // 三角形cda 面积的2倍  
    var area_cda = (c.x - a.x) * (d.y - a.y) - (c.y - a.y) * (d.x - a.x);  
    // 三角形cdb 面积的2倍  
    // 注意: 这里有一个小优化.不需要再用公式计算面积,而是通过已知的三个面积加减得出.  
    var area_cdb = area_cda + area_abc - area_abd ;  
    if (  area_cda * area_cdb >= 0 ) {  
        return false;  
    }  

    //计算交点坐标  
    var t = area_cda / ( area_abd- area_abc );  
    var dx= t*(b.x - a.x),  
        dy= t*(b.y - a.y);  
    return { x: a.x + dx , y: a.y + dy };  

}  

//计算profileRect
function utilGetProfileRect(profile){
	var floorRect = null;
  function updateFloorRect(point){
  	if (!floorRect) {
          floorRect = {};
          floorRect.l = point.x;
          floorRect.r = point.x;
          floorRect.t = point.y;
          floorRect.b = point.y;
      } else {
          floorRect.l = Math.min(point.x, floorRect.l);
          floorRect.r = Math.max(point.x, floorRect.r);
          floorRect.b = Math.min(point.y, floorRect.b);
          floorRect.t = Math.max(point.y, floorRect.t);
      }
  }
  profile.forEach(function(p){
      updateFloorRect(p);
  });
  return floorRect;
}

function utilMergeGeom(subgeom, maingeom){
	var facesIndexStart = maingeom.vertices.length;
	
  var faceVertexUvs = subgeom.faceVertexUvs;
  var faces = subgeom.faces;
  var vertices = subgeom.vertices;

  //顶点
  vertices.forEach(function (v) {
      maingeom.vertices.push(v);
  });

  faceVertexUvs[0].forEach(function (uv) {
      maingeom.faceVertexUvs[0].push(uv);
  });

  //面
  faces.forEach(function (face) {
      face.a += facesIndexStart;
      face.b += facesIndexStart;
      face.c += facesIndexStart;
      maingeom.faces.push(face);
  });
}

function utilMergeGeomArea(floorGeom, paveGeom, o, lineDir, wallOffset){
	var facesIndexStart = paveGeom.vertices.length;	
					    	
	var faceVertexUvs = floorGeom.faceVertexUvs;
	var faces = floorGeom.faces;
	var vertices = floorGeom.vertices;					    						    	
	
	//顶点
	vertices.forEach(function(v){
		//var rotatedPoint = center2d ? utilMathRotatePointCW(center2d, v, rot) : void 0;
    //rotatedPoint && (v.x = rotatedPoint.x, v.y = rotatedPoint.y);
    v.z -= wallOffset;
    var xyz = utilThreeUVW2XYZ(v, o, lineDir);
		paveGeom.vertices.push(new THREE.Vector3(xyz.x, xyz.y, xyz.z));
	});
	
	faceVertexUvs[0].forEach(function(uv){					    		
		paveGeom.faceVertexUvs[0].push(uv);
	});
	
	//面					    		    	
	faces.forEach(function(face){
		face.a += facesIndexStart;
		face.b += facesIndexStart;
		face.c += facesIndexStart;					    		
		paveGeom.faces.push(face);
	});
}

function utilCliperFromPaths( paths, clippaths, cpr, cliptype, clipperFactor){
	cpr.Clear();
	cpr.AddPaths(paths, ClipperLib.PolyType.ptSubject, true);
	cpr.AddPaths(clippaths, ClipperLib.PolyType.ptClip, true);
	var solution = new ClipperLib.PolyTree();
	cpr.Execute(cliptype, solution, ClipperLib.PolyFillType.pftNonZero, ClipperLib.PolyFillType.pftNonZero);
	if(solution.m_Childs.length > 0){
		var ret = [];
		solution.m_Childs.forEach(function(poly){
			var profile = poly.m_polygon.map(function(p){
				return {x:p.X/clipperFactor, y:p.Y/clipperFactor};
			});
			var holes = [];
			poly.m_Childs.forEach(function(hole){
				var holeProfile = hole.m_polygon.map(function(p){
					return {x:p.X/clipperFactor, y:p.Y/clipperFactor};
				});
				holes.push(holeProfile);
			});
			
			ret.push({profile:profile, holes:holes});
		});
		return ret;
	}
}

function utilRedrawnAllFloor3D(){
	var fp = application.doc.floorplan;
	utilFloorplanForEachFloor(fp, function (floor) {
		floor.redrawn3D = true;
		utilModelChangeFlag(floor, FLOORFLAG_CHANGED_FOR_REDRAWN);    						
	});
}

function utilColorHexString(r, g, b) {
    var color = ( r || Math.random() * 255 ) << 16 ^ ( g || Math.random() * 255 ) << 8 ^ (b || Math.random() * 255 ) << 0;
    return ( '000000' + color.toString(16) ).slice(-6);//random color
}

function utilActiveCameraMatrix(){
	var view3d = utilAppGetViewById(application, "3d");
	var camera = view3d.camera;
	if(camera){
		return "["+camera.matrix.elements.toString()+"]";
	}
	return "";
}