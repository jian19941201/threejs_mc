//波打线
function Boundary(opt) {
    classBase(this, opt);
    var db = Root.prototype.database;
    this.host = opt ? typeof opt.host == "string" ? db[opt.host] : opt.host : void 0;     //从属主体
    this.corner = opt.type;      //判断是否为corner类型, base, cblr(corner+base+left+right)
    if(this.corner == true){
    	this.corner = "corner";
    }else if(this.corner == false){
    	this.corner = "base";
    }
    
    this.level = 0;
    this.category = "";    
    this.host && this.host instanceof Area && (this.category = "inner", this.level = this.host.level);
        
    this.createtime = new Date().valueOf();  //创建时间(根据创建时间先后计算放置次序)
    this.baseCount = 0;
	  this.cornerCount = 0;
	  this.size = DEFAULT_BOUNDARY_SIZE;	  
    
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
        
    utilRootDefineProperty(this, "level", 0, propertyChanged);
    
    utilRootDefineProperty(this, "cornerRot", 0, propertyChanged);   //角花角度
    utilRootDefineProperty(this, "baseRot", 0, propertyChanged);     //衬线角度
    utilRootDefineProperty(this, "leftRot", 0, propertyChanged);     //左配件
    utilRootDefineProperty(this, "rightRot", 0, propertyChanged);    //右配件
    
    //基础材质 
    utilRootDefineProperty(this, "cornerMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "baseMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "leftMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "rightMaterial", void 0, linkChanged);
        
    this.applyModelRoomComplete = new signals.Signal();
    
    //by mond 2017/10/21
    utilRootDefineProperty(this, "rootMaterial", void 0, linkChanged);    //砖缝颜色纹理
    utilRootDefineProperty(this, "paveType", "SINGLEPAVE_01X", propertyChanged);     //铺贴方式，默认连续直铺
    this.rootMaterial = new MaterialRawColor({color:utilStringToHexCharCode(DEFAULT_FLOOR_ROOTCOLOR)});    
    utilRootDefineProperty(this, "gapwidth", 0.003, propertyChanged);//this.gapwidth = 0.003; //初始化默认0.003米
    utilRootDefineProperty(this, "gapcolor", DEFAULT_FLOOR_ROOTCOLOR, propertyChanged);//this.gapcolor = DEFAULT_FLOOR_ROOTCOLOR; 
    this.rebuild = utilBoundaryBuildTilePave.bind(this);
    this.baseOffsetX = []; //所有baseloop中的X轴偏移

	  this.rightOffsetX = []; //所有baseloop中的X轴偏移

    //监听host变化    
    this.addLink();
}

Boundary.prototype.type = "BOUNDARY", classInherit(Boundary, ModelObject);

var BOUNDARY_CHANGED_FOR_REDRAWN = 128, BOUNDARY_DETAILEDUPDATED_MATERIAL = 256;
var BOUNDARY_REBUILD_LOOPS = 512, BOUNDARY_REBUILD_MATERIALS = 1024;
var DEFAULT_BOUNDARY_CORNERMATERIAL_ID = "p8f9b024e43e64dc0bf51d7da321ac613";   //电商产品 ODT301-4P
var DEFAULT_BOUNDARY_BASEMATERIAL_ID = "p01212d0d2b2646f6a943cb3bf38b9b7c";     //电商产品 ODT301-1P
var DEFAULT_BOUNDARY_MATERIAL = "lightyellow";
var DEFAULT_BOUNDARY_SIZE = 0.15;

utilExtend(Boundary.prototype, {
    save: function () {
        var saved = classBase(this, "save");        
        this.cornerMaterial && (saved.cornerMaterial = this.cornerMaterial.id);
        this.baseMaterial && (saved.baseMaterial = this.baseMaterial.id);
        this.leftMaterial && (saved.leftMaterial = this.leftMaterial.id);
        this.rightMaterial && (saved.rightMaterial = this.rightMaterial.id);
        
        saved.size = this.size;
        saved.host = this.host.id;
        saved.corner = this.corner;
        saved.createtime = this.createtime;
        saved.cornerRot = this.cornerRot;
        saved.baseRot = this.baseRot;
        saved.leftRot = this.leftRot;
        saved.rightRot = this.rightRot;
        saved.baseOffsetX = this.baseOffsetX;
		    saved.rightOffsetX = this.baseOffsetX;
        saved.level = this.level;
                
        this.rootMaterial && (saved.rootMaterial = this.rootMaterial.id);
        this.paveType && (saved.paveType = this.paveType);
        this.gapwidth && (saved.gapwidth = this.gapwidth);
        this.gapcolor && (saved.gapcolor = this.gapcolor);
        
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        data.cornerMaterial ? this.cornerMaterial = db[data.cornerMaterial] : this.cornerMaterial = new Material({
            pid: DEFAULT_BOUNDARY_CORNERMATERIAL_ID
        }); 
        data.baseMaterial ? this.baseMaterial = db[data.baseMaterial] : this.baseMaterial = new Material({
            pid: DEFAULT_BOUNDARY_BASEMATERIAL_ID
        });
        data.leftMaterial ? this.leftMaterial = db[data.leftMaterial] : this.leftMaterial = new Material({
            pid: DEFAULT_BOUNDARY_BASEMATERIAL_ID
        });
        data.rightMaterial ? this.rightMaterial = db[data.rightMaterial] : this.rightMaterial = new Material({
            pid: DEFAULT_BOUNDARY_BASEMATERIAL_ID
        });
        data.rootMaterial ? this.rootMaterial = db[data.rootMaterial] : this.rootMaterial = new MaterialRawColor({
            color: DEFAULT_FLOOR_ROOTCOLOR
        });
        
        data.size && (this.size = data.size);
        data.corner && (this.corner = data.corner);
        data.host && (this.host = db[data.host]);
        data.createtime && (this.createtime = data.createtime);
        data.cornerRot && (this.cornerRot = data.cornerRot);
        data.baseRot && (this.baseRot = data.baseRot);
        data.leftRot && (this.leftRot = data.leftRot);
        data.rightRot && (this.rightRot = data.rightRot);
        data.paveType && (this.paveType = data.paveType);
        data.gapwidth && (this.gapwidth = data.gapwidth);
        data.gapcolor && (this.gapcolor = data.gapcolor);
        data.baseOffsetX && (this.baseOffsetX = data.baseOffsetX);
		    data.rightOffsetX && (this.rightOffsetX = data.rightOffsetX);
        data.level && (this.level = data.level);
        
        if(this.corner == true){
		    	this.corner = "corner";
		    }else if(this.corner == false){
		    	this.corner = "base";
		    }
        
        utilModelChangeFlag(this, BOUNDARY_CHANGED_FOR_REDRAWN);
    },
    //重新创建区域
    updateLoops: function() {
    	  if(utilModelIsFlagOn(this, BOUNDARY_REBUILD_LOOPS)){
    	      utilModelSetFlagOff(this, BOUNDARY_REBUILD_LOOPS);
    	      var fp = application.doc.floorplan;
    	      
    	      this.cornerLoops = [];
				    this.leftLoops = [];
				    this.rightLoops = [];
    	      
    	      if(this.host instanceof Floor){
    	      	  this.baseLoops = utilFloorGetBoundaryLoops(fp, this);				        
    	      }else if(this.host instanceof RectArea || this.host instanceof FreeArea){
    	      	  this.baseLoops = utilAreaGetBoundaryLoops(fp, this);
    	      }

    	      if(this.corner == "corner"){
		        	//带转角类型
		        	this.cornerLoops = utilCreateCornerFromBoundaryloops(this);    	
		        }else if(this.corner == "cblr"){
		        	//四件套 先产生转角
		        	this.cornerLoops = utilCreateCornerFromBoundaryloops(this);
		        	//生成左右两个配件
		        	if(this.leftMaterial && this.rightMaterial && this.leftMaterial.meta && this.rightMaterial.meta){
			        	var lrLoops = utilCreateLRFromBoundaryloops(this,this.leftMaterial.meta.xlen, this.rightMaterial.meta.xlen);
			        	this.leftLoops = lrLoops[0];
			        	this.rightLoops = lrLoops[1];
						//console.log(this.rightLoops);
			        }
		        }
    	  }
    },
    //更新纹理
    updateMaterial: function () {
    	  if(utilModelIsFlagOn(this, BOUNDARY_REBUILD_MATERIALS)){
			  	  utilModelSetFlagOff(this, BOUNDARY_REBUILD_MATERIALS);
			  }			  	  
    },
    clearAllMaterials: function () {
    	  //清除旧的material
	  	  var db = Root.prototype.database;
	  	  for(var i=0;i<this.baseCount;++i){
	  	  	  var sideName = "base" + i + "Material";
	  	  	  var mat = this[sideName];
	  	  	  mat && (mat.dispose(), delete db[mat.id], this[sideName] = null);
	  	  }
	  	  for(var i=0;i<this.cornerCount;++i){
	  	  	  var sideName = "corner" + i + "Material";
	  	  	  var mat = this[sideName];
	  	  	  mat && (mat.dispose(), delete db[mat.id], this[sideName] = null);
	  	  }
	  	  this.baseCount = 0;
	  	  this.cornerCount = 0;
    },
    addLink: function(){
    	  if(this.host instanceof RectArea || this.host instanceof FreeArea){    	  	 
						this.propertyChangedFun = function (propertyName, oldValue, newValue) {
						    "flag" == propertyName && ((oldValue & AREAFLAG_CHANGED_FOR_REDRAWN) != (newValue & AREAFLAG_CHANGED_FOR_REDRAWN) ? utilModelChangeFlag(this, BOUNDARY_CHANGED_FOR_REDRAWN) : void 0);						    						    
						    if(propertyName == "rot" || propertyName == "width" || propertyName == "height" ){
						    	utilModelChangeFlag(this, BOUNDARY_CHANGED_FOR_REDRAWN);
						    }
						    if(propertyName == "level"){
						    	this.level = newValue;
						    }
						}.bind(this);						
						this.linkPropertyChangedFun = function (changedLinkEntity, propertyName) {
						    changedLinkEntity instanceof Point && ("x" == propertyName || "y" == propertyName) ? utilModelChangeFlag(this, BOUNDARY_CHANGED_FOR_REDRAWN) : void 0;
						}.bind(this);						
						this.host.propertyChangedEvent.add(this.propertyChangedFun);											
						this.host.linkPropertyChangedEvent.add(this.linkPropertyChangedFun);
    	  }else if(this.host instanceof Floor){
    	  	  this.propertyChangedFun = function (propertyName, oldValue, newValue) {
						    "flag" == propertyName && ((oldValue & FLOORFLAG_CHANGED_FOR_REDRAWN) != (newValue & FLOORFLAG_CHANGED_FOR_REDRAWN) ? utilModelChangeFlag(this, BOUNDARY_CHANGED_FOR_REDRAWN) : void 0);
						}.bind(this);
						this.host.propertyChangedEvent.add(this.propertyChangedFun);
    	  }
    	  
    	  this.linksChangedFun = function (propertyName, linksOp, changeFrom, changeTo) {
				    if(propertyName == "lt" && linksOp == "remove" && (changeFrom && changeFrom.type == Floorplan.prototype.type)){
				    	//删除事件
				    	utilRemoveLinkedBoundary(this.host);
				    }
				}.bind(this);
				this.host.linksChangedEvent.add(this.linksChangedFun);	
    },
    removeLink: function(){
    	  if(this.propertyChangedFun){
    	  	this.host.propertyChangedEvent.remove(this.propertyChangedFun);
    	  	this.propertyChangedFun = null;
    	  }
    	  if(this.linkPropertyChangedFun){
    	  	this.host.linkPropertyChangedEvent.remove(this.linkPropertyChangedFun);
    	  	this.linkPropertyChangedFun = null;
    	  }
    	  if(this.linksChangedFun){
    	  	this.host.linksChangedEvent.remove(this.linksChangedFun);
    	  	this.linksChangedFun = null;
    	  }
    },
    dispose:function(){
    	  this.removeLink();
    	  this.clearAllMaterials();
    	  
    	  this.baseMaterial = null;
	  	  this.cornerMaterial = null;
    }
})

function utilAdaptorClipperOffset2(geom, offset){
		var geomLine = geom;
    var line = [];
    for(var i=1;i<geomLine.length+1;++i){
      if(i == geomLine.length){
	      var dir = new Vec2(geomLine[0].x - geomLine[i-1].x, geomLine[0].y - geomLine[i-1].y);
	    	var lineOffset = dir.normalize().scale(offset);
	    	line.push([Vec2.rotateAroundPoint(lineOffset.clone().add(geomLine[i-1]), geomLine[i-1], -Math.PI / 2),
	                 Vec2.rotateAroundPoint(lineOffset.clone().add(geomLine[0]), geomLine[0], -Math.PI / 2)]);
      }else{
	      var dir = new Vec2(geomLine[i].x - geomLine[i-1].x, geomLine[i].y - geomLine[i-1].y);
	    	var lineOffset = dir.normalize().scale(offset);
	    	line.push([Vec2.rotateAroundPoint(lineOffset.clone().add(geomLine[i-1]), geomLine[i-1], -Math.PI / 2),
	                 Vec2.rotateAroundPoint(lineOffset.clone().add(geomLine[i]), geomLine[i], -Math.PI / 2)]);
      }
    }
    
    var offsetLine = [];
    if(line.length > 1){		            	
      for(var i=0;i<line.length;++i){
      	//计算每个线段的交点
      	if(i==0){
      		var last = line.length - 1;
      		if(utilMathIsLineParallel(line[last][0], line[last][1], line[0][0], line[0][1])){
	      		offsetLine.push(line[last][1]);
	      	}else{
	      		offsetLine.push(utilMathLineLineIntersection(line[last][0], line[last][1], line[0][0], line[0][1]));
	      	}
      	}else{
	      	if(utilMathIsLineParallel(line[i-1][0], line[i-1][1], line[i][0], line[i][1])){
	      		offsetLine.push(line[i-1][1]);
	      	}else{
	      		offsetLine.push(utilMathLineLineIntersection(line[i-1][0], line[i-1][1], line[i][0], line[i][1]));
	      	}
	      }
      }
    }    
    
    return offsetLine;
}

function utilFloorGetBoundaryLoops(fp, boundary){	
	  var db = fp.database;
    var floorModel = db[boundary.host.id];
    
	  var boundarys = [];	  
	  utilFloorplanForEachBoundary(fp, function(b){
    	  if(b.host.id == floorModel.id){
    	  	boundarys.push(b);
    	  }        
    });
    
    //对创建时间进行排序
    function sortBoundary(a,b){
    	if(a.createtime > b.createtime){
    		return 1;
    	}
    	return 0;
    }    
    boundarys.sort(sortBoundary);
    
    var offset = 0;
    for(var i=0;i<boundarys.length;++i){
    	if(boundary.id != boundarys[i].id){
    		offset += boundarys[i].size;
    	}else{
    		break;
    	}
    }
       
    var geom = utilFloorInsideLoopFromProfile(floorModel);
    
    if(geom){    	
    	var geom_outside = utilAdaptorClipperOffset(geom, -offset);
    	//var geom_x = utilAdaptorClipperOffset(geom, -(offset + boundary.size));
    	var geom_inside  = utilAdaptorClipperOffset2(geom_outside, -(boundary.size));
    	
    	//var outsideMeasurement = utilMathPolyMeasurement(geom_outside);
    	//var insideMeasurement = utilMathPolyMeasurement(geom_inside);
    	//if(insideMeasurement > outsideMeasurement){
    	//	//方向反了
    	//	geom_inside  = utilAdaptorClipperOffset2(geom_outside, (boundary.size));
    	//}
    	    	    	
    	if(geom_outside && geom_inside && (geom_outside.length == geom_inside.length)){
    		//添加开始节点
    		geom_outside.push(geom_outside[0]);
    		geom_inside.push(geom_inside[0]);
    		
    		var loops = [];
    		for(var i=0;i<geom_outside.length - 1;++i){
    			var areageom = [];
    			areageom.push(geom_outside[i]);
    			areageom.push(geom_outside[i+1]);
    			    			
    			areageom.push(geom_inside[i+1]);
    			areageom.push(geom_inside[i]);
    			
    			loops.push(areageom);
    		}
    		
    		return loops;
    	}
    }
    
    return [];
}

function utilAreaGetBoundaryLoops(fp, boundary){	
	  var db = fp.database;
    var rectAreaModel = db[boundary.host.id];
    
	  var boundarys = [];	  
	  utilFloorplanForEachBoundary(fp, function(b){
    	  if(b.host.id == rectAreaModel.id){
    	  	boundarys.push(b);
    	  }        
    });
    
    //对创建时间进行排序
    function sortBoundary(a,b){
    	if(a.createtime > b.createtime){
    		return 1;
    	}
    	return 0;
    }    
    boundarys.sort(sortBoundary);
    
    var offset = 0;
    for(var i=0;i<boundarys.length;++i){
    	if(boundary.id != boundarys[i].id){
    		offset += boundarys[i].size;
    	}else{
    		break;
    	}
    }
       
    var geom = rectAreaModel.getLoop();
    if(geom){
      geom.pop();//不需要最后一个重复的    
    
      //扩展
    	var geom_outside = utilAdaptorClipperExtend(geom, (offset + boundary.size));
    	var geom_inside = utilAdaptorClipperExtend(geom, offset);    	
    	
    	if(geom_outside && geom_inside && (geom_outside.length == geom_inside.length)){
    		//添加开始节点
    		geom_outside.push(geom_outside[0]);
    		geom_inside.push(geom_inside[0]);
    		
    		var loops = [];
    		for(var i=0;i<geom_outside.length - 1;++i){
    			var areageom = [];
    			areageom.push(geom_outside[i]);
    			areageom.push(geom_outside[i+1]);
    			    			
    			areageom.push(geom_inside[i+1]);
    			areageom.push(geom_inside[i]);
    			
    			loops.push(areageom);
    		}
    		
    		return loops;
    	}
    }
    
    return [];
}

function utilCreateCornerFromBoundaryloops(boundary){
	var loops = boundary.baseLoops;
	if(!loops){
		return [];
	}
	var cornerLoops = []
	try{
		for(var i=0;i<loops.length;i++){
			  var l1 = loops[i];        		  
			  var l2 = (i == loops.length - 1) ? loops[0] : loops[i+1]; //最后一个节点，使用第一个节点作为loop2
			  
			  //调整衬线部分节点
			  var angle = utilMathLinelineCCWAngle(l1[1], l2[1], l1[0]);
			  if(Math.round(angle) == 90){
			  	  var newL1 = utilMathGetExtendPoint(l1[0], l1[1], -boundary.size);
			  	  var newL2 = utilMathGetExtendPoint(l2[1], l2[0], -boundary.size);
			  	  
			  	  //并生成转角loop
			  	  var loop = [];
			  	  loop.push({x:newL1.x, y:newL1.y});
			  	  loop.push({x:l1[1].x, y:l1[1].y});
			  	  loop.push({x:newL2.x, y:newL2.y});
			  	  loop.push({x:l1[2].x, y:l1[2].y});
			  	  
			  	  l1[1] = newL1;
			  	  l2[0] = newL2;
			  	  cornerLoops.push(loop);
			  }else if(Math.round(angle) == 270){
			  	  var newL1 = utilMathGetExtendPoint(l1[3], l1[2], -boundary.size);
			  	  var newL2 = utilMathGetExtendPoint(l2[2], l2[3], -boundary.size);
			  	  
			  	  //并生成转角loop
			  	  var loop = [];
			  	  loop.push({x:l1[1].x, y:l1[1].y});
			  	  loop.push({x:newL1.x, y:newL1.y});
			  	  loop.push({x:l1[2].x, y:l1[2].y});
			  	  loop.push({x:newL2.x, y:newL2.y});		  	  
			  	  
			  	  l1[2] = newL1;
			  	  l2[3] = newL2;
			  	  cornerLoops.push(loop);
			  }else{
			  	  cornerLoops.push([]);
			  }
		} 
	}catch(e){
		//...
	}
	return cornerLoops;
}

function utilCreateLRFromBoundaryloops(boundary,xlenL, xlenR){
	var loops = boundary.baseLoops;
	if(!loops){
		return [[],[]];
	}
	var xlenB = boundary.baseMaterial.meta.xlen;

	var leftLoops = [];
	var rightLoops = [];
	
	try{
		for(var i=0;i<loops.length;i++){

			  var leftLoop = [];
			  var rightLoop = [];
			  
			  var l1 = loops[i];        		  
			  var l2 = (i == loops.length - 1) ? loops[0] : loops[i+1]; //最后一个节点，使用第一个节点作为loop2
			  
			  var lenL = xlenL;
			  var lenR = xlenR;
			  var lenB = xlenB;//0.1;//如果出现长度不足xLenL+xLenR，三段平均裁剪
			  
			  var lenLoop = utilMathLineLength(l1[0], l1[1]);

			//保证左右完整
			//if(lenLoop <= (lenL + lenR)){
			  //	lenL = lenR = lenB = lenLoop/3.0;
			  //}else
			  //{
				//  var bOffset = (lenLoop * 0.001 -(lenL + lenR ) * 0.001) % (xlenB * 0.001);
				//  bOffset = bOffset * 1000;
				//  boundary.baseOffsetX[i] = -bOffset/2;
			  //}

			//保证中间完整
			if (lenLoop <= (lenB + lenL + lenR)) {
				lenL = lenR = lenB = lenLoop / 3.0;
			} else {
				var bOffset = (lenLoop * 0.001 - xlenB * 0.001) % (xlenB * 0.001);
				bOffset = (bOffset + xlenB * 0.001) * 1000;
				//boundary.baseOffsetX[i] = -bOffset / 2;
				lenL = bOffset / 2;
				lenR = bOffset / 2;
				lenB = lenLoop - bOffset;//Math.floor((lenLoop) / (xlenB ));
			}

			var cornerLoopTail = boundary.cornerLoops[i];
			  var headIndex = i - 1;
			  headIndex = headIndex < 0?boundary.cornerLoops.length - 1 : headIndex;
			  var cornerLoopHead = boundary.cornerLoops[headIndex];
			  
			  if(cornerLoopTail.length > 0 && cornerLoopHead.length > 0){
			  	  var newL1 = utilMathGetExtendPoint(l1[0], l1[1], -lenL);
			  	  var newL2 = utilMathGetExtendPoint(l1[3], l1[2], -lenL);
			  	  
			  	  leftLoop.push({x:newL1.x, y:newL1.y});
			  	  leftLoop.push({x:l1[1].x, y:l1[1].y});
			  	  leftLoop.push({x:l1[2].x, y:l1[2].y});
			  	  leftLoop.push({x:newL2.x, y:newL2.y});

				  var newR1 = utilMathGetExtendPoint(l1[1], l1[0], -lenR);
				  var newR2 = utilMathGetExtendPoint(l1[2], l1[3], -lenR);

				  rightLoop.push({x:l1[0].x, y:l1[0].y});//1
				  rightLoop.push({x:newR1.x, y:newR1.y});//2
				  rightLoop.push({x:newR2.x, y:newR2.y});//3
				  rightLoop.push({x:l1[3].x, y:l1[3].y});//4

				  boundary.rightOffsetX[i] = (xlenR -lenR);

			  	  //base段
			  	  l1[0] = newR1;
			  	  l1[1] = newL1;
			  	  l1[2] = newL2;
			  	  l1[3] = newR2;
			  }else if(cornerLoopTail.length > 0){
			  	  var newL1 = utilMathGetExtendPoint(l1[0], l1[1], -lenL);
			  	  var newL2 = utilMathGetExtendPoint(l1[3], l1[2], -lenL);
			  	  
			  	  leftLoop.push({x:newL1.x, y:newL1.y});
			  	  leftLoop.push({x:l1[1].x, y:l1[1].y});
			  	  leftLoop.push({x:l1[2].x, y:l1[2].y});
			  	  leftLoop.push({x:newL2.x, y:newL2.y});
			  	  
			  	  //base段
			  	  l1[1] = newL1;
			  	  l1[2] = newL2;
			  }else if(cornerLoopHead.length > 0){
			  	  var newR1 = utilMathGetExtendPoint(l1[1], l1[0], -lenR);
			  	  var newR2 = utilMathGetExtendPoint(l1[2], l1[3], -lenR);

			  	  rightLoop.push({x:l1[0].x, y:l1[0].y});
			  	  rightLoop.push({x:newR1.x, y:newR1.y});
			  	  rightLoop.push({x:newR2.x, y:newR2.y});
			  	  rightLoop.push({x:l1[3].x, y:l1[3].y});

				  boundary.rightOffsetX[i] = (xlenR -lenR);

			  	  //base段
			  	  l1[0] = newR1;
			  	  l1[3] = newR2;
			  }
			  else{
			  	  //不带转角 不显示lr段			  	  
			  }
			  
			  leftLoops.push(leftLoop);
			  rightLoops.push(rightLoop);
		}
	}catch(e){
		//...
		console.log(e);
	}
	
	return [leftLoops, rightLoops];
}


function utilRemoveLinkedBoundary(model){
	var fp = application.doc.floorplan;
	utilFloorplanForEachBoundary(fp, function(boundary){
		if(boundary.host.id == this.id){
			  utilEntityRemoveLink(fp, boundary);
		}
	}, model);
}

function genBoundaryTiles(profile, name, index, boundaryModel, loopOffsetX){	
	if(profile.length < 3){
		return;
	}
	for(var i=0;i<profile.length;++i){
		if(!profile[i])
		    return;
	}
	
	loopOffsetX = loopOffsetX == null ? 0 : loopOffsetX;
	var material = boundaryModel[name+"Material"];
	
	//返回结果
	var ret = {};
	ret.profile = profile;	
	ret.material = material;
	ret.name = name;
	ret.index = index;
	
	//需要产生的字段
	ret.tiles = null;
	ret.floorRectOrigin = null;
	ret.singlepaveRot = null;
	
	var p1 = profile[0];
  var p2 = profile[1];
  var rot = utilMathGetAngleHorizontaleCCW(p2, p1) + boundaryModel[name+"Rot"];
	
  //计算铺贴区域
  var floorRect = null;
  function updateFloorRect(point){
  	if (!floorRect) {
          floorRect = {};
          floorRect.l = point.x;
          floorRect.r = point.x;
          floorRect.t = point.y;
          floorRect.b = point.y;
      } else {
          floorRect.l = Math.min(point.x, floorRect.l);
          floorRect.r = Math.max(point.x, floorRect.r);
          floorRect.b = Math.min(point.y, floorRect.b);
          floorRect.t = Math.max(point.y, floorRect.t);
      }
  }
  profile.forEach(function(p){
      updateFloorRect(p);
  });
     					    	
	var cuth = 1;      //竖切单元
	var cutv = 1;      //横切单元
	var scaleW = 1.0;  //宽缩放
	var scaleH = 1.0;  //高缩放
	boundaryModel.rootMaterial.setColor(utilStringToHexCharCode(boundaryModel.gapcolor));
	
	var ignoreDir = false; //忽略朝向选择
	if(material.type == TileSingle.prototype.type){
		cuth = parseInt(material.cuth);
		cutv = parseInt(material.cutv);
		//boundaryModel.rootMaterial.setColor(utilStringToHexCharCode(this.gapcolor));
		//gap = boundaryModel.gapwidth;
  }else{
  	//...			    				    	
  }
  
  var meta = material.meta;
	if(meta.xlen == undefined){ //无效的产品长宽
		boundaryModel.paveRebuild = false;
    boundaryModel.redrawn = false;
	  return;
	}
	  
	if(material.category == "custom_tile" || material.category == "customparquet"){
  	//自定义拼花，要求尺寸跟floorRect一致			    	
  	material.sx = (floorRect.r - floorRect.l)/meta.xlen;
  	material.sy = (floorRect.t - floorRect.b)/meta.ylen;
  	ignoreDir = true;
  }  
	  
  scaleW = material.sx;
  scaleH = material.sy;		    	
	
	var tileW = meta.xlen/cuth*scaleW; //切砖大小
	var tileH = meta.ylen/cutv*scaleH;
	
	var isSquare = tileW == tileH;
	boundaryModel.isSquare = isSquare;		    	
	
	var paveW = tileW; //铺贴大小为 砖大小+砖缝*2
	var paveH = tileH;
	
	//铺贴方式中的所有铺贴单元
	var paveTileModel = {};
	var paveTileProfile = {};
	var singlepave = PAVEMODEL[boundaryModel.paveType];
	var tiles = singlepave.tiles;
	if(paveW < paveH){
		tiles = singlepave.tilesHW || tiles;
	}
	tiles.forEach(function(tile){
		  paveTileModel[tile.id] = tile;
		  
		  paveTileProfile[tile.id] = [];
		  tile.profile.forEach(function(p){
    		paveTileProfile[tile.id].push({x:p.x*paveW, y:p.y*paveH});
    	});
	});				    	
	
	//step1 创建floorRect中的所有铺砖
	var clipperFactor = 10000.0;//clipper缩放因子
	var cpr = new ClipperLib.Clipper();
	//房间铺砖区域裁剪path(大)
	var floorRectClipPaths = [];
	floorRectClipPaths.push({X:Math.ceil(floorRect.l * clipperFactor), Y: Math.ceil(floorRect.b* clipperFactor)});
	floorRectClipPaths.push({X:Math.ceil(floorRect.l * clipperFactor), Y: Math.ceil(floorRect.t* clipperFactor)});
	floorRectClipPaths.push({X:Math.ceil(floorRect.r * clipperFactor), Y: Math.ceil(floorRect.t* clipperFactor)});
	floorRectClipPaths.push({X:Math.ceil(floorRect.r * clipperFactor), Y: Math.ceil(floorRect.b* clipperFactor)});
	
	//内墙线裁剪path
	var floorInsideClipPaths = profile.map(function(p){
		return {X:Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
	});
			
	var offsetX = loopOffsetX;
	if(offsetX > paveW){
		offsetX = paveW;
	}else if(offsetX < -paveW){
		offsetX = -paveW;
	}
	
	var floorRectOrigin = utilMathGetExtendPoint(p1, p2, offsetX);//{x:floorRect.l + material.tx, y:floorRect.b + material.ty};
	var singlepaveRot = singlepave.rotate || 0;
	singlepaveRot += rot;	
	
	ret.floorRectOrigin = floorRectOrigin;
	ret.singlepaveRot = singlepaveRot;
			
	var beginVisibleTile = false; //记录是否开始可见铺砖,可见铺砖后，不再接受不在裁剪区出现的砖
	var floorRectTiles = [];      //floorRect铺砖
	var unpaves = [];//未铺贴
	var tile = {};
	tile.id  = "0";   //从0号砖开始进行铺贴
	tile.origin = {x:floorRectOrigin.x, y:floorRectOrigin.y};  //原始生成点（未整体旋转前)
	tile.rot = tiles[0].rot;
	tile.dir = 0;
	tile.tileIndex = 0;
	tile.pavetileID = tiles[0].id;    	
	tile.paveW = paveW;
	tile.paveH = paveH;
	tile.tileW = tileW;
	tile.tileH = tileH;
	tile.pos = tile.origin;			    		
	//实际整体平移和旋转后得到的profile    	
	tile.profile = paveTileProfile[tile.pavetileID].map(function(p){    		  
		  return utilMathRotatePointCW(floorRectOrigin, {x:tile.pos.x + p.x, y:tile.pos.y + p.y}, singlepaveRot);
	});
	var paths = tile.profile.map(function(p){
		 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
	});
	cpr.Clear();
	cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
  cpr.AddPath(floorRectClipPaths, ClipperLib.PolyType.ptClip, true);
	var solution = new ClipperLib.PolyTree();
	cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
	if(solution.m_AllPolys.length > 0){
		beginVisibleTile = true;
		//使用内墙线进一步裁剪
		cpr.Clear();
  	cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
    cpr.AddPath(floorInsideClipPaths, ClipperLib.PolyType.ptClip, true);
  	var solution = new ClipperLib.PolyTree();
		cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
		if(solution.m_AllPolys.length > 0){		
			tile.tileProfile = [];
			solution.m_AllPolys.forEach(function(poly){
				tile.tileProfile.push(poly.m_polygon.map(function(p){  
						return {x:p.X/clipperFactor, y:p.Y/clipperFactor};
				}));
		  });						
		}
	}
	unpaves.push(tile);
	floorRectTiles.push(tile);
	
	//通过nodes对tile进行周边砖的铺贴,直到所有砖铺完
	var tileNum = 0;
	while(unpaves.length > 0){
		tileNum++;
		var tile = unpaves.shift();
		
		//节点    		
		var addTiles = [];
		var nodes = paveTileModel[tile.pavetileID].nodes;
		nodes.forEach(function(node, index){
			  var hx = node.center.hx != null? node.center.hx*paveH:0;  //用于计算以高度为单位的x轴偏移
			  var wy = node.center.wy != null? node.center.wy*paveW:0;  //用于计算以长度为单位的y轴偏移
			  var center = {x:tile.origin.x + node.center.x*tile.paveW + hx, y:tile.origin.y + node.center.y*tile.paveH + wy};
			  center = utilMathRotatePointCW(floorRectOrigin, center, singlepaveRot);
			  //通过center判断是否已经有砖
			  var ignore = false;
			  for(var i=0;i<floorRectTiles.length;++i){
			  	var fpTile = floorRectTiles[i];
			  	var inside = utilMathIsPointInPoly(fpTile.profile, center);
			  	if(inside){
			  		ignore = true;
			  		break;
			  	}
			  };
			  
			  if(!ignore){
			  	var tM = paveTileModel[node.id];
			  	var t = {};
			  	var hx = node.offset.hx != null ? node.offset.hx * paveH:0;  //用于计算以高度为单位的x轴偏移
			  	var wy = node.offset.wy != null ? node.offset.wy * paveW:0;  //用于计算以长度为单位的y轴偏移
		    	t.id  = tile.id + "#" + index;   //以node索引作为id记录(用于记录换砖历史)
		    	t.origin = {x:tile.origin.x + tile.paveW*node.offset.x + hx, y:tile.origin.y + tile.paveH*node.offset.y + wy};
		    	t.rot = tM.rot;
		    	t.dir = 0;								    	
		    	t.pavetileID = tM.id;    	
		    	t.paveW = paveW;
		    	t.paveH = paveH;
		    	t.tileW = tileW;
		    	t.tileH = tileH;
		    	t.pos = utilMathRotatePointCW(floorRectOrigin, t.origin, singlepaveRot);    	
		    	if(t.rot){
		    		//以origin进行旋转后偏移
		    		t.profile = paveTileProfile[tile.pavetileID].map(function(p){
			    	    var rp = utilMathRotatePointCW({x:0,y:0}, {x:p.x, y:p.y}, t.rot.r);
			    	    var x = t.rot.x != null ? t.rot.x*paveW:0;
			    	    var y = t.rot.y != null ? t.rot.y*paveH:0;
			    	    var hx = t.rot.hx != null ? t.rot.hx*paveH:0;
			    	    var wy = t.rot.wy != null ? t.rot.wy*paveW:0;
			    	    return utilMathRotatePointCW(floorRectOrigin, {x:t.origin.x + rp.x + x + hx, y:t.origin.y + rp.y + y + wy}, singlepaveRot);
			    	});
		    	}else{
		    		t.profile = paveTileProfile[tile.pavetileID].map(function(p){
			    		  return utilMathRotatePointCW(floorRectOrigin, {x:t.origin.x + p.x, y:t.origin.y + p.y}, singlepaveRot);				    		  
			    	});
		    	}
		    	
		    	var paths = t.profile.map(function(p){
		    		 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
		    	});
		    	
		    	cpr.Clear();
		    	cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
			    cpr.AddPath(floorRectClipPaths, ClipperLib.PolyType.ptClip, true);
		    	var solution = new ClipperLib.PolyTree();
					cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
					
					if(solution.m_AllPolys.length > 0){
						beginVisibleTile = true;
						//进一步对铺砖进行裁剪
						cpr.Clear();
			    	cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
				    cpr.AddPath(floorInsideClipPaths, ClipperLib.PolyType.ptClip, true);
			    	var solution = new ClipperLib.PolyTree();
						cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
						if(solution.m_AllPolys.length > 0){
							t.tileProfile = [];
							solution.m_AllPolys.forEach(function(poly){
								t.tileProfile.push(poly.m_polygon.map(function(p){  
										return {x:p.X/clipperFactor, y:p.Y/clipperFactor};
								}));												
							});
							t.tileIndex = 0;
						}
												
						//通过裁剪，判断是否为有效铺砖
						unpaves.push(t);
						addTiles.push(t);
					}else if(!beginVisibleTile){
						//未找到第一个可见铺砖时，允许不在裁剪区内的砖进行记录
						unpaves.push(t);
						addTiles.push(t);
					}
			  }
		}.bind(boundaryModel));
		
		addTiles.forEach(function(t){
			floorRectTiles.push(t);
		});
	};
    
  ret.tiles = floorRectTiles;  
  return ret;
}

function utilBoundaryBuildTilePave(){
	var gap = this.gapwidth;
	var floorModel = this;
	var profile = null;
	var insideProfile = null;
	var material = null;
					
	if(this.paveRebuild){
		  var floorRectTiles = [];
		  //计算衬线
		  if(this.baseMaterial){
		  	this.baseOffsetX.length = this.baseLoops.length;//重置baseLoop偏移数组大小
		  	this.baseLoops.forEach(function(profile, index){
		  		var paveTiles = genBoundaryTiles(profile, "base", index, this, this.baseOffsetX[index]);
		  		if(paveTiles){		  			
		  			floorRectTiles.push(paveTiles);
		  		}
		  	}.bind(this));		  	
		  }
		  //计算转角
		  if(this.cornerMaterial){
		  	this.cornerLoops.forEach(function(profile, index){		  	
		  		var paveTiles = genBoundaryTiles(profile, "corner", index, this);
		  		if(paveTiles){
		  			floorRectTiles.push(paveTiles);
		  		}
		  	}.bind(this));
		  }
		  //lr段
		  if(this.leftMaterial){
		  	this.leftLoops.forEach(function(profile, index){		  	
		  		var paveTiles = genBoundaryTiles(profile, "left", index, this);
		  		if(paveTiles){
		  			floorRectTiles.push(paveTiles);
		  		}
		  	}.bind(this));
		  }
		  if(this.rightMaterial){
		  	this.rightLoops.forEach(function(profile, index){
		  		var paveTiles = genBoundaryTiles(profile, "right", index, this, this.rightOffsetX[index]);
		  		if(paveTiles){
		  			floorRectTiles.push(paveTiles);
		  		}
		  	}.bind(this));
		  }
		  
		  this.floorRectTiles = floorRectTiles;
	}	    
	  
	this.paveRebuild = false;
}

//# sourceURL=src\model\boundary.js