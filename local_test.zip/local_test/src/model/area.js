function Area(opt) {
    classBase(this, opt);
    this.opt = opt;
    this.host = opt ? opt.host : void 0;
    var category = opt && DEFAULT_AREA_MATERIAL[opt.category] ? opt.category : AREA_INNER_CATEGORY_ID;
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "areaMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "level", 0, propertyChanged);
    utilRootDefineProperty(this, "category", category, propertyChanged);
    utilRootDefineProperty(this, "group", void 0, propertyChanged);
    utilRootDefineProperty(this, "cavern", false, propertyChanged);
    utilRootDefineProperty(this, "areaColor", utilColorHexString(), propertyChanged);
    
    utilRootDefineProperty(this, "z", 0, propertyChanged);         //离地高度
    utilRootDefineProperty(this, "height3d", 0, propertyChanged);  //墙高
    
    
    //paveMaterial 0~9 提供最多10组独立的纹理
    for(var i=0;i<10;++i){
    	utilRootDefineProperty(this, "pave" + i + "Material", void 0, linkChanged);
    }
    
    //by mond 2017
    utilRootDefineProperty(this, "rootMaterial", void 0, linkChanged);    //砖缝颜色纹理
    utilRootDefineProperty(this, "paveType", "SINGLEPAVE_01", propertyChanged);     //铺贴方式，默认连续直铺
    this.rootMaterial = new MaterialRawColor({color:utilStringToHexCharCode(DEFAULT_FLOOR_ROOTCOLOR)});    
    this.paveDB = {}; //铺贴记录(选砖，选砖)   
    utilRootDefineProperty(this, "gapwidth", 0.003, propertyChanged);//this.gapwidth = 0.003; //初始化默认0.003米
    utilRootDefineProperty(this, "gapcolor", DEFAULT_FLOOR_ROOTCOLOR, propertyChanged);//this.gapcolor = DEFAULT_FLOOR_ROOTCOLOR; 
    this.rebuild = utilFloorBuildTilePave.bind(this);
    //新增铺贴相关初始化
    
    this.clearPaveDB = function(){
	  	this.paveDB = {};
	  }
}

Area.prototype.type = "AREABASE", classInherit(Area, ModelObject);

var AREAFLAG_CHANGED_FOR_REDRAWN = 512;
var AREA_INNER_CATEGORY_ID = "inner";
var AREA_OUTER_CATEGORY_ID = "outer";
var AREA_LEFT_CATEGORY_ID = "left";
var AREA_RIGHT_CATEGORY_ID = "right";
var AREA_SIDE0_CATEGORY_ID = "side0";
var AREA_SIDE1_CATEGORY_ID = "side1";
var AREA_SIDE2_CATEGORY_ID = "side2";
var AREA_SIDE3_CATEGORY_ID = "side3";
var AREA_BASEBOARD_ID = "baseboard";
var AREA_WALLBOARD_ID = "wallboard";
var DEFAULT_AREA_MATERIAL = {};

DEFAULT_AREA_MATERIAL[AREA_INNER_CATEGORY_ID] = "lightyellow";
DEFAULT_AREA_MATERIAL[AREA_OUTER_CATEGORY_ID] = "lightgrass";
DEFAULT_AREA_MATERIAL[AREA_LEFT_CATEGORY_ID]  = "lightyellow";
DEFAULT_AREA_MATERIAL[AREA_RIGHT_CATEGORY_ID] = "lightyellow";
DEFAULT_AREA_MATERIAL[AREA_SIDE0_CATEGORY_ID] = "lightyellow";
DEFAULT_AREA_MATERIAL[AREA_SIDE1_CATEGORY_ID] = "lightyellow";
DEFAULT_AREA_MATERIAL[AREA_SIDE2_CATEGORY_ID] = "lightyellow";
DEFAULT_AREA_MATERIAL[AREA_SIDE3_CATEGORY_ID] = "lightyellow";
DEFAULT_AREA_MATERIAL[AREA_BASEBOARD_ID]      = "p351ea1332b1d407aaf5ec4e371becd6a";
DEFAULT_AREA_MATERIAL[AREA_WALLBOARD_ID]      = "p6866902dcac84dac9484f703743e13a4";

var AREAFLAG_HOST_CHANGED_UPDATE3D = 512;

utilExtend(Area.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        this.areaMaterial && (saved.areaMaterial = this.areaMaterial.id);
        saved.category = this.category;
        saved.level = this.level;
        this.host && (saved.host = this.host.id);
        var measure = Math.abs(utilAreaGetMeasument(application, this));
        saved._m = measure;
        this.group && (saved.group = this.group.id);
        
        //by mond 2017
        this.rootMaterial && (saved.rootMaterial = this.rootMaterial.id);
        this.paveType && (saved.paveType = this.paveType);
        this.gapwidth && (saved.gapwidth = this.gapwidth);
        this.gapcolor && (saved.gapcolor = this.gapcolor);
        this.cavern && (saved.cavern = this.cavern);
        this.areaColor && (saved.areaColor = this.areaColor);        
        //this.paveDB && (saved.paveDB = this.paveDB);
        for(var i=0;i<10;++i){
        	this["pave" + i + "Material"] && (saved["pave" + i + "Material"] = this["pave" + i + "Material"].id);		    	
		    }
        //铺贴相关
        this.z && (saved.z = this.z);
        this.height3d && (saved.height3d = this.height3d);
        
        saved.profileNum = this.profileNum || 0;
        if(this.profileNum > 0){
        	for(var i=0;i<this.profileNum-1;++i){
				    saved["side" + i + "Boards"] = this["side" + i + "Boards"];
				  }
        }
        
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        if (data.host && (this.host = db[data.host]),
            this.category = DEFAULT_AREA_MATERIAL[data.category] ? data.category : AREA_INNER_CATEGORY_ID,
            data.level && (this.level = data.level),
            data.areaMaterial) {
            	if("object" == typeof data.areaMaterial){
            		if(data.areaMaterial.category == "tilesingle"){
            			this.areaMaterial = new TileSingle(data.areaMaterial);            			
            		}else{
            			this.areaMaterial = new Material(data.areaMaterial);
            		}            		
            		this.areaMaterial.load(data.areaMaterial);
            	}else if("string" == typeof data.areaMaterial){
            		this.areaMaterial = db[data.areaMaterial];
            	}            	
        } else {
            var pid = DEFAULT_AREA_MATERIAL[this.category];
            this.areaMaterial = new Material({
                pid: pid
            });
        }
        
        //by mond 2017
        if(data.rootMaterial){
        	if("object" == typeof data.rootMaterial){
        		this.rootMaterial = new MaterialRawColor(data.rootMaterial);
        		this.rootMaterial.load(data.rootMaterial);
        	}else if("string" == typeof data.rootMaterial){
        		this.rootMaterial = db[data.rootMaterial];
        	}
        }else{
        	this.rootMaterial = new MaterialRawColor({
            color: DEFAULT_FLOOR_ROOTCOLOR
          });
        };
        for(var i=0;i<10;++i){	
        	data["pave" + i + "Material"] ? this["pave" + i + "Material"] = db[data["pave" + i + "Material"]] : this["pave" + i + "Material"] = 0;
		    }
        data.paveType && (this.paveType = data.paveType);
        data.gapwidth && (this.gapwidth = data.gapwidth);
        data.gapcolor && (this.gapcolor = data.gapcolor);
        //data.paveDB && (this.paveDB = data.paveDB);
        if(!data.paveType && (this.areaMaterial instanceof TileSingle)){
        	//版本兼容，当没有铺贴方式时，读取tileSingle pavetype
        	var paveType = "SINGLEPAVE_01X";
	    		switch(this.areaMaterial.pavetype){
	    			case "0":
	    			  paveType = "SINGLEPAVE_01X";
	    			break;
	    			case "1":
	    			  paveType = "SINGLEPAVE_06";
	    			break;
	    			case "2":
	    			  paveType = "SINGLEPAVE_04";
	    			break;
	    			case "3":
	    			  //...
	    			break;
	    		}
	    		this.paveType = paveType;
        }
        //铺贴相关        
        data.group && utilGroupAddItem(db[data.group], this);        
        data.cavern && (this.cavern = data.cavern);
        data.areaColor && (this.areaColor = data.areaColor);
        data.z && (this.z = data.z);
        data.height3d && (this.height3d = data.height3d);
        
        this.profileNum = data.profileNum || 0;
        if(data.profileNum > 0){        	
        	for(var i=0;i<data.profileNum-1;++i){
				    data["side" + i + "Boards"] && (this["side" + i + "Boards"] = data["side" + i + "Boards"]);
				  }
        }
    },
    copy: function (source) {
        __assert(source instanceof Area, "Bad Copy From.");
        var data = source;
        this.category = data.category;
        this.host = data.host;
        this.level = data.level;
        this.level = utilAppFloorplanGetAreasByHostId(application, void 0, this.host && this.host.id, this.category).length + 1;
        this.areaMaterial = data.areaMaterial.clone();
        this.rootMaterial = data.rootMaterial.clone();
        this.paveType = data.paveType;
        this.gapwidth = data.gapwidth;
        this.gapcolor = data.gapcolor;
        this.cavern = data.cavern;
        this.z = data.z;
        this.height3d = data.height3d;
        
        for(var i=0;i<10;++i){
        	if(data["pave" + i + "Material"]){
        		this["pave" + i + "Material"] = data["pave" + i + "Material"].clone();
        	}else{
        		this["pave" + i + "Material"] = 0;
        	}
		    }
             
        this.profileNum = data.profileNum || 0;
        if(this.profileNum > 0){
        	for(var i=0;i<this.profileNum-1;++i){
				    this["side" + i + "Boards"] = data["side" + i + "Boards"];
				  }
        }
    },
    canGroup: function () {
        return !0;
    },
    getLoop: function (opt) {
        __assert(!1, "PLEASE OVERWRITE this function in derived class.");
    },
    getBound: function () {
        return utilBoundFromLoop(this.getLoop());
    },
    isValid: function () {
        return !1;
    },
    dispose: function() {
    	var fp = application.doc.floorplan;
    	
    	this.areaMaterial && (utilEntityRemoveLink(fp, this.areaMaterial),this.areaMaterial = null);
    	this.rootMaterial && (utilEntityRemoveLink(fp, this.rootMaterial),this.rootMaterial = null);    	
    	this.center && (this.center = null);
    	
    	for(var i=0;i<10;++i){
    		this["pave" + i + "Material"] && (utilEntityRemoveLink(fp, this["pave" + i + "Material"]),this["pave" + i + "Material"] = null);
  	  }
  	  
  	  if(this.cavern){
  	  	//刷新地面挖洞效果
  	  	utilRedrawnAllFloor3D();
  	  } 	  
  	  
  	  var area = this;
  	  //墙面区域铺贴
  	  utilAppFloorplanFilterEntity(application, function (e) {
          return e instanceof Area && e.host.id == area.id;
      }, fp).forEach(function (wallArea) {
          utilEntityRemoveLink(fp, wallArea);
      });
      
      //墙面铺贴
      if(this.host && this.host[this.category + "Boards"]){
		  	var index = this.host[this.category + "Boards"].indexOf(this.id);
		  	if(index != -1){
		  		this.host[this.category + "Boards"].splice(index,1);
		  	}
		  }
    }
});

function FreeArea(opt) {
    classBase(this, opt);
    linkPropertyChangedCalllback.bind(this);
    entityPropertyChangedCallback.bind(this);
    this.profile = [];
}
FreeArea.prototype.type = "FREEAREA";
classInherit(FreeArea, Area);
utilExtend(FreeArea.prototype, {
    save: function () {
        var saved = classBase(this, "save");
                
        return saved.profile = this.profile.map(function (p) {
            return p ? p.id : void 0;
        }).filter(function (p) {
            return void 0 != p;
        }), saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        
        var db = Root.prototype.database, profile = [];
        data.profile.forEach(function (p) {
            var pro = db[p];
            profile.push(pro);
        }, this), this.profile = profile, utilModelChangeFlag(this, AREAFLAG_CHANGED_FOR_REDRAWN);
    },
    // 获取区域顶点
    getLoop: function () {
        return utilFreeAreaGetLoopFromProfile(this);
    },
    isValid: function () {
        return this.profile.length > 2;
    }
});

function RectArea(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "center", void 0, linkChanged);
    utilRootDefineProperty(this, "width", 0, propertyChanged);
    utilRootDefineProperty(this, "height", 0, propertyChanged);
    utilRootDefineProperty(this, "rot", 0, propertyChanged);

    utilRootDefineProperty(this, "fixation", false, propertyChanged);    
}

RectArea.prototype.type = "RECTAREA";
classInherit(RectArea, Area);

var RECT_SIDE_VECTOR_MAP = {
    left: {
        x: -1,
        y: 0
    },
    right: {
        x: 1,
        y: 0
    },
    top: {
        x: 0,
        y: 1
    },
    bottom: {
        x: 0,
        y: -1
    }
}, RECT_SIDE_POINTS_OFFSET_FACTOR_MAP = {
    left: [{
        x: -1,
        y: -1
    }, {
        x: -1,
        y: 1
    }],
    right: [{
        x: 1,
        y: 1
    }, {
        x: 1,
        y: -1
    }],
    top: [{
        x: -1,
        y: 1
    }, {
        x: 1,
        y: 1
    }],
    bottom: [{
        x: 1,
        y: -1
    }, {
        x: -1,
        y: -1
    }]
};

utilExtend(RectArea.prototype, {
    canGroup: function () {
        return !0;
    },
    save: function () {
        var saved = classBase(this, "save");
        
        return this.center || __assert(!1, "Rect Area must has a center point."), this.center && (saved.center = this.center.id),
            saved.width = this.width, saved.height = this.height, saved.rot = this.rot, saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        
        var db = Root.prototype.database;
        this.center = db[data.center], this.width = data.width, this.height = data.height,
            this.rot = data.rot;
    },
    copy: function (source) {
        classBase(this, "copy", source);
        var data = source;
        this.width = data.width, this.height = data.height, this.rot = data.rot, this.center = data.center.clone();
    },
    getLoop: function (opt) {
        return utilRectAreaGetLoop(this, opt);
    },
    isValid: function () {
        return !isNaN(this.center.x) && !isNaN(this.center.y) && !isNaN(this.width) && !isNaN(this.height) && this.width > .01 && this.height > .01;
    },
    boundSnap: function () {
        return utilRectAreaBoundSnap(this);
    },
    edgeSnap: function (side) {
        return utilRectAreaEdgeSnap(this, side);
    }
});

var AREA_SNAP_TOLERANCE = .1;

function RectArea3d(opt) {
    classBase(this, opt);
    this.gapwidth = 0;
    this.paveType = "SINGLEPAVE_01X";
}
RectArea3d.prototype.type = "RECTAREA3D";
classInherit(RectArea3d, RectArea);

//rectarea3d
///////////////////////////////////////////////////////////////////////////////////////////

function RoundArea(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "center", void 0, linkChanged);
    utilRootDefineProperty(this, "radius", 0, propertyChanged);
    utilRootDefineProperty(this, "sx", 1, propertyChanged);
    utilRootDefineProperty(this, "sy", 1, propertyChanged);
    utilRootDefineProperty(this, "rot", 0, propertyChanged);
}
function RoundArea3d(opt) {
    classBase(this, opt);
    this.gapwidth = 0;
    this.paveType = "SINGLEPAVE_01X";
}

RoundArea.prototype.type = "ROUNDAREA";
classInherit(RoundArea, Area);
RoundArea3d.prototype.type = "ROUNDAREA3D";
classInherit(RoundArea3d, RoundArea);
utilExtend(RoundArea.prototype, {
    canGroup: function () {
        return !0;
    },
    save: function () {
        var saved = classBase(this, "save");
        
        return this.center || __assert(!1, "Circle Area must has a center point."), this.center && (saved.center = this.center.id),
            saved.radius = this.radius, saved.sx = this.sx, saved.sy = this.sy, saved.rot = this.rot,
            saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        this.center = db[data.center], this.radius = data.radius, this.sx = data.sx, this.sy = data.sy,
            this.rot = data.rot;
    },
    copy: function (source) {
        classBase(this, "copy", source);
        var data = source;
        this.radius = data.radius, this.rot = data.rot, this.sx = data.sx, this.sy = data.sy,
            this.center = data.center.clone();
    },
    getLoop: function () {
        return utilRoundAreaGetLoop(this);
    },
    isValid: function () {
        return !isNaN(this.center.x) && !isNaN(this.center.y) && !isNaN(this.radius);
    },
    boundSnap: function () {
        return utilRoundAreaCenterSanp(this);
    }
});

//墙铺贴
function Wallboard(opt) {
	  classBase(this, opt);
}
Wallboard.prototype.type = "WALLBOARD";
classInherit(Wallboard, RectArea3d);
utilExtend(Wallboard.prototype, {
	getLoop: function () {
      return utilWallboardGetLoop(this);
  },
  copy: function(source){
  	  classBase(this, "copy", source);
  	  this.level = 0;
  }
});

//踢脚线
function Baseboard(opt) {
	  classBase(this, opt);
}
Baseboard.prototype.type = "BASEBOARD";
classInherit(Baseboard, RectArea3d);
utilExtend(Baseboard.prototype, {
	getLoop: function () {
      return utilBaseboardGetLoop(this);
  },
  copy: function(source){
  	  classBase(this, "copy", source);
  	  this.level = 0;
  }
});


///////////////////////////////////////////////////////////////////////////////////
//公共函数
function utilRectAreaGetLoop(area, opt) {
    if (!(area.width < .01 || area.height < .01) && area.center) {
        var c = area.center, w = area.width, h = area.height, rot = opt && void 0 !== opt.rot ? opt.rot : area.rot, loop = [{
            x: c.x - w / 2,
            y: c.y - h / 2,
            z: 0
        }, {
            x: c.x - w / 2,
            y: c.y + h / 2,
            z: 0
        }, {
            x: c.x + w / 2,
            y: c.y + h / 2,
            z: 0
        }, {
            x: c.x + w / 2,
            y: c.y - h / 2,
            z: 0
        }, {
            x: c.x - w / 2,
            y: c.y - h / 2,
            z: 0
        }];
        return loop.map(function (pt) {
            return utilMathRotatePointCW(c, pt, rot);
        });
    }
}
function utilRoundAreaGetLoop(area) {
    if (!(area.radius < .05) && area.center) {
        for (var loop = [], firstPt = Vec2.sum(area.center, {
            x: area.radius,
            y: 0
        }), i = 0; 361 > i; i += 10) {
            var pt = utilMathRotatePointCW(area.center, firstPt, i);
            pt.subtract(area.center).scale(area.sx, area.sy).add(area.center), loop.push(pt);
        }
        return loop;
    }
}
function utilFreeAreaGetLoopFromProfile(freeArea) {
    if (freeArea && freeArea.profile) {
        var loop = freeArea.profile.map(function (curve) {
            return curve && curve.type && curve.type == Curve.prototype.type ? curve.begin : void __assert(!1, "FreeArea should be a loop of 'Curve' class, please check.");
        });
        loop.push(loop[0]);
        for (var i = 0, len = loop.length; len > i; ++i) {
            var pt = loop[i];
            if (!pt || isNaN(pt.x) || isNaN(pt.y)) return;
        }
        return loop;
    }
}
function utilBaseboardGetLoop(area, opt) {
	  if(!area.center){
	  	return;
	  }
	
	  var width = area.width;
	  if(area.host.type == "RECTAREA" || area.host.type == "ROUNDAREA" || area.host.type == "FREEAREA"){
	  	width = utilModelWallGetSideLength(area.host, area.category);	
	  }else if(area.host.type == "WALL"){
		  var geom = utilModelWallGetTessellates(area.host, 0);
			switch(area.category){
				case "right":
				  if(area.host.bezier){
				  	width = utilMathLineLength(geom[1], geom[7][0]);
				  	for(var i=1;i<geom[7].length;++i){
				  		width += utilMathLineLength(geom[7][i-1], geom[7][i]);
				  	}
				  	width += utilMathLineLength(geom[7][geom[7].length - 1], geom[2]);
				  }else{
			  	  width = utilModelWallGetSideLength(area.host, area.category);		  		          	
			  	}  		          	
				break;
				case "left":
				  if(area.host.bezier){
				  	width = utilMathLineLength(geom[4], geom[8][0]);
				  	for(var i=1;i<geom[8].length;++i){
				  		width += utilMathLineLength(geom[8][i-1], geom[8][i]);
				  	}
				  	width += utilMathLineLength(geom[8][geom[8].length - 1], geom[5]);
				  }else{
				    width = utilModelWallGetSideLength(area.host, area.category);
				  }
				break;
				case "side0":
				case "side1":
				  width = utilModelWallGetSideLength(area.host, area.category);
				break;
			}
	  }
	  
	  area.center.x = width/2.0;
		area.center.y = area.height/2.0;
			
    if (!(width < .01 || area.height < .01) && area.center) {
        var c = area.center, w = width, h = area.height, rot = opt && void 0 !== opt.rot ? opt.rot : area.rot, loop = [{
            x: c.x - w / 2,
            y: c.y - h / 2,
            z: 0
        }, {
            x: c.x - w / 2,
            y: c.y + h / 2,
            z: 0
        }, {
            x: c.x + w / 2,
            y: c.y + h / 2,
            z: 0
        }, {
            x: c.x + w / 2,
            y: c.y - h / 2,
            z: 0
        }, {
            x: c.x - w / 2,
            y: c.y - h / 2,
            z: 0
        }];
        return loop.map(function (pt) {
            return utilMathRotatePointCW(c, pt, rot);
        });
    }
}

function utilWallboardGetLoop(area, opt) {
	  if(!area.center){
	  	return;
	  }
	  var width = area.width;
	  
	  if(area.host.type == "RECTAREA" || area.host.type == "ROUNDAREA" || area.host.type == "FREEAREA"){
	  	width = utilModelWallGetSideLength(area.host, area.category);	
	  }else if(area.host.type == "WALL"){
	  	var geom = utilModelWallGetTessellates(area.host, 0);
			switch(area.category){
				case "right":
				  if(area.host.bezier){
				  	width = utilMathLineLength(geom[1], geom[7][0]);
				  	for(var i=1;i<geom[7].length;++i){
				  		width += utilMathLineLength(geom[7][i-1], geom[7][i]);
				  	}
				  	width += utilMathLineLength(geom[7][geom[7].length - 1], geom[2]);
				  }else{
				  	width = utilModelWallGetSideLength(area.host, area.category);
			  	}
				break;
				case "left":
				  if(area.host.bezier){
				  	width = utilMathLineLength(geom[4], geom[8][0]);
				  	for(var i=1;i<geom[8].length;++i){
				  		width += utilMathLineLength(geom[8][i-1], geom[8][i]);
				  	}
				  	width += utilMathLineLength(geom[8][geom[8].length - 1], geom[5]);
				  }else{
				  	width = utilModelWallGetSideLength(area.host, area.category);
				  }
				break;
				case "side0":			  
				case "side1":
				  width = utilModelWallGetSideLength(area.host, area.category);
				break;
			}
	  }
	  
		
		var offsetH = utilWallGetWallboardOffsetH(area);
		
		area.center.x = width/2.0;
		area.center.y = area.height/2.0 + offsetH;
		
    if (!(width < .01 || area.height < .01) && area.center) {
        var c = area.center, w = width, h = area.height, rot = opt && void 0 !== opt.rot ? opt.rot : area.rot, loop = [{
            x: c.x - w / 2,
            y: c.y - h / 2,
            z: 0
        }, {
            x: c.x - w / 2,
            y: c.y + h / 2,
            z: 0
        }, {
            x: c.x + w / 2,
            y: c.y + h / 2,
            z: 0
        }, {
            x: c.x + w / 2,
            y: c.y - h / 2,
            z: 0
        }, {
            x: c.x - w / 2,
            y: c.y - h / 2,
            z: 0
        }];
        return loop.map(function (pt) {
            //return utilMathRotatePointCW(c, pt, rot);
            pt.y = pt.y > Math.abs(area.host.height3d) ? Math.abs(area.host.height3d) : pt.y;
            return pt;
        });        
    }
}
// sourceURL=src\model\area.js