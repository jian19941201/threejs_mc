//窗户
function Windows(meta) {
    classBase(this, meta);
}

Windows.prototype.type = "WINDOW";
classInherit(Windows, Opening);
utilExtend(Windows.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
    }
})