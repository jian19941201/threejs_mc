var POINT_CHANGED_FOR_FROZEN = 512;
function Point(opt) {
    classBase(this, opt);
    var cb = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "x", NaN, cb);
    utilRootDefineProperty(this, "y", NaN, cb);
    utilRootDefineProperty(this, "z", 0, cb);
    utilRootDefineProperty(this, "flag", 0, defaultPropertyChangedCallbackInternal.bind(this));
}

function utilPointGetHost(point) {
    var hosts = point.lt;
    var hostsId = Object.keys(hosts);
    return hosts[hostsId[0]];
}

Point.prototype.type = "POINT";
classInherit(Point, ModelObject);
utilExtend(Point.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.x = this.x, saved.y = this.y, saved.z = this.z, saved;
    },
    load: function (data) {
        classBase(this, "load", data), this.x = data.x, this.y = data.y, data.z && (this.z = data.z);
    },
    clone: function () {
        var rv = new TYPE[this.type](this.opt);
        return rv.x = this.x, rv.y = this.y, rv.z = this.z, rv;
    },
    getBound: function () {
        var bound = new Bound(1 / 0, 1 / 0, 0, 0);
        return bound.addPoint({
            x: this.x,
            y: this.y
        }), bound;
    }
})

//贝塞尔控制点
function BezierPoint(opt) {
    classBase(this, opt);
    var cb = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "x", opt.x, cb);
    utilRootDefineProperty(this, "y", opt.y, cb);
    utilRootDefineProperty(this, "z", 0, cb);
    utilRootDefineProperty(this, "flag", 0, defaultPropertyChangedCallbackInternal.bind(this));
}

BezierPoint.prototype.type = "BEZIERPOINT";
classInherit(BezierPoint, ModelObject);
utilExtend(BezierPoint.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.x = this.x, saved.y = this.y, saved.z = this.z, saved;
    },
    load: function (data) {
        classBase(this, "load", data), this.x = data.x, this.y = data.y, data.z && (this.z = data.z);
    },
    clone: function () {
        var rv = new TYPE[this.type](this.opt);
        return rv.x = this.x, rv.y = this.y, rv.z = this.z, rv;
    },
    getBound: function () {
        var bound = new Bound(1 / 0, 1 / 0, 0, 0);
        return bound.addPoint({
            x: this.x,
            y: this.y
        }), bound;
    }
})