function Opening(meta) {
    classBase(this, meta);
    var propertyChanged = (linkPropertyChangedCalllback.bind(this),
    entityPropertyChangedCallback.bind(this));
    
    utilRootDefineProperty(this, "swing", 0, propertyChanged);
    this.extra = meta.extra ? JSON.parse(meta.extra) : {};
    this.profile = [{
        x: 0,
        y: 0
    }, {
        x: 1,
        y: 0
    }, {
        x: 1,
        y: 1
    }, {
        x: 0,
        y: 1
    }, {
        x: 0,
        y: 0
    }];
    if (this.extra.profile) {
        var p = this.extra.profile;
        __assert(p.length % 2 == 0), this.profile = [];
        for (var i = 0, len = p.length; len > i; i += 2){
        	 this.profile.push({
            x: p[i],
            y: p[i + 1]
           });
        }
    }
}

Opening.prototype.type = "OPENING";
classInherit(Opening, Product);
utilExtend(Opening.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved.swing = this.swing, saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        Root.prototype.database;
        data.swing && (this.swing = data.swing);
    },
    copy: function (source) {
        __assert(source instanceof Opening, "Bad Copy From."), classBase(this, "copy", source),
            this.swing = source.swing;
    }
})
