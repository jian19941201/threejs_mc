//平面图
function Floorplan(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "cameraPerson", void 0, linkChanged);
    utilRootDefineProperty(this, "cameraFly", void 0, linkChanged);
    utilRootDefineProperty(this, "underImage", void 0, linkChanged);
    this.compassRotation = 0;
}

Floorplan.prototype.type = "FLOORPLAN", classInherit(Floorplan, ModelObject);

var MODELFLAG_LOCKED = 16;
var FLOORPLAN_FLAG_CHANGED_FOR_REDRAWN = 512;

utilExtend(Floorplan.prototype, {
    init: function () {
        this.cameraPerson = new Camera({
            id: "cameraPerson"
        }), this.cameraPerson.name = CAMERA_PERSON_DEFAULT_NAME, this.cameraPerson.active = !0,
            this.cameraFly = new Camera({
                id: "cameraFly"
            }),
            this.cameraFly.name = CAMERA_FLY_DEFAULT_NAME,
            this.cameraFly.z = 10,  //change by gaoning 2016.12.7
            this.cameraFly.x = 0,
            this.cameraFly.y = -10,
            this.cameraFly.tx = 0,
            this.cameraFly.ty = 0,
            this.cameraFly.pitch = -45,
            this.cameraFly.hfov = 60,
            //console.log("come here......");
            utilGroupReset(this, GROUP_TEMP);
            utilEntityAddLink(this, GROUP_TEMP);
            this.propertyChangedEvent.add(function (fieldName, oldValue, newValue) {
                "flag" == fieldName && (oldValue & MODELFLAG_LOCKED) != (newValue & MODELFLAG_LOCKED) && utilFloorplanLockFlagChangedNotify(this, newValue);
            }.bind(this));
    },


    save: function () {
        var saved = classBase(this, "save");
        return saved.cameraPerson = this.cameraPerson.id, saved.cameraFly = this.cameraFly.id,
        this.underImage && (saved.underImage = this.underImage.id), saved.compassRotation = this.compassRotation,
            saved;
    },
    load: function (designJson) {
        classBase(this, "load", designJson);
        designJson.cameraPerson && (this.cameraPerson = this.database[designJson.cameraPerson]);
        designJson.cameraFly && (this.cameraFly = this.database[designJson.cameraFly]);
        designJson.underImage && (this.underImage = this.database[designJson.underImage]);
        designJson.compassRotation && (this.compassRotation = designJson.compassRotation);
    },
    destroy: function () {
        this.cameraPerson = void 0, this.cameraFly = void 0;
    }
})

//# sourceURL=src\model\floorplan.js