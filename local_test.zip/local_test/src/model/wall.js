function Curve(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "begin", void 0, linkChanged);
    utilRootDefineProperty(this, "end", void 0, linkChanged);
    utilRootDefineProperty(this, "bezier", void 0, linkChanged); //贝塞尔控制点
}

function utilCurveGetSideNormal(wall, side) {
    var dir = Vec2.difference(wall.end, wall.begin);
    return "right" == side ? {
        x: dir.y,
        y: -dir.x,
        z: 0
    } : {
        x: -dir.y,
        y: dir.x,
        z: 0
    };
}

Curve.prototype.type = "CURVE";
classInherit(Curve, ModelObject);
utilExtend(Curve.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        this.begin && (saved.begin = this.begin.id);
        this.end && (saved.end = this.end.id);
        this.bezier && (saved.bezier = this.bezier.id);
        
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        data.begin && (this.begin = db[data.begin]);
        data.end && (this.end = db[data.end]);
        data.bezier && (this.bezier = db[data.bezier]);
    }
});

function Wall(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "leftMaterial",  void 0, linkChanged);
    utilRootDefineProperty(this, "rightMaterial", void 0, linkChanged);    
    utilRootDefineProperty(this, "side0Material", void 0, linkChanged);
    utilRootDefineProperty(this, "side1Material", void 0, linkChanged);
    utilRootDefineProperty(this, "side2Material", void 0, linkChanged);
    utilRootDefineProperty(this, "side3Material", void 0, linkChanged);
    utilRootDefineProperty(this, "stoneMaterial", void 0, linkChanged);//门槛石
    utilRootDefineProperty(this, "width", DEFAULT_WALL_WIDTH, propertyChanged);
    utilRootDefineProperty(this, "height3d", DEFAULT_WALL_HEIGHT3D, propertyChanged);
    utilRootDefineProperty(this, "transparent", DEFAULT_WALL_TRANSPARENT, propertyChanged);
    this.linkPropertyChangedEvent.add(utilModelWallPointXYChanged.bind(void 0, this));
    
    this.stoneMaterial = new Material({pid: DEFAULT_WALL_STONEMATERIAL_ID});
    
    //墙面铺贴
    this.leftBoards = [];
    this.rightBoards = [];
    this.side0Boards = [];
    this.side1Boards = [];
}

Wall.prototype.type = "WALL";
classInherit(Wall, Curve);
var DEFAULT_WALL_WIDTH = .15;
var DEFAULT_WALL_WIDTH_INNER = -0.25;  //add by gaoning 2017.8.14 内墙线
var DEFAULT_WALL_HEIGHT3D = 2.8;
var DEFAULT_WALL_TRANSPARENT = 0;
var WALLFLAG_DETAILEDUPDATED_2D = 256;
var WALLFLAG_DETAILEDUPDATED_3D = 512;
var WALLFLAG_LOAD_BEARING = 1024;
var DEFAULT_WALL_STONEMATERIAL_ID = "pd7ab09cd25e74cdeaf2591d91361d0f7";   //俄罗斯金 门槛石

utilExtend(Wall.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return this.leftMaterial  && (saved.leftMaterial  = this.leftMaterial.id),
               this.rightMaterial && (saved.rightMaterial = this.rightMaterial.id),
               this.side0Material && (saved.side0Material = this.side0Material.id),
               this.side1Material && (saved.side1Material = this.side1Material.id),
               this.side2Material && (saved.side2Material = this.side2Material.id),
               this.side3Material && (saved.side3Material = this.side3Material.id),
               this.stoneMaterial && (saved.stoneMaterial = this.stoneMaterial.id),
            saved.width = this.width, saved.height3d = this.height3d, saved.transparent = this.transparent,
            this.leftBoards && (saved.leftBoards = this.leftBoards),
				    this.rightBoards && (saved.rightBoards = this.rightBoards),
				    this.side0Boards && (saved.side0Boards = this.side0Boards),
				    this.side1Boards && (saved.side1Boards = this.side1Boards),
            saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        var db = Root.prototype.database;
        data.leftMaterial  && (this.leftMaterial  = db[data.leftMaterial]),
        data.rightMaterial && (this.rightMaterial = db[data.rightMaterial]),
        data.side0Material && (this.side0Material = db[data.side0Material]),
        data.side1Material && (this.side1Material = db[data.side1Material]),
        data.side2Material && (this.side2Material = db[data.side2Material]),
        data.side3Material && (this.side3Material = db[data.side3Material]),
        data.stoneMaterial && (this.stoneMaterial = db[data.stoneMaterial]),        
        data.leftBoards && (this.leftBoards = data.leftBoards),
        data.rightBoards && (this.rightBoards = data.rightBoards),
        data.side0Boards && (this.side0Boards = data.side0Boards),
        data.side1Boards && (this.side1Boards = data.side1Boards),
        this.width = data.width || .3, 
        this.height3d = data.height3d || 2.6, 
        this.transparent = data.transparent || DEFAULT_WALL_TRANSPARENT;
    },
    dispose: function(){
    	  var fp = application.doc.floorplan;
    	  var wall = this;
    	  utilAppFloorplanFilterEntity(application, function (e) {
            return e instanceof Area && e.host.id == wall.id;
        }, fp).forEach(function (wallArea) {
            utilEntityRemoveLink(fp, wallArea);
        });
        
        this.leftMaterial = null;
        this.rightMaterial = null;
        this.side0Material = null;
        this.side1Material = null;
        this.side2Material = null;
        this.side3Material = null;
        this.stoneMaterial = null;
    }
});

function utilModelWallGetLength(wall) {
    return utilMathLineLength(wall.begin, wall.end);
}

function utilModelWallGetAttached(fp, wall, type) {
    var openings = [];
    return utilFloorplanForEachProduct(fp, function (prod) {
        prod instanceof type && prod.attached && prod.attached.id == wall.id && !wall.bezier && openings.push(prod);
    }), openings;
}

function utilModelWallPointXYChanged(wall, pt, propName, oldV, newV, e) {
    if (pt && wall.begin && wall.end && !(pt.id != wall.begin.id && pt.id != wall.end.id || "x" != propName && "y" != propName)) {
        var fp = application.doc.floorplan;
        var openings = utilModelWallGetAttached(fp, wall, Opening);
        0 != openings.length && openings.forEach(function (opening) {
            if (this.begin && this.end && !(isNaN(this.begin.y) || isNaN(this.end.y) || isNaN(this.begin.x) || isNaN(this.end.x))) {
                var pos = utilMathGetPerpendicularIntersect(opening, this.begin, this.end);
                opening.x = pos.x;
                opening.y = pos.y;
                opening.rot = utilMathGetAngleHorizontaleCCW(this.begin, this.end);
            }
        }, wall);
    }
}

//矩形嵌合
function utilModelWallGetTessellates(wall, isSimplified) {
	  if(!wall)
	    return;
	  //重置墙面左侧右侧平滑过渡墙体id
	  wall._smoothWallID = [0,0,0,0];//分别表示 left_begin_turnLeft, left_end_turnRight, right_end_turnLeft, right_begin_turnRight
	  
	  if(wall.bezier){
	  	return utilModelWallGetBezierTessellates(wall, isSimplified);
	  }
	  
	  var maxSmoothAngle = 10;
	  var geom = utilWallGetSimpleGeom(wall);
    if (wall && wall.end && wall.begin && geom) {    		
        if (wall._lines = geom, wall._geom = geom, 0 == isSimplified) {
            var road;
            var sameDir;
            var fp = application.doc.floorplan;
            var beginTurnLeft = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !1);
            var beginTurnRight = utilWallWalkingTurns(fp, wall, wall.end, wall.begin, !0);
            var endTurnLeft = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !1);
            var endTurnRight = utilWallWalkingTurns(fp, wall, wall.begin, wall.end, !0);
            
            var beginTurnLeftSimpleGeom = beginTurnLeft ? utilWallGetSimpleGeom(beginTurnLeft.road) : null;              
            var beginTurnRightSimpleGeom = beginTurnRight ? utilWallGetSimpleGeom(beginTurnRight.road) : null;
            var endTurnLeftSimpleGeom = endTurnLeft ? utilWallGetSimpleGeom(endTurnLeft.road) : null;
            var endTurnRightSimpleGeom = endTurnRight ? utilWallGetSimpleGeom(endTurnRight.road) : null;

            var v1 = geom[1];
            var v2 = geom[2];
            var v4 = geom[4];
            var v5 = geom[5];

            if (beginTurnLeft && wall._lines) {
            	  if(Math.abs(beginTurnLeft.angle - 180) < maxSmoothAngle && !beginTurnLeft.road.bezier){
            	  	wall._smoothWallID[0] = {wall:beginTurnLeft.road, sameDir:beginTurnLeft.sameRoadDir};
            	  } 
            	  
                road = beginTurnLeft.road;
                sameDir = beginTurnLeft.sameRoadDir;
                if(road.bezier){
                	//曲面墙
                	v1 = utilWallStraightIntrBezier(beginTurnLeft, geom, beginTurnLeftSimpleGeom, "beginTurnLeft");                	
                }else{
                	var isParallel = utilMathIsLineParallel(wall.begin, wall.end, road.begin, road.end);
	                var simpleGeom = beginTurnLeftSimpleGeom;
	                if (simpleGeom && !isParallel) {                    		
	                		v1 = utilMathLineLineIntersection(wall._lines[1], wall._lines[2], simpleGeom[sameDir ? 4 : 1], simpleGeom[sameDir ? 5 : 2]);
	                }                    
	                __assert(!isNaN(v1.x) && !isNaN(v1.y));
                }                
            }
            if (beginTurnRight && wall._lines) {
            	  if(Math.abs(beginTurnRight.angle - 180) < maxSmoothAngle && !beginTurnRight.road.bezier){
            	  	wall._smoothWallID[3] = {wall:beginTurnRight.road, sameDir:beginTurnRight.sameRoadDir};
            	  } 
            	  
                road = beginTurnRight.road;
                sameDir = beginTurnRight.sameRoadDir;
                if(road.bezier){
                	//曲面墙
                	v5 = utilWallStraightIntrBezier(beginTurnRight, geom, beginTurnRightSimpleGeom, "beginTurnRight");                	                	
                }else{
	                var isParallel = utilMathIsLineParallel(wall.begin, wall.end, road.begin, road.end);
	                var simpleGeom = beginTurnRightSimpleGeom;
	                if (simpleGeom && !isParallel) {
	                    v5 = utilMathLineLineIntersection(wall._lines[4], wall._lines[5], simpleGeom[sameDir ? 1 : 4], simpleGeom[sameDir ? 2 : 5]);
	                }
	                __assert(!isNaN(v5.x) && !isNaN(v5.y));
	              }
            }
            if (endTurnRight && wall._lines) {
            	  if(Math.abs(endTurnRight.angle - 180) < maxSmoothAngle && !endTurnRight.road.bezier){
            	  	wall._smoothWallID[1] = {wall:endTurnRight.road, sameDir:endTurnRight.sameRoadDir};
            	  } 
            	  
                road = endTurnRight.road;
                sameDir = endTurnRight.sameRoadDir;
                if(road.bezier){
                	//曲面墙
                	v2 = utilWallStraightIntrBezier(endTurnRight, geom, endTurnRightSimpleGeom, "endTurnRight");                	
                }else{
	                var isParallel = utilMathIsLineParallel(wall.begin, wall.end, road.begin, road.end);
	                var simpleGeom = endTurnRightSimpleGeom;
	                if (simpleGeom && !isParallel) {
	                    v2 = utilMathLineLineIntersection(wall._lines[1], wall._lines[2], simpleGeom[sameDir ? 1 : 4], simpleGeom[sameDir ? 2 : 5]);
	                }
	                __assert(!isNaN(v2.x) && !isNaN(v2.y));
	              }
            }
            if (endTurnLeft && wall._lines) {
            	  if(Math.abs(endTurnLeft.angle - 180) < maxSmoothAngle && !endTurnLeft.road.bezier){
            	  	wall._smoothWallID[2] = {wall:endTurnLeft.road, sameDir:endTurnLeft.sameRoadDir};
            	  }
            	  
                road = endTurnLeft.road;
                sameDir = endTurnLeft.sameRoadDir;
                if(road.bezier){
                	//曲面墙
                	v4 = utilWallStraightIntrBezier(endTurnLeft, geom, endTurnLeftSimpleGeom, "endTurnLeft");                	
                }else{
	                var isParallel = utilMathIsLineParallel(wall.begin, wall.end, road.begin, road.end);
	                var simpleGeom = endTurnLeftSimpleGeom;
	                if (simpleGeom && !isParallel) {
	                    v4 = utilMathLineLineIntersection(wall._lines[4], wall._lines[5], simpleGeom[sameDir ? 4 : 1], simpleGeom[sameDir ? 5 : 2]);
	                }
	                __assert(!isNaN(v4.x) && !isNaN(v4.y));
	              }
            }
            geom = [wall.begin, v1, v2, wall.end, v4, v5, wall.begin];
        }
        return __assert(!isNaN(geom[1].x) && !isNaN(geom[1].y)), wall._lines = geom, geom;
    }
}

//贝塞尔嵌合
function utilModelWallGetBezierTessellates(wall, isSimplified) {
	  var geom = utilWallGetSimpleBezierGeom(wall);
	  //var geomProfile = utilWallGetSimpleBezierProfileBuyGeom(geom);
	  
    if (wall && wall.end && wall.begin && wall.bezier && geom) {
    	  
    		if (wall._lines = geom, wall._geom = geom, 0 == isSimplified) {
    			  var road;
            var sameDir;
            var fp = application.doc.floorplan;
            var beginTurnLeft = utilWallWalkingTurns(fp, wall, wall.bezier, wall.begin, !1);
            var beginTurnRight = utilWallWalkingTurns(fp, wall, wall.bezier, wall.begin, !0);
            var endTurnLeft = utilWallWalkingTurns(fp, wall, wall.bezier, wall.end, !1);
            var endTurnRight = utilWallWalkingTurns(fp, wall, wall.bezier, wall.end, !0);
            
            //geom结构
            var beginTurnLeftSimpleGeom = beginTurnLeft ? utilWallGetSimpleGeom(beginTurnLeft.road) : null;              
            var beginTurnRightSimpleGeom = beginTurnRight ? utilWallGetSimpleGeom(beginTurnRight.road) : null;
            var endTurnLeftSimpleGeom = endTurnLeft ? utilWallGetSimpleGeom(endTurnLeft.road) : null;
            var endTurnRightSimpleGeom = endTurnRight ? utilWallGetSimpleGeom(endTurnRight.road) : null;
            
            //profile点结构
            //var beginTurnLeftSimpleProfile = beginTurnLeftSimpleGeom && beginTurnLeftSimpleGeom.length == 9 ? utilWallGetSimpleBezierProfileBuyGeom(beginTurnLeftSimpleGeom):null;  
            //var beginTurnRightSimpleProfile = beginTurnRightSimpleGeom && beginTurnRightSimpleGeom.length == 9 ? utilWallGetSimpleBezierProfileBuyGeom(beginTurnRightSimpleGeom):null;
            //var endTurnLeftSimpleProfile = endTurnLeftSimpleGeom && endTurnLeftSimpleGeom.length == 9 ? utilWallGetSimpleBezierProfileBuyGeom(endTurnLeftSimpleGeom):null;
            //var endTurnRightSimpleProfile = endTurnRightSimpleGeom && endTurnRightSimpleGeom.length == 9 ? utilWallGetSimpleBezierProfileBuyGeom(endTurnRightSimpleGeom):null;

            var v1 = {i:0,  p:geom[7][0]};//geom[7][0];  
            var v2 = {i:19, p:geom[7][19]};//geom[7][19];          
                        
            var v4 = {i:0,  p:geom[8][0]};//geom[8][0];
            var v5 = {i:19, p:geom[8][19]};//geom[8][19];
            
            if (beginTurnLeft && wall._lines) {
                var road = beginTurnLeft.road;
                var simpleGeom = beginTurnLeftSimpleGeom;                
                var sameDir = beginTurnLeft.sameRoadDir;
                                
                if(road.bezier){
                	//曲面墙跟曲面墙
                	var bIb = utilWallBezierIntrBezier(beginTurnLeft,simpleGeom, geom, "beginTurnLeft");
                	v1.i = bIb.i != null ? bIb.i : v1.i;
                	v1.p = bIb.intr;
                }else{
                	var p1 = simpleGeom[sameDir ? 4 : 1];
	                var p2 = simpleGeom[sameDir ? 5 : 2]; 
	                
	                var intr = false;
	                if(beginTurnLeft.angle > 180){
	                	//找出交点
	                	
	                	for(var i=0;i<19;++i){
	                		var p3 = geom[7][i];
	                		var p4 = geom[7][i + 1];
	                		intr = segmentsIntr(p1,p2,p3,p4);
	                		if(intr){
	                			//得到交点索引截止点
	                			v1.i = i;
	                			v1.p = intr;
	                			break;
	                		}
	                	}
	                }
	                
	                if(!intr){
	                	var p3 = geom[7][0];
	                	var p4 = geom[7][1];
	                	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	                	if(!isParallel){
	                		intr = utilMathLineLineIntersection(p1, p2, p3, p4);
	                		v1.p = intr;
	                	}else{
	                		//平行，使用1节点,不变
	                		v1.p = p2;
	                	}
	                }
                }
            }
            if (beginTurnRight && wall._lines) {
                var road = beginTurnRight.road;
                var simpleGeom = beginTurnRightSimpleGeom;                
                var sameDir = beginTurnRight.sameRoadDir;
                
                if(road.bezier){
                	var bIb = utilWallBezierIntrBezier(beginTurnRight,simpleGeom, geom, "beginTurnRight");
                	v5.i = bIb.i != null ? bIb.i : v5.i;
                	v5.p = bIb.intr;
                }else{
	                var p1 = simpleGeom[sameDir ? 1 : 4];
	                var p2 = simpleGeom[sameDir ? 2 : 5];
	                
	                var intr = false;
	                if(beginTurnRight.angle < 180){
	                	//找出交点	                	                	
	                	for(var i=19;i>0;--i){
	                		var p3 = geom[8][i];
	                		var p4 = geom[8][i - 1];
	                		intr = segmentsIntr(p1,p2,p3,p4);
	                		if(intr){
	                			//得到交点索引截止点
	                			v5.i = i;
	                			v5.p = intr;
	                			break;
	                		}
	                	}     	
	                }
	                
	                if(!intr){
	                	var p3 = geom[8][19];
	                	var p4 = geom[8][18];
	                	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	                	if(!isParallel){
	                		intr = utilMathLineLineIntersection(p1, p2, p3, p4);
	                		v5.p = intr;
	                	}else{
	                		//平行，使用41节点,不变
	                		v5.p = p1;
	                	}
	                }
	              }
            }
            if (endTurnRight && wall._lines) {
                var road = endTurnRight.road;
                var simpleGeom = endTurnRightSimpleGeom;
                var sameDir = endTurnRight.sameRoadDir;
                
                if(road.bezier){
                	//求两曲线的交点
                	var bIb = utilWallBezierIntrBezier(endTurnRight,simpleGeom, geom, "endTurnRight");
                	v2.i = bIb.i != null ? bIb.i : v2.i;
                	v2.p = bIb.intr;
                }else{
	                var p1 = simpleGeom[sameDir ? 1 : 4];
	                var p2 = simpleGeom[sameDir ? 2 : 5];  
	                	
	                var intr = false;
	                if(endTurnRight.angle < 180){
	                	//找出交点              	
	                	for(var i=19;i>0;--i){
	                		var p3 = geom[7][i];
	                		var p4 = geom[7][i - 1];
	                		intr = segmentsIntr(p1,p2,p3,p4);
	                		if(intr){
	                			//得到交点索引截止点
	                			v2.i = i;
	                			v2.p = intr;
	                			break;
	                		}
	                	}   	
	                }
	                
	                if(!intr){
	                	var p3 = geom[7][19];
	                	var p4 = geom[7][18];
	                	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	                	if(!isParallel){
	                		intr = utilMathLineLineIntersection(p1, p2, p3, p4);
	                		v2.p = intr;
	                	}else{
	                		//平行，使用20节点，不变
	                		v2.p = p1;
	                	}
	                }
	              }
            }
            if (endTurnLeft && wall._lines) {
                var road = endTurnLeft.road;
                var simpleGeom = endTurnLeftSimpleGeom;                
                var sameDir = endTurnLeft.sameRoadDir;
                
                if(road.bezier){
                	var bIb = utilWallBezierIntrBezier(endTurnLeft,simpleGeom, geom, "endTurnLeft");
                	v4.i = bIb.i != null ? bIb.i : v4.i;
                	v4.p = bIb.intr;
                }else{
	                var p1 = simpleGeom[sameDir ? 4 : 1];
	                var p2 = simpleGeom[sameDir ? 5 : 2];
	                
	                var intr = false;
	                if(endTurnLeft.angle > 180){
	                	//找出交点	                	
	                	for(var i=0;i<19;++i){
	                		var p3 = geom[8][i];
	                		var p4 = geom[8][i + 1];
	                		intr = segmentsIntr(p1,p2,p3,p4);
	                		if(intr){
	                			//得到交点索引截止点
	                			v4.i = i;
	                			v4.p = intr;
	                			break;
	                		}
	                	}
	                }
	                
	                if(!intr){
	                	var p3 = geom[8][0];
	                	var p4 = geom[8][1];
	                	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	                	if(!isParallel){
	                		intr = utilMathLineLineIntersection(p1, p2, p3, p4);
	                		v4.p = intr;
	                	}else{
	                		//平行，使用22节点,不变;
	                		v4.p = p2;
	                	}
	                }
	              }
            }
            
            var bezierGeomV12 = []; //两段曲线点V12
            //bezierGeomV12.push(v1.p);
            for(var i = v1.i + 1;i<v2.i; ++i){
            	bezierGeomV12.push(geom[7][i]);
            }
            //retGeom.push(v2.p);
            
            var bezierGeomV45 = []; //两段曲线点V45
            //bezierGeomV45.push(v4.p);
            for(var i = v4.i + 1;i<v5.i;++i){
            	bezierGeomV45.push(geom[8][i]);
            }
            //bezierGeomV45.push(v5.p);
            
            geom = [wall.begin, v1.p, v2.p, wall.end, v4.p, v5.p, wall.begin, bezierGeomV12, bezierGeomV45];
    		}    		
    		return __assert(!isNaN(geom[1].x) && !isNaN(geom[1].y)), wall._lines = geom, geom;
    }
}

//获取墙面一侧长度
function utilModelWallGetSideLength(wall, side){
	if(wall.type == "RECTAREA" || wall.type == "FREEAREA"){
		var profile = wall.getLoop();
		var outside = wall.height3d > 0;
		var cw = utilMathPolyIsClockWise(profile);
  	if((cw && outside) || (!cw && !outside)){
  		for(var i = 0, len = profile.length - 1;i < len;++i){    			    		
  			if("side" + i == side){
    		  return utilMathLineLength(profile[i], profile[i + 1]);
    		}
    	}
  	}else{
  		for(var i = profile.length - 1;i > 0;--i){	    
  			if("side" + (i - 1) == side){
  				return utilMathLineLength(profile[i], profile[i - 1]);
  			}
    	}
  	}
  	return 0;
	}
	if(wall.type == "ROUNDAREA"){
		var length = 0;
		var profile = wall.getLoop();
		for(var i = 0, len = profile.length - 1;i < len;++i){    			    		
			length += utilMathLineLength(profile[i], profile[i + 1]);
  	}
  	return length;
	}
	
	var geom = wall._lines;
	if(!geom){
		geom = utilModelWallGetTessellates(wall, 0);		
	}
	if(!geom){
		return 0;
	}
	
	if(side == "right"){
		if(wall.bezier){
			var sideWidth = utilMathLineLength(geom[1],geom[7][0]);
  		for(var i=1;i<geom[7].length;++i){
  			sideWidth += utilMathLineLength(geom[7][i-1],geom[7][i]);
  		}
  		sideWidth += utilMathLineLength(geom[7][geom[7].length-1],geom[2]);
  		return sideWidth;
		}
		
		if(wall._smoothWallID){
			if(wall._smoothWallID[0] != 0){
				return 0;
			}else if(wall._smoothWallID[1] != 0){
				//计算衔接墙体长度 next				
			}else{
				return utilMathLineLength(geom[1],geom[2]);
			}
		}else{
			return utilMathLineLength(geom[1],geom[2]);
		}
	}else if(side == "left"){
		if(wall.bezier){
			var sideWidth = utilMathLineLength(geom[4],geom[8][0]);
  		for(var i=1;i<geom[8].length;++i){
  			sideWidth += utilMathLineLength(geom[8][i-1],geom[8][i]);
  		}
  		sideWidth += utilMathLineLength(geom[8][geom[8].length-1],geom[5]);
  		return sideWidth;
		}
		
		if(wall._smoothWallID){
			if(wall._smoothWallID[2] != 0){
				return 0;
			}else if(wall._smoothWallID[3] != 0){
				//计算衔接墙体长度 next				
			}else{
				return utilMathLineLength(geom[4],geom[5]);
			}
		}else{
			return utilMathLineLength(geom[4],geom[5]);
		}
	}else if(side == "side0"){
		return utilMathLineLength(geom[5],geom[1]);
	}else if(side == "side1"){
		return utilMathLineLength(geom[2],geom[4]);
	}
	
		
	var width = (side == "right") ? utilMathLineLength(geom[1],geom[2]):utilMathLineLength(geom[4],geom[5]);
  var smoothWallInfo = (side == "right") ? wall._smoothWallID[1]:wall._smoothWallID[3];		  
  //当前墙体衔接侧面  
  while(smoothWallInfo){
  	geom = smoothWallInfo.wall._lines;
  	if(!geom){
  		geom = utilModelWallGetTessellates(smoothWallInfo.wall, 0);		
  	}
  	
  	if(geom){
  		if(side == "right"){
  			//right
	  		if(smoothWallInfo.sameDir){
	  			width += utilMathLineLength(geom[1],geom[2]);		  		
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[1];
		  	}else{
		  		width += utilMathLineLength(geom[4],geom[5]);
		  		side = "left";
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[3];
		  	}
	  	}else{
	  		//left	  		
	  		if(smoothWallInfo.sameDir){
	  			width += utilMathLineLength(geom[1],geom[2]);
		  		side = "right";
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[1];
		  	}else{
		  		width += utilMathLineLength(geom[4],geom[5]);
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[3];
		  	}
	  	}		
  	}else{
  		break;
  	}
  }
  
  return width;
}

//判断墙一侧是否为平滑开端
function utilModelWallIsSmoothStart(wall, side){
	if(wall.type == "RECTAREA" || wall.type == "FREEAREA"){
		return true;
	}
	if(wall.type == "ROUNDAREA"){
		var profile = wall.getLoop();
		//var outside = wall.height3d > 0;
		//var cw = utilMathPolyIsClockWise(profile);
		//if((cw && outside) || (!cw && !outside)){
			return side == "side0";
		//}else{
		//	return side == "side" + (profile.length - 2);
		//}
	}
	
	if(side == "right"){
		if(wall._smoothWallID){
			if(wall._smoothWallID[0] != 0){
				return false
			}else if(wall._smoothWallID[1] != 0){
				return true
			}
		}
	}else if(side == "left"){
		if(wall._smoothWallID){
			if(wall._smoothWallID[2] != 0){
				return false;
			}else if(wall._smoothWallID[3] != 0){
				return true;
			}
		}
	}
	
	return false;
}

function utilModelWallGetSmoothStart(wall, side){
	var ret = {wall:wall, side:side};
	if(wall.type == "RECTAREA" || wall.type == "FREEAREA"){
		return ret;
	}
	if(wall.type == "ROUNDAREA"){
		var profile = wall.getLoop();
		//var outside = wall.height3d > 0;
		//var cw = utilMathPolyIsClockWise(profile);
  	//if((cw && outside) || (!cw && !outside)){
			ret.side = "side0";
		//}else{
		//	ret.side = "side" + (profile.length - 2);
		//}
		return ret;
	}
	
	
	if(utilModelWallIsSmoothStart(wall, side) || !wall._smoothWallID){
		return ret;
	}
  
	var smoothWallInfo = (side == "right") ? wall._smoothWallID[0]:wall._smoothWallID[2];
  //当前墙体衔接侧面  
  while(smoothWallInfo){
  	geom = smoothWallInfo.wall._lines;
  	if(!geom){
  		geom = utilModelWallGetTessellates(smoothWallInfo.wall, 0);		
  	}
  	
  	if(geom){
  		ret.wall = smoothWallInfo.wall;
  		if(side == "right"){
  			//right
	  		if(smoothWallInfo.sameDir){ 	
	  			side = "left";
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[2];
		  	}else{		  		
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[0];
		  	}
	  	}else{
	  		//left	  		
	  		if(smoothWallInfo.sameDir){
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[2];
		  	}else{
		  		side = "right";
		  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[0];
		  	}
	  	}		
	  	ret.side = side;
  	}else{
  		break;
  	}
  }
  
  return ret;
}

function utilModelWallGetSmoothRawDatas(wall, side){
	if(wall.type == "RECTAREA" || wall.type == "FREEAREA"){	
		var sideWidths = [];
		var profile = wall.getLoop();
		var outside = wall.height3d > 0;
		var cw = utilMathPolyIsClockWise(profile);
  	if((cw && outside) || (!cw && !outside)){
  		for(var i = 0, len = profile.length - 1;i < len;++i){    			    		
  			if("side" + i == side){
  				var width = utilMathLineLength(profile[i], profile[i + 1]);
    		  sideWidths.push({wall:wall, width:width, o:profile[i],lineDir:{x:(profile[i + 1].x-profile[i].x)/width, y:(profile[i + 1].y-profile[i].y)/width}, side:side});
    		  return sideWidths;
    		}
    	}
  	}else{
  		for(var i = profile.length - 1;i > 0;--i){	    
  			if("side" + (i - 1) == side){
  				var width = utilMathLineLength(profile[i], profile[i - 1]);
  				sideWidths.push({wall:wall, width:width, o:profile[i],lineDir:{x:(profile[i - 1].x-profile[i].x)/width, y:(profile[i - 1].y-profile[i].y)/width}, side:side});
  				return sideWidths;
  			}
    	}
  	}
  	return sideWidths;
	}
	if(wall.type == "ROUNDAREA"){
		var sideWidths = [];
		var profile = wall.getLoop();
		var outside = wall.height3d > 0;
		var cw = utilMathPolyIsClockWise(profile);
  	if((cw && outside) || (!cw && !outside)){
  		for(var i = 0, len = profile.length - 1;i < len;++i){    			    		
  			var width = utilMathLineLength(profile[i], profile[i + 1]);
    		sideWidths.push({wall:wall, width:width, o:profile[i],lineDir:{x:(profile[i + 1].x-profile[i].x)/width, y:(profile[i + 1].y-profile[i].y)/width}, side:"side" + i});
    	}
  	}else{
  		for(var i = profile.length - 1;i > 0;--i){	    
  			var width = utilMathLineLength(profile[i], profile[i - 1]);
  			sideWidths.push({wall:wall, width:width, o:profile[i],lineDir:{x:(profile[i - 1].x-profile[i].x)/width, y:(profile[i - 1].y-profile[i].y)/width}, side:"side" + (i - 1)});
    	}
  	}
  	return sideWidths;
	}
	
	var geom = wall._lines;
	if(!geom){
		geom = utilModelWallGetTessellates(wall, 0);		
	}
	if(geom){
		var smoothWallInfo;
		var width;
		var sideWidths = []; 
		if(side == "right"){
			width = utilMathLineLength(geom[1],geom[2]);
		  smoothWallInfo = wall._smoothWallID[1];
		  sideWidths.push({wall:wall, width:width, o:geom[1],lineDir:{x:(geom[2].x-geom[1].x)/width, y:(geom[2].y-geom[1].y)/width}, side:"right"});
		}else if(side == "left"){
			width = utilMathLineLength(geom[4],geom[5]);
		  smoothWallInfo = wall._smoothWallID[3];		
		  sideWidths.push({wall:wall, width:width, o:geom[4], lineDir:{x:(geom[5].x-geom[4].x)/width, y:(geom[5].y-geom[4].y)/width}, side:"left"});
		}		  
	  //当前墙体衔接侧面  
	  while(smoothWallInfo){
	  	geom = smoothWallInfo.wall._lines;
	  	if(!geom){
	  		geom = utilModelWallGetTessellates(smoothWallInfo.wall, 0);		
	  	}
	  	
	  	if(geom){
	  		if(side == "right"){
	  			//right
		  		if(smoothWallInfo.sameDir){
		  			width = utilMathLineLength(geom[1],geom[2]);		  
		  			sideWidths.push({wall:smoothWallInfo.wall, width:width, o:geom[1], lineDir:{x:(geom[2].x-geom[1].x)/width, y:(geom[2].y-geom[1].y)/width}, side:"right"}); 
			  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[1];
			  	}else{
			  		width = utilMathLineLength(geom[4],geom[5]);
			  		sideWidths.push({wall:smoothWallInfo.wall, width:width, o:geom[4], lineDir:{x:(geom[5].x-geom[4].x)/width, y:(geom[5].y-geom[4].y)/width}, side:"left"}); 
			  		side = "left";
			  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[3];
			  	}
		  	}else{
		  		//left	  		
		  		if(smoothWallInfo.sameDir){
		  			width = utilMathLineLength(geom[1],geom[2]);
		  			sideWidths.push({wall:smoothWallInfo.wall, width:width, o:geom[1], lineDir:{x:(geom[2].x-geom[1].x)/width, y:(geom[2].y-geom[1].y)/width}, side:"right"}); 
			  		side = "right";
			  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[1];
			  	}else{
			  		width = utilMathLineLength(geom[4],geom[5]);
			  		sideWidths.push({wall:smoothWallInfo.wall, width:width, o:geom[4], lineDir:{x:(geom[5].x-geom[4].x)/width, y:(geom[5].y-geom[4].y)/width}, side:"left"}); 
			  		smoothWallInfo = smoothWallInfo.wall._smoothWallID[3];
			  	}
		  	}		
	  	}else{
	  		break;
	  	}
	  }
	  
	  return sideWidths;
	}
}

function utilModelWallGetSmoothHoleprofiles(wall, side){
	var holeProfiles = [];
	if(wall.type == "RECTAREA" || wall.type == "ROUNDAREA" || wall.type == "FREEAREA"){
		return holeProfiles;
	}	
	
	var smoothStart = utilModelWallGetSmoothStart(wall, side);
	var smoothRawDatas = utilModelWallGetSmoothRawDatas(smoothStart.wall, smoothStart.side);
	var offsetX = 0;
	var fp = application.doc.floorplan;
	smoothRawDatas && smoothRawDatas.forEach(function(smoothRawData){
		var openings = utilModelWallGetAttached(fp, smoothRawData.wall, Opening);
		
		var geom = smoothRawData.wall._lines;
		var line2d = smoothRawData.side == "left" ? [geom[4], geom[5]]:[geom[1], geom[2]]; 
		var lineDir = new THREE.Vector2(line2d[1].x, line2d[1].y);
		lineDir.sub(line2d[0]);
		var xyzOrig = new THREE.Vector3(line2d[0].x, line2d[0].y, 0);
		openings.forEach(function (hole) {
			var uvwHolePos = utilThreeXYZ2UVW(hole, xyzOrig, lineDir);
	    var holeProfile = _utilThreeGetHoleProfileUVW(hole).map(function (pt) {
	        return {
	            x: pt.x * hole.sx + uvwHolePos.x + offsetX,
	            y: pt.y * hole.sz + uvwHolePos.y,
	            z: 0
	        };
	    });
	    holeProfiles.push(holeProfile);
	  });
	  
	  offsetX += smoothRawData.width;
	});
	return holeProfiles;
}

//求直线墙和曲线墙交点
function utilWallStraightIntrBezier(turnStruct, simpleGeom, bezierGeom, turnType){
	  var v1 = simpleGeom[1];//{i:1, p:bezierGeom[1]};   
    var v2 = simpleGeom[2];//{i:20,p:bezierGeom[20]};   
                
    var v4 = simpleGeom[4];//{i:22,p:bezierGeom[22]};
    var v5 = simpleGeom[5];//{i:41,p:bezierGeom[41]};
     
    var geom = bezierGeom;
    var sameRoadDir = turnStruct.sameRoadDir;
    if(turnType == "beginTurnLeft"){
    	//返回v1
    	if(sameRoadDir){
    		var p1 = simpleGeom[1];
    		var p2 = simpleGeom[2];
    		
    		var intr = false;
    		if(turnStruct.angle >= 180){
	      	//找出交点	      	
	      	for(var i=19;i>0;--i){
	      		var p3 = geom[8][i];
	      		var p4 = geom[8][i - 1];
	      		intr = segmentsIntr(p1,p2,p3,p4);
	      		if(intr){
	      			//得到交点索引截止点	      			
	      			return intr;
	      		}
	      	}  	      	
	      }
	      
	      if(!intr){
	      	var p3 = geom[8][19];
	      	var p4 = geom[8][18];
	      	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	      	if(!isParallel){
	      		return utilMathLineLineIntersection(p1, p2, p3, p4);	      		
	      	}else{
	      		//平行，使用41节点,不变
	      		return v1;
	      	}
	      }
    	}else{
    		var p1 = simpleGeom[1];
	      var p2 = simpleGeom[2];  
	      	
	      var geom = bezierGeom;
	      var intr = false;
	      if(turnStruct.angle >= 180){
	      	//找出交点 	      	               	
	      	for(var i=19;i>0;--i){
	      		var p3 = geom[7][i];
	      		var p4 = geom[7][i - 1];
	      		intr = segmentsIntr(p1,p2,p3,p4);
	      		if(intr){
	      			//得到交点索引截止点
	      			return intr;
	      		}
	      	}
	      }	      
	      if(!intr){
	      	var p3 = geom[7][19];
	      	var p4 = geom[7][18];
	      	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	      	if(!isParallel){
	      		return utilMathLineLineIntersection(p1, p2, p3, p4);
	      	}else{
	      		//平行，使用20节点，不变
	      		return v1;
	      	}
	      }
    	}
    }else if(turnType == "beginTurnRight"){
    	//返回v5
    	if(sameRoadDir){
    		var p1 = simpleGeom[4];
	      var p2 = simpleGeom[5]; 
	      
	      var geom = bezierGeom;      
	      var intr = false;
	      if(turnStruct.angle <= 180){
	      	//找出交点	      	
	      	for(var i=0;i<19;++i){
	      		var p3 = geom[7][i];
	      		var p4 = geom[7][i + 1];
	      		intr = segmentsIntr(p1,p2,p3,p4);
	      		if(intr){
	      			//得到交点索引截止点
	      			return intr;
	      		}
	      	}
	      }
	      if(!intr){
	      	var p3 = geom[7][0];
	      	var p4 = geom[7][1];
	      	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	      	if(!isParallel){
	      		return utilMathLineLineIntersection(p1, p2, p3, p4);	      		
	      	}else{
	      		//平行，使用1节点,不变
	      		return v5;
	      	}
	      }
    	}else{
    		var p1 = simpleGeom[4];
	      var p2 = simpleGeom[5];
	      
	      var geom = bezierGeom;
	      var intr = false;
	      if(turnStruct.angle <= 180){
	      	//找出交点	      	
	      	for(var i=0;i<19;++i){
	      		var p3 = geom[8][i];
	      		var p4 = geom[8][i + 1];
	      		intr = segmentsIntr(p1,p2,p3,p4);
	      		if(intr){
	      			//得到交点索引截止点
	      			return intr;
	      			break;
	      		}
	      	}	      	
	      }
	      
	      if(!intr){
	      	var p3 = geom[8][0];
	      	var p4 = geom[8][1];
	      	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
	      	if(!isParallel){
	      		return utilMathLineLineIntersection(p1, p2, p3, p4);	      		
	      	}else{
	      		//平行，使用22节点,不变;
	      		return v5;
	      	}
	      }
    	}
    }else if(turnType == "endTurnRight"){
    	//返回v2
    	if(sameRoadDir){
    		var p1 = simpleGeom[1];
        var p2 = simpleGeom[2];
        
        var geom = bezierGeom;
        var intr = false;
        if(turnStruct.angle <= 180){
        	//找出交点        	
        	for(var i=0;i<19;++i){
        		var p3 = geom[7][i];
        		var p4 = geom[7][i + 1];
        		intr = segmentsIntr(p1,p2,p3,p4);
        		if(intr){
        			//得到交点索引截止点
        			return intr;
        		}
        	}
        }
        
        if(!intr){
        	var p3 = geom[7][0];
        	var p4 = geom[7][1];
        	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
        	if(!isParallel){
        		return utilMathLineLineIntersection(p1, p2, p3, p4);        		
        	}else{
        		//平行，使用22节点,不变;
        		return v2;
        	}
        }
    	}else{
    		var p1 = simpleGeom[1];
        var p2 = simpleGeom[2];
        
        var geom = bezierGeom;
        var intr = false;
        if(turnStruct.angle <= 180){
        	//找出交点        	
        	for(var i=0;i<19;++i){
        		var p3 = geom[8][i];
        		var p4 = geom[8][i + 1];
        		intr = segmentsIntr(p1,p2,p3,p4);
        		if(intr){
        			//得到交点索引截止点
        			return intr;
        		}
        	}
        }
        
        if(!intr){
        	var p3 = geom[8][0];
        	var p4 = geom[8][1];
        	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
        	if(!isParallel){
        		return utilMathLineLineIntersection(p1, p2, p3, p4);        		
        	}else{
        		//平行，使用22节点,不变;
        		return v2;
        	}
        }
    	}
    }else if(turnType == "endTurnLeft"){
    	//返回v4
    	if(sameRoadDir){
    		var p1 = simpleGeom[4];
        var p2 = simpleGeom[5];  
        	
        var geom = bezierGeom;
        var intr = false;
        if(turnStruct.angle >= 180){
        	//找出交点     	
        	for(var i=19;i>0;--i){
        		var p3 = geom[8][i];
        		var p4 = geom[8][i - 1];
        		intr = segmentsIntr(p1,p2,p3,p4);
        		if(intr){
        			//得到交点索引截止点
        			return intr;
        		}
        	}
        }
        if(!intr){
        	var p3 = geom[8][19];
        	var p4 = geom[8][18];
        	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
        	if(!isParallel){
        		return utilMathLineLineIntersection(p1, p2, p3, p4);        		
        	}else{
        		//平行，使用20节点，不变
        		return v4;
        	}
        }
    	}else{
    		var p1 = simpleGeom[4];
        var p2 = simpleGeom[5];
        
        var geom = bezierGeom;
        var intr = false;
        if(turnStruct.angle >= 180){
        	//找出交点        	                	
        	for(var i=19;i>0;--i){
        		var p3 = geom[7][i];
        		var p4 = geom[7][i - 1];
        		intr = segmentsIntr(p1,p2,p3,p4);
        		if(intr){
        			//得到交点索引截止点
        			return intr;
        		}
        	}
        }
        
        if(!intr){
        	var p3 = geom[7][19];
        	var p4 = geom[7][18];
        	var isParallel = utilMathIsLineParallel(p1, p2, p3, p4);
        	if(!isParallel){
        		return utilMathLineLineIntersection(p1, p2, p3, p4);
        	}else{
        		//平行，使用41节点,不变
        		return v4;
        	}
        }
    	}
    }
}

function utilWallBezierIntrBezier(turnStruct, simpleGeom, bezierGeom, turnType){     
    var geom = bezierGeom;
    var sameRoadDir = turnStruct.sameRoadDir;
    if(turnType == "beginTurnLeft"){
    	//返回v1{i,intr}
    	var b = bezierGeom[7];
  		var s = simpleGeom[sameRoadDir?8:7];
  		
  		for(var bI=0;bI<19;++bI){
  			for(var sI=19;sI>0;--sI){
  				var intr = segmentsIntr(b[bI],b[bI+1],s[sI],s[sI-1]);
  				if(intr){
  					return {i:bI,intr:intr};
  				}
  			}
  		}
  		
  		var isParallel = utilMathIsLineParallel(b[0],b[1],s[19],s[18]);
  		if(!isParallel){
	  		var intr = utilMathLineLineIntersection(b[0],b[1],s[19],s[18]);
	  		if(intr){
	  			return {intr:intr};
	  		}
	  	}
  		
    	return {intr:geom[1]};
    }else if(turnType == "beginTurnRight"){
    	//返回v5{i,intr}
    	var b = bezierGeom[8];
  		var s = simpleGeom[sameRoadDir?7:8];
  		
  		for(var bI=19;bI>0;--bI){
  			for(var sI=0;sI<19;++sI){
  				var intr = segmentsIntr(b[bI],b[bI-1],s[sI],s[sI+1]);
  				if(intr){
  					return {i:bI,intr:intr};
  				}
  			}
  		}
  		
  		var isParallel = utilMathIsLineParallel(b[19],b[18],s[0],s[1]);
  		if(!isParallel){
	  		var intr = utilMathLineLineIntersection(b[19],b[18],s[0],s[1]);
	  		if(intr){
	  			return {intr:intr};
	  		}
	  	}
  		
    	return {intr:geom[5]};
    }else if(turnType == "endTurnRight"){
    	//返回v2{i,intr}
  		var b = bezierGeom[7];
  		var s = simpleGeom[sameRoadDir?7:8];
  		
  		for(var bI=19;bI>0;--bI){
  			for(var sI=0;sI<19;++sI){
  				var intr = segmentsIntr(b[bI],b[bI-1],s[sI],s[sI+1]);
  				if(intr){
  					return {i:bI,intr:intr};
  				}
  			}
  		}
  		
  		var isParallel = utilMathIsLineParallel(b[19],b[18],s[0],s[1]);
  		if(!isParallel){
	  		var intr = utilMathLineLineIntersection(b[19],b[18],s[0],s[1]);
	  		if(intr){
	  			return {intr:intr};
	  		}
	  	}
  		
  		//没有交点
  		return {intr:geom[2]};    	
    }else if(turnType == "endTurnLeft"){
    	//返回v4{i,intr}
    	var b = bezierGeom[8];
  		var s = simpleGeom[sameRoadDir?8:7];
  		
  		for(var bI=0;bI<19;++bI){
  			for(var sI=19;sI>0;--sI){
  				var intr = segmentsIntr(b[bI],b[bI+1],s[sI],s[sI-1]);
  				if(intr){
  					return {i:bI,intr:intr};
  				}
  			}
  		}
  		
  		var isParallel = utilMathIsLineParallel(b[0],b[1],s[19],s[18]);
  		if(!isParallel){
	  		var intr = utilMathLineLineIntersection(b[0],b[1],s[19],s[18]);
	  		if(intr){
	  			return {intr:intr};
	  		}
	  	}
	  	    	
    	return {intr:geom[4]};
    }
}

function utilWallWalkingTurns(fp, wall, walkFromPoint, crossingRoadPoint, isTurnRight) {
    if (wall.begin && wall.end) {
        var crossRoads = [];
        if (utilFloorplanForEachWall(fp, function (w) {
                this.id != w.id && w.begin && w.end && (utilMathIsSamePoint(crossingRoadPoint, w.begin, .05) ? crossRoads.push({
                    road: w,
                    walkToPoint: w.bezier ? w.bezier : w.end, //添加bezier点
                    sameRoadDir: !0
                }) : utilMathIsSamePoint(crossingRoadPoint, w.end, .05) ? crossRoads.push({
                    road: w,
                    walkToPoint: w.bezier ? w.bezier : w.begin,
                    sameRoadDir: !1
                }) : utilMathIsPointInLineSegment(crossingRoadPoint, w.begin, w.end, -.05) && (crossRoads.push({
                    road: w,
                    walkToPoint: w.bezier ? w.bezier : w.begin,
                    sameRoadDir: !1
                }), crossRoads.push({
                    road: w,
                    walkToPoint: w.bezier ? w.bezier : w.end,
                    sameRoadDir: !0
                })));
            }, wall), 0 != crossRoads.length) {
            for (var rv = void 0, minTurnRightAngle = 360, maxTurnLeftAngle = 0, i = 0; i < crossRoads.length; ++i) {
                var road = crossRoads[i], turnAngle = utilMathLinelineCCWAngle(crossingRoadPoint, walkFromPoint, road.walkToPoint);
                1 == isTurnRight && minTurnRightAngle > turnAngle ? (minTurnRightAngle = turnAngle,
                    rv = road, rv.angle = turnAngle) : 0 == isTurnRight && turnAngle > maxTurnLeftAngle && (maxTurnLeftAngle = turnAngle,
                    rv = road, rv.angle = turnAngle);
            }
            return rv;
        }
    }
}

function utilWallIsPointInAnyWall(fp, point) {
    var walls = [];
    return utilFloorplanForEachWall(fp, function (wall) {
        if (wall.begin && wall.end && utilMathIsPointInLine(point, wall.begin, wall.end, .4)) {
            var lerpNum = utilMathGetLerpNumber(wall.begin, wall.end, point);
            lerpNum >= -.05 && 1.05 >= lerpNum && this.push(wall);
        }
    }, walls), walls;
}

function utilWallGetSnapPt(fp, point, excludedWalls) {
    var snapWalls = utilWallIsPointInAnyWall(fp, point);
    if (0 != snapWalls.length) {
        var pt = void 0;
        if (snapWalls.forEach(function (snappedWall) {
                -1 == excludedWalls.indexOf(snappedWall) && (utilMathIsSamePoint(point, snappedWall.begin, .3) && (pt = snappedWall.begin),
                utilMathIsSamePoint(point, snappedWall.end, .3) && (pt = snappedWall.end));
            }), pt) return {
            point: pt,
            snapTo: pt
        };
        var snapWall;
        return snapWalls.forEach(function (snappedWall) {
            -1 == excludedWalls.indexOf(snappedWall) && (pt = utilMathGetPerpendicularIntersect(point, snappedWall.begin, snappedWall.end),
                snapWall = snappedWall);
        }), pt ? {
            point: pt,
            snapTo: snapWall
        } : void 0;
    }
}


//add by gaoning 2018.4.12
function utilWallIsPointInAnyWallForArea(fp, point) {
    //var walls = [];
    //return utilFloorplanForEachWall(fp, function (wall) {
    //
    //    // 判断点到线段的距离，取距离小的为房间内墙，吸咐时就吸咐到内墙。
    //    var p1 = wall._lines[1], p2 = wall._lines[2], p4 = wall._lines[4], p5 = wall._lines[5];
    //
    //    var d1 = getDistFromPointToLine(p1, p2, point);
    //    var d2 = getDistFromPointToLine(p4, p5, point);
    //
    //    if (d1 > d2) {
    //        if (p4 && p5 && utilMathIsPointInLine(point, p4, p5, .4)) {
    //            var lerpNum = utilMathGetLerpNumber(p4, p5, point);
    //            lerpNum >= -.05 && 1.05 >= lerpNum && this.push(wall);
    //        }
    //    } else {
    //        if (p1 && p2 && utilMathIsPointInLine(point, p1, p2, .4)) {
    //            var lerpNum = utilMathGetLerpNumber(p1, p2, point);
    //            lerpNum >= -.05 && 1.05 >= lerpNum && this.push(wall);
    //        }
    //    }
    //
    //}, walls), walls;

    var walls = [];
    return utilFloorplanForEachWall(fp, function (wall) {
        if (wall.begin && wall.end && utilMathIsPointInLine(point, wall.begin, wall.end, .16)) {  //修改吸咐距离
            var lerpNum = utilMathGetLerpNumber(wall.begin, wall.end, point);
            lerpNum >= -.05 && 1.05 >= lerpNum && this.push(wall);
        }
    }, walls), walls;
}

function utilWallGetSnapPtForArea(fp, point, excludedWalls) {
    var snapWalls = utilWallIsPointInAnyWallForArea(fp, point);
    var pt = void 0;
    if (0 != snapWalls.length) {
        if (snapWalls.forEach(function (snappedWall) {
                // 判断点到线段的距离，取距离小的为房间内墙，吸咐时就吸咐到内墙。
                var p1 = snappedWall._lines[1], p2 = snappedWall._lines[2], p4 = snappedWall._lines[4], p5 = snappedWall._lines[5];
                var d1 = getDistFromPointToLine(p1, p2, point);
                var d2 = getDistFromPointToLine(p4, p5, point);

                if(d1 > d2){
                    -1 == excludedWalls.indexOf(snappedWall) && (utilMathIsSamePoint(point, p4, 0) && (pt = p4),
                    utilMathIsSamePoint(point, p5, 0) && (pt = p5));
                }else{
                    -1 == excludedWalls.indexOf(snappedWall) && (utilMathIsSamePoint(point, p1, 0) && (pt = p1),
                    utilMathIsSamePoint(point, p2, 0) && (pt = p2));  //调整与原点的距离多少开始吸咐。0为原点也吸咐
                }
                //-1 == excludedWalls.indexOf(snappedWall) && (utilMathIsSamePoint(point, snappedWall.begin, .3) && (pt = snappedWall.begin),
                //utilMathIsSamePoint(point, snappedWall.end, .3) && (pt = snappedWall.end));

            }), pt) return {
            point: pt,
            snapTo: pt
        };
        var snapWall;
        return snapWalls.forEach(function (snappedWall) {
            // 判断点到线段的距离，取距离小的为房间内墙，吸咐时就吸咐到内墙。
            var p1 = snappedWall._lines[1], p2 = snappedWall._lines[2], p4 = snappedWall._lines[4], p5 = snappedWall._lines[5];
            var d1 = getDistFromPointToLine(p1, p2, point);
            var d2 = getDistFromPointToLine(p4, p5, point);
            if(d1 > d2){
                -1 == excludedWalls.indexOf(snappedWall) && (pt = utilMathGetPerpendicularIntersect(point, p4, p5),
                    snapWall = snappedWall);
            }else{
                -1 == excludedWalls.indexOf(snappedWall) && (pt = utilMathGetPerpendicularIntersect(point, p1, p2),
                    snapWall = snappedWall);
            }
            //-1 == excludedWalls.indexOf(snappedWall) && (pt = utilMathGetPerpendicularIntersect(point, snappedWall.begin, snappedWall.end),
            //    snapWall = snappedWall);
        }), pt ? {
            point: pt,
            snapTo: snapWall
        } : void 0;
    }
    //else{
    //    //优先吸咐墙，再吸咐其他区域的点。
    //    for (var wID in fp.lf) {
    //        var area = fp.lf[wID];
    //        if(area instanceof FreeArea){
    //            area.profile.forEach(function (cruve){
    //                if(cruve){
    //                    var s1 = utilMathIsSamePoint(cruve.begin,point,0.1);
    //                    return s1 ? {
    //                        point: pt,
    //                        snapTo: cruve
    //                    } : void 0;
    //                    var s2 = utilMathIsSamePoint(cruve.end,point,0.1);
    //                    return s2 ? {
    //                        point: pt,
    //                        snapTo: cruve
    //                    } : void 0;
    //                }
    //            });
    //        }
    //    }
    //}
}


function utilWallBreak(fp, breakWall, lerpNumber) {
    var current = breakWall;
    var lerp = Number(lerpNumber) || .5;
    var middlePoint = Vec2.lerp(current.begin, current.end, lerp);
    var wall = new Wall();
    return utilEntityAddLink(fp, wall), wall.width = current.width, wall.height3d = current.height3d,
        wall.transparent = current.transparent, 
        current.leftMaterial && (wall.leftMaterial = current.leftMaterial.clone()),
        current.rightMaterial && (wall.rightMaterial = current.rightMaterial.clone()),
        current.side2Material && (wall.side2Material = current.side2Material.clone()),
        current.side3Material && (wall.side3Material = current.side3Material.clone()),
        current.stoneMaterial && (wall.stoneMaterial = current.stoneMaterial.clone()),
        wall.begin = new Point(),
        wall.begin.x = current.begin.x, wall.begin.y = current.begin.y, wall.end = new Point(),
        wall.end.x = current.end.x, wall.end.y = current.end.y, current.end.x = wall.begin.x = middlePoint.x,
        current.end.y = wall.begin.y = middlePoint.y, wall;
}

function utilWallForEachFloor(fp, wall, callback, thisArg) {
    callback && utilFloorplanForEachFloor(fp, function (floor) {
        -1 != floor.profile.indexOf(wall) && callback.call(thisArg, floor);
    });
}

function utilFloorplanForEachWall(fp, callback, thisArg) {
    __assert(void 0 != callback);
    for (var wID in fp.lf) {
        var wall = fp.lf[wID];
        wall instanceof Wall && callback.call(thisArg, wall);
    }
}

function utilWallGetSimpleGeom(wall, callback){
	  if(wall.bezier){
	  	return utilWallGetSimpleBezierGeom(wall, callback);
	  }
	  
	  if(!wall.end || !wall.begin){
	  	return null;
	  }
	  
		var wallDir = new Vec2(wall.end.x - wall.begin.x, wall.end.y - wall.begin.y);
    var wallWidth = wall.width;
    if (!isNaN(wallDir.x) && 0 != Vec2.dot(wallDir, wallDir)) {
        var wallDirOffset = wallDir.normalize().scale(wallWidth / 2)
        wall._simpleGeom = [wall.begin,
            Vec2.rotateAroundPoint(wallDirOffset.clone().add(wall.begin), wall.begin, -Math.PI / 2),
            Vec2.rotateAroundPoint(wallDirOffset.clone().add(wall.end),   wall.end,   -Math.PI / 2),
            wall.end,
            Vec2.rotateAroundPoint(wallDirOffset.clone().add(wall.end),   wall.end,    Math.PI / 2),
            Vec2.rotateAroundPoint(wallDirOffset.clone().add(wall.begin), wall.begin,  Math.PI / 2),
            wall.begin];
        
    }else{
    	wall._simpleLast = null;
    	wall._simpleGeom = null;	      	
    }
    
    return wall._simpleGeom;
}

function utilWallGetSimpleBezierGeom(wall, callback){
	  var wallDirBegin = new Vec2(wall.bezier.x - wall.begin.x, wall.bezier.y - wall.begin.y);
		var wallDirEnd = new Vec2(wall.end.x - wall.bezier.x, wall.end.y - wall.bezier.y);
		
    var wallWidth = wall.width;
    if (!isNaN(wallDirBegin.x) && 0 != Vec2.dot(wallDirBegin, wallDirBegin) &&
        !isNaN(wallDirEnd.x) && 0 != Vec2.dot(wallDirEnd, wallDirEnd)) {
        	
        var wallDirBeginOffset = wallDirBegin.normalize().scale(wallWidth / 2);
        var wallDirEndOffset   = wallDirEnd.normalize().scale(wallWidth / 2);
        var geom = [wall.begin,
            Vec2.rotateAroundPoint(wallDirBeginOffset.clone().add(wall.begin), wall.begin, -Math.PI / 2),
            Vec2.rotateAroundPoint(wallDirEndOffset.clone().add(wall.end),   wall.end,   -Math.PI / 2),
            wall.end,
            Vec2.rotateAroundPoint(wallDirEndOffset.clone().add(wall.end),   wall.end,    Math.PI / 2),
            Vec2.rotateAroundPoint(wallDirBeginOffset.clone().add(wall.begin), wall.begin,  Math.PI / 2),
            wall.begin];
        
        if (wall._lines = geom, wall._geom = geom) {
            var road;
            var sameDir;
            var fp = application.doc.floorplan;
            
            var bezierLine = [];
            for(var i=0;i<20;++i){
            	bezierLine.push(utilMathBerzier(geom[0], wall.bezier, geom[3], i/19));
            }
            
            var bezierLineV12 = [];
            for(var i=1;i<20;++i){
            	var bezierDir = new Vec2(bezierLine[i].x - bezierLine[i-1].x, bezierLine[i].y - bezierLine[i-1].y);
            	var bezierOffset = bezierDir.normalize().scale(wallWidth / 2);
            	bezierLineV12.push([Vec2.rotateAroundPoint(bezierOffset.clone().add(bezierLine[i-1]), bezierLine[i-1], -Math.PI / 2),
            	                    Vec2.rotateAroundPoint(bezierOffset.clone().add(bezierLine[i]), bezierLine[i], -Math.PI / 2)]);		            	
            }		            
            var bezierV12 = [];
            if(bezierLineV12.length > 1){		            	
	            for(var i=1;i<bezierLineV12.length;++i){
	            	//计算每个线段的交点
	            	if(i == 1){
	            		bezierV12.push(geom[1]);//bezierLineV12[0][0]);
	            	}			            	
	            	if(utilMathIsLineParallel(bezierLineV12[i-1][0], bezierLineV12[i-1][1], bezierLineV12[i][0], bezierLineV12[i][1])){
	            		bezierV12.push(bezierLineV12[i-1][1]);
	            	}else{
	            		bezierV12.push(utilMathLineLineIntersection(bezierLineV12[i-1][0], bezierLineV12[i-1][1], bezierLineV12[i][0], bezierLineV12[i][1]));
	            	}	            	
	            				            			            	 
	            	if(i == (bezierLineV12.length - 1)){
	            		bezierV12.push(geom[2]);//bezierLineV12[bezierLineV12.length - 1][1]);
	            	}
	            }
            }
            
            var bezierLineV45 = [];
            for(var i=19;i>0;--i){
            	var bezierDir = new Vec2(bezierLine[i-1].x - bezierLine[i].x, bezierLine[i-1].y - bezierLine[i].y);
            	var bezierOffset = bezierDir.normalize().scale(wallWidth / 2);
            	bezierLineV45.push([Vec2.rotateAroundPoint(bezierOffset.clone().add(bezierLine[i]), bezierLine[i], -Math.PI / 2),
            	                    Vec2.rotateAroundPoint(bezierOffset.clone().add(bezierLine[i-1]), bezierLine[i-1], -Math.PI / 2)]);
            }
            var bezierV45 = [];
            if(bezierLineV45.length > 1){		            	
	            for(var i=1;i<bezierLineV45.length;++i){
	            	//计算每个线段的交点
	            	if(i == 1){
	            		bezierV45.push(geom[4]);//bezierLineV45[0][0]);
	            	}			            	
	            	
	            	if(utilMathIsLineParallel(bezierLineV45[i-1][0], bezierLineV45[i-1][1], bezierLineV45[i][0], bezierLineV45[i][1])){
	            		bezierV45.push(bezierLineV45[i-1][1]);
	            	}else{
	            		bezierV45.push(utilMathLineLineIntersection(bezierLineV45[i-1][0], bezierLineV45[i-1][1], bezierLineV45[i][0], bezierLineV45[i][1]));	
	            	}		            			            	 
	            	if(i == (bezierLineV45.length - 1)){
	            		bezierV45.push(geom[5]);//bezierLineV45[bezierLineV45.length - 1][1]);
	            	}
	            }
            }
            
            //添加v1-v2曲线
            var ret = [wall.begin,bezierV12[0],bezierV12[19],wall.end,bezierV45[0],bezierV45[19],wall.begin];
            
            //var vB12 = utilMathLineLineIntersection(v1, wallDirBeginOffset.clone().add(v1), wallDirEndOffset.clone().add(v2), v2);//{x:wall.bezier.x + geom[1].x - wall.begin.x, y:wall.bezier.y + geom[1].y - wall.begin.y};
            //for(var i=0;i<20;++i){
            	//ret.push(utilMathBerzier(v1, vB12, v2, i/19));
            	ret.push(bezierV12);//7号
            //}
            
            //var vB34 = utilMathLineLineIntersection(v4, wallDirEndOffset.clone().add(v4), wallDirBeginOffset.clone().add(v5), v5);//{x:wall.bezier.x + geom[4].x - wall.end.x, y:wall.bezier.y + geom[4].y - wall.end.y};
            //for(var i=0;i<20;++i){
            	//ret.push(utilMathBerzier(v4, vB34, v5, i/19));
            	ret.push(bezierV45);//8号
            //}
                        
            wall._simpleGeom = ret;
            
            wall._simpleLast = {};
		        wall._simpleLast.begin = {x:wall.begin.x, y:wall.begin.y};
		        wall._simpleLast.end = {x:wall.end.x, y:wall.end.y}; 
		    }       	        
		}else{
			  wall._simpleLast = null;
    	  wall._simpleGeom = null;	
		}
		        
    return wall._simpleGeom;
}

function utilWallGetSimpleBezierProfileBuyGeom(bezierGeom){
	var profile = [bezierGeom[0]];
	bezierGeom[7].forEach(function(p){
		profile.push(p);
	});
	profile.push(bezierGeom[3]);
	bezierGeom[8].forEach(function(p){
		profile.push(p);
	});
	profile.push(bezierGeom[6]);
	return profile;
}

var utilWallAdjacentPoint = function () {
    var wall_side_ptAt_table = {
        left: {
            begin: 5,
            end: 4
        },
        right: {
            begin: 1,
            end: 2
        }
    }, left = "left", right = "right", begin = "begin", end = "end";
    return function (wall1, side1, wall2, side2) {
        if (__assert(wall1.begin && wall1.end && wall2.begin && wall2.end, "invalid walls"),
            side1 != left && side1 != right || side2 != left && side2 != right) return void __assert(!1, "error: <side> parameter should be <left|right>");
        var common1, common2;
        if (utilMathIsSamePoint(wall1.begin, wall2.end) ? (common1 = wall1.begin, common2 = wall2.end) : utilMathIsSamePoint(wall1.end, wall2.begin) ? (common1 = wall1.end,
                common2 = wall2.begin) : utilMathIsSamePoint(wall1.begin, wall2.begin) ? (common1 = wall1.begin,
                common2 = wall2.begin) : utilMathIsSamePoint(wall1.end, wall2.end) && (common1 = wall1.end,
                common2 = wall2.end), common1) {
            var intersection = utilMathIsLineParallel(wall1.begin, wall1.end, wall2.begin, wall2.end, .05) ? utilMathGetPerpendicularIntersect(common1, wall1._lines[wall_side_ptAt_table[side1][begin]], wall1._lines[wall_side_ptAt_table[side1][end]]) : utilMathLineLineIntersection(wall1._lines[wall_side_ptAt_table[side1][begin]], wall1._lines[wall_side_ptAt_table[side1][end]], wall2._lines[wall_side_ptAt_table[side2][begin]], wall2._lines[wall_side_ptAt_table[side2][end]]), common1_ptAt = common1.id == wall1.begin.id ? begin : end, common2_ptAt = common2.id == wall2.begin.id ? begin : end, other1_ptAt = common1.id == wall1.begin.id ? end : begin, other2_ptAt = common2.id == wall2.begin.id ? end : begin;
            return {
                p: intersection,
                c1at: common1_ptAt,
                c2at: common2_ptAt,
                o1: wall1._lines[wall_side_ptAt_table[side1][other1_ptAt]],
                o2: wall2._lines[wall_side_ptAt_table[side2][other2_ptAt]]
            };
        }
    };
}(); 

//获取wallboard离地高度
function utilWallGetWallboardOffsetH(wallboard){
	var offsetH = 0;
	if(wallboard.host){
		var wall = wallboard.host;
		var category = wallboard.category;
		var wallboards = wall[category +"Boards"];
		if(wallboards){			
			for(var i=wallboards.length - 1;i>=0;--i){
				if(wallboards[i] == wallboard.id){
					break;
				}
				
				var fp = application.doc.floorplan;
				var wb = fp.lf[wallboards[i]];
				wb && (offsetH += wb.height);
			}
		}		
	}
	
	return offsetH;
}
// sourceURL=src\model\wall.js