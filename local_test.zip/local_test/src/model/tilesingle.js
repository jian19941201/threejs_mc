//单砖铺贴
function TileSingle(meta) {
    classBase(this, meta);
    var propertyChanged = (linkPropertyChangedCalllback.bind(this), entityPropertyChangedCallback.bind(this));
    this.category = "tilesingle";
    utilRootDefineProperty(this, "gapwidth", 0, propertyChanged);  //砖缝大小
    utilRootDefineProperty(this, "gapcolor", 0, propertyChanged);  //砖缝颜色
    utilRootDefineProperty(this, "cuth", 1, propertyChanged);      //横切
    utilRootDefineProperty(this, "cutv", 1, propertyChanged);      //纵切
    utilRootDefineProperty(this, "pavetype", 0, propertyChanged);  //铺砖类型
    utilRootDefineProperty(this, "psx", 1, propertyChanged);       //缩放x
    utilRootDefineProperty(this, "psy", 1, propertyChanged);       //缩放y    
    utilRootDefineProperty(this, "pavejson", 0, propertyChanged);  //铺贴json
}

//新建tilesingle
function utilTileSingleCreate(pid) {
    var productMeta = application.catalogMgr.productsMeta[pid];
    return new TileSingle(productMeta);
}

//获得tilesingle url
function utilTileSingleGetUrl(tile, usePrefix, map) {
	  if(tile.ignoreUV){
	  	if (tile._url) 
	  	    return tile._url;
	    var url = "https://pic.oceano.com.cn/h5filesystem/products/" + tile.pid + "/top.jpg@256h.jpg";//utilCatalogGetFileUrl(application.catalogMgr, "product", tile.pid, "top", "jpg");
	    return tile._url = url, url;
	  }else{
	  	var urlPrefix = utilAppGetServicePrefix(application, "tileimg");
	    var mapUrl = map && "" != map ? "diffuse" == map ? "/tileImgD" : "tileImgR" : "";
	    var url = mapUrl + "?pid=" + tile.pid + "&psx=" + tile.psx + "&psy=" + tile.psy + "&xlen=" + tile.meta.xlen + "&ylen=" + tile.meta.ylen + "&gapwidth=" + tile.gapwidth + "&gapcolor=" + tile.gapcolor + "&cuth=" + tile.cuth + "&cutv=" + tile.cutv + "&pavetype=" + tile.pavetype + "&version=" + tile.meta.version;
	    return (usePrefix === !0 ? urlPrefix : "") + url;
	  }
    
}

TileSingle.prototype.type = "TILESINGLE";
classInherit(TileSingle, Material);
utilExtend(TileSingle.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        saved.gapwidth = this.gapwidth;
        saved.gapcolor = this.gapcolor;
        saved.cuth = this.cuth;
        saved.cutv = this.cutv;
        saved.pavetype = this.pavetype;
        saved.psx = this.psx;
        saved.psy = this.psy;
        saved.pavejson = this.pavejson;
        var _url = saved._url = utilTileSingleGetUrl(this, !1);
        saved._md5 = utilMakeMD5(_url);
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
        Root.prototype.database;
        data.gapwidth && (this.gapwidth = data.gapwidth);
        data.gapcolor && (this.gapcolor = data.gapcolor);
        data.cuth && (this.cuth = data.cuth);
        data.cutv && (this.cutv = data.cutv);
        data.pavetype && (this.pavetype = data.pavetype);
        data.psx && (this.psx = data.psx);
        data.psy && (this.psy = data.psy);
        data.pavejson && (this.pavejson = data.pavejson);
    },
    clone: function () {
        var saved = classBase(this, "clone");
        saved.gapwidth = this.gapwidth;
        saved.gapcolor = this.gapcolor;
        saved.cuth = this.cuth;
        saved.cutv = this.cutv;
        saved.pavetype = this.pavetype;
        saved.psx = this.psx;
        saved.psy = this.psy;
        saved.pavejson = this.pavejson;
        var _url = saved._url = utilTileSingleGetUrl(this, !1);
        saved._md5 = utilMakeMD5(_url);
        return saved;
    },
    getUrl: function () {
        return utilTileSingleGetUrl(this, !0, "diffuse");
    },
    getThreeUrl: function () {
    	  return utilTileSingleGetUrl(this, !0, "diffuse");
    },
    getScale: function () {
        return {
            x: this.sx * this.psx,
            y: this.sy * this.psy
        };
    }
});

//# sourceURL=src\model\tilesingle.js