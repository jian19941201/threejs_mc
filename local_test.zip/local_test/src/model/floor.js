var FLOORFLAG_CHANGED_FOR_REDRAWN = 512;
var FLOORFLAG_HAS_BOUNDARY_LINE = 1024;
var FLOORFLAG_HIDE_CEILING = 4096;
var DEFAULT_FLOOR_MATERIAL_ID = "beechwoodhoney";
var DEFAULT_FLOOR_ROOTCOLOR = 'a9a9a9';

//地面铺砖
function Floor(opt) {
    classBase(this, opt);
    var linkChanged = linkPropertyChangedCalllback.bind(this);
    var propertyChanged = entityPropertyChangedCallback.bind(this);
    utilRootDefineProperty(this, "floorMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "ceilingMaterial", void 0, linkChanged);
    utilRootDefineProperty(this, "height3d", DEFAULT_WALL_HEIGHT3D, propertyChanged);
    utilRootDefineProperty(this, "label", "", propertyChanged);
    utilRootDefineProperty(this, "labelX", void 0, propertyChanged);
    utilRootDefineProperty(this, "labelY", void 0, propertyChanged);
    utilRootDefineProperty(this, "measurementLabel", void 0, propertyChanged);
    utilRootDefineProperty(this, "direction", 4, propertyChanged);

    //paveMaterial 0~9 提供最多10组独立的纹理
    for(var i=0;i<10;++i){
    	utilRootDefineProperty(this, "pave" + i + "Material", void 0, linkChanged);
    }
    
    this.profile = [];
    this.applyModelRoomComplete = new signals.Signal();
    
    //by mond 2017
    utilRootDefineProperty(this, "rootMaterial", void 0, linkChanged);    //砖缝颜色纹理
    utilRootDefineProperty(this, "paveType", "SINGLEPAVE_01", propertyChanged);     //铺贴方式，默认连续直铺
    this.rootMaterial = new MaterialRawColor({color:utilStringToHexCharCode(DEFAULT_FLOOR_ROOTCOLOR)});
    this.paveDB = {}; //铺贴记录(选砖，选砖)
    utilRootDefineProperty(this, "gapwidth", 0.003, propertyChanged);//this.gapwidth = 0.003; //初始化默认0.003米
    utilRootDefineProperty(this, "gapcolor", DEFAULT_FLOOR_ROOTCOLOR, propertyChanged);//this.gapcolor = DEFAULT_FLOOR_ROOTCOLOR;   
        
    this.rebuild = utilFloorBuildTilePave.bind(this);
    this.clearPaveDB = function(){
	  	this.paveDB = {};
	  }
	  
	this.floorMeasurement = {center:0, inner:0, outer:0};
    //新增铺贴相关初始化
}

Floor.prototype.type = "FLOOR", classInherit(Floor, ModelObject);


utilExtend(Floor.prototype, {	  
    save: function () {
        var saved = classBase(this, "save");
        //材质
        this.floorMaterial && (saved.floorMaterial = this.floorMaterial.id);
        this.ceilingMaterial && (saved.ceilingMaterial = this.ceilingMaterial.id);
        this.rootMaterial && (saved.rootMaterial = this.rootMaterial.id);
        for(var i=0;i<10;++i){
        	this["pave" + i + "Material"] && (saved["pave" + i + "Material"] = this["pave" + i + "Material"].id);
		    }
        
        saved.label = this.label,
            saved.labelX = this.labelX, saved.labelY = this.labelY, saved.profile = this.profile.map(function (p) {
            return p.id;
        }), saved.height3d = this.height3d;
		saved.dirction = this.dirction;
        var floor_loop = utilFloorGetLoopFromProfile(this);
        if (floor_loop) {
            var center = utilMathPolyMassCenter(floor_loop);
            center && !isNaN(center.x) && (saved._m = this.getMeasurement(), saved._cx = center.x,
                saved._cy = center.y);
        }
        
        //by mond 2017        
        this.paveType && (saved.paveType = this.paveType);
        this.gapwidth && (saved.gapwidth = this.gapwidth);
        this.gapcolor && (saved.gapcolor = this.gapcolor);
        //this.paveDB && (saved.paveDB = this.paveDB);
        //铺贴相关
        
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);         
        data.height3d && (this.height3d = data.height3d);
        data.dirction && (this.dirction = data.dirction);
        data.label && (this.label = data.label);
        data.labelX && (this.labelX = data.labelX);
        data.labelY && (this.labelY = data.labelY);
        
        var db = Root.prototype.database;        
        data.floorMaterial ? this.floorMaterial = db[data.floorMaterial] : this.floorMaterial = new Material({
            pid: DEFAULT_FLOOR_MATERIAL_ID
        }); 
        data.ceilingMaterial ? this.ceilingMaterial = db[data.ceilingMaterial] : this.ceilingMaterial = new Material({
            pid: DEFAULT_TILE_MATERIAL_ID
        });
        
        //by mond 2017
        data.rootMaterial ? this.rootMaterial = db[data.rootMaterial] : this.rootMaterial = new MaterialRawColor({
            color: DEFAULT_FLOOR_ROOTCOLOR
        });
        for(var i=0;i<10;++i){
        	data["pave" + i + "Material"] ? this["pave" + i + "Material"] = db[data["pave" + i + "Material"]] : this["pave" + i + "Material"] = 0;
		    }
        data.paveType && (this.paveType = data.paveType);
        data.gapwidth && (this.gapwidth = data.gapwidth);
        data.gapcolor && (this.gapcolor = data.gapcolor);
        //data.paveDB && (this.paveDB = data.paveDB);
        if(!data.paveType && (this.floorMaterial instanceof TileSingle)){
        	//版本兼容，当没有铺贴方式时，读取tileSingle pavetype
        	var paveType = "SINGLEPAVE_01";
	    		switch(this.floorMaterial.pavetype){
	    			case "0":
	    			  paveType = "SINGLEPAVE_01";
	    			break;
	    			case "1":
	    			  paveType = "SINGLEPAVE_06";
	    			break;
	    			case "2":
	    			  paveType = "SINGLEPAVE_04";
	    			break;
	    			case "3":
	    			  //...
	    			break;
	    		}
	    		this.paveType = paveType;
        }
        //铺贴相关
        
        var profile = [];
        data.profile.forEach(function (p) {
            var pro = db[p];
            profile.push(pro);
        }, this);
        this.profile = profile;
        utilModelChangeFlag(this, FLOORFLAG_CHANGED_FOR_REDRAWN);
    },
    getLoop: function () {
        return utilFloorGetLoopFromProfile(this);
    },
    getInsideLoop: function () {
        return utilFloorInsideLoopFromProfile(this);
    },
    getMeasurement: function (type) {
    	  if(type == "inner"){
    	  	  return this.floorMeasurement.inner;
    	  }else if("outer"){
    	  	  return this.floorMeasurement.outer;
    	  }else{
    	  	  return this.floorMeasurement.center;
    	  }
    },
    reset: function (opt) {
        return utilAppFloorplanResetRoom(application, application.doc.floorplan, this, opt);
    },
    dispose: function () {
    	  this.floorMaterial = null;
    	  this.ceilingMaterial = null;
    	  this.rootMaterial = null;
    	  
    	  for(var i=0;i<10;++i){
    	  	this["pave" + i + "Material"] = null;
    	  }
    }
})

function utilFloorplanRebuildFloor(fp) {
    function _getExistingFloorFromProfile(profile, candidates) {
        var floor;
        var loop = utilGetLoopFromProfile(profile);
        candidates.forEach(function (candidate) {
            if (candidate && !floor) {
                var candidateProfile = candidate.profile, match = !0;
                if (profile.forEach(function (p) {
                        0 != match && -1 == candidateProfile.indexOf(p) && (match = !1);
                    }), match && (floor = candidate), !floor) {
                    var candidateLoop = utilGetLoopFromProfile(candidateProfile);
                    !loop || !candidateLoop || loop.length < 3 || candidateLoop.length < 3 || Math.abs(utilMathPolyMeasurement(loop) - utilMathPolyMeasurement(candidateLoop)) < .3 && utilMathIsSamePoint(utilMathPolyMassCenter(loop), utilMathPolyMassCenter(candidateLoop)) && (floor = candidate);
                }
            }
        })
        return floor;
    }

    var points = []
    var lines = [];
    var idx = 0;
    var db = fp.database;
    utilFloorplanForEachWall(fp, function (wall) {
        if(wall.begin && wall.end){
	        points.push({
	            x: wall.begin.x,
	            y: wall.begin.y,
	            id: wall.begin.id
	        }, {
	            x: wall.end.x,
	            y: wall.end.y,
	            id: wall.end.id
	        });
	        lines.push({
	            v1: idx,
	            v2: idx + 1,
	            id: wall.id
	        });
	        idx += 2;
	      };
    });
    var sketches = S2P.MS(points, lines);
    var profiles = S2P.BP(!0);
    __log("--floor count = " + profiles.length);
    var allOldFloors = [];
    utilFloorplanForEachFloor(fp, function (floor) {
        allOldFloors.push(floor);
    }, fp);

    profiles.forEach(function (p) {
        for (var profile = [], i = 0; i < p.e.length; ++i) {
            var e = p.e[i];
            var wall = db[e.s];
            
            //重复墙面不再添加
            //if(profile.indexOf(wall) == -1){
            	profile.push(wall);
            //}           
        }
                
        var floor = _getExistingFloorFromProfile(profile, allOldFloors);
        if (void 0 == floor) {
            if (utilIsProfileValid(profile)) {
                var floor = new Floor();
                utilEntityAddLink(fp, floor);
                utilCatalogGetProductsMetaPromise(application.catalogMgr, [DEFAULT_FLOOR_MATERIAL_ID, DEFAULT_TILE_MATERIAL_ID]).then(function (meta) {
                    floor.floorMaterial = new Material(meta[DEFAULT_FLOOR_MATERIAL_ID]);
                    floor.ceilingMaterial = new Material(meta[DEFAULT_TILE_MATERIAL_ID]);                    
                });
                utilFloorSetFromProfile(floor, profile, sketches);
            }
        } else {
            var idx = allOldFloors.indexOf(floor);
            allOldFloors[idx] = void 0;
            utilFloorSetFromProfile(floor, profile, sketches);
            
            //更新地面
        	  var offset = utilFloorGetBoundaryOffset(floor);
						if(!utilSnapFloorTestOffset(floor, offset)){
							  //删除所有关联波打线
							  utilRemoveLinkedBoundary(floor);
						}else{
							  //刷新对应的波打线
		            utilFloorplanForEachBoundary(fp, function (boundary) {
	                if(boundary.host.id == this.id) {
	                    utilModelChangeFlag(boundary, BOUNDARY_CHANGED_FOR_REDRAWN);
	                }
		            }, floor);
						}
        	  
        }
    });

    utilFloorplanForEachFloor(fp, function (floor) {
    	  //删除地面
        if(-1 != allOldFloors.indexOf(floor)){
        	utilEntityRemoveLink(this, floor);
        }
    }, fp);
}

function utilFloorplanUpdateWallArea(fp) {
	utilFloorplanForEachArea(fp, function (area) {
      area.type != RectArea3d.prototype.type && 
      area.type != RoundArea3d.prototype.type && 
      area.type != Baseboard.prototype.type &&
      area.type != Wallboard.prototype.type
      || utilModelSetFlagOn(area, AREAFLAG_HOST_CHANGED_UPDATE3D);
  });
}

function utilFloorplanUpdateWallAreaByWall(wall) {
	var fp = application.doc.floorplan;
	utilFloorplanForEachArea(fp, function (area) {
   if(area.type == RectArea3d.prototype.type ||
      area.type == RoundArea3d.prototype.type || 
      area.type == Baseboard.prototype.type ||
      area.type == Wallboard.prototype.type){
      (area.host == wall) && utilModelSetFlagOn(area, AREAFLAG_HOST_CHANGED_UPDATE3D);
   }
  });
}

function utilFloorplanForEachBoundary(fp, callback, thisArg) {
    __assert(void 0 != callback), Object.keys(fp.lf).forEach(function (fID) {
        var boundary = fp.lf[fID];
        boundary instanceof Boundary && callback.call(thisArg, boundary);
    });
}

function utilFloorBuildTilePave(){
	var pr = this.paveRebuild;
	var rd = this.redrawn;
	
	var gap = this.gapwidth;  //砖缝
	var floorModel = this;
	var profile = null;
	var insideProfile = null;
	var material = null;
				
	if(this.redrawn && !this.paveRebuild && !this.redrawn2D && !this.redrawn3D){
		//刷新
		this.redrawn = false;
		if(this.type == "FLOOR"){
			insideProfile = utilFloorInsideLoopFromProfile(floorModel);
		  if(insideProfile)
	       profile = utilAdaptorClipperOffset(insideProfile, utilFloorGetBoundaryOffset(this));
	       
	    if(profile){
	    	var loopPath = JSON.stringify(profile);	
	   		if(this.paveLoopPath == loopPath){	    	  
			      this.redrawn2D = false;
			      this.redrawn3D = false;
			      return;
			  }
			  this.paveRebuild = true;
			  this.paveLoopPath = loopPath;
	    }
		}
	}	
	
	if(this.paveRebuild){
		  //强制刷新			
			switch(this.type){
				case "RECTAREA":
				case "RECTAREA3D":
				case "ROUNDAREA":
				case "ROUNDAREA3D":
				case "FREEAREA":
				case "BASEBOARD":
				case "WALLBOARD":
				  material = this.areaMaterial;
				  profile = this.getLoop();
				  //if(profile)
			    //   profile = utilAdaptorClipperOffset(profile, utilFloorGetBoundaryOffset(this)+gap*0.5);
				  break;
				case "FLOOR":
				  material = this.floorMaterial;
				  if(!insideProfile){
				  	insideProfile = utilFloorInsideLoopFromProfile(floorModel);
					  if(insideProfile){
				       profile = utilAdaptorClipperOffset(insideProfile, utilFloorGetBoundaryOffset(this));
				       if(profile){
				       	  this.paveLoopPath = JSON.stringify(profile);
				       }
				    }
				  }				  
				  break;
			}		
			
			this.redrawn2D = true;
			this.redrawn3D = true;
						  				  
	    if(this.type == "FLOOR"){
	    	//重置面积数据
	      this.floorMeasurement = {center:0, inner:0, outer:0};
	      
	      var floor_loop = utilFloorGetLoopFromProfile(this);
	      if(floor_loop){
		      var centerMeasurment = Math.abs(utilMathPolyMeasurement(floor_loop));
		      var wallsMeasurement = 0;
			    for (var i = 0; i < this.profile.length; ++i) {
			        var wall = this.profile[i];
			        var startPt = floor_loop[i];
			        var endPt = floor_loop[i + 1];
			        wallsMeasurement += wall.width * utilMathLineLength(startPt, endPt);
			    }
			
			    //inner
	        insideProfile.push(insideProfile[0]);
	        this.floorMeasurement.inner = Math.abs(utilMathPolyMeasurement(insideProfile));
			    this.floorMeasurement.outer = centerMeasurment + wallsMeasurement / 2;		    
			    this.floorMeasurement.center = centerMeasurment;
			  }
			  
			  if(insideProfile.length >= 2){
			  	var center = utilMathPolyMassCenter(insideProfile);
				  this.labelX = center.x;
	        this.labelY = center.y;
	        var measure = this.getMeasurement("inner");
	        this.measurement = Math.abs(toFixedNumber(measure, 2));
	        this.measurementLabel = this.measurement.toString() + " m²";
			  }			  
	    }	    	    
	    
	  	this.floorRectTiles = [];
	  			
	  	//判断pave_xMaterial是否齐全
	  	var paveMaterialReady = true;
	  	var paveInfo = PAVEMODEL[floorModel.paveType];		
	  	if(paveInfo.pids){
	  		paveInfo.pids.forEach(function(pid,index){
	  			if(!floorModel["pave"+index + "Material"]){
	  				paveMaterialReady = false;
	  			}
	  		});
	  	}
	  			  
	    if (profile && material && paveMaterialReady){
	    	
	    	  //计算铺贴区域
	    	  var floorRect = utilGetProfileRect(profile);
			    			    
			    //step1 创建floorRect中的所有铺砖
		    	var clipperFactor = 10000.0;//clipper缩放因子
		    	var cpr = new ClipperLib.Clipper();
		    	//房间铺砖区域裁剪path(大)
		    	var floorRectClipPaths = [];
		    	floorRectClipPaths.push({X:Math.ceil(floorRect.l * clipperFactor), Y: Math.ceil(floorRect.b* clipperFactor)});
		    	floorRectClipPaths.push({X:Math.ceil(floorRect.l * clipperFactor), Y: Math.ceil(floorRect.t* clipperFactor)});
		    	floorRectClipPaths.push({X:Math.ceil(floorRect.r * clipperFactor), Y: Math.ceil(floorRect.t* clipperFactor)});
		    	floorRectClipPaths.push({X:Math.ceil(floorRect.r * clipperFactor), Y: Math.ceil(floorRect.b* clipperFactor)});
		    	//内墙线裁剪path
		    	var floorInsideClipPaths = profile.map(function(p){
		    		return {X:Math.ceil(p.x * clipperFactor), Y: Math.ceil(p.y * clipperFactor)};
		    	});
		    	//铺贴起始点
		    	var floorRectOrigin = {x:floorRect.l + material.tx, y:floorRect.b + material.ty};
		    	//旋转		    	
		    	var singlepaveRot = paveInfo.rotate || 0;
		    	singlepaveRot += Number(material.rot);
		    	if(this.type == "RECTAREA" || this.type == "RECTAREA3D"){
		    		singlepaveRot += Number(this.rot);
		    		var area = this;
		    		var c = area.center;
		    		var w = area.width;
		    		var h = area.height;
		        
		    		floorRectOrigin.x = c.x - w / 2 + material.tx;
		    		floorRectOrigin.y = c.y - h / 2 + material.ty;
		    		floorRectOrigin = utilMathRotatePointCW(c, floorRectOrigin, this.rot);
		    	}		    	
		    	this.floorRectOrigin = floorRectOrigin;
		    	this.singlepaveRot = singlepaveRot;
			    
			    //获取主砖信息，用来决定整体铺贴相对大小
			    var cuth = 1;      //竖切单元
		    	var cutv = 1;      //横切单元
		    	var scaleW = 1.0;  //宽缩放
		    	var scaleH = 1.0;  //高缩放
		    	this.rootMaterial.setColor && this.rootMaterial.setColor(utilStringToHexCharCode(this.gapcolor));

				var extraCuth=1,extraCutv=1;
				if(material.meta.pid!=="lightyellow"){//排除画区域
					var extraObj=JSON.parse(material.meta.extra);
					extraCuth=extraObj["cuth"]||1
					extraCutv=extraObj["cutv"]||1
				}

		    	if(material.type == TileSingle.prototype.type){
                    cuth = parseInt(material.cuth)*extraCuth;
                    cutv = parseInt(material.cutv)*extraCutv;
		    		//this.gapwidth = Number(material.gapwidth);		    		
		    		//gap = this.gapwidth;
			    }else{
					cuth=extraCuth;
					cutv=extraCutv;
			    }
			    var meta = material.meta;
		    	if(meta.xlen == undefined ||
		    	   meta.pid == "lightyellow"){ //无效的产品长宽
		    		this.paveRebuild = false;
		        this.redrawn = false;
		    	  return;
		    	}
		    	if(material.category == "custom_tile" || material.category == "customparquet"){
			    	//自定义拼花，要求尺寸跟floorRect一致
			    	material.sx = (floorRect.r - floorRect.l)/meta.xlen;
			    	material.sy = (floorRect.t - floorRect.b)/meta.ylen;
			    	if(this.type == "RECTAREA" || this.type == "RECTAREA3D"){
			    		material.sx = area.width/meta.xlen;
			    		material.sy = area.height/meta.ylen;
			    	}
			    }
			    scaleW = material.sx;
			    scaleH = material.sy;		    	
		    	
		    	var tileW = meta.xlen/cuth*scaleW; //切砖大小
		    	var tileH = meta.ylen/cutv*scaleH;
		    	
		    	var mainTileW = tileW; //主砖大小(切砖后的大小)
		    	var mainTileH = tileH;
		    	var mainPaveW = tileW; 
		    	var mainPaveH = tileH;
		    	
		    	
		    	//铺贴方式中的所有铺贴单元
		    	var paveTileModel = {};
		    	var paveTileProfile = {};			    	
		    	var tiles = paveInfo.tiles;
		    	if(mainPaveW < mainPaveH){
		    		tiles = paveInfo.tilesHW || tiles;
		    	}
		    	//提炼铺贴形状(加入预定义切砖大小tw,th
		    	tiles.forEach(function(tile){
		    		  paveTileModel[tile.id] = tile;			    		  
		    		  paveTileProfile[tile.id] = [];
		    		  var tw = (tile.tw != null || tile.tHw != null) ? ((tile.tw||0)*mainTileW + (tile.tHw||0)*mainTileH) : mainTileW;
		    		  var th = (tile.th != null || tile.tWh != null) ? ((tile.th||0)*mainTileH + (tile.tWh||0)*mainTileW) : mainTileH;
		    		  tw = tile.aw || tw;
		    		  th = tile.ah || th;
		    		  
		    		  tile.profile.forEach(function(p){
		    		  	//以主砖大小为基础
				    		paveTileProfile[tile.id].push({x:p.x*tw, y:p.y*th});
				    	})
		    	});
		    	//顶层铺砖（用于裁剪)
		    	var topTiles = paveInfo.topTiles;
		    	topTiles && topTiles.forEach(function(tile){
		    		  paveTileModel[tile.id] = tile;			    		  
		    		  paveTileProfile[tile.id] = [];
		    		  var tw = (tile.tw != null || tile.tHw != null) ? ((tile.tw||0)*mainTileW + (tile.tHw||0)*mainTileH) : mainTileW;
		    		  var th = (tile.th != null || tile.tWh != null) ? ((tile.th||0)*mainTileH + (tile.tWh||0)*mainTileW) : mainTileH;
		    		  tw = tile.aw || tw;
		    		  th = tile.ah || th;
		    		  
		    		  tile.profile.forEach(function(p){
		    		  	//以主砖大小为基础
				    		paveTileProfile[tile.id].push({x:p.x*tw, y:p.y*th});
				    	})
		    	});
		    			    				       		
			    var mainTile = function(){
			    	//随机朝向				    	
			    	function rendomDir(isSquare, ignoreDir){
			    		var dir = 1;
			    		if(!ignoreDir){
			    			var r = Math.random();							
								if(r > 0.25 && r < 0.5){
									dir = isSquare?2:1;                                               
								}else if(r >= 0.5 && r < 0.75){
								  dir = 3;
								}else if(r >= 0.75){                                           
								  dir = isSquare?4:3;                                                             
								}
			    		}		    		
							return dir;
			    	}			    	
			    	//随机选砖(切砖后)
			    	var tileIndex = 0;
			    	function rendomTileIndex(cut,opt){
			    		var ret = opt || {};
			    		if(opt){
			    			ret.th = opt.th % cut.th;
			    			ret.tv = opt.tv % cut.tv;
			    		}else{			
			    			var tileTotal = cut.th*cut.tv;
			    			var index = tileIndex % tileTotal;
			    			ret.th = index % cut.th;
			    			ret.tv = Math.floor(index / cut.th);
			    			
			    			tileIndex += Math.round(Math.random(tileTotal));
			    		}		    		
			    		return ret;
			    	}			    	
			    	//生成单个砖
		    		var buildTile = function(tile, node, tM, id, removeRubble){
		    			var t = {};						
							t.id  = id;									
							t.rot = tM.rot;
							t.pavetileID = tM.id;
							t.paveW = (tM.tw != null || tM.tHw != null) ? ((tM.tw||0)*mainTileW + (tM.tHw||0)*mainTileH) : mainTileW;
							t.paveH = (tM.th != null || tM.tWh != null) ? ((tM.th||0)*mainTileH + (tM.tWh||0)*mainTileW) : mainTileH;
							t.paveW = tM.aw || t.paveW;
							t.paveH = tM.ah || t.paveH;
							
							if(tile) {
								var lLen = Math.sqrt(t.paveW * t.paveW + t.paveH * t.paveH);
								var hx = node.offset.hx != null ? node.offset.hx * mainTileH : 0;  //用于计算以高度为单位的x轴偏移
								var wy = node.offset.wy != null ? node.offset.wy * mainTileW : 0;  //用于计算以长度为单位的y轴偏移
								var lx = node.offset.lx != null ? node.offset.lx * lLen : 0;  //用于计算以对角线长度为单位的x轴偏移
								var ly = node.offset.ly != null ? node.offset.ly * lLen : 0;  //用于计算以对角线长度为单位的y轴偏移
								var ax = node.offset.ax != null ? node.offset.ax : 0;  //用于计算以绝对长度为单位的x轴偏移
								var ay = node.offset.ay != null ? node.offset.ay : 0;  //用于计算以绝对长度为单位的y轴偏移
								t.origin = {
									x: tile.origin.x + mainTileW * node.offset.x + hx + lx + ax,
									y: tile.origin.y + mainTileH * node.offset.y + wy + ly + ay
								};
							}else{
								if(floorModel.type != "FLOOR"){
                                    t.origin = {x:floorRectOrigin.x, y:floorRectOrigin.y};  //原始生成点（未整体旋转前)*/
								}else{
                                    switch(floorModel.direction){
                                        case 0:
                                            t.origin = {x:floorRect.l + material.tx, y:floorRect.t + material.ty-meta.ylen};
                                            break;
                                        case 1:
                                            t.origin = {x:floorRect.r + material.tx-(floorRect.r-floorRect.l)/2 - meta.xlen/2, y:floorRect.t + material.ty-meta.ylen};
                                            break;
                                        case 2:
                                            t.origin = {x:floorRect.r + material.tx- meta.xlen, y:floorRect.t + material.ty-meta.ylen}
                                            break;
                                        case 3:
                                            t.origin = {x:floorRect.l + material.tx, y:floorRect.t + (floorRect.b-floorRect.t)/2 - meta.ylen/2 + material.ty};
                                            break;
                                        case 4:
                                            t.origin = {x:floorRect.r + material.tx-(floorRect.r-floorRect.l)/2- meta.xlen/2, y:floorRect.t + (floorRect.b-floorRect.t)/2 - meta.ylen/2 + material.ty};
                                            break;
                                        case 5:
                                            t.origin = {x:floorRect.r + material.tx- meta.xlen, y:floorRect.t + (floorRect.b-floorRect.t)/2 - meta.ylen/2 + material.ty}
                                            break;
                                        case 6:
                                            t.origin = {x:floorRect.l + material.tx, y:floorRect.b + material.ty};
                                            break;
                                        case 7:
                                            t.origin = {x:floorRect.r + material.tx-(floorRect.r-floorRect.l)/2- meta.xlen/2, y:floorRect.b + material.ty};
                                            break;
                                        case 8:
                                            t.origin = {x:floorRect.r + material.tx- meta.xlen, y:floorRect.b + material.ty};
                                            break;
                                    }
								}

                            }
							t.pos = utilMathRotatePointCW(floorRectOrigin, t.origin, singlepaveRot);
							t.pidIndex = tM.pidIndex;
							t.type = tM.type || "tile"; // tile or group
							if(t.pidIndex != null){
							  t.material = floorModel["pave" + t.pidIndex + "Material"];
							}else{
								t.material = material;
							}
							//朝向部分
							var isSquare = t.paveW == t.paveH;
							var ignoreDir = (t.material.category == "custom_tile" || t.material.category == "parquet" || t.material.category == "customparquet");
							t.dir = this.paveDB[t.id]?this.paveDB[t.id].dir : tM.dir ? tM.dir : rendomDir(isSquare, ignoreDir);
							//实际整体平移和旋转后得到的profile
							if(t.rot){
								//以origin进行旋转后偏移
								t.profile = paveTileProfile[t.pavetileID].map(function(p){
								    var rp = utilMathRotatePointCW({x:0,y:0}, {x:p.x, y:p.y}, t.rot.r);
								    var x = t.rot.x != null ? t.rot.x*t.paveW:0;
								    var y = t.rot.y != null ? t.rot.y*t.paveH:0;
								    var hx = t.rot.hx != null ? t.rot.hx*t.paveH:0;
								    var wy = t.rot.wy != null ? t.rot.wy*t.paveW:0;
								    
								    var l = Math.sqrt(t.paveW*t.paveW + t.paveH*t.paveH);
								    var lx = t.rot.lx != null ? l*t.rot.lx:0;
								    var ly = t.rot.ly != null ? l*t.rot.ly:0;
								    
								    var ax = t.rot.ax != null ? t.rot.ax:0;
								    var ay = t.rot.ay != null ? t.rot.ay:0;
								    
										return utilMathRotatePointCW(floorRectOrigin, {x:t.origin.x + rp.x + x + hx + lx + ax, y:t.origin.y + rp.y + y + wy + ly + ay}, singlepaveRot);
								});
							}else{
								t.profile = paveTileProfile[t.pavetileID].map(function(p){
									  return utilMathRotatePointCW(floorRectOrigin, {x:t.origin.x + p.x, y:t.origin.y + p.y}, singlepaveRot);				    		  
								});
							}
							var paths = t.profile.map(function(p){
								 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
							});
							
							//完整砖面积
							var measure = utilMathPolyMeasurement(t.profile);						
							cpr.Clear();
							cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
							cpr.AddPath(floorRectClipPaths, ClipperLib.PolyType.ptClip, true);
							var solution = new ClipperLib.PolyTree();
							cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
							if(solution.m_AllPolys.length > 0){
								beginVisibleTile = true;
								//进一步对铺砖进行裁剪
								cpr.Clear();
								cpr.AddPath(paths, ClipperLib.PolyType.ptSubject, true);
								cpr.AddPath(floorInsideClipPaths, ClipperLib.PolyType.ptClip, true);
								var solution = new ClipperLib.PolyTree();
								cpr.Execute(ClipperLib.ClipType.ctIntersection, solution);
								if(solution.m_AllPolys.length > 0){
									t.tileProfile = [];
									solution.m_AllPolys.forEach(function(poly){
										var profile = poly.m_polygon.map(function(p){
											return {x:p.X/clipperFactor, y:p.Y/clipperFactor};
										});
										
										//删除碎砖
										if(removeRubble){
											var subMeasure = utilMathPolyMeasurement(profile);
											if(measure - subMeasure < 0.0001){
												t.tileProfile.push(profile);
											}
										}else{
											t.tileProfile.push(profile);
										}
									});
							
									//切砖部分
									var extraCuth = 1;
									var extraCutv = 1;															
									if(material.meta.extra){
										var extraObj = JSON.parse(material.meta.extra);			
										extraCuth = extraObj["cuth"] || 1;
										extraCutv = extraObj["cutv"] || 1;
									}
									var tileCuth = extraCuth;
									var tileCutv = extraCuth;
									if(t.material.type == TileSingle.prototype.type){
										tileCuth = parseInt(t.material.cuth)*extraCuth;
										tileCutv = parseInt(t.material.cutv)*extraCuth;
									}
									var cut = {th:tileCuth,tv:tileCutv};
									t.tileIndex = this.paveDB[t.id]?rendomTileIndex(cut, this.paveDB[t.id].tI):rendomTileIndex(cut);//切砖
								}
							
								t.dir = t.dir == 2 && !isSquare ? 1 : t.dir; //修正朝向
								t.dir = t.dir == 4 && !isSquare ? 3 : t.dir;
								this.paveDB[t.id]={dir:t.dir, tI:t.tileIndex};
							
								//通过裁剪，判断是否为有效铺砖
								return {visible:true,t:t};
							}else{
								return {visible:false,t:t};
							}
		    		}.bind(this);
		    		
		    		//对已经生成的tiles进行profile裁剪
		    		var clipByProfile = function(tile, clippaths, cliptype){
		    			if(tile.type == "tile"){
				    			var tileProfile = tile.tileProfile;
		              if (tileProfile) {
		              	var subTileProfiles = [];//裁剪后的
		                tileProfile.forEach(function (subTileProfile) {		                	
		                	cpr.Clear();
		                	var path = subTileProfile.map(function(p){
												 return {X:Math.ceil(p.x * clipperFactor), Y:Math.ceil(p.y*clipperFactor)};
											});
											cpr.AddPath(path, ClipperLib.PolyType.ptSubject, true);
											cpr.AddPaths(clippaths, ClipperLib.PolyType.ptClip, true);
											var solution = new ClipperLib.PolyTree();
											cpr.Execute(cliptype, solution);
											
											//subTileProfile.length = 0;
											if(solution.m_AllPolys.length > 0){
												solution.m_AllPolys.forEach(function(poly){
													var subProfile = [];													
													poly.m_polygon.forEach(function(p){
														subProfile.push({x:p.X/clipperFactor, y:p.Y/clipperFactor});
													});
													if(utilMathPolyMeasurement(subProfile) > 0.0001){														
													//	subProfile.forEach(function(p){
													//		subTileProfile.push(p);
													//	});
													   subTileProfiles.push(subProfile);
													}
												});
											}else{
												//...未处理												
											}
		                })
		                
		                tileProfile.length = 0;
		                subTileProfiles.forEach(function(subTileProfile){
		                	tileProfile.push(subTileProfile);
		                });		                
		              }
		            }
		    		}		    		
		    		//前置复用函数
		    		///////////////////////////////////////////////////////////////
			    	
			    	var beginVisibleTile = false; //记录是否开始可见铺砖,可见铺砖后，不再接受不在裁剪区出现的砖	    	
			    	var floorRectTiles = [];      //floorRect铺砖
			    	var unpaves = [];//未铺贴
			    	var floorRectTopTiles = [];   //顶砖
			    	
			    	if(topTiles){
			    		//优先完成顶砖
			    		var tM = topTiles[0] || topTiles[0];
			    		var tileRet = buildTile(null,null,tM, "1", true);//topTiles以1开头
			    		var startTopTile = tileRet.t;
			    		
			    		unpaves.push(startTopTile);
			    		floorRectTopTiles.push(startTopTile);
			    		
			    		var tileNum = 0;
				    	while(unpaves.length > 0 && tileNum <= 10000){
				    		tileNum++;
				    		var tile = unpaves.shift();
				    		
				    		//节点    		
				    		var addTiles = [];
				    		var nodes = paveTileModel[tile.pavetileID].nodes;
				    		nodes.forEach(function(node, index){			    			  
				    			  var hx = node.center.hx != null? node.center.hx*mainTileH:0;  //用于计算以高度为单位的x轴偏移
				    			  var wy = node.center.wy != null? node.center.wy*mainTileW:0;  //用于计算以长度为单位的y轴偏移
				    			  var ax = node.center.ax != null? node.center.ax:0;  //用于计算以绝对单位的x轴偏移
				    			  var ay = node.center.ay != null? node.center.ay:0;  //用于计算以绝对单位的y轴偏移
				    			  var center = {x:tile.origin.x + node.center.x*mainTileW + hx + ax, y:tile.origin.y + node.center.y*mainTileH + wy + ay};
				    			  center = utilMathRotatePointCW(floorRectOrigin, center, singlepaveRot);
				    			  //通过center判断是否已经有砖
				    			  var ignore = false;
				    			  for(var i=0;i<floorRectTopTiles.length;++i){
				    			  	var fpTile = floorRectTopTiles[i];
				    			  	var inside = utilMathIsPointInPoly(fpTile.profile, center);
				    			  	if(inside){
				    			  		ignore = true;
				    			  		break;
				    			  	}
				    			  };
				    			  
				    			  if(!ignore){
				    			  	var tM = paveTileModel[node.id];
				    			  	var t = buildTile(tile, node, tM, tile.id + "$" + index, true); //topTile以$为分隔符
				    			  	if(t.visible){
				    			  		//t.t.center = center; //用于测试显示，不显示可以注释
				    			  		unpaves.push(t.t);			    			  		
				    			  		addTiles.push(t.t);			    			  				
				    			  	}else if(!beginVisibleTile){
				    			  		unpaves.push(t.t);
												addTiles.push(t.t);
				    			  	}
				    			  }
				    		}.bind(this));
				    		
				    		addTiles.forEach(function(t){
				    			floorRectTopTiles.push(t);
				    		});
				    	};
			    		
			    		//重置可视砖标志
			    	  beginVisibleTile = false;
			    	}	
			    	var floorRectTopClipPaths = [];
			    	floorRectTopTiles.forEach(function(tile){
			    		var tileProfile = tile.tileProfile;
              if (tileProfile) {
                tileProfile.forEach(function (subTileProfile) {
                	var subProfile = subTileProfile.map(function (t) {
                		return {X:Math.ceil(t.x * clipperFactor), Y:Math.ceil(t.y * clipperFactor)};
                	})
                	floorRectTopClipPaths.push(subProfile);
                })
              }
			    	})
			    	//处理完成顶砖
			    	///////////////////////////////////////////////////////////////////
		    		
		    		//////////////////////////////////////////////////////////////////
		    		//起点砖
		    		var tM = tiles[0] || tiles[0];
		    		var tileRet = buildTile(null,null,tM,"0"); //起始砖以0开头
		    		var startTile = tileRet.t;
		    		
		    		unpaves.push(startTile);
		    		if(startTile.type == "tile"){
		    			floorRectTiles.push(startTile);
		    		} 
			    	
			    	//通过nodes对tile进行周边砖的铺贴,直到所有砖铺完
			    	var tileNum = 0;
			    	while(unpaves.length > 0 && tileNum <= 10000){
			    		tileNum++;
			    		var tile = unpaves.shift();
			    		
			    		//节点    		
			    		var addTiles = [];			    		
			    		if(tile.type == "group"){
			    			//添加groupnodes
			    			var groupnodes = paveTileModel[tile.pavetileID].groupnodes;
			    			groupnodes.forEach(function(node, index){
			    				var tM = paveTileModel[node.id];
			    				var t = buildTile(tile, node, tM, tile.id + "&" + index); //group以&为分隔符
			    				if(t.visible){
										addTiles.push(t.t);
			    				}
			    			}.bind(this));
			    		}

			    		var nodes = paveTileModel[tile.pavetileID].nodes;
			    		nodes.forEach(function(node, index){			    			  
			    			  var hx = node.center.hx != null? node.center.hx*mainTileH:0;  //用于计算以高度为单位的x轴偏移
			    			  var wy = node.center.wy != null? node.center.wy*mainTileW:0;  //用于计算以长度为单位的y轴偏移
			    			  var ax = node.center.ax != null? node.center.ax:0;  
			    			  var ay = node.center.ay != null? node.center.ay:0;  
			    			  var center = {x:tile.origin.x + node.center.x*mainTileW + hx + ax, y:tile.origin.y + node.center.y*mainTileH + wy + ay};
			    			  center = utilMathRotatePointCW(floorRectOrigin, center, singlepaveRot);
			    			  //通过center判断是否已经有砖
			    			  var ignore = false;
			    			  for(var i=0;i<floorRectTiles.length;++i){
			    			  	var fpTile = floorRectTiles[i];
			    			  	var inside = utilMathIsPointInPoly(fpTile.profile, center);
			    			  	if(inside){
			    			  		ignore = true;
			    			  		break;
			    			  	}
			    			  };
			    			  
			    			  if(!ignore){
			    			  	var tM = paveTileModel[node.id];
			    			  	var t = buildTile(tile, node, tM, tile.id + "#" + index); //tile以#为分隔符
			    			  	if(t.visible){
			    			  		//t.t.center = center; //用于测试显示，不显示可以注释
			    			  		unpaves.push(t.t);			    			  		
			    			  		addTiles.push(t.t);			    			  				
			    			  	}else if(!beginVisibleTile){
			    			  		unpaves.push(t.t);
											addTiles.push(t.t);
			    			  	}
			    			  }
			    		}.bind(this));
			    		
			    		addTiles.forEach(function(t){
			    			floorRectTiles.push(t);
			    		});
			    	};
			    	
			    	//使用顶砖进行裁剪
			    	if(floorRectTopClipPaths.length > 0){
			    		floorRectTiles.forEach(function(tile){
			    			clipByProfile(tile, floorRectTopClipPaths, ClipperLib.ClipType.ctDifference);
			    		});
			    	}
			    	
			    	//对墙砖进行门窗裁剪
			    	if(this.type == "WALLBOARD" || this.type == "BASEBOARD" || this.type == "RECTAREA3D" || this.type == "ROUNDAREA3D"){
			    		var geom = utilModelWallGetTessellates(this.host, 0);
			    		if(geom){
				    		if(this.category == "left" || this.category == "right"){
			    				var line2d = this.category == "left" ? [geom[4], geom[5]]:[geom[1], geom[2]]; 
			    				var lineDir = new THREE.Vector2(line2d[1].x, line2d[1].y);
			    				lineDir.sub(line2d[0]);
			    				var xyzOrig = new THREE.Vector3(line2d[0].x, line2d[0].y, 0);
			    				
			    				var fp = application.doc.floorplan;
					    		var holeProfiles = utilModelWallGetSmoothHoleprofiles(this.host, this.category);
					    		//处理门窗
					    		//var openings = 
					    		//openings.forEach(function (hole) {
					        //    var uvwHolePos = utilThreeXYZ2UVW(hole, xyzOrig, lineDir);
					        //    var holeProfile = _utilThreeGetHoleProfileUVW(hole).map(function (pt) {
					        //        return {
					        //            x: pt.x * hole.sx + uvwHolePos.x,
					        //            y: pt.y * hole.sz + uvwHolePos.y,
					        //            z: 0
					        //        };
					        //    });
					        //    holeProfiles.push(holeProfile);
					        //});
					        var clipPaths = [];
						    	holeProfiles.forEach(function(profile){						    		
	                	clipPaths.push(profile.map(function (t) {
	                		return {X:Math.ceil(t.x * clipperFactor), Y:Math.ceil(t.y * clipperFactor)};
	                	}));
						    	});
					        
						    	if(clipPaths.length > 0){
						    		floorRectTiles.forEach(function(tile){
						    			clipByProfile(tile, clipPaths, ClipperLib.ClipType.ctDifference);
						    		});
						    		floorRectTopTiles.forEach(function(tile){
						    			clipByProfile(tile, clipPaths, ClipperLib.ClipType.ctDifference);
						    		});
						    	}
						    	
						    	//处理区域裁剪
					        var topAreas = [];
					        utilFloorplanForEachArea(fp, function (area) {
								   if(area.type == RectArea3d.prototype.type ||
								      area.type == RoundArea3d.prototype.type){								      	
								      (area.host == this.host) && (area.category == this.category) && (area.id != this.id) && (area.level >= this.level) && topAreas.push(area.getLoop());
								   }
								  }.bind(this));
								  topAreas.forEach(function(profile){

									  if (profile) {
										  	  	var clipPaths = [profile.map(function (t) {
										  	return {X:Math.ceil(t.x * clipperFactor), Y:Math.ceil(t.y * clipperFactor)};
										  })];

										  floorRectTiles.forEach(function (tile) {
											  clipByProfile(tile, clipPaths, ClipperLib.ClipType.ctDifference);
										  });
										  floorRectTopTiles.forEach(function (tile) {
											  clipByProfile(tile, clipPaths, ClipperLib.ClipType.ctDifference);
										  });

									  }
						    	});			    		
					      }
					      
					      //墙面直接裁剪				        
				        var width = 0;
				        var height = this.host.height3d;
				        if(this.category == "left"){
				        	if(this.host.bezier){
								  	width = utilMathLineLength(geom[4], geom[8][0]);
								  	for(var i=1;i<geom[8].length;++i){
								  		width += utilMathLineLength(geom[8][i-1], geom[8][i]);
								  	}
								  	width += utilMathLineLength(geom[8][geom[8].length - 1], geom[5]);
								  }else{
								  	width = utilModelWallGetSideLength(this.host, this.category);
								  }
				        }else if(this.category == "right"){				        	
				        	if(this.host.bezier){
								  	width = utilMathLineLength(geom[1], geom[7][0]);
								  	for(var i=1;i<geom[7].length;++i){
								  		width += utilMathLineLength(geom[7][i-1], geom[7][i]);
								  	}
								  	width += utilMathLineLength(geom[7][geom[7].length - 1], geom[2]);
								  }else{
								  	width = utilModelWallGetSideLength(this.host, this.category);
							  	}
				        }else if(this.category == "side0"){
				        	width = utilModelWallGetSideLength(this.host, this.category);
				        }else if(this.category == "side1"){
				        	width = utilModelWallGetSideLength(this.host, this.category);
				        }
				        
				        var wallSideclipPaths = [];
					    	wallSideclipPaths.push({X:Math.ceil(0 * clipperFactor), Y: Math.ceil(0* clipperFactor)});
					    	wallSideclipPaths.push({X:Math.ceil(0 * clipperFactor), Y: Math.ceil(height* clipperFactor)});
					    	wallSideclipPaths.push({X:Math.ceil(width * clipperFactor), Y: Math.ceil(height* clipperFactor)});
					    	wallSideclipPaths.push({X:Math.ceil(width * clipperFactor), Y: Math.ceil(0* clipperFactor)});
					    	wallSideclipPaths = [wallSideclipPaths];					    	
					    	floorRectTiles.forEach(function(tile){
				    			clipByProfile(tile, wallSideclipPaths, ClipperLib.ClipType.ctIntersection);
				    		});
				    		floorRectTopTiles.forEach(function(tile){
				    			clipByProfile(tile, wallSideclipPaths, ClipperLib.ClipType.ctIntersection);
				    		});
				    		//墙面直接裁剪 end
					    }
			    	}
			    	
			    	this.floorRectTiles = floorRectTiles.concat(floorRectTopTiles);
			    }.bind(this);
			    
			    mainTile();
	    }
	  }
	  
	  this.paveRebuild = false;
		this.redrawn = false;
}
// sourceURL=src\model\floor.js