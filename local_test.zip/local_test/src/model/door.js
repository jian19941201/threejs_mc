//门
function Door(meta) {
    classBase(this, meta);
    entityPropertyChangedCallback.bind(this);
}

Door.prototype.type = "DOOR";
classInherit(Door, Opening);
utilExtend(Door.prototype, {
    save: function () {
        var saved = classBase(this, "save");
        return saved;
    },
    load: function (data) {
        classBase(this, "load", data);
    }
})